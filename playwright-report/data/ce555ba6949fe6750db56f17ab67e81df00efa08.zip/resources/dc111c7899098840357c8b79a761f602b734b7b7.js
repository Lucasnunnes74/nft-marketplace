import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-Bk_YeHJf.js?v=1500aecb";
import { t as require_react } from "/node_modules/.vite/deps/react-Bk9vEtng.js?v=1500aecb";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-XdfVfXhi.js?v=1500aecb";
//#region node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
/**
* The context that `useQueryClient` reads from. `QueryClientProvider` is the normal way to set it.
*/
var QueryClientContext = import_react.createContext(void 0);
/**
* The `useQueryClient` hook returns the current `QueryClient` instance.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The current `QueryClient` instance.
* @throws {Error} If no `queryClient` argument is passed and no `QueryClientProvider` is found in the
* component tree.
*/
var useQueryClient = (queryClient) => {
	const client = import_react.useContext(QueryClientContext);
	if (queryClient) return queryClient;
	if (!client) throw new Error("No QueryClient set, use QueryClientProvider to set one");
	return client;
};
/**
* Use the `QueryClientProvider` component to connect and provide a `QueryClient` to your application. Also
* calls `client.mount()`/`client.unmount()` as this component mounts/unmounts, which subscribes the client to
* focus/online events (resuming any paused mutations and refetching as needed when the app regains focus or
* comes back online).
* @param props - The `client` to provide, and the `children` that get access to it.
* @returns The provided `children`, wrapped so they can read the `QueryClient` via `useQueryClient`.
* @example
* ```tsx
* import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
*
* const queryClient = new QueryClient()
*
* function App() {
*   return <QueryClientProvider client={queryClient}>...</QueryClientProvider>
* }
* ```
*/
var QueryClientProvider = ({ client, children }) => {
	import_react.useEffect(() => {
		client.mount();
		return () => {
			client.unmount();
		};
	}, [client]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientContext.Provider, {
		value: client,
		children
	});
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/timeoutManager.js
var defaultTimeoutProvider = {
	setTimeout: (callback, delay) => setTimeout(callback, delay),
	clearTimeout: (timeoutId) => clearTimeout(timeoutId),
	setInterval: (callback, delay) => setInterval(callback, delay),
	clearInterval: (intervalId) => clearInterval(intervalId)
};
/**
* Allows customization of how timeouts are created.
*
* `@tanstack/query-core` makes liberal use of timeouts to implement `staleTime`
* and `gcTime`. The default TimeoutManager provider uses the platform's global
* `setTimeout` implementation, which is known to have scalability issues with
* thousands of timeouts on the event loop.
*
* If you hit this limitation, consider providing a custom TimeoutProvider that
* coalesces timeouts.
*/
var TimeoutManager = class {
	#provider = defaultTimeoutProvider;
	#providerCalled = false;
	/**
	* `setTimeoutProvider` can be used to set a custom implementation of the
	* `setTimeout`, `clearTimeout`, `setInterval`, `clearInterval` functions,
	* called a `TimeoutProvider`.
	*
	* This may be useful if you notice event loop performance issues with
	* thousands of queries. A custom TimeoutProvider could also support timer
	* delays longer than the global `setTimeout` maximum delay value of about
	* 24 days.
	*
	* It is important to call `setTimeoutProvider` before creating a
	* QueryClient or queries, so that the same provider is used consistently
	* for all timers in the application, since different TimeoutProviders
	* cannot cancel each others' timers.
	* @param provider - The `TimeoutProvider` to use for all timers from now on.
	* @example
	* ```ts
	* import { timeoutManager, QueryClient } from '@tanstack/query-core'
	* import { CustomTimeoutProvider } from './CustomTimeoutProvider'
	*
	* timeoutManager.setTimeoutProvider(new CustomTimeoutProvider())
	*
	* export const queryClient = new QueryClient()
	* ```
	*/
	setTimeoutProvider(provider) {
		if (this.#providerCalled && provider !== this.#provider) console.error(`[timeoutManager]: Switching provider after calls to previous provider might result in unexpected behavior.`, {
			previous: this.#provider,
			provider
		});
		this.#provider = provider;
		this.#providerCalled = false;
	}
	/**
	* `setTimeout` schedules a callback to run after approximately `delay`
	* milliseconds, like the global `setTimeout` function. The callback can be
	* canceled with `clearTimeout`.
	*
	* It returns a timer ID, which may be a number or an object that can be
	* coerced to a number via `Symbol.toPrimitive`.
	* @param callback - The function to call when the timeout elapses.
	* @param delay - The time to wait before calling `callback`, in milliseconds.
	* @returns The timer ID, to pass to {@link TimeoutManager#clearTimeout}.
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const timeoutId = timeoutManager.setTimeout(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* const timeoutIdNumber: number = Number(timeoutId)
	* ```
	*/
	setTimeout(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setTimeout(callback, delay);
	}
	/**
	* `clearTimeout` cancels a timeout callback scheduled with `setTimeout`,
	* like the global `clearTimeout` function. It should be called with a
	* timer ID returned by `setTimeout`.
	* @param timeoutId - The timer ID returned by `setTimeout`, or `undefined`.
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const timeoutId = timeoutManager.setTimeout(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* timeoutManager.clearTimeout(timeoutId)
	* ```
	*/
	clearTimeout(timeoutId) {
		this.#provider.clearTimeout(timeoutId);
	}
	/**
	* `setInterval` schedules a callback to be called approximately every
	* `delay` milliseconds, like the global `setInterval` function.
	*
	* Like `setTimeout`, it returns a timer ID, which may be a number or an
	* object that can be coerced to a number via `Symbol.toPrimitive`.
	* @param callback - The function to call on every interval.
	* @param delay - The time between calls, in milliseconds.
	* @returns The timer ID, to pass to {@link TimeoutManager#clearInterval}.
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const intervalId = timeoutManager.setInterval(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	* ```
	*/
	setInterval(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setInterval(callback, delay);
	}
	/**
	* `clearInterval` can be used to cancel an interval, like the global
	* `clearInterval` function. It should be called with an interval ID
	* returned by `setInterval`.
	* @param intervalId - The timer ID returned by `setInterval`, or `undefined`.
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const intervalId = timeoutManager.setInterval(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* timeoutManager.clearInterval(intervalId)
	* ```
	*/
	clearInterval(intervalId) {
		this.#provider.clearInterval(intervalId);
	}
};
/**
* Singleton instance of {@link TimeoutManager}, used throughout TanStack Query to schedule and cancel timers.
*/
var timeoutManager = new TimeoutManager();
/**
* In many cases code wants to delay to the next event loop tick; this is not
* mediated by {@link timeoutManager}.
*
* This function is provided to make auditing the `tanstack/query-core` for
* incorrect use of system `setTimeout` easier.
* @param callback - The function to call on the next event loop tick.
*/
function systemSetTimeoutZero(callback) {
	setTimeout(callback, 0);
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/utils.js
/**
* @deprecated use `environmentManager.isServer()` instead.
*/
var isServer = typeof window === "undefined" || "Deno" in globalThis;
function noop() {}
/**
* Resolves an {@link Updater}: calls it with `input` if it is a function, otherwise returns it as
* is.
* @param updater - The new value, or a function that receives `input` and returns the new value.
* @param input - The current value, passed to `updater` if it is a function.
* @returns The new value.
*/
function functionalUpdate(updater, input) {
	return typeof updater === "function" ? updater(input) : updater;
}
/**
* Checks whether a value can be used as a timeout: a non-negative, finite number.
* @param value - The value to check.
* @returns `true` if `value` is a number that is `>= 0` and not `Infinity`.
*/
function isValidTimeout(value) {
	return typeof value === "number" && value >= 0 && value !== Infinity;
}
/**
* Calculates how long until data updated at `updatedAt` becomes stale.
* @param updatedAt - The timestamp, in milliseconds, at which the data was last updated.
* @param staleTime - The time, in milliseconds, after which data is considered stale. Defaults to
* `0`.
* @returns The remaining time in milliseconds, or `0` if the data is already stale.
*/
function timeUntilStale(updatedAt, staleTime) {
	return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
}
/**
* Resolves an option that can be given either as a value or as a function of the query, such as
* `staleTime`.
* @param value - The option value, or a function that receives `query` and returns the value.
* @param query - The query passed to `value` if it is a function.
* @returns The resolved value, or `undefined` if `value` is `undefined`.
*/
function resolveQueryValue(value, query) {
	return typeof value === "function" ? value(query) : value;
}
/**
* Checks whether a query matches the given {@link QueryFilters}.
* Every filter that is specified must match; filters that are left unspecified are ignored.
* @param filters - The filters to check the query against.
* @param query - The query to check.
* @returns `true` if the query matches every specified filter.
* @example
* ```ts
* const queryCache = queryClient.getQueryCache()
*
* const matchingQueries = queryCache
*   .getAll()
*   .filter((query) => matchQuery({ queryKey: ['posts'] }, query))
* ```
*/
function matchQuery(filters, query) {
	const { type = "all", exact, fetchStatus, predicate, queryKey, stale } = filters;
	if (queryKey) {
		if (exact) {
			if (query.queryHash !== hashQueryKeyByOptions(queryKey, query.options)) return false;
		} else if (!partialMatchKey(query.queryKey, queryKey)) return false;
	}
	if (type !== "all") {
		const isActive = query.isActive();
		if (type === "active" && !isActive) return false;
		if (type === "inactive" && isActive) return false;
	}
	if (typeof stale === "boolean" && query.isStale() !== stale) return false;
	if (fetchStatus && fetchStatus !== query.state.fetchStatus) return false;
	if (predicate && !predicate(query)) return false;
	return true;
}
/**
* Checks whether a mutation matches the given {@link MutationFilters}.
* Every filter that is specified must match; filters that are left unspecified are ignored.
* If a `mutationKey` filter is provided but the mutation has no `mutationKey` of its own, it does not match.
* @param filters - The filters to check the mutation against.
* @param mutation - The mutation to check.
* @returns `true` if the mutation matches every specified filter.
* @example
* ```ts
* const mutationCache = queryClient.getMutationCache()
*
* const matchingMutations = mutationCache
*   .getAll()
*   .filter((mutation) => matchMutation({ mutationKey: ['addPost'] }, mutation))
* ```
*/
function matchMutation(filters, mutation) {
	const { exact, status, predicate, mutationKey } = filters;
	if (mutationKey) {
		if (!mutation.options.mutationKey) return false;
		if (exact) {
			if (hashKey(mutation.options.mutationKey) !== hashKey(mutationKey)) return false;
		} else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) return false;
	}
	if (status && mutation.state.status !== status) return false;
	if (predicate && !predicate(mutation)) return false;
	return true;
}
/**
* Hashes a query key with the query's `queryKeyHashFn` option, falling back to {@link hashKey}.
* @param queryKey - The query key to hash.
* @param options - The query options that may provide a custom `queryKeyHashFn`.
* @returns The query hash, a string that identifies the query in the cache.
*/
function hashQueryKeyByOptions(queryKey, options) {
	return (options?.queryKeyHashFn || hashKey)(queryKey);
}
/**
* Default query & mutation keys hash function.
* Hashes the value into a stable hash.
* @param queryKey - The query or mutation key to hash.
* @returns The stable hash of the key, as a JSON string.
* @example
* ```ts
* // Object keys are sorted, so key order doesn't affect the hash:
* hashKey(['todos', { page: 1, filter: 'done' }]) // === '["todos",{"filter":"done","page":1}]'
* ```
*/
function hashKey(queryKey) {
	return JSON.stringify(queryKey, (_, val) => isPlainObject(val) ? Object.keys(val).sort().reduce((result, key) => {
		result[key] = val[key];
		return result;
	}, {}) : val);
}
function partialMatchKey(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (a && b && typeof a === "object" && typeof b === "object") {
		if (Array.isArray(a) && Array.isArray(b)) {
			if (b.length > a.length) return false;
			for (let i = 0; i < b.length; i++) if (!partialMatchKey(a[i], b[i])) return false;
			return true;
		}
		const bKeys = Object.keys(b);
		for (const key of bKeys) if (!partialMatchKey(a[key], b[key])) return false;
		return true;
	}
	return false;
}
var hasOwn = Object.prototype.hasOwnProperty;
function replaceEqualDeep(a, b, depth = 0) {
	if (a === b) return a;
	if (depth > 500) return b;
	const array = isPlainArray(a) && isPlainArray(b);
	if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
	const aSize = (array ? a : Object.keys(a)).length;
	const bItems = array ? b : Object.keys(b);
	const bSize = bItems.length;
	const copy = array ? new Array(bSize) : {};
	let equalItems = 0;
	for (let i = 0; i < bSize; i++) {
		const key = array ? i : bItems[i];
		const aItem = a[key];
		const bItem = b[key];
		if (aItem === bItem) {
			copy[key] = aItem;
			if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
			continue;
		}
		if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
			copy[key] = bItem;
			continue;
		}
		const v = replaceEqualDeep(aItem, bItem, depth + 1);
		copy[key] = v;
		if (v === aItem) equalItems++;
	}
	return aSize === bSize && equalItems === aSize ? a : copy;
}
/**
* Shallow compare objects.
* @param a - The first object.
* @param b - The second object, or `undefined`.
* @returns `true` if both objects have the same keys, with strictly equal values for each key.
*/
function shallowEqualObjects(a, b) {
	if (!b || Object.keys(a).length !== Object.keys(b).length) return false;
	for (const key in a) if (a[key] !== b[key]) return false;
	return true;
}
/**
* Checks whether a value is an array with no holes and no extra properties.
* @param value - The value to check.
* @returns `true` if `value` is an array whose number of own keys equals its `length`.
*/
function isPlainArray(value) {
	return Array.isArray(value) && value.length === Object.keys(value).length;
}
/**
* Checks whether a value is a plain object, e.g. created with an object literal or
* `Object.create(null)`.
* @param o - The value to check.
* @returns `true` if `o` is a plain object.
*/
function isPlainObject(o) {
	if (!hasObjectPrototype(o)) return false;
	const objectPrototype = Object.getPrototypeOf(o);
	const ctor = objectPrototype?.constructor;
	if (ctor === void 0) return true;
	if (typeof ctor !== "function") return false;
	const prot = ctor.prototype;
	if (!hasObjectPrototype(prot)) return false;
	if (!prot.hasOwnProperty("isPrototypeOf")) return false;
	if (objectPrototype !== Object.prototype) return false;
	return true;
}
/**
* Checks whether a value's `Object.prototype.toString` tag is `[object Object]`.
* @param o - The value to check.
* @returns `true` if the tag is `[object Object]`.
*/
function hasObjectPrototype(o) {
	return Object.prototype.toString.call(o) === "[object Object]";
}
/**
* Waits for the given time, using the configured {@link timeoutManager}.
* @param timeout - The time to wait, in milliseconds.
* @returns A promise that resolves after `timeout` milliseconds.
*/
function sleep(timeout) {
	return new Promise((resolve) => {
		timeoutManager.setTimeout(resolve, timeout);
	});
}
/**
* Applies a query's `structuralSharing` option when writing new data.
* @param prevData - The previously cached data.
* @param data - The new data.
* @param options - The query options, whose `structuralSharing` decides how the data is merged.
* @returns The result of a custom `structuralSharing` function, `data` with its unchanged parts
* replaced by those of `prevData` by default, or `data` as is if `structuralSharing` is `false`.
* @throws {Error} The error from the default structural sharing, e.g. when the data is not JSON serializable.
* Outside production, it is also logged to the console.
*/
function replaceData(prevData, data, options) {
	if (typeof options.structuralSharing === "function") return options.structuralSharing(prevData, data);
	else if (options.structuralSharing !== false) try {
		return replaceEqualDeep(prevData, data);
	} catch (error) {
		console.error(`Structural sharing requires data to be JSON serializable. To fix this, turn off structuralSharing or return JSON-serializable data from your queryFn. [${options.queryHash}]: ${error}`);
		throw error;
	}
	return data;
}
/**
* Intended to be passed as a query's `placeholderData` option, for example
* `placeholderData: keepPreviousData`. Instead of resetting the query's data to `undefined` while a new
* query key is fetching, it keeps displaying the previously fetched data until the new data arrives.
* @param previousData - The data of the previous query key, passed by the observer.
* @returns The previous data, unchanged.
* @example
* ```ts
* new QueryObserver(queryClient, {
*   queryKey: ['posts', page],
*   queryFn: () => fetchPosts(page),
*   placeholderData: keepPreviousData,
* })
* ```
*/
function keepPreviousData(previousData) {
	return previousData;
}
/**
* Returns a new array with `item` added at the end. If that makes the array longer than `max`,
* the first item is dropped. Only one item is dropped, so the result can still exceed `max` if
* `items` already did.
* @param items - The current items.
* @param item - The value to append.
* @param max - The length above which an item is dropped. `0` (the default) means no limit.
* @returns A new array with `item` added.
*/
function addToEnd(items, item, max = 0) {
	const newItems = [...items, item];
	return max && newItems.length > max ? newItems.slice(1) : newItems;
}
/**
* Returns a new array with `item` added at the start. If that makes the array longer than `max`,
* the last item is dropped. Only one item is dropped, so the result can still exceed `max` if
* `items` already did.
* @param items - The current items.
* @param item - The value to prepend.
* @param max - The length above which an item is dropped. `0` (the default) means no limit.
* @returns A new array with `item` added.
*/
function addToStart(items, item, max = 0) {
	const newItems = [item, ...items];
	return max && newItems.length > max ? newItems.slice(0, -1) : newItems;
}
/**
* Sentinel value that can be passed as a query's `queryFn` to conditionally disable the query (equivalent
* to `enabled: false`) while preserving full type inference for the query's data. Unlike `enabled: false`,
* a query disabled via `skipToken` cannot be triggered with `refetch`.
* @example
* ```ts
* new QueryObserver(queryClient, {
*   queryKey: ['post', postId],
*   queryFn: postId != null ? () => fetchPost(postId) : skipToken,
* })
* ```
*/
var skipToken = Symbol();
/**
* Returns the function to call for a fetch. If there is no `queryFn` but the fetch was started from
* an `initialPromise`, that promise is returned instead. If there is no usable `queryFn` (missing or
* {@link skipToken}), the returned function rejects with a `Missing queryFn` error.
* @param options - The query options with the `queryFn`, and the `queryHash` used in error messages.
* @param fetchOptions - The fetch options, which may carry an `initialPromise`.
* @returns The function to call for the fetch.
*/
function ensureQueryFn(options, fetchOptions) {
	if (options.queryFn === skipToken) console.error(`Attempted to invoke queryFn when set to skipToken. This is likely a configuration error. Query hash: '${options.queryHash}'`);
	if (!options.queryFn && fetchOptions?.initialPromise) return () => fetchOptions.initialPromise;
	if (!options.queryFn || options.queryFn === skipToken) return () => Promise.reject(/* @__PURE__ */ new Error(`Missing queryFn: '${options.queryHash}'`));
	return options.queryFn;
}
/**
* Resolves a `throwOnError` option to a boolean.
* If `throwOnError` is a function, it is called with `params` (e.g. the error and, depending on the caller,
* additional context such as the query or mutation) and its result is returned, allowing the throwing
* behavior to be decided per error. Otherwise, `throwOnError` itself is coerced to a boolean (`undefined`
* resolves to `false`).
* @param throwOnError - The `throwOnError` option: a boolean, a function that decides per error, or
* `undefined`.
* @param params - The arguments passed to `throwOnError` if it is a function.
* @returns Whether the error should be thrown.
* @example
* ```ts
* const throwOnError =
*   query.state.error && typeof options.throwOnError === 'function'
*     ? shouldThrowError(options.throwOnError, [query.state.error, query])
*     : options.throwOnError
* ```
*/
function shouldThrowError(throwOnError, params) {
	if (typeof throwOnError === "function") return throwOnError(...params);
	return !!throwOnError;
}
/**
* Adds a lazy `signal` getter to an object, such as a query function context. The first time
* `signal` is read, `onCancelled` is registered for the signal's `abort` event (or called right
* away if it is already aborted), so cancellation is only tracked when the signal is actually used.
* @param object - The object to add the `signal` property to.
* @param getSignal - Returns the `AbortSignal`. Called once, when `signal` is first read.
* @param onCancelled - Called when the signal is aborted, if `signal` was read.
* @returns The same object, with the `signal` property added.
*/
function addConsumeAwareSignal(object, getSignal, onCancelled) {
	let consumed = false;
	let signal;
	Object.defineProperty(object, "signal", {
		enumerable: true,
		get: () => {
			signal ??= getSignal();
			if (consumed) return signal;
			consumed = true;
			if (signal.aborted) onCancelled();
			else signal.addEventListener("abort", onCancelled, { once: true });
			return signal;
		}
	});
	return object;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/environmentManager.js
var isServerFn = () => isServer;
/**
* Returns whether the current runtime should be treated as a server environment.
* @returns `true` if the runtime is treated as a server.
*/
var isServer$2 = () => isServerFn();
/**
* Manages how TanStack Query detects whether the current runtime should be treated as
* server-side, which disables scheduling refetch timers and changes the default `retry` count
* and `gcTime`. By default, the detection treats a missing `window` (or the presence of a
* `Deno` global) as server.
*
* Override this for runtimes where that default detection would give the wrong answer — for
* example, a Service Worker, where `window` is undefined even though the environment should
* behave like a client.
* @example
* ```ts
* import { environmentManager } from '@tanstack/query-core'
*
* environmentManager.setIsServer(() => false)
* ```
*/
var environmentManager = {
	isServer: isServer$2,
	/**
	* Overrides the server check globally.
	* @param isServerValue - A function that returns whether the runtime should be treated as a
	* server.
	*/
	setIsServer(isServerValue) {
		isServerFn = isServerValue;
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/subscribable.js
/**
* The base class behind everything in Query that you can subscribe to: `QueryCache`, `MutationCache`,
* the observers, and the `FocusManager`/`OnlineManager` behind `focusManager` and `onlineManager`.
* Subclasses decide what a listener receives and when it is called.
*/
var Subscribable = class {
	constructor() {
		this.listeners = /* @__PURE__ */ new Set();
		this.subscribe = this.subscribe.bind(this);
	}
	/**
	* Registers a listener to be called on every update this object notifies about. Returns a function
	* that removes the listener again — call it to stop listening. The base class never drops a listener
	* on its own, though some subclasses clear all of theirs in `destroy()`.
	* @param listener - Called on each update, with whatever the subclass passes to its subscribers.
	* @returns A function that removes the listener.
	* @example
	* ```ts
	* const unsubscribe = subscribable.subscribe(() => {
	*   // react to the update
	* })
	*
	* unsubscribe()
	* ```
	*/
	subscribe(listener) {
		this.listeners.add(listener);
		this.onSubscribe();
		return () => {
			this.listeners.delete(listener);
			this.onUnsubscribe();
		};
	}
	/**
	* Returns `true` while at least one listener is registered, `false` once they have all unsubscribed.
	* @returns `true` if at least one listener is registered.
	*/
	hasListeners() {
		return this.listeners.size > 0;
	}
	/**
	* Called after a listener is added. Does nothing here; subclasses override it, e.g. to start
	* tracking what they observe once the first listener subscribes.
	*/
	onSubscribe() {}
	/**
	* Called after a listener is removed. Does nothing here; subclasses override it, e.g. to clean up
	* once the last listener unsubscribes.
	*/
	onUnsubscribe() {}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/focusManager.js
/**
* The `FocusManager` manages the focus state within TanStack Query.
*
* It can be used to change the default event listeners or to manually change the focus state.
*/
var FocusManager = class extends Subscribable {
	#focused;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onFocus) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const listener = () => onFocus();
				window.addEventListener("visibilitychange", listener, false);
				return () => {
					window.removeEventListener("visibilitychange", listener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	/**
	* `setEventListener` can be used to set a custom event listener that will
	* be used to determine the focus state. The provided `setup` function
	* receives a `setFocused` callback: call it with a `boolean` to manually
	* set the focus state, or with no arguments to re-evaluate the current
	* focus state and notify subscribers.
	* @param setup - Receives the `setFocused` callback, registers the event listener, and may return
	* a cleanup function that is called when the listener is replaced or no longer needed.
	* @example
	* ```ts
	* import { focusManager } from '@tanstack/query-core'
	*
	* focusManager.setEventListener((handleFocus) => {
	*   const listener = () => handleFocus()
	*   // Listen to visibilitychange
	*   if (typeof window !== 'undefined' && window.addEventListener) {
	*     window.addEventListener('visibilitychange', listener, false)
	*   }
	*
	*   return () => {
	*     // Be sure to unsubscribe if a new handler is set
	*     window.removeEventListener('visibilitychange', listener)
	*   }
	* })
	* ```
	*/
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup((focused) => {
			if (typeof focused === "boolean") this.setFocused(focused);
			else this.onFocus();
		});
	}
	/**
	* `setFocused` can be used to manually set the focus state. Set `undefined`
	* to fall back to the default focus check.
	* @param focused - The focus state, or `undefined` to use the default focus check.
	* @example
	* ```ts
	* import { focusManager } from '@tanstack/query-core'
	*
	* // Set focused
	* focusManager.setFocused(true)
	*
	* // Set unfocused
	* focusManager.setFocused(false)
	*
	* // Fallback to the default focus check
	* focusManager.setFocused(undefined)
	* ```
	*/
	setFocused(focused) {
		if (this.#focused !== focused) {
			this.#focused = focused;
			this.onFocus();
		}
	}
	/**
	* `onFocus` notifies all subscribed listeners with the current focus state.
	*/
	onFocus() {
		const isFocused = this.isFocused();
		this.listeners.forEach((listener) => {
			listener(isFocused);
		});
	}
	/**
	* `isFocused` can be used to get the current focus state.
	* @returns The focus state set with `setFocused`, or otherwise whether the document is visible.
	*/
	isFocused() {
		if (typeof this.#focused === "boolean") return this.#focused;
		return globalThis.document?.visibilityState !== "hidden";
	}
};
/**
* Singleton instance of {@link FocusManager}, used to manage and observe the focus state within TanStack Query.
*/
var focusManager = new FocusManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/hydration.js
/**
* Reads the value of a promise synchronously if it has already resolved, e.g. a thenable that
* resolves within its `then` call.
* @param promise - The promise to read.
* @returns An object with the resolved `data`, or `undefined` if the promise hasn't resolved
* synchronously (or resolved with `undefined`).
*/
function tryResolveSync(promise) {
	let data;
	promise.then((result) => {
		data = result;
		return result;
	}, noop)?.catch?.(noop);
	if (data !== void 0) return { data };
}
/**
* Dehydrates a single `Mutation` into a serializable snapshot of its key, state, scope, and meta.
* @param mutation - The mutation to dehydrate.
* @returns The dehydrated mutation.
*/
function dehydrateMutation(mutation) {
	return {
		mutationKey: mutation.options.mutationKey,
		state: mutation.state,
		...mutation.options.scope && { scope: mutation.options.scope },
		...mutation.meta && { meta: mutation.meta }
	};
}
/**
* Prepares the in-flight promise of a pending query for dehydration: applies `serializeData` to its
* result, and redacts its rejection error unless `shouldRedactErrors` returns `false` for it.
* @param query - The pending query whose promise is dehydrated.
* @param serializeData - Optional transform applied to the resolved data.
* @param shouldRedactErrors - Optional predicate; if it returns `false` for the rejection error,
* that
* error is kept as-is instead of being redacted.
* @returns The transformed promise, or `undefined` if the query has no in-flight promise.
*/
function dehydratePromise(query, serializeData, shouldRedactErrors) {
	const promise = query.promise?.then(serializeData).catch((error) => {
		if (shouldRedactErrors?.(error) === false) return Promise.reject(error);
		console.error(`A query that was dehydrated as pending ended up rejecting. [${query.queryHash}]: ${error}; The error will be redacted in production builds`);
		return Promise.reject(/* @__PURE__ */ new Error("redacted"));
	});
	promise?.catch(noop);
	return promise;
}
/**
* Dehydrates a single `Query` into a serializable `DehydratedQuery` snapshot. Note that most query config (e.g.
* `queryFn`, `staleTime`) is not dehydrated but instead meant to be configured again when consuming the
* de/rehydrated data, typically with `useQuery` on the client. If the query is still `pending`, its in-flight
* promise is dehydrated too so it can be resumed on the other side instead of re-fetched.
* @param query - The query to dehydrate.
* @param serializeData - Optional transform applied to `query.state.data` before it is included in the snapshot.
* @param shouldRedactErrors - Optional predicate; if it returns `false` for the promise's rejection error, that
* error is kept as-is instead of being redacted.
* @returns The dehydrated query.
*/
function dehydrateQuery(query, serializeData, shouldRedactErrors) {
	return {
		dehydratedAt: Date.now(),
		state: {
			...query.state,
			...query.state.data !== void 0 && { data: serializeData ? serializeData(query.state.data) : query.state.data }
		},
		queryKey: query.queryKey,
		queryHash: query.queryHash,
		...query.state.status === "pending" && { promise: dehydratePromise(query, serializeData, shouldRedactErrors) },
		...query.meta && { meta: query.meta },
		...query.queryType && { queryType: query.queryType }
	};
}
/**
* The default `shouldDehydrateMutation` predicate used by `dehydrate`. Only dehydrates mutations that are
* currently paused (e.g. paused by `networkMode` while offline).
* @param mutation - The mutation to check.
* @returns `true` if the mutation is paused.
*/
function defaultShouldDehydrateMutation(mutation) {
	return mutation.state.isPaused;
}
/**
* The default `shouldDehydrateQuery` predicate used by `dehydrate`. Only dehydrates queries whose status is
* `'success'`.
* @param query - The query to check.
* @returns `true` if the query's status is `'success'`.
*/
function defaultShouldDehydrateQuery(query) {
	return query.state.status === "success";
}
/**
* Dehydrates a `QueryClient`'s cache (queries and mutations) into a plain, serializable `DehydratedState`,
* typically to embed in server-rendered markup and later restore into a client-side `QueryClient` via `hydrate`.
* Which queries/mutations are included, and how their data/errors are transformed, is controlled by `options`,
* falling back to the client's `dehydrate` default options, and finally to `defaultShouldDehydrateQuery` /
* `defaultShouldDehydrateMutation`.
* @param client - The client whose cache is dehydrated.
* @param options - Controls which queries and mutations are included and how their data and errors
* are transformed. Each option falls back to the client's `defaultOptions.dehydrate`.
* @returns The dehydrated state, with the included `queries` and `mutations`.
* @example
* ```ts
* const queryClient = new QueryClient()
*
* await queryClient.prefetchQuery({
*   queryKey: ['posts'],
*   queryFn: getPosts,
* })
*
* const dehydratedState = dehydrate(queryClient)
* ```
*/
function dehydrate(client, options = {}) {
	const filterMutation = options.shouldDehydrateMutation ?? client.getDefaultOptions().dehydrate?.shouldDehydrateMutation ?? defaultShouldDehydrateMutation;
	const mutations = client.getMutationCache().getAll().flatMap((mutation) => filterMutation(mutation) ? [dehydrateMutation(mutation)] : []);
	const filterQuery = options.shouldDehydrateQuery ?? client.getDefaultOptions().dehydrate?.shouldDehydrateQuery ?? defaultShouldDehydrateQuery;
	const shouldRedactErrors = options.shouldRedactErrors ?? client.getDefaultOptions().dehydrate?.shouldRedactErrors;
	const serializeData = options.serializeData ?? client.getDefaultOptions().dehydrate?.serializeData;
	return {
		mutations,
		queries: client.getQueryCache().getAll().flatMap((query) => filterQuery(query) ? [dehydrateQuery(query, serializeData, shouldRedactErrors)] : [])
	};
}
/**
* Restores a `DehydratedState` (as produced by `dehydrate`) into a `QueryClient`'s cache, typically to seed the
* client with data already fetched on the server. `mutations` and `queries` are each optional on `dehydratedState`.
* Queries not yet in the cache are built from the dehydrated snapshot; queries that already exist are only updated
* when the dehydrated data is newer than what's already cached. Newly built queries have their `fetchStatus` reset
* to `'idle'` so they don't hydrate stuck in a fetching state. If a dehydrated query still had an in-flight
* promise, it is resumed via `query.fetch()` (reusing that promise as `initialPromise`) rather than re-invoking
* `queryFn`.
* @param client - The client whose cache is restored into.
* @param dehydratedState - The dehydrated state, e.g. produced by `dehydrate` on the server.
* @param options - `defaultOptions` merged into every restored query and mutation (on top of the
* client's `defaultOptions.hydrate`), and `deserializeData` to reverse `serializeData`.
* @example
* ```ts
* // dehydratedState was produced by `dehydrate` on the server
* // and sent to the client, e.g. embedded in server-rendered markup.
* const queryClient = new QueryClient()
*
* hydrate(queryClient, dehydratedState)
* ```
*/
function hydrate(client, dehydratedState, options) {
	const mutationCache = client.getMutationCache();
	const queryCache = client.getQueryCache();
	const deserializeData = options?.defaultOptions?.deserializeData ?? client.getDefaultOptions().hydrate?.deserializeData;
	dehydratedState.mutations?.forEach(({ state, ...mutationOptions }) => {
		mutationCache.build(client, {
			...client.getDefaultOptions().hydrate?.mutations,
			...options?.defaultOptions?.mutations,
			...mutationOptions
		}, state);
	});
	dehydratedState.queries?.forEach(({ queryKey, state, queryHash, meta, promise, dehydratedAt, queryType }) => {
		const syncData = promise ? tryResolveSync(promise) : void 0;
		const rawData = state.data === void 0 ? syncData?.data : state.data;
		const data = rawData === void 0 ? rawData : deserializeData ? deserializeData(rawData) : rawData;
		let query = queryCache.get(queryHash);
		const existingQueryIsPending = query?.state.status === "pending";
		const existingQueryIsFetching = query?.state.fetchStatus === "fetching";
		if (query) {
			const hasNewerSyncData = syncData && dehydratedAt > query.state.dataUpdatedAt;
			if (state.dataUpdatedAt > query.state.dataUpdatedAt || hasNewerSyncData) {
				const { fetchStatus: _ignored, ...serializedState } = state;
				query.setState({
					...serializedState,
					data,
					...state.status === "pending" && data !== void 0 && {
						status: "success",
						dataUpdatedAt: dehydratedAt,
						...!existingQueryIsFetching && { fetchStatus: "idle" }
					}
				});
			}
		} else query = queryCache.build(client, {
			...client.getDefaultOptions().hydrate?.queries,
			...options?.defaultOptions?.queries,
			queryKey,
			queryHash,
			meta,
			_type: queryType
		}, {
			...state,
			data,
			fetchStatus: "idle",
			status: state.status === "pending" && data !== void 0 ? "success" : state.status,
			...state.status === "pending" && data !== void 0 && { dataUpdatedAt: dehydratedAt }
		});
		if (promise && !syncData && !existingQueryIsPending && !existingQueryIsFetching && dehydratedAt > query.state.dataUpdatedAt) query.fetch(void 0, { initialPromise: Promise.resolve(promise).then(deserializeData) }).catch(noop);
	});
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/notifyManager.js
/**
* Default scheduling function used by the notify manager.
* Schedules the callback with the system's `setTimeout(callback, 0)`.
*/
var defaultScheduler = systemSetTimeoutZero;
/**
* Creates a notify manager, which schedules and batches notifications to subscribers. Query uses a
* single instance of it, exported as {@link notifyManager}.
* @returns A new notify manager.
*/
function createNotifyManager() {
	let queue = [];
	let transactions = 0;
	let notifyFn = (callback) => {
		callback();
	};
	let batchNotifyFn = (callback) => {
		callback();
	};
	let scheduleFn = defaultScheduler;
	const schedule = (callback) => {
		if (transactions) queue.push(callback);
		else scheduleFn(() => {
			notifyFn(callback);
		});
	};
	const flush = () => {
		const originalQueue = queue;
		queue = [];
		if (originalQueue.length) scheduleFn(() => {
			batchNotifyFn(() => {
				originalQueue.forEach((callback) => {
					notifyFn(callback);
				});
			});
		});
	};
	return {
		/**
		* Batches all updates scheduled inside the passed callback.
		* This is mainly used internally to optimize query client updating.
		* Batches can be nested; the queue is only flushed once the outermost `batch` call finishes.
		* The return value of `callback` is passed through.
		* @param callback - The function to run in the batch.
		* @returns The return value of `callback`.
		*/
		batch: (callback) => {
			let result;
			transactions++;
			try {
				result = callback();
			} finally {
				transactions--;
				if (!transactions) flush();
			}
			return result;
		},
		/**
		* All calls to the wrapped function will be batched.
		* @param callback - The function to wrap.
		* @returns A function that schedules a call to `callback` with the given arguments.
		*/
		batchCalls: (callback) => {
			return (...args) => {
				schedule(() => {
					callback(...args);
				});
			};
		},
		/**
		* Schedules a function to be run on the next batch.
		* By default, the batch is run with a `setTimeout`, but this can be configured via `setScheduler`.
		*/
		schedule,
		/**
		* Use this method to set a custom notify function.
		* This can be used to for example wrap notifications with `React.act` while running tests.
		* @param fn - Receives each notification callback and must call it.
		*/
		setNotifyFunction: (fn) => {
			notifyFn = fn;
		},
		/**
		* Use this method to set a custom function to batch notifications together into a single tick.
		* Framework adapters use this to plug in their own batching primitive, so that a single query
		* update only triggers one re-render instead of one per subscriber.
		* @param fn - Receives a function that runs a batch of notifications and must call it.
		* @example
		* ```ts
		* import { notifyManager } from '@tanstack/query-core'
		* import { batch } from 'solid-js'
		*
		* notifyManager.setBatchNotifyFunction(batch)
		* ```
		*/
		setBatchNotifyFunction: (fn) => {
			batchNotifyFn = fn;
		},
		/**
		* Configures a custom callback that schedules when the next batch runs.
		* The default behavior is `setTimeout(callback, 0)`.
		* @param fn - Receives a callback that runs the next batch, and schedules it.
		* @example
		* ```ts
		* import { notifyManager } from '@tanstack/query-core'
		*
		* // Schedule batches in the next microtask
		* notifyManager.setScheduler(queueMicrotask)
		*
		* // Schedule batches before the next frame is rendered
		* notifyManager.setScheduler(requestAnimationFrame)
		*
		* // Schedule batches some time in the future
		* notifyManager.setScheduler((cb) => setTimeout(cb, 10))
		* ```
		*/
		setScheduler: (fn) => {
			scheduleFn = fn;
		}
	};
}
/**
* Handles scheduling and batching callbacks in TanStack Query.
*/
var notifyManager = createNotifyManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/onlineManager.js
/**
* The `OnlineManager` manages the online state within TanStack Query. It can
* be used to change the default event listeners or to manually change the
* online state.
*
* By default, the `onlineManager` assumes an active network connection, and
* listens to the `online` and `offline` events on the `window` object to
* detect changes.
*/
var OnlineManager = class extends Subscribable {
	#online = true;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onOnline) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const onlineListener = () => onOnline(true);
				const offlineListener = () => onOnline(false);
				window.addEventListener("online", onlineListener, false);
				window.addEventListener("offline", offlineListener, false);
				return () => {
					window.removeEventListener("online", onlineListener);
					window.removeEventListener("offline", offlineListener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	/**
	* `setEventListener` can be used to set a custom event listener that will
	* be used to determine the online state. The provided `setup` function
	* receives a `setOnline` callback that should be called with a `boolean`
	* whenever the online state changes.
	* @param setup - Receives the `setOnline` callback, registers the event listener, and may return
	* a cleanup function that is called when the listener is replaced or no longer needed.
	* @example
	* ```ts
	* import NetInfo from '@react-native-community/netinfo'
	* import { onlineManager } from '@tanstack/query-core'
	*
	* onlineManager.setEventListener((setOnline) => {
	*   return NetInfo.addEventListener((state) => {
	*     setOnline(!!state.isConnected)
	*   })
	* })
	* ```
	*/
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup(this.setOnline.bind(this));
	}
	/**
	* `setOnline` can be used to manually set the online state.
	* @param online - The online state.
	* @example
	* ```ts
	* import { onlineManager } from '@tanstack/query-core'
	*
	* // Set to online
	* onlineManager.setOnline(true)
	*
	* // Set to offline
	* onlineManager.setOnline(false)
	* ```
	*/
	setOnline(online) {
		if (this.#online !== online) {
			this.#online = online;
			this.listeners.forEach((listener) => {
				listener(online);
			});
		}
	}
	/**
	* `isOnline` can be used to get the current online state.
	* @returns `true` if online.
	*/
	isOnline() {
		return this.#online;
	}
};
/**
* Singleton instance of {@link OnlineManager}, used to manage and observe the online state within TanStack Query.
*/
var onlineManager = new OnlineManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/retryer.js
/**
* The default `retryDelay`: doubles with every failure, starting at 1 second, up to 30 seconds.
* @param failureCount - The number of failures so far.
* @returns The delay before the next retry, in milliseconds.
*/
function defaultRetryDelay(failureCount) {
	return Math.min(1e3 * 2 ** failureCount, 3e4);
}
/**
* Checks whether a fetch can run for the given network mode.
* @param networkMode - The `networkMode` option. Defaults to `'online'`.
* @returns `true` if the network mode is not `'online'`, or if it is and the client is online.
*/
function canFetch(networkMode) {
	return (networkMode ?? "online") === "online" ? onlineManager.isOnline() : true;
}
/**
* The error thrown by a `Retryer` (and surfaced to `query.promise`/`mutation`) when a fetch is cancelled, e.g. via
* `query.cancel()`. `revert`, if `true`, tells the caller to restore the state the query was in before the fetch
* started instead of surfacing the error. `silent`, if `true`, tells the caller to suppress this error and instead
* resolve with the promise of the fetch that triggered the cancellation.
* @example
* ```ts
* query.cancel()
*
* try {
*   await query.promise
* } catch (error) {
*   if (error instanceof CancelledError) {
*     // the fetch was cancelled, e.g. via `query.cancel()`
*   }
* }
* ```
*/
var CancelledError = class extends Error {
	constructor(options) {
		super("CancelledError");
		this.revert = options?.revert;
		this.silent = options?.silent;
	}
};
/**
* Checks whether a value is a `CancelledError`.
* @param value - The value to check.
* @returns `true` if `value` is a `CancelledError`.
* @deprecated Use instanceof `CancelledError` instead.
*/
function isCancelledError(value) {
	return value instanceof CancelledError;
}
/**
* Creates a retryer, which runs a function and retries it on failure according to the `retry` and
* `retryDelay` options. It pauses while the network mode doesn't allow fetching or `canRun` returns
* `false`, and can be cancelled. Queries and mutations use it to run their `queryFn` and
* `mutationFn`.
* @param config - The function to run, the retry options, and the callbacks for failures, pausing,
* continuing, and cancellation.
* @returns The retryer, whose `promise` settles with the result of the function.
*/
function createRetryer(config) {
	let isRetryCancelled = false;
	let failureCount = 0;
	let continueFn;
	let status = "pending";
	let promiseResolve;
	let promiseReject;
	const promise = new Promise((resolve, reject) => {
		promiseResolve = resolve;
		promiseReject = reject;
	});
	promise.catch(noop);
	const isResolved = () => status !== "pending";
	const cancel = (cancelOptions) => {
		if (!isResolved()) {
			const error = new CancelledError(cancelOptions);
			reject(error);
			config.onCancel?.(error);
		}
	};
	const cancelRetry = () => {
		isRetryCancelled = true;
	};
	const continueRetry = () => {
		isRetryCancelled = false;
	};
	const canContinue = () => focusManager.isFocused() && (config.networkMode === "always" || onlineManager.isOnline()) && config.canRun();
	const canStart = () => canFetch(config.networkMode) && config.canRun();
	const resolve = (value) => {
		if (!isResolved()) {
			continueFn?.();
			status = "resolved";
			promiseResolve(value);
		}
	};
	const reject = (value) => {
		if (!isResolved()) {
			continueFn?.();
			status = "rejected";
			promiseReject(value);
		}
	};
	const pause = (canResume) => {
		return new Promise((continueResolve) => {
			continueFn = (value) => {
				if (isResolved() || canResume()) continueResolve(value);
			};
			config.onPause?.();
		}).then(() => {
			continueFn = void 0;
			if (!isResolved()) config.onContinue?.();
		});
	};
	const run = () => {
		if (isResolved()) return;
		let promiseOrValue;
		const initialPromise = failureCount === 0 ? config.initialPromise : void 0;
		try {
			promiseOrValue = initialPromise ?? config.fn();
		} catch (error) {
			promiseOrValue = Promise.reject(error);
		}
		Promise.resolve(promiseOrValue).then(resolve).catch((error) => {
			if (isResolved()) return;
			const retry = config.retry ?? (isServer$2() ? 0 : 3);
			const retryDelay = config.retryDelay ?? defaultRetryDelay;
			const delay = typeof retryDelay === "function" ? retryDelay(failureCount, error) : retryDelay;
			const shouldRetry = retry === true || typeof retry === "number" && failureCount < retry || typeof retry === "function" && retry(failureCount, error);
			if (isRetryCancelled || !shouldRetry) {
				reject(error);
				return;
			}
			failureCount++;
			config.onFail?.(failureCount, error);
			sleep(delay).then(() => {
				return canContinue() ? void 0 : pause(canContinue);
			}).then(() => {
				if (isRetryCancelled) reject(error);
				else run();
			});
		});
	};
	return {
		promise,
		status: () => status,
		cancel,
		continue: () => {
			continueFn?.();
			return promise;
		},
		cancelRetry,
		continueRetry,
		canStart,
		start: () => {
			if (canStart()) run();
			else pause(canStart).then(run);
			return promise;
		}
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/removable.js
/**
* The base class for cache entries that are garbage collected once nothing is using them —
* `Query` and `Mutation` both extend it. `gcTime` controls how long an unused entry is kept.
*/
var Removable = class {
	#gcTimeout;
	/**
	* Clears the pending garbage collection timeout, so the entry is no longer scheduled for removal.
	* A subclass may override this to release what it holds on to as well — `Query` also cancels any
	* in-flight fetch.
	*/
	destroy() {
		this.clearGcTimeout();
	}
	/**
	* Schedules the entry to be removed from its cache after `gcTime`, replacing any timeout scheduled
	* before. Nothing is scheduled if `gcTime` is `Infinity`.
	*/
	scheduleGc() {
		this.clearGcTimeout();
		if (isValidTimeout(this.gcTime)) this.#gcTimeout = timeoutManager.setTimeout(() => {
			this.optionalRemove();
		}, this.gcTime);
	}
	/**
	* Updates `gcTime`, keeping the longest one seen so far. Without a value, it defaults to 5 minutes
	* on the client and `Infinity` on the server.
	* @param newGcTime - The `gcTime` from the latest options, if any.
	*/
	updateGcTime(newGcTime) {
		this.gcTime = Math.max(this.gcTime || 0, newGcTime ?? (isServer$2() ? Infinity : 3e5));
	}
	/**
	* Cancels the scheduled removal, if there is one.
	*/
	clearGcTimeout() {
		if (this.#gcTimeout !== void 0) {
			timeoutManager.clearTimeout(this.#gcTimeout);
			this.#gcTimeout = void 0;
		}
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js
/**
* Creates the behavior that fetches the pages of an infinite query: the next or previous page for
* `fetchNextPage`/`fetchPreviousPage`, or all pages again from the start on a refetch.
* @param pages - The number of pages to fetch from the start when all pages are fetched again,
* e.g. from the `pages` option of `queryClient.infiniteQuery`. Defaults to the number of cached
* pages.
* @returns The query behavior to set on an infinite query.
*/
function infiniteQueryBehavior(pages) {
	return { onFetch: (context, query) => {
		const options = context.options;
		const direction = context.fetchOptions?.meta?.fetchMore?.direction;
		const oldPages = context.state.data?.pages || [];
		const oldPageParams = context.state.data?.pageParams || [];
		let result = {
			pages: [],
			pageParams: []
		};
		let currentPage = 0;
		const fetchFn = async () => {
			let cancelled = false;
			const addSignalProperty = (object) => {
				addConsumeAwareSignal(object, () => context.signal, () => cancelled = true);
			};
			const queryFn = ensureQueryFn(context.options, context.fetchOptions);
			const fetchPage = async (data, param, previous) => {
				if (cancelled) return Promise.reject(context.signal.reason);
				if (param == null && data.pages.length) return Promise.resolve(data);
				const createQueryFnContext = () => {
					const queryFnContext = {
						client: context.client,
						queryKey: context.queryKey,
						pageParam: param,
						direction: previous ? "backward" : "forward",
						meta: context.options.meta
					};
					addSignalProperty(queryFnContext);
					return queryFnContext;
				};
				const queryFnContext = createQueryFnContext();
				const page = await queryFn(queryFnContext);
				const { maxPages } = context.options;
				const addTo = previous ? addToStart : addToEnd;
				return {
					pages: addTo(data.pages, page, maxPages),
					pageParams: addTo(data.pageParams, param, maxPages)
				};
			};
			if (direction && oldPages.length) {
				const previous = direction === "backward";
				const pageParamFn = previous ? getPreviousPageParam : getNextPageParam;
				const oldData = {
					pages: oldPages,
					pageParams: oldPageParams
				};
				result = await fetchPage(oldData, pageParamFn(options, oldData), previous);
			} else {
				const remainingPages = pages ?? oldPages.length;
				do {
					const param = currentPage === 0 ? oldPageParams[0] === void 0 ? options.initialPageParam : oldPageParams[0] : getNextPageParam(options, result);
					if (currentPage > 0 && param == null) break;
					result = await fetchPage(result, param);
					currentPage++;
				} while (currentPage < remainingPages);
			}
			return result;
		};
		if (context.options.persister) context.fetchFn = () => {
			return context.options.persister?.(fetchFn, {
				client: context.client,
				queryKey: context.queryKey,
				meta: context.options.meta,
				signal: context.signal
			}, query);
		};
		else context.fetchFn = fetchFn;
	} };
}
/**
* Computes the page param of the page after the last one, with the `getNextPageParam` option.
* @param options - The infinite query options.
* @param data - The current pages and page params.
* @returns The next page param, or `undefined` if there are no pages yet.
*/
function getNextPageParam(options, { pages, pageParams }) {
	const lastIndex = pages.length - 1;
	return pages.length > 0 ? options.getNextPageParam(pages[lastIndex], pages, pageParams[lastIndex], pageParams) : void 0;
}
/**
* Computes the page param of the page before the first one, with the `getPreviousPageParam`
* option.
* @param options - The infinite query options.
* @param data - The current pages and page params.
* @returns The previous page param, or `undefined` if there are no pages yet or no
* `getPreviousPageParam` option.
*/
function getPreviousPageParam(options, { pages, pageParams }) {
	return pages.length > 0 ? options.getPreviousPageParam?.(pages[0], pages, pageParams[0], pageParams) : void 0;
}
/**
* Checks if there is a next page.
* @param options - The infinite query options with `getNextPageParam`.
* @param data - The current pages and page params.
* @returns `true` if `getNextPageParam` returns a value other than `null` or `undefined`.
*/
function hasNextPage(options, data) {
	if (!data) return false;
	return getNextPageParam(options, data) != null;
}
/**
* Checks if there is a previous page.
* @param options - The infinite query options with `getPreviousPageParam`.
* @param data - The current pages and page params.
* @returns `true` if `getPreviousPageParam` is set and returns a value other than `null` or
* `undefined`.
*/
function hasPreviousPage(options, data) {
	if (!data || !options.getPreviousPageParam) return false;
	return getPreviousPageParam(options, data) != null;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/query.js
/**
* Represents a single cached query. A `Query` holds the query's key, options,
* state (data/error/status), and the observers currently subscribed to it.
*
* Instances are created and managed internally by `QueryCache`; application
* code typically interacts with queries indirectly through `QueryClient` or
* a framework hook like `useQuery`. Direct access to a `Query` instance is
* possible via `queryCache.find()`/`findAll()` for inspecting cache state.
* @example
* ```ts
* const queryCache = queryClient.getQueryCache()
* const query = queryCache.find({ queryKey: ['posts'] })
*
* if (query) {
*   console.log(query.state.dataUpdatedAt)
* }
* ```
*/
var Query = class extends Removable {
	#queryType;
	#initialState;
	#revertState;
	#cache;
	#client;
	#retryer;
	#defaultOptions;
	#abortSignalConsumed;
	constructor(config) {
		super();
		this.#abortSignalConsumed = false;
		this.#defaultOptions = config.defaultOptions;
		this.setOptions(config.options);
		this.observers = [];
		this.#client = config.client;
		this.#cache = this.#client.getQueryCache();
		this.queryKey = config.queryKey;
		this.queryHash = config.queryHash;
		this.#initialState = getDefaultState$1(this.options);
		this.state = config.state ?? this.#initialState;
		this.scheduleGc();
	}
	/**
	* The `meta` object passed in the query's options, if any.
	* @returns The query's `meta`, or `undefined` if none was set.
	*/
	get meta() {
		return this.options.meta;
	}
	/**
	* `'infinite'` for an infinite query, otherwise `undefined`.
	* @internal
	* @returns The type of the query, set from the `_type` option (e.g. `'infinite'`).
	*/
	get queryType() {
		return this.#queryType;
	}
	/**
	* The promise for the currently in-flight fetch, if the query is fetching.
	* `undefined` when the query is not fetching.
	* @returns The promise of the in-flight fetch, or `undefined`.
	*/
	get promise() {
		return this.#retryer?.promise;
	}
	/**
	* Replaces the query's options and applies their `gcTime`. If the query has no data yet, it gets
	* the `initialData` from the new options, if any.
	* @internal
	* @param options - The new query options, merged on top of the query's default options.
	*/
	setOptions(options) {
		this.options = {
			...this.#defaultOptions,
			...options
		};
		if (options?._type) this.#queryType = options._type;
		this.updateGcTime(this.options.gcTime);
		if (this.state && this.state.data === void 0) {
			const defaultState = getDefaultState$1(this.options);
			if (defaultState.data !== void 0) {
				this.setState(successState(defaultState.data, defaultState.dataUpdatedAt));
				this.#initialState = defaultState;
			}
		}
	}
	optionalRemove() {
		if (!this.observers.length && this.state.fetchStatus === "idle") this.#cache.remove(this);
	}
	/**
	* Writes new data to the query and marks it as successfully fetched.
	* @internal
	* @param newData - The data to write. Structural sharing with the current data is applied.
	* @param options - Set `updatedAt` to override the timestamp, and `manual` to mark the write as
	* manual (e.g. from `queryClient.setQueryData`).
	* @returns The data that was written.
	*/
	setData(newData, options) {
		const data = replaceData(this.state.data, newData, this.options);
		this.#dispatch({
			data,
			type: "success",
			dataUpdatedAt: options?.updatedAt,
			manual: options?.manual
		});
		return data;
	}
	/**
	* Merges the given partial state directly into this query's state, notifying observers. Used
	* by persistence and broadcast plugins to restore a state snapshot, and by devtools to let a
	* user manually trigger a loading/error state or edit the cached data.
	* @param state - The partial state to merge into the query's state.
	*/
	setState(state) {
		this.#dispatch({
			type: "setState",
			state
		});
	}
	/**
	* Cancels the query's currently in-flight fetch, if any.
	* - Returns a promise that resolves once the cancellation has settled.
	* - If no fetch is in progress, resolves immediately.
	* @param options - Set `revert` to restore the state from before the fetch started, and `silent`
	* to suppress the cancellation error when a new fetch replaces the cancelled one.
	* @returns A promise that resolves once the cancellation has settled.
	* @example
	* ```ts
	* await query.cancel()
	* ```
	*/
	cancel(options) {
		const promise = this.#retryer?.promise;
		this.#retryer?.cancel(options);
		return promise ? promise.then(noop).catch(noop) : Promise.resolve();
	}
	/**
	* Clears the query's garbage collection timeout and silently cancels any
	* in-flight fetch. Called by `QueryCache` when the query is removed from
	* the cache.
	* @see {@link Query#cancel}
	*/
	destroy() {
		super.destroy();
		this.cancel({ silent: true });
	}
	/**
	* The state the query was created with.
	* @internal
	* @returns The state the query had when it was first created, used by {@link Query#reset}.
	*/
	get resetState() {
		return this.#initialState;
	}
	/**
	* Resets the query back to its initial state (the state it had when it was
	* first created, e.g. any `initialData`), destroying it first to cancel any
	* in-flight fetch.
	*/
	reset() {
		this.destroy();
		this.setState(this.resetState);
	}
	/**
	* Returns `true` if the query has at least one observer for which `enabled`
	* does not resolve to `false`.
	* @returns `true` if the query has an enabled observer.
	*/
	isActive() {
		return this.observers.some((observer) => resolveQueryValue(observer.options.enabled, this) !== false);
	}
	/**
	* Returns `true` if the query is disabled, meaning it will not fetch
	* automatically.
	* - If the query has observers, it is disabled when none of them are active
	*   (see `isActive`).
	* - If the query has no observers, it is disabled when its `queryFn` is
	*   `skipToken` or it has never been fetched.
	* @returns `true` if the query is disabled.
	*/
	isDisabled() {
		if (this.getObserversCount() > 0) return !this.isActive();
		return this.options.queryFn === skipToken || !this.isFetched();
	}
	/**
	* Returns `true` if the query has been fetched, i.e. it has resolved with
	* either data or an error at least once.
	* @returns `true` if the query has been fetched.
	*/
	isFetched() {
		return this.state.dataUpdateCount + this.state.errorUpdateCount > 0;
	}
	/**
	* Returns `true` if the query has at least one observer configured with
	* `staleTime: 'static'`, meaning it is treated as never stale.
	* @returns `true` if the query is static.
	*/
	isStatic() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => resolveQueryValue(observer.options.staleTime, this) === "static");
		return false;
	}
	/**
	* Returns `true` if the query is stale.
	* - If the query has observers, defers to whether any observer's current
	*   result reports `isStale` (which accounts for each observer's own
	*   `staleTime` and `enabled` state).
	* - If the query has no observers, it is considered stale when it has no
	*   data or has been invalidated.
	* @returns `true` if the query is stale.
	* @see {@link Query#isStaleByTime}
	* @example
	* ```ts
	* if (query.isStale()) {
	*   // refetch or otherwise treat the cached data as outdated
	* }
	* ```
	*/
	isStale() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => observer.getCurrentResult().isStale);
		return this.state.data === void 0 || this.state.isInvalidated;
	}
	/**
	* Returns `true` if the query's data is stale relative to the given
	* `staleTime` (defaults to `0`).
	* - A query with no data is always stale.
	* - `staleTime: 'static'` is never stale.
	* - An invalidated query is always stale.
	* - Otherwise, staleness is based on elapsed time since `dataUpdatedAt`.
	* @param staleTime - The time, in milliseconds, after which data is considered stale, or
	* `'static'` to never treat existing data as stale. A query without data is stale either way.
	* @returns `true` if the query's data is stale.
	* @see {@link Query#isStale}
	* @example
	* ```ts
	* const isStale = query.isStaleByTime(1000 * 60)
	* ```
	*/
	isStaleByTime(staleTime = 0) {
		if (this.state.data === void 0) return true;
		if (staleTime === "static") return false;
		if (this.state.isInvalidated) return true;
		return !timeUntilStale(this.state.dataUpdatedAt, staleTime);
	}
	/**
	* Refetches the query when the window regains focus, if an observer wants that, and continues a
	* paused fetch.
	* @internal
	*/
	onFocus() {
		this.observers.find((x) => x.shouldFetchOnWindowFocus())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	/**
	* Refetches the query when the app reconnects, if an observer wants that, and continues a paused
	* fetch.
	* @internal
	*/
	onOnline() {
		this.observers.find((x) => x.shouldFetchOnReconnect())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	/**
	* Subscribes an observer to the query and stops its garbage collection.
	* @internal
	* @param observer - The observer to add. Adding an observer that is already subscribed does
	* nothing.
	*/
	addObserver(observer) {
		if (!this.observers.includes(observer)) {
			this.observers.push(observer);
			this.clearGcTimeout();
			this.#cache.notify({
				type: "observerAdded",
				query: this,
				observer
			});
		}
	}
	/**
	* Unsubscribes an observer from the query.
	* @internal
	* @param observer - The observer to remove. When the last observer is removed, the in-flight
	* fetch is cancelled if its abort signal was consumed (otherwise only its retries are stopped),
	* and garbage collection is scheduled.
	*/
	removeObserver(observer) {
		const index = this.observers.indexOf(observer);
		if (index !== -1) {
			this.observers.splice(index, 1);
			if (!this.observers.length) {
				if (this.#retryer) {
					if (this.#abortSignalConsumed || this.state.fetchStatus === "paused" && this.state.status === "pending") this.#retryer.cancel({ revert: true });
					else this.#retryer.cancelRetry();
				}
				this.scheduleGc();
			}
			this.#cache.notify({
				type: "observerRemoved",
				query: this,
				observer
			});
		}
	}
	/**
	* Returns the number of observers currently subscribed to this query.
	* @returns The number of observers.
	* @example
	* ```ts
	* if (query.getObserversCount() === 0) {
	*   // no component is currently watching this query
	* }
	* ```
	*/
	getObserversCount() {
		return this.observers.length;
	}
	/**
	* Marks the query as invalidated, unless it is already invalidated. This
	* updates `state.isInvalidated` and notifies observers, but does not by
	* itself trigger a refetch.
	* @example
	* ```ts
	* query.invalidate()
	* ```
	*/
	invalidate() {
		if (!this.state.isInvalidated) this.#dispatch({ type: "invalidate" });
	}
	/**
	* Fetches the query, i.e. runs its `queryFn` (through any configured
	* retryer/behavior) and updates the query's state with the result.
	* - If a fetch is already in flight, returns its promise instead of
	*   starting a new one, unless `fetchOptions.cancelRefetch` is set and the
	*   query already has data, in which case the current fetch is silently
	*   cancelled first.
	* - If `options` is passed, it replaces the query's current options
	*   before fetching.
	* @param options - Query options that replace the query's current options before fetching. They
	* are not applied when an in-flight fetch is reused.
	* @param fetchOptions - Set `cancelRefetch` to cancel an in-flight fetch first (only if the query
	* already has data), and `meta` to pass extra information to the query's behavior.
	* @returns A promise that resolves with the fetched data, or rejects with the fetch error. If the
	* fetch is cancelled with `revert` while the query has data, it resolves with the restored data
	* instead.
	*/
	async fetch(options, fetchOptions) {
		if (this.state.fetchStatus !== "idle" && this.#retryer?.status() !== "rejected") {
			if (this.state.data !== void 0 && fetchOptions?.cancelRefetch) this.cancel({ silent: true });
			else if (this.#retryer) {
				this.#retryer.continueRetry();
				return this.#retryer.promise;
			}
		}
		if (options) this.setOptions(options);
		if (!this.options.queryFn) {
			const observer = this.observers.find((x) => x.options.queryFn);
			if (observer) this.setOptions(observer.options);
		}
		if (!Array.isArray(this.options.queryKey)) console.error(`As of v4, queryKey needs to be an Array. If you are using a string like 'repoData', please change it to an Array, e.g. ['repoData']`);
		const abortController = new AbortController();
		const addSignalProperty = (object) => {
			Object.defineProperty(object, "signal", {
				enumerable: true,
				get: () => {
					this.#abortSignalConsumed = true;
					return abortController.signal;
				}
			});
		};
		const fetchFn = () => {
			const queryFn = ensureQueryFn(this.options, fetchOptions);
			const createQueryFnContext = () => {
				const queryFnContext = {
					client: this.#client,
					queryKey: this.queryKey,
					meta: this.meta
				};
				addSignalProperty(queryFnContext);
				return queryFnContext;
			};
			const queryFnContext = createQueryFnContext();
			this.#abortSignalConsumed = false;
			if (this.options.persister) return this.options.persister(queryFn, queryFnContext, this);
			return queryFn(queryFnContext);
		};
		const createFetchContext = () => {
			const context = {
				fetchOptions,
				options: this.options,
				queryKey: this.queryKey,
				client: this.#client,
				state: this.state,
				fetchFn
			};
			addSignalProperty(context);
			return context;
		};
		const context = createFetchContext();
		(this.#queryType === "infinite" ? infiniteQueryBehavior(this.options.pages) : this.options.behavior)?.onFetch(context, this);
		this.#revertState = this.state;
		if (this.state.fetchStatus === "idle" || this.state.fetchMeta !== context.fetchOptions?.meta) this.#dispatch({
			type: "fetch",
			meta: context.fetchOptions?.meta
		});
		const retryer = this.#retryer = createRetryer({
			initialPromise: fetchOptions?.initialPromise,
			fn: context.fetchFn,
			onCancel: (error) => {
				if (error instanceof CancelledError && error.revert) this.setState({
					...this.#revertState,
					fetchStatus: "idle"
				});
				abortController.abort();
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue: () => {
				this.#dispatch({ type: "continue" });
			},
			retry: context.options.retry,
			retryDelay: context.options.retryDelay,
			networkMode: context.options.networkMode,
			canRun: () => true
		});
		try {
			const data = await retryer.start();
			if (data === void 0) {
				console.error(`Query data cannot be undefined. Please make sure to return a value other than undefined from your query function. Affected query key: ${this.queryHash}`);
				throw new Error(`${this.queryHash} data is undefined`);
			}
			this.setData(data);
			this.#cache.config.onSuccess?.(data, this);
			this.#cache.config.onSettled?.(data, this.state.error, this);
			return data;
		} catch (error) {
			if (error instanceof CancelledError) {
				if (error.silent) return this.#retryer.promise;
				else if (error.revert) {
					if (this.state.data === void 0) throw error;
					return this.state.data;
				}
			}
			this.#dispatch({
				type: "error",
				error
			});
			this.#cache.config.onError?.(error, this);
			this.#cache.config.onSettled?.(this.state.data, error, this);
			throw error;
		} finally {
			if (this.#retryer === retryer) this.#retryer = void 0;
			this.scheduleGc();
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					fetchFailureCount: action.failureCount,
					fetchFailureReason: action.error
				};
				case "pause": return {
					...state,
					fetchStatus: "paused"
				};
				case "continue": return {
					...state,
					fetchStatus: "fetching"
				};
				case "fetch": return {
					...state,
					...fetchState(state.data, this.options),
					fetchMeta: action.meta ?? null
				};
				case "success":
					const newState = {
						...state,
						...successState(action.data, action.dataUpdatedAt),
						dataUpdateCount: state.dataUpdateCount + 1,
						...!action.manual && {
							fetchStatus: "idle",
							fetchFailureCount: 0,
							fetchFailureReason: null
						}
					};
					this.#revertState = action.manual ? newState : void 0;
					return newState;
				case "error":
					const error = action.error;
					return {
						...state,
						error,
						errorUpdateCount: state.errorUpdateCount + 1,
						errorUpdatedAt: Date.now(),
						fetchFailureCount: state.fetchFailureCount + 1,
						fetchFailureReason: error,
						fetchStatus: "idle",
						status: "error",
						isInvalidated: true
					};
				case "invalidate": return {
					...state,
					isInvalidated: true
				};
				case "setState": return {
					...state,
					...action.state
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.observers.slice().forEach((observer) => {
				observer.onQueryUpdate();
			});
			this.#cache.notify({
				query: this,
				type: "updated",
				action
			});
		});
	}
};
/**
* Returns the state changes applied when a query starts fetching.
* @param data - The query's current data. If it is `undefined`, the query is also reset to
* `'pending'` with no error.
* @param options - The query options, whose `networkMode` decides whether the query is `'fetching'`
* or `'paused'`.
* @returns The partial query state for a starting fetch.
*/
function fetchState(data, options) {
	return {
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchStatus: canFetch(options.networkMode) ? "fetching" : "paused",
		...data === void 0 && {
			error: null,
			status: "pending"
		}
	};
}
/**
* Returns the state changes applied when a query receives data.
* @param data - The new data.
* @param dataUpdatedAt - The timestamp the data is recorded with. Defaults to the current time.
* @returns The partial query state for a successful update.
*/
function successState(data, dataUpdatedAt) {
	return {
		data,
		dataUpdatedAt: dataUpdatedAt ?? Date.now(),
		error: null,
		isInvalidated: false,
		status: "success"
	};
}
/**
* Returns the initial state of a query, based on its `initialData` and `initialDataUpdatedAt`
* options.
* @param options - The query options.
* @returns The initial query state: `'success'` if `initialData` is set, otherwise `'pending'`.
*/
function getDefaultState$1(options) {
	const data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
	const hasData = data !== void 0;
	const initialDataUpdatedAt = hasData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
	return {
		data,
		dataUpdateCount: 0,
		dataUpdatedAt: hasData ? initialDataUpdatedAt ?? Date.now() : 0,
		error: null,
		errorUpdateCount: 0,
		errorUpdatedAt: 0,
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchMeta: null,
		isInvalidated: false,
		status: hasData ? "success" : "pending",
		fetchStatus: "idle"
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryObserver.js
/**
* A `QueryObserver` watches a single query in the `QueryCache` and computes a
* `QueryObserverResult` from its state, recomputing and notifying subscribers
* whenever the underlying query (or the observer's options) changes. It is
* the primitive that framework adapters (e.g. `useQuery`) build their hooks
* on top of, but it can also be used directly to observe and switch between
* queries outside of any framework.
* @example
* ```ts
* const observer = new QueryObserver(queryClient, {
*   queryKey: ['posts'],
*   queryFn: fetchPosts,
* })
*
* const unsubscribe = observer.subscribe((result) => {
*   console.log(result.data)
* })
* ```
*/
var QueryObserver = class extends Subscribable {
	#client;
	#currentQuery = void 0;
	#currentQueryInitialState = void 0;
	#currentResult = void 0;
	#currentResultState;
	#currentResultOptions;
	#selectError;
	#selectFn;
	#selectResult;
	#lastQueryWithDefinedData;
	#staleTimeoutId;
	#refetchIntervalId;
	#currentRefetchInterval;
	#trackedProps = /* @__PURE__ */ new Set();
	constructor(client, options) {
		super();
		this.options = options;
		this.#client = client;
		this.#selectError = null;
		this.bindMethods();
		this.setOptions(options);
	}
	/**
	* Binds the methods of the result (`refetch`) to the observer, so they keep working when destructured
	* from it. Subclasses override it to bind their own result methods as well.
	*/
	bindMethods() {
		this.refetch = this.refetch.bind(this);
	}
	onSubscribe() {
		if (this.listeners.size === 1) {
			this.#currentQuery.addObserver(this);
			if (shouldFetchOnMount(this.#currentQuery, this.options)) this.#executeFetch();
			else this.updateResult();
			this.#updateTimers();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.destroy();
	}
	/**
	* Returns whether the observed query is currently stale and configured
	* (via the `refetchOnReconnect` option) to refetch when the network
	* reconnects.
	* @returns `true` if the observer should refetch the query on reconnect.
	*/
	shouldFetchOnReconnect() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnReconnect);
	}
	/**
	* Returns whether the observed query is currently stale and configured
	* (via the `refetchOnWindowFocus` option) to refetch when the window
	* regains focus.
	* @returns `true` if the observer should refetch the query on window focus.
	*/
	shouldFetchOnWindowFocus() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnWindowFocus);
	}
	/**
	* Stops observing the current query: clears all listeners, cancels the
	* stale and refetch-interval timers, and removes this observer from the
	* query it was observing.
	*/
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#clearStaleTimeout();
		this.#clearRefetchInterval();
		this.#currentQuery.removeObserver(this);
	}
	/**
	* Updates the observer's options. This will re-resolve the query being
	* observed (switching to a different query if the `queryKey` changed),
	* trigger a fetch if the new options require one and the observer has
	* subscribers, recompute the current result, and reschedule the stale and
	* refetch-interval timers as needed.
	* @param options - The new observer options. They are defaulted with {@link
	* QueryClient#defaultQueryOptions} before being applied.
	* @throws {Error} If `enabled` is neither a boolean nor a function.
	* @example
	* ```ts
	* observer.setOptions({ queryKey: ['posts', 1], queryFn: () => fetchPost(1) })
	* // later: switch to a different query, reusing the same observer
	* observer.setOptions({ queryKey: ['posts', 2], queryFn: () => fetchPost(2) })
	* ```
	*/
	setOptions(options) {
		const prevOptions = this.options;
		const prevQuery = this.#currentQuery;
		this.options = this.#client.defaultQueryOptions(options);
		if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveQueryValue(this.options.enabled, this.#currentQuery) !== "boolean") throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
		this.#updateQuery();
		this.#currentQuery.setOptions(this.options);
		if (prevOptions._defaulted && !shallowEqualObjects(this.options, prevOptions)) this.#client.getQueryCache().notify({
			type: "observerOptionsUpdated",
			query: this.#currentQuery,
			observer: this
		});
		const mounted = this.hasListeners();
		if (mounted && shouldFetchOptionally(this.#currentQuery, prevQuery, this.options, prevOptions)) this.#executeFetch();
		this.updateResult();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryValue(this.options.enabled, this.#currentQuery) !== resolveQueryValue(prevOptions.enabled, this.#currentQuery) || resolveQueryValue(this.options.staleTime, this.#currentQuery) !== resolveQueryValue(prevOptions.staleTime, this.#currentQuery))) this.#updateStaleTimeout();
		const nextRefetchInterval = this.#computeRefetchInterval();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryValue(this.options.enabled, this.#currentQuery) !== resolveQueryValue(prevOptions.enabled, this.#currentQuery) || nextRefetchInterval !== this.#currentRefetchInterval)) this.#updateRefetchInterval(nextRefetchInterval);
	}
	/**
	* Computes the result the observer would produce for the given (already-defaulted) options
	* right now, building the underlying `Query` if it doesn't exist yet, without waiting for a
	* subscription callback. Called by framework adapters on every render (e.g. `useQuery`) so the
	* returned value is available synchronously, ahead of `setOptions` triggering an actual fetch.
	* @param options - The defaulted observer options to compute the result for.
	* @returns The result for the given options.
	*/
	getOptimisticResult(options) {
		const query = this.#client.getQueryCache().build(this.#client, options);
		const result = this.createResult(query, options);
		if (!shallowEqualObjects(this.getCurrentResult(), result)) {
			this.#currentResult = result;
			this.#currentResultOptions = this.options;
			this.#currentResultState = this.#currentQuery.state;
		}
		return result;
	}
	/**
	* Returns the most recently computed `QueryObserverResult` for the
	* observed query. This is a point-in-time read; to be notified of updates
	* as they happen, subscribe to the observer instead (its inherited
	* `subscribe` method).
	* @returns The observer's latest result.
	* @example
	* ```ts
	* const result = observer.getCurrentResult()
	* console.log(result.status, result.data)
	* ```
	*/
	getCurrentResult() {
		return this.#currentResult;
	}
	/**
	* Wraps a `QueryObserverResult` in a `Proxy` that records which properties are read, via
	* {@link QueryObserver#trackProp} (and an optional `onPropTracked` callback). Used by framework
	* adapters when `notifyOnChangeProps` is not set, to implement its default "only re-render on
	* properties you actually read" behavior.
	* @param result - The result to wrap.
	* @param onPropTracked - Called with the name of each property that is read.
	* @returns A proxy of `result` that tracks property reads.
	*/
	trackResult(result, onPropTracked) {
		return new Proxy(result, { get: (target, key) => {
			this.trackProp(key);
			onPropTracked?.(key);
			return Reflect.get(target, key);
		} });
	}
	/**
	* Records that the given `QueryObserverResult` property was read, so a subsequent update only
	* notifies this observer if a tracked property actually changed. Normally called indirectly via
	* {@link QueryObserver#trackResult}'s proxy; exposed directly for adapters that track property
	* access themselves (e.g. through their own reactivity system) instead of via the proxy.
	* @param key - The name of the property that was read.
	*/
	trackProp(key) {
		this.#trackedProps.add(key);
	}
	/**
	* Returns the `Query` instance this observer is currently observing.
	* @returns The observed query.
	*/
	getCurrentQuery() {
		return this.#currentQuery;
	}
	/**
	* Refetches the observed query and returns a promise that resolves with
	* the resulting `QueryObserverResult`.
	* @param options - Set `cancelRefetch` to `false` to keep a running fetch instead of cancelling
	* it, and `throwOnError` to `true` to reject when the refetch fails.
	* @returns A promise that resolves with the result after the refetch.
	* @example
	* ```ts
	* const result = await observer.refetch({ cancelRefetch: false })
	* console.log(result.data)
	* ```
	*/
	refetch({ ...options } = {}) {
		return this.fetch({ ...options });
	}
	/**
	* Fetches a query defined by the given options without affecting this
	* observer's own tracked query or result, and returns a promise that
	* resolves with the `QueryObserverResult` for that fetch. This is useful
	* for prefetching data that another observer (e.g. a query about to be
	* navigated to) will need, ahead of time.
	* @param options - The observer options of the query to fetch.
	* @returns A promise that resolves with the result for the fetched query.
	* @example
	* ```ts
	* const result = await observer.fetchOptimistic({
	*   queryKey: ['posts', 2],
	*   queryFn: () => fetchPost(2),
	* })
	* console.log(result.data)
	* ```
	*/
	fetchOptimistic(options) {
		const defaultedOptions = this.#client.defaultQueryOptions(options);
		const query = this.#client.getQueryCache().build(this.#client, defaultedOptions);
		let unsubscribe = () => {};
		let resolveEarly;
		const cachePromise = new Promise((resolve) => {
			resolveEarly = resolve;
			unsubscribe = this.#client.getQueryCache().subscribe((event) => {
				if (event.type === "updated" && event.query.queryHash === query.queryHash && query.state.data !== void 0) {
					unsubscribe();
					resolve(this.createResult(query, defaultedOptions));
				}
			});
		});
		return Promise.race([query.fetch(defaultedOptions).then(() => {
			const result = this.createResult(query, defaultedOptions);
			resolveEarly?.(result);
			return result;
		}).finally(() => {
			unsubscribe();
		}), cachePromise]);
	}
	/**
	* Fetches the observed query and updates the result once the fetch settles. Used by `refetch` and,
	* in `InfiniteQueryObserver`, to fetch more pages.
	* @param fetchOptions - Options for this fetch. `cancelRefetch` defaults to `true`.
	* @returns A promise that resolves with the updated result.
	*/
	fetch(fetchOptions) {
		return this.#executeFetch({
			...fetchOptions,
			cancelRefetch: fetchOptions.cancelRefetch ?? true
		}).then(() => {
			this.updateResult();
			return this.#currentResult;
		});
	}
	#executeFetch(fetchOptions) {
		this.#updateQuery();
		let promise = this.#currentQuery.fetch(this.options, fetchOptions);
		if (!fetchOptions?.throwOnError) promise = promise.catch(noop);
		return promise;
	}
	#shouldScheduleTimer(timeout) {
		return !isServer$2() && resolveQueryValue(this.options.enabled, this.#currentQuery) !== false && isValidTimeout(timeout);
	}
	#updateStaleTimeout() {
		this.#clearStaleTimeout();
		const staleTime = resolveQueryValue(this.options.staleTime, this.#currentQuery);
		if (this.#currentResult.isStale || !this.#shouldScheduleTimer(staleTime)) return;
		const timeout = timeUntilStale(this.#currentResult.dataUpdatedAt, staleTime) + 1;
		this.#staleTimeoutId = timeoutManager.setTimeout(() => {
			if (!this.#currentResult.isStale) this.updateResult();
		}, timeout);
	}
	#computeRefetchInterval() {
		return resolveQueryValue(this.options.refetchInterval, this.#currentQuery) ?? false;
	}
	#updateRefetchInterval(nextInterval) {
		this.#clearRefetchInterval();
		this.#currentRefetchInterval = nextInterval;
		if (this.#currentRefetchInterval === 0 || !this.#shouldScheduleTimer(this.#currentRefetchInterval)) return;
		this.#refetchIntervalId = timeoutManager.setInterval(() => {
			if (this.options.refetchIntervalInBackground || focusManager.isFocused()) this.#executeFetch();
		}, this.#currentRefetchInterval);
	}
	#updateTimers() {
		this.#updateStaleTimeout();
		this.#updateRefetchInterval(this.#computeRefetchInterval());
	}
	#clearStaleTimeout() {
		if (this.#staleTimeoutId !== void 0) {
			timeoutManager.clearTimeout(this.#staleTimeoutId);
			this.#staleTimeoutId = void 0;
		}
	}
	#clearRefetchInterval() {
		if (this.#refetchIntervalId !== void 0) {
			timeoutManager.clearInterval(this.#refetchIntervalId);
			this.#refetchIntervalId = void 0;
		}
	}
	/**
	* Computes the result for a query and options from the query's state, applying `select`,
	* `placeholderData`, and the derived flags. Subclasses override it to add their own fields.
	* @param query - The query to compute the result for.
	* @param options - The observer options to compute the result with.
	* @returns The computed result.
	*/
	createResult(query, options) {
		const prevQuery = this.#currentQuery;
		const prevOptions = this.options;
		const prevResult = this.#currentResult;
		const prevResultState = this.#currentResultState;
		const prevResultOptions = this.#currentResultOptions;
		const queryInitialState = query !== prevQuery ? query.state : this.#currentQueryInitialState;
		const { state } = query;
		let newState = { ...state };
		let isPlaceholderData = false;
		let data;
		if (options._optimisticResults) {
			const mounted = this.hasListeners();
			const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
			const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
			if (fetchOnMount || fetchOptionally) newState = {
				...newState,
				...fetchState(state.data, query.options)
			};
			if (options._optimisticResults === "isRestoring") newState.fetchStatus = "idle";
		}
		let { error, errorUpdatedAt, status } = newState;
		data = newState.data;
		let skipSelect = false;
		if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
			let placeholderData;
			if (prevResult?.isPlaceholderData && options.placeholderData === prevResultOptions?.placeholderData) {
				placeholderData = prevResult.data;
				skipSelect = true;
			} else placeholderData = typeof options.placeholderData === "function" ? options.placeholderData(this.#lastQueryWithDefinedData?.state.data, this.#lastQueryWithDefinedData) : options.placeholderData;
			if (placeholderData !== void 0) {
				status = "success";
				data = replaceData(prevResult?.data, placeholderData, options);
				isPlaceholderData = true;
			}
		}
		if (options.select && data !== void 0 && !skipSelect) {
			if (prevResult && data === prevResultState?.data && options.select === this.#selectFn) data = this.#selectResult;
			else try {
				this.#selectFn = options.select;
				data = options.select(data);
				data = replaceData(prevResult?.data, data, options);
				this.#selectResult = data;
				this.#selectError = null;
			} catch (selectError) {
				this.#selectError = selectError;
			}
		} else if (data === void 0) this.#selectError = null;
		if (this.#selectError) {
			error = this.#selectError;
			data = this.#selectResult;
			errorUpdatedAt = Date.now();
			status = "error";
			isPlaceholderData = false;
		}
		const isFetching = newState.fetchStatus === "fetching";
		const isPending = status === "pending";
		const isError = status === "error";
		const isLoading = isPending && isFetching;
		const hasData = data !== void 0;
		return {
			status,
			fetchStatus: newState.fetchStatus,
			isPending,
			isSuccess: status === "success",
			isError,
			isInitialLoading: isLoading,
			isLoading,
			data,
			dataUpdatedAt: newState.dataUpdatedAt,
			error,
			errorUpdatedAt,
			failureCount: newState.fetchFailureCount,
			failureReason: newState.fetchFailureReason,
			errorUpdateCount: newState.errorUpdateCount,
			isFetched: query.isFetched(),
			isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
			isFetching,
			isRefetching: isFetching && !isPending,
			isLoadingError: isError && !hasData,
			isPaused: newState.fetchStatus === "paused",
			isPlaceholderData,
			isRefetchError: isError && hasData,
			isStale: isStale(query, options),
			refetch: this.refetch,
			isEnabled: resolveQueryValue(options.enabled, query) !== false
		};
	}
	/**
	* Recomputes and stores the current result from the current query/options, notifying listeners
	* if it changed. Framework adapters call this right after subscribing to make sure no query
	* update was missed in the gap between creating the observer and subscribing to it.
	*/
	updateResult() {
		const prevResult = this.#currentResult;
		const nextResult = this.createResult(this.#currentQuery, this.options);
		this.#currentResultState = this.#currentQuery.state;
		this.#currentResultOptions = this.options;
		if (this.#currentResultState.data !== void 0) this.#lastQueryWithDefinedData = this.#currentQuery;
		if (shallowEqualObjects(nextResult, prevResult)) return;
		this.#currentResult = nextResult;
		const shouldNotifyListeners = () => {
			if (!prevResult) return true;
			const { notifyOnChangeProps } = this.options;
			const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
			if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !this.#trackedProps.size) return true;
			const includedProps = new Set(notifyOnChangePropsValue ?? this.#trackedProps);
			if (this.options.throwOnError) includedProps.add("error");
			return Object.keys(this.#currentResult).some((key) => {
				const typedKey = key;
				return this.#currentResult[typedKey] !== prevResult[typedKey] && includedProps.has(typedKey);
			});
		};
		const notifyListeners = shouldNotifyListeners();
		notifyManager.batch(() => {
			if (notifyListeners) this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
			this.#client.getQueryCache().notify({
				query: this.#currentQuery,
				type: "observerResultsUpdated"
			});
		});
	}
	#updateQuery() {
		const query = this.#client.getQueryCache().build(this.#client, this.options);
		if (query === this.#currentQuery) return;
		const prevQuery = this.#currentQuery;
		this.#currentQuery = query;
		this.#currentQueryInitialState = query.state;
		if (this.hasListeners()) {
			prevQuery?.removeObserver(this);
			query.addObserver(this);
		}
	}
	/**
	* Updates the observer's result when the observed query changes, and reschedules its timers if it
	* has listeners.
	* @internal
	*/
	onQueryUpdate() {
		this.updateResult();
		if (this.hasListeners()) this.#updateTimers();
	}
};
/**
* Checks whether a query has no data yet and should do its initial load when an observer mounts.
* @param query - The query to check.
* @param options - The observer options.
* @returns `true` if the query is enabled, has no data, and isn't in an error state with
* `retryOnMount: false`.
*/
function shouldLoadOnMount(query, options) {
	return resolveQueryValue(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && resolveQueryValue(options.retryOnMount, query) === false);
}
/**
* Checks whether a query should fetch when an observer mounts: either for its initial load, or
* because it has data and `refetchOnMount` asks for a refetch.
* @param query - The query to check.
* @param options - The observer options.
* @returns `true` if the query should fetch on mount.
*/
function shouldFetchOnMount(query, options) {
	return shouldLoadOnMount(query, options) || query.state.data !== void 0 && shouldFetchOn(query, options, options.refetchOnMount);
}
/**
* Checks whether a query should fetch for a `refetchOnMount`, `refetchOnWindowFocus`, or
* `refetchOnReconnect` option.
* @param query - The query to check.
* @param options - The observer options.
* @param field - The value of the option to check.
* @returns `true` if the query is enabled, not static, and the option is `'always'`, or is not
* `false` and the query is stale.
*/
function shouldFetchOn(query, options, field) {
	if (resolveQueryValue(options.enabled, query) !== false && resolveQueryValue(options.staleTime, query) !== "static") {
		const value = resolveQueryValue(field, query);
		return value === "always" || value !== false && isStale(query, options);
	}
	return false;
}
/**
* Checks whether a query should fetch after the observer's options change.
* @param query - The query observed with the new options.
* @param prevQuery - The query observed with the previous options.
* @param options - The new observer options.
* @param prevOptions - The previous observer options.
* @returns `true` if the query changed or was disabled before, it isn't a suspense query in an
* error state, and it is stale.
*/
function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
	return (query !== prevQuery || resolveQueryValue(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale(query, options);
}
/**
* Checks whether a query is stale for the given observer options.
* @param query - The query to check.
* @param options - The observer options, whose `enabled` and `staleTime` are used.
* @returns `true` if the query is enabled and its data is stale for `staleTime`.
*/
function isStale(query, options) {
	return resolveQueryValue(options.enabled, query) !== false && query.isStaleByTime(resolveQueryValue(options.staleTime, query));
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/infiniteQueryObserver.js
/**
* An `InfiniteQueryObserver` extends `QueryObserver` to observe and switch
* between infinite queries. It augments the base `QueryObserverResult` with
* infinite-query-specific fields and methods, such as `hasNextPage` and
* `fetchNextPage`, and is the primitive that framework adapters (e.g.
* `useInfiniteQuery`) build their hooks on top of.
* @example
* ```ts
* const observer = new InfiniteQueryObserver(queryClient, {
*   queryKey: ['projects'],
*   queryFn: ({ pageParam }) => fetchProjects(pageParam),
*   initialPageParam: 0,
*   getNextPageParam: (lastPage) => lastPage.nextCursor,
* })
*
* const unsubscribe = observer.subscribe((result) => console.log(result))
* ```
*/
var InfiniteQueryObserver = class extends QueryObserver {
	constructor(client, options) {
		super(client, options);
	}
	bindMethods() {
		super.bindMethods();
		this.fetchNextPage = this.fetchNextPage.bind(this);
		this.fetchPreviousPage = this.fetchPreviousPage.bind(this);
	}
	/**
	* Updates the observer's options. Behaves the same as
	* `QueryObserver.setOptions`, additionally marking the options as
	* belonging to an infinite query before delegating to the base
	* implementation.
	* @param options - The new infinite query observer options.
	*/
	setOptions(options) {
		options._type = "infinite";
		super.setOptions(options);
	}
	/**
	* The infinite-query counterpart of {@link QueryObserver#getOptimisticResult}, marking the
	* options as an infinite query before delegating to it. Called by framework adapters (e.g.
	* `useInfiniteQuery`) ahead of subscribing, to compute the current `InfiniteQueryObserverResult`
	* synchronously.
	* @param options - The defaulted infinite query observer options to compute the result for.
	* @returns The result for the given options.
	*/
	getOptimisticResult(options) {
		options._type = "infinite";
		return super.getOptimisticResult(options);
	}
	/**
	* Fetches the next page of the infinite query and returns a promise that
	* resolves with the resulting `InfiniteQueryObserverResult`. The page
	* param used for the fetch is determined by `getNextPageParam`, which
	* receives the current pages/page params and whose result also determines
	* `hasNextPage`.
	* @param options - Set `cancelRefetch` to `false` to ignore the call while a fetch is running,
	* and `throwOnError` to `true` to reject when the fetch fails.
	* @returns A promise that resolves with the result after the next page is fetched. With
	* `cancelRefetch: false`, a running fetch is reused instead, so the next page may not be fetched.
	* @see {@link InfiniteQueryObserver#fetchPreviousPage}
	* @example
	* ```ts
	* const { hasNextPage } = observer.getCurrentResult()
	*
	* if (hasNextPage) {
	*   await observer.fetchNextPage()
	* }
	* ```
	*/
	fetchNextPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "forward" } }
		});
	}
	/**
	* Fetches the previous page of the infinite query and returns a promise
	* that resolves with the resulting `InfiniteQueryObserverResult`. The page
	* param used for the fetch is determined by `getPreviousPageParam`, which
	* receives the current pages/page params and whose result also determines
	* `hasPreviousPage`.
	* @param options - Set `cancelRefetch` to `false` to ignore the call while a fetch is running,
	* and `throwOnError` to `true` to reject when the fetch fails.
	* @returns A promise that resolves with the result after the previous page is fetched. With
	* `cancelRefetch: false`, a running fetch is reused instead, so the previous page may not be fetched.
	* @see {@link InfiniteQueryObserver#fetchNextPage}
	* @example
	* ```ts
	* const { hasPreviousPage } = observer.getCurrentResult()
	*
	* if (hasPreviousPage) {
	*   await observer.fetchPreviousPage()
	* }
	* ```
	*/
	fetchPreviousPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "backward" } }
		});
	}
	createResult(query, options) {
		const { state } = query;
		const parentResult = super.createResult(query, options);
		const { isFetching, isRefetching, isError, isRefetchError } = parentResult;
		const fetchDirection = state.fetchMeta?.fetchMore?.direction;
		const isFetchNextPageError = isError && fetchDirection === "forward";
		const isFetchingNextPage = isFetching && fetchDirection === "forward";
		const isFetchPreviousPageError = isError && fetchDirection === "backward";
		const isFetchingPreviousPage = isFetching && fetchDirection === "backward";
		return {
			...parentResult,
			fetchNextPage: this.fetchNextPage,
			fetchPreviousPage: this.fetchPreviousPage,
			hasNextPage: hasNextPage(options, state.data),
			hasPreviousPage: hasPreviousPage(options, state.data),
			isFetchNextPageError,
			isFetchingNextPage,
			isFetchPreviousPageError,
			isFetchingPreviousPage,
			isRefetchError: isRefetchError && !isFetchNextPageError && !isFetchPreviousPageError,
			isRefetching: isRefetching && !isFetchingNextPage && !isFetchingPreviousPage
		};
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutation.js
/**
* Represents a single mutation attempt. A `Mutation` holds the mutation's
* options, state (data/error/status), and the `MutationObserver`s currently
* subscribed to it.
*
* Instances are created and managed internally by `MutationCache`; application
* code typically interacts with mutations indirectly through `QueryClient` or
* a framework hook like `useMutation`. Direct access to a `Mutation` instance
* is possible via `mutationCache.find()`/`getAll()` for inspecting cache state.
* @example
* ```ts
* const mutationCache = queryClient.getMutationCache()
*
* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
* ```
*/
var Mutation = class extends Removable {
	#client;
	#observers;
	#mutationCache;
	#retryer;
	constructor(config) {
		super();
		this.#client = config.client;
		this.mutationId = config.mutationId;
		this.#mutationCache = config.mutationCache;
		this.#observers = [];
		this.state = config.state || getDefaultState();
		this.setOptions(config.options);
		this.scheduleGc();
	}
	/**
	* Replaces the mutation's options and applies their `gcTime`.
	* @internal
	* @param options - The new mutation options.
	*/
	setOptions(options) {
		this.options = options;
		this.updateGcTime(this.options.gcTime);
	}
	/**
	* The `meta` object passed in the mutation's options, if any.
	* @returns The mutation's `meta`, or `undefined` if none was set.
	*/
	get meta() {
		return this.options.meta;
	}
	/**
	* Subscribes an observer to the mutation and stops its garbage collection.
	* @internal
	* @param observer - The observer to add. Adding an observer that is already subscribed does
	* nothing.
	*/
	addObserver(observer) {
		if (!this.#observers.includes(observer)) {
			this.#observers.push(observer);
			this.clearGcTimeout();
			this.#mutationCache.notify({
				type: "observerAdded",
				mutation: this,
				observer
			});
		}
	}
	/**
	* Unsubscribes an observer from the mutation.
	* @internal
	* @param observer - The observer to remove. Garbage collection is scheduled afterwards.
	*/
	removeObserver(observer) {
		this.#observers = this.#observers.filter((x) => x !== observer);
		this.scheduleGc();
		this.#mutationCache.notify({
			type: "observerRemoved",
			mutation: this,
			observer
		});
	}
	optionalRemove() {
		if (!this.#observers.length) {
			if (this.state.status === "pending") this.scheduleGc();
			else this.#mutationCache.remove(this);
		}
	}
	/**
	* Resumes a mutation that is currently paused or was restored from a
	* dehydrated, still-`pending` state.
	*
	* - If this mutation has an active retryer (it paused mid-attempt, e.g. due
	*   to the network mode or scope-based queuing), its retryer is resumed.
	* - Otherwise, if the mutation's status is still `pending` (e.g. it was
	*   dehydrated while an attempt was in flight and never got a retryer in
	*   this instance), `execute` is called again with the last known variables.
	* - Otherwise the mutation has already settled and this resolves immediately
	*   without running anything again.
	* @returns A promise that settles with the resumed mutation: it rejects if the mutation fails.
	* It resolves immediately if the mutation has already settled.
	* @see {@link Mutation#execute}
	* @example
	* ```ts
	* // typically driven by reconnect handling, e.g. queryClient.resumePausedMutations()
	* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
	* await mutation?.continue()
	* ```
	*/
	continue() {
		return this.#retryer?.continue() ?? (this.state.status === "pending" ? this.execute(this.state.variables) : Promise.resolve());
	}
	/**
	* Runs the mutation function for the given variables through a retryer, and
	* drives the mutation's state and lifecycle callbacks through to settlement.
	*
	* If this mutation's state is already `pending` when `execute` is called
	* (i.e. it was restored, still in-flight, from a dehydrated state), the
	* `onMutate` step is skipped and a `continue` action is dispatched to
	* unpause it; otherwise a `pending` action is dispatched first, then the
	* mutation cache's `onMutate` and the mutation's own `onMutate` option are
	* awaited in that order, and the resulting context is stored.
	*
	* The mutation function is then run (subject to `retry`/`retryDelay`/
	* `networkMode`, and to the mutation cache's scope-based serialization).
	* On success, the cache's `onSuccess`/`onSettled` callbacks run before the
	* mutation's own `onSuccess`/`onSettled` options, a `success` action is
	* dispatched, and the resolved data is returned. On failure, the same
	* cache-then-option ordering is used for `onError`/`onSettled`, but each of
	* those four callbacks is individually caught so that a throwing callback
	* cannot mask the original error; an `error` action is then dispatched and
	* the original error is re-thrown.
	* @param variables - The variables passed to the `mutationFn`.
	* @returns A promise that resolves with the mutation's data, or rejects with its error.
	* @see {@link Mutation#continue}
	* @example
	* ```ts
	* // Called internally by `MutationObserver.mutate` and `Mutation.continue` —
	* // applications normally trigger mutations through those, not this method.
	* const data = await mutation.execute(variables)
	* ```
	*/
	async execute(variables) {
		const onContinue = () => {
			this.#dispatch({ type: "continue" });
		};
		const mutationFnContext = {
			client: this.#client,
			meta: this.options.meta,
			mutationKey: this.options.mutationKey
		};
		const retryer = this.#retryer = createRetryer({
			fn: () => {
				if (!this.options.mutationFn) return Promise.reject(/* @__PURE__ */ new Error("No mutationFn found"));
				return this.options.mutationFn(variables, mutationFnContext);
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue,
			retry: this.options.retry ?? 0,
			retryDelay: this.options.retryDelay,
			networkMode: this.options.networkMode,
			canRun: () => this.#mutationCache.canRun(this)
		});
		const restored = this.state.status === "pending";
		const isPaused = !retryer.canStart();
		try {
			if (restored) onContinue();
			else {
				this.#dispatch({
					type: "pending",
					variables,
					isPaused
				});
				if (this.#mutationCache.config.onMutate) await this.#mutationCache.config.onMutate(variables, this, mutationFnContext);
				const context = await this.options.onMutate?.(variables, mutationFnContext);
				if (context !== this.state.context) this.#dispatch({
					type: "pending",
					context,
					variables,
					isPaused
				});
			}
			const data = await retryer.start();
			await this.#mutationCache.config.onSuccess?.(data, variables, this.state.context, this, mutationFnContext);
			await this.options.onSuccess?.(data, variables, this.state.context, mutationFnContext);
			await this.#mutationCache.config.onSettled?.(data, null, this.state.variables, this.state.context, this, mutationFnContext);
			await this.options.onSettled?.(data, null, variables, this.state.context, mutationFnContext);
			this.#dispatch({
				type: "success",
				data
			});
			return data;
		} catch (error) {
			try {
				await this.#mutationCache.config.onError?.(error, variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onError?.(error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.#mutationCache.config.onSettled?.(void 0, error, this.state.variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onSettled?.(void 0, error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			this.#dispatch({
				type: "error",
				error
			});
			throw error;
		} finally {
			if (this.#retryer === retryer) this.#retryer = void 0;
			this.#mutationCache.runNext(this);
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					failureCount: action.failureCount,
					failureReason: action.error
				};
				case "pause": return {
					...state,
					isPaused: true
				};
				case "continue": return {
					...state,
					isPaused: false
				};
				case "pending": return {
					...state,
					context: action.context,
					data: void 0,
					failureCount: 0,
					failureReason: null,
					error: null,
					isPaused: action.isPaused,
					status: "pending",
					variables: action.variables,
					submittedAt: Date.now()
				};
				case "success": return {
					...state,
					data: action.data,
					failureCount: 0,
					failureReason: null,
					error: null,
					status: "success",
					isPaused: false
				};
				case "error": return {
					...state,
					data: void 0,
					error: action.error,
					failureCount: state.failureCount + 1,
					failureReason: action.error,
					isPaused: false,
					status: "error"
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.#observers.forEach((observer) => {
				observer.onMutationUpdate(action);
			});
			this.#mutationCache.notify({
				mutation: this,
				type: "updated",
				action
			});
		});
	}
};
/**
* Returns the initial state of a mutation: `'idle'`, with no data, error, or variables.
* @returns The initial mutation state.
*/
function getDefaultState() {
	return {
		context: void 0,
		data: void 0,
		error: null,
		failureCount: 0,
		failureReason: null,
		isPaused: false,
		status: "idle",
		variables: void 0,
		submittedAt: 0
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutationCache.js
/**
* The `MutationCache` is the storage for mutations.
*
* Normally, you will not interact with the `MutationCache` directly and instead use a
* `QueryClient`. You can subscribe to it (inherited from `Subscribable`) to be informed of
* safe/known updates to the cache, such as mutations being added, removed, or updated.
* @example
* ```ts
* const unsubscribe = mutationCache.subscribe((event) => {
*   console.log(event.type, event.mutation)
* })
* ```
*/
var MutationCache = class extends Subscribable {
	#mutations;
	#scopes;
	#mutationId;
	constructor(config = {}) {
		super();
		this.config = config;
		this.#mutations = /* @__PURE__ */ new Set();
		this.#scopes = /* @__PURE__ */ new Map();
		this.#mutationId = 0;
	}
	/**
	* Creates a mutation and adds it to the cache.
	* @internal
	* @param client - The client the mutation belongs to, used to default its options.
	* @param options - The mutation options. They are defaulted with {@link
	* QueryClient#defaultMutationOptions}.
	* @param state - The initial state of the mutation, e.g. when restoring a dehydrated mutation.
	* @returns The new mutation, already added to the cache.
	*/
	build(client, options, state) {
		const mutation = new Mutation({
			client,
			mutationCache: this,
			mutationId: ++this.#mutationId,
			options: client.defaultMutationOptions(options),
			state
		});
		this.add(mutation);
		return mutation;
	}
	/**
	* Adds a mutation to the cache.
	* @internal
	* @param mutation - The mutation to add. If it has a `scope`, it is queued in that scope.
	*/
	add(mutation) {
		this.#mutations.add(mutation);
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const scopedMutations = this.#scopes.get(scope);
			if (scopedMutations) scopedMutations.push(mutation);
			else this.#scopes.set(scope, [mutation]);
		}
		this.notify({
			type: "added",
			mutation
		});
	}
	/**
	* Removes a mutation from the cache.
	* @internal
	* @param mutation - The mutation to remove, also from its scope's queue.
	*/
	remove(mutation) {
		if (this.#mutations.delete(mutation)) {
			const scope = scopeFor(mutation);
			if (typeof scope === "string") {
				const scopedMutations = this.#scopes.get(scope);
				if (scopedMutations) {
					if (scopedMutations.length > 1) {
						const index = scopedMutations.indexOf(mutation);
						if (index !== -1) scopedMutations.splice(index, 1);
					} else if (scopedMutations[0] === mutation) this.#scopes.delete(scope);
				}
			}
		}
		this.notify({
			type: "removed",
			mutation
		});
	}
	/**
	* Checks whether a mutation can run now, given the other mutations in its `scope`.
	* @internal
	* @param mutation - The mutation to check.
	* @returns `true` if the mutation has no `scope`, or no other mutation in its scope is pending
	* ahead of it.
	*/
	canRun(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const firstPendingMutation = this.#scopes.get(scope)?.find((m) => m.state.status === "pending");
			return !firstPendingMutation || firstPendingMutation === mutation;
		} else return true;
	}
	/**
	* Continues the next paused mutation in the same `scope` after a mutation finishes.
	* @internal
	* @param mutation - The mutation that finished.
	* @returns A promise that resolves once the next paused mutation in the same scope has continued,
	* or immediately if there is none.
	*/
	runNext(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") return (this.#scopes.get(scope)?.find((m) => m !== mutation && m.state.isPaused))?.continue() ?? Promise.resolve();
		else return Promise.resolve();
	}
	/**
	* Removes all mutations from the cache.
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* mutationCache.clear()
	* ```
	*/
	clear() {
		notifyManager.batch(() => {
			const mutations = this.getAll();
			this.#mutations.clear();
			this.#scopes.clear();
			mutations.forEach((mutation) => {
				this.notify({
					type: "removed",
					mutation
				});
			});
		});
	}
	/**
	* Returns all mutations within the cache.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a mutation in rare scenarios.
	* @returns Every mutation in the cache.
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutations = mutationCache.getAll()
	* ```
	*/
	getAll() {
		return Array.from(this.#mutations);
	}
	/**
	* A slightly more advanced method that can be used to get an existing mutation instance from
	* the cache. If the mutation does not exist, `undefined` is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a mutation in rare scenarios.
	* @param filters - The filters to match. `exact` defaults to `true`.
	* @returns The first matching mutation, or `undefined`.
	* @see {@link MutationCache#findAll}
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
	* ```
	*/
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((mutation) => matchMutation(defaultedFilters, mutation));
	}
	/**
	* An even more advanced method that can be used to get existing mutation instances from the
	* cache that match the given filters. If no mutations match, an empty array is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about mutations in rare scenarios.
	* @param filters - The filters to match. Without filters, every mutation is returned.
	* @returns The matching mutations.
	* @see {@link MutationCache#find}
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutations = mutationCache.findAll({ mutationKey: ['addPost'] })
	* ```
	*/
	findAll(filters = {}) {
		return this.getAll().filter((mutation) => matchMutation(filters, mutation));
	}
	/**
	* Notifies every cache listener of an event, in one batch.
	* @internal
	* @param event - The event passed to every listener.
	*/
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	/**
	* Continues every paused mutation, e.g. when the app comes back online.
	* @internal
	* @returns A promise that resolves once every paused mutation has continued and settled.
	*/
	resumePausedMutations() {
		const pausedMutations = this.getAll().filter((x) => x.state.isPaused);
		return notifyManager.batch(() => Promise.all(pausedMutations.map((mutation) => mutation.continue().catch(noop))));
	}
};
/**
* Returns the scope id of a mutation, used to run mutations with the same scope one after another.
* @param mutation - The mutation to read the scope of.
* @returns The mutation's `scope.id`, or `undefined` if it has no scope.
*/
function scopeFor(mutation) {
	return mutation.options.scope?.id;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutationObserver.js
/**
* Observes a single mutation and derives a `MutationObserverResult` from it.
* A framework hook like `useMutation` creates one `MutationObserver` per hook
* call, keeps it stable across re-renders, calls `setOptions` when the options
* passed to the hook change, subscribes to it to re-render on updates, and
* reads `getCurrentResult()` for the value to return. Calling `mutate()`
* builds a new underlying `Mutation` in the `MutationCache` and executes it.
* @example
* ```ts
* const observer = new MutationObserver(queryClient, {
*   mutationFn: (variables: { title: string }) => addPost(variables),
* })
* ```
*/
var MutationObserver = class extends Subscribable {
	#client;
	#currentResult = void 0;
	#currentMutation;
	#mutateOptions;
	constructor(client, options) {
		super();
		this.#client = client;
		this.setOptions(options);
		this.bindMethods();
		this.#updateResult();
	}
	/**
	* Binds the methods of the result (`mutate` and `reset`) to the observer, so they keep working when
	* destructured from it.
	*/
	bindMethods() {
		this.mutate = this.mutate.bind(this);
		this.reset = this.reset.bind(this);
	}
	/**
	* Updates the observer's options.
	*
	* If the new `mutationKey` differs from the previous one (and both were
	* defined), the observer is reset, detaching it from the mutation it was
	* observing. Otherwise, if the currently observed mutation is still
	* `pending`, its options are updated in place as well.
	* @param options - The new mutation observer options. They are defaulted with {@link
	* QueryClient#defaultMutationOptions} before being applied.
	* @example
	* ```ts
	* observer.setOptions({
	*   mutationFn: (variables: { title: string }) => addPost(variables),
	*   onSuccess: (data) => console.log(data),
	* })
	* ```
	*/
	setOptions(options) {
		const prevOptions = this.options;
		this.options = this.#client.defaultMutationOptions(options);
		if (!shallowEqualObjects(this.options, prevOptions)) this.#client.getMutationCache().notify({
			type: "observerOptionsUpdated",
			mutation: this.#currentMutation,
			observer: this
		});
		if (prevOptions?.mutationKey && this.options.mutationKey && hashKey(prevOptions.mutationKey) !== hashKey(this.options.mutationKey)) this.reset();
		else if (this.#currentMutation?.state.status === "pending") this.#currentMutation.setOptions(this.options);
	}
	onSubscribe() {
		if (this.listeners.size === 1 && this.#currentMutation) {
			this.#currentMutation.addObserver(this);
			this.#updateResult();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.#currentMutation?.removeObserver(this);
	}
	/**
	* Updates the observer's result when the observed mutation changes, and notifies its listeners.
	* @internal
	* @param action - The action that updated the observed mutation, passed on to the observer's
	* callbacks.
	*/
	onMutationUpdate(action) {
		this.#updateResult();
		this.#notify(action);
	}
	/**
	* Returns the observer's current result, derived from the observed
	* mutation's state (or the default, `idle` state if no mutation has been
	* built yet, e.g. before the first `mutate()` call or after `reset()`).
	* @returns The observer's latest result.
	*/
	getCurrentResult() {
		return this.#currentResult;
	}
	/**
	* Detaches the observer from the mutation it is currently observing (if
	* any) and resets the observed result back to its default, `idle` state.
	*
	* This does not cancel an in-flight mutation; the mutation itself keeps
	* running to completion and its own callbacks still fire, but this
	* observer stops reflecting its state and a subsequent `mutate()` call
	* will build a brand new mutation.
	* @see {@link MutationObserver#mutate}
	* @example
	* ```ts
	* observer.reset()
	* ```
	*/
	reset() {
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = void 0;
		this.#updateResult();
		this.#notify();
	}
	/**
	* Builds a new `Mutation` in the `MutationCache` using the observer's
	* current options, detaches this observer from any previously observed
	* mutation, attaches it to the new one, and executes it with the given
	* variables.
	*
	* The optional per-call `options` (`onSuccess`/`onError`/`onSettled`) are
	* invoked once the mutation settles, in addition to any callbacks defined
	* on the observer's own options.
	* @param variables - The variables passed to the `mutationFn`.
	* @param options - Per-call `onSuccess`, `onError`, and `onSettled` callbacks.
	* @returns A promise that resolves with the mutation's data, or rejects with its error.
	* @example
	* ```ts
	* await observer.mutate(
	*   { title: 'New post' },
	*   { onSuccess: (data) => console.log(data) },
	* )
	* ```
	*/
	mutate(variables, options) {
		this.#mutateOptions = options;
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = this.#client.getMutationCache().build(this.#client, this.options);
		this.#currentMutation.addObserver(this);
		return this.#currentMutation.execute(variables);
	}
	#updateResult() {
		const state = this.#currentMutation?.state ?? getDefaultState();
		this.#currentResult = {
			...state,
			isPending: state.status === "pending",
			isSuccess: state.status === "success",
			isError: state.status === "error",
			isIdle: state.status === "idle",
			mutate: this.mutate,
			reset: this.reset
		};
	}
	#notify(action) {
		notifyManager.batch(() => {
			const mutateOptions = this.#mutateOptions;
			if (mutateOptions && this.hasListeners()) {
				const variables = this.#currentResult.variables;
				const onMutateResult = this.#currentResult.context;
				const context = {
					client: this.#client,
					meta: this.options.meta,
					mutationKey: this.options.mutationKey
				};
				if (action?.type === "success") {
					try {
						mutateOptions.onSuccess?.(action.data, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						mutateOptions.onSettled?.(action.data, null, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				} else if (action?.type === "error") {
					try {
						mutateOptions.onError?.(action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						mutateOptions.onSettled?.(void 0, action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				}
			}
			this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
		});
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queriesObserver.js
/**
* Returns the items of `array1` that are not in `array2`.
* @param array1 - The items to filter.
* @param array2 - The items to exclude.
* @returns A new array with the items of `array1` that are not in `array2`.
*/
function difference(array1, array2) {
	const excludeSet = new Set(array2);
	return array1.filter((x) => !excludeSet.has(x));
}
/**
* A `QueriesObserver` watches an array of queries at once, exposing them as
* a single array of `QueryObserverResult`s (or, when a `combine` option is
* given, as a combined value derived from that array). It manages one
* internal `QueryObserver` per query, and is the primitive that framework
* adapters (e.g. `useQueries`) build their hooks on top of.
* @example
* ```ts
* const observer = new QueriesObserver(queryClient, [
*   { queryKey: ['post', 1], queryFn: fetchPost },
*   { queryKey: ['post', 2], queryFn: fetchPost },
* ])
*
* const unsubscribe = observer.subscribe((result) => {
*   console.log(result)
* })
* ```
*/
var QueriesObserver = class extends Subscribable {
	#client;
	#result;
	#queries;
	#options;
	#observers;
	#combinedResult;
	#lastCombine;
	#lastResult;
	#lastQueryHashes;
	#observerMatches = [];
	constructor(client, queries, options) {
		super();
		this.#client = client;
		this.#options = options;
		this.#queries = [];
		this.#observers = [];
		this.#result = [];
		this.setQueries(queries);
	}
	onSubscribe() {
		if (this.listeners.size === 1) this.#observers.forEach((observer) => {
			observer.subscribe((result) => {
				this.#onUpdate(observer, result);
			});
		});
	}
	onUnsubscribe() {
		if (!this.listeners.size) this.destroy();
	}
	/**
	* Stops observing all queries: clears all listeners and destroys every
	* underlying `QueryObserver` this observer manages.
	*/
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#observers.forEach((observer) => {
			observer.destroy();
		});
	}
	/**
	* Replaces the set of queries being observed. Existing `QueryObserver`s
	* are reused for queries that match an already-observed query hash;
	* observers for queries that are no longer present are destroyed, and new
	* observers are created and subscribed to for newly added queries.
	* @param queries - The options of the queries to observe.
	* @param options - Replaces the observer's options, e.g. its `combine` function.
	* @example
	* ```ts
	* observer.setQueries([
	*   { queryKey: ['post', 1], queryFn: fetchPost },
	*   { queryKey: ['post', 3], queryFn: fetchPost },
	* ])
	* ```
	*/
	setQueries(queries, options) {
		this.#queries = queries;
		this.#options = options;
		{
			const queryHashes = queries.map((query) => this.#client.defaultQueryOptions(query).queryHash);
			if (new Set(queryHashes).size !== queryHashes.length) console.warn("[QueriesObserver]: Duplicate Queries found. This might result in unexpected behavior.");
		}
		notifyManager.batch(() => {
			const prevObservers = this.#observers;
			const newObserverMatches = this.#findMatchingObservers(this.#queries);
			newObserverMatches.forEach((match) => match.observer.setOptions(match.defaultedQueryOptions));
			const newObservers = newObserverMatches.map((match) => match.observer);
			const newResult = newObservers.map((observer) => observer.getCurrentResult());
			const hasLengthChange = prevObservers.length !== newObservers.length;
			const hasIndexChange = newObservers.some((observer, index) => observer !== prevObservers[index]);
			const hasStructuralChange = hasLengthChange || hasIndexChange;
			const hasResultChange = hasStructuralChange ? true : newResult.some((result, index) => {
				const prev = this.#result[index];
				return !prev || !shallowEqualObjects(result, prev);
			});
			if (!hasStructuralChange && !hasResultChange) return;
			if (hasStructuralChange) {
				this.#observerMatches = newObserverMatches;
				this.#observers = newObservers;
			}
			this.#result = newResult;
			if (!this.hasListeners()) return;
			if (hasStructuralChange) {
				difference(prevObservers, newObservers).forEach((observer) => {
					observer.destroy();
				});
				difference(newObservers, prevObservers).forEach((observer) => {
					observer.subscribe((result) => {
						this.#onUpdate(observer, result);
					});
				});
			}
			this.#notify();
		});
	}
	/**
	* Returns the most recently computed array of `QueryObserverResult`s, one
	* per observed query, in the same order as the queries passed to the
	* constructor or `setQueries`.
	* @returns The current results.
	* @example
	* ```ts
	* const results = observer.getCurrentResult()
	* const data = results.map((result) => result.data)
	* ```
	*/
	getCurrentResult() {
		return this.#result;
	}
	/**
	* Returns the underlying `Query` instances currently being observed, in
	* the same order as the queries passed to the constructor or `setQueries`.
	* @returns The observed queries.
	*/
	getQueries() {
		return this.#observers.map((observer) => observer.getCurrentQuery());
	}
	/**
	* Returns the underlying `QueryObserver` instances this observer manages,
	* in the same order as the queries passed to the constructor or
	* `setQueries`.
	* @returns The managed query observers.
	*/
	getObservers() {
		return this.#observers;
	}
	/**
	* The `QueriesObserver` counterpart of {@link QueryObserver#getOptimisticResult} — computes
	* the result for the given (already-defaulted) queries right now, synchronously. Called by
	* framework adapters (e.g. `useQueries`) ahead of subscribing, returning a tuple of the raw
	* per-query results, a function to compute the combined result from them, and a function to
	* wrap the results for property-access tracking.
	* @param queries - The defaulted options of the queries to compute the result for.
	* @param combine - The `combine` function used by the returned `combineResult`, if any.
	* @returns A tuple of the per-query results, a function that computes the combined result, and a
	* function that returns the results wrapped for property-access tracking.
	*/
	getOptimisticResult(queries, combine) {
		const matches = this.#findMatchingObservers(queries);
		const result = matches.map((match) => match.observer.getOptimisticResult(match.defaultedQueryOptions));
		const queryHashes = matches.map((match) => match.defaultedQueryOptions.queryHash);
		return [
			result,
			(r) => {
				return this.#combineResult(r ?? result, combine, queryHashes);
			},
			() => {
				return this.#trackResult(result, matches);
			}
		];
	}
	#trackResult(result, matches) {
		const trackedProps = /* @__PURE__ */ new Set();
		return matches.map((match, index) => {
			const observerResult = result[index];
			return !match.defaultedQueryOptions.notifyOnChangeProps ? match.observer.trackResult(observerResult, (accessedProp) => {
				if (!trackedProps.has(accessedProp)) {
					trackedProps.add(accessedProp);
					matches.forEach((m) => {
						m.observer.trackProp(accessedProp);
					});
				}
			}) : observerResult;
		});
	}
	#combineResult(input, combine, queryHashes) {
		if (combine) {
			const lastHashes = this.#lastQueryHashes;
			const queryHashesChanged = queryHashes !== void 0 && lastHashes !== void 0 && (lastHashes.length !== queryHashes.length || queryHashes.some((hash, i) => hash !== lastHashes[i]));
			if (this.#result !== this.#lastResult || queryHashesChanged || combine !== this.#lastCombine) {
				this.#lastCombine = combine;
				this.#lastResult = this.#result;
				if (queryHashes !== void 0) this.#lastQueryHashes = queryHashes;
				this.#combinedResult = replaceEqualDeep(this.#combinedResult, combine(input));
			}
			return this.#combinedResult;
		}
		return input;
	}
	#shouldSkipCombine() {
		return !this.#options?.combine || this.#observers.some((observer, index) => {
			return observer.options.suspense && this.#result[index]?.data === void 0;
		});
	}
	#findMatchingObservers(queries) {
		const prevObserversMap = /* @__PURE__ */ new Map();
		this.#observers.forEach((observer) => {
			const key = observer.options.queryHash;
			if (!key) return;
			const previousObservers = prevObserversMap.get(key);
			if (previousObservers) previousObservers.push(observer);
			else prevObserversMap.set(key, [observer]);
		});
		const observers = [];
		queries.forEach((options) => {
			const defaultedOptions = this.#client.defaultQueryOptions(options);
			const observer = prevObserversMap.get(defaultedOptions.queryHash)?.shift() ?? new QueryObserver(this.#client, defaultedOptions);
			observers.push({
				defaultedQueryOptions: defaultedOptions,
				observer
			});
		});
		return observers;
	}
	#onUpdate(observer, result) {
		const index = this.#observers.indexOf(observer);
		if (index !== -1) {
			this.#result = this.#result.slice();
			this.#result[index] = result;
			this.#notify();
		}
	}
	#notify() {
		if (this.hasListeners()) {
			const shouldSkipCombine = this.#shouldSkipCombine();
			const previousResult = this.#combinedResult;
			const newResult = shouldSkipCombine ? previousResult : this.#combineResult(this.#trackResult(this.#result, this.#observerMatches), this.#options?.combine);
			if (shouldSkipCombine || previousResult !== newResult) notifyManager.batch(() => {
				this.listeners.forEach((listener) => {
					listener(this.#result);
				});
			});
		}
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryCache.js
/**
* The `QueryCache` is the storage mechanism for TanStack Query. It stores all the data, meta
* information, and state of the queries it contains.
*
* Normally, you will not interact with the `QueryCache` directly and instead use a `QueryClient`
* for a specific cache. You can subscribe to it (inherited from `Subscribable`) to be informed of
* safe/known updates to the cache, such as queries being added, removed, or updated — updates made
* outside of the cache's own tracked mechanisms (e.g. mutating a query's state object directly) do
* not notify subscribers.
* @example
* ```ts
* const unsubscribe = queryCache.subscribe((event) => {
*   console.log(event.type, event.query)
* })
* ```
*/
var QueryCache = class extends Subscribable {
	#queries;
	constructor(config = {}) {
		super();
		this.config = config;
		this.#queries = /* @__PURE__ */ new Map();
	}
	/**
	* Returns the existing `Query` instance for the given options' `queryKey`/`queryHash`, or
	* builds and adds a new one to the cache if none exists yet. Used by framework adapters and
	* plugins (e.g. broadcast/persistence) that need to get-or-create a `Query` directly, bypassing
	* the reactive `QueryObserver` machinery.
	* @param client - The client the query belongs to, used to default its options.
	* @param options - The query options, including the `queryKey`. A new query is created with the
	* options defaulted by {@link QueryClient#defaultQueryOptions}.
	* @param state - The initial state of a newly created query, e.g. when hydrating. Ignored if the
	* query already exists.
	* @returns The existing or newly created query.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const query = queryCache.build(queryClient, {
	*   queryKey: ['posts'],
	*   queryFn: fetchPosts,
	* })
	* ```
	*/
	build(client, options, state) {
		const queryKey = options.queryKey;
		const queryHash = options.queryHash ?? hashQueryKeyByOptions(queryKey, options);
		let query = this.get(queryHash);
		if (!query) {
			query = new Query({
				client,
				queryKey,
				queryHash,
				options: client.defaultQueryOptions(options),
				state,
				defaultOptions: client.getQueryDefaults(queryKey)
			});
			this.add(query);
		}
		return query;
	}
	/**
	* Adds a query to the cache.
	* @internal
	* @param query - The query to add. If a query with the same hash is already cached, nothing
	* happens.
	*/
	add(query) {
		if (!this.#queries.has(query.queryHash)) {
			this.#queries.set(query.queryHash, query);
			this.notify({
				type: "added",
				query
			});
		}
	}
	/**
	* Destroys the given `Query` and removes it from the cache, notifying subscribers with a
	* `'removed'` event. A no-op if the query is no longer the one currently stored under its hash
	* (e.g. it was already replaced). Used by plugins (e.g. the broadcast client) that mirror
	* removals across `QueryCache` instances.
	* @param query - The query to remove.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	* const query = queryCache.find({ queryKey: ['posts'] })
	*
	* if (query) {
	*   queryCache.remove(query)
	* }
	* ```
	*/
	remove(query) {
		if (this.#queries.get(query.queryHash) === query) {
			query.destroy();
			this.#queries.delete(query.queryHash);
			this.notify({
				type: "removed",
				query
			});
		}
	}
	/**
	* Removes all queries from the cache.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* queryCache.clear()
	* ```
	*/
	clear() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				this.remove(query);
			});
		});
	}
	/**
	* Returns the `Query` instance stored under the given `queryHash`, or `undefined` if none
	* exists. Unlike {@link QueryCache#find}, this looks up by the already-computed hash rather
	* than by `QueryFilters`. Used by plugins (e.g. broadcast/hydration) that already have a hash
	* to look up directly.
	* @param queryHash - The hash of the query to look up.
	* @returns The query stored under the hash, or `undefined`.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	* const queryHash = hashKey(['posts'])
	*
	* const query = queryCache.get(queryHash)
	* ```
	*/
	get(queryHash) {
		return this.#queries.get(queryHash);
	}
	/**
	* Returns all queries within the cache.
	* @returns Every query in the cache.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const queries = queryCache.getAll()
	* ```
	*/
	getAll() {
		return [...this.#queries.values()];
	}
	/**
	* A slightly more advanced method that can be used to get an existing query instance from the
	* cache. This instance not only contains all the state for the query, but all of the instances,
	* and underlying guts of the query as well. If the query does not exist, `undefined` is
	* returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a query in rare scenarios (e.g. looking at `query.state.dataUpdatedAt` to
	* decide whether a query is fresh enough to be used as an initial value).
	* @param filters - The filters to match, including the required `queryKey`. `exact` defaults to
	* `true`.
	* @returns The first matching query, or `undefined`.
	* @see {@link QueryCache#findAll}
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const query = queryCache.find({ queryKey: ['posts'] })
	* ```
	*/
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((query) => matchQuery(defaultedFilters, query));
	}
	/**
	* An even more advanced method that can be used to get existing query instances from the cache
	* that partially match a query key. If no queries match, an empty array is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about queries in rare scenarios.
	* @param filters - The filters to match. Without filters, every query is returned.
	* @returns The matching queries.
	* @see {@link QueryCache#find}
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const queries = queryCache.findAll({ queryKey: ['posts'] })
	* ```
	*/
	findAll(filters = {}) {
		const queries = this.getAll();
		return Object.keys(filters).length > 0 ? queries.filter((query) => matchQuery(filters, query)) : queries;
	}
	/**
	* Notifies every cache listener of an event, in one batch.
	* @internal
	* @param event - The event passed to every listener.
	*/
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	/**
	* Calls {@link Query#onFocus} on every cached query, in one batch.
	* @internal
	*/
	onFocus() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onFocus();
			});
		});
	}
	/**
	* Calls {@link Query#onOnline} on every cached query, in one batch.
	* @internal
	*/
	onOnline() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onOnline();
			});
		});
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryClient.js
/**
* `QueryClient` is used to interact with a cache of queries and mutations. It owns a
* `QueryCache` and a `MutationCache` (creating default ones if none are passed in) and holds
* the default options that are applied to queries and mutations created through it.
* @example
* ```ts
* const queryClient = new QueryClient({
*   defaultOptions: {
*     queries: {
*       staleTime: Infinity,
*     },
*   },
* })
*
* await queryClient.query({ queryKey: ['posts'], queryFn: fetchPosts })
* ```
*/
var QueryClient = class {
	#queryCache;
	#mutationCache;
	#defaultOptions;
	#queryDefaults;
	#mutationDefaults;
	#mountCount;
	#unsubscribeFocus;
	#unsubscribeOnline;
	constructor(config = {}) {
		this.#queryCache = config.queryCache || new QueryCache();
		this.#mutationCache = config.mutationCache || new MutationCache();
		this.#defaultOptions = config.defaultOptions || {};
		this.#queryDefaults = /* @__PURE__ */ new Map();
		this.#mutationDefaults = /* @__PURE__ */ new Map();
		this.#mountCount = 0;
	}
	/**
	* Called by a framework adapter's `QueryClientProvider`-equivalent when it mounts, to start
	* listening for focus/online events and resume paused mutations. Ref-counted via an internal
	* mount count, so nested or multiple providers sharing the same `QueryClient` don't tear down
	* the shared listeners until the last one unmounts.
	*/
	mount() {
		this.#mountCount++;
		if (this.#mountCount !== 1) return;
		this.#unsubscribeFocus = focusManager.subscribe(async (focused) => {
			if (focused) {
				await this.resumePausedMutations();
				this.#queryCache.onFocus();
			}
		});
		this.#unsubscribeOnline = onlineManager.subscribe(async (online) => {
			if (online) {
				await this.resumePausedMutations();
				this.#queryCache.onOnline();
			}
		});
	}
	/**
	* The inverse of {@link QueryClient#mount} — called by a framework adapter's
	* `QueryClientProvider`-equivalent when it unmounts. Only tears down the focus/online
	* listeners once the mount count returns to `0`.
	*/
	unmount() {
		this.#mountCount--;
		if (this.#mountCount !== 0) return;
		this.#unsubscribeFocus?.();
		this.#unsubscribeFocus = void 0;
		this.#unsubscribeOnline?.();
		this.#unsubscribeOnline = void 0;
	}
	/**
	* Returns the number of queries in the cache that are currently fetching, optionally
	* matching a set of filters. This includes background-fetching, loading new pages, and
	* loading more infinite query results.
	* @param filters - Narrows down which fetching queries are counted. Without filters, every
	* fetching query is counted.
	* @returns The number of matching queries whose `fetchStatus` is `'fetching'`.
	* @example
	* ```ts
	* if (queryClient.isFetching()) {
	*   console.log('At least one query is fetching!')
	* }
	* ```
	*/
	isFetching(filters) {
		return this.#queryCache.findAll({
			...filters,
			fetchStatus: "fetching"
		}).length;
	}
	/**
	* Returns the number of mutations in the cache that are currently pending, optionally
	* matching a set of filters.
	* @param filters - Narrows down which pending mutations are counted. Without filters, every
	* pending mutation is counted.
	* @returns The number of matching mutations whose `status` is `'pending'`.
	* @example
	* ```ts
	* if (queryClient.isMutating()) {
	*   console.log('At least one mutation is pending!')
	* }
	* ```
	*/
	isMutating(filters) {
		return this.#mutationCache.findAll({
			...filters,
			status: "pending"
		}).length;
	}
	/**
	* Imperative (non-reactive) way to retrieve data for a QueryKey.
	* Should only be used in callbacks or functions where reading the latest data is necessary, e.g. for optimistic updates.
	*
	* Hint: Do not use this function inside a component, because it won't receive updates.
	* Use `useQuery` to create a `QueryObserver` that subscribes to changes.
	* @param queryKey - The query key of the query to read.
	* @returns The cached data for the query, or `undefined` if no query with this key has been observed yet.
	* @see {@link QueryClient#getQueriesData}
	*/
	getQueryData(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state.data;
	}
	/**
	* Returns the cached data of a query, or fetches it if there is none. With `revalidateIfStale`,
	* stale cached data is also refetched in the background.
	* @param options - The query options. If the query has no cached data yet, it is fetched with
	* these options.
	* @returns A promise that resolves to the cached data, or to the fetched data if nothing was
	* cached yet.
	* @deprecated Use queryClient.query({ ...options, staleTime: 'static' }) instead. This method will be removed in the next major version.
	*/
	ensureQueryData(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		const query = this.#queryCache.build(this, defaultedOptions);
		const cachedData = query.state.data;
		if (cachedData === void 0) return this.fetchQuery(options);
		if (options.revalidateIfStale && query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query))) this.prefetchQuery(defaultedOptions);
		return Promise.resolve(cachedData);
	}
	/**
	* Imperative (non-reactive) way to retrieve the cached data of multiple queries at once.
	* Only queries matching the given filters are returned; if none match, an empty array is
	* returned.
	*
	* Because the matched queries can hold data of different shapes (e.g. a broad filter can match
	* queries with unrelated data types), the `TQueryFnData` generic defaults to `unknown` rather
	* than being inferred. Passing a more specific type is a convenience for call sites that know
	* every matched query holds the same shape — it is not checked against the actual cache
	* contents.
	* @param filters - The filters that select which queries to read.
	* @returns An array of query key and data pairs. The data is `undefined` for a query with no cached data.
	* @see {@link QueryClient#getQueryData}
	* @example
	* ```ts
	* const data = queryClient.getQueriesData({ queryKey: ['posts'] })
	* ```
	*/
	getQueriesData(filters) {
		return this.#queryCache.findAll(filters).map(({ queryKey, state }) => {
			return [queryKey, state.data];
		});
	}
	/**
	* Synchronous way to immediately update a query's cached data. If the updater (or the value
	* passed) resolves to `undefined`, the cache is left untouched and no query is created;
	* otherwise, if the query does not exist yet, it will be created. To update multiple queries
	* at once by partially matching query keys, use {@link QueryClient#setQueriesData} instead.
	*
	* Updates must be performed immutably: do not mutate `oldData`, or data previously retrieved
	* via {@link QueryClient#getQueryData}, in place.
	* @param queryKey - The query key to set data for.
	* @param updater - Either the new data, or a function that receives the current data (which
	* may be `undefined`) and returns the new data.
	* @param options - Set `updatedAt` to override the timestamp the written data is recorded with.
	* @returns The data that was written, or `undefined` if the updater returned `undefined` — in that case
	* the write is skipped and the cache is left unchanged.
	* @example
	* ```ts
	* queryClient.setQueryData(['posts'], newPosts)
	*
	* // Or, using an updater function that receives the current data:
	* queryClient.setQueryData(['posts'], (oldPosts) => [...oldPosts, newPost])
	* ```
	*/
	setQueryData(queryKey, updater, options) {
		const defaultedOptions = this.defaultQueryOptions({ queryKey });
		const prevData = this.#queryCache.get(defaultedOptions.queryHash)?.state.data;
		const data = functionalUpdate(updater, prevData);
		if (data === void 0) return;
		return this.#queryCache.build(this, defaultedOptions).setData(data, {
			...options,
			manual: true
		});
	}
	/**
	* Synchronous way to immediately update the cached data of multiple queries at once, using
	* filters or partial query key matching. Only queries that already exist and match the given
	* filters are updated; no new cache entries are created. Internally this calls
	* {@link QueryClient#setQueryData} for each matching query.
	* @param filters - The filters that select which existing queries to update.
	* @param updater - Either the new data, or a function that receives each matched query's current
	* data (which may be `undefined`) and returns the new data.
	* @param options - Set `updatedAt` to override the timestamp the written data is recorded with.
	* @returns One `[queryKey, data]` tuple per matched query, in the same shape and with the same
	* `undefined` case as {@link QueryClient#setQueryData}.
	* @example
	* ```ts
	* queryClient.setQueriesData({ queryKey: ['posts'] }, (oldPosts) =>
	*   oldPosts ? oldPosts.filter((post) => post.id !== deletedId) : oldPosts,
	* )
	* ```
	*/
	setQueriesData(filters, updater, options) {
		return notifyManager.batch(() => this.#queryCache.findAll(filters).map(({ queryKey }) => [queryKey, this.setQueryData(queryKey, updater, options)]));
	}
	/**
	* Imperative (non-reactive) way to retrieve an existing query's state. If the query does not
	* exist, `undefined` is returned.
	* @param queryKey - The query key of the query to read.
	* @returns The query's state, or `undefined` if no query with this key exists.
	* @example
	* ```ts
	* const state = queryClient.getQueryState(['posts'])
	* console.log(state?.dataUpdatedAt)
	* ```
	*/
	getQueryState(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state;
	}
	/**
	* Removes queries from the cache that match the given filters. Unlike
	* {@link QueryClient#invalidateQueries} or {@link QueryClient#refetchQueries}, this removes
	* matching queries from the cache instead of refetching them. Without filters, every query in
	* the cache is removed.
	* @param filters - The filters that select which queries to remove. Without filters, every query
	* is removed.
	* @example
	* ```ts
	* queryClient.removeQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	removeQueries(filters) {
		const queryCache = this.#queryCache;
		notifyManager.batch(() => {
			queryCache.findAll(filters).forEach((query) => {
				queryCache.remove(query);
			});
		});
	}
	/**
	* Resets queries matching the given filters back to their initial state (e.g. any
	* `initialData`), notifying subscribers rather than removing them. Active queries among the
	* matched set are then refetched, and the returned promise resolves once that refetch settles.
	* @param filters - The filters that select which queries to reset. Without filters, every query
	* is reset.
	* @param options - Passed to the refetch of the active matched queries, e.g. `cancelRefetch` and
	* `throwOnError`.
	* @returns A promise that resolves once the refetch of the active matched queries settles.
	* @example
	* ```ts
	* await queryClient.resetQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	resetQueries(filters, options) {
		const queryCache = this.#queryCache;
		return notifyManager.batch(() => {
			const matched = queryCache.findAll(filters);
			const queriesToRefetch = new Set(matched);
			matched.forEach((query) => {
				query.reset();
			});
			return this.refetchQueries({
				type: "active",
				predicate: (query) => queriesToRefetch.has(query)
			}, options);
		});
	}
	/**
	* Cancels outgoing fetches for queries matching the given filters. Most useful when performing
	* optimistic updates, since any outgoing refetch that resolves afterwards would otherwise
	* overwrite the optimistic update. By default (`revert: true`), a cancelled query's data is
	* reverted to its state before the outgoing fetch started.
	*
	* The returned promise never rejects, even if individual cancellations fail.
	* @param filters - The filters that select which queries to cancel. Without filters, every query
	* is cancelled.
	* @param cancelOptions - Passed to each matched query's cancellation. `revert` defaults to
	* `true`.
	* @returns A promise that resolves once every cancellation has settled.
	* @example
	* ```ts
	* await queryClient.cancelQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	cancelQueries(filters, cancelOptions = {}) {
		const defaultedCancelOptions = {
			revert: true,
			...cancelOptions
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).map((query) => query.cancel(defaultedCancelOptions)));
		return Promise.all(promises).then(noop).catch(noop);
	}
	/**
	* Marks queries matching the given filters as invalidated. Unlike
	* {@link QueryClient#removeQueries}, invalidated queries stay in the cache.
	*
	* Unless `filters.refetchType` is `'none'`, matching queries are then refetched via
	* {@link QueryClient#refetchQueries}, using `filters.refetchType` if set, otherwise
	* `filters.type`, otherwise `'active'`.
	* @param filters - The filters that select which queries to invalidate, plus `refetchType` to
	* control which of them to refetch afterwards. Without filters, every query is invalidated.
	* @param options - Passed to {@link QueryClient#refetchQueries}, e.g. `cancelRefetch` and
	* `throwOnError`.
	* @returns A promise that resolves once the refetch settles, or immediately if `refetchType` is
	* `'none'`.
	* @example
	* ```ts
	* await queryClient.invalidateQueries({ queryKey: ['posts'], refetchType: 'active' })
	* ```
	*/
	invalidateQueries(filters, options = {}) {
		return notifyManager.batch(() => {
			this.#queryCache.findAll(filters).forEach((query) => {
				query.invalidate();
			});
			if (filters?.refetchType === "none") return Promise.resolve();
			return this.refetchQueries({
				...filters,
				type: filters?.refetchType ?? filters?.type ?? "active"
			}, options);
		});
	}
	/**
	* Refetches queries matching the given filters, regardless of whether they are stale. Without
	* filters, every query in the cache is refetched. Queries that are disabled, or static (only
	* have observers with a static `staleTime`), are never refetched.
	*
	* By default (`cancelRefetch: true`), a currently running fetch is cancelled before the new
	* one starts. The returned promise resolves once all matching queries have settled; it does
	* not reject on individual query failures unless `throwOnError` is set.
	* @param filters - The filters that select which queries to refetch. Without filters, every query
	* in the cache is included.
	* @param options - Set `cancelRefetch` to `false` to keep a running fetch instead of cancelling
	* it, and `throwOnError` to `true` to reject when a refetch fails.
	* @returns A promise that resolves once every matched query has settled.
	* @example
	* ```ts
	* // refetch all active queries partially matching a query key:
	* await queryClient.refetchQueries({ queryKey: ['posts'], type: 'active' })
	* ```
	*/
	refetchQueries(filters, options = {}) {
		const fetchOptions = {
			...options,
			cancelRefetch: options.cancelRefetch ?? true
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).filter((query) => !query.isDisabled() && !query.isStatic()).map((query) => {
			let promise = query.fetch(void 0, fetchOptions);
			if (!fetchOptions.throwOnError) promise = promise.catch(noop);
			return query.state.fetchStatus === "paused" ? Promise.resolve() : promise;
		}));
		return Promise.all(promises).then(noop);
	}
	/**
	* Asynchronous method to fetch and cache a query, resolving with the data or throwing with
	* the error.
	*
	* If the query already exists in the cache and its data is not stale (per the given
	* `staleTime`), the cached data is returned without fetching. Otherwise, the query is fetched
	* and the promise resolves once the fetch settles. If a `select` function is provided, it is
	* applied to the data in both cases (cached or freshly fetched) before it is returned.
	*
	* Unlike a reactive observer, retries are disabled by default here (`retry: false`) unless
	* explicitly configured, since there is no component to catch a thrown error and retry through
	* re-render.
	*
	* The accepted options are `QueryObserverOptions` minus the fields that only make sense for a
	* reactive observer — `enabled`, `refetchInterval`, `refetchIntervalInBackground`,
	* `refetchOnWindowFocus`, `refetchOnReconnect`, `refetchOnMount`, `retryOnMount`,
	* `notifyOnChangeProps`, `throwOnError`, `suspense`, and `placeholderData` are not part of this
	* method's options.
	*
	* This method replaces the deprecated `fetchQuery`, and — combined with
	* `{ staleTime: 'static' }` — the deprecated `ensureQueryData`.
	* @param options - The query options, including the `queryKey` and the `queryFn` used if the
	* query needs to fetch.
	* @returns A promise that resolves to the data, or to the result of `select` if provided. It
	* rejects with the error from the fetch or from `select`.
	* @example
	* ```ts
	* try {
	*   const data = await queryClient.query({ queryKey, queryFn, staleTime: 10000 })
	* } catch (error) {
	*   console.log(error)
	* }
	* ```
	*/
	async query(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
		const query = this.#queryCache.build(this, defaultedOptions);
		const queryData = query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query)) ? await query.fetch(defaultedOptions) : query.state.data;
		const select = defaultedOptions.select;
		if (select) return select(queryData);
		return queryData;
	}
	/**
	* Fetches and caches a query, or returns its cached data if it isn't stale. Unlike in observers,
	* the fetch isn't retried unless `retry` is set.
	* @param options - The query options, including the `queryKey` and the `queryFn` used if the
	* query needs to fetch.
	* @returns A promise that resolves to the cached or fetched data, or rejects with the fetch
	* error.
	* @deprecated Use queryClient.query(options) instead. This method will be removed in the next major version.
	*/
	fetchQuery(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
		const query = this.#queryCache.build(this, defaultedOptions);
		return query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query)) ? query.fetch(defaultedOptions) : Promise.resolve(query.state.data);
	}
	/**
	* Fetches and caches a query like {@link QueryClient#fetchQuery}, but ignores the result and any
	* error.
	* @param options - The query options, including the `queryKey` and the `queryFn` used if the
	* query needs to fetch.
	* @returns A promise that resolves once the fetch settles. It never rejects.
	* @deprecated Use queryClient.query(options) instead. You can swallow errors with `.catch(noop)`. This method will be removed in the next major version.
	*/
	prefetchQuery(options) {
		return this.fetchQuery(options).then(noop).catch(noop);
	}
	/**
	* Asynchronous method to fetch and cache an infinite query, resolving with an
	* {@link InfiniteData} object or throwing with the error.
	*
	* Behaves like {@link QueryClient#query}, accepting the same options (minus
	* `initialPageParam`), plus the required `initialPageParam`, and an optional `pages` /
	* `getNextPageParam` pair used to refetch a fixed number of pages from the start.
	*
	* This method replaces the deprecated `fetchInfiniteQuery`, and — combined with
	* `{ staleTime: 'static' }` — the deprecated `ensureInfiniteQueryData`.
	* @param options - The infinite query options, including the `queryKey`, the `queryFn`, and the
	* `initialPageParam`.
	* @returns A promise that resolves to the {@link InfiniteData}, or to the result of `select` if
	* provided. It rejects with the error from the fetch or from `select`.
	* @example
	* ```ts
	* try {
	*   const data = await queryClient.infiniteQuery({ queryKey, queryFn, initialPageParam: 0 })
	*   console.log(data.pages)
	* } catch (error) {
	*   console.log(error)
	* }
	* ```
	*/
	infiniteQuery(options) {
		options._type = "infinite";
		return this.query(options);
	}
	/**
	* Fetches and caches an infinite query, or returns its cached data if it isn't stale.
	* @param options - The infinite query options, including the `queryKey`, the `queryFn`, and the
	* `initialPageParam`.
	* @returns A promise that resolves to the cached or fetched {@link InfiniteData}, or rejects with
	* the fetch error.
	* @deprecated Use queryClient.infiniteQuery(options) instead. This method will be removed in the next major version.
	*/
	fetchInfiniteQuery(options) {
		options._type = "infinite";
		return this.fetchQuery(options);
	}
	/**
	* Fetches and caches an infinite query like {@link QueryClient#fetchInfiniteQuery}, but ignores
	* the result and any error.
	* @param options - The infinite query options, including the `queryKey`, the `queryFn`, and the
	* `initialPageParam`.
	* @returns A promise that resolves once the fetch settles. It never rejects.
	* @deprecated Use queryClient.infiniteQuery(options) instead. You can swallow errors with `.catch(noop)`. This method will be removed in the next major version.
	*/
	prefetchInfiniteQuery(options) {
		return this.fetchInfiniteQuery(options).then(noop).catch(noop);
	}
	/**
	* Returns the cached data of an infinite query, or fetches it if there is none. With
	* `revalidateIfStale`, stale cached data is also refetched in the background.
	* @param options - The infinite query options. If the query has no cached data yet, it is fetched
	* with these options.
	* @returns A promise that resolves to the cached {@link InfiniteData}, or to the fetched data if
	* nothing was cached yet.
	* @deprecated Use queryClient.infiniteQuery({ ...options, staleTime: 'static' }) instead. This method will be removed in the next major version.
	*/
	ensureInfiniteQueryData(options) {
		options._type = "infinite";
		return this.ensureQueryData(options);
	}
	/**
	* Resumes mutations that were paused because there was no network connection. Does nothing
	* (resolving immediately) if the client is currently offline.
	* @returns A promise that resolves once the resumed mutations have settled.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* await queryClient.resumePausedMutations()
	* ```
	*/
	resumePausedMutations() {
		if (onlineManager.isOnline()) return this.#mutationCache.resumePausedMutations();
		return Promise.resolve();
	}
	/**
	* Returns the query cache this client is connected to.
	* @returns The {@link QueryCache} instance.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const queryCache = queryClient.getQueryCache()
	* const queries = queryCache.findAll({ queryKey: ['posts'] })
	* ```
	*/
	getQueryCache() {
		return this.#queryCache;
	}
	/**
	* Returns the mutation cache this client is connected to.
	* @returns The {@link MutationCache} instance.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const mutationCache = queryClient.getMutationCache()
	* const mutations = mutationCache.findAll({ status: 'pending' })
	* ```
	*/
	getMutationCache() {
		return this.#mutationCache;
	}
	/**
	* Returns the default options that were set when creating the client, or via
	* {@link QueryClient#setDefaultOptions}.
	* @returns The client's current default options.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const defaultOptions = queryClient.getDefaultOptions()
	* ```
	*/
	getDefaultOptions() {
		return this.#defaultOptions;
	}
	/**
	* Dynamically sets the default options for this client, overwriting any previously defined
	* default options.
	* @param options - The new default options for queries and mutations.
	* @see {@link QueryClient#getDefaultOptions}
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* queryClient.setDefaultOptions({
	*   queries: {
	*     staleTime: Infinity,
	*   },
	* })
	* ```
	*/
	setDefaultOptions(options) {
		this.#defaultOptions = options;
	}
	/**
	* Sets default options for queries whose query key partially matches the given `queryKey`.
	*
	* If several registered query defaults match a given query key, they are merged together in
	* registration order by {@link QueryClient#getQueryDefaults}, so register defaults from the
	* most generic key to the least generic one — more specific defaults should be registered
	* after more generic ones so they take precedence.
	* @param queryKey - The query key that query keys are partially matched against.
	* @param options - The default options applied to matching queries.
	* @example
	* ```ts
	* queryClient.setQueryDefaults(['posts'], { queryFn: fetchPosts })
	*
	* await queryClient.query({ queryKey: ['posts'] })
	* ```
	*/
	setQueryDefaults(queryKey, options) {
		this.#queryDefaults.set(hashKey(queryKey), {
			queryKey,
			defaultOptions: options
		});
	}
	/**
	* Returns the default options registered for queries whose query key partially matches the
	* given `queryKey`, via {@link QueryClient#setQueryDefaults}. If multiple registered defaults
	* match, they are merged together in registration order.
	* @param queryKey - The query key to look up registered defaults for.
	* @returns The merged default options of every registration that matches, or an empty object if
	* none match.
	* @example
	* ```ts
	* const defaultOptions = queryClient.getQueryDefaults(['posts'])
	* ```
	*/
	getQueryDefaults(queryKey) {
		const defaults = [...this.#queryDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(queryKey, queryDefault.queryKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	/**
	* Sets default options for mutations whose mutation key partially matches the given
	* `mutationKey`. As with {@link QueryClient#setQueryDefaults}, the order of registration
	* matters when several registered defaults match the same mutation key.
	* @param mutationKey - The mutation key that mutation keys are partially matched against.
	* @param options - The default options applied to matching mutations.
	* @see {@link QueryClient#getMutationDefaults}
	* @example
	* ```ts
	* queryClient.setMutationDefaults(['addPost'], { mutationFn: addPost })
	* ```
	*/
	setMutationDefaults(mutationKey, options) {
		this.#mutationDefaults.set(hashKey(mutationKey), {
			mutationKey,
			defaultOptions: options
		});
	}
	/**
	* Returns the default options registered for mutations whose mutation key partially matches
	* the given `mutationKey`, via {@link QueryClient#setMutationDefaults}. If multiple registered
	* defaults match, they are merged together in registration order.
	* @param mutationKey - The mutation key to look up registered defaults for.
	* @returns The merged default options of every registration that matches, or an empty object if
	* none match.
	* @example
	* ```ts
	* const defaultOptions = queryClient.getMutationDefaults(['addPost'])
	* ```
	*/
	getMutationDefaults(mutationKey) {
		const defaults = [...this.#mutationDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(mutationKey, queryDefault.mutationKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	/**
	* Called by framework adapters (e.g. inside `useQuery`) to resolve the options passed by the
	* caller into their final, defaulted form: merging the client's own `defaultOptions.queries`,
	* then `queryClient.setQueryDefaults` for the given `queryKey`, then the caller's options on
	* top. A no-op if the options are already defaulted (`_defaulted: true`).
	* @param options - The query options passed by the caller.
	* @returns The defaulted options, with `queryHash` and dependent defaults (e.g.
	* `refetchOnReconnect`) filled in.
	*/
	defaultQueryOptions(options) {
		if (options._defaulted) return options;
		const defaultedOptions = {
			...this.#defaultOptions.queries,
			...this.getQueryDefaults(options.queryKey),
			...options,
			_defaulted: true
		};
		if (!defaultedOptions.queryHash) defaultedOptions.queryHash = hashQueryKeyByOptions(defaultedOptions.queryKey, defaultedOptions);
		if (defaultedOptions.refetchOnReconnect === void 0) defaultedOptions.refetchOnReconnect = defaultedOptions.networkMode !== "always";
		if (defaultedOptions.throwOnError === void 0) defaultedOptions.throwOnError = !!defaultedOptions.suspense;
		if (!defaultedOptions.networkMode && defaultedOptions.persister) defaultedOptions.networkMode = "offlineFirst";
		if (defaultedOptions.queryFn === skipToken) defaultedOptions.enabled = false;
		return defaultedOptions;
	}
	/**
	* The mutation counterpart of {@link QueryClient#defaultQueryOptions}. Called by framework
	* adapters (e.g. inside `useMutation`) to merge the client's `defaultOptions.mutations`, then
	* `queryClient.setMutationDefaults` for the given `mutationKey`, then the caller's options on
	* top. A no-op if the options are already defaulted (`_defaulted: true`).
	* @param options - The mutation options passed by the caller.
	* @returns The defaulted options.
	*/
	defaultMutationOptions(options) {
		if (options?._defaulted) return options;
		return {
			...this.#defaultOptions.mutations,
			...options?.mutationKey && this.getMutationDefaults(options.mutationKey),
			...options,
			_defaulted: true
		};
	}
	/**
	* Clears both the query cache and the mutation cache this client is connected to.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* queryClient.clear()
	* ```
	*/
	clear() {
		this.#queryCache.clear();
		this.#mutationCache.clear();
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/streamedQuery.js
/**
* This is a helper function to create a query function that streams data from an AsyncIterable.
* Data will be an Array of all the chunks received.
* The query will be in a 'pending' state until the first chunk of data is received, but will go to 'success' after that.
* The query will stay in fetchStatus 'fetching' until the stream ends.
* @param options - The `streamFn` that returns an AsyncIterable to stream data from, and the optional
* `refetchMode`, `reducer`, and `initialValue` options.
* @returns A query function to pass as `queryFn`.
* @example
* ```ts
* await queryClient.query({
*   queryKey: ['data'],
*   queryFn: streamedQuery({
*     streamFn: fetchDataInChunks,
*   }),
* })
* ```
*/
function streamedQuery({ streamFn, refetchMode = "reset", reducer = (items, chunk) => addToEnd(items, chunk), initialValue = [] }) {
	return async (context) => {
		const query = context.client.getQueryCache().find({
			queryKey: context.queryKey,
			exact: true
		});
		const isRefetch = !!query && query.isFetched();
		if (isRefetch && refetchMode === "reset") query.setState({
			...query.resetState,
			fetchStatus: "fetching"
		});
		let result = initialValue;
		let cancelled = false;
		const stream = await streamFn(addConsumeAwareSignal({
			client: context.client,
			meta: context.meta,
			queryKey: context.queryKey,
			pageParam: context.pageParam,
			direction: context.direction
		}, () => context.signal, () => cancelled = true));
		const isReplaceRefetch = isRefetch && refetchMode === "replace";
		for await (const chunk of stream) {
			if (cancelled) break;
			if (isReplaceRefetch) result = reducer(result, chunk);
			else context.client.setQueryData(context.queryKey, (prev) => reducer(prev === void 0 ? initialValue : prev, chunk));
		}
		if (isReplaceRefetch && !cancelled) context.client.setQueryData(context.queryKey, result);
		const data = context.client.getQueryData(context.queryKey);
		return data === void 0 ? initialValue : data;
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/types.js
/* istanbul ignore file */
var dataTagSymbol = Symbol();
var dataTagErrorSymbol = Symbol();
var unsetMarker = Symbol();
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/HydrationBoundary.js
/**
* `HydrationBoundary` adds a previously dehydrated state into the `queryClient` that would be returned by
* `useQueryClient()`. If the client already contains data, the new queries will be intelligently merged based on
* update timestamp.
*
* Note: Only `queries` can be dehydrated with an `HydrationBoundary`.
* @param props - The dehydrated `state` to hydrate, the hydrate `options`, an optional custom
* `queryClient`, and the `children` to render.
* @returns The provided `children`, rendered unconditionally. New queries in `state` are hydrated into the
* cache during render; for queries already in the cache, only newer dehydrated data is hydrated, in an effect
* after commit.
* @example
* ```tsx
* import { HydrationBoundary } from '@tanstack/react-query'
*
* function App() {
*   return <HydrationBoundary state={dehydratedState}>...</HydrationBoundary>
* }
* ```
* @example
* Server-side prefetch handed off to the client via `dehydrate`:
* ```tsx
* import { HydrationBoundary, dehydrate, noop } from '@tanstack/react-query'
*
* async function ServerComponent() {
*   const queryClient = getQueryClient()
*
*   await queryClient
*     .query({
*       queryKey: ['posts'],
*       queryFn: fetchPosts,
*     })
*     .catch(noop)
*
*   return (
*     <HydrationBoundary state={dehydrate(queryClient)}>
*       <Posts />
*     </HydrationBoundary>
*   )
* }
* ```
*/
var HydrationBoundary = ({ children, options = {}, state, queryClient }) => {
	const client = useQueryClient(queryClient);
	const optionsRef = import_react.useRef(options);
	import_react.useEffect(() => {
		optionsRef.current = options;
	});
	const hydrationQueue = import_react.useMemo(() => {
		if (state) {
			if (typeof state !== "object") return;
			const queryCache = client.getQueryCache();
			const queries = state.queries || [];
			const newQueries = [];
			const existingQueries = [];
			for (const dehydratedQuery of queries) {
				const existingQuery = queryCache.get(dehydratedQuery.queryHash);
				if (!existingQuery) newQueries.push(dehydratedQuery);
				else if (dehydratedQuery.state.dataUpdatedAt > existingQuery.state.dataUpdatedAt || dehydratedQuery.promise && existingQuery.state.status !== "pending" && existingQuery.state.fetchStatus !== "fetching" && dehydratedQuery.dehydratedAt > existingQuery.state.dataUpdatedAt) existingQueries.push(dehydratedQuery);
			}
			if (newQueries.length > 0) hydrate(client, { queries: newQueries }, optionsRef.current);
			if (existingQueries.length > 0) return existingQueries;
		}
	}, [client, state]);
	import_react.useEffect(() => {
		if (hydrationQueue) hydrate(client, { queries: hydrationQueue }, optionsRef.current);
	}, [client, hydrationQueue]);
	return children;
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/IsRestoringProvider.js
var IsRestoringContext = import_react.createContext(false);
/**
* If you are using `PersistQueryClientProvider`, you can also use the `useIsRestoring` hook alongside it to
* check if a restore is currently in progress. `useQuery` and friends also check this internally to avoid
* race conditions between the restore and mounting queries.
* @returns `true` while a persisted client is being restored, `false` otherwise.
*/
var useIsRestoring = () => import_react.useContext(IsRestoringContext);
/**
* The Provider that `PersistQueryClientProvider` uses to signal whether a persisted client is currently
* being restored, read by `useIsRestoring`.
*/
var IsRestoringProvider = IsRestoringContext.Provider;
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js
/**
* Creates the value shared through the boundary's context, which tracks whether a reset was
* requested.
* @returns The `clearReset`, `isReset`, and `reset` functions of the boundary.
*/
function createValue() {
	let isReset = false;
	return {
		/**
		* Clears the reset state, so queries know not to try again until the boundary is reset again.
		*/
		clearReset: () => {
			isReset = false;
		},
		/**
		* Resets any query errors within the boundary, so queries know they can try again.
		*/
		reset: () => {
			isReset = true;
		},
		/**
		* Returns whether the boundary has been reset and not yet cleared.
		* @returns `true` if the boundary has been reset and not yet cleared.
		*/
		isReset: () => {
			return isReset;
		}
	};
}
var QueryErrorResetBoundaryContext = import_react.createContext(createValue());
/**
* This hook will reset any query errors within the closest `QueryErrorResetBoundary`. If there is no boundary
* defined it will reset them globally.
* @returns The boundary's {@link QueryErrorResetBoundaryValue}.
* @example
* ```tsx
* import { ErrorBoundary } from 'react-error-boundary'
* import { useQueryErrorResetBoundary } from '@tanstack/react-query'
*
* function App({ children }: { children: React.ReactNode }) {
*   const { reset } = useQueryErrorResetBoundary()
*
*   return (
*     <ErrorBoundary
*       onReset={reset}
*       fallbackRender={({ resetErrorBoundary }) => (
*         <div>
*           There was an error!
*           <button onClick={() => resetErrorBoundary()}>Try again</button>
*         </div>
*       )}
*     >
*       {children}
*     </ErrorBoundary>
*   )
* }
* ```
*/
var useQueryErrorResetBoundary = () => import_react.useContext(QueryErrorResetBoundaryContext);
/**
* When using `suspense` or `throwOnError` in your queries, you need a way to let queries know that you want to
* try again when re-rendering after some error occurred. With the `QueryErrorResetBoundary` component you can
* reset any query errors within the boundaries of the component.
* @param props - The `children` to render.
* @returns The `children`, rendered as-is, or called with the boundary's {@link QueryErrorResetBoundaryValue}
* if `children` is a function.
* @example
* ```tsx
* import { ErrorBoundary } from 'react-error-boundary'
* import { QueryErrorResetBoundary } from '@tanstack/react-query'
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Page />
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
var QueryErrorResetBoundary = ({ children }) => {
	const [value] = import_react.useState(() => createValue());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryErrorResetBoundaryContext.Provider, {
		value,
		children: typeof children === "function" ? children(value) : children
	});
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/errorBoundaryUtils.js
/**
* Turns off `retryOnMount` for a query that throws its errors (with `suspense` or `throwOnError`),
* unless the error boundary has been reset, so a remount doesn't retry the failed query before the
* user resets the boundary. Mutates the options.
* @param options - The defaulted query options to adjust.
* @param errorResetBoundary - The value of the nearest `QueryErrorResetBoundary`.
* @param query - The query, used to evaluate a `throwOnError` function against its error.
*/
var ensurePreventErrorBoundaryRetry = (options, errorResetBoundary, query) => {
	const throwOnError = query?.state.status === "error" && typeof options.throwOnError === "function" ? shouldThrowError(options.throwOnError, [query.state.error, query]) : options.throwOnError;
	if (options.suspense || throwOnError) {
		if (!errorResetBoundary.isReset()) options.retryOnMount = false;
	}
};
/**
* Clears the reset state of the error boundary after the component mounts, so later errors are
* thrown to the boundary again.
* @param errorResetBoundary - The value of the nearest `QueryErrorResetBoundary`.
*/
var useClearResetErrorBoundary = (errorResetBoundary) => {
	import_react.useEffect(() => {
		errorResetBoundary.clearReset();
	}, [errorResetBoundary]);
};
/**
* Checks whether the query error should be thrown to the nearest error boundary: the query errored
* and isn't fetching, the boundary hasn't been reset, and either `suspense` is enabled with no data
* or `throwOnError` says so.
* @param params - The observer `result`, the `errorResetBoundary`, the `throwOnError` option, the
* `query`, and the `suspense` option.
* @returns `true` if the error should be thrown.
*/
var getHasError = ({ result, errorResetBoundary, throwOnError, query, suspense }) => {
	return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError(throwOnError, [result.error, query]));
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/suspense.js
/**
* The default `throwOnError` of the suspense hooks: throws the error to the nearest error boundary
* only if the query has no data to show.
* @param _error - The error of the query. Unused.
* @param query - The query that errored.
* @returns `true` if the query has no data.
*/
var defaultThrowOnError = (_error, query) => query.state.data === void 0;
/**
* Raises `staleTime` and a numeric `gcTime` to at least 1000ms when `suspense` is enabled, so a
* component that remounts after suspending doesn't refetch right away or find the query garbage
* collected. A `'static'` `staleTime` is kept as is. Mutates the options.
* @param defaultedOptions - The defaulted query options to adjust.
*/
var ensureSuspenseTimers = (defaultedOptions) => {
	if (defaultedOptions.suspense) {
		const MIN_SUSPENSE_TIME_MS = 1e3;
		const clamp = (value) => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
		const originalStaleTime = defaultedOptions.staleTime;
		defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
		if (typeof defaultedOptions.gcTime === "number") defaultedOptions.gcTime = Math.max(defaultedOptions.gcTime, MIN_SUSPENSE_TIME_MS);
	}
};
/**
* Checks whether a query should suspend: `suspense` is enabled and the result is still `pending`.
* @param defaultedOptions - The defaulted query options, if any.
* @param result - The current result of the observer.
* @returns `true` if the component should suspend.
*/
var shouldSuspend = (defaultedOptions, result) => defaultedOptions?.suspense && result.isPending;
/**
* Fetches the query for a suspending component, without affecting the observer's own result. If
* the fetch fails, the reset state of the error boundary is cleared, so the error is thrown to it.
* @param defaultedOptions - The defaulted query options to fetch with.
* @param observer - The observer of the query.
* @param errorResetBoundary - The value of the nearest `QueryErrorResetBoundary`.
* @returns A promise that resolves once the fetch settles. It never rejects.
*/
var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
	errorResetBoundary.clearReset();
});
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useQueries.js
/**
* The `useQueries` hook can be used to fetch a variable number of queries.
*
* The `queries` key accepts an array with query option objects mostly identical to `useQuery` — the top-level
* `subscribed` option isn't accepted per query (see `placeholderData` below for another difference). A custom
* `QueryClient` is supplied once, as `useQueries`' own top-level second argument, rather than per query.
*
* Having the same query key more than once in the array of query objects may cause some data to be shared
* between queries. To avoid this, consider de-duplicating the queries and map the results back to the desired
* structure.
*
* The `combine` option can be used to combine the results of the queries into a single value. The result will
* be structurally shared to be as referentially stable as possible.
* @param options - The `queries` array to run, and the optional `combine` and `subscribed` options.
* @param queryClient - Use this to provide a custom `QueryClient`. Otherwise, the one from the nearest context
* will be used.
* @returns The combined result. Without `combine`, this is an array with all the query results, in the same
* order as the input. When `combine` is provided, this is the value returned by `combine` instead.
* @throws {Error} The error of the first query that should be thrown to the nearest error boundary (see
* `throwOnError`). While suspending, it throws a promise instead.
* @remarks The `combine` function only re-runs if it changed referentially, or if any of the query results
* changed. An inlined `combine` function, as shown in the example below, therefore runs on every render — wrap
* it in `useCallback`, or extract it to a stable function reference if it doesn't have any dependencies, to
* avoid that.
*
* Unlike `useQuery`, `useQueries` cannot infer the `data` argument of an _inline_ `select` from its sibling
* `queryFn`. Because `useQueries` infers the type of the whole `queries` array at once, the `select` parameter
* of a query object written inline cannot be contextually typed from that same object's `queryFn`, so it falls
* back to `unknown` — a [known TypeScript limitation](https://github.com/TanStack/query/issues/6556). Annotate
* the `select` parameter explicitly, or define the query with {@link queryOptions}, which resolves its types in
* a single object _before_ it reaches `useQueries`, to work around this — see the example below. The same
* limitation applies to {@link useSuspenseQueries}.
*
* `placeholderData` is supported here too, but unlike `useQuery`, it doesn't receive information from
* previously rendered queries, because the number of queries can differ between renders.
* @example
* ```tsx
* import { useQueries } from '@tanstack/react-query'
*
* function Posts({ ids }: { ids: Array<number> }) {
*   const postQueries = useQueries({
*     queries: ids.map((id) => ({
*       queryKey: ['post', id],
*       queryFn: () => fetchPost(id),
*       staleTime: Infinity,
*     })),
*   })
*
*   return (
*     <ul>
*       {postQueries.map((query, index) => {
*         if (query.isPending) return <li key={ids[index]}>Loading...</li>
*         if (query.isError) return <li key={ids[index]}>Error: {query.error.message}</li>
*         return <li key={ids[index]}>{query.data.title}</li>
*       })}
*     </ul>
*   )
* }
* ```
* @example
* Combining results into a single value:
* ```tsx
* import { useQueries } from '@tanstack/react-query'
*
* function Posts({ ids }: { ids: Array<number> }) {
*   const { data, isPending, isError } = useQueries({
*     queries: ids.map((id) => ({
*       queryKey: ['post', id],
*       queryFn: () => fetchPost(id),
*     })),
*     combine: (postQueries) => {
*       return {
*         data: postQueries.map((query) => query.data),
*         isPending: postQueries.some((query) => query.isPending),
*         isError: postQueries.some((query) => query.isError),
*       }
*     },
*   })
*
*   if (isPending) return 'Loading...'
*   if (isError) return 'Error loading posts'
*
*   return (
*     <ul>
*       {data.map((post) => (
*         <li key={post?.id}>{post?.title}</li>
*       ))}
*     </ul>
*   )
* }
* ```
* @example
* Typing `select` via {@link queryOptions}. Note that spreading a `queryOptions` result and overriding
* `select` inline still falls back to `unknown` — wrap the spread in `queryOptions` again so the override is
* resolved before it reaches `useQueries`:
* ```tsx
* import { queryOptions, useQueries } from '@tanstack/react-query'
*
* const postOptions = (id: number) =>
*   queryOptions({
*     queryKey: ['post', id],
*     queryFn: () => fetchPost(id),
*   })
*
* function PostTitle({ id }: { id: number }) {
*   const [{ data: broken }] = useQueries({
*     queries: [
*       {
*         ...postOptions(id),
*         // ❌ `data` is `unknown` here
*         select: (data) => data.title,
*       },
*     ],
*   })
*
*   const [{ data: fixed }] = useQueries({
*     queries: [
*       queryOptions({
*         ...postOptions(id),
*         // ✅ `data` is `Post`
*         select: (data) => data.title,
*       }),
*     ],
*   })
*
*   return <h1>{fixed}</h1>
* }
* ```
*/
function useQueries({ queries, ...options }, queryClient) {
	const client = useQueryClient(queryClient);
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const subscribed = options.subscribed !== false;
	const defaultedQueries = import_react.useMemo(() => queries.map((opts) => {
		const defaultedOptions = client.defaultQueryOptions(opts);
		defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
		return defaultedOptions;
	}), [
		queries,
		client,
		isRestoring,
		subscribed
	]);
	defaultedQueries.forEach((queryOptions) => {
		ensureSuspenseTimers(queryOptions);
		const query = client.getQueryCache().get(queryOptions.queryHash);
		ensurePreventErrorBoundaryRetry(queryOptions, errorResetBoundary, query);
	});
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new QueriesObserver(client, defaultedQueries, options));
	const [optimisticResult, getCombinedResult, trackResult] = observer.getOptimisticResult(defaultedQueries, options.combine);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	import_react.useEffect(() => {
		observer.setQueries(defaultedQueries, options);
	}, [
		defaultedQueries,
		options,
		observer
	]);
	const suspensePromises = optimisticResult.some((result, index) => shouldSuspend(defaultedQueries[index], result)) ? optimisticResult.flatMap((result, index) => {
		const opts = defaultedQueries[index];
		if (opts && shouldSuspend(opts, result)) return fetchOptimistic(opts, new QueryObserver(client, opts), errorResetBoundary);
		return [];
	}) : [];
	if (suspensePromises.length > 0) throw Promise.all(suspensePromises);
	const firstSingleResultWhichShouldThrow = optimisticResult.find((result, index) => {
		const query = defaultedQueries[index];
		return query && getHasError({
			result,
			errorResetBoundary,
			throwOnError: query.throwOnError,
			query: client.getQueryCache().get(query.queryHash),
			suspense: query.suspense
		});
	});
	if (firstSingleResultWhichShouldThrow) throw firstSingleResultWhichShouldThrow.error;
	return getCombinedResult(trackResult());
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useBaseQuery.js
/**
* Base implementation shared by `useQuery`, `useInfiniteQuery`, `useSuspenseQuery`, and
* `useSuspenseInfiniteQuery`.
* @param options - The options passed to the calling hook.
* @param Observer - The observer class from query-core (`QueryObserver` or
* `InfiniteQueryObserver`).
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest
* context will be used.
* @returns The query result, tracking which properties are read unless `notifyOnChangeProps` is
* set.
* @throws {Error} If `options` is not an object (outside production), or the query error when it should be
* thrown to the nearest error boundary (see `throwOnError`). While suspending, it throws a promise instead.
*/
function useBaseQuery(options, Observer, queryClient) {
	if (typeof options !== "object" || Array.isArray(options)) throw new Error("Bad argument type. Starting with v5, only the \"Object\" form is allowed when calling query related functions. Please use the error stack to find the culprit call. More info here: https://tanstack.com/query/latest/docs/react/guides/migrating-to-v5#supports-a-single-signature-one-object");
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const client = useQueryClient(queryClient);
	const defaultedOptions = client.defaultQueryOptions(options);
	const query = client.getQueryCache().get(defaultedOptions.queryHash);
	if (!defaultedOptions.queryFn) console.error(`[${defaultedOptions.queryHash}]: No queryFn was passed as an option, and no default queryFn was found. The queryFn parameter is only optional when using a default queryFn. More info here: https://tanstack.com/query/latest/docs/framework/react/guides/default-query-function`);
	const subscribed = options.subscribed !== false;
	defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
	ensureSuspenseTimers(defaultedOptions);
	ensurePreventErrorBoundaryRetry(defaultedOptions, errorResetBoundary, query);
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new Observer(client, defaultedOptions));
	const result = observer.getOptimisticResult(defaultedOptions);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => {
		const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop;
		observer.updateResult();
		return unsubscribe;
	}, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	import_react.useEffect(() => {
		observer.setOptions(defaultedOptions);
	}, [defaultedOptions, observer]);
	if (shouldSuspend(defaultedOptions, result)) throw fetchOptimistic(defaultedOptions, observer, errorResetBoundary);
	if (getHasError({
		result,
		errorResetBoundary,
		throwOnError: defaultedOptions.throwOnError,
		query,
		suspense: defaultedOptions.suspense
	})) throw result.error;
	return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useQuery.js
function useQuery(options, queryClient) {
	return useBaseQuery(options, QueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useSuspenseQuery.js
/**
* The options for `useSuspenseQuery` are the same as for `useQuery`, except for `throwOnError`, `enabled`, and
* `placeholderData` — and `queryFn` may not be `skipToken`, since Suspense hooks can't render a "disabled" state.
*
* Caveat: cancellation does not work.
* @param options - The {@link UseSuspenseQueryOptions} to use — the same options as `useQuery`, minus the ones listed above.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The same object as `useQuery`, except that `data` is guaranteed to be defined, `isPlaceholderData`
* is missing, and `status` is either `success` or `error` (with the derived flags set accordingly).
* @remarks Multiple `useSuspenseQuery` calls in the same component suspend serially, causing a request
* waterfall — each one blocks rendering until it resolves, so the next doesn't even start fetching until then.
* Use {@link useSuspenseQueries} instead when you have more than one suspenseful query in a component, so they
* fetch in parallel.
* @example
* The query error is thrown if the fetch fails and no cached data exists yet, so an error boundary is
* required around `<Suspense>`. A failed background refetch instead continues to render the cached data.
* Use {@link QueryErrorResetBoundary} to let the user retry after such an error:
* ```tsx
* import { Suspense } from 'react'
* import { ErrorBoundary } from 'react-error-boundary'
* import { QueryErrorResetBoundary, useSuspenseQuery } from '@tanstack/react-query'
*
* function Posts() {
*   // `data` is guaranteed to be defined here — no `isPending` check needed.
*   const { data, isFetching } = useSuspenseQuery({
*     queryKey: ['posts'],
*     queryFn: fetchPosts,
*   })
*
*   return (
*     <div>
*       <h1>Posts {isFetching ? '(refreshing...)' : null}</h1>
*       <ul>
*         {data.map((post) => (
*           <li key={post.id}>{post.title}</li>
*         ))}
*       </ul>
*     </div>
*   )
* }
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Suspense fallback={<h1>Loading posts...</h1>}>
*             <Posts />
*           </Suspense>
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
function useSuspenseQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError,
		placeholderData: void 0
	}, QueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useSuspenseInfiniteQuery.js
/**
* The options for `useSuspenseInfiniteQuery` are the same as for `useInfiniteQuery`, except for `throwOnError`,
* `enabled`, and `placeholderData`.
*
* Caveat: cancellation does not work.
* @param options - The {@link UseSuspenseInfiniteQueryOptions} to use — the same options as `useInfiniteQuery`, minus the ones listed above.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The same object as `useInfiniteQuery`, except that `data` is guaranteed to be defined,
* `isPlaceholderData` is missing, and `status` is either `success` or `error` (with the derived flags set
* accordingly).
* @remarks Multiple suspenseful query calls in the same component suspend serially, causing a request
* waterfall — each one blocks rendering until it resolves, so the next doesn't even start fetching until
* then. There's no way to parallelize multiple infinite queries under Suspense. Also keep in mind that
* imperative fetch calls, such as `fetchNextPage`, may interfere with the default refetch behavior,
* resulting in outdated data. Make sure to call these functions only in response to user actions, or add
* conditions like `hasNextPage && !isFetching`.
* @see {@link useInfiniteQuery} for the non-Suspense version of this hook.
* @example
* The query error is thrown if a fetch fails and no cached data exists yet, so an error boundary is
* required around `<Suspense>`. A failed background refetch instead continues to render the cached data.
* Use {@link QueryErrorResetBoundary} to let the user retry after such an error:
* ```tsx
* import { Suspense } from 'react'
* import { ErrorBoundary } from 'react-error-boundary'
* import {
*   QueryErrorResetBoundary,
*   useSuspenseInfiniteQuery,
* } from '@tanstack/react-query'
*
* function Projects() {
*   // `data` is guaranteed to be defined here — no `isPending` check needed.
*   const { data, fetchNextPage, hasNextPage, isFetching, isFetchingNextPage } =
*     useSuspenseInfiniteQuery({
*       queryKey: ['projects'],
*       queryFn: ({ pageParam }) => fetchProjects(pageParam),
*       initialPageParam: 0,
*       getNextPageParam: (lastPage) => lastPage.nextId,
*     })
*
*   return (
*     <div>
*       <ul>
*         {data.pages.map((page) =>
*           page.projects.map((project) => <li key={project.id}>{project.name}</li>),
*         )}
*       </ul>
*       <button
*         onClick={() => fetchNextPage()}
*         disabled={!hasNextPage || isFetching}
*       >
*         {isFetchingNextPage
*           ? 'Loading more...'
*           : hasNextPage
*             ? 'Load More'
*             : 'Nothing more to load'}
*       </button>
*     </div>
*   )
* }
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Suspense fallback={<h1>Loading projects...</h1>}>
*             <Projects />
*           </Suspense>
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
function useSuspenseInfiniteQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseInfiniteQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError,
		placeholderData: void 0
	}, InfiniteQueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useSuspenseQueries.js
function useSuspenseQueries(options, queryClient) {
	return useQueries({
		...options,
		queries: options.queries.map((query) => {
			if (query.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQueries");
			return {
				...query,
				suspense: true,
				throwOnError: defaultThrowOnError,
				enabled: true,
				placeholderData: void 0
			};
		})
	}, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/usePrefetchQuery.js
/**
* `usePrefetchQuery` does not return anything, it should be used just to fire a prefetch during render, before
* a suspense boundary that wraps a component that uses `useSuspenseQuery`. You can pass everything to
* `usePrefetchQuery` that you can pass to `queryClient.query`, though `queryKey` is always required, and
* `queryFn` is required unless a default query function has been defined.
*
* The prefetch is skipped if the query already has any cached state — including a `pending`/`error` state left
* over from a previous attempt — so calling this on every render is cheap and won't refetch data that's
* already there or already in flight.
* @param options - The {@link UsePrefetchQueryOptions} to use — everything you can pass to `queryClient.query`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @example
* ```tsx
* import { Suspense } from 'react'
* import { usePrefetchQuery } from '@tanstack/react-query'
*
* function App() {
*   // Fire the prefetch during render, before the suspense boundary below.
*   usePrefetchQuery({
*     queryKey: ['posts'],
*     queryFn: fetchPosts,
*   })
*
*   return (
*     <Suspense fallback={<h1>Loading posts...</h1>}>
*       <Posts />
*     </Suspense>
*   )
* }
* ```
*/
function usePrefetchQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.query(options).catch(noop);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/usePrefetchInfiniteQuery.js
/**
* `usePrefetchInfiniteQuery` does not return anything, it should be used just to fire a prefetch during render,
* before a suspense boundary that wraps a component that uses `useSuspenseInfiniteQuery`. You can pass
* everything to `usePrefetchInfiniteQuery` that you can pass to `queryClient.infiniteQuery`, though
* `queryKey`, `initialPageParam`, and `getNextPageParam` are always required, and `queryFn` is required unless
* a default query function has been defined.
*
* `getNextPageParam` receives both the last page of the infinite list of data and the full array of all pages,
* as well as pageParam information, and should return a single variable that will be passed to your query
* function as `context.pageParam`. Return `undefined` or `null` to indicate there is no next page available.
*
* The prefetch is skipped if the query already has any cached state — including a `pending`/`error` state left
* over from a previous attempt — so calling this on every render is cheap and won't refetch data that's
* already there or already in flight.
* @param options - The {@link UsePrefetchInfiniteQueryOptions} to use — everything you can pass to `queryClient.infiniteQuery`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @example
* ```tsx
* import { Suspense } from 'react'
* import { infiniteQueryOptions, usePrefetchInfiniteQuery } from '@tanstack/react-query'
*
* const projectsOptions = infiniteQueryOptions({
*   queryKey: ['projects'],
*   queryFn: ({ pageParam }) => fetchProjects(pageParam),
*   initialPageParam: 0,
*   getNextPageParam: (lastPage) => lastPage.nextId,
* })
*
* function App() {
*   // Fire the prefetch during render, before the suspense boundary below.
*   usePrefetchInfiniteQuery(projectsOptions)
*
*   return (
*     <Suspense fallback={<h1>Loading projects...</h1>}>
*       <Projects />
*     </Suspense>
*   )
* }
* ```
*/
function usePrefetchInfiniteQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.infiniteQuery(options).catch(noop);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/queryOptions.js
function queryOptions(options) {
	return options;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/infiniteQueryOptions.js
function infiniteQueryOptions(options) {
	return options;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useIsFetching.js
/**
* The `useIsFetching` hook returns the `number` of the queries that your application is loading or fetching in
* the background (useful for app-wide loading indicators).
* @param filters - The {@link QueryFilters} to narrow down the matched queries.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be the `number` of the queries that your application is currently loading or fetching in the
* background.
* @example
* ```tsx
* import { useIsFetching } from '@tanstack/react-query'
*
* function PostsFetchingIndicator() {
*   // How many queries matching the posts prefix are fetching?
*   const isFetchingPosts = useIsFetching({ queryKey: ['posts'] })
*
*   return isFetchingPosts ? <span>Refreshing posts...</span> : null
* }
* ```
* @example
* A global loading indicator for any query fetching in the background, not just the ones on screen:
* ```tsx
* import { useIsFetching } from '@tanstack/react-query'
*
* function GlobalLoadingIndicator() {
*   const isFetching = useIsFetching()
*
*   return isFetching ? (
*     <div>Queries are fetching in the background...</div>
*   ) : null
* }
* ```
*/
function useIsFetching(filters, queryClient) {
	const client = useQueryClient(queryClient);
	const queryCache = client.getQueryCache();
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => queryCache.subscribe(notifyManager.batchCalls(onStoreChange)), [queryCache]), () => client.isFetching(filters), () => client.isFetching(filters));
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useMutationState.js
/**
* The `useIsMutating` hook returns the `number` of mutations that your application currently has `pending`
* (useful for app-wide loading indicators).
* @param filters - The {@link MutationFilters} to narrow down the matched mutations.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be the `number` of the mutations that your application currently has `pending`.
* @example
* ```tsx
* import { useIsMutating } from '@tanstack/react-query'
*
* function PostsMutatingIndicator() {
*   // How many mutations matching the posts prefix are in progress?
*   const isMutatingPosts = useIsMutating({ mutationKey: ['posts'] })
*
*   return isMutatingPosts ? <span>Saving posts...</span> : null
* }
* ```
*/
function useIsMutating(filters, queryClient) {
	const client = useQueryClient(queryClient);
	return useMutationState({ filters: {
		...filters,
		status: "pending"
	} }, client).length;
}
/**
* Creates snapshot getters that share equal selected results across renders.
* A new getter is created on each render. Each getter caches its snapshot until the matching mutations
* or their states change.
* @returns A factory for snapshot getters with a shared result cache.
*/
function createSnapshotFactory() {
	let previousResult;
	return (mutationCache, options) => {
		let inputs = [];
		let snapshot;
		return () => {
			const mutations = mutationCache.findAll(options.filters);
			const nextInputs = mutations.flatMap((mutation) => [mutation, mutation.state]);
			if (!snapshot || nextInputs.length !== inputs.length || nextInputs.some((input, index) => !Object.is(input, inputs[index]))) {
				inputs = nextInputs;
				snapshot = replaceEqualDeep(previousResult, mutations.map((mutation) => options.select ? options.select(mutation) : mutation.state));
				previousResult = snapshot;
			}
			return snapshot;
		};
	};
}
/**
* `useMutationState` is a hook that gives you access to all mutations in the `MutationCache`. You can pass
* `filters` ({@link MutationFilters}) to narrow down your mutations, and `select` to transform the mutation
* state.
* @param options - The `filters` to narrow down matched mutations, and an optional `select` to transform the
* mutation state.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be an Array of whatever `select` returns for each matching mutation.
* @example
* Get all variables of all running mutations:
* ```tsx
* import { useMutationState } from '@tanstack/react-query'
*
* function PendingPosts() {
*   const pendingVariables = useMutationState({
*     filters: { status: 'pending' },
*     select: (mutation) => mutation.state.variables,
*   })
*
*   return <>{pendingVariables.length} posts saving...</>
* }
* ```
* @example
* Get all data for specific mutations via the `mutationKey`:
* ```tsx
* import { useMutation, useMutationState } from '@tanstack/react-query'
*
* const mutationKey = ['posts']
*
* function Posts() {
*   // Some mutation that we want to get the state for
*   const mutation = useMutation({
*     mutationKey,
*     mutationFn: createPosts,
*   })
*
*   const savedPosts = useMutationState({
*     // this mutation key needs to match the mutation key of the given mutation (see above)
*     filters: { mutationKey, status: 'success' },
*     select: (mutation) => mutation.state.data,
*   })
*
*   return (
*     <button onClick={() => mutation.mutate(['New Post'])}>
*       Create post ({savedPosts.length} saved so far)
*     </button>
*   )
* }
* ```
* @example
* Access the latest successful mutation data via the `mutationKey`. Each invocation of `mutate` adds a new
* entry to the mutation cache for `gcTime` milliseconds — with the `status: 'success'` filter below, check the
* last item that `useMutationState` returns to get the latest successful invocation:
* ```tsx
* import { useMutationState } from '@tanstack/react-query'
*
* function LatestPost() {
*   const savedPosts = useMutationState({
*     filters: { mutationKey: ['posts'], status: 'success' },
*     select: (mutation) => mutation.state.data,
*   })
*
*   const latestSavedPost = savedPosts[savedPosts.length - 1]
*
*   return <>{latestSavedPost ? 'Saved' : 'Nothing saved yet'}</>
* }
* ```
*/
function useMutationState(options = {}, queryClient) {
	const mutationCache = useQueryClient(queryClient).getMutationCache();
	const [createSnapshot] = import_react.useState(() => createSnapshotFactory());
	const getSnapshot = createSnapshot(mutationCache, options);
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => mutationCache.subscribe(notifyManager.batchCalls(onStoreChange)), [mutationCache]), getSnapshot, getSnapshot);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useMutation.js
/**
* Unlike queries, mutations are typically used to create/update/delete data or perform server side-effects.
* `useMutation` is the hook for that.
* @param options - The {@link UseMutationOptions} to use — everything you can pass to `useMutation`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns `mutate`/`mutateAsync` also accept per-call `onSuccess`/`onError`/`onSettled` callbacks as a second
* argument, useful for triggering call-site side effects (e.g. navigation) without coupling them to the shared
* mutation definition. Hook-level callbacks (passed to `options`) fire for every mutation; per-call callbacks
* fire only for the latest call you've made, and only while the component is still mounted — unmounting before
* the mutation settles removes the subscription and prevents them from firing.
* @throws {Error} The mutation error, when `throwOnError` is `true` or returns `true` for it, so that it is
* thrown to the nearest error boundary.
* @see {@link mutationOptions} to share these options across multiple `useMutation` call sites, or to look
* the mutation up elsewhere via its `mutationKey` (e.g. with `useMutationState`).
* @example
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   return (
*     <button
*       onClick={() =>
*         addMutation.mutate('Item', {
*           onError: (error) => console.error('Failed to add item:', error),
*         })
*       }
*     >
*       Add
*     </button>
*   )
* }
* ```
* @example
* Rendering the mutation's own state, rather than just firing it off:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   return (
*     <div>
*       {addMutation.isPending ? (
*         'Adding todo...'
*       ) : (
*         <>
*           {addMutation.isError ? (
*             <div>An error occurred: {addMutation.error.message}</div>
*           ) : null}
*           <button onClick={() => addMutation.mutate('Item')}>Add</button>
*         </>
*       )}
*     </div>
*   )
* }
* ```
* @example
* Optimistic update via `onMutate`, rolling back on `onError`:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onMutate: async (newTodo) => {
*       await queryClient.cancelQueries({ queryKey: ['todos'] })
*       const previousTodos = queryClient.getQueryData<Array<string>>(['todos'])
*
*       queryClient.setQueryData<Array<string>>(['todos'], (old) => [
*         ...(old ?? []),
*         newTodo,
*       ])
*
*       // Passed to `onError` as `onMutateResult` if the mutation fails.
*       return { previousTodos }
*     },
*     onError: (_err, _newTodo, onMutateResult) => {
*       queryClient.setQueryData(['todos'], onMutateResult?.previousTodos)
*     },
*     onSettled: () => {
*       queryClient.invalidateQueries({ queryKey: ['todos'] })
*     },
*   })
*
*   return (
*     <button onClick={() => addMutation.mutate('Item')}>Add</button>
*   )
* }
* ```
* @example
* Callbacks passed per call to `mutate` only fire for the last call — `mutateAsync` gives you a
* promise per call instead, so you can wait for all of them when they succeed:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodos() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   async function handleAddAll(todos: Array<string>) {
*     try {
*       await Promise.all(todos.map((todo) => addMutation.mutateAsync(todo)))
*     } catch (error) {
*       console.error('Failed to add todos:', error)
*     }
*   }
*
*   return (
*     <button onClick={() => handleAddAll(['Todo 1', 'Todo 2', 'Todo 3'])}>
*       Add all
*     </button>
*   )
* }
* ```
* @example
* If some of the mutations above can fail independently of the others, and you want to know which ones
* did — rather than losing that information the moment the first one rejects — swap `Promise.all` for
* `Promise.allSettled`:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodos() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   async function handleAddAll(todos: Array<string>) {
*     const addResults = await Promise.allSettled(
*       todos.map((todo) => addMutation.mutateAsync(todo)),
*     )
*
*     addResults.forEach((addResult, index) => {
*       if (addResult.status === 'rejected') {
*         console.error(`Failed to add "${todos[index]}":`, addResult.reason)
*       }
*     })
*   }
*
*   return (
*     <button onClick={() => handleAddAll(['Todo 1', 'Todo 2', 'Todo 3'])}>
*       Add all
*     </button>
*   )
* }
* ```
*/
function useMutation(options, queryClient) {
	const client = useQueryClient(queryClient);
	const [observer] = import_react.useState(() => new MutationObserver(client, options));
	import_react.useEffect(() => {
		observer.setOptions(options);
	}, [observer, options]);
	const result = import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => observer.subscribe(notifyManager.batchCalls(onStoreChange)), [observer]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	const mutate = import_react.useCallback((...args) => {
		observer.mutate(args[0], args[1]).catch(noop);
	}, [observer]);
	if (result.error && shouldThrowError(observer.options.throwOnError, [result.error])) throw result.error;
	return {
		...result,
		mutate,
		mutateAsync: result.mutate
	};
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/mutationOptions.js
function mutationOptions(options) {
	return options;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useInfiniteQuery.js
function useInfiniteQuery(options, queryClient) {
	return useBaseQuery(options, InfiniteQueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/index.js
/* istanbul ignore file */
//#endregion
export { CancelledError, HydrationBoundary, InfiniteQueryObserver, IsRestoringProvider, Mutation, MutationCache, MutationObserver, QueriesObserver, Query, QueryCache, QueryClient, QueryClientContext, QueryClientProvider, QueryErrorResetBoundary, QueryObserver, dataTagErrorSymbol, dataTagSymbol, defaultScheduler, defaultShouldDehydrateMutation, defaultShouldDehydrateQuery, dehydrate, dehydrateQuery, environmentManager, streamedQuery as experimental_streamedQuery, focusManager, hashKey, hydrate, infiniteQueryOptions, isCancelledError, isServer, keepPreviousData, matchMutation, matchQuery, mutationOptions, noop, notifyManager, onlineManager, partialMatchKey, queryOptions, replaceEqualDeep, shouldThrowError, skipToken, timeoutManager, unsetMarker, useInfiniteQuery, useIsFetching, useIsMutating, useIsRestoring, useMutation, useMutationState, usePrefetchInfiniteQuery, usePrefetchQuery, useQueries, useQuery, useQueryClient, useQueryErrorResetBoundary, useSuspenseInfiniteQuery, useSuspenseQueries, useSuspenseQuery };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHRhbnN0YWNrX3JlYWN0LXF1ZXJ5LmpzIiwibmFtZXMiOlsiaXNTZXJ2ZXIkMSIsImlzU2VydmVyIiwiaXNTZXJ2ZXIiLCJpc1NlcnZlciIsImdldERlZmF1bHRTdGF0ZSIsImlzU2VydmVyIl0sInNvdXJjZXMiOlsiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3RpbWVvdXRNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3V0aWxzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL2Vudmlyb25tZW50TWFuYWdlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9zdWJzY3JpYmFibGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vZm9jdXNNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL2h5ZHJhdGlvbi5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9ub3RpZnlNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL29ubGluZU1hbmFnZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcmV0cnllci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9yZW1vdmFibGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3F1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3F1ZXJ5T2JzZXJ2ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeU9ic2VydmVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL211dGF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL211dGF0aW9uQ2FjaGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vbXV0YXRpb25PYnNlcnZlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyaWVzT2JzZXJ2ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcXVlcnlDYWNoZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyeUNsaWVudC5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9zdHJlYW1lZFF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3R5cGVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9IeWRyYXRpb25Cb3VuZGFyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vSXNSZXN0b3JpbmdQcm92aWRlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL2Vycm9yQm91bmRhcnlVdGlscy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vc3VzcGVuc2UuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVF1ZXJpZXMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUJhc2VRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVN1c3BlbnNlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVN1c3BlbnNlSW5maW5pdGVRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlU3VzcGVuc2VRdWVyaWVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VQcmVmZXRjaFF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VQcmVmZXRjaEluZmluaXRlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3F1ZXJ5T3B0aW9ucy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeU9wdGlvbnMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUlzRmV0Y2hpbmcuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZU11dGF0aW9uU3RhdGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZU11dGF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9tdXRhdGlvbk9wdGlvbnMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUluZmluaXRlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvUXVlcnlDbGllbnRQcm92aWRlci50c3hcbi8qKlxuKiBUaGUgY29udGV4dCB0aGF0IGB1c2VRdWVyeUNsaWVudGAgcmVhZHMgZnJvbS4gYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgIGlzIHRoZSBub3JtYWwgd2F5IHRvIHNldCBpdC5cbiovXG5jb25zdCBRdWVyeUNsaWVudENvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KHZvaWQgMCk7XG4vKipcbiogVGhlIGB1c2VRdWVyeUNsaWVudGAgaG9vayByZXR1cm5zIHRoZSBjdXJyZW50IGBRdWVyeUNsaWVudGAgaW5zdGFuY2UuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgVGhlIGN1cnJlbnQgYFF1ZXJ5Q2xpZW50YCBpbnN0YW5jZS5cbiogQHRocm93cyB7RXJyb3J9IElmIG5vIGBxdWVyeUNsaWVudGAgYXJndW1lbnQgaXMgcGFzc2VkIGFuZCBubyBgUXVlcnlDbGllbnRQcm92aWRlcmAgaXMgZm91bmQgaW4gdGhlXG4qIGNvbXBvbmVudCB0cmVlLlxuKi9cbmNvbnN0IHVzZVF1ZXJ5Q2xpZW50ID0gKHF1ZXJ5Q2xpZW50KSA9PiB7XG5cdGNvbnN0IGNsaWVudCA9IFJlYWN0LnVzZUNvbnRleHQoUXVlcnlDbGllbnRDb250ZXh0KTtcblx0aWYgKHF1ZXJ5Q2xpZW50KSByZXR1cm4gcXVlcnlDbGllbnQ7XG5cdGlmICghY2xpZW50KSB0aHJvdyBuZXcgRXJyb3IoXCJObyBRdWVyeUNsaWVudCBzZXQsIHVzZSBRdWVyeUNsaWVudFByb3ZpZGVyIHRvIHNldCBvbmVcIik7XG5cdHJldHVybiBjbGllbnQ7XG59O1xuLyoqXG4qIFVzZSB0aGUgYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgIGNvbXBvbmVudCB0byBjb25uZWN0IGFuZCBwcm92aWRlIGEgYFF1ZXJ5Q2xpZW50YCB0byB5b3VyIGFwcGxpY2F0aW9uLiBBbHNvXG4qIGNhbGxzIGBjbGllbnQubW91bnQoKWAvYGNsaWVudC51bm1vdW50KClgIGFzIHRoaXMgY29tcG9uZW50IG1vdW50cy91bm1vdW50cywgd2hpY2ggc3Vic2NyaWJlcyB0aGUgY2xpZW50IHRvXG4qIGZvY3VzL29ubGluZSBldmVudHMgKHJlc3VtaW5nIGFueSBwYXVzZWQgbXV0YXRpb25zIGFuZCByZWZldGNoaW5nIGFzIG5lZWRlZCB3aGVuIHRoZSBhcHAgcmVnYWlucyBmb2N1cyBvclxuKiBjb21lcyBiYWNrIG9ubGluZSkuXG4qIEBwYXJhbSBwcm9wcyAtIFRoZSBgY2xpZW50YCB0byBwcm92aWRlLCBhbmQgdGhlIGBjaGlsZHJlbmAgdGhhdCBnZXQgYWNjZXNzIHRvIGl0LlxuKiBAcmV0dXJucyBUaGUgcHJvdmlkZWQgYGNoaWxkcmVuYCwgd3JhcHBlZCBzbyB0aGV5IGNhbiByZWFkIHRoZSBgUXVlcnlDbGllbnRgIHZpYSBgdXNlUXVlcnlDbGllbnRgLlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgUXVlcnlDbGllbnQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiA8UXVlcnlDbGllbnRQcm92aWRlciBjbGllbnQ9e3F1ZXJ5Q2xpZW50fT4uLi48L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+XG4qIH1cbiogYGBgXG4qL1xuY29uc3QgUXVlcnlDbGllbnRQcm92aWRlciA9ICh7IGNsaWVudCwgY2hpbGRyZW4gfSkgPT4ge1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGNsaWVudC5tb3VudCgpO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRjbGllbnQudW5tb3VudCgpO1xuXHRcdH07XG5cdH0sIFtjbGllbnRdKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUXVlcnlDbGllbnRDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0dmFsdWU6IGNsaWVudCxcblx0XHRjaGlsZHJlblxuXHR9KTtcbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFF1ZXJ5Q2xpZW50Q29udGV4dCwgUXVlcnlDbGllbnRQcm92aWRlciwgdXNlUXVlcnlDbGllbnQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9UXVlcnlDbGllbnRQcm92aWRlci5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3RpbWVvdXRNYW5hZ2VyLnRzXG5jb25zdCBkZWZhdWx0VGltZW91dFByb3ZpZGVyID0ge1xuXHRzZXRUaW1lb3V0OiAoY2FsbGJhY2ssIGRlbGF5KSA9PiBzZXRUaW1lb3V0KGNhbGxiYWNrLCBkZWxheSksXG5cdGNsZWFyVGltZW91dDogKHRpbWVvdXRJZCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCksXG5cdHNldEludGVydmFsOiAoY2FsbGJhY2ssIGRlbGF5KSA9PiBzZXRJbnRlcnZhbChjYWxsYmFjaywgZGVsYXkpLFxuXHRjbGVhckludGVydmFsOiAoaW50ZXJ2YWxJZCkgPT4gY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKVxufTtcbi8qKlxuKiBBbGxvd3MgY3VzdG9taXphdGlvbiBvZiBob3cgdGltZW91dHMgYXJlIGNyZWF0ZWQuXG4qXG4qIGBAdGFuc3RhY2svcXVlcnktY29yZWAgbWFrZXMgbGliZXJhbCB1c2Ugb2YgdGltZW91dHMgdG8gaW1wbGVtZW50IGBzdGFsZVRpbWVgXG4qIGFuZCBgZ2NUaW1lYC4gVGhlIGRlZmF1bHQgVGltZW91dE1hbmFnZXIgcHJvdmlkZXIgdXNlcyB0aGUgcGxhdGZvcm0ncyBnbG9iYWxcbiogYHNldFRpbWVvdXRgIGltcGxlbWVudGF0aW9uLCB3aGljaCBpcyBrbm93biB0byBoYXZlIHNjYWxhYmlsaXR5IGlzc3VlcyB3aXRoXG4qIHRob3VzYW5kcyBvZiB0aW1lb3V0cyBvbiB0aGUgZXZlbnQgbG9vcC5cbipcbiogSWYgeW91IGhpdCB0aGlzIGxpbWl0YXRpb24sIGNvbnNpZGVyIHByb3ZpZGluZyBhIGN1c3RvbSBUaW1lb3V0UHJvdmlkZXIgdGhhdFxuKiBjb2FsZXNjZXMgdGltZW91dHMuXG4qL1xudmFyIFRpbWVvdXRNYW5hZ2VyID0gY2xhc3Mge1xuXHQjcHJvdmlkZXIgPSBkZWZhdWx0VGltZW91dFByb3ZpZGVyO1xuXHQjcHJvdmlkZXJDYWxsZWQgPSBmYWxzZTtcblx0LyoqXG5cdCogYHNldFRpbWVvdXRQcm92aWRlcmAgY2FuIGJlIHVzZWQgdG8gc2V0IGEgY3VzdG9tIGltcGxlbWVudGF0aW9uIG9mIHRoZVxuXHQqIGBzZXRUaW1lb3V0YCwgYGNsZWFyVGltZW91dGAsIGBzZXRJbnRlcnZhbGAsIGBjbGVhckludGVydmFsYCBmdW5jdGlvbnMsXG5cdCogY2FsbGVkIGEgYFRpbWVvdXRQcm92aWRlcmAuXG5cdCpcblx0KiBUaGlzIG1heSBiZSB1c2VmdWwgaWYgeW91IG5vdGljZSBldmVudCBsb29wIHBlcmZvcm1hbmNlIGlzc3VlcyB3aXRoXG5cdCogdGhvdXNhbmRzIG9mIHF1ZXJpZXMuIEEgY3VzdG9tIFRpbWVvdXRQcm92aWRlciBjb3VsZCBhbHNvIHN1cHBvcnQgdGltZXJcblx0KiBkZWxheXMgbG9uZ2VyIHRoYW4gdGhlIGdsb2JhbCBgc2V0VGltZW91dGAgbWF4aW11bSBkZWxheSB2YWx1ZSBvZiBhYm91dFxuXHQqIDI0IGRheXMuXG5cdCpcblx0KiBJdCBpcyBpbXBvcnRhbnQgdG8gY2FsbCBgc2V0VGltZW91dFByb3ZpZGVyYCBiZWZvcmUgY3JlYXRpbmcgYVxuXHQqIFF1ZXJ5Q2xpZW50IG9yIHF1ZXJpZXMsIHNvIHRoYXQgdGhlIHNhbWUgcHJvdmlkZXIgaXMgdXNlZCBjb25zaXN0ZW50bHlcblx0KiBmb3IgYWxsIHRpbWVycyBpbiB0aGUgYXBwbGljYXRpb24sIHNpbmNlIGRpZmZlcmVudCBUaW1lb3V0UHJvdmlkZXJzXG5cdCogY2Fubm90IGNhbmNlbCBlYWNoIG90aGVycycgdGltZXJzLlxuXHQqIEBwYXJhbSBwcm92aWRlciAtIFRoZSBgVGltZW91dFByb3ZpZGVyYCB0byB1c2UgZm9yIGFsbCB0aW1lcnMgZnJvbSBub3cgb24uXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyLCBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqIGltcG9ydCB7IEN1c3RvbVRpbWVvdXRQcm92aWRlciB9IGZyb20gJy4vQ3VzdG9tVGltZW91dFByb3ZpZGVyJ1xuXHQqXG5cdCogdGltZW91dE1hbmFnZXIuc2V0VGltZW91dFByb3ZpZGVyKG5ldyBDdXN0b21UaW1lb3V0UHJvdmlkZXIoKSlcblx0KlxuXHQqIGV4cG9ydCBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG5cdCogYGBgXG5cdCovXG5cdHNldFRpbWVvdXRQcm92aWRlcihwcm92aWRlcikge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdGlmICh0aGlzLiNwcm92aWRlckNhbGxlZCAmJiBwcm92aWRlciAhPT0gdGhpcy4jcHJvdmlkZXIpIGNvbnNvbGUuZXJyb3IoYFt0aW1lb3V0TWFuYWdlcl06IFN3aXRjaGluZyBwcm92aWRlciBhZnRlciBjYWxscyB0byBwcmV2aW91cyBwcm92aWRlciBtaWdodCByZXN1bHQgaW4gdW5leHBlY3RlZCBiZWhhdmlvci5gLCB7XG5cdFx0XHRcdHByZXZpb3VzOiB0aGlzLiNwcm92aWRlcixcblx0XHRcdFx0cHJvdmlkZXJcblx0XHRcdH0pO1xuXHRcdH1cblx0XHR0aGlzLiNwcm92aWRlciA9IHByb3ZpZGVyO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHRoaXMuI3Byb3ZpZGVyQ2FsbGVkID0gZmFsc2U7XG5cdH1cblx0LyoqXG5cdCogYHNldFRpbWVvdXRgIHNjaGVkdWxlcyBhIGNhbGxiYWNrIHRvIHJ1biBhZnRlciBhcHByb3hpbWF0ZWx5IGBkZWxheWBcblx0KiBtaWxsaXNlY29uZHMsIGxpa2UgdGhlIGdsb2JhbCBgc2V0VGltZW91dGAgZnVuY3Rpb24uIFRoZSBjYWxsYmFjayBjYW4gYmVcblx0KiBjYW5jZWxlZCB3aXRoIGBjbGVhclRpbWVvdXRgLlxuXHQqXG5cdCogSXQgcmV0dXJucyBhIHRpbWVyIElELCB3aGljaCBtYXkgYmUgYSBudW1iZXIgb3IgYW4gb2JqZWN0IHRoYXQgY2FuIGJlXG5cdCogY29lcmNlZCB0byBhIG51bWJlciB2aWEgYFN5bWJvbC50b1ByaW1pdGl2ZWAuXG5cdCogQHBhcmFtIGNhbGxiYWNrIC0gVGhlIGZ1bmN0aW9uIHRvIGNhbGwgd2hlbiB0aGUgdGltZW91dCBlbGFwc2VzLlxuXHQqIEBwYXJhbSBkZWxheSAtIFRoZSB0aW1lIHRvIHdhaXQgYmVmb3JlIGNhbGxpbmcgYGNhbGxiYWNrYCwgaW4gbWlsbGlzZWNvbmRzLlxuXHQqIEByZXR1cm5zIFRoZSB0aW1lciBJRCwgdG8gcGFzcyB0byB7QGxpbmsgVGltZW91dE1hbmFnZXIjY2xlYXJUaW1lb3V0fS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgdGltZW91dE1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIGNvbnN0IHRpbWVvdXRJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldFRpbWVvdXQoXG5cdCogICAoKSA9PiBjb25zb2xlLmxvZygncmFuIGF0OicsIG5ldyBEYXRlKCkpLFxuXHQqICAgMTAwMCxcblx0KiApXG5cdCpcblx0KiBjb25zdCB0aW1lb3V0SWROdW1iZXI6IG51bWJlciA9IE51bWJlcih0aW1lb3V0SWQpXG5cdCogYGBgXG5cdCovXG5cdHNldFRpbWVvdXQoY2FsbGJhY2ssIGRlbGF5KSB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgdGhpcy4jcHJvdmlkZXJDYWxsZWQgPSB0cnVlO1xuXHRcdHJldHVybiB0aGlzLiNwcm92aWRlci5zZXRUaW1lb3V0KGNhbGxiYWNrLCBkZWxheSk7XG5cdH1cblx0LyoqXG5cdCogYGNsZWFyVGltZW91dGAgY2FuY2VscyBhIHRpbWVvdXQgY2FsbGJhY2sgc2NoZWR1bGVkIHdpdGggYHNldFRpbWVvdXRgLFxuXHQqIGxpa2UgdGhlIGdsb2JhbCBgY2xlYXJUaW1lb3V0YCBmdW5jdGlvbi4gSXQgc2hvdWxkIGJlIGNhbGxlZCB3aXRoIGFcblx0KiB0aW1lciBJRCByZXR1cm5lZCBieSBgc2V0VGltZW91dGAuXG5cdCogQHBhcmFtIHRpbWVvdXRJZCAtIFRoZSB0aW1lciBJRCByZXR1cm5lZCBieSBgc2V0VGltZW91dGAsIG9yIGB1bmRlZmluZWRgLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgdGltZW91dElkID0gdGltZW91dE1hbmFnZXIuc2V0VGltZW91dChcblx0KiAgICgpID0+IGNvbnNvbGUubG9nKCdyYW4gYXQ6JywgbmV3IERhdGUoKSksXG5cdCogICAxMDAwLFxuXHQqIClcblx0KlxuXHQqIHRpbWVvdXRNYW5hZ2VyLmNsZWFyVGltZW91dCh0aW1lb3V0SWQpXG5cdCogYGBgXG5cdCovXG5cdGNsZWFyVGltZW91dCh0aW1lb3V0SWQpIHtcblx0XHR0aGlzLiNwcm92aWRlci5jbGVhclRpbWVvdXQodGltZW91dElkKTtcblx0fVxuXHQvKipcblx0KiBgc2V0SW50ZXJ2YWxgIHNjaGVkdWxlcyBhIGNhbGxiYWNrIHRvIGJlIGNhbGxlZCBhcHByb3hpbWF0ZWx5IGV2ZXJ5XG5cdCogYGRlbGF5YCBtaWxsaXNlY29uZHMsIGxpa2UgdGhlIGdsb2JhbCBgc2V0SW50ZXJ2YWxgIGZ1bmN0aW9uLlxuXHQqXG5cdCogTGlrZSBgc2V0VGltZW91dGAsIGl0IHJldHVybnMgYSB0aW1lciBJRCwgd2hpY2ggbWF5IGJlIGEgbnVtYmVyIG9yIGFuXG5cdCogb2JqZWN0IHRoYXQgY2FuIGJlIGNvZXJjZWQgdG8gYSBudW1iZXIgdmlhIGBTeW1ib2wudG9QcmltaXRpdmVgLlxuXHQqIEBwYXJhbSBjYWxsYmFjayAtIFRoZSBmdW5jdGlvbiB0byBjYWxsIG9uIGV2ZXJ5IGludGVydmFsLlxuXHQqIEBwYXJhbSBkZWxheSAtIFRoZSB0aW1lIGJldHdlZW4gY2FsbHMsIGluIG1pbGxpc2Vjb25kcy5cblx0KiBAcmV0dXJucyBUaGUgdGltZXIgSUQsIHRvIHBhc3MgdG8ge0BsaW5rIFRpbWVvdXRNYW5hZ2VyI2NsZWFySW50ZXJ2YWx9LlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgaW50ZXJ2YWxJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldEludGVydmFsKFxuXHQqICAgKCkgPT4gY29uc29sZS5sb2coJ3JhbiBhdDonLCBuZXcgRGF0ZSgpKSxcblx0KiAgIDEwMDAsXG5cdCogKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRJbnRlcnZhbChjYWxsYmFjaywgZGVsYXkpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0aGlzLiNwcm92aWRlckNhbGxlZCA9IHRydWU7XG5cdFx0cmV0dXJuIHRoaXMuI3Byb3ZpZGVyLnNldEludGVydmFsKGNhbGxiYWNrLCBkZWxheSk7XG5cdH1cblx0LyoqXG5cdCogYGNsZWFySW50ZXJ2YWxgIGNhbiBiZSB1c2VkIHRvIGNhbmNlbCBhbiBpbnRlcnZhbCwgbGlrZSB0aGUgZ2xvYmFsXG5cdCogYGNsZWFySW50ZXJ2YWxgIGZ1bmN0aW9uLiBJdCBzaG91bGQgYmUgY2FsbGVkIHdpdGggYW4gaW50ZXJ2YWwgSURcblx0KiByZXR1cm5lZCBieSBgc2V0SW50ZXJ2YWxgLlxuXHQqIEBwYXJhbSBpbnRlcnZhbElkIC0gVGhlIHRpbWVyIElEIHJldHVybmVkIGJ5IGBzZXRJbnRlcnZhbGAsIG9yIGB1bmRlZmluZWRgLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgaW50ZXJ2YWxJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldEludGVydmFsKFxuXHQqICAgKCkgPT4gY29uc29sZS5sb2coJ3JhbiBhdDonLCBuZXcgRGF0ZSgpKSxcblx0KiAgIDEwMDAsXG5cdCogKVxuXHQqXG5cdCogdGltZW91dE1hbmFnZXIuY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKVxuXHQqIGBgYFxuXHQqL1xuXHRjbGVhckludGVydmFsKGludGVydmFsSWQpIHtcblx0XHR0aGlzLiNwcm92aWRlci5jbGVhckludGVydmFsKGludGVydmFsSWQpO1xuXHR9XG59O1xuLyoqXG4qIFNpbmdsZXRvbiBpbnN0YW5jZSBvZiB7QGxpbmsgVGltZW91dE1hbmFnZXJ9LCB1c2VkIHRocm91Z2hvdXQgVGFuU3RhY2sgUXVlcnkgdG8gc2NoZWR1bGUgYW5kIGNhbmNlbCB0aW1lcnMuXG4qL1xuY29uc3QgdGltZW91dE1hbmFnZXIgPSBuZXcgVGltZW91dE1hbmFnZXIoKTtcbi8qKlxuKiBJbiBtYW55IGNhc2VzIGNvZGUgd2FudHMgdG8gZGVsYXkgdG8gdGhlIG5leHQgZXZlbnQgbG9vcCB0aWNrOyB0aGlzIGlzIG5vdFxuKiBtZWRpYXRlZCBieSB7QGxpbmsgdGltZW91dE1hbmFnZXJ9LlxuKlxuKiBUaGlzIGZ1bmN0aW9uIGlzIHByb3ZpZGVkIHRvIG1ha2UgYXVkaXRpbmcgdGhlIGB0YW5zdGFjay9xdWVyeS1jb3JlYCBmb3JcbiogaW5jb3JyZWN0IHVzZSBvZiBzeXN0ZW0gYHNldFRpbWVvdXRgIGVhc2llci5cbiogQHBhcmFtIGNhbGxiYWNrIC0gVGhlIGZ1bmN0aW9uIHRvIGNhbGwgb24gdGhlIG5leHQgZXZlbnQgbG9vcCB0aWNrLlxuKi9cbmZ1bmN0aW9uIHN5c3RlbVNldFRpbWVvdXRaZXJvKGNhbGxiYWNrKSB7XG5cdHNldFRpbWVvdXQoY2FsbGJhY2ssIDApO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBUaW1lb3V0TWFuYWdlciwgZGVmYXVsdFRpbWVvdXRQcm92aWRlciwgc3lzdGVtU2V0VGltZW91dFplcm8sIHRpbWVvdXRNYW5hZ2VyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXRpbWVvdXRNYW5hZ2VyLmpzLm1hcCIsImltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSBcIi4vdGltZW91dE1hbmFnZXIuanNcIjtcbi8vI3JlZ2lvbiBzcmMvdXRpbHMudHNcbi8qKlxuKiBAZGVwcmVjYXRlZCB1c2UgYGVudmlyb25tZW50TWFuYWdlci5pc1NlcnZlcigpYCBpbnN0ZWFkLlxuKi9cbmNvbnN0IGlzU2VydmVyID0gdHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIiB8fCBcIkRlbm9cIiBpbiBnbG9iYWxUaGlzO1xuZnVuY3Rpb24gbm9vcCgpIHt9XG4vKipcbiogUmVzb2x2ZXMgYW4ge0BsaW5rIFVwZGF0ZXJ9OiBjYWxscyBpdCB3aXRoIGBpbnB1dGAgaWYgaXQgaXMgYSBmdW5jdGlvbiwgb3RoZXJ3aXNlIHJldHVybnMgaXQgYXNcbiogaXMuXG4qIEBwYXJhbSB1cGRhdGVyIC0gVGhlIG5ldyB2YWx1ZSwgb3IgYSBmdW5jdGlvbiB0aGF0IHJlY2VpdmVzIGBpbnB1dGAgYW5kIHJldHVybnMgdGhlIG5ldyB2YWx1ZS5cbiogQHBhcmFtIGlucHV0IC0gVGhlIGN1cnJlbnQgdmFsdWUsIHBhc3NlZCB0byBgdXBkYXRlcmAgaWYgaXQgaXMgYSBmdW5jdGlvbi5cbiogQHJldHVybnMgVGhlIG5ldyB2YWx1ZS5cbiovXG5mdW5jdGlvbiBmdW5jdGlvbmFsVXBkYXRlKHVwZGF0ZXIsIGlucHV0KSB7XG5cdHJldHVybiB0eXBlb2YgdXBkYXRlciA9PT0gXCJmdW5jdGlvblwiID8gdXBkYXRlcihpbnB1dCkgOiB1cGRhdGVyO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgdmFsdWUgY2FuIGJlIHVzZWQgYXMgYSB0aW1lb3V0OiBhIG5vbi1uZWdhdGl2ZSwgZmluaXRlIG51bWJlci5cbiogQHBhcmFtIHZhbHVlIC0gVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhIG51bWJlciB0aGF0IGlzIGA+PSAwYCBhbmQgbm90IGBJbmZpbml0eWAuXG4qL1xuZnVuY3Rpb24gaXNWYWxpZFRpbWVvdXQodmFsdWUpIHtcblx0cmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIiAmJiB2YWx1ZSA+PSAwICYmIHZhbHVlICE9PSBJbmZpbml0eTtcbn1cbi8qKlxuKiBDYWxjdWxhdGVzIGhvdyBsb25nIHVudGlsIGRhdGEgdXBkYXRlZCBhdCBgdXBkYXRlZEF0YCBiZWNvbWVzIHN0YWxlLlxuKiBAcGFyYW0gdXBkYXRlZEF0IC0gVGhlIHRpbWVzdGFtcCwgaW4gbWlsbGlzZWNvbmRzLCBhdCB3aGljaCB0aGUgZGF0YSB3YXMgbGFzdCB1cGRhdGVkLlxuKiBAcGFyYW0gc3RhbGVUaW1lIC0gVGhlIHRpbWUsIGluIG1pbGxpc2Vjb25kcywgYWZ0ZXIgd2hpY2ggZGF0YSBpcyBjb25zaWRlcmVkIHN0YWxlLiBEZWZhdWx0cyB0b1xuKiBgMGAuXG4qIEByZXR1cm5zIFRoZSByZW1haW5pbmcgdGltZSBpbiBtaWxsaXNlY29uZHMsIG9yIGAwYCBpZiB0aGUgZGF0YSBpcyBhbHJlYWR5IHN0YWxlLlxuKi9cbmZ1bmN0aW9uIHRpbWVVbnRpbFN0YWxlKHVwZGF0ZWRBdCwgc3RhbGVUaW1lKSB7XG5cdHJldHVybiBNYXRoLm1heCh1cGRhdGVkQXQgKyAoc3RhbGVUaW1lIHx8IDApIC0gRGF0ZS5ub3coKSwgMCk7XG59XG4vKipcbiogUmVzb2x2ZXMgYW4gb3B0aW9uIHRoYXQgY2FuIGJlIGdpdmVuIGVpdGhlciBhcyBhIHZhbHVlIG9yIGFzIGEgZnVuY3Rpb24gb2YgdGhlIHF1ZXJ5LCBzdWNoIGFzXG4qIGBzdGFsZVRpbWVgLlxuKiBAcGFyYW0gdmFsdWUgLSBUaGUgb3B0aW9uIHZhbHVlLCBvciBhIGZ1bmN0aW9uIHRoYXQgcmVjZWl2ZXMgYHF1ZXJ5YCBhbmQgcmV0dXJucyB0aGUgdmFsdWUuXG4qIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSBwYXNzZWQgdG8gYHZhbHVlYCBpZiBpdCBpcyBhIGZ1bmN0aW9uLlxuKiBAcmV0dXJucyBUaGUgcmVzb2x2ZWQgdmFsdWUsIG9yIGB1bmRlZmluZWRgIGlmIGB2YWx1ZWAgaXMgYHVuZGVmaW5lZGAuXG4qL1xuZnVuY3Rpb24gcmVzb2x2ZVF1ZXJ5VmFsdWUodmFsdWUsIHF1ZXJ5KSB7XG5cdHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIiA/IHZhbHVlKHF1ZXJ5KSA6IHZhbHVlO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgcXVlcnkgbWF0Y2hlcyB0aGUgZ2l2ZW4ge0BsaW5rIFF1ZXJ5RmlsdGVyc30uXG4qIEV2ZXJ5IGZpbHRlciB0aGF0IGlzIHNwZWNpZmllZCBtdXN0IG1hdGNoOyBmaWx0ZXJzIHRoYXQgYXJlIGxlZnQgdW5zcGVjaWZpZWQgYXJlIGlnbm9yZWQuXG4qIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdG8gY2hlY2sgdGhlIHF1ZXJ5IGFnYWluc3QuXG4qIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSB0byBjaGVjay5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBtYXRjaGVzIGV2ZXJ5IHNwZWNpZmllZCBmaWx0ZXIuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcbipcbiogY29uc3QgbWF0Y2hpbmdRdWVyaWVzID0gcXVlcnlDYWNoZVxuKiAgIC5nZXRBbGwoKVxuKiAgIC5maWx0ZXIoKHF1ZXJ5KSA9PiBtYXRjaFF1ZXJ5KHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9LCBxdWVyeSkpXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIG1hdGNoUXVlcnkoZmlsdGVycywgcXVlcnkpIHtcblx0Y29uc3QgeyB0eXBlID0gXCJhbGxcIiwgZXhhY3QsIGZldGNoU3RhdHVzLCBwcmVkaWNhdGUsIHF1ZXJ5S2V5LCBzdGFsZSB9ID0gZmlsdGVycztcblx0aWYgKHF1ZXJ5S2V5KSB7XG5cdFx0aWYgKGV4YWN0KSB7XG5cdFx0XHRpZiAocXVlcnkucXVlcnlIYXNoICE9PSBoYXNoUXVlcnlLZXlCeU9wdGlvbnMocXVlcnlLZXksIHF1ZXJ5Lm9wdGlvbnMpKSByZXR1cm4gZmFsc2U7XG5cdFx0fSBlbHNlIGlmICghcGFydGlhbE1hdGNoS2V5KHF1ZXJ5LnF1ZXJ5S2V5LCBxdWVyeUtleSkpIHJldHVybiBmYWxzZTtcblx0fVxuXHRpZiAodHlwZSAhPT0gXCJhbGxcIikge1xuXHRcdGNvbnN0IGlzQWN0aXZlID0gcXVlcnkuaXNBY3RpdmUoKTtcblx0XHRpZiAodHlwZSA9PT0gXCJhY3RpdmVcIiAmJiAhaXNBY3RpdmUpIHJldHVybiBmYWxzZTtcblx0XHRpZiAodHlwZSA9PT0gXCJpbmFjdGl2ZVwiICYmIGlzQWN0aXZlKSByZXR1cm4gZmFsc2U7XG5cdH1cblx0aWYgKHR5cGVvZiBzdGFsZSA9PT0gXCJib29sZWFuXCIgJiYgcXVlcnkuaXNTdGFsZSgpICE9PSBzdGFsZSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAoZmV0Y2hTdGF0dXMgJiYgZmV0Y2hTdGF0dXMgIT09IHF1ZXJ5LnN0YXRlLmZldGNoU3RhdHVzKSByZXR1cm4gZmFsc2U7XG5cdGlmIChwcmVkaWNhdGUgJiYgIXByZWRpY2F0ZShxdWVyeSkpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIHRydWU7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBtdXRhdGlvbiBtYXRjaGVzIHRoZSBnaXZlbiB7QGxpbmsgTXV0YXRpb25GaWx0ZXJzfS5cbiogRXZlcnkgZmlsdGVyIHRoYXQgaXMgc3BlY2lmaWVkIG11c3QgbWF0Y2g7IGZpbHRlcnMgdGhhdCBhcmUgbGVmdCB1bnNwZWNpZmllZCBhcmUgaWdub3JlZC5cbiogSWYgYSBgbXV0YXRpb25LZXlgIGZpbHRlciBpcyBwcm92aWRlZCBidXQgdGhlIG11dGF0aW9uIGhhcyBubyBgbXV0YXRpb25LZXlgIG9mIGl0cyBvd24sIGl0IGRvZXMgbm90IG1hdGNoLlxuKiBAcGFyYW0gZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRvIGNoZWNrIHRoZSBtdXRhdGlvbiBhZ2FpbnN0LlxuKiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdG8gY2hlY2suXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgbXV0YXRpb24gbWF0Y2hlcyBldmVyeSBzcGVjaWZpZWQgZmlsdGVyLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBtdXRhdGlvbkNhY2hlID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpXG4qXG4qIGNvbnN0IG1hdGNoaW5nTXV0YXRpb25zID0gbXV0YXRpb25DYWNoZVxuKiAgIC5nZXRBbGwoKVxuKiAgIC5maWx0ZXIoKG11dGF0aW9uKSA9PiBtYXRjaE11dGF0aW9uKHsgbXV0YXRpb25LZXk6IFsnYWRkUG9zdCddIH0sIG11dGF0aW9uKSlcbiogYGBgXG4qL1xuZnVuY3Rpb24gbWF0Y2hNdXRhdGlvbihmaWx0ZXJzLCBtdXRhdGlvbikge1xuXHRjb25zdCB7IGV4YWN0LCBzdGF0dXMsIHByZWRpY2F0ZSwgbXV0YXRpb25LZXkgfSA9IGZpbHRlcnM7XG5cdGlmIChtdXRhdGlvbktleSkge1xuXHRcdGlmICghbXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSkgcmV0dXJuIGZhbHNlO1xuXHRcdGlmIChleGFjdCkge1xuXHRcdFx0aWYgKGhhc2hLZXkobXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSkgIT09IGhhc2hLZXkobXV0YXRpb25LZXkpKSByZXR1cm4gZmFsc2U7XG5cdFx0fSBlbHNlIGlmICghcGFydGlhbE1hdGNoS2V5KG11dGF0aW9uLm9wdGlvbnMubXV0YXRpb25LZXksIG11dGF0aW9uS2V5KSkgcmV0dXJuIGZhbHNlO1xuXHR9XG5cdGlmIChzdGF0dXMgJiYgbXV0YXRpb24uc3RhdGUuc3RhdHVzICE9PSBzdGF0dXMpIHJldHVybiBmYWxzZTtcblx0aWYgKHByZWRpY2F0ZSAmJiAhcHJlZGljYXRlKG11dGF0aW9uKSkgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbi8qKlxuKiBIYXNoZXMgYSBxdWVyeSBrZXkgd2l0aCB0aGUgcXVlcnkncyBgcXVlcnlLZXlIYXNoRm5gIG9wdGlvbiwgZmFsbGluZyBiYWNrIHRvIHtAbGluayBoYXNoS2V5fS5cbiogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSB0byBoYXNoLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBxdWVyeSBvcHRpb25zIHRoYXQgbWF5IHByb3ZpZGUgYSBjdXN0b20gYHF1ZXJ5S2V5SGFzaEZuYC5cbiogQHJldHVybnMgVGhlIHF1ZXJ5IGhhc2gsIGEgc3RyaW5nIHRoYXQgaWRlbnRpZmllcyB0aGUgcXVlcnkgaW4gdGhlIGNhY2hlLlxuKi9cbmZ1bmN0aW9uIGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhxdWVyeUtleSwgb3B0aW9ucykge1xuXHRyZXR1cm4gKG9wdGlvbnM/LnF1ZXJ5S2V5SGFzaEZuIHx8IGhhc2hLZXkpKHF1ZXJ5S2V5KTtcbn1cbi8qKlxuKiBEZWZhdWx0IHF1ZXJ5ICYgbXV0YXRpb24ga2V5cyBoYXNoIGZ1bmN0aW9uLlxuKiBIYXNoZXMgdGhlIHZhbHVlIGludG8gYSBzdGFibGUgaGFzaC5cbiogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IG9yIG11dGF0aW9uIGtleSB0byBoYXNoLlxuKiBAcmV0dXJucyBUaGUgc3RhYmxlIGhhc2ggb2YgdGhlIGtleSwgYXMgYSBKU09OIHN0cmluZy5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogLy8gT2JqZWN0IGtleXMgYXJlIHNvcnRlZCwgc28ga2V5IG9yZGVyIGRvZXNuJ3QgYWZmZWN0IHRoZSBoYXNoOlxuKiBoYXNoS2V5KFsndG9kb3MnLCB7IHBhZ2U6IDEsIGZpbHRlcjogJ2RvbmUnIH1dKSAvLyA9PT0gJ1tcInRvZG9zXCIse1wiZmlsdGVyXCI6XCJkb25lXCIsXCJwYWdlXCI6MX1dJ1xuKiBgYGBcbiovXG5mdW5jdGlvbiBoYXNoS2V5KHF1ZXJ5S2V5KSB7XG5cdHJldHVybiBKU09OLnN0cmluZ2lmeShxdWVyeUtleSwgKF8sIHZhbCkgPT4gaXNQbGFpbk9iamVjdCh2YWwpID8gT2JqZWN0LmtleXModmFsKS5zb3J0KCkucmVkdWNlKChyZXN1bHQsIGtleSkgPT4ge1xuXHRcdHJlc3VsdFtrZXldID0gdmFsW2tleV07XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fSwge30pIDogdmFsKTtcbn1cbmZ1bmN0aW9uIHBhcnRpYWxNYXRjaEtleShhLCBiKSB7XG5cdGlmIChhID09PSBiKSByZXR1cm4gdHJ1ZTtcblx0aWYgKHR5cGVvZiBhICE9PSB0eXBlb2YgYikgcmV0dXJuIGZhbHNlO1xuXHRpZiAoYSAmJiBiICYmIHR5cGVvZiBhID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBiID09PSBcIm9iamVjdFwiKSB7XG5cdFx0aWYgKEFycmF5LmlzQXJyYXkoYSkgJiYgQXJyYXkuaXNBcnJheShiKSkge1xuXHRcdFx0aWYgKGIubGVuZ3RoID4gYS5sZW5ndGgpIHJldHVybiBmYWxzZTtcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgYi5sZW5ndGg7IGkrKykgaWYgKCFwYXJ0aWFsTWF0Y2hLZXkoYVtpXSwgYltpXSkpIHJldHVybiBmYWxzZTtcblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH1cblx0XHRjb25zdCBiS2V5cyA9IE9iamVjdC5rZXlzKGIpO1xuXHRcdGZvciAoY29uc3Qga2V5IG9mIGJLZXlzKSBpZiAoIXBhcnRpYWxNYXRjaEtleShhW2tleV0sIGJba2V5XSkpIHJldHVybiBmYWxzZTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxuXHRyZXR1cm4gZmFsc2U7XG59XG5jb25zdCBoYXNPd24gPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xuZnVuY3Rpb24gcmVwbGFjZUVxdWFsRGVlcChhLCBiLCBkZXB0aCA9IDApIHtcblx0aWYgKGEgPT09IGIpIHJldHVybiBhO1xuXHRpZiAoZGVwdGggPiA1MDApIHJldHVybiBiO1xuXHRjb25zdCBhcnJheSA9IGlzUGxhaW5BcnJheShhKSAmJiBpc1BsYWluQXJyYXkoYik7XG5cdGlmICghYXJyYXkgJiYgIShpc1BsYWluT2JqZWN0KGEpICYmIGlzUGxhaW5PYmplY3QoYikpKSByZXR1cm4gYjtcblx0Y29uc3QgYVNpemUgPSAoYXJyYXkgPyBhIDogT2JqZWN0LmtleXMoYSkpLmxlbmd0aDtcblx0Y29uc3QgYkl0ZW1zID0gYXJyYXkgPyBiIDogT2JqZWN0LmtleXMoYik7XG5cdGNvbnN0IGJTaXplID0gYkl0ZW1zLmxlbmd0aDtcblx0Y29uc3QgY29weSA9IGFycmF5ID8gbmV3IEFycmF5KGJTaXplKSA6IHt9O1xuXHRsZXQgZXF1YWxJdGVtcyA9IDA7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgYlNpemU7IGkrKykge1xuXHRcdGNvbnN0IGtleSA9IGFycmF5ID8gaSA6IGJJdGVtc1tpXTtcblx0XHRjb25zdCBhSXRlbSA9IGFba2V5XTtcblx0XHRjb25zdCBiSXRlbSA9IGJba2V5XTtcblx0XHRpZiAoYUl0ZW0gPT09IGJJdGVtKSB7XG5cdFx0XHRjb3B5W2tleV0gPSBhSXRlbTtcblx0XHRcdGlmIChhcnJheSA/IGkgPCBhU2l6ZSA6IGhhc093bi5jYWxsKGEsIGtleSkpIGVxdWFsSXRlbXMrKztcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRpZiAoYUl0ZW0gPT09IG51bGwgfHwgYkl0ZW0gPT09IG51bGwgfHwgdHlwZW9mIGFJdGVtICE9PSBcIm9iamVjdFwiIHx8IHR5cGVvZiBiSXRlbSAhPT0gXCJvYmplY3RcIikge1xuXHRcdFx0Y29weVtrZXldID0gYkl0ZW07XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0Y29uc3QgdiA9IHJlcGxhY2VFcXVhbERlZXAoYUl0ZW0sIGJJdGVtLCBkZXB0aCArIDEpO1xuXHRcdGNvcHlba2V5XSA9IHY7XG5cdFx0aWYgKHYgPT09IGFJdGVtKSBlcXVhbEl0ZW1zKys7XG5cdH1cblx0cmV0dXJuIGFTaXplID09PSBiU2l6ZSAmJiBlcXVhbEl0ZW1zID09PSBhU2l6ZSA/IGEgOiBjb3B5O1xufVxuLyoqXG4qIFNoYWxsb3cgY29tcGFyZSBvYmplY3RzLlxuKiBAcGFyYW0gYSAtIFRoZSBmaXJzdCBvYmplY3QuXG4qIEBwYXJhbSBiIC0gVGhlIHNlY29uZCBvYmplY3QsIG9yIGB1bmRlZmluZWRgLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYm90aCBvYmplY3RzIGhhdmUgdGhlIHNhbWUga2V5cywgd2l0aCBzdHJpY3RseSBlcXVhbCB2YWx1ZXMgZm9yIGVhY2gga2V5LlxuKi9cbmZ1bmN0aW9uIHNoYWxsb3dFcXVhbE9iamVjdHMoYSwgYikge1xuXHRpZiAoIWIgfHwgT2JqZWN0LmtleXMoYSkubGVuZ3RoICE9PSBPYmplY3Qua2V5cyhiKS5sZW5ndGgpIHJldHVybiBmYWxzZTtcblx0Zm9yIChjb25zdCBrZXkgaW4gYSkgaWYgKGFba2V5XSAhPT0gYltrZXldKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiB0cnVlO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgdmFsdWUgaXMgYW4gYXJyYXkgd2l0aCBubyBob2xlcyBhbmQgbm8gZXh0cmEgcHJvcGVydGllcy5cbiogQHBhcmFtIHZhbHVlIC0gVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhbiBhcnJheSB3aG9zZSBudW1iZXIgb2Ygb3duIGtleXMgZXF1YWxzIGl0cyBgbGVuZ3RoYC5cbiovXG5mdW5jdGlvbiBpc1BsYWluQXJyYXkodmFsdWUpIHtcblx0cmV0dXJuIEFycmF5LmlzQXJyYXkodmFsdWUpICYmIHZhbHVlLmxlbmd0aCA9PT0gT2JqZWN0LmtleXModmFsdWUpLmxlbmd0aDtcbn1cbi8qKlxuKiBDaGVja3Mgd2hldGhlciBhIHZhbHVlIGlzIGEgcGxhaW4gb2JqZWN0LCBlLmcuIGNyZWF0ZWQgd2l0aCBhbiBvYmplY3QgbGl0ZXJhbCBvclxuKiBgT2JqZWN0LmNyZWF0ZShudWxsKWAuXG4qIEBwYXJhbSBvIC0gVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYG9gIGlzIGEgcGxhaW4gb2JqZWN0LlxuKi9cbmZ1bmN0aW9uIGlzUGxhaW5PYmplY3Qobykge1xuXHRpZiAoIWhhc09iamVjdFByb3RvdHlwZShvKSkgcmV0dXJuIGZhbHNlO1xuXHRjb25zdCBvYmplY3RQcm90b3R5cGUgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2Yobyk7XG5cdGNvbnN0IGN0b3IgPSBvYmplY3RQcm90b3R5cGU/LmNvbnN0cnVjdG9yO1xuXHRpZiAoY3RvciA9PT0gdm9pZCAwKSByZXR1cm4gdHJ1ZTtcblx0aWYgKHR5cGVvZiBjdG9yICE9PSBcImZ1bmN0aW9uXCIpIHJldHVybiBmYWxzZTtcblx0Y29uc3QgcHJvdCA9IGN0b3IucHJvdG90eXBlO1xuXHRpZiAoIWhhc09iamVjdFByb3RvdHlwZShwcm90KSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAoIXByb3QuaGFzT3duUHJvcGVydHkoXCJpc1Byb3RvdHlwZU9mXCIpKSByZXR1cm4gZmFsc2U7XG5cdGlmIChvYmplY3RQcm90b3R5cGUgIT09IE9iamVjdC5wcm90b3R5cGUpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIHRydWU7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSB2YWx1ZSdzIGBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nYCB0YWcgaXMgYFtvYmplY3QgT2JqZWN0XWAuXG4qIEBwYXJhbSBvIC0gVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHRhZyBpcyBgW29iamVjdCBPYmplY3RdYC5cbiovXG5mdW5jdGlvbiBoYXNPYmplY3RQcm90b3R5cGUobykge1xuXHRyZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG8pID09PSBcIltvYmplY3QgT2JqZWN0XVwiO1xufVxuLyoqXG4qIFdhaXRzIGZvciB0aGUgZ2l2ZW4gdGltZSwgdXNpbmcgdGhlIGNvbmZpZ3VyZWQge0BsaW5rIHRpbWVvdXRNYW5hZ2VyfS5cbiogQHBhcmFtIHRpbWVvdXQgLSBUaGUgdGltZSB0byB3YWl0LCBpbiBtaWxsaXNlY29uZHMuXG4qIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIGB0aW1lb3V0YCBtaWxsaXNlY29uZHMuXG4qL1xuZnVuY3Rpb24gc2xlZXAodGltZW91dCkge1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHR0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0KHJlc29sdmUsIHRpbWVvdXQpO1xuXHR9KTtcbn1cbi8qKlxuKiBBcHBsaWVzIGEgcXVlcnkncyBgc3RydWN0dXJhbFNoYXJpbmdgIG9wdGlvbiB3aGVuIHdyaXRpbmcgbmV3IGRhdGEuXG4qIEBwYXJhbSBwcmV2RGF0YSAtIFRoZSBwcmV2aW91c2x5IGNhY2hlZCBkYXRhLlxuKiBAcGFyYW0gZGF0YSAtIFRoZSBuZXcgZGF0YS5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucywgd2hvc2UgYHN0cnVjdHVyYWxTaGFyaW5nYCBkZWNpZGVzIGhvdyB0aGUgZGF0YSBpcyBtZXJnZWQuXG4qIEByZXR1cm5zIFRoZSByZXN1bHQgb2YgYSBjdXN0b20gYHN0cnVjdHVyYWxTaGFyaW5nYCBmdW5jdGlvbiwgYGRhdGFgIHdpdGggaXRzIHVuY2hhbmdlZCBwYXJ0c1xuKiByZXBsYWNlZCBieSB0aG9zZSBvZiBgcHJldkRhdGFgIGJ5IGRlZmF1bHQsIG9yIGBkYXRhYCBhcyBpcyBpZiBgc3RydWN0dXJhbFNoYXJpbmdgIGlzIGBmYWxzZWAuXG4qIEB0aHJvd3Mge0Vycm9yfSBUaGUgZXJyb3IgZnJvbSB0aGUgZGVmYXVsdCBzdHJ1Y3R1cmFsIHNoYXJpbmcsIGUuZy4gd2hlbiB0aGUgZGF0YSBpcyBub3QgSlNPTiBzZXJpYWxpemFibGUuXG4qIE91dHNpZGUgcHJvZHVjdGlvbiwgaXQgaXMgYWxzbyBsb2dnZWQgdG8gdGhlIGNvbnNvbGUuXG4qL1xuZnVuY3Rpb24gcmVwbGFjZURhdGEocHJldkRhdGEsIGRhdGEsIG9wdGlvbnMpIHtcblx0aWYgKHR5cGVvZiBvcHRpb25zLnN0cnVjdHVyYWxTaGFyaW5nID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBvcHRpb25zLnN0cnVjdHVyYWxTaGFyaW5nKHByZXZEYXRhLCBkYXRhKTtcblx0ZWxzZSBpZiAob3B0aW9ucy5zdHJ1Y3R1cmFsU2hhcmluZyAhPT0gZmFsc2UpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0cnkge1xuXHRcdFx0cmV0dXJuIHJlcGxhY2VFcXVhbERlZXAocHJldkRhdGEsIGRhdGEpO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRjb25zb2xlLmVycm9yKGBTdHJ1Y3R1cmFsIHNoYXJpbmcgcmVxdWlyZXMgZGF0YSB0byBiZSBKU09OIHNlcmlhbGl6YWJsZS4gVG8gZml4IHRoaXMsIHR1cm4gb2ZmIHN0cnVjdHVyYWxTaGFyaW5nIG9yIHJldHVybiBKU09OLXNlcmlhbGl6YWJsZSBkYXRhIGZyb20geW91ciBxdWVyeUZuLiBbJHtvcHRpb25zLnF1ZXJ5SGFzaH1dOiAke2Vycm9yfWApO1xuXHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0fVxuXHRcdHJldHVybiByZXBsYWNlRXF1YWxEZWVwKHByZXZEYXRhLCBkYXRhKTtcblx0fVxuXHRyZXR1cm4gZGF0YTtcbn1cbi8qKlxuKiBJbnRlbmRlZCB0byBiZSBwYXNzZWQgYXMgYSBxdWVyeSdzIGBwbGFjZWhvbGRlckRhdGFgIG9wdGlvbiwgZm9yIGV4YW1wbGVcbiogYHBsYWNlaG9sZGVyRGF0YToga2VlcFByZXZpb3VzRGF0YWAuIEluc3RlYWQgb2YgcmVzZXR0aW5nIHRoZSBxdWVyeSdzIGRhdGEgdG8gYHVuZGVmaW5lZGAgd2hpbGUgYSBuZXdcbiogcXVlcnkga2V5IGlzIGZldGNoaW5nLCBpdCBrZWVwcyBkaXNwbGF5aW5nIHRoZSBwcmV2aW91c2x5IGZldGNoZWQgZGF0YSB1bnRpbCB0aGUgbmV3IGRhdGEgYXJyaXZlcy5cbiogQHBhcmFtIHByZXZpb3VzRGF0YSAtIFRoZSBkYXRhIG9mIHRoZSBwcmV2aW91cyBxdWVyeSBrZXksIHBhc3NlZCBieSB0aGUgb2JzZXJ2ZXIuXG4qIEByZXR1cm5zIFRoZSBwcmV2aW91cyBkYXRhLCB1bmNoYW5nZWQuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIG5ldyBRdWVyeU9ic2VydmVyKHF1ZXJ5Q2xpZW50LCB7XG4qICAgcXVlcnlLZXk6IFsncG9zdHMnLCBwYWdlXSxcbiogICBxdWVyeUZuOiAoKSA9PiBmZXRjaFBvc3RzKHBhZ2UpLFxuKiAgIHBsYWNlaG9sZGVyRGF0YToga2VlcFByZXZpb3VzRGF0YSxcbiogfSlcbiogYGBgXG4qL1xuZnVuY3Rpb24ga2VlcFByZXZpb3VzRGF0YShwcmV2aW91c0RhdGEpIHtcblx0cmV0dXJuIHByZXZpb3VzRGF0YTtcbn1cbi8qKlxuKiBSZXR1cm5zIGEgbmV3IGFycmF5IHdpdGggYGl0ZW1gIGFkZGVkIGF0IHRoZSBlbmQuIElmIHRoYXQgbWFrZXMgdGhlIGFycmF5IGxvbmdlciB0aGFuIGBtYXhgLFxuKiB0aGUgZmlyc3QgaXRlbSBpcyBkcm9wcGVkLiBPbmx5IG9uZSBpdGVtIGlzIGRyb3BwZWQsIHNvIHRoZSByZXN1bHQgY2FuIHN0aWxsIGV4Y2VlZCBgbWF4YCBpZlxuKiBgaXRlbXNgIGFscmVhZHkgZGlkLlxuKiBAcGFyYW0gaXRlbXMgLSBUaGUgY3VycmVudCBpdGVtcy5cbiogQHBhcmFtIGl0ZW0gLSBUaGUgdmFsdWUgdG8gYXBwZW5kLlxuKiBAcGFyYW0gbWF4IC0gVGhlIGxlbmd0aCBhYm92ZSB3aGljaCBhbiBpdGVtIGlzIGRyb3BwZWQuIGAwYCAodGhlIGRlZmF1bHQpIG1lYW5zIG5vIGxpbWl0LlxuKiBAcmV0dXJucyBBIG5ldyBhcnJheSB3aXRoIGBpdGVtYCBhZGRlZC5cbiovXG5mdW5jdGlvbiBhZGRUb0VuZChpdGVtcywgaXRlbSwgbWF4ID0gMCkge1xuXHRjb25zdCBuZXdJdGVtcyA9IFsuLi5pdGVtcywgaXRlbV07XG5cdHJldHVybiBtYXggJiYgbmV3SXRlbXMubGVuZ3RoID4gbWF4ID8gbmV3SXRlbXMuc2xpY2UoMSkgOiBuZXdJdGVtcztcbn1cbi8qKlxuKiBSZXR1cm5zIGEgbmV3IGFycmF5IHdpdGggYGl0ZW1gIGFkZGVkIGF0IHRoZSBzdGFydC4gSWYgdGhhdCBtYWtlcyB0aGUgYXJyYXkgbG9uZ2VyIHRoYW4gYG1heGAsXG4qIHRoZSBsYXN0IGl0ZW0gaXMgZHJvcHBlZC4gT25seSBvbmUgaXRlbSBpcyBkcm9wcGVkLCBzbyB0aGUgcmVzdWx0IGNhbiBzdGlsbCBleGNlZWQgYG1heGAgaWZcbiogYGl0ZW1zYCBhbHJlYWR5IGRpZC5cbiogQHBhcmFtIGl0ZW1zIC0gVGhlIGN1cnJlbnQgaXRlbXMuXG4qIEBwYXJhbSBpdGVtIC0gVGhlIHZhbHVlIHRvIHByZXBlbmQuXG4qIEBwYXJhbSBtYXggLSBUaGUgbGVuZ3RoIGFib3ZlIHdoaWNoIGFuIGl0ZW0gaXMgZHJvcHBlZC4gYDBgICh0aGUgZGVmYXVsdCkgbWVhbnMgbm8gbGltaXQuXG4qIEByZXR1cm5zIEEgbmV3IGFycmF5IHdpdGggYGl0ZW1gIGFkZGVkLlxuKi9cbmZ1bmN0aW9uIGFkZFRvU3RhcnQoaXRlbXMsIGl0ZW0sIG1heCA9IDApIHtcblx0Y29uc3QgbmV3SXRlbXMgPSBbaXRlbSwgLi4uaXRlbXNdO1xuXHRyZXR1cm4gbWF4ICYmIG5ld0l0ZW1zLmxlbmd0aCA+IG1heCA/IG5ld0l0ZW1zLnNsaWNlKDAsIC0xKSA6IG5ld0l0ZW1zO1xufVxuLyoqXG4qIFNlbnRpbmVsIHZhbHVlIHRoYXQgY2FuIGJlIHBhc3NlZCBhcyBhIHF1ZXJ5J3MgYHF1ZXJ5Rm5gIHRvIGNvbmRpdGlvbmFsbHkgZGlzYWJsZSB0aGUgcXVlcnkgKGVxdWl2YWxlbnRcbiogdG8gYGVuYWJsZWQ6IGZhbHNlYCkgd2hpbGUgcHJlc2VydmluZyBmdWxsIHR5cGUgaW5mZXJlbmNlIGZvciB0aGUgcXVlcnkncyBkYXRhLiBVbmxpa2UgYGVuYWJsZWQ6IGZhbHNlYCxcbiogYSBxdWVyeSBkaXNhYmxlZCB2aWEgYHNraXBUb2tlbmAgY2Fubm90IGJlIHRyaWdnZXJlZCB3aXRoIGByZWZldGNoYC5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogbmV3IFF1ZXJ5T2JzZXJ2ZXIocXVlcnlDbGllbnQsIHtcbiogICBxdWVyeUtleTogWydwb3N0JywgcG9zdElkXSxcbiogICBxdWVyeUZuOiBwb3N0SWQgIT0gbnVsbCA/ICgpID0+IGZldGNoUG9zdChwb3N0SWQpIDogc2tpcFRva2VuLFxuKiB9KVxuKiBgYGBcbiovXG5jb25zdCBza2lwVG9rZW4gPSBTeW1ib2woKTtcbi8qKlxuKiBSZXR1cm5zIHRoZSBmdW5jdGlvbiB0byBjYWxsIGZvciBhIGZldGNoLiBJZiB0aGVyZSBpcyBubyBgcXVlcnlGbmAgYnV0IHRoZSBmZXRjaCB3YXMgc3RhcnRlZCBmcm9tXG4qIGFuIGBpbml0aWFsUHJvbWlzZWAsIHRoYXQgcHJvbWlzZSBpcyByZXR1cm5lZCBpbnN0ZWFkLiBJZiB0aGVyZSBpcyBubyB1c2FibGUgYHF1ZXJ5Rm5gIChtaXNzaW5nIG9yXG4qIHtAbGluayBza2lwVG9rZW59KSwgdGhlIHJldHVybmVkIGZ1bmN0aW9uIHJlamVjdHMgd2l0aCBhIGBNaXNzaW5nIHF1ZXJ5Rm5gIGVycm9yLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBxdWVyeSBvcHRpb25zIHdpdGggdGhlIGBxdWVyeUZuYCwgYW5kIHRoZSBgcXVlcnlIYXNoYCB1c2VkIGluIGVycm9yIG1lc3NhZ2VzLlxuKiBAcGFyYW0gZmV0Y2hPcHRpb25zIC0gVGhlIGZldGNoIG9wdGlvbnMsIHdoaWNoIG1heSBjYXJyeSBhbiBgaW5pdGlhbFByb21pc2VgLlxuKiBAcmV0dXJucyBUaGUgZnVuY3Rpb24gdG8gY2FsbCBmb3IgdGhlIGZldGNoLlxuKi9cbmZ1bmN0aW9uIGVuc3VyZVF1ZXJ5Rm4ob3B0aW9ucywgZmV0Y2hPcHRpb25zKSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAob3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4pIGNvbnNvbGUuZXJyb3IoYEF0dGVtcHRlZCB0byBpbnZva2UgcXVlcnlGbiB3aGVuIHNldCB0byBza2lwVG9rZW4uIFRoaXMgaXMgbGlrZWx5IGEgY29uZmlndXJhdGlvbiBlcnJvci4gUXVlcnkgaGFzaDogJyR7b3B0aW9ucy5xdWVyeUhhc2h9J2ApO1xuXHR9XG5cdGlmICghb3B0aW9ucy5xdWVyeUZuICYmIGZldGNoT3B0aW9ucz8uaW5pdGlhbFByb21pc2UpIHJldHVybiAoKSA9PiBmZXRjaE9wdGlvbnMuaW5pdGlhbFByb21pc2U7XG5cdGlmICghb3B0aW9ucy5xdWVyeUZuIHx8IG9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuKSByZXR1cm4gKCkgPT4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihgTWlzc2luZyBxdWVyeUZuOiAnJHtvcHRpb25zLnF1ZXJ5SGFzaH0nYCkpO1xuXHRyZXR1cm4gb3B0aW9ucy5xdWVyeUZuO1xufVxuLyoqXG4qIFJlc29sdmVzIGEgYHRocm93T25FcnJvcmAgb3B0aW9uIHRvIGEgYm9vbGVhbi5cbiogSWYgYHRocm93T25FcnJvcmAgaXMgYSBmdW5jdGlvbiwgaXQgaXMgY2FsbGVkIHdpdGggYHBhcmFtc2AgKGUuZy4gdGhlIGVycm9yIGFuZCwgZGVwZW5kaW5nIG9uIHRoZSBjYWxsZXIsXG4qIGFkZGl0aW9uYWwgY29udGV4dCBzdWNoIGFzIHRoZSBxdWVyeSBvciBtdXRhdGlvbikgYW5kIGl0cyByZXN1bHQgaXMgcmV0dXJuZWQsIGFsbG93aW5nIHRoZSB0aHJvd2luZ1xuKiBiZWhhdmlvciB0byBiZSBkZWNpZGVkIHBlciBlcnJvci4gT3RoZXJ3aXNlLCBgdGhyb3dPbkVycm9yYCBpdHNlbGYgaXMgY29lcmNlZCB0byBhIGJvb2xlYW4gKGB1bmRlZmluZWRgXG4qIHJlc29sdmVzIHRvIGBmYWxzZWApLlxuKiBAcGFyYW0gdGhyb3dPbkVycm9yIC0gVGhlIGB0aHJvd09uRXJyb3JgIG9wdGlvbjogYSBib29sZWFuLCBhIGZ1bmN0aW9uIHRoYXQgZGVjaWRlcyBwZXIgZXJyb3IsIG9yXG4qIGB1bmRlZmluZWRgLlxuKiBAcGFyYW0gcGFyYW1zIC0gVGhlIGFyZ3VtZW50cyBwYXNzZWQgdG8gYHRocm93T25FcnJvcmAgaWYgaXQgaXMgYSBmdW5jdGlvbi5cbiogQHJldHVybnMgV2hldGhlciB0aGUgZXJyb3Igc2hvdWxkIGJlIHRocm93bi5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgdGhyb3dPbkVycm9yID1cbiogICBxdWVyeS5zdGF0ZS5lcnJvciAmJiB0eXBlb2Ygb3B0aW9ucy50aHJvd09uRXJyb3IgPT09ICdmdW5jdGlvbidcbiogICAgID8gc2hvdWxkVGhyb3dFcnJvcihvcHRpb25zLnRocm93T25FcnJvciwgW3F1ZXJ5LnN0YXRlLmVycm9yLCBxdWVyeV0pXG4qICAgICA6IG9wdGlvbnMudGhyb3dPbkVycm9yXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHNob3VsZFRocm93RXJyb3IodGhyb3dPbkVycm9yLCBwYXJhbXMpIHtcblx0aWYgKHR5cGVvZiB0aHJvd09uRXJyb3IgPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIHRocm93T25FcnJvciguLi5wYXJhbXMpO1xuXHRyZXR1cm4gISF0aHJvd09uRXJyb3I7XG59XG4vKipcbiogQWRkcyBhIGxhenkgYHNpZ25hbGAgZ2V0dGVyIHRvIGFuIG9iamVjdCwgc3VjaCBhcyBhIHF1ZXJ5IGZ1bmN0aW9uIGNvbnRleHQuIFRoZSBmaXJzdCB0aW1lXG4qIGBzaWduYWxgIGlzIHJlYWQsIGBvbkNhbmNlbGxlZGAgaXMgcmVnaXN0ZXJlZCBmb3IgdGhlIHNpZ25hbCdzIGBhYm9ydGAgZXZlbnQgKG9yIGNhbGxlZCByaWdodFxuKiBhd2F5IGlmIGl0IGlzIGFscmVhZHkgYWJvcnRlZCksIHNvIGNhbmNlbGxhdGlvbiBpcyBvbmx5IHRyYWNrZWQgd2hlbiB0aGUgc2lnbmFsIGlzIGFjdHVhbGx5IHVzZWQuXG4qIEBwYXJhbSBvYmplY3QgLSBUaGUgb2JqZWN0IHRvIGFkZCB0aGUgYHNpZ25hbGAgcHJvcGVydHkgdG8uXG4qIEBwYXJhbSBnZXRTaWduYWwgLSBSZXR1cm5zIHRoZSBgQWJvcnRTaWduYWxgLiBDYWxsZWQgb25jZSwgd2hlbiBgc2lnbmFsYCBpcyBmaXJzdCByZWFkLlxuKiBAcGFyYW0gb25DYW5jZWxsZWQgLSBDYWxsZWQgd2hlbiB0aGUgc2lnbmFsIGlzIGFib3J0ZWQsIGlmIGBzaWduYWxgIHdhcyByZWFkLlxuKiBAcmV0dXJucyBUaGUgc2FtZSBvYmplY3QsIHdpdGggdGhlIGBzaWduYWxgIHByb3BlcnR5IGFkZGVkLlxuKi9cbmZ1bmN0aW9uIGFkZENvbnN1bWVBd2FyZVNpZ25hbChvYmplY3QsIGdldFNpZ25hbCwgb25DYW5jZWxsZWQpIHtcblx0bGV0IGNvbnN1bWVkID0gZmFsc2U7XG5cdGxldCBzaWduYWw7XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmplY3QsIFwic2lnbmFsXCIsIHtcblx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdGdldDogKCkgPT4ge1xuXHRcdFx0c2lnbmFsID8/PSBnZXRTaWduYWwoKTtcblx0XHRcdGlmIChjb25zdW1lZCkgcmV0dXJuIHNpZ25hbDtcblx0XHRcdGNvbnN1bWVkID0gdHJ1ZTtcblx0XHRcdGlmIChzaWduYWwuYWJvcnRlZCkgb25DYW5jZWxsZWQoKTtcblx0XHRcdGVsc2Ugc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBvbkNhbmNlbGxlZCwgeyBvbmNlOiB0cnVlIH0pO1xuXHRcdFx0cmV0dXJuIHNpZ25hbDtcblx0XHR9XG5cdH0pO1xuXHRyZXR1cm4gb2JqZWN0O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBhZGRDb25zdW1lQXdhcmVTaWduYWwsIGFkZFRvRW5kLCBhZGRUb1N0YXJ0LCBlbnN1cmVRdWVyeUZuLCBmdW5jdGlvbmFsVXBkYXRlLCBoYXNoS2V5LCBoYXNoUXVlcnlLZXlCeU9wdGlvbnMsIGlzUGxhaW5BcnJheSwgaXNQbGFpbk9iamVjdCwgaXNTZXJ2ZXIsIGlzVmFsaWRUaW1lb3V0LCBrZWVwUHJldmlvdXNEYXRhLCBtYXRjaE11dGF0aW9uLCBtYXRjaFF1ZXJ5LCBub29wLCBwYXJ0aWFsTWF0Y2hLZXksIHJlcGxhY2VEYXRhLCByZXBsYWNlRXF1YWxEZWVwLCByZXNvbHZlUXVlcnlWYWx1ZSwgc2hhbGxvd0VxdWFsT2JqZWN0cywgc2hvdWxkVGhyb3dFcnJvciwgc2tpcFRva2VuLCBzbGVlcCwgdGltZVVudGlsU3RhbGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXRpbHMuanMubWFwIiwiaW1wb3J0IHsgaXNTZXJ2ZXIgYXMgaXNTZXJ2ZXIkMSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyNyZWdpb24gc3JjL2Vudmlyb25tZW50TWFuYWdlci50c1xubGV0IGlzU2VydmVyRm4gPSAoKSA9PiBpc1NlcnZlciQxO1xuLyoqXG4qIFJldHVybnMgd2hldGhlciB0aGUgY3VycmVudCBydW50aW1lIHNob3VsZCBiZSB0cmVhdGVkIGFzIGEgc2VydmVyIGVudmlyb25tZW50LlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHJ1bnRpbWUgaXMgdHJlYXRlZCBhcyBhIHNlcnZlci5cbiovXG5jb25zdCBpc1NlcnZlciA9ICgpID0+IGlzU2VydmVyRm4oKTtcbi8qKlxuKiBNYW5hZ2VzIGhvdyBUYW5TdGFjayBRdWVyeSBkZXRlY3RzIHdoZXRoZXIgdGhlIGN1cnJlbnQgcnVudGltZSBzaG91bGQgYmUgdHJlYXRlZCBhc1xuKiBzZXJ2ZXItc2lkZSwgd2hpY2ggZGlzYWJsZXMgc2NoZWR1bGluZyByZWZldGNoIHRpbWVycyBhbmQgY2hhbmdlcyB0aGUgZGVmYXVsdCBgcmV0cnlgIGNvdW50XG4qIGFuZCBgZ2NUaW1lYC4gQnkgZGVmYXVsdCwgdGhlIGRldGVjdGlvbiB0cmVhdHMgYSBtaXNzaW5nIGB3aW5kb3dgIChvciB0aGUgcHJlc2VuY2Ugb2YgYVxuKiBgRGVub2AgZ2xvYmFsKSBhcyBzZXJ2ZXIuXG4qXG4qIE92ZXJyaWRlIHRoaXMgZm9yIHJ1bnRpbWVzIHdoZXJlIHRoYXQgZGVmYXVsdCBkZXRlY3Rpb24gd291bGQgZ2l2ZSB0aGUgd3JvbmcgYW5zd2VyIOKAlCBmb3JcbiogZXhhbXBsZSwgYSBTZXJ2aWNlIFdvcmtlciwgd2hlcmUgYHdpbmRvd2AgaXMgdW5kZWZpbmVkIGV2ZW4gdGhvdWdoIHRoZSBlbnZpcm9ubWVudCBzaG91bGRcbiogYmVoYXZlIGxpa2UgYSBjbGllbnQuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGltcG9ydCB7IGVudmlyb25tZW50TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuKlxuKiBlbnZpcm9ubWVudE1hbmFnZXIuc2V0SXNTZXJ2ZXIoKCkgPT4gZmFsc2UpXG4qIGBgYFxuKi9cbmNvbnN0IGVudmlyb25tZW50TWFuYWdlciA9IHtcblx0aXNTZXJ2ZXIsXG5cdC8qKlxuXHQqIE92ZXJyaWRlcyB0aGUgc2VydmVyIGNoZWNrIGdsb2JhbGx5LlxuXHQqIEBwYXJhbSBpc1NlcnZlclZhbHVlIC0gQSBmdW5jdGlvbiB0aGF0IHJldHVybnMgd2hldGhlciB0aGUgcnVudGltZSBzaG91bGQgYmUgdHJlYXRlZCBhcyBhXG5cdCogc2VydmVyLlxuXHQqL1xuXHRzZXRJc1NlcnZlcihpc1NlcnZlclZhbHVlKSB7XG5cdFx0aXNTZXJ2ZXJGbiA9IGlzU2VydmVyVmFsdWU7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGVudmlyb25tZW50TWFuYWdlciwgaXNTZXJ2ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZW52aXJvbm1lbnRNYW5hZ2VyLmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvc3Vic2NyaWJhYmxlLnRzXG4vKipcbiogVGhlIGJhc2UgY2xhc3MgYmVoaW5kIGV2ZXJ5dGhpbmcgaW4gUXVlcnkgdGhhdCB5b3UgY2FuIHN1YnNjcmliZSB0bzogYFF1ZXJ5Q2FjaGVgLCBgTXV0YXRpb25DYWNoZWAsXG4qIHRoZSBvYnNlcnZlcnMsIGFuZCB0aGUgYEZvY3VzTWFuYWdlcmAvYE9ubGluZU1hbmFnZXJgIGJlaGluZCBgZm9jdXNNYW5hZ2VyYCBhbmQgYG9ubGluZU1hbmFnZXJgLlxuKiBTdWJjbGFzc2VzIGRlY2lkZSB3aGF0IGEgbGlzdGVuZXIgcmVjZWl2ZXMgYW5kIHdoZW4gaXQgaXMgY2FsbGVkLlxuKi9cbnZhciBTdWJzY3JpYmFibGUgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdHRoaXMubGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHR0aGlzLnN1YnNjcmliZSA9IHRoaXMuc3Vic2NyaWJlLmJpbmQodGhpcyk7XG5cdH1cblx0LyoqXG5cdCogUmVnaXN0ZXJzIGEgbGlzdGVuZXIgdG8gYmUgY2FsbGVkIG9uIGV2ZXJ5IHVwZGF0ZSB0aGlzIG9iamVjdCBub3RpZmllcyBhYm91dC4gUmV0dXJucyBhIGZ1bmN0aW9uXG5cdCogdGhhdCByZW1vdmVzIHRoZSBsaXN0ZW5lciBhZ2FpbiDigJQgY2FsbCBpdCB0byBzdG9wIGxpc3RlbmluZy4gVGhlIGJhc2UgY2xhc3MgbmV2ZXIgZHJvcHMgYSBsaXN0ZW5lclxuXHQqIG9uIGl0cyBvd24sIHRob3VnaCBzb21lIHN1YmNsYXNzZXMgY2xlYXIgYWxsIG9mIHRoZWlycyBpbiBgZGVzdHJveSgpYC5cblx0KiBAcGFyYW0gbGlzdGVuZXIgLSBDYWxsZWQgb24gZWFjaCB1cGRhdGUsIHdpdGggd2hhdGV2ZXIgdGhlIHN1YmNsYXNzIHBhc3NlcyB0byBpdHMgc3Vic2NyaWJlcnMuXG5cdCogQHJldHVybnMgQSBmdW5jdGlvbiB0aGF0IHJlbW92ZXMgdGhlIGxpc3RlbmVyLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCB1bnN1YnNjcmliZSA9IHN1YnNjcmliYWJsZS5zdWJzY3JpYmUoKCkgPT4ge1xuXHQqICAgLy8gcmVhY3QgdG8gdGhlIHVwZGF0ZVxuXHQqIH0pXG5cdCpcblx0KiB1bnN1YnNjcmliZSgpXG5cdCogYGBgXG5cdCovXG5cdHN1YnNjcmliZShsaXN0ZW5lcikge1xuXHRcdHRoaXMubGlzdGVuZXJzLmFkZChsaXN0ZW5lcik7XG5cdFx0dGhpcy5vblN1YnNjcmliZSgpO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHR0aGlzLmxpc3RlbmVycy5kZWxldGUobGlzdGVuZXIpO1xuXHRcdFx0dGhpcy5vblVuc3Vic2NyaWJlKCk7XG5cdFx0fTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIGB0cnVlYCB3aGlsZSBhdCBsZWFzdCBvbmUgbGlzdGVuZXIgaXMgcmVnaXN0ZXJlZCwgYGZhbHNlYCBvbmNlIHRoZXkgaGF2ZSBhbGwgdW5zdWJzY3JpYmVkLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiBhdCBsZWFzdCBvbmUgbGlzdGVuZXIgaXMgcmVnaXN0ZXJlZC5cblx0Ki9cblx0aGFzTGlzdGVuZXJzKCkge1xuXHRcdHJldHVybiB0aGlzLmxpc3RlbmVycy5zaXplID4gMDtcblx0fVxuXHQvKipcblx0KiBDYWxsZWQgYWZ0ZXIgYSBsaXN0ZW5lciBpcyBhZGRlZC4gRG9lcyBub3RoaW5nIGhlcmU7IHN1YmNsYXNzZXMgb3ZlcnJpZGUgaXQsIGUuZy4gdG8gc3RhcnRcblx0KiB0cmFja2luZyB3aGF0IHRoZXkgb2JzZXJ2ZSBvbmNlIHRoZSBmaXJzdCBsaXN0ZW5lciBzdWJzY3JpYmVzLlxuXHQqL1xuXHRvblN1YnNjcmliZSgpIHt9XG5cdC8qKlxuXHQqIENhbGxlZCBhZnRlciBhIGxpc3RlbmVyIGlzIHJlbW92ZWQuIERvZXMgbm90aGluZyBoZXJlOyBzdWJjbGFzc2VzIG92ZXJyaWRlIGl0LCBlLmcuIHRvIGNsZWFuIHVwXG5cdCogb25jZSB0aGUgbGFzdCBsaXN0ZW5lciB1bnN1YnNjcmliZXMuXG5cdCovXG5cdG9uVW5zdWJzY3JpYmUoKSB7fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgU3Vic2NyaWJhYmxlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN1YnNjcmliYWJsZS5qcy5tYXAiLCJpbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbi8vI3JlZ2lvbiBzcmMvZm9jdXNNYW5hZ2VyLnRzXG4vKipcbiogVGhlIGBGb2N1c01hbmFnZXJgIG1hbmFnZXMgdGhlIGZvY3VzIHN0YXRlIHdpdGhpbiBUYW5TdGFjayBRdWVyeS5cbipcbiogSXQgY2FuIGJlIHVzZWQgdG8gY2hhbmdlIHRoZSBkZWZhdWx0IGV2ZW50IGxpc3RlbmVycyBvciB0byBtYW51YWxseSBjaGFuZ2UgdGhlIGZvY3VzIHN0YXRlLlxuKi9cbnZhciBGb2N1c01hbmFnZXIgPSBjbGFzcyBleHRlbmRzIFN1YnNjcmliYWJsZSB7XG5cdCNmb2N1c2VkO1xuXHQjY2xlYW51cDtcblx0I3NldHVwO1xuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuI3NldHVwID0gKG9uRm9jdXMpID0+IHtcblx0XHRcdGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKSB7XG5cdFx0XHRcdGNvbnN0IGxpc3RlbmVyID0gKCkgPT4gb25Gb2N1cygpO1xuXHRcdFx0XHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInZpc2liaWxpdHljaGFuZ2VcIiwgbGlzdGVuZXIsIGZhbHNlKTtcblx0XHRcdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInZpc2liaWxpdHljaGFuZ2VcIiwgbGlzdGVuZXIpO1xuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdH07XG5cdH1cblx0b25TdWJzY3JpYmUoKSB7XG5cdFx0aWYgKCF0aGlzLiNjbGVhbnVwKSB0aGlzLnNldEV2ZW50TGlzdGVuZXIodGhpcy4jc2V0dXApO1xuXHR9XG5cdG9uVW5zdWJzY3JpYmUoKSB7XG5cdFx0aWYgKCF0aGlzLmhhc0xpc3RlbmVycygpKSB7XG5cdFx0XHR0aGlzLiNjbGVhbnVwPy4oKTtcblx0XHRcdHRoaXMuI2NsZWFudXAgPSB2b2lkIDA7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIGBzZXRFdmVudExpc3RlbmVyYCBjYW4gYmUgdXNlZCB0byBzZXQgYSBjdXN0b20gZXZlbnQgbGlzdGVuZXIgdGhhdCB3aWxsXG5cdCogYmUgdXNlZCB0byBkZXRlcm1pbmUgdGhlIGZvY3VzIHN0YXRlLiBUaGUgcHJvdmlkZWQgYHNldHVwYCBmdW5jdGlvblxuXHQqIHJlY2VpdmVzIGEgYHNldEZvY3VzZWRgIGNhbGxiYWNrOiBjYWxsIGl0IHdpdGggYSBgYm9vbGVhbmAgdG8gbWFudWFsbHlcblx0KiBzZXQgdGhlIGZvY3VzIHN0YXRlLCBvciB3aXRoIG5vIGFyZ3VtZW50cyB0byByZS1ldmFsdWF0ZSB0aGUgY3VycmVudFxuXHQqIGZvY3VzIHN0YXRlIGFuZCBub3RpZnkgc3Vic2NyaWJlcnMuXG5cdCogQHBhcmFtIHNldHVwIC0gUmVjZWl2ZXMgdGhlIGBzZXRGb2N1c2VkYCBjYWxsYmFjaywgcmVnaXN0ZXJzIHRoZSBldmVudCBsaXN0ZW5lciwgYW5kIG1heSByZXR1cm5cblx0KiBhIGNsZWFudXAgZnVuY3Rpb24gdGhhdCBpcyBjYWxsZWQgd2hlbiB0aGUgbGlzdGVuZXIgaXMgcmVwbGFjZWQgb3Igbm8gbG9uZ2VyIG5lZWRlZC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgZm9jdXNNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBmb2N1c01hbmFnZXIuc2V0RXZlbnRMaXN0ZW5lcigoaGFuZGxlRm9jdXMpID0+IHtcblx0KiAgIGNvbnN0IGxpc3RlbmVyID0gKCkgPT4gaGFuZGxlRm9jdXMoKVxuXHQqICAgLy8gTGlzdGVuIHRvIHZpc2liaWxpdHljaGFuZ2Vcblx0KiAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcikge1xuXHQqICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIGxpc3RlbmVyLCBmYWxzZSlcblx0KiAgIH1cblx0KlxuXHQqICAgcmV0dXJuICgpID0+IHtcblx0KiAgICAgLy8gQmUgc3VyZSB0byB1bnN1YnNjcmliZSBpZiBhIG5ldyBoYW5kbGVyIGlzIHNldFxuXHQqICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIGxpc3RlbmVyKVxuXHQqICAgfVxuXHQqIH0pXG5cdCogYGBgXG5cdCovXG5cdHNldEV2ZW50TGlzdGVuZXIoc2V0dXApIHtcblx0XHR0aGlzLiNzZXR1cCA9IHNldHVwO1xuXHRcdHRoaXMuI2NsZWFudXA/LigpO1xuXHRcdHRoaXMuI2NsZWFudXAgPSBzZXR1cCgoZm9jdXNlZCkgPT4ge1xuXHRcdFx0aWYgKHR5cGVvZiBmb2N1c2VkID09PSBcImJvb2xlYW5cIikgdGhpcy5zZXRGb2N1c2VkKGZvY3VzZWQpO1xuXHRcdFx0ZWxzZSB0aGlzLm9uRm9jdXMoKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBgc2V0Rm9jdXNlZGAgY2FuIGJlIHVzZWQgdG8gbWFudWFsbHkgc2V0IHRoZSBmb2N1cyBzdGF0ZS4gU2V0IGB1bmRlZmluZWRgXG5cdCogdG8gZmFsbCBiYWNrIHRvIHRoZSBkZWZhdWx0IGZvY3VzIGNoZWNrLlxuXHQqIEBwYXJhbSBmb2N1c2VkIC0gVGhlIGZvY3VzIHN0YXRlLCBvciBgdW5kZWZpbmVkYCB0byB1c2UgdGhlIGRlZmF1bHQgZm9jdXMgY2hlY2suXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IGZvY3VzTWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogLy8gU2V0IGZvY3VzZWRcblx0KiBmb2N1c01hbmFnZXIuc2V0Rm9jdXNlZCh0cnVlKVxuXHQqXG5cdCogLy8gU2V0IHVuZm9jdXNlZFxuXHQqIGZvY3VzTWFuYWdlci5zZXRGb2N1c2VkKGZhbHNlKVxuXHQqXG5cdCogLy8gRmFsbGJhY2sgdG8gdGhlIGRlZmF1bHQgZm9jdXMgY2hlY2tcblx0KiBmb2N1c01hbmFnZXIuc2V0Rm9jdXNlZCh1bmRlZmluZWQpXG5cdCogYGBgXG5cdCovXG5cdHNldEZvY3VzZWQoZm9jdXNlZCkge1xuXHRcdGlmICh0aGlzLiNmb2N1c2VkICE9PSBmb2N1c2VkKSB7XG5cdFx0XHR0aGlzLiNmb2N1c2VkID0gZm9jdXNlZDtcblx0XHRcdHRoaXMub25Gb2N1cygpO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBgb25Gb2N1c2Agbm90aWZpZXMgYWxsIHN1YnNjcmliZWQgbGlzdGVuZXJzIHdpdGggdGhlIGN1cnJlbnQgZm9jdXMgc3RhdGUuXG5cdCovXG5cdG9uRm9jdXMoKSB7XG5cdFx0Y29uc3QgaXNGb2N1c2VkID0gdGhpcy5pc0ZvY3VzZWQoKTtcblx0XHR0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuXHRcdFx0bGlzdGVuZXIoaXNGb2N1c2VkKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBgaXNGb2N1c2VkYCBjYW4gYmUgdXNlZCB0byBnZXQgdGhlIGN1cnJlbnQgZm9jdXMgc3RhdGUuXG5cdCogQHJldHVybnMgVGhlIGZvY3VzIHN0YXRlIHNldCB3aXRoIGBzZXRGb2N1c2VkYCwgb3Igb3RoZXJ3aXNlIHdoZXRoZXIgdGhlIGRvY3VtZW50IGlzIHZpc2libGUuXG5cdCovXG5cdGlzRm9jdXNlZCgpIHtcblx0XHRpZiAodHlwZW9mIHRoaXMuI2ZvY3VzZWQgPT09IFwiYm9vbGVhblwiKSByZXR1cm4gdGhpcy4jZm9jdXNlZDtcblx0XHRyZXR1cm4gZ2xvYmFsVGhpcy5kb2N1bWVudD8udmlzaWJpbGl0eVN0YXRlICE9PSBcImhpZGRlblwiO1xuXHR9XG59O1xuLyoqXG4qIFNpbmdsZXRvbiBpbnN0YW5jZSBvZiB7QGxpbmsgRm9jdXNNYW5hZ2VyfSwgdXNlZCB0byBtYW5hZ2UgYW5kIG9ic2VydmUgdGhlIGZvY3VzIHN0YXRlIHdpdGhpbiBUYW5TdGFjayBRdWVyeS5cbiovXG5jb25zdCBmb2N1c01hbmFnZXIgPSBuZXcgRm9jdXNNYW5hZ2VyKCk7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEZvY3VzTWFuYWdlciwgZm9jdXNNYW5hZ2VyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWZvY3VzTWFuYWdlci5qcy5tYXAiLCJpbXBvcnQgeyBub29wIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vI3JlZ2lvbiBzcmMvaHlkcmF0aW9uLnRzXG4vKipcbiogUmVhZHMgdGhlIHZhbHVlIG9mIGEgcHJvbWlzZSBzeW5jaHJvbm91c2x5IGlmIGl0IGhhcyBhbHJlYWR5IHJlc29sdmVkLCBlLmcuIGEgdGhlbmFibGUgdGhhdFxuKiByZXNvbHZlcyB3aXRoaW4gaXRzIGB0aGVuYCBjYWxsLlxuKiBAcGFyYW0gcHJvbWlzZSAtIFRoZSBwcm9taXNlIHRvIHJlYWQuXG4qIEByZXR1cm5zIEFuIG9iamVjdCB3aXRoIHRoZSByZXNvbHZlZCBgZGF0YWAsIG9yIGB1bmRlZmluZWRgIGlmIHRoZSBwcm9taXNlIGhhc24ndCByZXNvbHZlZFxuKiBzeW5jaHJvbm91c2x5IChvciByZXNvbHZlZCB3aXRoIGB1bmRlZmluZWRgKS5cbiovXG5mdW5jdGlvbiB0cnlSZXNvbHZlU3luYyhwcm9taXNlKSB7XG5cdGxldCBkYXRhO1xuXHRwcm9taXNlLnRoZW4oKHJlc3VsdCkgPT4ge1xuXHRcdGRhdGEgPSByZXN1bHQ7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fSwgbm9vcCk/LmNhdGNoPy4obm9vcCk7XG5cdGlmIChkYXRhICE9PSB2b2lkIDApIHJldHVybiB7IGRhdGEgfTtcbn1cbi8qKlxuKiBEZWh5ZHJhdGVzIGEgc2luZ2xlIGBNdXRhdGlvbmAgaW50byBhIHNlcmlhbGl6YWJsZSBzbmFwc2hvdCBvZiBpdHMga2V5LCBzdGF0ZSwgc2NvcGUsIGFuZCBtZXRhLlxuKiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdG8gZGVoeWRyYXRlLlxuKiBAcmV0dXJucyBUaGUgZGVoeWRyYXRlZCBtdXRhdGlvbi5cbiovXG5mdW5jdGlvbiBkZWh5ZHJhdGVNdXRhdGlvbihtdXRhdGlvbikge1xuXHRyZXR1cm4ge1xuXHRcdG11dGF0aW9uS2V5OiBtdXRhdGlvbi5vcHRpb25zLm11dGF0aW9uS2V5LFxuXHRcdHN0YXRlOiBtdXRhdGlvbi5zdGF0ZSxcblx0XHQuLi5tdXRhdGlvbi5vcHRpb25zLnNjb3BlICYmIHsgc2NvcGU6IG11dGF0aW9uLm9wdGlvbnMuc2NvcGUgfSxcblx0XHQuLi5tdXRhdGlvbi5tZXRhICYmIHsgbWV0YTogbXV0YXRpb24ubWV0YSB9XG5cdH07XG59XG4vKipcbiogUHJlcGFyZXMgdGhlIGluLWZsaWdodCBwcm9taXNlIG9mIGEgcGVuZGluZyBxdWVyeSBmb3IgZGVoeWRyYXRpb246IGFwcGxpZXMgYHNlcmlhbGl6ZURhdGFgIHRvIGl0c1xuKiByZXN1bHQsIGFuZCByZWRhY3RzIGl0cyByZWplY3Rpb24gZXJyb3IgdW5sZXNzIGBzaG91bGRSZWRhY3RFcnJvcnNgIHJldHVybnMgYGZhbHNlYCBmb3IgaXQuXG4qIEBwYXJhbSBxdWVyeSAtIFRoZSBwZW5kaW5nIHF1ZXJ5IHdob3NlIHByb21pc2UgaXMgZGVoeWRyYXRlZC5cbiogQHBhcmFtIHNlcmlhbGl6ZURhdGEgLSBPcHRpb25hbCB0cmFuc2Zvcm0gYXBwbGllZCB0byB0aGUgcmVzb2x2ZWQgZGF0YS5cbiogQHBhcmFtIHNob3VsZFJlZGFjdEVycm9ycyAtIE9wdGlvbmFsIHByZWRpY2F0ZTsgaWYgaXQgcmV0dXJucyBgZmFsc2VgIGZvciB0aGUgcmVqZWN0aW9uIGVycm9yLFxuKiB0aGF0XG4qIGVycm9yIGlzIGtlcHQgYXMtaXMgaW5zdGVhZCBvZiBiZWluZyByZWRhY3RlZC5cbiogQHJldHVybnMgVGhlIHRyYW5zZm9ybWVkIHByb21pc2UsIG9yIGB1bmRlZmluZWRgIGlmIHRoZSBxdWVyeSBoYXMgbm8gaW4tZmxpZ2h0IHByb21pc2UuXG4qL1xuZnVuY3Rpb24gZGVoeWRyYXRlUHJvbWlzZShxdWVyeSwgc2VyaWFsaXplRGF0YSwgc2hvdWxkUmVkYWN0RXJyb3JzKSB7XG5cdGNvbnN0IHByb21pc2UgPSBxdWVyeS5wcm9taXNlPy50aGVuKHNlcmlhbGl6ZURhdGEpLmNhdGNoKChlcnJvcikgPT4ge1xuXHRcdGlmIChzaG91bGRSZWRhY3RFcnJvcnM/LihlcnJvcikgPT09IGZhbHNlKSByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNvbnNvbGUuZXJyb3IoYEEgcXVlcnkgdGhhdCB3YXMgZGVoeWRyYXRlZCBhcyBwZW5kaW5nIGVuZGVkIHVwIHJlamVjdGluZy4gWyR7cXVlcnkucXVlcnlIYXNofV06ICR7ZXJyb3J9OyBUaGUgZXJyb3Igd2lsbCBiZSByZWRhY3RlZCBpbiBwcm9kdWN0aW9uIGJ1aWxkc2ApO1xuXHRcdHJldHVybiBQcm9taXNlLnJlamVjdCgvKiBAX19QVVJFX18gKi8gbmV3IEVycm9yKFwicmVkYWN0ZWRcIikpO1xuXHR9KTtcblx0cHJvbWlzZT8uY2F0Y2gobm9vcCk7XG5cdHJldHVybiBwcm9taXNlO1xufVxuLyoqXG4qIERlaHlkcmF0ZXMgYSBzaW5nbGUgYFF1ZXJ5YCBpbnRvIGEgc2VyaWFsaXphYmxlIGBEZWh5ZHJhdGVkUXVlcnlgIHNuYXBzaG90LiBOb3RlIHRoYXQgbW9zdCBxdWVyeSBjb25maWcgKGUuZy5cbiogYHF1ZXJ5Rm5gLCBgc3RhbGVUaW1lYCkgaXMgbm90IGRlaHlkcmF0ZWQgYnV0IGluc3RlYWQgbWVhbnQgdG8gYmUgY29uZmlndXJlZCBhZ2FpbiB3aGVuIGNvbnN1bWluZyB0aGVcbiogZGUvcmVoeWRyYXRlZCBkYXRhLCB0eXBpY2FsbHkgd2l0aCBgdXNlUXVlcnlgIG9uIHRoZSBjbGllbnQuIElmIHRoZSBxdWVyeSBpcyBzdGlsbCBgcGVuZGluZ2AsIGl0cyBpbi1mbGlnaHRcbiogcHJvbWlzZSBpcyBkZWh5ZHJhdGVkIHRvbyBzbyBpdCBjYW4gYmUgcmVzdW1lZCBvbiB0aGUgb3RoZXIgc2lkZSBpbnN0ZWFkIG9mIHJlLWZldGNoZWQuXG4qIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSB0byBkZWh5ZHJhdGUuXG4qIEBwYXJhbSBzZXJpYWxpemVEYXRhIC0gT3B0aW9uYWwgdHJhbnNmb3JtIGFwcGxpZWQgdG8gYHF1ZXJ5LnN0YXRlLmRhdGFgIGJlZm9yZSBpdCBpcyBpbmNsdWRlZCBpbiB0aGUgc25hcHNob3QuXG4qIEBwYXJhbSBzaG91bGRSZWRhY3RFcnJvcnMgLSBPcHRpb25hbCBwcmVkaWNhdGU7IGlmIGl0IHJldHVybnMgYGZhbHNlYCBmb3IgdGhlIHByb21pc2UncyByZWplY3Rpb24gZXJyb3IsIHRoYXRcbiogZXJyb3IgaXMga2VwdCBhcy1pcyBpbnN0ZWFkIG9mIGJlaW5nIHJlZGFjdGVkLlxuKiBAcmV0dXJucyBUaGUgZGVoeWRyYXRlZCBxdWVyeS5cbiovXG5mdW5jdGlvbiBkZWh5ZHJhdGVRdWVyeShxdWVyeSwgc2VyaWFsaXplRGF0YSwgc2hvdWxkUmVkYWN0RXJyb3JzKSB7XG5cdHJldHVybiB7XG5cdFx0ZGVoeWRyYXRlZEF0OiBEYXRlLm5vdygpLFxuXHRcdHN0YXRlOiB7XG5cdFx0XHQuLi5xdWVyeS5zdGF0ZSxcblx0XHRcdC4uLnF1ZXJ5LnN0YXRlLmRhdGEgIT09IHZvaWQgMCAmJiB7IGRhdGE6IHNlcmlhbGl6ZURhdGEgPyBzZXJpYWxpemVEYXRhKHF1ZXJ5LnN0YXRlLmRhdGEpIDogcXVlcnkuc3RhdGUuZGF0YSB9XG5cdFx0fSxcblx0XHRxdWVyeUtleTogcXVlcnkucXVlcnlLZXksXG5cdFx0cXVlcnlIYXNoOiBxdWVyeS5xdWVyeUhhc2gsXG5cdFx0Li4ucXVlcnkuc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiB7IHByb21pc2U6IGRlaHlkcmF0ZVByb21pc2UocXVlcnksIHNlcmlhbGl6ZURhdGEsIHNob3VsZFJlZGFjdEVycm9ycykgfSxcblx0XHQuLi5xdWVyeS5tZXRhICYmIHsgbWV0YTogcXVlcnkubWV0YSB9LFxuXHRcdC4uLnF1ZXJ5LnF1ZXJ5VHlwZSAmJiB7IHF1ZXJ5VHlwZTogcXVlcnkucXVlcnlUeXBlIH1cblx0fTtcbn1cbi8qKlxuKiBUaGUgZGVmYXVsdCBgc2hvdWxkRGVoeWRyYXRlTXV0YXRpb25gIHByZWRpY2F0ZSB1c2VkIGJ5IGBkZWh5ZHJhdGVgLiBPbmx5IGRlaHlkcmF0ZXMgbXV0YXRpb25zIHRoYXQgYXJlXG4qIGN1cnJlbnRseSBwYXVzZWQgKGUuZy4gcGF1c2VkIGJ5IGBuZXR3b3JrTW9kZWAgd2hpbGUgb2ZmbGluZSkuXG4qIEBwYXJhbSBtdXRhdGlvbiAtIFRoZSBtdXRhdGlvbiB0byBjaGVjay5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBtdXRhdGlvbiBpcyBwYXVzZWQuXG4qL1xuZnVuY3Rpb24gZGVmYXVsdFNob3VsZERlaHlkcmF0ZU11dGF0aW9uKG11dGF0aW9uKSB7XG5cdHJldHVybiBtdXRhdGlvbi5zdGF0ZS5pc1BhdXNlZDtcbn1cbi8qKlxuKiBUaGUgZGVmYXVsdCBgc2hvdWxkRGVoeWRyYXRlUXVlcnlgIHByZWRpY2F0ZSB1c2VkIGJ5IGBkZWh5ZHJhdGVgLiBPbmx5IGRlaHlkcmF0ZXMgcXVlcmllcyB3aG9zZSBzdGF0dXMgaXNcbiogYCdzdWNjZXNzJ2AuXG4qIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSB0byBjaGVjay5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSdzIHN0YXR1cyBpcyBgJ3N1Y2Nlc3MnYC5cbiovXG5mdW5jdGlvbiBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlUXVlcnkocXVlcnkpIHtcblx0cmV0dXJuIHF1ZXJ5LnN0YXRlLnN0YXR1cyA9PT0gXCJzdWNjZXNzXCI7XG59XG4vKipcbiogRGVoeWRyYXRlcyBhIGBRdWVyeUNsaWVudGAncyBjYWNoZSAocXVlcmllcyBhbmQgbXV0YXRpb25zKSBpbnRvIGEgcGxhaW4sIHNlcmlhbGl6YWJsZSBgRGVoeWRyYXRlZFN0YXRlYCxcbiogdHlwaWNhbGx5IHRvIGVtYmVkIGluIHNlcnZlci1yZW5kZXJlZCBtYXJrdXAgYW5kIGxhdGVyIHJlc3RvcmUgaW50byBhIGNsaWVudC1zaWRlIGBRdWVyeUNsaWVudGAgdmlhIGBoeWRyYXRlYC5cbiogV2hpY2ggcXVlcmllcy9tdXRhdGlvbnMgYXJlIGluY2x1ZGVkLCBhbmQgaG93IHRoZWlyIGRhdGEvZXJyb3JzIGFyZSB0cmFuc2Zvcm1lZCwgaXMgY29udHJvbGxlZCBieSBgb3B0aW9uc2AsXG4qIGZhbGxpbmcgYmFjayB0byB0aGUgY2xpZW50J3MgYGRlaHlkcmF0ZWAgZGVmYXVsdCBvcHRpb25zLCBhbmQgZmluYWxseSB0byBgZGVmYXVsdFNob3VsZERlaHlkcmF0ZVF1ZXJ5YCAvXG4qIGBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlTXV0YXRpb25gLlxuKiBAcGFyYW0gY2xpZW50IC0gVGhlIGNsaWVudCB3aG9zZSBjYWNoZSBpcyBkZWh5ZHJhdGVkLlxuKiBAcGFyYW0gb3B0aW9ucyAtIENvbnRyb2xzIHdoaWNoIHF1ZXJpZXMgYW5kIG11dGF0aW9ucyBhcmUgaW5jbHVkZWQgYW5kIGhvdyB0aGVpciBkYXRhIGFuZCBlcnJvcnNcbiogYXJlIHRyYW5zZm9ybWVkLiBFYWNoIG9wdGlvbiBmYWxscyBiYWNrIHRvIHRoZSBjbGllbnQncyBgZGVmYXVsdE9wdGlvbnMuZGVoeWRyYXRlYC5cbiogQHJldHVybnMgVGhlIGRlaHlkcmF0ZWQgc3RhdGUsIHdpdGggdGhlIGluY2x1ZGVkIGBxdWVyaWVzYCBhbmQgYG11dGF0aW9uc2AuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcbipcbiogYXdhaXQgcXVlcnlDbGllbnQucHJlZmV0Y2hRdWVyeSh7XG4qICAgcXVlcnlLZXk6IFsncG9zdHMnXSxcbiogICBxdWVyeUZuOiBnZXRQb3N0cyxcbiogfSlcbipcbiogY29uc3QgZGVoeWRyYXRlZFN0YXRlID0gZGVoeWRyYXRlKHF1ZXJ5Q2xpZW50KVxuKiBgYGBcbiovXG5mdW5jdGlvbiBkZWh5ZHJhdGUoY2xpZW50LCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgZmlsdGVyTXV0YXRpb24gPSBvcHRpb25zLnNob3VsZERlaHlkcmF0ZU11dGF0aW9uID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmRlaHlkcmF0ZT8uc2hvdWxkRGVoeWRyYXRlTXV0YXRpb24gPz8gZGVmYXVsdFNob3VsZERlaHlkcmF0ZU11dGF0aW9uO1xuXHRjb25zdCBtdXRhdGlvbnMgPSBjbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpLmdldEFsbCgpLmZsYXRNYXAoKG11dGF0aW9uKSA9PiBmaWx0ZXJNdXRhdGlvbihtdXRhdGlvbikgPyBbZGVoeWRyYXRlTXV0YXRpb24obXV0YXRpb24pXSA6IFtdKTtcblx0Y29uc3QgZmlsdGVyUXVlcnkgPSBvcHRpb25zLnNob3VsZERlaHlkcmF0ZVF1ZXJ5ID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmRlaHlkcmF0ZT8uc2hvdWxkRGVoeWRyYXRlUXVlcnkgPz8gZGVmYXVsdFNob3VsZERlaHlkcmF0ZVF1ZXJ5O1xuXHRjb25zdCBzaG91bGRSZWRhY3RFcnJvcnMgPSBvcHRpb25zLnNob3VsZFJlZGFjdEVycm9ycyA/PyBjbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5kZWh5ZHJhdGU/LnNob3VsZFJlZGFjdEVycm9ycztcblx0Y29uc3Qgc2VyaWFsaXplRGF0YSA9IG9wdGlvbnMuc2VyaWFsaXplRGF0YSA/PyBjbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5kZWh5ZHJhdGU/LnNlcmlhbGl6ZURhdGE7XG5cdHJldHVybiB7XG5cdFx0bXV0YXRpb25zLFxuXHRcdHF1ZXJpZXM6IGNsaWVudC5nZXRRdWVyeUNhY2hlKCkuZ2V0QWxsKCkuZmxhdE1hcCgocXVlcnkpID0+IGZpbHRlclF1ZXJ5KHF1ZXJ5KSA/IFtkZWh5ZHJhdGVRdWVyeShxdWVyeSwgc2VyaWFsaXplRGF0YSwgc2hvdWxkUmVkYWN0RXJyb3JzKV0gOiBbXSlcblx0fTtcbn1cbi8qKlxuKiBSZXN0b3JlcyBhIGBEZWh5ZHJhdGVkU3RhdGVgIChhcyBwcm9kdWNlZCBieSBgZGVoeWRyYXRlYCkgaW50byBhIGBRdWVyeUNsaWVudGAncyBjYWNoZSwgdHlwaWNhbGx5IHRvIHNlZWQgdGhlXG4qIGNsaWVudCB3aXRoIGRhdGEgYWxyZWFkeSBmZXRjaGVkIG9uIHRoZSBzZXJ2ZXIuIGBtdXRhdGlvbnNgIGFuZCBgcXVlcmllc2AgYXJlIGVhY2ggb3B0aW9uYWwgb24gYGRlaHlkcmF0ZWRTdGF0ZWAuXG4qIFF1ZXJpZXMgbm90IHlldCBpbiB0aGUgY2FjaGUgYXJlIGJ1aWx0IGZyb20gdGhlIGRlaHlkcmF0ZWQgc25hcHNob3Q7IHF1ZXJpZXMgdGhhdCBhbHJlYWR5IGV4aXN0IGFyZSBvbmx5IHVwZGF0ZWRcbiogd2hlbiB0aGUgZGVoeWRyYXRlZCBkYXRhIGlzIG5ld2VyIHRoYW4gd2hhdCdzIGFscmVhZHkgY2FjaGVkLiBOZXdseSBidWlsdCBxdWVyaWVzIGhhdmUgdGhlaXIgYGZldGNoU3RhdHVzYCByZXNldFxuKiB0byBgJ2lkbGUnYCBzbyB0aGV5IGRvbid0IGh5ZHJhdGUgc3R1Y2sgaW4gYSBmZXRjaGluZyBzdGF0ZS4gSWYgYSBkZWh5ZHJhdGVkIHF1ZXJ5IHN0aWxsIGhhZCBhbiBpbi1mbGlnaHRcbiogcHJvbWlzZSwgaXQgaXMgcmVzdW1lZCB2aWEgYHF1ZXJ5LmZldGNoKClgIChyZXVzaW5nIHRoYXQgcHJvbWlzZSBhcyBgaW5pdGlhbFByb21pc2VgKSByYXRoZXIgdGhhbiByZS1pbnZva2luZ1xuKiBgcXVlcnlGbmAuXG4qIEBwYXJhbSBjbGllbnQgLSBUaGUgY2xpZW50IHdob3NlIGNhY2hlIGlzIHJlc3RvcmVkIGludG8uXG4qIEBwYXJhbSBkZWh5ZHJhdGVkU3RhdGUgLSBUaGUgZGVoeWRyYXRlZCBzdGF0ZSwgZS5nLiBwcm9kdWNlZCBieSBgZGVoeWRyYXRlYCBvbiB0aGUgc2VydmVyLlxuKiBAcGFyYW0gb3B0aW9ucyAtIGBkZWZhdWx0T3B0aW9uc2AgbWVyZ2VkIGludG8gZXZlcnkgcmVzdG9yZWQgcXVlcnkgYW5kIG11dGF0aW9uIChvbiB0b3Agb2YgdGhlXG4qIGNsaWVudCdzIGBkZWZhdWx0T3B0aW9ucy5oeWRyYXRlYCksIGFuZCBgZGVzZXJpYWxpemVEYXRhYCB0byByZXZlcnNlIGBzZXJpYWxpemVEYXRhYC5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogLy8gZGVoeWRyYXRlZFN0YXRlIHdhcyBwcm9kdWNlZCBieSBgZGVoeWRyYXRlYCBvbiB0aGUgc2VydmVyXG4qIC8vIGFuZCBzZW50IHRvIHRoZSBjbGllbnQsIGUuZy4gZW1iZWRkZWQgaW4gc2VydmVyLXJlbmRlcmVkIG1hcmt1cC5cbiogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuKlxuKiBoeWRyYXRlKHF1ZXJ5Q2xpZW50LCBkZWh5ZHJhdGVkU3RhdGUpXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGh5ZHJhdGUoY2xpZW50LCBkZWh5ZHJhdGVkU3RhdGUsIG9wdGlvbnMpIHtcblx0Y29uc3QgbXV0YXRpb25DYWNoZSA9IGNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKCk7XG5cdGNvbnN0IHF1ZXJ5Q2FjaGUgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuXHRjb25zdCBkZXNlcmlhbGl6ZURhdGEgPSBvcHRpb25zPy5kZWZhdWx0T3B0aW9ucz8uZGVzZXJpYWxpemVEYXRhID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmh5ZHJhdGU/LmRlc2VyaWFsaXplRGF0YTtcblx0ZGVoeWRyYXRlZFN0YXRlLm11dGF0aW9ucz8uZm9yRWFjaCgoeyBzdGF0ZSwgLi4ubXV0YXRpb25PcHRpb25zIH0pID0+IHtcblx0XHRtdXRhdGlvbkNhY2hlLmJ1aWxkKGNsaWVudCwge1xuXHRcdFx0Li4uY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuaHlkcmF0ZT8ubXV0YXRpb25zLFxuXHRcdFx0Li4ub3B0aW9ucz8uZGVmYXVsdE9wdGlvbnM/Lm11dGF0aW9ucyxcblx0XHRcdC4uLm11dGF0aW9uT3B0aW9uc1xuXHRcdH0sIHN0YXRlKTtcblx0fSk7XG5cdGRlaHlkcmF0ZWRTdGF0ZS5xdWVyaWVzPy5mb3JFYWNoKCh7IHF1ZXJ5S2V5LCBzdGF0ZSwgcXVlcnlIYXNoLCBtZXRhLCBwcm9taXNlLCBkZWh5ZHJhdGVkQXQsIHF1ZXJ5VHlwZSB9KSA9PiB7XG5cdFx0Y29uc3Qgc3luY0RhdGEgPSBwcm9taXNlID8gdHJ5UmVzb2x2ZVN5bmMocHJvbWlzZSkgOiB2b2lkIDA7XG5cdFx0Y29uc3QgcmF3RGF0YSA9IHN0YXRlLmRhdGEgPT09IHZvaWQgMCA/IHN5bmNEYXRhPy5kYXRhIDogc3RhdGUuZGF0YTtcblx0XHRjb25zdCBkYXRhID0gcmF3RGF0YSA9PT0gdm9pZCAwID8gcmF3RGF0YSA6IGRlc2VyaWFsaXplRGF0YSA/IGRlc2VyaWFsaXplRGF0YShyYXdEYXRhKSA6IHJhd0RhdGE7XG5cdFx0bGV0IHF1ZXJ5ID0gcXVlcnlDYWNoZS5nZXQocXVlcnlIYXNoKTtcblx0XHRjb25zdCBleGlzdGluZ1F1ZXJ5SXNQZW5kaW5nID0gcXVlcnk/LnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCI7XG5cdFx0Y29uc3QgZXhpc3RpbmdRdWVyeUlzRmV0Y2hpbmcgPSBxdWVyeT8uc3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwiZmV0Y2hpbmdcIjtcblx0XHRpZiAocXVlcnkpIHtcblx0XHRcdGNvbnN0IGhhc05ld2VyU3luY0RhdGEgPSBzeW5jRGF0YSAmJiBkZWh5ZHJhdGVkQXQgPiBxdWVyeS5zdGF0ZS5kYXRhVXBkYXRlZEF0O1xuXHRcdFx0aWYgKHN0YXRlLmRhdGFVcGRhdGVkQXQgPiBxdWVyeS5zdGF0ZS5kYXRhVXBkYXRlZEF0IHx8IGhhc05ld2VyU3luY0RhdGEpIHtcblx0XHRcdFx0Y29uc3QgeyBmZXRjaFN0YXR1czogX2lnbm9yZWQsIC4uLnNlcmlhbGl6ZWRTdGF0ZSB9ID0gc3RhdGU7XG5cdFx0XHRcdHF1ZXJ5LnNldFN0YXRlKHtcblx0XHRcdFx0XHQuLi5zZXJpYWxpemVkU3RhdGUsXG5cdFx0XHRcdFx0ZGF0YSxcblx0XHRcdFx0XHQuLi5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmIGRhdGEgIT09IHZvaWQgMCAmJiB7XG5cdFx0XHRcdFx0XHRzdGF0dXM6IFwic3VjY2Vzc1wiLFxuXHRcdFx0XHRcdFx0ZGF0YVVwZGF0ZWRBdDogZGVoeWRyYXRlZEF0LFxuXHRcdFx0XHRcdFx0Li4uIWV4aXN0aW5nUXVlcnlJc0ZldGNoaW5nICYmIHsgZmV0Y2hTdGF0dXM6IFwiaWRsZVwiIH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSBxdWVyeSA9IHF1ZXJ5Q2FjaGUuYnVpbGQoY2xpZW50LCB7XG5cdFx0XHQuLi5jbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5oeWRyYXRlPy5xdWVyaWVzLFxuXHRcdFx0Li4ub3B0aW9ucz8uZGVmYXVsdE9wdGlvbnM/LnF1ZXJpZXMsXG5cdFx0XHRxdWVyeUtleSxcblx0XHRcdHF1ZXJ5SGFzaCxcblx0XHRcdG1ldGEsXG5cdFx0XHRfdHlwZTogcXVlcnlUeXBlXG5cdFx0fSwge1xuXHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRkYXRhLFxuXHRcdFx0ZmV0Y2hTdGF0dXM6IFwiaWRsZVwiLFxuXHRcdFx0c3RhdHVzOiBzdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmIGRhdGEgIT09IHZvaWQgMCA/IFwic3VjY2Vzc1wiIDogc3RhdGUuc3RhdHVzLFxuXHRcdFx0Li4uc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiBkYXRhICE9PSB2b2lkIDAgJiYgeyBkYXRhVXBkYXRlZEF0OiBkZWh5ZHJhdGVkQXQgfVxuXHRcdH0pO1xuXHRcdGlmIChwcm9taXNlICYmICFzeW5jRGF0YSAmJiAhZXhpc3RpbmdRdWVyeUlzUGVuZGluZyAmJiAhZXhpc3RpbmdRdWVyeUlzRmV0Y2hpbmcgJiYgZGVoeWRyYXRlZEF0ID4gcXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCkgcXVlcnkuZmV0Y2godm9pZCAwLCB7IGluaXRpYWxQcm9taXNlOiBQcm9taXNlLnJlc29sdmUocHJvbWlzZSkudGhlbihkZXNlcmlhbGl6ZURhdGEpIH0pLmNhdGNoKG5vb3ApO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZGVmYXVsdFNob3VsZERlaHlkcmF0ZU11dGF0aW9uLCBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlUXVlcnksIGRlaHlkcmF0ZSwgZGVoeWRyYXRlUXVlcnksIGh5ZHJhdGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aHlkcmF0aW9uLmpzLm1hcCIsImltcG9ydCB7IHN5c3RlbVNldFRpbWVvdXRaZXJvIH0gZnJvbSBcIi4vdGltZW91dE1hbmFnZXIuanNcIjtcbi8vI3JlZ2lvbiBzcmMvbm90aWZ5TWFuYWdlci50c1xuLyoqXG4qIERlZmF1bHQgc2NoZWR1bGluZyBmdW5jdGlvbiB1c2VkIGJ5IHRoZSBub3RpZnkgbWFuYWdlci5cbiogU2NoZWR1bGVzIHRoZSBjYWxsYmFjayB3aXRoIHRoZSBzeXN0ZW0ncyBgc2V0VGltZW91dChjYWxsYmFjaywgMClgLlxuKi9cbmNvbnN0IGRlZmF1bHRTY2hlZHVsZXIgPSBzeXN0ZW1TZXRUaW1lb3V0WmVybztcbi8qKlxuKiBDcmVhdGVzIGEgbm90aWZ5IG1hbmFnZXIsIHdoaWNoIHNjaGVkdWxlcyBhbmQgYmF0Y2hlcyBub3RpZmljYXRpb25zIHRvIHN1YnNjcmliZXJzLiBRdWVyeSB1c2VzIGFcbiogc2luZ2xlIGluc3RhbmNlIG9mIGl0LCBleHBvcnRlZCBhcyB7QGxpbmsgbm90aWZ5TWFuYWdlcn0uXG4qIEByZXR1cm5zIEEgbmV3IG5vdGlmeSBtYW5hZ2VyLlxuKi9cbmZ1bmN0aW9uIGNyZWF0ZU5vdGlmeU1hbmFnZXIoKSB7XG5cdGxldCBxdWV1ZSA9IFtdO1xuXHRsZXQgdHJhbnNhY3Rpb25zID0gMDtcblx0bGV0IG5vdGlmeUZuID0gKGNhbGxiYWNrKSA9PiB7XG5cdFx0Y2FsbGJhY2soKTtcblx0fTtcblx0bGV0IGJhdGNoTm90aWZ5Rm4gPSAoY2FsbGJhY2spID0+IHtcblx0XHRjYWxsYmFjaygpO1xuXHR9O1xuXHRsZXQgc2NoZWR1bGVGbiA9IGRlZmF1bHRTY2hlZHVsZXI7XG5cdGNvbnN0IHNjaGVkdWxlID0gKGNhbGxiYWNrKSA9PiB7XG5cdFx0aWYgKHRyYW5zYWN0aW9ucykgcXVldWUucHVzaChjYWxsYmFjayk7XG5cdFx0ZWxzZSBzY2hlZHVsZUZuKCgpID0+IHtcblx0XHRcdG5vdGlmeUZuKGNhbGxiYWNrKTtcblx0XHR9KTtcblx0fTtcblx0Y29uc3QgZmx1c2ggPSAoKSA9PiB7XG5cdFx0Y29uc3Qgb3JpZ2luYWxRdWV1ZSA9IHF1ZXVlO1xuXHRcdHF1ZXVlID0gW107XG5cdFx0aWYgKG9yaWdpbmFsUXVldWUubGVuZ3RoKSBzY2hlZHVsZUZuKCgpID0+IHtcblx0XHRcdGJhdGNoTm90aWZ5Rm4oKCkgPT4ge1xuXHRcdFx0XHRvcmlnaW5hbFF1ZXVlLmZvckVhY2goKGNhbGxiYWNrKSA9PiB7XG5cdFx0XHRcdFx0bm90aWZ5Rm4oY2FsbGJhY2spO1xuXHRcdFx0XHR9KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdC8qKlxuXHRcdCogQmF0Y2hlcyBhbGwgdXBkYXRlcyBzY2hlZHVsZWQgaW5zaWRlIHRoZSBwYXNzZWQgY2FsbGJhY2suXG5cdFx0KiBUaGlzIGlzIG1haW5seSB1c2VkIGludGVybmFsbHkgdG8gb3B0aW1pemUgcXVlcnkgY2xpZW50IHVwZGF0aW5nLlxuXHRcdCogQmF0Y2hlcyBjYW4gYmUgbmVzdGVkOyB0aGUgcXVldWUgaXMgb25seSBmbHVzaGVkIG9uY2UgdGhlIG91dGVybW9zdCBgYmF0Y2hgIGNhbGwgZmluaXNoZXMuXG5cdFx0KiBUaGUgcmV0dXJuIHZhbHVlIG9mIGBjYWxsYmFja2AgaXMgcGFzc2VkIHRocm91Z2guXG5cdFx0KiBAcGFyYW0gY2FsbGJhY2sgLSBUaGUgZnVuY3Rpb24gdG8gcnVuIGluIHRoZSBiYXRjaC5cblx0XHQqIEByZXR1cm5zIFRoZSByZXR1cm4gdmFsdWUgb2YgYGNhbGxiYWNrYC5cblx0XHQqL1xuXHRcdGJhdGNoOiAoY2FsbGJhY2spID0+IHtcblx0XHRcdGxldCByZXN1bHQ7XG5cdFx0XHR0cmFuc2FjdGlvbnMrKztcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHJlc3VsdCA9IGNhbGxiYWNrKCk7XG5cdFx0XHR9IGZpbmFsbHkge1xuXHRcdFx0XHR0cmFuc2FjdGlvbnMtLTtcblx0XHRcdFx0aWYgKCF0cmFuc2FjdGlvbnMpIGZsdXNoKCk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdH0sXG5cdFx0LyoqXG5cdFx0KiBBbGwgY2FsbHMgdG8gdGhlIHdyYXBwZWQgZnVuY3Rpb24gd2lsbCBiZSBiYXRjaGVkLlxuXHRcdCogQHBhcmFtIGNhbGxiYWNrIC0gVGhlIGZ1bmN0aW9uIHRvIHdyYXAuXG5cdFx0KiBAcmV0dXJucyBBIGZ1bmN0aW9uIHRoYXQgc2NoZWR1bGVzIGEgY2FsbCB0byBgY2FsbGJhY2tgIHdpdGggdGhlIGdpdmVuIGFyZ3VtZW50cy5cblx0XHQqL1xuXHRcdGJhdGNoQ2FsbHM6IChjYWxsYmFjaykgPT4ge1xuXHRcdFx0cmV0dXJuICguLi5hcmdzKSA9PiB7XG5cdFx0XHRcdHNjaGVkdWxlKCgpID0+IHtcblx0XHRcdFx0XHRjYWxsYmFjayguLi5hcmdzKTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9O1xuXHRcdH0sXG5cdFx0LyoqXG5cdFx0KiBTY2hlZHVsZXMgYSBmdW5jdGlvbiB0byBiZSBydW4gb24gdGhlIG5leHQgYmF0Y2guXG5cdFx0KiBCeSBkZWZhdWx0LCB0aGUgYmF0Y2ggaXMgcnVuIHdpdGggYSBgc2V0VGltZW91dGAsIGJ1dCB0aGlzIGNhbiBiZSBjb25maWd1cmVkIHZpYSBgc2V0U2NoZWR1bGVyYC5cblx0XHQqL1xuXHRcdHNjaGVkdWxlLFxuXHRcdC8qKlxuXHRcdCogVXNlIHRoaXMgbWV0aG9kIHRvIHNldCBhIGN1c3RvbSBub3RpZnkgZnVuY3Rpb24uXG5cdFx0KiBUaGlzIGNhbiBiZSB1c2VkIHRvIGZvciBleGFtcGxlIHdyYXAgbm90aWZpY2F0aW9ucyB3aXRoIGBSZWFjdC5hY3RgIHdoaWxlIHJ1bm5pbmcgdGVzdHMuXG5cdFx0KiBAcGFyYW0gZm4gLSBSZWNlaXZlcyBlYWNoIG5vdGlmaWNhdGlvbiBjYWxsYmFjayBhbmQgbXVzdCBjYWxsIGl0LlxuXHRcdCovXG5cdFx0c2V0Tm90aWZ5RnVuY3Rpb246IChmbikgPT4ge1xuXHRcdFx0bm90aWZ5Rm4gPSBmbjtcblx0XHR9LFxuXHRcdC8qKlxuXHRcdCogVXNlIHRoaXMgbWV0aG9kIHRvIHNldCBhIGN1c3RvbSBmdW5jdGlvbiB0byBiYXRjaCBub3RpZmljYXRpb25zIHRvZ2V0aGVyIGludG8gYSBzaW5nbGUgdGljay5cblx0XHQqIEZyYW1ld29yayBhZGFwdGVycyB1c2UgdGhpcyB0byBwbHVnIGluIHRoZWlyIG93biBiYXRjaGluZyBwcmltaXRpdmUsIHNvIHRoYXQgYSBzaW5nbGUgcXVlcnlcblx0XHQqIHVwZGF0ZSBvbmx5IHRyaWdnZXJzIG9uZSByZS1yZW5kZXIgaW5zdGVhZCBvZiBvbmUgcGVyIHN1YnNjcmliZXIuXG5cdFx0KiBAcGFyYW0gZm4gLSBSZWNlaXZlcyBhIGZ1bmN0aW9uIHRoYXQgcnVucyBhIGJhdGNoIG9mIG5vdGlmaWNhdGlvbnMgYW5kIG11c3QgY2FsbCBpdC5cblx0XHQqIEBleGFtcGxlXG5cdFx0KiBgYGB0c1xuXHRcdCogaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHRcdCogaW1wb3J0IHsgYmF0Y2ggfSBmcm9tICdzb2xpZC1qcydcblx0XHQqXG5cdFx0KiBub3RpZnlNYW5hZ2VyLnNldEJhdGNoTm90aWZ5RnVuY3Rpb24oYmF0Y2gpXG5cdFx0KiBgYGBcblx0XHQqL1xuXHRcdHNldEJhdGNoTm90aWZ5RnVuY3Rpb246IChmbikgPT4ge1xuXHRcdFx0YmF0Y2hOb3RpZnlGbiA9IGZuO1xuXHRcdH0sXG5cdFx0LyoqXG5cdFx0KiBDb25maWd1cmVzIGEgY3VzdG9tIGNhbGxiYWNrIHRoYXQgc2NoZWR1bGVzIHdoZW4gdGhlIG5leHQgYmF0Y2ggcnVucy5cblx0XHQqIFRoZSBkZWZhdWx0IGJlaGF2aW9yIGlzIGBzZXRUaW1lb3V0KGNhbGxiYWNrLCAwKWAuXG5cdFx0KiBAcGFyYW0gZm4gLSBSZWNlaXZlcyBhIGNhbGxiYWNrIHRoYXQgcnVucyB0aGUgbmV4dCBiYXRjaCwgYW5kIHNjaGVkdWxlcyBpdC5cblx0XHQqIEBleGFtcGxlXG5cdFx0KiBgYGB0c1xuXHRcdCogaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHRcdCpcblx0XHQqIC8vIFNjaGVkdWxlIGJhdGNoZXMgaW4gdGhlIG5leHQgbWljcm90YXNrXG5cdFx0KiBub3RpZnlNYW5hZ2VyLnNldFNjaGVkdWxlcihxdWV1ZU1pY3JvdGFzaylcblx0XHQqXG5cdFx0KiAvLyBTY2hlZHVsZSBiYXRjaGVzIGJlZm9yZSB0aGUgbmV4dCBmcmFtZSBpcyByZW5kZXJlZFxuXHRcdCogbm90aWZ5TWFuYWdlci5zZXRTY2hlZHVsZXIocmVxdWVzdEFuaW1hdGlvbkZyYW1lKVxuXHRcdCpcblx0XHQqIC8vIFNjaGVkdWxlIGJhdGNoZXMgc29tZSB0aW1lIGluIHRoZSBmdXR1cmVcblx0XHQqIG5vdGlmeU1hbmFnZXIuc2V0U2NoZWR1bGVyKChjYikgPT4gc2V0VGltZW91dChjYiwgMTApKVxuXHRcdCogYGBgXG5cdFx0Ki9cblx0XHRzZXRTY2hlZHVsZXI6IChmbikgPT4ge1xuXHRcdFx0c2NoZWR1bGVGbiA9IGZuO1xuXHRcdH1cblx0fTtcbn1cbi8qKlxuKiBIYW5kbGVzIHNjaGVkdWxpbmcgYW5kIGJhdGNoaW5nIGNhbGxiYWNrcyBpbiBUYW5TdGFjayBRdWVyeS5cbiovXG5jb25zdCBub3RpZnlNYW5hZ2VyID0gY3JlYXRlTm90aWZ5TWFuYWdlcigpO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjcmVhdGVOb3RpZnlNYW5hZ2VyLCBkZWZhdWx0U2NoZWR1bGVyLCBub3RpZnlNYW5hZ2VyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vdGlmeU1hbmFnZXIuanMubWFwIiwiaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG4vLyNyZWdpb24gc3JjL29ubGluZU1hbmFnZXIudHNcbi8qKlxuKiBUaGUgYE9ubGluZU1hbmFnZXJgIG1hbmFnZXMgdGhlIG9ubGluZSBzdGF0ZSB3aXRoaW4gVGFuU3RhY2sgUXVlcnkuIEl0IGNhblxuKiBiZSB1c2VkIHRvIGNoYW5nZSB0aGUgZGVmYXVsdCBldmVudCBsaXN0ZW5lcnMgb3IgdG8gbWFudWFsbHkgY2hhbmdlIHRoZVxuKiBvbmxpbmUgc3RhdGUuXG4qXG4qIEJ5IGRlZmF1bHQsIHRoZSBgb25saW5lTWFuYWdlcmAgYXNzdW1lcyBhbiBhY3RpdmUgbmV0d29yayBjb25uZWN0aW9uLCBhbmRcbiogbGlzdGVucyB0byB0aGUgYG9ubGluZWAgYW5kIGBvZmZsaW5lYCBldmVudHMgb24gdGhlIGB3aW5kb3dgIG9iamVjdCB0b1xuKiBkZXRlY3QgY2hhbmdlcy5cbiovXG52YXIgT25saW5lTWFuYWdlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I29ubGluZSA9IHRydWU7XG5cdCNjbGVhbnVwO1xuXHQjc2V0dXA7XG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy4jc2V0dXAgPSAob25PbmxpbmUpID0+IHtcblx0XHRcdGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKSB7XG5cdFx0XHRcdGNvbnN0IG9ubGluZUxpc3RlbmVyID0gKCkgPT4gb25PbmxpbmUodHJ1ZSk7XG5cdFx0XHRcdGNvbnN0IG9mZmxpbmVMaXN0ZW5lciA9ICgpID0+IG9uT25saW5lKGZhbHNlKTtcblx0XHRcdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJvbmxpbmVcIiwgb25saW5lTGlzdGVuZXIsIGZhbHNlKTtcblx0XHRcdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJvZmZsaW5lXCIsIG9mZmxpbmVMaXN0ZW5lciwgZmFsc2UpO1xuXHRcdFx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0XHRcdHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwib25saW5lXCIsIG9ubGluZUxpc3RlbmVyKTtcblx0XHRcdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm9mZmxpbmVcIiwgb2ZmbGluZUxpc3RlbmVyKTtcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9O1xuXHR9XG5cdG9uU3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy4jY2xlYW51cCkgdGhpcy5zZXRFdmVudExpc3RlbmVyKHRoaXMuI3NldHVwKTtcblx0fVxuXHRvblVuc3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuXHRcdFx0dGhpcy4jY2xlYW51cD8uKCk7XG5cdFx0XHR0aGlzLiNjbGVhbnVwID0gdm9pZCAwO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBgc2V0RXZlbnRMaXN0ZW5lcmAgY2FuIGJlIHVzZWQgdG8gc2V0IGEgY3VzdG9tIGV2ZW50IGxpc3RlbmVyIHRoYXQgd2lsbFxuXHQqIGJlIHVzZWQgdG8gZGV0ZXJtaW5lIHRoZSBvbmxpbmUgc3RhdGUuIFRoZSBwcm92aWRlZCBgc2V0dXBgIGZ1bmN0aW9uXG5cdCogcmVjZWl2ZXMgYSBgc2V0T25saW5lYCBjYWxsYmFjayB0aGF0IHNob3VsZCBiZSBjYWxsZWQgd2l0aCBhIGBib29sZWFuYFxuXHQqIHdoZW5ldmVyIHRoZSBvbmxpbmUgc3RhdGUgY2hhbmdlcy5cblx0KiBAcGFyYW0gc2V0dXAgLSBSZWNlaXZlcyB0aGUgYHNldE9ubGluZWAgY2FsbGJhY2ssIHJlZ2lzdGVycyB0aGUgZXZlbnQgbGlzdGVuZXIsIGFuZCBtYXkgcmV0dXJuXG5cdCogYSBjbGVhbnVwIGZ1bmN0aW9uIHRoYXQgaXMgY2FsbGVkIHdoZW4gdGhlIGxpc3RlbmVyIGlzIHJlcGxhY2VkIG9yIG5vIGxvbmdlciBuZWVkZWQuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCBOZXRJbmZvIGZyb20gJ0ByZWFjdC1uYXRpdmUtY29tbXVuaXR5L25ldGluZm8nXG5cdCogaW1wb3J0IHsgb25saW5lTWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogb25saW5lTWFuYWdlci5zZXRFdmVudExpc3RlbmVyKChzZXRPbmxpbmUpID0+IHtcblx0KiAgIHJldHVybiBOZXRJbmZvLmFkZEV2ZW50TGlzdGVuZXIoKHN0YXRlKSA9PiB7XG5cdCogICAgIHNldE9ubGluZSghIXN0YXRlLmlzQ29ubmVjdGVkKVxuXHQqICAgfSlcblx0KiB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRFdmVudExpc3RlbmVyKHNldHVwKSB7XG5cdFx0dGhpcy4jc2V0dXAgPSBzZXR1cDtcblx0XHR0aGlzLiNjbGVhbnVwPy4oKTtcblx0XHR0aGlzLiNjbGVhbnVwID0gc2V0dXAodGhpcy5zZXRPbmxpbmUuYmluZCh0aGlzKSk7XG5cdH1cblx0LyoqXG5cdCogYHNldE9ubGluZWAgY2FuIGJlIHVzZWQgdG8gbWFudWFsbHkgc2V0IHRoZSBvbmxpbmUgc3RhdGUuXG5cdCogQHBhcmFtIG9ubGluZSAtIFRoZSBvbmxpbmUgc3RhdGUuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IG9ubGluZU1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIC8vIFNldCB0byBvbmxpbmVcblx0KiBvbmxpbmVNYW5hZ2VyLnNldE9ubGluZSh0cnVlKVxuXHQqXG5cdCogLy8gU2V0IHRvIG9mZmxpbmVcblx0KiBvbmxpbmVNYW5hZ2VyLnNldE9ubGluZShmYWxzZSlcblx0KiBgYGBcblx0Ki9cblx0c2V0T25saW5lKG9ubGluZSkge1xuXHRcdGlmICh0aGlzLiNvbmxpbmUgIT09IG9ubGluZSkge1xuXHRcdFx0dGhpcy4jb25saW5lID0gb25saW5lO1xuXHRcdFx0dGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcblx0XHRcdFx0bGlzdGVuZXIob25saW5lKTtcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBgaXNPbmxpbmVgIGNhbiBiZSB1c2VkIHRvIGdldCB0aGUgY3VycmVudCBvbmxpbmUgc3RhdGUuXG5cdCogQHJldHVybnMgYHRydWVgIGlmIG9ubGluZS5cblx0Ki9cblx0aXNPbmxpbmUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI29ubGluZTtcblx0fVxufTtcbi8qKlxuKiBTaW5nbGV0b24gaW5zdGFuY2Ugb2Yge0BsaW5rIE9ubGluZU1hbmFnZXJ9LCB1c2VkIHRvIG1hbmFnZSBhbmQgb2JzZXJ2ZSB0aGUgb25saW5lIHN0YXRlIHdpdGhpbiBUYW5TdGFjayBRdWVyeS5cbiovXG5jb25zdCBvbmxpbmVNYW5hZ2VyID0gbmV3IE9ubGluZU1hbmFnZXIoKTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgT25saW5lTWFuYWdlciwgb25saW5lTWFuYWdlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1vbmxpbmVNYW5hZ2VyLmpzLm1hcCIsImltcG9ydCB7IG5vb3AsIHNsZWVwIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIi4vZW52aXJvbm1lbnRNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBmb2N1c01hbmFnZXIgfSBmcm9tIFwiLi9mb2N1c01hbmFnZXIuanNcIjtcbmltcG9ydCB7IG9ubGluZU1hbmFnZXIgfSBmcm9tIFwiLi9vbmxpbmVNYW5hZ2VyLmpzXCI7XG4vLyNyZWdpb24gc3JjL3JldHJ5ZXIudHNcbi8qKlxuKiBUaGUgZGVmYXVsdCBgcmV0cnlEZWxheWA6IGRvdWJsZXMgd2l0aCBldmVyeSBmYWlsdXJlLCBzdGFydGluZyBhdCAxIHNlY29uZCwgdXAgdG8gMzAgc2Vjb25kcy5cbiogQHBhcmFtIGZhaWx1cmVDb3VudCAtIFRoZSBudW1iZXIgb2YgZmFpbHVyZXMgc28gZmFyLlxuKiBAcmV0dXJucyBUaGUgZGVsYXkgYmVmb3JlIHRoZSBuZXh0IHJldHJ5LCBpbiBtaWxsaXNlY29uZHMuXG4qL1xuZnVuY3Rpb24gZGVmYXVsdFJldHJ5RGVsYXkoZmFpbHVyZUNvdW50KSB7XG5cdHJldHVybiBNYXRoLm1pbigxZTMgKiAyICoqIGZhaWx1cmVDb3VudCwgM2U0KTtcbn1cbi8qKlxuKiBDaGVja3Mgd2hldGhlciBhIGZldGNoIGNhbiBydW4gZm9yIHRoZSBnaXZlbiBuZXR3b3JrIG1vZGUuXG4qIEBwYXJhbSBuZXR3b3JrTW9kZSAtIFRoZSBgbmV0d29ya01vZGVgIG9wdGlvbi4gRGVmYXVsdHMgdG8gYCdvbmxpbmUnYC5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBuZXR3b3JrIG1vZGUgaXMgbm90IGAnb25saW5lJ2AsIG9yIGlmIGl0IGlzIGFuZCB0aGUgY2xpZW50IGlzIG9ubGluZS5cbiovXG5mdW5jdGlvbiBjYW5GZXRjaChuZXR3b3JrTW9kZSkge1xuXHRyZXR1cm4gKG5ldHdvcmtNb2RlID8/IFwib25saW5lXCIpID09PSBcIm9ubGluZVwiID8gb25saW5lTWFuYWdlci5pc09ubGluZSgpIDogdHJ1ZTtcbn1cbi8qKlxuKiBUaGUgZXJyb3IgdGhyb3duIGJ5IGEgYFJldHJ5ZXJgIChhbmQgc3VyZmFjZWQgdG8gYHF1ZXJ5LnByb21pc2VgL2BtdXRhdGlvbmApIHdoZW4gYSBmZXRjaCBpcyBjYW5jZWxsZWQsIGUuZy4gdmlhXG4qIGBxdWVyeS5jYW5jZWwoKWAuIGByZXZlcnRgLCBpZiBgdHJ1ZWAsIHRlbGxzIHRoZSBjYWxsZXIgdG8gcmVzdG9yZSB0aGUgc3RhdGUgdGhlIHF1ZXJ5IHdhcyBpbiBiZWZvcmUgdGhlIGZldGNoXG4qIHN0YXJ0ZWQgaW5zdGVhZCBvZiBzdXJmYWNpbmcgdGhlIGVycm9yLiBgc2lsZW50YCwgaWYgYHRydWVgLCB0ZWxscyB0aGUgY2FsbGVyIHRvIHN1cHByZXNzIHRoaXMgZXJyb3IgYW5kIGluc3RlYWRcbiogcmVzb2x2ZSB3aXRoIHRoZSBwcm9taXNlIG9mIHRoZSBmZXRjaCB0aGF0IHRyaWdnZXJlZCB0aGUgY2FuY2VsbGF0aW9uLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBxdWVyeS5jYW5jZWwoKVxuKlxuKiB0cnkge1xuKiAgIGF3YWl0IHF1ZXJ5LnByb21pc2VcbiogfSBjYXRjaCAoZXJyb3IpIHtcbiogICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBDYW5jZWxsZWRFcnJvcikge1xuKiAgICAgLy8gdGhlIGZldGNoIHdhcyBjYW5jZWxsZWQsIGUuZy4gdmlhIGBxdWVyeS5jYW5jZWwoKWBcbiogICB9XG4qIH1cbiogYGBgXG4qL1xudmFyIENhbmNlbGxlZEVycm9yID0gY2xhc3MgZXh0ZW5kcyBFcnJvciB7XG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHRzdXBlcihcIkNhbmNlbGxlZEVycm9yXCIpO1xuXHRcdHRoaXMucmV2ZXJ0ID0gb3B0aW9ucz8ucmV2ZXJ0O1xuXHRcdHRoaXMuc2lsZW50ID0gb3B0aW9ucz8uc2lsZW50O1xuXHR9XG59O1xuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgdmFsdWUgaXMgYSBgQ2FuY2VsbGVkRXJyb3JgLlxuKiBAcGFyYW0gdmFsdWUgLSBUaGUgdmFsdWUgdG8gY2hlY2suXG4qIEByZXR1cm5zIGB0cnVlYCBpZiBgdmFsdWVgIGlzIGEgYENhbmNlbGxlZEVycm9yYC5cbiogQGRlcHJlY2F0ZWQgVXNlIGluc3RhbmNlb2YgYENhbmNlbGxlZEVycm9yYCBpbnN0ZWFkLlxuKi9cbmZ1bmN0aW9uIGlzQ2FuY2VsbGVkRXJyb3IodmFsdWUpIHtcblx0cmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgQ2FuY2VsbGVkRXJyb3I7XG59XG4vKipcbiogQ3JlYXRlcyBhIHJldHJ5ZXIsIHdoaWNoIHJ1bnMgYSBmdW5jdGlvbiBhbmQgcmV0cmllcyBpdCBvbiBmYWlsdXJlIGFjY29yZGluZyB0byB0aGUgYHJldHJ5YCBhbmRcbiogYHJldHJ5RGVsYXlgIG9wdGlvbnMuIEl0IHBhdXNlcyB3aGlsZSB0aGUgbmV0d29yayBtb2RlIGRvZXNuJ3QgYWxsb3cgZmV0Y2hpbmcgb3IgYGNhblJ1bmAgcmV0dXJuc1xuKiBgZmFsc2VgLCBhbmQgY2FuIGJlIGNhbmNlbGxlZC4gUXVlcmllcyBhbmQgbXV0YXRpb25zIHVzZSBpdCB0byBydW4gdGhlaXIgYHF1ZXJ5Rm5gIGFuZFxuKiBgbXV0YXRpb25GbmAuXG4qIEBwYXJhbSBjb25maWcgLSBUaGUgZnVuY3Rpb24gdG8gcnVuLCB0aGUgcmV0cnkgb3B0aW9ucywgYW5kIHRoZSBjYWxsYmFja3MgZm9yIGZhaWx1cmVzLCBwYXVzaW5nLFxuKiBjb250aW51aW5nLCBhbmQgY2FuY2VsbGF0aW9uLlxuKiBAcmV0dXJucyBUaGUgcmV0cnllciwgd2hvc2UgYHByb21pc2VgIHNldHRsZXMgd2l0aCB0aGUgcmVzdWx0IG9mIHRoZSBmdW5jdGlvbi5cbiovXG5mdW5jdGlvbiBjcmVhdGVSZXRyeWVyKGNvbmZpZykge1xuXHRsZXQgaXNSZXRyeUNhbmNlbGxlZCA9IGZhbHNlO1xuXHRsZXQgZmFpbHVyZUNvdW50ID0gMDtcblx0bGV0IGNvbnRpbnVlRm47XG5cdGxldCBzdGF0dXMgPSBcInBlbmRpbmdcIjtcblx0bGV0IHByb21pc2VSZXNvbHZlO1xuXHRsZXQgcHJvbWlzZVJlamVjdDtcblx0Y29uc3QgcHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRwcm9taXNlUmVzb2x2ZSA9IHJlc29sdmU7XG5cdFx0cHJvbWlzZVJlamVjdCA9IHJlamVjdDtcblx0fSk7XG5cdHByb21pc2UuY2F0Y2gobm9vcCk7XG5cdGNvbnN0IGlzUmVzb2x2ZWQgPSAoKSA9PiBzdGF0dXMgIT09IFwicGVuZGluZ1wiO1xuXHRjb25zdCBjYW5jZWwgPSAoY2FuY2VsT3B0aW9ucykgPT4ge1xuXHRcdGlmICghaXNSZXNvbHZlZCgpKSB7XG5cdFx0XHRjb25zdCBlcnJvciA9IG5ldyBDYW5jZWxsZWRFcnJvcihjYW5jZWxPcHRpb25zKTtcblx0XHRcdHJlamVjdChlcnJvcik7XG5cdFx0XHRjb25maWcub25DYW5jZWw/LihlcnJvcik7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBjYW5jZWxSZXRyeSA9ICgpID0+IHtcblx0XHRpc1JldHJ5Q2FuY2VsbGVkID0gdHJ1ZTtcblx0fTtcblx0Y29uc3QgY29udGludWVSZXRyeSA9ICgpID0+IHtcblx0XHRpc1JldHJ5Q2FuY2VsbGVkID0gZmFsc2U7XG5cdH07XG5cdGNvbnN0IGNhbkNvbnRpbnVlID0gKCkgPT4gZm9jdXNNYW5hZ2VyLmlzRm9jdXNlZCgpICYmIChjb25maWcubmV0d29ya01vZGUgPT09IFwiYWx3YXlzXCIgfHwgb25saW5lTWFuYWdlci5pc09ubGluZSgpKSAmJiBjb25maWcuY2FuUnVuKCk7XG5cdGNvbnN0IGNhblN0YXJ0ID0gKCkgPT4gY2FuRmV0Y2goY29uZmlnLm5ldHdvcmtNb2RlKSAmJiBjb25maWcuY2FuUnVuKCk7XG5cdGNvbnN0IHJlc29sdmUgPSAodmFsdWUpID0+IHtcblx0XHRpZiAoIWlzUmVzb2x2ZWQoKSkge1xuXHRcdFx0Y29udGludWVGbj8uKCk7XG5cdFx0XHRzdGF0dXMgPSBcInJlc29sdmVkXCI7XG5cdFx0XHRwcm9taXNlUmVzb2x2ZSh2YWx1ZSk7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCByZWplY3QgPSAodmFsdWUpID0+IHtcblx0XHRpZiAoIWlzUmVzb2x2ZWQoKSkge1xuXHRcdFx0Y29udGludWVGbj8uKCk7XG5cdFx0XHRzdGF0dXMgPSBcInJlamVjdGVkXCI7XG5cdFx0XHRwcm9taXNlUmVqZWN0KHZhbHVlKTtcblx0XHR9XG5cdH07XG5cdGNvbnN0IHBhdXNlID0gKGNhblJlc3VtZSkgPT4ge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZSgoY29udGludWVSZXNvbHZlKSA9PiB7XG5cdFx0XHRjb250aW51ZUZuID0gKHZhbHVlKSA9PiB7XG5cdFx0XHRcdGlmIChpc1Jlc29sdmVkKCkgfHwgY2FuUmVzdW1lKCkpIGNvbnRpbnVlUmVzb2x2ZSh2YWx1ZSk7XG5cdFx0XHR9O1xuXHRcdFx0Y29uZmlnLm9uUGF1c2U/LigpO1xuXHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0Y29udGludWVGbiA9IHZvaWQgMDtcblx0XHRcdGlmICghaXNSZXNvbHZlZCgpKSBjb25maWcub25Db250aW51ZT8uKCk7XG5cdFx0fSk7XG5cdH07XG5cdGNvbnN0IHJ1biA9ICgpID0+IHtcblx0XHRpZiAoaXNSZXNvbHZlZCgpKSByZXR1cm47XG5cdFx0bGV0IHByb21pc2VPclZhbHVlO1xuXHRcdGNvbnN0IGluaXRpYWxQcm9taXNlID0gZmFpbHVyZUNvdW50ID09PSAwID8gY29uZmlnLmluaXRpYWxQcm9taXNlIDogdm9pZCAwO1xuXHRcdHRyeSB7XG5cdFx0XHRwcm9taXNlT3JWYWx1ZSA9IGluaXRpYWxQcm9taXNlID8/IGNvbmZpZy5mbigpO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRwcm9taXNlT3JWYWx1ZSA9IFByb21pc2UucmVqZWN0KGVycm9yKTtcblx0XHR9XG5cdFx0UHJvbWlzZS5yZXNvbHZlKHByb21pc2VPclZhbHVlKS50aGVuKHJlc29sdmUpLmNhdGNoKChlcnJvcikgPT4ge1xuXHRcdFx0aWYgKGlzUmVzb2x2ZWQoKSkgcmV0dXJuO1xuXHRcdFx0Y29uc3QgcmV0cnkgPSBjb25maWcucmV0cnkgPz8gKGlzU2VydmVyKCkgPyAwIDogMyk7XG5cdFx0XHRjb25zdCByZXRyeURlbGF5ID0gY29uZmlnLnJldHJ5RGVsYXkgPz8gZGVmYXVsdFJldHJ5RGVsYXk7XG5cdFx0XHRjb25zdCBkZWxheSA9IHR5cGVvZiByZXRyeURlbGF5ID09PSBcImZ1bmN0aW9uXCIgPyByZXRyeURlbGF5KGZhaWx1cmVDb3VudCwgZXJyb3IpIDogcmV0cnlEZWxheTtcblx0XHRcdGNvbnN0IHNob3VsZFJldHJ5ID0gcmV0cnkgPT09IHRydWUgfHwgdHlwZW9mIHJldHJ5ID09PSBcIm51bWJlclwiICYmIGZhaWx1cmVDb3VudCA8IHJldHJ5IHx8IHR5cGVvZiByZXRyeSA9PT0gXCJmdW5jdGlvblwiICYmIHJldHJ5KGZhaWx1cmVDb3VudCwgZXJyb3IpO1xuXHRcdFx0aWYgKGlzUmV0cnlDYW5jZWxsZWQgfHwgIXNob3VsZFJldHJ5KSB7XG5cdFx0XHRcdHJlamVjdChlcnJvcik7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGZhaWx1cmVDb3VudCsrO1xuXHRcdFx0Y29uZmlnLm9uRmFpbD8uKGZhaWx1cmVDb3VudCwgZXJyb3IpO1xuXHRcdFx0c2xlZXAoZGVsYXkpLnRoZW4oKCkgPT4ge1xuXHRcdFx0XHRyZXR1cm4gY2FuQ29udGludWUoKSA/IHZvaWQgMCA6IHBhdXNlKGNhbkNvbnRpbnVlKTtcblx0XHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0XHRpZiAoaXNSZXRyeUNhbmNlbGxlZCkgcmVqZWN0KGVycm9yKTtcblx0XHRcdFx0ZWxzZSBydW4oKTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdHByb21pc2UsXG5cdFx0c3RhdHVzOiAoKSA9PiBzdGF0dXMsXG5cdFx0Y2FuY2VsLFxuXHRcdGNvbnRpbnVlOiAoKSA9PiB7XG5cdFx0XHRjb250aW51ZUZuPy4oKTtcblx0XHRcdHJldHVybiBwcm9taXNlO1xuXHRcdH0sXG5cdFx0Y2FuY2VsUmV0cnksXG5cdFx0Y29udGludWVSZXRyeSxcblx0XHRjYW5TdGFydCxcblx0XHRzdGFydDogKCkgPT4ge1xuXHRcdFx0aWYgKGNhblN0YXJ0KCkpIHJ1bigpO1xuXHRcdFx0ZWxzZSBwYXVzZShjYW5TdGFydCkudGhlbihydW4pO1xuXHRcdFx0cmV0dXJuIHByb21pc2U7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBDYW5jZWxsZWRFcnJvciwgY2FuRmV0Y2gsIGNyZWF0ZVJldHJ5ZXIsIGlzQ2FuY2VsbGVkRXJyb3IgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmV0cnllci5qcy5tYXAiLCJpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBpc1ZhbGlkVGltZW91dCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCIuL2Vudmlyb25tZW50TWFuYWdlci5qc1wiO1xuLy8jcmVnaW9uIHNyYy9yZW1vdmFibGUudHNcbi8qKlxuKiBUaGUgYmFzZSBjbGFzcyBmb3IgY2FjaGUgZW50cmllcyB0aGF0IGFyZSBnYXJiYWdlIGNvbGxlY3RlZCBvbmNlIG5vdGhpbmcgaXMgdXNpbmcgdGhlbSDigJRcbiogYFF1ZXJ5YCBhbmQgYE11dGF0aW9uYCBib3RoIGV4dGVuZCBpdC4gYGdjVGltZWAgY29udHJvbHMgaG93IGxvbmcgYW4gdW51c2VkIGVudHJ5IGlzIGtlcHQuXG4qL1xudmFyIFJlbW92YWJsZSA9IGNsYXNzIHtcblx0I2djVGltZW91dDtcblx0LyoqXG5cdCogQ2xlYXJzIHRoZSBwZW5kaW5nIGdhcmJhZ2UgY29sbGVjdGlvbiB0aW1lb3V0LCBzbyB0aGUgZW50cnkgaXMgbm8gbG9uZ2VyIHNjaGVkdWxlZCBmb3IgcmVtb3ZhbC5cblx0KiBBIHN1YmNsYXNzIG1heSBvdmVycmlkZSB0aGlzIHRvIHJlbGVhc2Ugd2hhdCBpdCBob2xkcyBvbiB0byBhcyB3ZWxsIOKAlCBgUXVlcnlgIGFsc28gY2FuY2VscyBhbnlcblx0KiBpbi1mbGlnaHQgZmV0Y2guXG5cdCovXG5cdGRlc3Ryb3koKSB7XG5cdFx0dGhpcy5jbGVhckdjVGltZW91dCgpO1xuXHR9XG5cdC8qKlxuXHQqIFNjaGVkdWxlcyB0aGUgZW50cnkgdG8gYmUgcmVtb3ZlZCBmcm9tIGl0cyBjYWNoZSBhZnRlciBgZ2NUaW1lYCwgcmVwbGFjaW5nIGFueSB0aW1lb3V0IHNjaGVkdWxlZFxuXHQqIGJlZm9yZS4gTm90aGluZyBpcyBzY2hlZHVsZWQgaWYgYGdjVGltZWAgaXMgYEluZmluaXR5YC5cblx0Ki9cblx0c2NoZWR1bGVHYygpIHtcblx0XHR0aGlzLmNsZWFyR2NUaW1lb3V0KCk7XG5cdFx0aWYgKGlzVmFsaWRUaW1lb3V0KHRoaXMuZ2NUaW1lKSkgdGhpcy4jZ2NUaW1lb3V0ID0gdGltZW91dE1hbmFnZXIuc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHR0aGlzLm9wdGlvbmFsUmVtb3ZlKCk7XG5cdFx0fSwgdGhpcy5nY1RpbWUpO1xuXHR9XG5cdC8qKlxuXHQqIFVwZGF0ZXMgYGdjVGltZWAsIGtlZXBpbmcgdGhlIGxvbmdlc3Qgb25lIHNlZW4gc28gZmFyLiBXaXRob3V0IGEgdmFsdWUsIGl0IGRlZmF1bHRzIHRvIDUgbWludXRlc1xuXHQqIG9uIHRoZSBjbGllbnQgYW5kIGBJbmZpbml0eWAgb24gdGhlIHNlcnZlci5cblx0KiBAcGFyYW0gbmV3R2NUaW1lIC0gVGhlIGBnY1RpbWVgIGZyb20gdGhlIGxhdGVzdCBvcHRpb25zLCBpZiBhbnkuXG5cdCovXG5cdHVwZGF0ZUdjVGltZShuZXdHY1RpbWUpIHtcblx0XHR0aGlzLmdjVGltZSA9IE1hdGgubWF4KHRoaXMuZ2NUaW1lIHx8IDAsIG5ld0djVGltZSA/PyAoaXNTZXJ2ZXIoKSA/IEluZmluaXR5IDogM2U1KSk7XG5cdH1cblx0LyoqXG5cdCogQ2FuY2VscyB0aGUgc2NoZWR1bGVkIHJlbW92YWwsIGlmIHRoZXJlIGlzIG9uZS5cblx0Ki9cblx0Y2xlYXJHY1RpbWVvdXQoKSB7XG5cdFx0aWYgKHRoaXMuI2djVGltZW91dCAhPT0gdm9pZCAwKSB7XG5cdFx0XHR0aW1lb3V0TWFuYWdlci5jbGVhclRpbWVvdXQodGhpcy4jZ2NUaW1lb3V0KTtcblx0XHRcdHRoaXMuI2djVGltZW91dCA9IHZvaWQgMDtcblx0XHR9XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFJlbW92YWJsZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZW1vdmFibGUuanMubWFwIiwiaW1wb3J0IHsgYWRkQ29uc3VtZUF3YXJlU2lnbmFsLCBhZGRUb0VuZCwgYWRkVG9TdGFydCwgZW5zdXJlUXVlcnlGbiB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyNyZWdpb24gc3JjL2luZmluaXRlUXVlcnlCZWhhdmlvci50c1xuLyoqXG4qIENyZWF0ZXMgdGhlIGJlaGF2aW9yIHRoYXQgZmV0Y2hlcyB0aGUgcGFnZXMgb2YgYW4gaW5maW5pdGUgcXVlcnk6IHRoZSBuZXh0IG9yIHByZXZpb3VzIHBhZ2UgZm9yXG4qIGBmZXRjaE5leHRQYWdlYC9gZmV0Y2hQcmV2aW91c1BhZ2VgLCBvciBhbGwgcGFnZXMgYWdhaW4gZnJvbSB0aGUgc3RhcnQgb24gYSByZWZldGNoLlxuKiBAcGFyYW0gcGFnZXMgLSBUaGUgbnVtYmVyIG9mIHBhZ2VzIHRvIGZldGNoIGZyb20gdGhlIHN0YXJ0IHdoZW4gYWxsIHBhZ2VzIGFyZSBmZXRjaGVkIGFnYWluLFxuKiBlLmcuIGZyb20gdGhlIGBwYWdlc2Agb3B0aW9uIG9mIGBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5YC4gRGVmYXVsdHMgdG8gdGhlIG51bWJlciBvZiBjYWNoZWRcbiogcGFnZXMuXG4qIEByZXR1cm5zIFRoZSBxdWVyeSBiZWhhdmlvciB0byBzZXQgb24gYW4gaW5maW5pdGUgcXVlcnkuXG4qL1xuZnVuY3Rpb24gaW5maW5pdGVRdWVyeUJlaGF2aW9yKHBhZ2VzKSB7XG5cdHJldHVybiB7IG9uRmV0Y2g6IChjb250ZXh0LCBxdWVyeSkgPT4ge1xuXHRcdGNvbnN0IG9wdGlvbnMgPSBjb250ZXh0Lm9wdGlvbnM7XG5cdFx0Y29uc3QgZGlyZWN0aW9uID0gY29udGV4dC5mZXRjaE9wdGlvbnM/Lm1ldGE/LmZldGNoTW9yZT8uZGlyZWN0aW9uO1xuXHRcdGNvbnN0IG9sZFBhZ2VzID0gY29udGV4dC5zdGF0ZS5kYXRhPy5wYWdlcyB8fCBbXTtcblx0XHRjb25zdCBvbGRQYWdlUGFyYW1zID0gY29udGV4dC5zdGF0ZS5kYXRhPy5wYWdlUGFyYW1zIHx8IFtdO1xuXHRcdGxldCByZXN1bHQgPSB7XG5cdFx0XHRwYWdlczogW10sXG5cdFx0XHRwYWdlUGFyYW1zOiBbXVxuXHRcdH07XG5cdFx0bGV0IGN1cnJlbnRQYWdlID0gMDtcblx0XHRjb25zdCBmZXRjaEZuID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0bGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuXHRcdFx0Y29uc3QgYWRkU2lnbmFsUHJvcGVydHkgPSAob2JqZWN0KSA9PiB7XG5cdFx0XHRcdGFkZENvbnN1bWVBd2FyZVNpZ25hbChvYmplY3QsICgpID0+IGNvbnRleHQuc2lnbmFsLCAoKSA9PiBjYW5jZWxsZWQgPSB0cnVlKTtcblx0XHRcdH07XG5cdFx0XHRjb25zdCBxdWVyeUZuID0gZW5zdXJlUXVlcnlGbihjb250ZXh0Lm9wdGlvbnMsIGNvbnRleHQuZmV0Y2hPcHRpb25zKTtcblx0XHRcdGNvbnN0IGZldGNoUGFnZSA9IGFzeW5jIChkYXRhLCBwYXJhbSwgcHJldmlvdXMpID0+IHtcblx0XHRcdFx0aWYgKGNhbmNlbGxlZCkgcmV0dXJuIFByb21pc2UucmVqZWN0KGNvbnRleHQuc2lnbmFsLnJlYXNvbik7XG5cdFx0XHRcdGlmIChwYXJhbSA9PSBudWxsICYmIGRhdGEucGFnZXMubGVuZ3RoKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGRhdGEpO1xuXHRcdFx0XHRjb25zdCBjcmVhdGVRdWVyeUZuQ29udGV4dCA9ICgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBxdWVyeUZuQ29udGV4dCA9IHtcblx0XHRcdFx0XHRcdGNsaWVudDogY29udGV4dC5jbGllbnQsXG5cdFx0XHRcdFx0XHRxdWVyeUtleTogY29udGV4dC5xdWVyeUtleSxcblx0XHRcdFx0XHRcdHBhZ2VQYXJhbTogcGFyYW0sXG5cdFx0XHRcdFx0XHRkaXJlY3Rpb246IHByZXZpb3VzID8gXCJiYWNrd2FyZFwiIDogXCJmb3J3YXJkXCIsXG5cdFx0XHRcdFx0XHRtZXRhOiBjb250ZXh0Lm9wdGlvbnMubWV0YVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0YWRkU2lnbmFsUHJvcGVydHkocXVlcnlGbkNvbnRleHQpO1xuXHRcdFx0XHRcdHJldHVybiBxdWVyeUZuQ29udGV4dDtcblx0XHRcdFx0fTtcblx0XHRcdFx0Y29uc3QgcXVlcnlGbkNvbnRleHQgPSBjcmVhdGVRdWVyeUZuQ29udGV4dCgpO1xuXHRcdFx0XHRjb25zdCBwYWdlID0gYXdhaXQgcXVlcnlGbihxdWVyeUZuQ29udGV4dCk7XG5cdFx0XHRcdGNvbnN0IHsgbWF4UGFnZXMgfSA9IGNvbnRleHQub3B0aW9ucztcblx0XHRcdFx0Y29uc3QgYWRkVG8gPSBwcmV2aW91cyA/IGFkZFRvU3RhcnQgOiBhZGRUb0VuZDtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRwYWdlczogYWRkVG8oZGF0YS5wYWdlcywgcGFnZSwgbWF4UGFnZXMpLFxuXHRcdFx0XHRcdHBhZ2VQYXJhbXM6IGFkZFRvKGRhdGEucGFnZVBhcmFtcywgcGFyYW0sIG1heFBhZ2VzKVxuXHRcdFx0XHR9O1xuXHRcdFx0fTtcblx0XHRcdGlmIChkaXJlY3Rpb24gJiYgb2xkUGFnZXMubGVuZ3RoKSB7XG5cdFx0XHRcdGNvbnN0IHByZXZpb3VzID0gZGlyZWN0aW9uID09PSBcImJhY2t3YXJkXCI7XG5cdFx0XHRcdGNvbnN0IHBhZ2VQYXJhbUZuID0gcHJldmlvdXMgPyBnZXRQcmV2aW91c1BhZ2VQYXJhbSA6IGdldE5leHRQYWdlUGFyYW07XG5cdFx0XHRcdGNvbnN0IG9sZERhdGEgPSB7XG5cdFx0XHRcdFx0cGFnZXM6IG9sZFBhZ2VzLFxuXHRcdFx0XHRcdHBhZ2VQYXJhbXM6IG9sZFBhZ2VQYXJhbXNcblx0XHRcdFx0fTtcblx0XHRcdFx0cmVzdWx0ID0gYXdhaXQgZmV0Y2hQYWdlKG9sZERhdGEsIHBhZ2VQYXJhbUZuKG9wdGlvbnMsIG9sZERhdGEpLCBwcmV2aW91cyk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRjb25zdCByZW1haW5pbmdQYWdlcyA9IHBhZ2VzID8/IG9sZFBhZ2VzLmxlbmd0aDtcblx0XHRcdFx0ZG8ge1xuXHRcdFx0XHRcdGNvbnN0IHBhcmFtID0gY3VycmVudFBhZ2UgPT09IDAgPyBvbGRQYWdlUGFyYW1zWzBdID09PSB2b2lkIDAgPyBvcHRpb25zLmluaXRpYWxQYWdlUGFyYW0gOiBvbGRQYWdlUGFyYW1zWzBdIDogZ2V0TmV4dFBhZ2VQYXJhbShvcHRpb25zLCByZXN1bHQpO1xuXHRcdFx0XHRcdGlmIChjdXJyZW50UGFnZSA+IDAgJiYgcGFyYW0gPT0gbnVsbCkgYnJlYWs7XG5cdFx0XHRcdFx0cmVzdWx0ID0gYXdhaXQgZmV0Y2hQYWdlKHJlc3VsdCwgcGFyYW0pO1xuXHRcdFx0XHRcdGN1cnJlbnRQYWdlKys7XG5cdFx0XHRcdH0gd2hpbGUgKGN1cnJlbnRQYWdlIDwgcmVtYWluaW5nUGFnZXMpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9O1xuXHRcdGlmIChjb250ZXh0Lm9wdGlvbnMucGVyc2lzdGVyKSBjb250ZXh0LmZldGNoRm4gPSAoKSA9PiB7XG5cdFx0XHRyZXR1cm4gY29udGV4dC5vcHRpb25zLnBlcnNpc3Rlcj8uKGZldGNoRm4sIHtcblx0XHRcdFx0Y2xpZW50OiBjb250ZXh0LmNsaWVudCxcblx0XHRcdFx0cXVlcnlLZXk6IGNvbnRleHQucXVlcnlLZXksXG5cdFx0XHRcdG1ldGE6IGNvbnRleHQub3B0aW9ucy5tZXRhLFxuXHRcdFx0XHRzaWduYWw6IGNvbnRleHQuc2lnbmFsXG5cdFx0XHR9LCBxdWVyeSk7XG5cdFx0fTtcblx0XHRlbHNlIGNvbnRleHQuZmV0Y2hGbiA9IGZldGNoRm47XG5cdH0gfTtcbn1cbi8qKlxuKiBDb21wdXRlcyB0aGUgcGFnZSBwYXJhbSBvZiB0aGUgcGFnZSBhZnRlciB0aGUgbGFzdCBvbmUsIHdpdGggdGhlIGBnZXROZXh0UGFnZVBhcmFtYCBvcHRpb24uXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIGluZmluaXRlIHF1ZXJ5IG9wdGlvbnMuXG4qIEBwYXJhbSBkYXRhIC0gVGhlIGN1cnJlbnQgcGFnZXMgYW5kIHBhZ2UgcGFyYW1zLlxuKiBAcmV0dXJucyBUaGUgbmV4dCBwYWdlIHBhcmFtLCBvciBgdW5kZWZpbmVkYCBpZiB0aGVyZSBhcmUgbm8gcGFnZXMgeWV0LlxuKi9cbmZ1bmN0aW9uIGdldE5leHRQYWdlUGFyYW0ob3B0aW9ucywgeyBwYWdlcywgcGFnZVBhcmFtcyB9KSB7XG5cdGNvbnN0IGxhc3RJbmRleCA9IHBhZ2VzLmxlbmd0aCAtIDE7XG5cdHJldHVybiBwYWdlcy5sZW5ndGggPiAwID8gb3B0aW9ucy5nZXROZXh0UGFnZVBhcmFtKHBhZ2VzW2xhc3RJbmRleF0sIHBhZ2VzLCBwYWdlUGFyYW1zW2xhc3RJbmRleF0sIHBhZ2VQYXJhbXMpIDogdm9pZCAwO1xufVxuLyoqXG4qIENvbXB1dGVzIHRoZSBwYWdlIHBhcmFtIG9mIHRoZSBwYWdlIGJlZm9yZSB0aGUgZmlyc3Qgb25lLCB3aXRoIHRoZSBgZ2V0UHJldmlvdXNQYWdlUGFyYW1gXG4qIG9wdGlvbi5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgaW5maW5pdGUgcXVlcnkgb3B0aW9ucy5cbiogQHBhcmFtIGRhdGEgLSBUaGUgY3VycmVudCBwYWdlcyBhbmQgcGFnZSBwYXJhbXMuXG4qIEByZXR1cm5zIFRoZSBwcmV2aW91cyBwYWdlIHBhcmFtLCBvciBgdW5kZWZpbmVkYCBpZiB0aGVyZSBhcmUgbm8gcGFnZXMgeWV0IG9yIG5vXG4qIGBnZXRQcmV2aW91c1BhZ2VQYXJhbWAgb3B0aW9uLlxuKi9cbmZ1bmN0aW9uIGdldFByZXZpb3VzUGFnZVBhcmFtKG9wdGlvbnMsIHsgcGFnZXMsIHBhZ2VQYXJhbXMgfSkge1xuXHRyZXR1cm4gcGFnZXMubGVuZ3RoID4gMCA/IG9wdGlvbnMuZ2V0UHJldmlvdXNQYWdlUGFyYW0/LihwYWdlc1swXSwgcGFnZXMsIHBhZ2VQYXJhbXNbMF0sIHBhZ2VQYXJhbXMpIDogdm9pZCAwO1xufVxuLyoqXG4qIENoZWNrcyBpZiB0aGVyZSBpcyBhIG5leHQgcGFnZS5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgaW5maW5pdGUgcXVlcnkgb3B0aW9ucyB3aXRoIGBnZXROZXh0UGFnZVBhcmFtYC5cbiogQHBhcmFtIGRhdGEgLSBUaGUgY3VycmVudCBwYWdlcyBhbmQgcGFnZSBwYXJhbXMuXG4qIEByZXR1cm5zIGB0cnVlYCBpZiBgZ2V0TmV4dFBhZ2VQYXJhbWAgcmV0dXJucyBhIHZhbHVlIG90aGVyIHRoYW4gYG51bGxgIG9yIGB1bmRlZmluZWRgLlxuKi9cbmZ1bmN0aW9uIGhhc05leHRQYWdlKG9wdGlvbnMsIGRhdGEpIHtcblx0aWYgKCFkYXRhKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiBnZXROZXh0UGFnZVBhcmFtKG9wdGlvbnMsIGRhdGEpICE9IG51bGw7XG59XG4vKipcbiogQ2hlY2tzIGlmIHRoZXJlIGlzIGEgcHJldmlvdXMgcGFnZS5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgaW5maW5pdGUgcXVlcnkgb3B0aW9ucyB3aXRoIGBnZXRQcmV2aW91c1BhZ2VQYXJhbWAuXG4qIEBwYXJhbSBkYXRhIC0gVGhlIGN1cnJlbnQgcGFnZXMgYW5kIHBhZ2UgcGFyYW1zLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYGdldFByZXZpb3VzUGFnZVBhcmFtYCBpcyBzZXQgYW5kIHJldHVybnMgYSB2YWx1ZSBvdGhlciB0aGFuIGBudWxsYCBvclxuKiBgdW5kZWZpbmVkYC5cbiovXG5mdW5jdGlvbiBoYXNQcmV2aW91c1BhZ2Uob3B0aW9ucywgZGF0YSkge1xuXHRpZiAoIWRhdGEgfHwgIW9wdGlvbnMuZ2V0UHJldmlvdXNQYWdlUGFyYW0pIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIGdldFByZXZpb3VzUGFnZVBhcmFtKG9wdGlvbnMsIGRhdGEpICE9IG51bGw7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGhhc05leHRQYWdlLCBoYXNQcmV2aW91c1BhZ2UsIGluZmluaXRlUXVlcnlCZWhhdmlvciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmZpbml0ZVF1ZXJ5QmVoYXZpb3IuanMubWFwIiwiaW1wb3J0IHsgZW5zdXJlUXVlcnlGbiwgbm9vcCwgcmVwbGFjZURhdGEsIHJlc29sdmVRdWVyeVZhbHVlLCBza2lwVG9rZW4sIHRpbWVVbnRpbFN0YWxlIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBDYW5jZWxsZWRFcnJvciwgY2FuRmV0Y2gsIGNyZWF0ZVJldHJ5ZXIgfSBmcm9tIFwiLi9yZXRyeWVyLmpzXCI7XG5pbXBvcnQgeyBSZW1vdmFibGUgfSBmcm9tIFwiLi9yZW1vdmFibGUuanNcIjtcbmltcG9ydCB7IGluZmluaXRlUXVlcnlCZWhhdmlvciB9IGZyb20gXCIuL2luZmluaXRlUXVlcnlCZWhhdmlvci5qc1wiO1xuLy8jcmVnaW9uIHNyYy9xdWVyeS50c1xuLyoqXG4qIFJlcHJlc2VudHMgYSBzaW5nbGUgY2FjaGVkIHF1ZXJ5LiBBIGBRdWVyeWAgaG9sZHMgdGhlIHF1ZXJ5J3Mga2V5LCBvcHRpb25zLFxuKiBzdGF0ZSAoZGF0YS9lcnJvci9zdGF0dXMpLCBhbmQgdGhlIG9ic2VydmVycyBjdXJyZW50bHkgc3Vic2NyaWJlZCB0byBpdC5cbipcbiogSW5zdGFuY2VzIGFyZSBjcmVhdGVkIGFuZCBtYW5hZ2VkIGludGVybmFsbHkgYnkgYFF1ZXJ5Q2FjaGVgOyBhcHBsaWNhdGlvblxuKiBjb2RlIHR5cGljYWxseSBpbnRlcmFjdHMgd2l0aCBxdWVyaWVzIGluZGlyZWN0bHkgdGhyb3VnaCBgUXVlcnlDbGllbnRgIG9yXG4qIGEgZnJhbWV3b3JrIGhvb2sgbGlrZSBgdXNlUXVlcnlgLiBEaXJlY3QgYWNjZXNzIHRvIGEgYFF1ZXJ5YCBpbnN0YW5jZSBpc1xuKiBwb3NzaWJsZSB2aWEgYHF1ZXJ5Q2FjaGUuZmluZCgpYC9gZmluZEFsbCgpYCBmb3IgaW5zcGVjdGluZyBjYWNoZSBzdGF0ZS5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuKiBjb25zdCBxdWVyeSA9IHF1ZXJ5Q2FjaGUuZmluZCh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcbipcbiogaWYgKHF1ZXJ5KSB7XG4qICAgY29uc29sZS5sb2cocXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdClcbiogfVxuKiBgYGBcbiovXG52YXIgUXVlcnkgPSBjbGFzcyBleHRlbmRzIFJlbW92YWJsZSB7XG5cdCNxdWVyeVR5cGU7XG5cdCNpbml0aWFsU3RhdGU7XG5cdCNyZXZlcnRTdGF0ZTtcblx0I2NhY2hlO1xuXHQjY2xpZW50O1xuXHQjcmV0cnllcjtcblx0I2RlZmF1bHRPcHRpb25zO1xuXHQjYWJvcnRTaWduYWxDb25zdW1lZDtcblx0Y29uc3RydWN0b3IoY29uZmlnKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLiNhYm9ydFNpZ25hbENvbnN1bWVkID0gZmFsc2U7XG5cdFx0dGhpcy4jZGVmYXVsdE9wdGlvbnMgPSBjb25maWcuZGVmYXVsdE9wdGlvbnM7XG5cdFx0dGhpcy5zZXRPcHRpb25zKGNvbmZpZy5vcHRpb25zKTtcblx0XHR0aGlzLm9ic2VydmVycyA9IFtdO1xuXHRcdHRoaXMuI2NsaWVudCA9IGNvbmZpZy5jbGllbnQ7XG5cdFx0dGhpcy4jY2FjaGUgPSB0aGlzLiNjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuXHRcdHRoaXMucXVlcnlLZXkgPSBjb25maWcucXVlcnlLZXk7XG5cdFx0dGhpcy5xdWVyeUhhc2ggPSBjb25maWcucXVlcnlIYXNoO1xuXHRcdHRoaXMuI2luaXRpYWxTdGF0ZSA9IGdldERlZmF1bHRTdGF0ZSh0aGlzLm9wdGlvbnMpO1xuXHRcdHRoaXMuc3RhdGUgPSBjb25maWcuc3RhdGUgPz8gdGhpcy4jaW5pdGlhbFN0YXRlO1xuXHRcdHRoaXMuc2NoZWR1bGVHYygpO1xuXHR9XG5cdC8qKlxuXHQqIFRoZSBgbWV0YWAgb2JqZWN0IHBhc3NlZCBpbiB0aGUgcXVlcnkncyBvcHRpb25zLCBpZiBhbnkuXG5cdCogQHJldHVybnMgVGhlIHF1ZXJ5J3MgYG1ldGFgLCBvciBgdW5kZWZpbmVkYCBpZiBub25lIHdhcyBzZXQuXG5cdCovXG5cdGdldCBtZXRhKCkge1xuXHRcdHJldHVybiB0aGlzLm9wdGlvbnMubWV0YTtcblx0fVxuXHQvKipcblx0KiBgJ2luZmluaXRlJ2AgZm9yIGFuIGluZmluaXRlIHF1ZXJ5LCBvdGhlcndpc2UgYHVuZGVmaW5lZGAuXG5cdCogQGludGVybmFsXG5cdCogQHJldHVybnMgVGhlIHR5cGUgb2YgdGhlIHF1ZXJ5LCBzZXQgZnJvbSB0aGUgYF90eXBlYCBvcHRpb24gKGUuZy4gYCdpbmZpbml0ZSdgKS5cblx0Ki9cblx0Z2V0IHF1ZXJ5VHlwZSgpIHtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlUeXBlO1xuXHR9XG5cdC8qKlxuXHQqIFRoZSBwcm9taXNlIGZvciB0aGUgY3VycmVudGx5IGluLWZsaWdodCBmZXRjaCwgaWYgdGhlIHF1ZXJ5IGlzIGZldGNoaW5nLlxuXHQqIGB1bmRlZmluZWRgIHdoZW4gdGhlIHF1ZXJ5IGlzIG5vdCBmZXRjaGluZy5cblx0KiBAcmV0dXJucyBUaGUgcHJvbWlzZSBvZiB0aGUgaW4tZmxpZ2h0IGZldGNoLCBvciBgdW5kZWZpbmVkYC5cblx0Ki9cblx0Z2V0IHByb21pc2UoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3JldHJ5ZXI/LnByb21pc2U7XG5cdH1cblx0LyoqXG5cdCogUmVwbGFjZXMgdGhlIHF1ZXJ5J3Mgb3B0aW9ucyBhbmQgYXBwbGllcyB0aGVpciBgZ2NUaW1lYC4gSWYgdGhlIHF1ZXJ5IGhhcyBubyBkYXRhIHlldCwgaXQgZ2V0c1xuXHQqIHRoZSBgaW5pdGlhbERhdGFgIGZyb20gdGhlIG5ldyBvcHRpb25zLCBpZiBhbnkuXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgbmV3IHF1ZXJ5IG9wdGlvbnMsIG1lcmdlZCBvbiB0b3Agb2YgdGhlIHF1ZXJ5J3MgZGVmYXVsdCBvcHRpb25zLlxuXHQqL1xuXHRzZXRPcHRpb25zKG9wdGlvbnMpIHtcblx0XHR0aGlzLm9wdGlvbnMgPSB7XG5cdFx0XHQuLi50aGlzLiNkZWZhdWx0T3B0aW9ucyxcblx0XHRcdC4uLm9wdGlvbnNcblx0XHR9O1xuXHRcdGlmIChvcHRpb25zPy5fdHlwZSkgdGhpcy4jcXVlcnlUeXBlID0gb3B0aW9ucy5fdHlwZTtcblx0XHR0aGlzLnVwZGF0ZUdjVGltZSh0aGlzLm9wdGlvbnMuZ2NUaW1lKTtcblx0XHRpZiAodGhpcy5zdGF0ZSAmJiB0aGlzLnN0YXRlLmRhdGEgPT09IHZvaWQgMCkge1xuXHRcdFx0Y29uc3QgZGVmYXVsdFN0YXRlID0gZ2V0RGVmYXVsdFN0YXRlKHRoaXMub3B0aW9ucyk7XG5cdFx0XHRpZiAoZGVmYXVsdFN0YXRlLmRhdGEgIT09IHZvaWQgMCkge1xuXHRcdFx0XHR0aGlzLnNldFN0YXRlKHN1Y2Nlc3NTdGF0ZShkZWZhdWx0U3RhdGUuZGF0YSwgZGVmYXVsdFN0YXRlLmRhdGFVcGRhdGVkQXQpKTtcblx0XHRcdFx0dGhpcy4jaW5pdGlhbFN0YXRlID0gZGVmYXVsdFN0YXRlO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRvcHRpb25hbFJlbW92ZSgpIHtcblx0XHRpZiAoIXRoaXMub2JzZXJ2ZXJzLmxlbmd0aCAmJiB0aGlzLnN0YXRlLmZldGNoU3RhdHVzID09PSBcImlkbGVcIikgdGhpcy4jY2FjaGUucmVtb3ZlKHRoaXMpO1xuXHR9XG5cdC8qKlxuXHQqIFdyaXRlcyBuZXcgZGF0YSB0byB0aGUgcXVlcnkgYW5kIG1hcmtzIGl0IGFzIHN1Y2Nlc3NmdWxseSBmZXRjaGVkLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBuZXdEYXRhIC0gVGhlIGRhdGEgdG8gd3JpdGUuIFN0cnVjdHVyYWwgc2hhcmluZyB3aXRoIHRoZSBjdXJyZW50IGRhdGEgaXMgYXBwbGllZC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFNldCBgdXBkYXRlZEF0YCB0byBvdmVycmlkZSB0aGUgdGltZXN0YW1wLCBhbmQgYG1hbnVhbGAgdG8gbWFyayB0aGUgd3JpdGUgYXNcblx0KiBtYW51YWwgKGUuZy4gZnJvbSBgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhYCkuXG5cdCogQHJldHVybnMgVGhlIGRhdGEgdGhhdCB3YXMgd3JpdHRlbi5cblx0Ki9cblx0c2V0RGF0YShuZXdEYXRhLCBvcHRpb25zKSB7XG5cdFx0Y29uc3QgZGF0YSA9IHJlcGxhY2VEYXRhKHRoaXMuc3RhdGUuZGF0YSwgbmV3RGF0YSwgdGhpcy5vcHRpb25zKTtcblx0XHR0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRkYXRhLFxuXHRcdFx0dHlwZTogXCJzdWNjZXNzXCIsXG5cdFx0XHRkYXRhVXBkYXRlZEF0OiBvcHRpb25zPy51cGRhdGVkQXQsXG5cdFx0XHRtYW51YWw6IG9wdGlvbnM/Lm1hbnVhbFxuXHRcdH0pO1xuXHRcdHJldHVybiBkYXRhO1xuXHR9XG5cdC8qKlxuXHQqIE1lcmdlcyB0aGUgZ2l2ZW4gcGFydGlhbCBzdGF0ZSBkaXJlY3RseSBpbnRvIHRoaXMgcXVlcnkncyBzdGF0ZSwgbm90aWZ5aW5nIG9ic2VydmVycy4gVXNlZFxuXHQqIGJ5IHBlcnNpc3RlbmNlIGFuZCBicm9hZGNhc3QgcGx1Z2lucyB0byByZXN0b3JlIGEgc3RhdGUgc25hcHNob3QsIGFuZCBieSBkZXZ0b29scyB0byBsZXQgYVxuXHQqIHVzZXIgbWFudWFsbHkgdHJpZ2dlciBhIGxvYWRpbmcvZXJyb3Igc3RhdGUgb3IgZWRpdCB0aGUgY2FjaGVkIGRhdGEuXG5cdCogQHBhcmFtIHN0YXRlIC0gVGhlIHBhcnRpYWwgc3RhdGUgdG8gbWVyZ2UgaW50byB0aGUgcXVlcnkncyBzdGF0ZS5cblx0Ki9cblx0c2V0U3RhdGUoc3RhdGUpIHtcblx0XHR0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHR0eXBlOiBcInNldFN0YXRlXCIsXG5cdFx0XHRzdGF0ZVxuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIENhbmNlbHMgdGhlIHF1ZXJ5J3MgY3VycmVudGx5IGluLWZsaWdodCBmZXRjaCwgaWYgYW55LlxuXHQqIC0gUmV0dXJucyBhIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIHRoZSBjYW5jZWxsYXRpb24gaGFzIHNldHRsZWQuXG5cdCogLSBJZiBubyBmZXRjaCBpcyBpbiBwcm9ncmVzcywgcmVzb2x2ZXMgaW1tZWRpYXRlbHkuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBTZXQgYHJldmVydGAgdG8gcmVzdG9yZSB0aGUgc3RhdGUgZnJvbSBiZWZvcmUgdGhlIGZldGNoIHN0YXJ0ZWQsIGFuZCBgc2lsZW50YFxuXHQqIHRvIHN1cHByZXNzIHRoZSBjYW5jZWxsYXRpb24gZXJyb3Igd2hlbiBhIG5ldyBmZXRjaCByZXBsYWNlcyB0aGUgY2FuY2VsbGVkIG9uZS5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIHRoZSBjYW5jZWxsYXRpb24gaGFzIHNldHRsZWQuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGF3YWl0IHF1ZXJ5LmNhbmNlbCgpXG5cdCogYGBgXG5cdCovXG5cdGNhbmNlbChvcHRpb25zKSB7XG5cdFx0Y29uc3QgcHJvbWlzZSA9IHRoaXMuI3JldHJ5ZXI/LnByb21pc2U7XG5cdFx0dGhpcy4jcmV0cnllcj8uY2FuY2VsKG9wdGlvbnMpO1xuXHRcdHJldHVybiBwcm9taXNlID8gcHJvbWlzZS50aGVuKG5vb3ApLmNhdGNoKG5vb3ApIDogUHJvbWlzZS5yZXNvbHZlKCk7XG5cdH1cblx0LyoqXG5cdCogQ2xlYXJzIHRoZSBxdWVyeSdzIGdhcmJhZ2UgY29sbGVjdGlvbiB0aW1lb3V0IGFuZCBzaWxlbnRseSBjYW5jZWxzIGFueVxuXHQqIGluLWZsaWdodCBmZXRjaC4gQ2FsbGVkIGJ5IGBRdWVyeUNhY2hlYCB3aGVuIHRoZSBxdWVyeSBpcyByZW1vdmVkIGZyb21cblx0KiB0aGUgY2FjaGUuXG5cdCogQHNlZSB7QGxpbmsgUXVlcnkjY2FuY2VsfVxuXHQqL1xuXHRkZXN0cm95KCkge1xuXHRcdHN1cGVyLmRlc3Ryb3koKTtcblx0XHR0aGlzLmNhbmNlbCh7IHNpbGVudDogdHJ1ZSB9KTtcblx0fVxuXHQvKipcblx0KiBUaGUgc3RhdGUgdGhlIHF1ZXJ5IHdhcyBjcmVhdGVkIHdpdGguXG5cdCogQGludGVybmFsXG5cdCogQHJldHVybnMgVGhlIHN0YXRlIHRoZSBxdWVyeSBoYWQgd2hlbiBpdCB3YXMgZmlyc3QgY3JlYXRlZCwgdXNlZCBieSB7QGxpbmsgUXVlcnkjcmVzZXR9LlxuXHQqL1xuXHRnZXQgcmVzZXRTdGF0ZSgpIHtcblx0XHRyZXR1cm4gdGhpcy4jaW5pdGlhbFN0YXRlO1xuXHR9XG5cdC8qKlxuXHQqIFJlc2V0cyB0aGUgcXVlcnkgYmFjayB0byBpdHMgaW5pdGlhbCBzdGF0ZSAodGhlIHN0YXRlIGl0IGhhZCB3aGVuIGl0IHdhc1xuXHQqIGZpcnN0IGNyZWF0ZWQsIGUuZy4gYW55IGBpbml0aWFsRGF0YWApLCBkZXN0cm95aW5nIGl0IGZpcnN0IHRvIGNhbmNlbCBhbnlcblx0KiBpbi1mbGlnaHQgZmV0Y2guXG5cdCovXG5cdHJlc2V0KCkge1xuXHRcdHRoaXMuZGVzdHJveSgpO1xuXHRcdHRoaXMuc2V0U3RhdGUodGhpcy5yZXNldFN0YXRlKTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaGFzIGF0IGxlYXN0IG9uZSBvYnNlcnZlciBmb3Igd2hpY2ggYGVuYWJsZWRgXG5cdCogZG9lcyBub3QgcmVzb2x2ZSB0byBgZmFsc2VgLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaGFzIGFuIGVuYWJsZWQgb2JzZXJ2ZXIuXG5cdCovXG5cdGlzQWN0aXZlKCkge1xuXHRcdHJldHVybiB0aGlzLm9ic2VydmVycy5zb21lKChvYnNlcnZlcikgPT4gcmVzb2x2ZVF1ZXJ5VmFsdWUob2JzZXJ2ZXIub3B0aW9ucy5lbmFibGVkLCB0aGlzKSAhPT0gZmFsc2UpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBkaXNhYmxlZCwgbWVhbmluZyBpdCB3aWxsIG5vdCBmZXRjaFxuXHQqIGF1dG9tYXRpY2FsbHkuXG5cdCogLSBJZiB0aGUgcXVlcnkgaGFzIG9ic2VydmVycywgaXQgaXMgZGlzYWJsZWQgd2hlbiBub25lIG9mIHRoZW0gYXJlIGFjdGl2ZVxuXHQqICAgKHNlZSBgaXNBY3RpdmVgKS5cblx0KiAtIElmIHRoZSBxdWVyeSBoYXMgbm8gb2JzZXJ2ZXJzLCBpdCBpcyBkaXNhYmxlZCB3aGVuIGl0cyBgcXVlcnlGbmAgaXNcblx0KiAgIGBza2lwVG9rZW5gIG9yIGl0IGhhcyBuZXZlciBiZWVuIGZldGNoZWQuXG5cdCogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBkaXNhYmxlZC5cblx0Ki9cblx0aXNEaXNhYmxlZCgpIHtcblx0XHRpZiAodGhpcy5nZXRPYnNlcnZlcnNDb3VudCgpID4gMCkgcmV0dXJuICF0aGlzLmlzQWN0aXZlKCk7XG5cdFx0cmV0dXJuIHRoaXMub3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4gfHwgIXRoaXMuaXNGZXRjaGVkKCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGhhcyBiZWVuIGZldGNoZWQsIGkuZS4gaXQgaGFzIHJlc29sdmVkIHdpdGhcblx0KiBlaXRoZXIgZGF0YSBvciBhbiBlcnJvciBhdCBsZWFzdCBvbmNlLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaGFzIGJlZW4gZmV0Y2hlZC5cblx0Ki9cblx0aXNGZXRjaGVkKCkge1xuXHRcdHJldHVybiB0aGlzLnN0YXRlLmRhdGFVcGRhdGVDb3VudCArIHRoaXMuc3RhdGUuZXJyb3JVcGRhdGVDb3VudCA+IDA7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGhhcyBhdCBsZWFzdCBvbmUgb2JzZXJ2ZXIgY29uZmlndXJlZCB3aXRoXG5cdCogYHN0YWxlVGltZTogJ3N0YXRpYydgLCBtZWFuaW5nIGl0IGlzIHRyZWF0ZWQgYXMgbmV2ZXIgc3RhbGUuXG5cdCogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBzdGF0aWMuXG5cdCovXG5cdGlzU3RhdGljKCkge1xuXHRcdGlmICh0aGlzLmdldE9ic2VydmVyc0NvdW50KCkgPiAwKSByZXR1cm4gdGhpcy5vYnNlcnZlcnMuc29tZSgob2JzZXJ2ZXIpID0+IHJlc29sdmVRdWVyeVZhbHVlKG9ic2VydmVyLm9wdGlvbnMuc3RhbGVUaW1lLCB0aGlzKSA9PT0gXCJzdGF0aWNcIik7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBzdGFsZS5cblx0KiAtIElmIHRoZSBxdWVyeSBoYXMgb2JzZXJ2ZXJzLCBkZWZlcnMgdG8gd2hldGhlciBhbnkgb2JzZXJ2ZXIncyBjdXJyZW50XG5cdCogICByZXN1bHQgcmVwb3J0cyBgaXNTdGFsZWAgKHdoaWNoIGFjY291bnRzIGZvciBlYWNoIG9ic2VydmVyJ3Mgb3duXG5cdCogICBgc3RhbGVUaW1lYCBhbmQgYGVuYWJsZWRgIHN0YXRlKS5cblx0KiAtIElmIHRoZSBxdWVyeSBoYXMgbm8gb2JzZXJ2ZXJzLCBpdCBpcyBjb25zaWRlcmVkIHN0YWxlIHdoZW4gaXQgaGFzIG5vXG5cdCogICBkYXRhIG9yIGhhcyBiZWVuIGludmFsaWRhdGVkLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaXMgc3RhbGUuXG5cdCogQHNlZSB7QGxpbmsgUXVlcnkjaXNTdGFsZUJ5VGltZX1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaWYgKHF1ZXJ5LmlzU3RhbGUoKSkge1xuXHQqICAgLy8gcmVmZXRjaCBvciBvdGhlcndpc2UgdHJlYXQgdGhlIGNhY2hlZCBkYXRhIGFzIG91dGRhdGVkXG5cdCogfVxuXHQqIGBgYFxuXHQqL1xuXHRpc1N0YWxlKCkge1xuXHRcdGlmICh0aGlzLmdldE9ic2VydmVyc0NvdW50KCkgPiAwKSByZXR1cm4gdGhpcy5vYnNlcnZlcnMuc29tZSgob2JzZXJ2ZXIpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKS5pc1N0YWxlKTtcblx0XHRyZXR1cm4gdGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDAgfHwgdGhpcy5zdGF0ZS5pc0ludmFsaWRhdGVkO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSdzIGRhdGEgaXMgc3RhbGUgcmVsYXRpdmUgdG8gdGhlIGdpdmVuXG5cdCogYHN0YWxlVGltZWAgKGRlZmF1bHRzIHRvIGAwYCkuXG5cdCogLSBBIHF1ZXJ5IHdpdGggbm8gZGF0YSBpcyBhbHdheXMgc3RhbGUuXG5cdCogLSBgc3RhbGVUaW1lOiAnc3RhdGljJ2AgaXMgbmV2ZXIgc3RhbGUuXG5cdCogLSBBbiBpbnZhbGlkYXRlZCBxdWVyeSBpcyBhbHdheXMgc3RhbGUuXG5cdCogLSBPdGhlcndpc2UsIHN0YWxlbmVzcyBpcyBiYXNlZCBvbiBlbGFwc2VkIHRpbWUgc2luY2UgYGRhdGFVcGRhdGVkQXRgLlxuXHQqIEBwYXJhbSBzdGFsZVRpbWUgLSBUaGUgdGltZSwgaW4gbWlsbGlzZWNvbmRzLCBhZnRlciB3aGljaCBkYXRhIGlzIGNvbnNpZGVyZWQgc3RhbGUsIG9yXG5cdCogYCdzdGF0aWMnYCB0byBuZXZlciB0cmVhdCBleGlzdGluZyBkYXRhIGFzIHN0YWxlLiBBIHF1ZXJ5IHdpdGhvdXQgZGF0YSBpcyBzdGFsZSBlaXRoZXIgd2F5LlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkncyBkYXRhIGlzIHN0YWxlLlxuXHQqIEBzZWUge0BsaW5rIFF1ZXJ5I2lzU3RhbGV9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IGlzU3RhbGUgPSBxdWVyeS5pc1N0YWxlQnlUaW1lKDEwMDAgKiA2MClcblx0KiBgYGBcblx0Ki9cblx0aXNTdGFsZUJ5VGltZShzdGFsZVRpbWUgPSAwKSB7XG5cdFx0aWYgKHRoaXMuc3RhdGUuZGF0YSA9PT0gdm9pZCAwKSByZXR1cm4gdHJ1ZTtcblx0XHRpZiAoc3RhbGVUaW1lID09PSBcInN0YXRpY1wiKSByZXR1cm4gZmFsc2U7XG5cdFx0aWYgKHRoaXMuc3RhdGUuaXNJbnZhbGlkYXRlZCkgcmV0dXJuIHRydWU7XG5cdFx0cmV0dXJuICF0aW1lVW50aWxTdGFsZSh0aGlzLnN0YXRlLmRhdGFVcGRhdGVkQXQsIHN0YWxlVGltZSk7XG5cdH1cblx0LyoqXG5cdCogUmVmZXRjaGVzIHRoZSBxdWVyeSB3aGVuIHRoZSB3aW5kb3cgcmVnYWlucyBmb2N1cywgaWYgYW4gb2JzZXJ2ZXIgd2FudHMgdGhhdCwgYW5kIGNvbnRpbnVlcyBhXG5cdCogcGF1c2VkIGZldGNoLlxuXHQqIEBpbnRlcm5hbFxuXHQqL1xuXHRvbkZvY3VzKCkge1xuXHRcdHRoaXMub2JzZXJ2ZXJzLmZpbmQoKHgpID0+IHguc2hvdWxkRmV0Y2hPbldpbmRvd0ZvY3VzKCkpPy5yZWZldGNoKHsgY2FuY2VsUmVmZXRjaDogZmFsc2UgfSk7XG5cdFx0dGhpcy4jcmV0cnllcj8uY29udGludWUoKTtcblx0fVxuXHQvKipcblx0KiBSZWZldGNoZXMgdGhlIHF1ZXJ5IHdoZW4gdGhlIGFwcCByZWNvbm5lY3RzLCBpZiBhbiBvYnNlcnZlciB3YW50cyB0aGF0LCBhbmQgY29udGludWVzIGEgcGF1c2VkXG5cdCogZmV0Y2guXG5cdCogQGludGVybmFsXG5cdCovXG5cdG9uT25saW5lKCkge1xuXHRcdHRoaXMub2JzZXJ2ZXJzLmZpbmQoKHgpID0+IHguc2hvdWxkRmV0Y2hPblJlY29ubmVjdCgpKT8ucmVmZXRjaCh7IGNhbmNlbFJlZmV0Y2g6IGZhbHNlIH0pO1xuXHRcdHRoaXMuI3JldHJ5ZXI/LmNvbnRpbnVlKCk7XG5cdH1cblx0LyoqXG5cdCogU3Vic2NyaWJlcyBhbiBvYnNlcnZlciB0byB0aGUgcXVlcnkgYW5kIHN0b3BzIGl0cyBnYXJiYWdlIGNvbGxlY3Rpb24uXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIG9ic2VydmVyIC0gVGhlIG9ic2VydmVyIHRvIGFkZC4gQWRkaW5nIGFuIG9ic2VydmVyIHRoYXQgaXMgYWxyZWFkeSBzdWJzY3JpYmVkIGRvZXNcblx0KiBub3RoaW5nLlxuXHQqL1xuXHRhZGRPYnNlcnZlcihvYnNlcnZlcikge1xuXHRcdGlmICghdGhpcy5vYnNlcnZlcnMuaW5jbHVkZXMob2JzZXJ2ZXIpKSB7XG5cdFx0XHR0aGlzLm9ic2VydmVycy5wdXNoKG9ic2VydmVyKTtcblx0XHRcdHRoaXMuY2xlYXJHY1RpbWVvdXQoKTtcblx0XHRcdHRoaXMuI2NhY2hlLm5vdGlmeSh7XG5cdFx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJBZGRlZFwiLFxuXHRcdFx0XHRxdWVyeTogdGhpcyxcblx0XHRcdFx0b2JzZXJ2ZXJcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBVbnN1YnNjcmliZXMgYW4gb2JzZXJ2ZXIgZnJvbSB0aGUgcXVlcnkuXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIG9ic2VydmVyIC0gVGhlIG9ic2VydmVyIHRvIHJlbW92ZS4gV2hlbiB0aGUgbGFzdCBvYnNlcnZlciBpcyByZW1vdmVkLCB0aGUgaW4tZmxpZ2h0XG5cdCogZmV0Y2ggaXMgY2FuY2VsbGVkIGlmIGl0cyBhYm9ydCBzaWduYWwgd2FzIGNvbnN1bWVkIChvdGhlcndpc2Ugb25seSBpdHMgcmV0cmllcyBhcmUgc3RvcHBlZCksXG5cdCogYW5kIGdhcmJhZ2UgY29sbGVjdGlvbiBpcyBzY2hlZHVsZWQuXG5cdCovXG5cdHJlbW92ZU9ic2VydmVyKG9ic2VydmVyKSB7XG5cdFx0Y29uc3QgaW5kZXggPSB0aGlzLm9ic2VydmVycy5pbmRleE9mKG9ic2VydmVyKTtcblx0XHRpZiAoaW5kZXggIT09IC0xKSB7XG5cdFx0XHR0aGlzLm9ic2VydmVycy5zcGxpY2UoaW5kZXgsIDEpO1xuXHRcdFx0aWYgKCF0aGlzLm9ic2VydmVycy5sZW5ndGgpIHtcblx0XHRcdFx0aWYgKHRoaXMuI3JldHJ5ZXIpIHtcblx0XHRcdFx0XHRpZiAodGhpcy4jYWJvcnRTaWduYWxDb25zdW1lZCB8fCB0aGlzLnN0YXRlLmZldGNoU3RhdHVzID09PSBcInBhdXNlZFwiICYmIHRoaXMuc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIikgdGhpcy4jcmV0cnllci5jYW5jZWwoeyByZXZlcnQ6IHRydWUgfSk7XG5cdFx0XHRcdFx0ZWxzZSB0aGlzLiNyZXRyeWVyLmNhbmNlbFJldHJ5KCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0dGhpcy5zY2hlZHVsZUdjKCk7XG5cdFx0XHR9XG5cdFx0XHR0aGlzLiNjYWNoZS5ub3RpZnkoe1xuXHRcdFx0XHR0eXBlOiBcIm9ic2VydmVyUmVtb3ZlZFwiLFxuXHRcdFx0XHRxdWVyeTogdGhpcyxcblx0XHRcdFx0b2JzZXJ2ZXJcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBudW1iZXIgb2Ygb2JzZXJ2ZXJzIGN1cnJlbnRseSBzdWJzY3JpYmVkIHRvIHRoaXMgcXVlcnkuXG5cdCogQHJldHVybnMgVGhlIG51bWJlciBvZiBvYnNlcnZlcnMuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGlmIChxdWVyeS5nZXRPYnNlcnZlcnNDb3VudCgpID09PSAwKSB7XG5cdCogICAvLyBubyBjb21wb25lbnQgaXMgY3VycmVudGx5IHdhdGNoaW5nIHRoaXMgcXVlcnlcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGdldE9ic2VydmVyc0NvdW50KCkge1xuXHRcdHJldHVybiB0aGlzLm9ic2VydmVycy5sZW5ndGg7XG5cdH1cblx0LyoqXG5cdCogTWFya3MgdGhlIHF1ZXJ5IGFzIGludmFsaWRhdGVkLCB1bmxlc3MgaXQgaXMgYWxyZWFkeSBpbnZhbGlkYXRlZC4gVGhpc1xuXHQqIHVwZGF0ZXMgYHN0YXRlLmlzSW52YWxpZGF0ZWRgIGFuZCBub3RpZmllcyBvYnNlcnZlcnMsIGJ1dCBkb2VzIG5vdCBieVxuXHQqIGl0c2VsZiB0cmlnZ2VyIGEgcmVmZXRjaC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnkuaW52YWxpZGF0ZSgpXG5cdCogYGBgXG5cdCovXG5cdGludmFsaWRhdGUoKSB7XG5cdFx0aWYgKCF0aGlzLnN0YXRlLmlzSW52YWxpZGF0ZWQpIHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJpbnZhbGlkYXRlXCIgfSk7XG5cdH1cblx0LyoqXG5cdCogRmV0Y2hlcyB0aGUgcXVlcnksIGkuZS4gcnVucyBpdHMgYHF1ZXJ5Rm5gICh0aHJvdWdoIGFueSBjb25maWd1cmVkXG5cdCogcmV0cnllci9iZWhhdmlvcikgYW5kIHVwZGF0ZXMgdGhlIHF1ZXJ5J3Mgc3RhdGUgd2l0aCB0aGUgcmVzdWx0LlxuXHQqIC0gSWYgYSBmZXRjaCBpcyBhbHJlYWR5IGluIGZsaWdodCwgcmV0dXJucyBpdHMgcHJvbWlzZSBpbnN0ZWFkIG9mXG5cdCogICBzdGFydGluZyBhIG5ldyBvbmUsIHVubGVzcyBgZmV0Y2hPcHRpb25zLmNhbmNlbFJlZmV0Y2hgIGlzIHNldCBhbmQgdGhlXG5cdCogICBxdWVyeSBhbHJlYWR5IGhhcyBkYXRhLCBpbiB3aGljaCBjYXNlIHRoZSBjdXJyZW50IGZldGNoIGlzIHNpbGVudGx5XG5cdCogICBjYW5jZWxsZWQgZmlyc3QuXG5cdCogLSBJZiBgb3B0aW9uc2AgaXMgcGFzc2VkLCBpdCByZXBsYWNlcyB0aGUgcXVlcnkncyBjdXJyZW50IG9wdGlvbnNcblx0KiAgIGJlZm9yZSBmZXRjaGluZy5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFF1ZXJ5IG9wdGlvbnMgdGhhdCByZXBsYWNlIHRoZSBxdWVyeSdzIGN1cnJlbnQgb3B0aW9ucyBiZWZvcmUgZmV0Y2hpbmcuIFRoZXlcblx0KiBhcmUgbm90IGFwcGxpZWQgd2hlbiBhbiBpbi1mbGlnaHQgZmV0Y2ggaXMgcmV1c2VkLlxuXHQqIEBwYXJhbSBmZXRjaE9wdGlvbnMgLSBTZXQgYGNhbmNlbFJlZmV0Y2hgIHRvIGNhbmNlbCBhbiBpbi1mbGlnaHQgZmV0Y2ggZmlyc3QgKG9ubHkgaWYgdGhlIHF1ZXJ5XG5cdCogYWxyZWFkeSBoYXMgZGF0YSksIGFuZCBgbWV0YWAgdG8gcGFzcyBleHRyYSBpbmZvcm1hdGlvbiB0byB0aGUgcXVlcnkncyBiZWhhdmlvci5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBmZXRjaGVkIGRhdGEsIG9yIHJlamVjdHMgd2l0aCB0aGUgZmV0Y2ggZXJyb3IuIElmIHRoZVxuXHQqIGZldGNoIGlzIGNhbmNlbGxlZCB3aXRoIGByZXZlcnRgIHdoaWxlIHRoZSBxdWVyeSBoYXMgZGF0YSwgaXQgcmVzb2x2ZXMgd2l0aCB0aGUgcmVzdG9yZWQgZGF0YVxuXHQqIGluc3RlYWQuXG5cdCovXG5cdGFzeW5jIGZldGNoKG9wdGlvbnMsIGZldGNoT3B0aW9ucykge1xuXHRcdGlmICh0aGlzLnN0YXRlLmZldGNoU3RhdHVzICE9PSBcImlkbGVcIiAmJiB0aGlzLiNyZXRyeWVyPy5zdGF0dXMoKSAhPT0gXCJyZWplY3RlZFwiKSB7XG5cdFx0XHRpZiAodGhpcy5zdGF0ZS5kYXRhICE9PSB2b2lkIDAgJiYgZmV0Y2hPcHRpb25zPy5jYW5jZWxSZWZldGNoKSB0aGlzLmNhbmNlbCh7IHNpbGVudDogdHJ1ZSB9KTtcblx0XHRcdGVsc2UgaWYgKHRoaXMuI3JldHJ5ZXIpIHtcblx0XHRcdFx0dGhpcy4jcmV0cnllci5jb250aW51ZVJldHJ5KCk7XG5cdFx0XHRcdHJldHVybiB0aGlzLiNyZXRyeWVyLnByb21pc2U7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmIChvcHRpb25zKSB0aGlzLnNldE9wdGlvbnMob3B0aW9ucyk7XG5cdFx0aWYgKCF0aGlzLm9wdGlvbnMucXVlcnlGbikge1xuXHRcdFx0Y29uc3Qgb2JzZXJ2ZXIgPSB0aGlzLm9ic2VydmVycy5maW5kKCh4KSA9PiB4Lm9wdGlvbnMucXVlcnlGbik7XG5cdFx0XHRpZiAob2JzZXJ2ZXIpIHRoaXMuc2V0T3B0aW9ucyhvYnNlcnZlci5vcHRpb25zKTtcblx0XHR9XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0aWYgKCFBcnJheS5pc0FycmF5KHRoaXMub3B0aW9ucy5xdWVyeUtleSkpIGNvbnNvbGUuZXJyb3IoYEFzIG9mIHY0LCBxdWVyeUtleSBuZWVkcyB0byBiZSBhbiBBcnJheS4gSWYgeW91IGFyZSB1c2luZyBhIHN0cmluZyBsaWtlICdyZXBvRGF0YScsIHBsZWFzZSBjaGFuZ2UgaXQgdG8gYW4gQXJyYXksIGUuZy4gWydyZXBvRGF0YSddYCk7XG5cdFx0fVxuXHRcdGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRjb25zdCBhZGRTaWduYWxQcm9wZXJ0eSA9IChvYmplY3QpID0+IHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmplY3QsIFwic2lnbmFsXCIsIHtcblx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdFx0Z2V0OiAoKSA9PiB7XG5cdFx0XHRcdFx0dGhpcy4jYWJvcnRTaWduYWxDb25zdW1lZCA9IHRydWU7XG5cdFx0XHRcdFx0cmV0dXJuIGFib3J0Q29udHJvbGxlci5zaWduYWw7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0Y29uc3QgZmV0Y2hGbiA9ICgpID0+IHtcblx0XHRcdGNvbnN0IHF1ZXJ5Rm4gPSBlbnN1cmVRdWVyeUZuKHRoaXMub3B0aW9ucywgZmV0Y2hPcHRpb25zKTtcblx0XHRcdGNvbnN0IGNyZWF0ZVF1ZXJ5Rm5Db250ZXh0ID0gKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBxdWVyeUZuQ29udGV4dCA9IHtcblx0XHRcdFx0XHRjbGllbnQ6IHRoaXMuI2NsaWVudCxcblx0XHRcdFx0XHRxdWVyeUtleTogdGhpcy5xdWVyeUtleSxcblx0XHRcdFx0XHRtZXRhOiB0aGlzLm1ldGFcblx0XHRcdFx0fTtcblx0XHRcdFx0YWRkU2lnbmFsUHJvcGVydHkocXVlcnlGbkNvbnRleHQpO1xuXHRcdFx0XHRyZXR1cm4gcXVlcnlGbkNvbnRleHQ7XG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgcXVlcnlGbkNvbnRleHQgPSBjcmVhdGVRdWVyeUZuQ29udGV4dCgpO1xuXHRcdFx0dGhpcy4jYWJvcnRTaWduYWxDb25zdW1lZCA9IGZhbHNlO1xuXHRcdFx0aWYgKHRoaXMub3B0aW9ucy5wZXJzaXN0ZXIpIHJldHVybiB0aGlzLm9wdGlvbnMucGVyc2lzdGVyKHF1ZXJ5Rm4sIHF1ZXJ5Rm5Db250ZXh0LCB0aGlzKTtcblx0XHRcdHJldHVybiBxdWVyeUZuKHF1ZXJ5Rm5Db250ZXh0KTtcblx0XHR9O1xuXHRcdGNvbnN0IGNyZWF0ZUZldGNoQ29udGV4dCA9ICgpID0+IHtcblx0XHRcdGNvbnN0IGNvbnRleHQgPSB7XG5cdFx0XHRcdGZldGNoT3B0aW9ucyxcblx0XHRcdFx0b3B0aW9uczogdGhpcy5vcHRpb25zLFxuXHRcdFx0XHRxdWVyeUtleTogdGhpcy5xdWVyeUtleSxcblx0XHRcdFx0Y2xpZW50OiB0aGlzLiNjbGllbnQsXG5cdFx0XHRcdHN0YXRlOiB0aGlzLnN0YXRlLFxuXHRcdFx0XHRmZXRjaEZuXG5cdFx0XHR9O1xuXHRcdFx0YWRkU2lnbmFsUHJvcGVydHkoY29udGV4dCk7XG5cdFx0XHRyZXR1cm4gY29udGV4dDtcblx0XHR9O1xuXHRcdGNvbnN0IGNvbnRleHQgPSBjcmVhdGVGZXRjaENvbnRleHQoKTtcblx0XHQodGhpcy4jcXVlcnlUeXBlID09PSBcImluZmluaXRlXCIgPyBpbmZpbml0ZVF1ZXJ5QmVoYXZpb3IodGhpcy5vcHRpb25zLnBhZ2VzKSA6IHRoaXMub3B0aW9ucy5iZWhhdmlvcik/Lm9uRmV0Y2goY29udGV4dCwgdGhpcyk7XG5cdFx0dGhpcy4jcmV2ZXJ0U3RhdGUgPSB0aGlzLnN0YXRlO1xuXHRcdGlmICh0aGlzLnN0YXRlLmZldGNoU3RhdHVzID09PSBcImlkbGVcIiB8fCB0aGlzLnN0YXRlLmZldGNoTWV0YSAhPT0gY29udGV4dC5mZXRjaE9wdGlvbnM/Lm1ldGEpIHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdHR5cGU6IFwiZmV0Y2hcIixcblx0XHRcdG1ldGE6IGNvbnRleHQuZmV0Y2hPcHRpb25zPy5tZXRhXG5cdFx0fSk7XG5cdFx0Y29uc3QgcmV0cnllciA9IHRoaXMuI3JldHJ5ZXIgPSBjcmVhdGVSZXRyeWVyKHtcblx0XHRcdGluaXRpYWxQcm9taXNlOiBmZXRjaE9wdGlvbnM/LmluaXRpYWxQcm9taXNlLFxuXHRcdFx0Zm46IGNvbnRleHQuZmV0Y2hGbixcblx0XHRcdG9uQ2FuY2VsOiAoZXJyb3IpID0+IHtcblx0XHRcdFx0aWYgKGVycm9yIGluc3RhbmNlb2YgQ2FuY2VsbGVkRXJyb3IgJiYgZXJyb3IucmV2ZXJ0KSB0aGlzLnNldFN0YXRlKHtcblx0XHRcdFx0XHQuLi50aGlzLiNyZXZlcnRTdGF0ZSxcblx0XHRcdFx0XHRmZXRjaFN0YXR1czogXCJpZGxlXCJcblx0XHRcdFx0fSk7XG5cdFx0XHRcdGFib3J0Q29udHJvbGxlci5hYm9ydCgpO1xuXHRcdFx0fSxcblx0XHRcdG9uRmFpbDogKGZhaWx1cmVDb3VudCwgZXJyb3IpID0+IHtcblx0XHRcdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHRcdHR5cGU6IFwiZmFpbGVkXCIsXG5cdFx0XHRcdFx0ZmFpbHVyZUNvdW50LFxuXHRcdFx0XHRcdGVycm9yXG5cdFx0XHRcdH0pO1xuXHRcdFx0fSxcblx0XHRcdG9uUGF1c2U6ICgpID0+IHtcblx0XHRcdFx0dGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcInBhdXNlXCIgfSk7XG5cdFx0XHR9LFxuXHRcdFx0b25Db250aW51ZTogKCkgPT4ge1xuXHRcdFx0XHR0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwiY29udGludWVcIiB9KTtcblx0XHRcdH0sXG5cdFx0XHRyZXRyeTogY29udGV4dC5vcHRpb25zLnJldHJ5LFxuXHRcdFx0cmV0cnlEZWxheTogY29udGV4dC5vcHRpb25zLnJldHJ5RGVsYXksXG5cdFx0XHRuZXR3b3JrTW9kZTogY29udGV4dC5vcHRpb25zLm5ldHdvcmtNb2RlLFxuXHRcdFx0Y2FuUnVuOiAoKSA9PiB0cnVlXG5cdFx0fSk7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGRhdGEgPSBhd2FpdCByZXRyeWVyLnN0YXJ0KCk7XG5cdFx0XHRpZiAoZGF0YSA9PT0gdm9pZCAwKSB7XG5cdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNvbnNvbGUuZXJyb3IoYFF1ZXJ5IGRhdGEgY2Fubm90IGJlIHVuZGVmaW5lZC4gUGxlYXNlIG1ha2Ugc3VyZSB0byByZXR1cm4gYSB2YWx1ZSBvdGhlciB0aGFuIHVuZGVmaW5lZCBmcm9tIHlvdXIgcXVlcnkgZnVuY3Rpb24uIEFmZmVjdGVkIHF1ZXJ5IGtleTogJHt0aGlzLnF1ZXJ5SGFzaH1gKTtcblx0XHRcdFx0dGhyb3cgbmV3IEVycm9yKGAke3RoaXMucXVlcnlIYXNofSBkYXRhIGlzIHVuZGVmaW5lZGApO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy5zZXREYXRhKGRhdGEpO1xuXHRcdFx0dGhpcy4jY2FjaGUuY29uZmlnLm9uU3VjY2Vzcz8uKGRhdGEsIHRoaXMpO1xuXHRcdFx0dGhpcy4jY2FjaGUuY29uZmlnLm9uU2V0dGxlZD8uKGRhdGEsIHRoaXMuc3RhdGUuZXJyb3IsIHRoaXMpO1xuXHRcdFx0cmV0dXJuIGRhdGE7XG5cdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdGlmIChlcnJvciBpbnN0YW5jZW9mIENhbmNlbGxlZEVycm9yKSB7XG5cdFx0XHRcdGlmIChlcnJvci5zaWxlbnQpIHJldHVybiB0aGlzLiNyZXRyeWVyLnByb21pc2U7XG5cdFx0XHRcdGVsc2UgaWYgKGVycm9yLnJldmVydCkge1xuXHRcdFx0XHRcdGlmICh0aGlzLnN0YXRlLmRhdGEgPT09IHZvaWQgMCkgdGhyb3cgZXJyb3I7XG5cdFx0XHRcdFx0cmV0dXJuIHRoaXMuc3RhdGUuZGF0YTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHR0eXBlOiBcImVycm9yXCIsXG5cdFx0XHRcdGVycm9yXG5cdFx0XHR9KTtcblx0XHRcdHRoaXMuI2NhY2hlLmNvbmZpZy5vbkVycm9yPy4oZXJyb3IsIHRoaXMpO1xuXHRcdFx0dGhpcy4jY2FjaGUuY29uZmlnLm9uU2V0dGxlZD8uKHRoaXMuc3RhdGUuZGF0YSwgZXJyb3IsIHRoaXMpO1xuXHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdGlmICh0aGlzLiNyZXRyeWVyID09PSByZXRyeWVyKSB0aGlzLiNyZXRyeWVyID0gdm9pZCAwO1xuXHRcdFx0dGhpcy5zY2hlZHVsZUdjKCk7XG5cdFx0fVxuXHR9XG5cdCNkaXNwYXRjaChhY3Rpb24pIHtcblx0XHRjb25zdCByZWR1Y2VyID0gKHN0YXRlKSA9PiB7XG5cdFx0XHRzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XG5cdFx0XHRcdGNhc2UgXCJmYWlsZWRcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRmZXRjaEZhaWx1cmVDb3VudDogYWN0aW9uLmZhaWx1cmVDb3VudCxcblx0XHRcdFx0XHRmZXRjaEZhaWx1cmVSZWFzb246IGFjdGlvbi5lcnJvclxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwicGF1c2VcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRmZXRjaFN0YXR1czogXCJwYXVzZWRcIlxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwiY29udGludWVcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRmZXRjaFN0YXR1czogXCJmZXRjaGluZ1wiXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJmZXRjaFwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdC4uLmZldGNoU3RhdGUoc3RhdGUuZGF0YSwgdGhpcy5vcHRpb25zKSxcblx0XHRcdFx0XHRmZXRjaE1ldGE6IGFjdGlvbi5tZXRhID8/IG51bGxcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcInN1Y2Nlc3NcIjpcblx0XHRcdFx0XHRjb25zdCBuZXdTdGF0ZSA9IHtcblx0XHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdFx0Li4uc3VjY2Vzc1N0YXRlKGFjdGlvbi5kYXRhLCBhY3Rpb24uZGF0YVVwZGF0ZWRBdCksXG5cdFx0XHRcdFx0XHRkYXRhVXBkYXRlQ291bnQ6IHN0YXRlLmRhdGFVcGRhdGVDb3VudCArIDEsXG5cdFx0XHRcdFx0XHQuLi4hYWN0aW9uLm1hbnVhbCAmJiB7XG5cdFx0XHRcdFx0XHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIixcblx0XHRcdFx0XHRcdFx0ZmV0Y2hGYWlsdXJlQ291bnQ6IDAsXG5cdFx0XHRcdFx0XHRcdGZldGNoRmFpbHVyZVJlYXNvbjogbnVsbFxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0dGhpcy4jcmV2ZXJ0U3RhdGUgPSBhY3Rpb24ubWFudWFsID8gbmV3U3RhdGUgOiB2b2lkIDA7XG5cdFx0XHRcdFx0cmV0dXJuIG5ld1N0YXRlO1xuXHRcdFx0XHRjYXNlIFwiZXJyb3JcIjpcblx0XHRcdFx0XHRjb25zdCBlcnJvciA9IGFjdGlvbi5lcnJvcjtcblx0XHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0XHRlcnJvcixcblx0XHRcdFx0XHRcdGVycm9yVXBkYXRlQ291bnQ6IHN0YXRlLmVycm9yVXBkYXRlQ291bnQgKyAxLFxuXHRcdFx0XHRcdFx0ZXJyb3JVcGRhdGVkQXQ6IERhdGUubm93KCksXG5cdFx0XHRcdFx0XHRmZXRjaEZhaWx1cmVDb3VudDogc3RhdGUuZmV0Y2hGYWlsdXJlQ291bnQgKyAxLFxuXHRcdFx0XHRcdFx0ZmV0Y2hGYWlsdXJlUmVhc29uOiBlcnJvcixcblx0XHRcdFx0XHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIixcblx0XHRcdFx0XHRcdHN0YXR1czogXCJlcnJvclwiLFxuXHRcdFx0XHRcdFx0aXNJbnZhbGlkYXRlZDogdHJ1ZVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJpbnZhbGlkYXRlXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0aXNJbnZhbGlkYXRlZDogdHJ1ZVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwic2V0U3RhdGVcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHQuLi5hY3Rpb24uc3RhdGVcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdHRoaXMuc3RhdGUgPSByZWR1Y2VyKHRoaXMuc3RhdGUpO1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy5vYnNlcnZlcnMuc2xpY2UoKS5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuXHRcdFx0XHRvYnNlcnZlci5vblF1ZXJ5VXBkYXRlKCk7XG5cdFx0XHR9KTtcblx0XHRcdHRoaXMuI2NhY2hlLm5vdGlmeSh7XG5cdFx0XHRcdHF1ZXJ5OiB0aGlzLFxuXHRcdFx0XHR0eXBlOiBcInVwZGF0ZWRcIixcblx0XHRcdFx0YWN0aW9uXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxufTtcbi8qKlxuKiBSZXR1cm5zIHRoZSBzdGF0ZSBjaGFuZ2VzIGFwcGxpZWQgd2hlbiBhIHF1ZXJ5IHN0YXJ0cyBmZXRjaGluZy5cbiogQHBhcmFtIGRhdGEgLSBUaGUgcXVlcnkncyBjdXJyZW50IGRhdGEuIElmIGl0IGlzIGB1bmRlZmluZWRgLCB0aGUgcXVlcnkgaXMgYWxzbyByZXNldCB0b1xuKiBgJ3BlbmRpbmcnYCB3aXRoIG5vIGVycm9yLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBxdWVyeSBvcHRpb25zLCB3aG9zZSBgbmV0d29ya01vZGVgIGRlY2lkZXMgd2hldGhlciB0aGUgcXVlcnkgaXMgYCdmZXRjaGluZydgXG4qIG9yIGAncGF1c2VkJ2AuXG4qIEByZXR1cm5zIFRoZSBwYXJ0aWFsIHF1ZXJ5IHN0YXRlIGZvciBhIHN0YXJ0aW5nIGZldGNoLlxuKi9cbmZ1bmN0aW9uIGZldGNoU3RhdGUoZGF0YSwgb3B0aW9ucykge1xuXHRyZXR1cm4ge1xuXHRcdGZldGNoRmFpbHVyZUNvdW50OiAwLFxuXHRcdGZldGNoRmFpbHVyZVJlYXNvbjogbnVsbCxcblx0XHRmZXRjaFN0YXR1czogY2FuRmV0Y2gob3B0aW9ucy5uZXR3b3JrTW9kZSkgPyBcImZldGNoaW5nXCIgOiBcInBhdXNlZFwiLFxuXHRcdC4uLmRhdGEgPT09IHZvaWQgMCAmJiB7XG5cdFx0XHRlcnJvcjogbnVsbCxcblx0XHRcdHN0YXR1czogXCJwZW5kaW5nXCJcblx0XHR9XG5cdH07XG59XG4vKipcbiogUmV0dXJucyB0aGUgc3RhdGUgY2hhbmdlcyBhcHBsaWVkIHdoZW4gYSBxdWVyeSByZWNlaXZlcyBkYXRhLlxuKiBAcGFyYW0gZGF0YSAtIFRoZSBuZXcgZGF0YS5cbiogQHBhcmFtIGRhdGFVcGRhdGVkQXQgLSBUaGUgdGltZXN0YW1wIHRoZSBkYXRhIGlzIHJlY29yZGVkIHdpdGguIERlZmF1bHRzIHRvIHRoZSBjdXJyZW50IHRpbWUuXG4qIEByZXR1cm5zIFRoZSBwYXJ0aWFsIHF1ZXJ5IHN0YXRlIGZvciBhIHN1Y2Nlc3NmdWwgdXBkYXRlLlxuKi9cbmZ1bmN0aW9uIHN1Y2Nlc3NTdGF0ZShkYXRhLCBkYXRhVXBkYXRlZEF0KSB7XG5cdHJldHVybiB7XG5cdFx0ZGF0YSxcblx0XHRkYXRhVXBkYXRlZEF0OiBkYXRhVXBkYXRlZEF0ID8/IERhdGUubm93KCksXG5cdFx0ZXJyb3I6IG51bGwsXG5cdFx0aXNJbnZhbGlkYXRlZDogZmFsc2UsXG5cdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIlxuXHR9O1xufVxuLyoqXG4qIFJldHVybnMgdGhlIGluaXRpYWwgc3RhdGUgb2YgYSBxdWVyeSwgYmFzZWQgb24gaXRzIGBpbml0aWFsRGF0YWAgYW5kIGBpbml0aWFsRGF0YVVwZGF0ZWRBdGBcbiogb3B0aW9ucy5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucy5cbiogQHJldHVybnMgVGhlIGluaXRpYWwgcXVlcnkgc3RhdGU6IGAnc3VjY2VzcydgIGlmIGBpbml0aWFsRGF0YWAgaXMgc2V0LCBvdGhlcndpc2UgYCdwZW5kaW5nJ2AuXG4qL1xuZnVuY3Rpb24gZ2V0RGVmYXVsdFN0YXRlKG9wdGlvbnMpIHtcblx0Y29uc3QgZGF0YSA9IHR5cGVvZiBvcHRpb25zLmluaXRpYWxEYXRhID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb25zLmluaXRpYWxEYXRhKCkgOiBvcHRpb25zLmluaXRpYWxEYXRhO1xuXHRjb25zdCBoYXNEYXRhID0gZGF0YSAhPT0gdm9pZCAwO1xuXHRjb25zdCBpbml0aWFsRGF0YVVwZGF0ZWRBdCA9IGhhc0RhdGEgPyB0eXBlb2Ygb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCA9PT0gXCJmdW5jdGlvblwiID8gb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCgpIDogb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCA6IDA7XG5cdHJldHVybiB7XG5cdFx0ZGF0YSxcblx0XHRkYXRhVXBkYXRlQ291bnQ6IDAsXG5cdFx0ZGF0YVVwZGF0ZWRBdDogaGFzRGF0YSA/IGluaXRpYWxEYXRhVXBkYXRlZEF0ID8/IERhdGUubm93KCkgOiAwLFxuXHRcdGVycm9yOiBudWxsLFxuXHRcdGVycm9yVXBkYXRlQ291bnQ6IDAsXG5cdFx0ZXJyb3JVcGRhdGVkQXQ6IDAsXG5cdFx0ZmV0Y2hGYWlsdXJlQ291bnQ6IDAsXG5cdFx0ZmV0Y2hGYWlsdXJlUmVhc29uOiBudWxsLFxuXHRcdGZldGNoTWV0YTogbnVsbCxcblx0XHRpc0ludmFsaWRhdGVkOiBmYWxzZSxcblx0XHRzdGF0dXM6IGhhc0RhdGEgPyBcInN1Y2Nlc3NcIiA6IFwicGVuZGluZ1wiLFxuXHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIlxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBRdWVyeSwgZmV0Y2hTdGF0ZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeS5qcy5tYXAiLCJpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBpc1ZhbGlkVGltZW91dCwgbm9vcCwgcmVwbGFjZURhdGEsIHJlc29sdmVRdWVyeVZhbHVlLCBzaGFsbG93RXF1YWxPYmplY3RzLCB0aW1lVW50aWxTdGFsZSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCIuL2Vudmlyb25tZW50TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG5pbXBvcnQgeyBmb2N1c01hbmFnZXIgfSBmcm9tIFwiLi9mb2N1c01hbmFnZXIuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBmZXRjaFN0YXRlIH0gZnJvbSBcIi4vcXVlcnkuanNcIjtcbi8vI3JlZ2lvbiBzcmMvcXVlcnlPYnNlcnZlci50c1xuLyoqXG4qIEEgYFF1ZXJ5T2JzZXJ2ZXJgIHdhdGNoZXMgYSBzaW5nbGUgcXVlcnkgaW4gdGhlIGBRdWVyeUNhY2hlYCBhbmQgY29tcHV0ZXMgYVxuKiBgUXVlcnlPYnNlcnZlclJlc3VsdGAgZnJvbSBpdHMgc3RhdGUsIHJlY29tcHV0aW5nIGFuZCBub3RpZnlpbmcgc3Vic2NyaWJlcnNcbiogd2hlbmV2ZXIgdGhlIHVuZGVybHlpbmcgcXVlcnkgKG9yIHRoZSBvYnNlcnZlcidzIG9wdGlvbnMpIGNoYW5nZXMuIEl0IGlzXG4qIHRoZSBwcmltaXRpdmUgdGhhdCBmcmFtZXdvcmsgYWRhcHRlcnMgKGUuZy4gYHVzZVF1ZXJ5YCkgYnVpbGQgdGhlaXIgaG9va3Ncbiogb24gdG9wIG9mLCBidXQgaXQgY2FuIGFsc28gYmUgdXNlZCBkaXJlY3RseSB0byBvYnNlcnZlIGFuZCBzd2l0Y2ggYmV0d2VlblxuKiBxdWVyaWVzIG91dHNpZGUgb2YgYW55IGZyYW1ld29yay5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgUXVlcnlPYnNlcnZlcihxdWVyeUNsaWVudCwge1xuKiAgIHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sXG4qICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcbiogfSlcbipcbiogY29uc3QgdW5zdWJzY3JpYmUgPSBvYnNlcnZlci5zdWJzY3JpYmUoKHJlc3VsdCkgPT4ge1xuKiAgIGNvbnNvbGUubG9nKHJlc3VsdC5kYXRhKVxuKiB9KVxuKiBgYGBcbiovXG52YXIgUXVlcnlPYnNlcnZlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I2NsaWVudDtcblx0I2N1cnJlbnRRdWVyeSA9IHZvaWQgMDtcblx0I2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZSA9IHZvaWQgMDtcblx0I2N1cnJlbnRSZXN1bHQgPSB2b2lkIDA7XG5cdCNjdXJyZW50UmVzdWx0U3RhdGU7XG5cdCNjdXJyZW50UmVzdWx0T3B0aW9ucztcblx0I3NlbGVjdEVycm9yO1xuXHQjc2VsZWN0Rm47XG5cdCNzZWxlY3RSZXN1bHQ7XG5cdCNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGE7XG5cdCNzdGFsZVRpbWVvdXRJZDtcblx0I3JlZmV0Y2hJbnRlcnZhbElkO1xuXHQjY3VycmVudFJlZmV0Y2hJbnRlcnZhbDtcblx0I3RyYWNrZWRQcm9wcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGNvbnN0cnVjdG9yKGNsaWVudCwgb3B0aW9ucykge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy5vcHRpb25zID0gb3B0aW9ucztcblx0XHR0aGlzLiNjbGllbnQgPSBjbGllbnQ7XG5cdFx0dGhpcy4jc2VsZWN0RXJyb3IgPSBudWxsO1xuXHRcdHRoaXMuYmluZE1ldGhvZHMoKTtcblx0XHR0aGlzLnNldE9wdGlvbnMob3B0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogQmluZHMgdGhlIG1ldGhvZHMgb2YgdGhlIHJlc3VsdCAoYHJlZmV0Y2hgKSB0byB0aGUgb2JzZXJ2ZXIsIHNvIHRoZXkga2VlcCB3b3JraW5nIHdoZW4gZGVzdHJ1Y3R1cmVkXG5cdCogZnJvbSBpdC4gU3ViY2xhc3NlcyBvdmVycmlkZSBpdCB0byBiaW5kIHRoZWlyIG93biByZXN1bHQgbWV0aG9kcyBhcyB3ZWxsLlxuXHQqL1xuXHRiaW5kTWV0aG9kcygpIHtcblx0XHR0aGlzLnJlZmV0Y2ggPSB0aGlzLnJlZmV0Y2guYmluZCh0aGlzKTtcblx0fVxuXHRvblN1YnNjcmliZSgpIHtcblx0XHRpZiAodGhpcy5saXN0ZW5lcnMuc2l6ZSA9PT0gMSkge1xuXHRcdFx0dGhpcy4jY3VycmVudFF1ZXJ5LmFkZE9ic2VydmVyKHRoaXMpO1xuXHRcdFx0aWYgKHNob3VsZEZldGNoT25Nb3VudCh0aGlzLiNjdXJyZW50UXVlcnksIHRoaXMub3B0aW9ucykpIHRoaXMuI2V4ZWN1dGVGZXRjaCgpO1xuXHRcdFx0ZWxzZSB0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdFx0dGhpcy4jdXBkYXRlVGltZXJzKCk7XG5cdFx0fVxuXHR9XG5cdG9uVW5zdWJzY3JpYmUoKSB7XG5cdFx0aWYgKCF0aGlzLmhhc0xpc3RlbmVycygpKSB0aGlzLmRlc3Ryb3koKTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHdoZXRoZXIgdGhlIG9ic2VydmVkIHF1ZXJ5IGlzIGN1cnJlbnRseSBzdGFsZSBhbmQgY29uZmlndXJlZFxuXHQqICh2aWEgdGhlIGByZWZldGNoT25SZWNvbm5lY3RgIG9wdGlvbikgdG8gcmVmZXRjaCB3aGVuIHRoZSBuZXR3b3JrXG5cdCogcmVjb25uZWN0cy5cblx0KiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9ic2VydmVyIHNob3VsZCByZWZldGNoIHRoZSBxdWVyeSBvbiByZWNvbm5lY3QuXG5cdCovXG5cdHNob3VsZEZldGNoT25SZWNvbm5lY3QoKSB7XG5cdFx0cmV0dXJuIHNob3VsZEZldGNoT24odGhpcy4jY3VycmVudFF1ZXJ5LCB0aGlzLm9wdGlvbnMsIHRoaXMub3B0aW9ucy5yZWZldGNoT25SZWNvbm5lY3QpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgd2hldGhlciB0aGUgb2JzZXJ2ZWQgcXVlcnkgaXMgY3VycmVudGx5IHN0YWxlIGFuZCBjb25maWd1cmVkXG5cdCogKHZpYSB0aGUgYHJlZmV0Y2hPbldpbmRvd0ZvY3VzYCBvcHRpb24pIHRvIHJlZmV0Y2ggd2hlbiB0aGUgd2luZG93XG5cdCogcmVnYWlucyBmb2N1cy5cblx0KiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9ic2VydmVyIHNob3VsZCByZWZldGNoIHRoZSBxdWVyeSBvbiB3aW5kb3cgZm9jdXMuXG5cdCovXG5cdHNob3VsZEZldGNoT25XaW5kb3dGb2N1cygpIHtcblx0XHRyZXR1cm4gc2hvdWxkRmV0Y2hPbih0aGlzLiNjdXJyZW50UXVlcnksIHRoaXMub3B0aW9ucywgdGhpcy5vcHRpb25zLnJlZmV0Y2hPbldpbmRvd0ZvY3VzKTtcblx0fVxuXHQvKipcblx0KiBTdG9wcyBvYnNlcnZpbmcgdGhlIGN1cnJlbnQgcXVlcnk6IGNsZWFycyBhbGwgbGlzdGVuZXJzLCBjYW5jZWxzIHRoZVxuXHQqIHN0YWxlIGFuZCByZWZldGNoLWludGVydmFsIHRpbWVycywgYW5kIHJlbW92ZXMgdGhpcyBvYnNlcnZlciBmcm9tIHRoZVxuXHQqIHF1ZXJ5IGl0IHdhcyBvYnNlcnZpbmcuXG5cdCovXG5cdGRlc3Ryb3koKSB7XG5cdFx0dGhpcy5saXN0ZW5lcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHRoaXMuI2NsZWFyU3RhbGVUaW1lb3V0KCk7XG5cdFx0dGhpcy4jY2xlYXJSZWZldGNoSW50ZXJ2YWwoKTtcblx0XHR0aGlzLiNjdXJyZW50UXVlcnkucmVtb3ZlT2JzZXJ2ZXIodGhpcyk7XG5cdH1cblx0LyoqXG5cdCogVXBkYXRlcyB0aGUgb2JzZXJ2ZXIncyBvcHRpb25zLiBUaGlzIHdpbGwgcmUtcmVzb2x2ZSB0aGUgcXVlcnkgYmVpbmdcblx0KiBvYnNlcnZlZCAoc3dpdGNoaW5nIHRvIGEgZGlmZmVyZW50IHF1ZXJ5IGlmIHRoZSBgcXVlcnlLZXlgIGNoYW5nZWQpLFxuXHQqIHRyaWdnZXIgYSBmZXRjaCBpZiB0aGUgbmV3IG9wdGlvbnMgcmVxdWlyZSBvbmUgYW5kIHRoZSBvYnNlcnZlciBoYXNcblx0KiBzdWJzY3JpYmVycywgcmVjb21wdXRlIHRoZSBjdXJyZW50IHJlc3VsdCwgYW5kIHJlc2NoZWR1bGUgdGhlIHN0YWxlIGFuZFxuXHQqIHJlZmV0Y2gtaW50ZXJ2YWwgdGltZXJzIGFzIG5lZWRlZC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBuZXcgb2JzZXJ2ZXIgb3B0aW9ucy4gVGhleSBhcmUgZGVmYXVsdGVkIHdpdGgge0BsaW5rXG5cdCogUXVlcnlDbGllbnQjZGVmYXVsdFF1ZXJ5T3B0aW9uc30gYmVmb3JlIGJlaW5nIGFwcGxpZWQuXG5cdCogQHRocm93cyB7RXJyb3J9IElmIGBlbmFibGVkYCBpcyBuZWl0aGVyIGEgYm9vbGVhbiBub3IgYSBmdW5jdGlvbi5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogb2JzZXJ2ZXIuc2V0T3B0aW9ucyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJywgMV0sIHF1ZXJ5Rm46ICgpID0+IGZldGNoUG9zdCgxKSB9KVxuXHQqIC8vIGxhdGVyOiBzd2l0Y2ggdG8gYSBkaWZmZXJlbnQgcXVlcnksIHJldXNpbmcgdGhlIHNhbWUgb2JzZXJ2ZXJcblx0KiBvYnNlcnZlci5zZXRPcHRpb25zKHsgcXVlcnlLZXk6IFsncG9zdHMnLCAyXSwgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KDIpIH0pXG5cdCogYGBgXG5cdCovXG5cdHNldE9wdGlvbnMob3B0aW9ucykge1xuXHRcdGNvbnN0IHByZXZPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuXHRcdGNvbnN0IHByZXZRdWVyeSA9IHRoaXMuI2N1cnJlbnRRdWVyeTtcblx0XHR0aGlzLm9wdGlvbnMgPSB0aGlzLiNjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcblx0XHRpZiAodGhpcy5vcHRpb25zLmVuYWJsZWQgIT09IHZvaWQgMCAmJiB0eXBlb2YgdGhpcy5vcHRpb25zLmVuYWJsZWQgIT09IFwiYm9vbGVhblwiICYmIHR5cGVvZiB0aGlzLm9wdGlvbnMuZW5hYmxlZCAhPT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiByZXNvbHZlUXVlcnlWYWx1ZSh0aGlzLm9wdGlvbnMuZW5hYmxlZCwgdGhpcy4jY3VycmVudFF1ZXJ5KSAhPT0gXCJib29sZWFuXCIpIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIGVuYWJsZWQgdG8gYmUgYSBib29sZWFuIG9yIGEgY2FsbGJhY2sgdGhhdCByZXR1cm5zIGEgYm9vbGVhblwiKTtcblx0XHR0aGlzLiN1cGRhdGVRdWVyeSgpO1xuXHRcdHRoaXMuI2N1cnJlbnRRdWVyeS5zZXRPcHRpb25zKHRoaXMub3B0aW9ucyk7XG5cdFx0aWYgKHByZXZPcHRpb25zLl9kZWZhdWx0ZWQgJiYgIXNoYWxsb3dFcXVhbE9iamVjdHModGhpcy5vcHRpb25zLCBwcmV2T3B0aW9ucykpIHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkubm90aWZ5KHtcblx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJPcHRpb25zVXBkYXRlZFwiLFxuXHRcdFx0cXVlcnk6IHRoaXMuI2N1cnJlbnRRdWVyeSxcblx0XHRcdG9ic2VydmVyOiB0aGlzXG5cdFx0fSk7XG5cdFx0Y29uc3QgbW91bnRlZCA9IHRoaXMuaGFzTGlzdGVuZXJzKCk7XG5cdFx0aWYgKG1vdW50ZWQgJiYgc2hvdWxkRmV0Y2hPcHRpb25hbGx5KHRoaXMuI2N1cnJlbnRRdWVyeSwgcHJldlF1ZXJ5LCB0aGlzLm9wdGlvbnMsIHByZXZPcHRpb25zKSkgdGhpcy4jZXhlY3V0ZUZldGNoKCk7XG5cdFx0dGhpcy51cGRhdGVSZXN1bHQoKTtcblx0XHRpZiAobW91bnRlZCAmJiAodGhpcy4jY3VycmVudFF1ZXJ5ICE9PSBwcmV2UXVlcnkgfHwgcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IHJlc29sdmVRdWVyeVZhbHVlKHByZXZPcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgfHwgcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLnN0YWxlVGltZSwgdGhpcy4jY3VycmVudFF1ZXJ5KSAhPT0gcmVzb2x2ZVF1ZXJ5VmFsdWUocHJldk9wdGlvbnMuc3RhbGVUaW1lLCB0aGlzLiNjdXJyZW50UXVlcnkpKSkgdGhpcy4jdXBkYXRlU3RhbGVUaW1lb3V0KCk7XG5cdFx0Y29uc3QgbmV4dFJlZmV0Y2hJbnRlcnZhbCA9IHRoaXMuI2NvbXB1dGVSZWZldGNoSW50ZXJ2YWwoKTtcblx0XHRpZiAobW91bnRlZCAmJiAodGhpcy4jY3VycmVudFF1ZXJ5ICE9PSBwcmV2UXVlcnkgfHwgcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IHJlc29sdmVRdWVyeVZhbHVlKHByZXZPcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgfHwgbmV4dFJlZmV0Y2hJbnRlcnZhbCAhPT0gdGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCkpIHRoaXMuI3VwZGF0ZVJlZmV0Y2hJbnRlcnZhbChuZXh0UmVmZXRjaEludGVydmFsKTtcblx0fVxuXHQvKipcblx0KiBDb21wdXRlcyB0aGUgcmVzdWx0IHRoZSBvYnNlcnZlciB3b3VsZCBwcm9kdWNlIGZvciB0aGUgZ2l2ZW4gKGFscmVhZHktZGVmYXVsdGVkKSBvcHRpb25zXG5cdCogcmlnaHQgbm93LCBidWlsZGluZyB0aGUgdW5kZXJseWluZyBgUXVlcnlgIGlmIGl0IGRvZXNuJ3QgZXhpc3QgeWV0LCB3aXRob3V0IHdhaXRpbmcgZm9yIGFcblx0KiBzdWJzY3JpcHRpb24gY2FsbGJhY2suIENhbGxlZCBieSBmcmFtZXdvcmsgYWRhcHRlcnMgb24gZXZlcnkgcmVuZGVyIChlLmcuIGB1c2VRdWVyeWApIHNvIHRoZVxuXHQqIHJldHVybmVkIHZhbHVlIGlzIGF2YWlsYWJsZSBzeW5jaHJvbm91c2x5LCBhaGVhZCBvZiBgc2V0T3B0aW9uc2AgdHJpZ2dlcmluZyBhbiBhY3R1YWwgZmV0Y2guXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgZGVmYXVsdGVkIG9ic2VydmVyIG9wdGlvbnMgdG8gY29tcHV0ZSB0aGUgcmVzdWx0IGZvci5cblx0KiBAcmV0dXJucyBUaGUgcmVzdWx0IGZvciB0aGUgZ2l2ZW4gb3B0aW9ucy5cblx0Ki9cblx0Z2V0T3B0aW1pc3RpY1Jlc3VsdChvcHRpb25zKSB7XG5cdFx0Y29uc3QgcXVlcnkgPSB0aGlzLiNjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmJ1aWxkKHRoaXMuI2NsaWVudCwgb3B0aW9ucyk7XG5cdFx0Y29uc3QgcmVzdWx0ID0gdGhpcy5jcmVhdGVSZXN1bHQocXVlcnksIG9wdGlvbnMpO1xuXHRcdGlmICghc2hhbGxvd0VxdWFsT2JqZWN0cyh0aGlzLmdldEN1cnJlbnRSZXN1bHQoKSwgcmVzdWx0KSkge1xuXHRcdFx0dGhpcy4jY3VycmVudFJlc3VsdCA9IHJlc3VsdDtcblx0XHRcdHRoaXMuI2N1cnJlbnRSZXN1bHRPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuXHRcdFx0dGhpcy4jY3VycmVudFJlc3VsdFN0YXRlID0gdGhpcy4jY3VycmVudFF1ZXJ5LnN0YXRlO1xuXHRcdH1cblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG1vc3QgcmVjZW50bHkgY29tcHV0ZWQgYFF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgIGZvciB0aGVcblx0KiBvYnNlcnZlZCBxdWVyeS4gVGhpcyBpcyBhIHBvaW50LWluLXRpbWUgcmVhZDsgdG8gYmUgbm90aWZpZWQgb2YgdXBkYXRlc1xuXHQqIGFzIHRoZXkgaGFwcGVuLCBzdWJzY3JpYmUgdG8gdGhlIG9ic2VydmVyIGluc3RlYWQgKGl0cyBpbmhlcml0ZWRcblx0KiBgc3Vic2NyaWJlYCBtZXRob2QpLlxuXHQqIEByZXR1cm5zIFRoZSBvYnNlcnZlcidzIGxhdGVzdCByZXN1bHQuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHJlc3VsdCA9IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuXHQqIGNvbnNvbGUubG9nKHJlc3VsdC5zdGF0dXMsIHJlc3VsdC5kYXRhKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRDdXJyZW50UmVzdWx0KCkge1xuXHRcdHJldHVybiB0aGlzLiNjdXJyZW50UmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIFdyYXBzIGEgYFF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgIGluIGEgYFByb3h5YCB0aGF0IHJlY29yZHMgd2hpY2ggcHJvcGVydGllcyBhcmUgcmVhZCwgdmlhXG5cdCoge0BsaW5rIFF1ZXJ5T2JzZXJ2ZXIjdHJhY2tQcm9wfSAoYW5kIGFuIG9wdGlvbmFsIGBvblByb3BUcmFja2VkYCBjYWxsYmFjaykuIFVzZWQgYnkgZnJhbWV3b3JrXG5cdCogYWRhcHRlcnMgd2hlbiBgbm90aWZ5T25DaGFuZ2VQcm9wc2AgaXMgbm90IHNldCwgdG8gaW1wbGVtZW50IGl0cyBkZWZhdWx0IFwib25seSByZS1yZW5kZXIgb25cblx0KiBwcm9wZXJ0aWVzIHlvdSBhY3R1YWxseSByZWFkXCIgYmVoYXZpb3IuXG5cdCogQHBhcmFtIHJlc3VsdCAtIFRoZSByZXN1bHQgdG8gd3JhcC5cblx0KiBAcGFyYW0gb25Qcm9wVHJhY2tlZCAtIENhbGxlZCB3aXRoIHRoZSBuYW1lIG9mIGVhY2ggcHJvcGVydHkgdGhhdCBpcyByZWFkLlxuXHQqIEByZXR1cm5zIEEgcHJveHkgb2YgYHJlc3VsdGAgdGhhdCB0cmFja3MgcHJvcGVydHkgcmVhZHMuXG5cdCovXG5cdHRyYWNrUmVzdWx0KHJlc3VsdCwgb25Qcm9wVHJhY2tlZCkge1xuXHRcdHJldHVybiBuZXcgUHJveHkocmVzdWx0LCB7IGdldDogKHRhcmdldCwga2V5KSA9PiB7XG5cdFx0XHR0aGlzLnRyYWNrUHJvcChrZXkpO1xuXHRcdFx0b25Qcm9wVHJhY2tlZD8uKGtleSk7XG5cdFx0XHRyZXR1cm4gUmVmbGVjdC5nZXQodGFyZ2V0LCBrZXkpO1xuXHRcdH0gfSk7XG5cdH1cblx0LyoqXG5cdCogUmVjb3JkcyB0aGF0IHRoZSBnaXZlbiBgUXVlcnlPYnNlcnZlclJlc3VsdGAgcHJvcGVydHkgd2FzIHJlYWQsIHNvIGEgc3Vic2VxdWVudCB1cGRhdGUgb25seVxuXHQqIG5vdGlmaWVzIHRoaXMgb2JzZXJ2ZXIgaWYgYSB0cmFja2VkIHByb3BlcnR5IGFjdHVhbGx5IGNoYW5nZWQuIE5vcm1hbGx5IGNhbGxlZCBpbmRpcmVjdGx5IHZpYVxuXHQqIHtAbGluayBRdWVyeU9ic2VydmVyI3RyYWNrUmVzdWx0fSdzIHByb3h5OyBleHBvc2VkIGRpcmVjdGx5IGZvciBhZGFwdGVycyB0aGF0IHRyYWNrIHByb3BlcnR5XG5cdCogYWNjZXNzIHRoZW1zZWx2ZXMgKGUuZy4gdGhyb3VnaCB0aGVpciBvd24gcmVhY3Rpdml0eSBzeXN0ZW0pIGluc3RlYWQgb2YgdmlhIHRoZSBwcm94eS5cblx0KiBAcGFyYW0ga2V5IC0gVGhlIG5hbWUgb2YgdGhlIHByb3BlcnR5IHRoYXQgd2FzIHJlYWQuXG5cdCovXG5cdHRyYWNrUHJvcChrZXkpIHtcblx0XHR0aGlzLiN0cmFja2VkUHJvcHMuYWRkKGtleSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgYFF1ZXJ5YCBpbnN0YW5jZSB0aGlzIG9ic2VydmVyIGlzIGN1cnJlbnRseSBvYnNlcnZpbmcuXG5cdCogQHJldHVybnMgVGhlIG9ic2VydmVkIHF1ZXJ5LlxuXHQqL1xuXHRnZXRDdXJyZW50UXVlcnkoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRRdWVyeTtcblx0fVxuXHQvKipcblx0KiBSZWZldGNoZXMgdGhlIG9ic2VydmVkIHF1ZXJ5IGFuZCByZXR1cm5zIGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGhcblx0KiB0aGUgcmVzdWx0aW5nIGBRdWVyeU9ic2VydmVyUmVzdWx0YC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFNldCBgY2FuY2VsUmVmZXRjaGAgdG8gYGZhbHNlYCB0byBrZWVwIGEgcnVubmluZyBmZXRjaCBpbnN0ZWFkIG9mIGNhbmNlbGxpbmdcblx0KiBpdCwgYW5kIGB0aHJvd09uRXJyb3JgIHRvIGB0cnVlYCB0byByZWplY3Qgd2hlbiB0aGUgcmVmZXRjaCBmYWlscy5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSByZXN1bHQgYWZ0ZXIgdGhlIHJlZmV0Y2guXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG9ic2VydmVyLnJlZmV0Y2goeyBjYW5jZWxSZWZldGNoOiBmYWxzZSB9KVxuXHQqIGNvbnNvbGUubG9nKHJlc3VsdC5kYXRhKVxuXHQqIGBgYFxuXHQqL1xuXHRyZWZldGNoKHsgLi4ub3B0aW9ucyB9ID0ge30pIHtcblx0XHRyZXR1cm4gdGhpcy5mZXRjaCh7IC4uLm9wdGlvbnMgfSk7XG5cdH1cblx0LyoqXG5cdCogRmV0Y2hlcyBhIHF1ZXJ5IGRlZmluZWQgYnkgdGhlIGdpdmVuIG9wdGlvbnMgd2l0aG91dCBhZmZlY3RpbmcgdGhpc1xuXHQqIG9ic2VydmVyJ3Mgb3duIHRyYWNrZWQgcXVlcnkgb3IgcmVzdWx0LCBhbmQgcmV0dXJucyBhIHByb21pc2UgdGhhdFxuXHQqIHJlc29sdmVzIHdpdGggdGhlIGBRdWVyeU9ic2VydmVyUmVzdWx0YCBmb3IgdGhhdCBmZXRjaC4gVGhpcyBpcyB1c2VmdWxcblx0KiBmb3IgcHJlZmV0Y2hpbmcgZGF0YSB0aGF0IGFub3RoZXIgb2JzZXJ2ZXIgKGUuZy4gYSBxdWVyeSBhYm91dCB0byBiZVxuXHQqIG5hdmlnYXRlZCB0bykgd2lsbCBuZWVkLCBhaGVhZCBvZiB0aW1lLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9ic2VydmVyIG9wdGlvbnMgb2YgdGhlIHF1ZXJ5IHRvIGZldGNoLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHJlc3VsdCBmb3IgdGhlIGZldGNoZWQgcXVlcnkuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG9ic2VydmVyLmZldGNoT3B0aW1pc3RpYyh7XG5cdCogICBxdWVyeUtleTogWydwb3N0cycsIDJdLFxuXHQqICAgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KDIpLFxuXHQqIH0pXG5cdCogY29uc29sZS5sb2cocmVzdWx0LmRhdGEpXG5cdCogYGBgXG5cdCovXG5cdGZldGNoT3B0aW1pc3RpYyhvcHRpb25zKSB7XG5cdFx0Y29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHRoaXMuI2NsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5idWlsZCh0aGlzLiNjbGllbnQsIGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRcdGxldCB1bnN1YnNjcmliZSA9ICgpID0+IHt9O1xuXHRcdGxldCByZXNvbHZlRWFybHk7XG5cdFx0Y29uc3QgY2FjaGVQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdHJlc29sdmVFYXJseSA9IHJlc29sdmU7XG5cdFx0XHR1bnN1YnNjcmliZSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkuc3Vic2NyaWJlKChldmVudCkgPT4ge1xuXHRcdFx0XHRpZiAoZXZlbnQudHlwZSA9PT0gXCJ1cGRhdGVkXCIgJiYgZXZlbnQucXVlcnkucXVlcnlIYXNoID09PSBxdWVyeS5xdWVyeUhhc2ggJiYgcXVlcnkuc3RhdGUuZGF0YSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0dW5zdWJzY3JpYmUoKTtcblx0XHRcdFx0XHRyZXNvbHZlKHRoaXMuY3JlYXRlUmVzdWx0KHF1ZXJ5LCBkZWZhdWx0ZWRPcHRpb25zKSk7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdHJldHVybiBQcm9taXNlLnJhY2UoW3F1ZXJ5LmZldGNoKGRlZmF1bHRlZE9wdGlvbnMpLnRoZW4oKCkgPT4ge1xuXHRcdFx0Y29uc3QgcmVzdWx0ID0gdGhpcy5jcmVhdGVSZXN1bHQocXVlcnksIGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRcdFx0cmVzb2x2ZUVhcmx5Py4ocmVzdWx0KTtcblx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fSkuZmluYWxseSgoKSA9PiB7XG5cdFx0XHR1bnN1YnNjcmliZSgpO1xuXHRcdH0pLCBjYWNoZVByb21pc2VdKTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIHRoZSBvYnNlcnZlZCBxdWVyeSBhbmQgdXBkYXRlcyB0aGUgcmVzdWx0IG9uY2UgdGhlIGZldGNoIHNldHRsZXMuIFVzZWQgYnkgYHJlZmV0Y2hgIGFuZCxcblx0KiBpbiBgSW5maW5pdGVRdWVyeU9ic2VydmVyYCwgdG8gZmV0Y2ggbW9yZSBwYWdlcy5cblx0KiBAcGFyYW0gZmV0Y2hPcHRpb25zIC0gT3B0aW9ucyBmb3IgdGhpcyBmZXRjaC4gYGNhbmNlbFJlZmV0Y2hgIGRlZmF1bHRzIHRvIGB0cnVlYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSB1cGRhdGVkIHJlc3VsdC5cblx0Ki9cblx0ZmV0Y2goZmV0Y2hPcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuI2V4ZWN1dGVGZXRjaCh7XG5cdFx0XHQuLi5mZXRjaE9wdGlvbnMsXG5cdFx0XHRjYW5jZWxSZWZldGNoOiBmZXRjaE9wdGlvbnMuY2FuY2VsUmVmZXRjaCA/PyB0cnVlXG5cdFx0fSkudGhlbigoKSA9PiB7XG5cdFx0XHR0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG5cdFx0fSk7XG5cdH1cblx0I2V4ZWN1dGVGZXRjaChmZXRjaE9wdGlvbnMpIHtcblx0XHR0aGlzLiN1cGRhdGVRdWVyeSgpO1xuXHRcdGxldCBwcm9taXNlID0gdGhpcy4jY3VycmVudFF1ZXJ5LmZldGNoKHRoaXMub3B0aW9ucywgZmV0Y2hPcHRpb25zKTtcblx0XHRpZiAoIWZldGNoT3B0aW9ucz8udGhyb3dPbkVycm9yKSBwcm9taXNlID0gcHJvbWlzZS5jYXRjaChub29wKTtcblx0XHRyZXR1cm4gcHJvbWlzZTtcblx0fVxuXHQjc2hvdWxkU2NoZWR1bGVUaW1lcih0aW1lb3V0KSB7XG5cdFx0cmV0dXJuICFpc1NlcnZlcigpICYmIHJlc29sdmVRdWVyeVZhbHVlKHRoaXMub3B0aW9ucy5lbmFibGVkLCB0aGlzLiNjdXJyZW50UXVlcnkpICE9PSBmYWxzZSAmJiBpc1ZhbGlkVGltZW91dCh0aW1lb3V0KTtcblx0fVxuXHQjdXBkYXRlU3RhbGVUaW1lb3V0KCkge1xuXHRcdHRoaXMuI2NsZWFyU3RhbGVUaW1lb3V0KCk7XG5cdFx0Y29uc3Qgc3RhbGVUaW1lID0gcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLnN0YWxlVGltZSwgdGhpcy4jY3VycmVudFF1ZXJ5KTtcblx0XHRpZiAodGhpcy4jY3VycmVudFJlc3VsdC5pc1N0YWxlIHx8ICF0aGlzLiNzaG91bGRTY2hlZHVsZVRpbWVyKHN0YWxlVGltZSkpIHJldHVybjtcblx0XHRjb25zdCB0aW1lb3V0ID0gdGltZVVudGlsU3RhbGUodGhpcy4jY3VycmVudFJlc3VsdC5kYXRhVXBkYXRlZEF0LCBzdGFsZVRpbWUpICsgMTtcblx0XHR0aGlzLiNzdGFsZVRpbWVvdXRJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0aWYgKCF0aGlzLiNjdXJyZW50UmVzdWx0LmlzU3RhbGUpIHRoaXMudXBkYXRlUmVzdWx0KCk7XG5cdFx0fSwgdGltZW91dCk7XG5cdH1cblx0I2NvbXB1dGVSZWZldGNoSW50ZXJ2YWwoKSB7XG5cdFx0cmV0dXJuIHJlc29sdmVRdWVyeVZhbHVlKHRoaXMub3B0aW9ucy5yZWZldGNoSW50ZXJ2YWwsIHRoaXMuI2N1cnJlbnRRdWVyeSkgPz8gZmFsc2U7XG5cdH1cblx0I3VwZGF0ZVJlZmV0Y2hJbnRlcnZhbChuZXh0SW50ZXJ2YWwpIHtcblx0XHR0aGlzLiNjbGVhclJlZmV0Y2hJbnRlcnZhbCgpO1xuXHRcdHRoaXMuI2N1cnJlbnRSZWZldGNoSW50ZXJ2YWwgPSBuZXh0SW50ZXJ2YWw7XG5cdFx0aWYgKHRoaXMuI2N1cnJlbnRSZWZldGNoSW50ZXJ2YWwgPT09IDAgfHwgIXRoaXMuI3Nob3VsZFNjaGVkdWxlVGltZXIodGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCkpIHJldHVybjtcblx0XHR0aGlzLiNyZWZldGNoSW50ZXJ2YWxJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldEludGVydmFsKCgpID0+IHtcblx0XHRcdGlmICh0aGlzLm9wdGlvbnMucmVmZXRjaEludGVydmFsSW5CYWNrZ3JvdW5kIHx8IGZvY3VzTWFuYWdlci5pc0ZvY3VzZWQoKSkgdGhpcy4jZXhlY3V0ZUZldGNoKCk7XG5cdFx0fSwgdGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCk7XG5cdH1cblx0I3VwZGF0ZVRpbWVycygpIHtcblx0XHR0aGlzLiN1cGRhdGVTdGFsZVRpbWVvdXQoKTtcblx0XHR0aGlzLiN1cGRhdGVSZWZldGNoSW50ZXJ2YWwodGhpcy4jY29tcHV0ZVJlZmV0Y2hJbnRlcnZhbCgpKTtcblx0fVxuXHQjY2xlYXJTdGFsZVRpbWVvdXQoKSB7XG5cdFx0aWYgKHRoaXMuI3N0YWxlVGltZW91dElkICE9PSB2b2lkIDApIHtcblx0XHRcdHRpbWVvdXRNYW5hZ2VyLmNsZWFyVGltZW91dCh0aGlzLiNzdGFsZVRpbWVvdXRJZCk7XG5cdFx0XHR0aGlzLiNzdGFsZVRpbWVvdXRJZCA9IHZvaWQgMDtcblx0XHR9XG5cdH1cblx0I2NsZWFyUmVmZXRjaEludGVydmFsKCkge1xuXHRcdGlmICh0aGlzLiNyZWZldGNoSW50ZXJ2YWxJZCAhPT0gdm9pZCAwKSB7XG5cdFx0XHR0aW1lb3V0TWFuYWdlci5jbGVhckludGVydmFsKHRoaXMuI3JlZmV0Y2hJbnRlcnZhbElkKTtcblx0XHRcdHRoaXMuI3JlZmV0Y2hJbnRlcnZhbElkID0gdm9pZCAwO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBDb21wdXRlcyB0aGUgcmVzdWx0IGZvciBhIHF1ZXJ5IGFuZCBvcHRpb25zIGZyb20gdGhlIHF1ZXJ5J3Mgc3RhdGUsIGFwcGx5aW5nIGBzZWxlY3RgLFxuXHQqIGBwbGFjZWhvbGRlckRhdGFgLCBhbmQgdGhlIGRlcml2ZWQgZmxhZ3MuIFN1YmNsYXNzZXMgb3ZlcnJpZGUgaXQgdG8gYWRkIHRoZWlyIG93biBmaWVsZHMuXG5cdCogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGNvbXB1dGUgdGhlIHJlc3VsdCBmb3IuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgb2JzZXJ2ZXIgb3B0aW9ucyB0byBjb21wdXRlIHRoZSByZXN1bHQgd2l0aC5cblx0KiBAcmV0dXJucyBUaGUgY29tcHV0ZWQgcmVzdWx0LlxuXHQqL1xuXHRjcmVhdGVSZXN1bHQocXVlcnksIG9wdGlvbnMpIHtcblx0XHRjb25zdCBwcmV2UXVlcnkgPSB0aGlzLiNjdXJyZW50UXVlcnk7XG5cdFx0Y29uc3QgcHJldk9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG5cdFx0Y29uc3QgcHJldlJlc3VsdCA9IHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG5cdFx0Y29uc3QgcHJldlJlc3VsdFN0YXRlID0gdGhpcy4jY3VycmVudFJlc3VsdFN0YXRlO1xuXHRcdGNvbnN0IHByZXZSZXN1bHRPcHRpb25zID0gdGhpcy4jY3VycmVudFJlc3VsdE9wdGlvbnM7XG5cdFx0Y29uc3QgcXVlcnlJbml0aWFsU3RhdGUgPSBxdWVyeSAhPT0gcHJldlF1ZXJ5ID8gcXVlcnkuc3RhdGUgOiB0aGlzLiNjdXJyZW50UXVlcnlJbml0aWFsU3RhdGU7XG5cdFx0Y29uc3QgeyBzdGF0ZSB9ID0gcXVlcnk7XG5cdFx0bGV0IG5ld1N0YXRlID0geyAuLi5zdGF0ZSB9O1xuXHRcdGxldCBpc1BsYWNlaG9sZGVyRGF0YSA9IGZhbHNlO1xuXHRcdGxldCBkYXRhO1xuXHRcdGlmIChvcHRpb25zLl9vcHRpbWlzdGljUmVzdWx0cykge1xuXHRcdFx0Y29uc3QgbW91bnRlZCA9IHRoaXMuaGFzTGlzdGVuZXJzKCk7XG5cdFx0XHRjb25zdCBmZXRjaE9uTW91bnQgPSAhbW91bnRlZCAmJiBzaG91bGRGZXRjaE9uTW91bnQocXVlcnksIG9wdGlvbnMpO1xuXHRcdFx0Y29uc3QgZmV0Y2hPcHRpb25hbGx5ID0gbW91bnRlZCAmJiBzaG91bGRGZXRjaE9wdGlvbmFsbHkocXVlcnksIHByZXZRdWVyeSwgb3B0aW9ucywgcHJldk9wdGlvbnMpO1xuXHRcdFx0aWYgKGZldGNoT25Nb3VudCB8fCBmZXRjaE9wdGlvbmFsbHkpIG5ld1N0YXRlID0ge1xuXHRcdFx0XHQuLi5uZXdTdGF0ZSxcblx0XHRcdFx0Li4uZmV0Y2hTdGF0ZShzdGF0ZS5kYXRhLCBxdWVyeS5vcHRpb25zKVxuXHRcdFx0fTtcblx0XHRcdGlmIChvcHRpb25zLl9vcHRpbWlzdGljUmVzdWx0cyA9PT0gXCJpc1Jlc3RvcmluZ1wiKSBuZXdTdGF0ZS5mZXRjaFN0YXR1cyA9IFwiaWRsZVwiO1xuXHRcdH1cblx0XHRsZXQgeyBlcnJvciwgZXJyb3JVcGRhdGVkQXQsIHN0YXR1cyB9ID0gbmV3U3RhdGU7XG5cdFx0ZGF0YSA9IG5ld1N0YXRlLmRhdGE7XG5cdFx0bGV0IHNraXBTZWxlY3QgPSBmYWxzZTtcblx0XHRpZiAob3B0aW9ucy5wbGFjZWhvbGRlckRhdGEgIT09IHZvaWQgMCAmJiBkYXRhID09PSB2b2lkIDAgJiYgc3RhdHVzID09PSBcInBlbmRpbmdcIikge1xuXHRcdFx0bGV0IHBsYWNlaG9sZGVyRGF0YTtcblx0XHRcdGlmIChwcmV2UmVzdWx0Py5pc1BsYWNlaG9sZGVyRGF0YSAmJiBvcHRpb25zLnBsYWNlaG9sZGVyRGF0YSA9PT0gcHJldlJlc3VsdE9wdGlvbnM/LnBsYWNlaG9sZGVyRGF0YSkge1xuXHRcdFx0XHRwbGFjZWhvbGRlckRhdGEgPSBwcmV2UmVzdWx0LmRhdGE7XG5cdFx0XHRcdHNraXBTZWxlY3QgPSB0cnVlO1xuXHRcdFx0fSBlbHNlIHBsYWNlaG9sZGVyRGF0YSA9IHR5cGVvZiBvcHRpb25zLnBsYWNlaG9sZGVyRGF0YSA9PT0gXCJmdW5jdGlvblwiID8gb3B0aW9ucy5wbGFjZWhvbGRlckRhdGEodGhpcy4jbGFzdFF1ZXJ5V2l0aERlZmluZWREYXRhPy5zdGF0ZS5kYXRhLCB0aGlzLiNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGEpIDogb3B0aW9ucy5wbGFjZWhvbGRlckRhdGE7XG5cdFx0XHRpZiAocGxhY2Vob2xkZXJEYXRhICE9PSB2b2lkIDApIHtcblx0XHRcdFx0c3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdFx0XHRcdGRhdGEgPSByZXBsYWNlRGF0YShwcmV2UmVzdWx0Py5kYXRhLCBwbGFjZWhvbGRlckRhdGEsIG9wdGlvbnMpO1xuXHRcdFx0XHRpc1BsYWNlaG9sZGVyRGF0YSA9IHRydWU7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmIChvcHRpb25zLnNlbGVjdCAmJiBkYXRhICE9PSB2b2lkIDAgJiYgIXNraXBTZWxlY3QpIHtcblx0XHRcdGlmIChwcmV2UmVzdWx0ICYmIGRhdGEgPT09IHByZXZSZXN1bHRTdGF0ZT8uZGF0YSAmJiBvcHRpb25zLnNlbGVjdCA9PT0gdGhpcy4jc2VsZWN0Rm4pIGRhdGEgPSB0aGlzLiNzZWxlY3RSZXN1bHQ7XG5cdFx0XHRlbHNlIHRyeSB7XG5cdFx0XHRcdHRoaXMuI3NlbGVjdEZuID0gb3B0aW9ucy5zZWxlY3Q7XG5cdFx0XHRcdGRhdGEgPSBvcHRpb25zLnNlbGVjdChkYXRhKTtcblx0XHRcdFx0ZGF0YSA9IHJlcGxhY2VEYXRhKHByZXZSZXN1bHQ/LmRhdGEsIGRhdGEsIG9wdGlvbnMpO1xuXHRcdFx0XHR0aGlzLiNzZWxlY3RSZXN1bHQgPSBkYXRhO1xuXHRcdFx0XHR0aGlzLiNzZWxlY3RFcnJvciA9IG51bGw7XG5cdFx0XHR9IGNhdGNoIChzZWxlY3RFcnJvcikge1xuXHRcdFx0XHR0aGlzLiNzZWxlY3RFcnJvciA9IHNlbGVjdEVycm9yO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSBpZiAoZGF0YSA9PT0gdm9pZCAwKSB0aGlzLiNzZWxlY3RFcnJvciA9IG51bGw7XG5cdFx0aWYgKHRoaXMuI3NlbGVjdEVycm9yKSB7XG5cdFx0XHRlcnJvciA9IHRoaXMuI3NlbGVjdEVycm9yO1xuXHRcdFx0ZGF0YSA9IHRoaXMuI3NlbGVjdFJlc3VsdDtcblx0XHRcdGVycm9yVXBkYXRlZEF0ID0gRGF0ZS5ub3coKTtcblx0XHRcdHN0YXR1cyA9IFwiZXJyb3JcIjtcblx0XHRcdGlzUGxhY2Vob2xkZXJEYXRhID0gZmFsc2U7XG5cdFx0fVxuXHRcdGNvbnN0IGlzRmV0Y2hpbmcgPSBuZXdTdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJmZXRjaGluZ1wiO1xuXHRcdGNvbnN0IGlzUGVuZGluZyA9IHN0YXR1cyA9PT0gXCJwZW5kaW5nXCI7XG5cdFx0Y29uc3QgaXNFcnJvciA9IHN0YXR1cyA9PT0gXCJlcnJvclwiO1xuXHRcdGNvbnN0IGlzTG9hZGluZyA9IGlzUGVuZGluZyAmJiBpc0ZldGNoaW5nO1xuXHRcdGNvbnN0IGhhc0RhdGEgPSBkYXRhICE9PSB2b2lkIDA7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHN0YXR1cyxcblx0XHRcdGZldGNoU3RhdHVzOiBuZXdTdGF0ZS5mZXRjaFN0YXR1cyxcblx0XHRcdGlzUGVuZGluZyxcblx0XHRcdGlzU3VjY2Vzczogc3RhdHVzID09PSBcInN1Y2Nlc3NcIixcblx0XHRcdGlzRXJyb3IsXG5cdFx0XHRpc0luaXRpYWxMb2FkaW5nOiBpc0xvYWRpbmcsXG5cdFx0XHRpc0xvYWRpbmcsXG5cdFx0XHRkYXRhLFxuXHRcdFx0ZGF0YVVwZGF0ZWRBdDogbmV3U3RhdGUuZGF0YVVwZGF0ZWRBdCxcblx0XHRcdGVycm9yLFxuXHRcdFx0ZXJyb3JVcGRhdGVkQXQsXG5cdFx0XHRmYWlsdXJlQ291bnQ6IG5ld1N0YXRlLmZldGNoRmFpbHVyZUNvdW50LFxuXHRcdFx0ZmFpbHVyZVJlYXNvbjogbmV3U3RhdGUuZmV0Y2hGYWlsdXJlUmVhc29uLFxuXHRcdFx0ZXJyb3JVcGRhdGVDb3VudDogbmV3U3RhdGUuZXJyb3JVcGRhdGVDb3VudCxcblx0XHRcdGlzRmV0Y2hlZDogcXVlcnkuaXNGZXRjaGVkKCksXG5cdFx0XHRpc0ZldGNoZWRBZnRlck1vdW50OiBuZXdTdGF0ZS5kYXRhVXBkYXRlQ291bnQgPiBxdWVyeUluaXRpYWxTdGF0ZS5kYXRhVXBkYXRlQ291bnQgfHwgbmV3U3RhdGUuZXJyb3JVcGRhdGVDb3VudCA+IHF1ZXJ5SW5pdGlhbFN0YXRlLmVycm9yVXBkYXRlQ291bnQsXG5cdFx0XHRpc0ZldGNoaW5nLFxuXHRcdFx0aXNSZWZldGNoaW5nOiBpc0ZldGNoaW5nICYmICFpc1BlbmRpbmcsXG5cdFx0XHRpc0xvYWRpbmdFcnJvcjogaXNFcnJvciAmJiAhaGFzRGF0YSxcblx0XHRcdGlzUGF1c2VkOiBuZXdTdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJwYXVzZWRcIixcblx0XHRcdGlzUGxhY2Vob2xkZXJEYXRhLFxuXHRcdFx0aXNSZWZldGNoRXJyb3I6IGlzRXJyb3IgJiYgaGFzRGF0YSxcblx0XHRcdGlzU3RhbGU6IGlzU3RhbGUocXVlcnksIG9wdGlvbnMpLFxuXHRcdFx0cmVmZXRjaDogdGhpcy5yZWZldGNoLFxuXHRcdFx0aXNFbmFibGVkOiByZXNvbHZlUXVlcnlWYWx1ZShvcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSAhPT0gZmFsc2Vcblx0XHR9O1xuXHR9XG5cdC8qKlxuXHQqIFJlY29tcHV0ZXMgYW5kIHN0b3JlcyB0aGUgY3VycmVudCByZXN1bHQgZnJvbSB0aGUgY3VycmVudCBxdWVyeS9vcHRpb25zLCBub3RpZnlpbmcgbGlzdGVuZXJzXG5cdCogaWYgaXQgY2hhbmdlZC4gRnJhbWV3b3JrIGFkYXB0ZXJzIGNhbGwgdGhpcyByaWdodCBhZnRlciBzdWJzY3JpYmluZyB0byBtYWtlIHN1cmUgbm8gcXVlcnlcblx0KiB1cGRhdGUgd2FzIG1pc3NlZCBpbiB0aGUgZ2FwIGJldHdlZW4gY3JlYXRpbmcgdGhlIG9ic2VydmVyIGFuZCBzdWJzY3JpYmluZyB0byBpdC5cblx0Ki9cblx0dXBkYXRlUmVzdWx0KCkge1xuXHRcdGNvbnN0IHByZXZSZXN1bHQgPSB0aGlzLiNjdXJyZW50UmVzdWx0O1xuXHRcdGNvbnN0IG5leHRSZXN1bHQgPSB0aGlzLmNyZWF0ZVJlc3VsdCh0aGlzLiNjdXJyZW50UXVlcnksIHRoaXMub3B0aW9ucyk7XG5cdFx0dGhpcy4jY3VycmVudFJlc3VsdFN0YXRlID0gdGhpcy4jY3VycmVudFF1ZXJ5LnN0YXRlO1xuXHRcdHRoaXMuI2N1cnJlbnRSZXN1bHRPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuXHRcdGlmICh0aGlzLiNjdXJyZW50UmVzdWx0U3RhdGUuZGF0YSAhPT0gdm9pZCAwKSB0aGlzLiNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGEgPSB0aGlzLiNjdXJyZW50UXVlcnk7XG5cdFx0aWYgKHNoYWxsb3dFcXVhbE9iamVjdHMobmV4dFJlc3VsdCwgcHJldlJlc3VsdCkpIHJldHVybjtcblx0XHR0aGlzLiNjdXJyZW50UmVzdWx0ID0gbmV4dFJlc3VsdDtcblx0XHRjb25zdCBzaG91bGROb3RpZnlMaXN0ZW5lcnMgPSAoKSA9PiB7XG5cdFx0XHRpZiAoIXByZXZSZXN1bHQpIHJldHVybiB0cnVlO1xuXHRcdFx0Y29uc3QgeyBub3RpZnlPbkNoYW5nZVByb3BzIH0gPSB0aGlzLm9wdGlvbnM7XG5cdFx0XHRjb25zdCBub3RpZnlPbkNoYW5nZVByb3BzVmFsdWUgPSB0eXBlb2Ygbm90aWZ5T25DaGFuZ2VQcm9wcyA9PT0gXCJmdW5jdGlvblwiID8gbm90aWZ5T25DaGFuZ2VQcm9wcygpIDogbm90aWZ5T25DaGFuZ2VQcm9wcztcblx0XHRcdGlmIChub3RpZnlPbkNoYW5nZVByb3BzVmFsdWUgPT09IFwiYWxsXCIgfHwgIW5vdGlmeU9uQ2hhbmdlUHJvcHNWYWx1ZSAmJiAhdGhpcy4jdHJhY2tlZFByb3BzLnNpemUpIHJldHVybiB0cnVlO1xuXHRcdFx0Y29uc3QgaW5jbHVkZWRQcm9wcyA9IG5ldyBTZXQobm90aWZ5T25DaGFuZ2VQcm9wc1ZhbHVlID8/IHRoaXMuI3RyYWNrZWRQcm9wcyk7XG5cdFx0XHRpZiAodGhpcy5vcHRpb25zLnRocm93T25FcnJvcikgaW5jbHVkZWRQcm9wcy5hZGQoXCJlcnJvclwiKTtcblx0XHRcdHJldHVybiBPYmplY3Qua2V5cyh0aGlzLiNjdXJyZW50UmVzdWx0KS5zb21lKChrZXkpID0+IHtcblx0XHRcdFx0Y29uc3QgdHlwZWRLZXkgPSBrZXk7XG5cdFx0XHRcdHJldHVybiB0aGlzLiNjdXJyZW50UmVzdWx0W3R5cGVkS2V5XSAhPT0gcHJldlJlc3VsdFt0eXBlZEtleV0gJiYgaW5jbHVkZWRQcm9wcy5oYXModHlwZWRLZXkpO1xuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHRjb25zdCBub3RpZnlMaXN0ZW5lcnMgPSBzaG91bGROb3RpZnlMaXN0ZW5lcnMoKTtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdGlmIChub3RpZnlMaXN0ZW5lcnMpIHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRcdGxpc3RlbmVyKHRoaXMuI2N1cnJlbnRSZXN1bHQpO1xuXHRcdFx0fSk7XG5cdFx0XHR0aGlzLiNjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLm5vdGlmeSh7XG5cdFx0XHRcdHF1ZXJ5OiB0aGlzLiNjdXJyZW50UXVlcnksXG5cdFx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJSZXN1bHRzVXBkYXRlZFwiXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXHQjdXBkYXRlUXVlcnkoKSB7XG5cdFx0Y29uc3QgcXVlcnkgPSB0aGlzLiNjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmJ1aWxkKHRoaXMuI2NsaWVudCwgdGhpcy5vcHRpb25zKTtcblx0XHRpZiAocXVlcnkgPT09IHRoaXMuI2N1cnJlbnRRdWVyeSkgcmV0dXJuO1xuXHRcdGNvbnN0IHByZXZRdWVyeSA9IHRoaXMuI2N1cnJlbnRRdWVyeTtcblx0XHR0aGlzLiNjdXJyZW50UXVlcnkgPSBxdWVyeTtcblx0XHR0aGlzLiNjdXJyZW50UXVlcnlJbml0aWFsU3RhdGUgPSBxdWVyeS5zdGF0ZTtcblx0XHRpZiAodGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuXHRcdFx0cHJldlF1ZXJ5Py5yZW1vdmVPYnNlcnZlcih0aGlzKTtcblx0XHRcdHF1ZXJ5LmFkZE9ic2VydmVyKHRoaXMpO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBVcGRhdGVzIHRoZSBvYnNlcnZlcidzIHJlc3VsdCB3aGVuIHRoZSBvYnNlcnZlZCBxdWVyeSBjaGFuZ2VzLCBhbmQgcmVzY2hlZHVsZXMgaXRzIHRpbWVycyBpZiBpdFxuXHQqIGhhcyBsaXN0ZW5lcnMuXG5cdCogQGludGVybmFsXG5cdCovXG5cdG9uUXVlcnlVcGRhdGUoKSB7XG5cdFx0dGhpcy51cGRhdGVSZXN1bHQoKTtcblx0XHRpZiAodGhpcy5oYXNMaXN0ZW5lcnMoKSkgdGhpcy4jdXBkYXRlVGltZXJzKCk7XG5cdH1cbn07XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBxdWVyeSBoYXMgbm8gZGF0YSB5ZXQgYW5kIHNob3VsZCBkbyBpdHMgaW5pdGlhbCBsb2FkIHdoZW4gYW4gb2JzZXJ2ZXIgbW91bnRzLlxuKiBAcGFyYW0gcXVlcnkgLSBUaGUgcXVlcnkgdG8gY2hlY2suXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9ic2VydmVyIG9wdGlvbnMuXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaXMgZW5hYmxlZCwgaGFzIG5vIGRhdGEsIGFuZCBpc24ndCBpbiBhbiBlcnJvciBzdGF0ZSB3aXRoXG4qIGByZXRyeU9uTW91bnQ6IGZhbHNlYC5cbiovXG5mdW5jdGlvbiBzaG91bGRMb2FkT25Nb3VudChxdWVyeSwgb3B0aW9ucykge1xuXHRyZXR1cm4gcmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgIT09IGZhbHNlICYmIHF1ZXJ5LnN0YXRlLmRhdGEgPT09IHZvaWQgMCAmJiAhKHF1ZXJ5LnN0YXRlLnN0YXR1cyA9PT0gXCJlcnJvclwiICYmIHJlc29sdmVRdWVyeVZhbHVlKG9wdGlvbnMucmV0cnlPbk1vdW50LCBxdWVyeSkgPT09IGZhbHNlKTtcbn1cbi8qKlxuKiBDaGVja3Mgd2hldGhlciBhIHF1ZXJ5IHNob3VsZCBmZXRjaCB3aGVuIGFuIG9ic2VydmVyIG1vdW50czogZWl0aGVyIGZvciBpdHMgaW5pdGlhbCBsb2FkLCBvclxuKiBiZWNhdXNlIGl0IGhhcyBkYXRhIGFuZCBgcmVmZXRjaE9uTW91bnRgIGFza3MgZm9yIGEgcmVmZXRjaC5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGNoZWNrLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBvYnNlcnZlciBvcHRpb25zLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IHNob3VsZCBmZXRjaCBvbiBtb3VudC5cbiovXG5mdW5jdGlvbiBzaG91bGRGZXRjaE9uTW91bnQocXVlcnksIG9wdGlvbnMpIHtcblx0cmV0dXJuIHNob3VsZExvYWRPbk1vdW50KHF1ZXJ5LCBvcHRpb25zKSB8fCBxdWVyeS5zdGF0ZS5kYXRhICE9PSB2b2lkIDAgJiYgc2hvdWxkRmV0Y2hPbihxdWVyeSwgb3B0aW9ucywgb3B0aW9ucy5yZWZldGNoT25Nb3VudCk7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBxdWVyeSBzaG91bGQgZmV0Y2ggZm9yIGEgYHJlZmV0Y2hPbk1vdW50YCwgYHJlZmV0Y2hPbldpbmRvd0ZvY3VzYCwgb3JcbiogYHJlZmV0Y2hPblJlY29ubmVjdGAgb3B0aW9uLlxuKiBAcGFyYW0gcXVlcnkgLSBUaGUgcXVlcnkgdG8gY2hlY2suXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9ic2VydmVyIG9wdGlvbnMuXG4qIEBwYXJhbSBmaWVsZCAtIFRoZSB2YWx1ZSBvZiB0aGUgb3B0aW9uIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGlzIGVuYWJsZWQsIG5vdCBzdGF0aWMsIGFuZCB0aGUgb3B0aW9uIGlzIGAnYWx3YXlzJ2AsIG9yIGlzIG5vdFxuKiBgZmFsc2VgIGFuZCB0aGUgcXVlcnkgaXMgc3RhbGUuXG4qL1xuZnVuY3Rpb24gc2hvdWxkRmV0Y2hPbihxdWVyeSwgb3B0aW9ucywgZmllbGQpIHtcblx0aWYgKHJlc29sdmVRdWVyeVZhbHVlKG9wdGlvbnMuZW5hYmxlZCwgcXVlcnkpICE9PSBmYWxzZSAmJiByZXNvbHZlUXVlcnlWYWx1ZShvcHRpb25zLnN0YWxlVGltZSwgcXVlcnkpICE9PSBcInN0YXRpY1wiKSB7XG5cdFx0Y29uc3QgdmFsdWUgPSByZXNvbHZlUXVlcnlWYWx1ZShmaWVsZCwgcXVlcnkpO1xuXHRcdHJldHVybiB2YWx1ZSA9PT0gXCJhbHdheXNcIiB8fCB2YWx1ZSAhPT0gZmFsc2UgJiYgaXNTdGFsZShxdWVyeSwgb3B0aW9ucyk7XG5cdH1cblx0cmV0dXJuIGZhbHNlO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgcXVlcnkgc2hvdWxkIGZldGNoIGFmdGVyIHRoZSBvYnNlcnZlcidzIG9wdGlvbnMgY2hhbmdlLlxuKiBAcGFyYW0gcXVlcnkgLSBUaGUgcXVlcnkgb2JzZXJ2ZWQgd2l0aCB0aGUgbmV3IG9wdGlvbnMuXG4qIEBwYXJhbSBwcmV2UXVlcnkgLSBUaGUgcXVlcnkgb2JzZXJ2ZWQgd2l0aCB0aGUgcHJldmlvdXMgb3B0aW9ucy5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgbmV3IG9ic2VydmVyIG9wdGlvbnMuXG4qIEBwYXJhbSBwcmV2T3B0aW9ucyAtIFRoZSBwcmV2aW91cyBvYnNlcnZlciBvcHRpb25zLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGNoYW5nZWQgb3Igd2FzIGRpc2FibGVkIGJlZm9yZSwgaXQgaXNuJ3QgYSBzdXNwZW5zZSBxdWVyeSBpbiBhblxuKiBlcnJvciBzdGF0ZSwgYW5kIGl0IGlzIHN0YWxlLlxuKi9cbmZ1bmN0aW9uIHNob3VsZEZldGNoT3B0aW9uYWxseShxdWVyeSwgcHJldlF1ZXJ5LCBvcHRpb25zLCBwcmV2T3B0aW9ucykge1xuXHRyZXR1cm4gKHF1ZXJ5ICE9PSBwcmV2UXVlcnkgfHwgcmVzb2x2ZVF1ZXJ5VmFsdWUocHJldk9wdGlvbnMuZW5hYmxlZCwgcXVlcnkpID09PSBmYWxzZSkgJiYgKCFvcHRpb25zLnN1c3BlbnNlIHx8IHF1ZXJ5LnN0YXRlLnN0YXR1cyAhPT0gXCJlcnJvclwiKSAmJiBpc1N0YWxlKHF1ZXJ5LCBvcHRpb25zKTtcbn1cbi8qKlxuKiBDaGVja3Mgd2hldGhlciBhIHF1ZXJ5IGlzIHN0YWxlIGZvciB0aGUgZ2l2ZW4gb2JzZXJ2ZXIgb3B0aW9ucy5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGNoZWNrLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBvYnNlcnZlciBvcHRpb25zLCB3aG9zZSBgZW5hYmxlZGAgYW5kIGBzdGFsZVRpbWVgIGFyZSB1c2VkLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGlzIGVuYWJsZWQgYW5kIGl0cyBkYXRhIGlzIHN0YWxlIGZvciBgc3RhbGVUaW1lYC5cbiovXG5mdW5jdGlvbiBpc1N0YWxlKHF1ZXJ5LCBvcHRpb25zKSB7XG5cdHJldHVybiByZXNvbHZlUXVlcnlWYWx1ZShvcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSAhPT0gZmFsc2UgJiYgcXVlcnkuaXNTdGFsZUJ5VGltZShyZXNvbHZlUXVlcnlWYWx1ZShvcHRpb25zLnN0YWxlVGltZSwgcXVlcnkpKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUXVlcnlPYnNlcnZlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeU9ic2VydmVyLmpzLm1hcCIsImltcG9ydCB7IGhhc05leHRQYWdlLCBoYXNQcmV2aW91c1BhZ2UgfSBmcm9tIFwiLi9pbmZpbml0ZVF1ZXJ5QmVoYXZpb3IuanNcIjtcbmltcG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIgfSBmcm9tIFwiLi9xdWVyeU9ic2VydmVyLmpzXCI7XG4vLyNyZWdpb24gc3JjL2luZmluaXRlUXVlcnlPYnNlcnZlci50c1xuLyoqXG4qIEFuIGBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXJgIGV4dGVuZHMgYFF1ZXJ5T2JzZXJ2ZXJgIHRvIG9ic2VydmUgYW5kIHN3aXRjaFxuKiBiZXR3ZWVuIGluZmluaXRlIHF1ZXJpZXMuIEl0IGF1Z21lbnRzIHRoZSBiYXNlIGBRdWVyeU9ic2VydmVyUmVzdWx0YCB3aXRoXG4qIGluZmluaXRlLXF1ZXJ5LXNwZWNpZmljIGZpZWxkcyBhbmQgbWV0aG9kcywgc3VjaCBhcyBgaGFzTmV4dFBhZ2VgIGFuZFxuKiBgZmV0Y2hOZXh0UGFnZWAsIGFuZCBpcyB0aGUgcHJpbWl0aXZlIHRoYXQgZnJhbWV3b3JrIGFkYXB0ZXJzIChlLmcuXG4qIGB1c2VJbmZpbml0ZVF1ZXJ5YCkgYnVpbGQgdGhlaXIgaG9va3Mgb24gdG9wIG9mLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBvYnNlcnZlciA9IG5ldyBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIocXVlcnlDbGllbnQsIHtcbiogICBxdWVyeUtleTogWydwcm9qZWN0cyddLFxuKiAgIHF1ZXJ5Rm46ICh7IHBhZ2VQYXJhbSB9KSA9PiBmZXRjaFByb2plY3RzKHBhZ2VQYXJhbSksXG4qICAgaW5pdGlhbFBhZ2VQYXJhbTogMCxcbiogICBnZXROZXh0UGFnZVBhcmFtOiAobGFzdFBhZ2UpID0+IGxhc3RQYWdlLm5leHRDdXJzb3IsXG4qIH0pXG4qXG4qIGNvbnN0IHVuc3Vic2NyaWJlID0gb2JzZXJ2ZXIuc3Vic2NyaWJlKChyZXN1bHQpID0+IGNvbnNvbGUubG9nKHJlc3VsdCkpXG4qIGBgYFxuKi9cbnZhciBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIgPSBjbGFzcyBleHRlbmRzIFF1ZXJ5T2JzZXJ2ZXIge1xuXHRjb25zdHJ1Y3RvcihjbGllbnQsIG9wdGlvbnMpIHtcblx0XHRzdXBlcihjbGllbnQsIG9wdGlvbnMpO1xuXHR9XG5cdGJpbmRNZXRob2RzKCkge1xuXHRcdHN1cGVyLmJpbmRNZXRob2RzKCk7XG5cdFx0dGhpcy5mZXRjaE5leHRQYWdlID0gdGhpcy5mZXRjaE5leHRQYWdlLmJpbmQodGhpcyk7XG5cdFx0dGhpcy5mZXRjaFByZXZpb3VzUGFnZSA9IHRoaXMuZmV0Y2hQcmV2aW91c1BhZ2UuYmluZCh0aGlzKTtcblx0fVxuXHQvKipcblx0KiBVcGRhdGVzIHRoZSBvYnNlcnZlcidzIG9wdGlvbnMuIEJlaGF2ZXMgdGhlIHNhbWUgYXNcblx0KiBgUXVlcnlPYnNlcnZlci5zZXRPcHRpb25zYCwgYWRkaXRpb25hbGx5IG1hcmtpbmcgdGhlIG9wdGlvbnMgYXNcblx0KiBiZWxvbmdpbmcgdG8gYW4gaW5maW5pdGUgcXVlcnkgYmVmb3JlIGRlbGVnYXRpbmcgdG8gdGhlIGJhc2Vcblx0KiBpbXBsZW1lbnRhdGlvbi5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBuZXcgaW5maW5pdGUgcXVlcnkgb2JzZXJ2ZXIgb3B0aW9ucy5cblx0Ki9cblx0c2V0T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0b3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcblx0XHRzdXBlci5zZXRPcHRpb25zKG9wdGlvbnMpO1xuXHR9XG5cdC8qKlxuXHQqIFRoZSBpbmZpbml0ZS1xdWVyeSBjb3VudGVycGFydCBvZiB7QGxpbmsgUXVlcnlPYnNlcnZlciNnZXRPcHRpbWlzdGljUmVzdWx0fSwgbWFya2luZyB0aGVcblx0KiBvcHRpb25zIGFzIGFuIGluZmluaXRlIHF1ZXJ5IGJlZm9yZSBkZWxlZ2F0aW5nIHRvIGl0LiBDYWxsZWQgYnkgZnJhbWV3b3JrIGFkYXB0ZXJzIChlLmcuXG5cdCogYHVzZUluZmluaXRlUXVlcnlgKSBhaGVhZCBvZiBzdWJzY3JpYmluZywgdG8gY29tcHV0ZSB0aGUgY3VycmVudCBgSW5maW5pdGVRdWVyeU9ic2VydmVyUmVzdWx0YFxuXHQqIHN5bmNocm9ub3VzbHkuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgZGVmYXVsdGVkIGluZmluaXRlIHF1ZXJ5IG9ic2VydmVyIG9wdGlvbnMgdG8gY29tcHV0ZSB0aGUgcmVzdWx0IGZvci5cblx0KiBAcmV0dXJucyBUaGUgcmVzdWx0IGZvciB0aGUgZ2l2ZW4gb3B0aW9ucy5cblx0Ki9cblx0Z2V0T3B0aW1pc3RpY1Jlc3VsdChvcHRpb25zKSB7XG5cdFx0b3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcblx0XHRyZXR1cm4gc3VwZXIuZ2V0T3B0aW1pc3RpY1Jlc3VsdChvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIHRoZSBuZXh0IHBhZ2Ugb2YgdGhlIGluZmluaXRlIHF1ZXJ5IGFuZCByZXR1cm5zIGEgcHJvbWlzZSB0aGF0XG5cdCogcmVzb2x2ZXMgd2l0aCB0aGUgcmVzdWx0aW5nIGBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgLiBUaGUgcGFnZVxuXHQqIHBhcmFtIHVzZWQgZm9yIHRoZSBmZXRjaCBpcyBkZXRlcm1pbmVkIGJ5IGBnZXROZXh0UGFnZVBhcmFtYCwgd2hpY2hcblx0KiByZWNlaXZlcyB0aGUgY3VycmVudCBwYWdlcy9wYWdlIHBhcmFtcyBhbmQgd2hvc2UgcmVzdWx0IGFsc28gZGV0ZXJtaW5lc1xuXHQqIGBoYXNOZXh0UGFnZWAuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBTZXQgYGNhbmNlbFJlZmV0Y2hgIHRvIGBmYWxzZWAgdG8gaWdub3JlIHRoZSBjYWxsIHdoaWxlIGEgZmV0Y2ggaXMgcnVubmluZyxcblx0KiBhbmQgYHRocm93T25FcnJvcmAgdG8gYHRydWVgIHRvIHJlamVjdCB3aGVuIHRoZSBmZXRjaCBmYWlscy5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSByZXN1bHQgYWZ0ZXIgdGhlIG5leHQgcGFnZSBpcyBmZXRjaGVkLiBXaXRoXG5cdCogYGNhbmNlbFJlZmV0Y2g6IGZhbHNlYCwgYSBydW5uaW5nIGZldGNoIGlzIHJldXNlZCBpbnN0ZWFkLCBzbyB0aGUgbmV4dCBwYWdlIG1heSBub3QgYmUgZmV0Y2hlZC5cblx0KiBAc2VlIHtAbGluayBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIjZmV0Y2hQcmV2aW91c1BhZ2V9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHsgaGFzTmV4dFBhZ2UgfSA9IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuXHQqXG5cdCogaWYgKGhhc05leHRQYWdlKSB7XG5cdCogICBhd2FpdCBvYnNlcnZlci5mZXRjaE5leHRQYWdlKClcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGZldGNoTmV4dFBhZ2Uob3B0aW9ucykge1xuXHRcdHJldHVybiB0aGlzLmZldGNoKHtcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRtZXRhOiB7IGZldGNoTW9yZTogeyBkaXJlY3Rpb246IFwiZm9yd2FyZFwiIH0gfVxuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIEZldGNoZXMgdGhlIHByZXZpb3VzIHBhZ2Ugb2YgdGhlIGluZmluaXRlIHF1ZXJ5IGFuZCByZXR1cm5zIGEgcHJvbWlzZVxuXHQqIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgcmVzdWx0aW5nIGBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgLiBUaGUgcGFnZVxuXHQqIHBhcmFtIHVzZWQgZm9yIHRoZSBmZXRjaCBpcyBkZXRlcm1pbmVkIGJ5IGBnZXRQcmV2aW91c1BhZ2VQYXJhbWAsIHdoaWNoXG5cdCogcmVjZWl2ZXMgdGhlIGN1cnJlbnQgcGFnZXMvcGFnZSBwYXJhbXMgYW5kIHdob3NlIHJlc3VsdCBhbHNvIGRldGVybWluZXNcblx0KiBgaGFzUHJldmlvdXNQYWdlYC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFNldCBgY2FuY2VsUmVmZXRjaGAgdG8gYGZhbHNlYCB0byBpZ25vcmUgdGhlIGNhbGwgd2hpbGUgYSBmZXRjaCBpcyBydW5uaW5nLFxuXHQqIGFuZCBgdGhyb3dPbkVycm9yYCB0byBgdHJ1ZWAgdG8gcmVqZWN0IHdoZW4gdGhlIGZldGNoIGZhaWxzLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHJlc3VsdCBhZnRlciB0aGUgcHJldmlvdXMgcGFnZSBpcyBmZXRjaGVkLiBXaXRoXG5cdCogYGNhbmNlbFJlZmV0Y2g6IGZhbHNlYCwgYSBydW5uaW5nIGZldGNoIGlzIHJldXNlZCBpbnN0ZWFkLCBzbyB0aGUgcHJldmlvdXMgcGFnZSBtYXkgbm90IGJlIGZldGNoZWQuXG5cdCogQHNlZSB7QGxpbmsgSW5maW5pdGVRdWVyeU9ic2VydmVyI2ZldGNoTmV4dFBhZ2V9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHsgaGFzUHJldmlvdXNQYWdlIH0gPSBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KClcblx0KlxuXHQqIGlmIChoYXNQcmV2aW91c1BhZ2UpIHtcblx0KiAgIGF3YWl0IG9ic2VydmVyLmZldGNoUHJldmlvdXNQYWdlKClcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGZldGNoUHJldmlvdXNQYWdlKG9wdGlvbnMpIHtcblx0XHRyZXR1cm4gdGhpcy5mZXRjaCh7XG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0bWV0YTogeyBmZXRjaE1vcmU6IHsgZGlyZWN0aW9uOiBcImJhY2t3YXJkXCIgfSB9XG5cdFx0fSk7XG5cdH1cblx0Y3JlYXRlUmVzdWx0KHF1ZXJ5LCBvcHRpb25zKSB7XG5cdFx0Y29uc3QgeyBzdGF0ZSB9ID0gcXVlcnk7XG5cdFx0Y29uc3QgcGFyZW50UmVzdWx0ID0gc3VwZXIuY3JlYXRlUmVzdWx0KHF1ZXJ5LCBvcHRpb25zKTtcblx0XHRjb25zdCB7IGlzRmV0Y2hpbmcsIGlzUmVmZXRjaGluZywgaXNFcnJvciwgaXNSZWZldGNoRXJyb3IgfSA9IHBhcmVudFJlc3VsdDtcblx0XHRjb25zdCBmZXRjaERpcmVjdGlvbiA9IHN0YXRlLmZldGNoTWV0YT8uZmV0Y2hNb3JlPy5kaXJlY3Rpb247XG5cdFx0Y29uc3QgaXNGZXRjaE5leHRQYWdlRXJyb3IgPSBpc0Vycm9yICYmIGZldGNoRGlyZWN0aW9uID09PSBcImZvcndhcmRcIjtcblx0XHRjb25zdCBpc0ZldGNoaW5nTmV4dFBhZ2UgPSBpc0ZldGNoaW5nICYmIGZldGNoRGlyZWN0aW9uID09PSBcImZvcndhcmRcIjtcblx0XHRjb25zdCBpc0ZldGNoUHJldmlvdXNQYWdlRXJyb3IgPSBpc0Vycm9yICYmIGZldGNoRGlyZWN0aW9uID09PSBcImJhY2t3YXJkXCI7XG5cdFx0Y29uc3QgaXNGZXRjaGluZ1ByZXZpb3VzUGFnZSA9IGlzRmV0Y2hpbmcgJiYgZmV0Y2hEaXJlY3Rpb24gPT09IFwiYmFja3dhcmRcIjtcblx0XHRyZXR1cm4ge1xuXHRcdFx0Li4ucGFyZW50UmVzdWx0LFxuXHRcdFx0ZmV0Y2hOZXh0UGFnZTogdGhpcy5mZXRjaE5leHRQYWdlLFxuXHRcdFx0ZmV0Y2hQcmV2aW91c1BhZ2U6IHRoaXMuZmV0Y2hQcmV2aW91c1BhZ2UsXG5cdFx0XHRoYXNOZXh0UGFnZTogaGFzTmV4dFBhZ2Uob3B0aW9ucywgc3RhdGUuZGF0YSksXG5cdFx0XHRoYXNQcmV2aW91c1BhZ2U6IGhhc1ByZXZpb3VzUGFnZShvcHRpb25zLCBzdGF0ZS5kYXRhKSxcblx0XHRcdGlzRmV0Y2hOZXh0UGFnZUVycm9yLFxuXHRcdFx0aXNGZXRjaGluZ05leHRQYWdlLFxuXHRcdFx0aXNGZXRjaFByZXZpb3VzUGFnZUVycm9yLFxuXHRcdFx0aXNGZXRjaGluZ1ByZXZpb3VzUGFnZSxcblx0XHRcdGlzUmVmZXRjaEVycm9yOiBpc1JlZmV0Y2hFcnJvciAmJiAhaXNGZXRjaE5leHRQYWdlRXJyb3IgJiYgIWlzRmV0Y2hQcmV2aW91c1BhZ2VFcnJvcixcblx0XHRcdGlzUmVmZXRjaGluZzogaXNSZWZldGNoaW5nICYmICFpc0ZldGNoaW5nTmV4dFBhZ2UgJiYgIWlzRmV0Y2hpbmdQcmV2aW91c1BhZ2Vcblx0XHR9O1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5maW5pdGVRdWVyeU9ic2VydmVyLmpzLm1hcCIsImltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVSZXRyeWVyIH0gZnJvbSBcIi4vcmV0cnllci5qc1wiO1xuaW1wb3J0IHsgUmVtb3ZhYmxlIH0gZnJvbSBcIi4vcmVtb3ZhYmxlLmpzXCI7XG4vLyNyZWdpb24gc3JjL211dGF0aW9uLnRzXG4vKipcbiogUmVwcmVzZW50cyBhIHNpbmdsZSBtdXRhdGlvbiBhdHRlbXB0LiBBIGBNdXRhdGlvbmAgaG9sZHMgdGhlIG11dGF0aW9uJ3Ncbiogb3B0aW9ucywgc3RhdGUgKGRhdGEvZXJyb3Ivc3RhdHVzKSwgYW5kIHRoZSBgTXV0YXRpb25PYnNlcnZlcmBzIGN1cnJlbnRseVxuKiBzdWJzY3JpYmVkIHRvIGl0LlxuKlxuKiBJbnN0YW5jZXMgYXJlIGNyZWF0ZWQgYW5kIG1hbmFnZWQgaW50ZXJuYWxseSBieSBgTXV0YXRpb25DYWNoZWA7IGFwcGxpY2F0aW9uXG4qIGNvZGUgdHlwaWNhbGx5IGludGVyYWN0cyB3aXRoIG11dGF0aW9ucyBpbmRpcmVjdGx5IHRocm91Z2ggYFF1ZXJ5Q2xpZW50YCBvclxuKiBhIGZyYW1ld29yayBob29rIGxpa2UgYHVzZU11dGF0aW9uYC4gRGlyZWN0IGFjY2VzcyB0byBhIGBNdXRhdGlvbmAgaW5zdGFuY2VcbiogaXMgcG9zc2libGUgdmlhIGBtdXRhdGlvbkNhY2hlLmZpbmQoKWAvYGdldEFsbCgpYCBmb3IgaW5zcGVjdGluZyBjYWNoZSBzdGF0ZS5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgbXV0YXRpb25DYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKVxuKlxuKiBjb25zdCBtdXRhdGlvbiA9IG11dGF0aW9uQ2FjaGUuZmluZCh7IG11dGF0aW9uS2V5OiBbJ2FkZFBvc3QnXSB9KVxuKiBgYGBcbiovXG52YXIgTXV0YXRpb24gPSBjbGFzcyBleHRlbmRzIFJlbW92YWJsZSB7XG5cdCNjbGllbnQ7XG5cdCNvYnNlcnZlcnM7XG5cdCNtdXRhdGlvbkNhY2hlO1xuXHQjcmV0cnllcjtcblx0Y29uc3RydWN0b3IoY29uZmlnKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLiNjbGllbnQgPSBjb25maWcuY2xpZW50O1xuXHRcdHRoaXMubXV0YXRpb25JZCA9IGNvbmZpZy5tdXRhdGlvbklkO1xuXHRcdHRoaXMuI211dGF0aW9uQ2FjaGUgPSBjb25maWcubXV0YXRpb25DYWNoZTtcblx0XHR0aGlzLiNvYnNlcnZlcnMgPSBbXTtcblx0XHR0aGlzLnN0YXRlID0gY29uZmlnLnN0YXRlIHx8IGdldERlZmF1bHRTdGF0ZSgpO1xuXHRcdHRoaXMuc2V0T3B0aW9ucyhjb25maWcub3B0aW9ucyk7XG5cdFx0dGhpcy5zY2hlZHVsZUdjKCk7XG5cdH1cblx0LyoqXG5cdCogUmVwbGFjZXMgdGhlIG11dGF0aW9uJ3Mgb3B0aW9ucyBhbmQgYXBwbGllcyB0aGVpciBgZ2NUaW1lYC5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBuZXcgbXV0YXRpb24gb3B0aW9ucy5cblx0Ki9cblx0c2V0T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0dGhpcy5vcHRpb25zID0gb3B0aW9ucztcblx0XHR0aGlzLnVwZGF0ZUdjVGltZSh0aGlzLm9wdGlvbnMuZ2NUaW1lKTtcblx0fVxuXHQvKipcblx0KiBUaGUgYG1ldGFgIG9iamVjdCBwYXNzZWQgaW4gdGhlIG11dGF0aW9uJ3Mgb3B0aW9ucywgaWYgYW55LlxuXHQqIEByZXR1cm5zIFRoZSBtdXRhdGlvbidzIGBtZXRhYCwgb3IgYHVuZGVmaW5lZGAgaWYgbm9uZSB3YXMgc2V0LlxuXHQqL1xuXHRnZXQgbWV0YSgpIHtcblx0XHRyZXR1cm4gdGhpcy5vcHRpb25zLm1ldGE7XG5cdH1cblx0LyoqXG5cdCogU3Vic2NyaWJlcyBhbiBvYnNlcnZlciB0byB0aGUgbXV0YXRpb24gYW5kIHN0b3BzIGl0cyBnYXJiYWdlIGNvbGxlY3Rpb24uXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIG9ic2VydmVyIC0gVGhlIG9ic2VydmVyIHRvIGFkZC4gQWRkaW5nIGFuIG9ic2VydmVyIHRoYXQgaXMgYWxyZWFkeSBzdWJzY3JpYmVkIGRvZXNcblx0KiBub3RoaW5nLlxuXHQqL1xuXHRhZGRPYnNlcnZlcihvYnNlcnZlcikge1xuXHRcdGlmICghdGhpcy4jb2JzZXJ2ZXJzLmluY2x1ZGVzKG9ic2VydmVyKSkge1xuXHRcdFx0dGhpcy4jb2JzZXJ2ZXJzLnB1c2gob2JzZXJ2ZXIpO1xuXHRcdFx0dGhpcy5jbGVhckdjVGltZW91dCgpO1xuXHRcdFx0dGhpcy4jbXV0YXRpb25DYWNoZS5ub3RpZnkoe1xuXHRcdFx0XHR0eXBlOiBcIm9ic2VydmVyQWRkZWRcIixcblx0XHRcdFx0bXV0YXRpb246IHRoaXMsXG5cdFx0XHRcdG9ic2VydmVyXG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogVW5zdWJzY3JpYmVzIGFuIG9ic2VydmVyIGZyb20gdGhlIG11dGF0aW9uLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBvYnNlcnZlciAtIFRoZSBvYnNlcnZlciB0byByZW1vdmUuIEdhcmJhZ2UgY29sbGVjdGlvbiBpcyBzY2hlZHVsZWQgYWZ0ZXJ3YXJkcy5cblx0Ki9cblx0cmVtb3ZlT2JzZXJ2ZXIob2JzZXJ2ZXIpIHtcblx0XHR0aGlzLiNvYnNlcnZlcnMgPSB0aGlzLiNvYnNlcnZlcnMuZmlsdGVyKCh4KSA9PiB4ICE9PSBvYnNlcnZlcik7XG5cdFx0dGhpcy5zY2hlZHVsZUdjKCk7XG5cdFx0dGhpcy4jbXV0YXRpb25DYWNoZS5ub3RpZnkoe1xuXHRcdFx0dHlwZTogXCJvYnNlcnZlclJlbW92ZWRcIixcblx0XHRcdG11dGF0aW9uOiB0aGlzLFxuXHRcdFx0b2JzZXJ2ZXJcblx0XHR9KTtcblx0fVxuXHRvcHRpb25hbFJlbW92ZSgpIHtcblx0XHRpZiAoIXRoaXMuI29ic2VydmVycy5sZW5ndGgpIHtcblx0XHRcdGlmICh0aGlzLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHRoaXMuc2NoZWR1bGVHYygpO1xuXHRcdFx0ZWxzZSB0aGlzLiNtdXRhdGlvbkNhY2hlLnJlbW92ZSh0aGlzKTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogUmVzdW1lcyBhIG11dGF0aW9uIHRoYXQgaXMgY3VycmVudGx5IHBhdXNlZCBvciB3YXMgcmVzdG9yZWQgZnJvbSBhXG5cdCogZGVoeWRyYXRlZCwgc3RpbGwtYHBlbmRpbmdgIHN0YXRlLlxuXHQqXG5cdCogLSBJZiB0aGlzIG11dGF0aW9uIGhhcyBhbiBhY3RpdmUgcmV0cnllciAoaXQgcGF1c2VkIG1pZC1hdHRlbXB0LCBlLmcuIGR1ZVxuXHQqICAgdG8gdGhlIG5ldHdvcmsgbW9kZSBvciBzY29wZS1iYXNlZCBxdWV1aW5nKSwgaXRzIHJldHJ5ZXIgaXMgcmVzdW1lZC5cblx0KiAtIE90aGVyd2lzZSwgaWYgdGhlIG11dGF0aW9uJ3Mgc3RhdHVzIGlzIHN0aWxsIGBwZW5kaW5nYCAoZS5nLiBpdCB3YXNcblx0KiAgIGRlaHlkcmF0ZWQgd2hpbGUgYW4gYXR0ZW1wdCB3YXMgaW4gZmxpZ2h0IGFuZCBuZXZlciBnb3QgYSByZXRyeWVyIGluXG5cdCogICB0aGlzIGluc3RhbmNlKSwgYGV4ZWN1dGVgIGlzIGNhbGxlZCBhZ2FpbiB3aXRoIHRoZSBsYXN0IGtub3duIHZhcmlhYmxlcy5cblx0KiAtIE90aGVyd2lzZSB0aGUgbXV0YXRpb24gaGFzIGFscmVhZHkgc2V0dGxlZCBhbmQgdGhpcyByZXNvbHZlcyBpbW1lZGlhdGVseVxuXHQqICAgd2l0aG91dCBydW5uaW5nIGFueXRoaW5nIGFnYWluLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHNldHRsZXMgd2l0aCB0aGUgcmVzdW1lZCBtdXRhdGlvbjogaXQgcmVqZWN0cyBpZiB0aGUgbXV0YXRpb24gZmFpbHMuXG5cdCogSXQgcmVzb2x2ZXMgaW1tZWRpYXRlbHkgaWYgdGhlIG11dGF0aW9uIGhhcyBhbHJlYWR5IHNldHRsZWQuXG5cdCogQHNlZSB7QGxpbmsgTXV0YXRpb24jZXhlY3V0ZX1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogLy8gdHlwaWNhbGx5IGRyaXZlbiBieSByZWNvbm5lY3QgaGFuZGxpbmcsIGUuZy4gcXVlcnlDbGllbnQucmVzdW1lUGF1c2VkTXV0YXRpb25zKClcblx0KiBjb25zdCBtdXRhdGlvbiA9IG11dGF0aW9uQ2FjaGUuZmluZCh7IG11dGF0aW9uS2V5OiBbJ2FkZFBvc3QnXSB9KVxuXHQqIGF3YWl0IG11dGF0aW9uPy5jb250aW51ZSgpXG5cdCogYGBgXG5cdCovXG5cdGNvbnRpbnVlKCkge1xuXHRcdHJldHVybiB0aGlzLiNyZXRyeWVyPy5jb250aW51ZSgpID8/ICh0aGlzLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgPyB0aGlzLmV4ZWN1dGUodGhpcy5zdGF0ZS52YXJpYWJsZXMpIDogUHJvbWlzZS5yZXNvbHZlKCkpO1xuXHR9XG5cdC8qKlxuXHQqIFJ1bnMgdGhlIG11dGF0aW9uIGZ1bmN0aW9uIGZvciB0aGUgZ2l2ZW4gdmFyaWFibGVzIHRocm91Z2ggYSByZXRyeWVyLCBhbmRcblx0KiBkcml2ZXMgdGhlIG11dGF0aW9uJ3Mgc3RhdGUgYW5kIGxpZmVjeWNsZSBjYWxsYmFja3MgdGhyb3VnaCB0byBzZXR0bGVtZW50LlxuXHQqXG5cdCogSWYgdGhpcyBtdXRhdGlvbidzIHN0YXRlIGlzIGFscmVhZHkgYHBlbmRpbmdgIHdoZW4gYGV4ZWN1dGVgIGlzIGNhbGxlZFxuXHQqIChpLmUuIGl0IHdhcyByZXN0b3JlZCwgc3RpbGwgaW4tZmxpZ2h0LCBmcm9tIGEgZGVoeWRyYXRlZCBzdGF0ZSksIHRoZVxuXHQqIGBvbk11dGF0ZWAgc3RlcCBpcyBza2lwcGVkIGFuZCBhIGBjb250aW51ZWAgYWN0aW9uIGlzIGRpc3BhdGNoZWQgdG9cblx0KiB1bnBhdXNlIGl0OyBvdGhlcndpc2UgYSBgcGVuZGluZ2AgYWN0aW9uIGlzIGRpc3BhdGNoZWQgZmlyc3QsIHRoZW4gdGhlXG5cdCogbXV0YXRpb24gY2FjaGUncyBgb25NdXRhdGVgIGFuZCB0aGUgbXV0YXRpb24ncyBvd24gYG9uTXV0YXRlYCBvcHRpb24gYXJlXG5cdCogYXdhaXRlZCBpbiB0aGF0IG9yZGVyLCBhbmQgdGhlIHJlc3VsdGluZyBjb250ZXh0IGlzIHN0b3JlZC5cblx0KlxuXHQqIFRoZSBtdXRhdGlvbiBmdW5jdGlvbiBpcyB0aGVuIHJ1biAoc3ViamVjdCB0byBgcmV0cnlgL2ByZXRyeURlbGF5YC9cblx0KiBgbmV0d29ya01vZGVgLCBhbmQgdG8gdGhlIG11dGF0aW9uIGNhY2hlJ3Mgc2NvcGUtYmFzZWQgc2VyaWFsaXphdGlvbikuXG5cdCogT24gc3VjY2VzcywgdGhlIGNhY2hlJ3MgYG9uU3VjY2Vzc2AvYG9uU2V0dGxlZGAgY2FsbGJhY2tzIHJ1biBiZWZvcmUgdGhlXG5cdCogbXV0YXRpb24ncyBvd24gYG9uU3VjY2Vzc2AvYG9uU2V0dGxlZGAgb3B0aW9ucywgYSBgc3VjY2Vzc2AgYWN0aW9uIGlzXG5cdCogZGlzcGF0Y2hlZCwgYW5kIHRoZSByZXNvbHZlZCBkYXRhIGlzIHJldHVybmVkLiBPbiBmYWlsdXJlLCB0aGUgc2FtZVxuXHQqIGNhY2hlLXRoZW4tb3B0aW9uIG9yZGVyaW5nIGlzIHVzZWQgZm9yIGBvbkVycm9yYC9gb25TZXR0bGVkYCwgYnV0IGVhY2ggb2Zcblx0KiB0aG9zZSBmb3VyIGNhbGxiYWNrcyBpcyBpbmRpdmlkdWFsbHkgY2F1Z2h0IHNvIHRoYXQgYSB0aHJvd2luZyBjYWxsYmFja1xuXHQqIGNhbm5vdCBtYXNrIHRoZSBvcmlnaW5hbCBlcnJvcjsgYW4gYGVycm9yYCBhY3Rpb24gaXMgdGhlbiBkaXNwYXRjaGVkIGFuZFxuXHQqIHRoZSBvcmlnaW5hbCBlcnJvciBpcyByZS10aHJvd24uXG5cdCogQHBhcmFtIHZhcmlhYmxlcyAtIFRoZSB2YXJpYWJsZXMgcGFzc2VkIHRvIHRoZSBgbXV0YXRpb25GbmAuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgbXV0YXRpb24ncyBkYXRhLCBvciByZWplY3RzIHdpdGggaXRzIGVycm9yLlxuXHQqIEBzZWUge0BsaW5rIE11dGF0aW9uI2NvbnRpbnVlfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiAvLyBDYWxsZWQgaW50ZXJuYWxseSBieSBgTXV0YXRpb25PYnNlcnZlci5tdXRhdGVgIGFuZCBgTXV0YXRpb24uY29udGludWVgIOKAlFxuXHQqIC8vIGFwcGxpY2F0aW9ucyBub3JtYWxseSB0cmlnZ2VyIG11dGF0aW9ucyB0aHJvdWdoIHRob3NlLCBub3QgdGhpcyBtZXRob2QuXG5cdCogY29uc3QgZGF0YSA9IGF3YWl0IG11dGF0aW9uLmV4ZWN1dGUodmFyaWFibGVzKVxuXHQqIGBgYFxuXHQqL1xuXHRhc3luYyBleGVjdXRlKHZhcmlhYmxlcykge1xuXHRcdGNvbnN0IG9uQ29udGludWUgPSAoKSA9PiB7XG5cdFx0XHR0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwiY29udGludWVcIiB9KTtcblx0XHR9O1xuXHRcdGNvbnN0IG11dGF0aW9uRm5Db250ZXh0ID0ge1xuXHRcdFx0Y2xpZW50OiB0aGlzLiNjbGllbnQsXG5cdFx0XHRtZXRhOiB0aGlzLm9wdGlvbnMubWV0YSxcblx0XHRcdG11dGF0aW9uS2V5OiB0aGlzLm9wdGlvbnMubXV0YXRpb25LZXlcblx0XHR9O1xuXHRcdGNvbnN0IHJldHJ5ZXIgPSB0aGlzLiNyZXRyeWVyID0gY3JlYXRlUmV0cnllcih7XG5cdFx0XHRmbjogKCkgPT4ge1xuXHRcdFx0XHRpZiAoIXRoaXMub3B0aW9ucy5tdXRhdGlvbkZuKSByZXR1cm4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcIk5vIG11dGF0aW9uRm4gZm91bmRcIikpO1xuXHRcdFx0XHRyZXR1cm4gdGhpcy5vcHRpb25zLm11dGF0aW9uRm4odmFyaWFibGVzLCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR9LFxuXHRcdFx0b25GYWlsOiAoZmFpbHVyZUNvdW50LCBlcnJvcikgPT4ge1xuXHRcdFx0XHR0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRcdFx0dHlwZTogXCJmYWlsZWRcIixcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQsXG5cdFx0XHRcdFx0ZXJyb3Jcblx0XHRcdFx0fSk7XG5cdFx0XHR9LFxuXHRcdFx0b25QYXVzZTogKCkgPT4ge1xuXHRcdFx0XHR0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwicGF1c2VcIiB9KTtcblx0XHRcdH0sXG5cdFx0XHRvbkNvbnRpbnVlLFxuXHRcdFx0cmV0cnk6IHRoaXMub3B0aW9ucy5yZXRyeSA/PyAwLFxuXHRcdFx0cmV0cnlEZWxheTogdGhpcy5vcHRpb25zLnJldHJ5RGVsYXksXG5cdFx0XHRuZXR3b3JrTW9kZTogdGhpcy5vcHRpb25zLm5ldHdvcmtNb2RlLFxuXHRcdFx0Y2FuUnVuOiAoKSA9PiB0aGlzLiNtdXRhdGlvbkNhY2hlLmNhblJ1bih0aGlzKVxuXHRcdH0pO1xuXHRcdGNvbnN0IHJlc3RvcmVkID0gdGhpcy5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiO1xuXHRcdGNvbnN0IGlzUGF1c2VkID0gIXJldHJ5ZXIuY2FuU3RhcnQoKTtcblx0XHR0cnkge1xuXHRcdFx0aWYgKHJlc3RvcmVkKSBvbkNvbnRpbnVlKCk7XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHRcdHR5cGU6IFwicGVuZGluZ1wiLFxuXHRcdFx0XHRcdHZhcmlhYmxlcyxcblx0XHRcdFx0XHRpc1BhdXNlZFxuXHRcdFx0XHR9KTtcblx0XHRcdFx0aWYgKHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uTXV0YXRlKSBhd2FpdCB0aGlzLiNtdXRhdGlvbkNhY2hlLmNvbmZpZy5vbk11dGF0ZSh2YXJpYWJsZXMsIHRoaXMsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdFx0Y29uc3QgY29udGV4dCA9IGF3YWl0IHRoaXMub3B0aW9ucy5vbk11dGF0ZT8uKHZhcmlhYmxlcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0XHRpZiAoY29udGV4dCAhPT0gdGhpcy5zdGF0ZS5jb250ZXh0KSB0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRcdFx0dHlwZTogXCJwZW5kaW5nXCIsXG5cdFx0XHRcdFx0Y29udGV4dCxcblx0XHRcdFx0XHR2YXJpYWJsZXMsXG5cdFx0XHRcdFx0aXNQYXVzZWRcblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBkYXRhID0gYXdhaXQgcmV0cnllci5zdGFydCgpO1xuXHRcdFx0YXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25TdWNjZXNzPy4oZGF0YSwgdmFyaWFibGVzLCB0aGlzLnN0YXRlLmNvbnRleHQsIHRoaXMsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdGF3YWl0IHRoaXMub3B0aW9ucy5vblN1Y2Nlc3M/LihkYXRhLCB2YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0YXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25TZXR0bGVkPy4oZGF0YSwgbnVsbCwgdGhpcy5zdGF0ZS52YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgdGhpcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0YXdhaXQgdGhpcy5vcHRpb25zLm9uU2V0dGxlZD8uKGRhdGEsIG51bGwsIHZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRcdHR5cGU6IFwic3VjY2Vzc1wiLFxuXHRcdFx0XHRkYXRhXG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiBkYXRhO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhd2FpdCB0aGlzLiNtdXRhdGlvbkNhY2hlLmNvbmZpZy5vbkVycm9yPy4oZXJyb3IsIHZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCB0aGlzLCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy5vcHRpb25zLm9uRXJyb3I/LihlcnJvciwgdmFyaWFibGVzLCB0aGlzLnN0YXRlLmNvbnRleHQsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0UHJvbWlzZS5yZWplY3QoZSk7XG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhd2FpdCB0aGlzLiNtdXRhdGlvbkNhY2hlLmNvbmZpZy5vblNldHRsZWQ/Lih2b2lkIDAsIGVycm9yLCB0aGlzLnN0YXRlLnZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCB0aGlzLCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy5vcHRpb25zLm9uU2V0dGxlZD8uKHZvaWQgMCwgZXJyb3IsIHZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHR0eXBlOiBcImVycm9yXCIsXG5cdFx0XHRcdGVycm9yXG5cdFx0XHR9KTtcblx0XHRcdHRocm93IGVycm9yO1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHRpZiAodGhpcy4jcmV0cnllciA9PT0gcmV0cnllcikgdGhpcy4jcmV0cnllciA9IHZvaWQgMDtcblx0XHRcdHRoaXMuI211dGF0aW9uQ2FjaGUucnVuTmV4dCh0aGlzKTtcblx0XHR9XG5cdH1cblx0I2Rpc3BhdGNoKGFjdGlvbikge1xuXHRcdGNvbnN0IHJlZHVjZXIgPSAoc3RhdGUpID0+IHtcblx0XHRcdHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcblx0XHRcdFx0Y2FzZSBcImZhaWxlZFwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGZhaWx1cmVDb3VudDogYWN0aW9uLmZhaWx1cmVDb3VudCxcblx0XHRcdFx0XHRmYWlsdXJlUmVhc29uOiBhY3Rpb24uZXJyb3Jcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcInBhdXNlXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0aXNQYXVzZWQ6IHRydWVcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcImNvbnRpbnVlXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0aXNQYXVzZWQ6IGZhbHNlXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJwZW5kaW5nXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0Y29udGV4dDogYWN0aW9uLmNvbnRleHQsXG5cdFx0XHRcdFx0ZGF0YTogdm9pZCAwLFxuXHRcdFx0XHRcdGZhaWx1cmVDb3VudDogMCxcblx0XHRcdFx0XHRmYWlsdXJlUmVhc29uOiBudWxsLFxuXHRcdFx0XHRcdGVycm9yOiBudWxsLFxuXHRcdFx0XHRcdGlzUGF1c2VkOiBhY3Rpb24uaXNQYXVzZWQsXG5cdFx0XHRcdFx0c3RhdHVzOiBcInBlbmRpbmdcIixcblx0XHRcdFx0XHR2YXJpYWJsZXM6IGFjdGlvbi52YXJpYWJsZXMsXG5cdFx0XHRcdFx0c3VibWl0dGVkQXQ6IERhdGUubm93KClcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcInN1Y2Nlc3NcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRkYXRhOiBhY3Rpb24uZGF0YSxcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQ6IDAsXG5cdFx0XHRcdFx0ZmFpbHVyZVJlYXNvbjogbnVsbCxcblx0XHRcdFx0XHRlcnJvcjogbnVsbCxcblx0XHRcdFx0XHRzdGF0dXM6IFwic3VjY2Vzc1wiLFxuXHRcdFx0XHRcdGlzUGF1c2VkOiBmYWxzZVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwiZXJyb3JcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRkYXRhOiB2b2lkIDAsXG5cdFx0XHRcdFx0ZXJyb3I6IGFjdGlvbi5lcnJvcixcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQ6IHN0YXRlLmZhaWx1cmVDb3VudCArIDEsXG5cdFx0XHRcdFx0ZmFpbHVyZVJlYXNvbjogYWN0aW9uLmVycm9yLFxuXHRcdFx0XHRcdGlzUGF1c2VkOiBmYWxzZSxcblx0XHRcdFx0XHRzdGF0dXM6IFwiZXJyb3JcIlxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdH07XG5cdFx0dGhpcy5zdGF0ZSA9IHJlZHVjZXIodGhpcy5zdGF0ZSk7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLiNvYnNlcnZlcnMuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IHtcblx0XHRcdFx0b2JzZXJ2ZXIub25NdXRhdGlvblVwZGF0ZShhY3Rpb24pO1xuXHRcdFx0fSk7XG5cdFx0XHR0aGlzLiNtdXRhdGlvbkNhY2hlLm5vdGlmeSh7XG5cdFx0XHRcdG11dGF0aW9uOiB0aGlzLFxuXHRcdFx0XHR0eXBlOiBcInVwZGF0ZWRcIixcblx0XHRcdFx0YWN0aW9uXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxufTtcbi8qKlxuKiBSZXR1cm5zIHRoZSBpbml0aWFsIHN0YXRlIG9mIGEgbXV0YXRpb246IGAnaWRsZSdgLCB3aXRoIG5vIGRhdGEsIGVycm9yLCBvciB2YXJpYWJsZXMuXG4qIEByZXR1cm5zIFRoZSBpbml0aWFsIG11dGF0aW9uIHN0YXRlLlxuKi9cbmZ1bmN0aW9uIGdldERlZmF1bHRTdGF0ZSgpIHtcblx0cmV0dXJuIHtcblx0XHRjb250ZXh0OiB2b2lkIDAsXG5cdFx0ZGF0YTogdm9pZCAwLFxuXHRcdGVycm9yOiBudWxsLFxuXHRcdGZhaWx1cmVDb3VudDogMCxcblx0XHRmYWlsdXJlUmVhc29uOiBudWxsLFxuXHRcdGlzUGF1c2VkOiBmYWxzZSxcblx0XHRzdGF0dXM6IFwiaWRsZVwiLFxuXHRcdHZhcmlhYmxlczogdm9pZCAwLFxuXHRcdHN1Ym1pdHRlZEF0OiAwXG5cdH07XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IE11dGF0aW9uLCBnZXREZWZhdWx0U3RhdGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bXV0YXRpb24uanMubWFwIiwiaW1wb3J0IHsgbWF0Y2hNdXRhdGlvbiwgbm9vcCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBNdXRhdGlvbiB9IGZyb20gXCIuL211dGF0aW9uLmpzXCI7XG4vLyNyZWdpb24gc3JjL211dGF0aW9uQ2FjaGUudHNcbi8qKlxuKiBUaGUgYE11dGF0aW9uQ2FjaGVgIGlzIHRoZSBzdG9yYWdlIGZvciBtdXRhdGlvbnMuXG4qXG4qIE5vcm1hbGx5LCB5b3Ugd2lsbCBub3QgaW50ZXJhY3Qgd2l0aCB0aGUgYE11dGF0aW9uQ2FjaGVgIGRpcmVjdGx5IGFuZCBpbnN0ZWFkIHVzZSBhXG4qIGBRdWVyeUNsaWVudGAuIFlvdSBjYW4gc3Vic2NyaWJlIHRvIGl0IChpbmhlcml0ZWQgZnJvbSBgU3Vic2NyaWJhYmxlYCkgdG8gYmUgaW5mb3JtZWQgb2Zcbiogc2FmZS9rbm93biB1cGRhdGVzIHRvIHRoZSBjYWNoZSwgc3VjaCBhcyBtdXRhdGlvbnMgYmVpbmcgYWRkZWQsIHJlbW92ZWQsIG9yIHVwZGF0ZWQuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHVuc3Vic2NyaWJlID0gbXV0YXRpb25DYWNoZS5zdWJzY3JpYmUoKGV2ZW50KSA9PiB7XG4qICAgY29uc29sZS5sb2coZXZlbnQudHlwZSwgZXZlbnQubXV0YXRpb24pXG4qIH0pXG4qIGBgYFxuKi9cbnZhciBNdXRhdGlvbkNhY2hlID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuXHQjbXV0YXRpb25zO1xuXHQjc2NvcGVzO1xuXHQjbXV0YXRpb25JZDtcblx0Y29uc3RydWN0b3IoY29uZmlnID0ge30pIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnO1xuXHRcdHRoaXMuI211dGF0aW9ucyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0dGhpcy4jc2NvcGVzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHR0aGlzLiNtdXRhdGlvbklkID0gMDtcblx0fVxuXHQvKipcblx0KiBDcmVhdGVzIGEgbXV0YXRpb24gYW5kIGFkZHMgaXQgdG8gdGhlIGNhY2hlLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBjbGllbnQgLSBUaGUgY2xpZW50IHRoZSBtdXRhdGlvbiBiZWxvbmdzIHRvLCB1c2VkIHRvIGRlZmF1bHQgaXRzIG9wdGlvbnMuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgbXV0YXRpb24gb3B0aW9ucy4gVGhleSBhcmUgZGVmYXVsdGVkIHdpdGgge0BsaW5rXG5cdCogUXVlcnlDbGllbnQjZGVmYXVsdE11dGF0aW9uT3B0aW9uc30uXG5cdCogQHBhcmFtIHN0YXRlIC0gVGhlIGluaXRpYWwgc3RhdGUgb2YgdGhlIG11dGF0aW9uLCBlLmcuIHdoZW4gcmVzdG9yaW5nIGEgZGVoeWRyYXRlZCBtdXRhdGlvbi5cblx0KiBAcmV0dXJucyBUaGUgbmV3IG11dGF0aW9uLCBhbHJlYWR5IGFkZGVkIHRvIHRoZSBjYWNoZS5cblx0Ki9cblx0YnVpbGQoY2xpZW50LCBvcHRpb25zLCBzdGF0ZSkge1xuXHRcdGNvbnN0IG11dGF0aW9uID0gbmV3IE11dGF0aW9uKHtcblx0XHRcdGNsaWVudCxcblx0XHRcdG11dGF0aW9uQ2FjaGU6IHRoaXMsXG5cdFx0XHRtdXRhdGlvbklkOiArK3RoaXMuI211dGF0aW9uSWQsXG5cdFx0XHRvcHRpb25zOiBjbGllbnQuZGVmYXVsdE11dGF0aW9uT3B0aW9ucyhvcHRpb25zKSxcblx0XHRcdHN0YXRlXG5cdFx0fSk7XG5cdFx0dGhpcy5hZGQobXV0YXRpb24pO1xuXHRcdHJldHVybiBtdXRhdGlvbjtcblx0fVxuXHQvKipcblx0KiBBZGRzIGEgbXV0YXRpb24gdG8gdGhlIGNhY2hlLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBtdXRhdGlvbiAtIFRoZSBtdXRhdGlvbiB0byBhZGQuIElmIGl0IGhhcyBhIGBzY29wZWAsIGl0IGlzIHF1ZXVlZCBpbiB0aGF0IHNjb3BlLlxuXHQqL1xuXHRhZGQobXV0YXRpb24pIHtcblx0XHR0aGlzLiNtdXRhdGlvbnMuYWRkKG11dGF0aW9uKTtcblx0XHRjb25zdCBzY29wZSA9IHNjb3BlRm9yKG11dGF0aW9uKTtcblx0XHRpZiAodHlwZW9mIHNjb3BlID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRjb25zdCBzY29wZWRNdXRhdGlvbnMgPSB0aGlzLiNzY29wZXMuZ2V0KHNjb3BlKTtcblx0XHRcdGlmIChzY29wZWRNdXRhdGlvbnMpIHNjb3BlZE11dGF0aW9ucy5wdXNoKG11dGF0aW9uKTtcblx0XHRcdGVsc2UgdGhpcy4jc2NvcGVzLnNldChzY29wZSwgW211dGF0aW9uXSk7XG5cdFx0fVxuXHRcdHRoaXMubm90aWZ5KHtcblx0XHRcdHR5cGU6IFwiYWRkZWRcIixcblx0XHRcdG11dGF0aW9uXG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmVtb3ZlcyBhIG11dGF0aW9uIGZyb20gdGhlIGNhY2hlLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBtdXRhdGlvbiAtIFRoZSBtdXRhdGlvbiB0byByZW1vdmUsIGFsc28gZnJvbSBpdHMgc2NvcGUncyBxdWV1ZS5cblx0Ki9cblx0cmVtb3ZlKG11dGF0aW9uKSB7XG5cdFx0aWYgKHRoaXMuI211dGF0aW9ucy5kZWxldGUobXV0YXRpb24pKSB7XG5cdFx0XHRjb25zdCBzY29wZSA9IHNjb3BlRm9yKG11dGF0aW9uKTtcblx0XHRcdGlmICh0eXBlb2Ygc2NvcGUgPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdFx0Y29uc3Qgc2NvcGVkTXV0YXRpb25zID0gdGhpcy4jc2NvcGVzLmdldChzY29wZSk7XG5cdFx0XHRcdGlmIChzY29wZWRNdXRhdGlvbnMpIHtcblx0XHRcdFx0XHRpZiAoc2NvcGVkTXV0YXRpb25zLmxlbmd0aCA+IDEpIHtcblx0XHRcdFx0XHRcdGNvbnN0IGluZGV4ID0gc2NvcGVkTXV0YXRpb25zLmluZGV4T2YobXV0YXRpb24pO1xuXHRcdFx0XHRcdFx0aWYgKGluZGV4ICE9PSAtMSkgc2NvcGVkTXV0YXRpb25zLnNwbGljZShpbmRleCwgMSk7XG5cdFx0XHRcdFx0fSBlbHNlIGlmIChzY29wZWRNdXRhdGlvbnNbMF0gPT09IG11dGF0aW9uKSB0aGlzLiNzY29wZXMuZGVsZXRlKHNjb3BlKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0XHR0aGlzLm5vdGlmeSh7XG5cdFx0XHR0eXBlOiBcInJlbW92ZWRcIixcblx0XHRcdG11dGF0aW9uXG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogQ2hlY2tzIHdoZXRoZXIgYSBtdXRhdGlvbiBjYW4gcnVuIG5vdywgZ2l2ZW4gdGhlIG90aGVyIG11dGF0aW9ucyBpbiBpdHMgYHNjb3BlYC5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdG8gY2hlY2suXG5cdCogQHJldHVybnMgYHRydWVgIGlmIHRoZSBtdXRhdGlvbiBoYXMgbm8gYHNjb3BlYCwgb3Igbm8gb3RoZXIgbXV0YXRpb24gaW4gaXRzIHNjb3BlIGlzIHBlbmRpbmdcblx0KiBhaGVhZCBvZiBpdC5cblx0Ki9cblx0Y2FuUnVuKG11dGF0aW9uKSB7XG5cdFx0Y29uc3Qgc2NvcGUgPSBzY29wZUZvcihtdXRhdGlvbik7XG5cdFx0aWYgKHR5cGVvZiBzY29wZSA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0Y29uc3QgZmlyc3RQZW5kaW5nTXV0YXRpb24gPSB0aGlzLiNzY29wZXMuZ2V0KHNjb3BlKT8uZmluZCgobSkgPT4gbS5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiKTtcblx0XHRcdHJldHVybiAhZmlyc3RQZW5kaW5nTXV0YXRpb24gfHwgZmlyc3RQZW5kaW5nTXV0YXRpb24gPT09IG11dGF0aW9uO1xuXHRcdH0gZWxzZSByZXR1cm4gdHJ1ZTtcblx0fVxuXHQvKipcblx0KiBDb250aW51ZXMgdGhlIG5leHQgcGF1c2VkIG11dGF0aW9uIGluIHRoZSBzYW1lIGBzY29wZWAgYWZ0ZXIgYSBtdXRhdGlvbiBmaW5pc2hlcy5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdGhhdCBmaW5pc2hlZC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIHRoZSBuZXh0IHBhdXNlZCBtdXRhdGlvbiBpbiB0aGUgc2FtZSBzY29wZSBoYXMgY29udGludWVkLFxuXHQqIG9yIGltbWVkaWF0ZWx5IGlmIHRoZXJlIGlzIG5vbmUuXG5cdCovXG5cdHJ1bk5leHQobXV0YXRpb24pIHtcblx0XHRjb25zdCBzY29wZSA9IHNjb3BlRm9yKG11dGF0aW9uKTtcblx0XHRpZiAodHlwZW9mIHNjb3BlID09PSBcInN0cmluZ1wiKSByZXR1cm4gKHRoaXMuI3Njb3Blcy5nZXQoc2NvcGUpPy5maW5kKChtKSA9PiBtICE9PSBtdXRhdGlvbiAmJiBtLnN0YXRlLmlzUGF1c2VkKSk/LmNvbnRpbnVlKCkgPz8gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0ZWxzZSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdH1cblx0LyoqXG5cdCogUmVtb3ZlcyBhbGwgbXV0YXRpb25zIGZyb20gdGhlIGNhY2hlLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBtdXRhdGlvbkNhY2hlID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpXG5cdCpcblx0KiBtdXRhdGlvbkNhY2hlLmNsZWFyKClcblx0KiBgYGBcblx0Ki9cblx0Y2xlYXIoKSB7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHRjb25zdCBtdXRhdGlvbnMgPSB0aGlzLmdldEFsbCgpO1xuXHRcdFx0dGhpcy4jbXV0YXRpb25zLmNsZWFyKCk7XG5cdFx0XHR0aGlzLiNzY29wZXMuY2xlYXIoKTtcblx0XHRcdG11dGF0aW9ucy5mb3JFYWNoKChtdXRhdGlvbikgPT4ge1xuXHRcdFx0XHR0aGlzLm5vdGlmeSh7XG5cdFx0XHRcdFx0dHlwZTogXCJyZW1vdmVkXCIsXG5cdFx0XHRcdFx0bXV0YXRpb25cblx0XHRcdFx0fSk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIGFsbCBtdXRhdGlvbnMgd2l0aGluIHRoZSBjYWNoZS5cblx0KlxuXHQqIFRoaXMgaXMgbm90IHR5cGljYWxseSBuZWVkZWQgZm9yIG1vc3QgYXBwbGljYXRpb25zLCBidXQgY2FuIGNvbWUgaW4gaGFuZHkgd2hlbiBuZWVkaW5nIG1vcmVcblx0KiBpbmZvcm1hdGlvbiBhYm91dCBhIG11dGF0aW9uIGluIHJhcmUgc2NlbmFyaW9zLlxuXHQqIEByZXR1cm5zIEV2ZXJ5IG11dGF0aW9uIGluIHRoZSBjYWNoZS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgbXV0YXRpb25DYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKVxuXHQqXG5cdCogY29uc3QgbXV0YXRpb25zID0gbXV0YXRpb25DYWNoZS5nZXRBbGwoKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRBbGwoKSB7XG5cdFx0cmV0dXJuIEFycmF5LmZyb20odGhpcy4jbXV0YXRpb25zKTtcblx0fVxuXHQvKipcblx0KiBBIHNsaWdodGx5IG1vcmUgYWR2YW5jZWQgbWV0aG9kIHRoYXQgY2FuIGJlIHVzZWQgdG8gZ2V0IGFuIGV4aXN0aW5nIG11dGF0aW9uIGluc3RhbmNlIGZyb21cblx0KiB0aGUgY2FjaGUuIElmIHRoZSBtdXRhdGlvbiBkb2VzIG5vdCBleGlzdCwgYHVuZGVmaW5lZGAgaXMgcmV0dXJuZWQuXG5cdCpcblx0KiBUaGlzIGlzIG5vdCB0eXBpY2FsbHkgbmVlZGVkIGZvciBtb3N0IGFwcGxpY2F0aW9ucywgYnV0IGNhbiBjb21lIGluIGhhbmR5IHdoZW4gbmVlZGluZyBtb3JlXG5cdCogaW5mb3JtYXRpb24gYWJvdXQgYSBtdXRhdGlvbiBpbiByYXJlIHNjZW5hcmlvcy5cblx0KiBAcGFyYW0gZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRvIG1hdGNoLiBgZXhhY3RgIGRlZmF1bHRzIHRvIGB0cnVlYC5cblx0KiBAcmV0dXJucyBUaGUgZmlyc3QgbWF0Y2hpbmcgbXV0YXRpb24sIG9yIGB1bmRlZmluZWRgLlxuXHQqIEBzZWUge0BsaW5rIE11dGF0aW9uQ2FjaGUjZmluZEFsbH1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgbXV0YXRpb25DYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKVxuXHQqXG5cdCogY29uc3QgbXV0YXRpb24gPSBtdXRhdGlvbkNhY2hlLmZpbmQoeyBtdXRhdGlvbktleTogWydhZGRQb3N0J10gfSlcblx0KiBgYGBcblx0Ki9cblx0ZmluZChmaWx0ZXJzKSB7XG5cdFx0Y29uc3QgZGVmYXVsdGVkRmlsdGVycyA9IHtcblx0XHRcdGV4YWN0OiB0cnVlLFxuXHRcdFx0Li4uZmlsdGVyc1xuXHRcdH07XG5cdFx0cmV0dXJuIHRoaXMuZ2V0QWxsKCkuZmluZCgobXV0YXRpb24pID0+IG1hdGNoTXV0YXRpb24oZGVmYXVsdGVkRmlsdGVycywgbXV0YXRpb24pKTtcblx0fVxuXHQvKipcblx0KiBBbiBldmVuIG1vcmUgYWR2YW5jZWQgbWV0aG9kIHRoYXQgY2FuIGJlIHVzZWQgdG8gZ2V0IGV4aXN0aW5nIG11dGF0aW9uIGluc3RhbmNlcyBmcm9tIHRoZVxuXHQqIGNhY2hlIHRoYXQgbWF0Y2ggdGhlIGdpdmVuIGZpbHRlcnMuIElmIG5vIG11dGF0aW9ucyBtYXRjaCwgYW4gZW1wdHkgYXJyYXkgaXMgcmV0dXJuZWQuXG5cdCpcblx0KiBUaGlzIGlzIG5vdCB0eXBpY2FsbHkgbmVlZGVkIGZvciBtb3N0IGFwcGxpY2F0aW9ucywgYnV0IGNhbiBjb21lIGluIGhhbmR5IHdoZW4gbmVlZGluZyBtb3JlXG5cdCogaW5mb3JtYXRpb24gYWJvdXQgbXV0YXRpb25zIGluIHJhcmUgc2NlbmFyaW9zLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdG8gbWF0Y2guIFdpdGhvdXQgZmlsdGVycywgZXZlcnkgbXV0YXRpb24gaXMgcmV0dXJuZWQuXG5cdCogQHJldHVybnMgVGhlIG1hdGNoaW5nIG11dGF0aW9ucy5cblx0KiBAc2VlIHtAbGluayBNdXRhdGlvbkNhY2hlI2ZpbmR9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKClcblx0KlxuXHQqIGNvbnN0IG11dGF0aW9ucyA9IG11dGF0aW9uQ2FjaGUuZmluZEFsbCh7IG11dGF0aW9uS2V5OiBbJ2FkZFBvc3QnXSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRmaW5kQWxsKGZpbHRlcnMgPSB7fSkge1xuXHRcdHJldHVybiB0aGlzLmdldEFsbCgpLmZpbHRlcigobXV0YXRpb24pID0+IG1hdGNoTXV0YXRpb24oZmlsdGVycywgbXV0YXRpb24pKTtcblx0fVxuXHQvKipcblx0KiBOb3RpZmllcyBldmVyeSBjYWNoZSBsaXN0ZW5lciBvZiBhbiBldmVudCwgaW4gb25lIGJhdGNoLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBldmVudCAtIFRoZSBldmVudCBwYXNzZWQgdG8gZXZlcnkgbGlzdGVuZXIuXG5cdCovXG5cdG5vdGlmeShldmVudCkge1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcblx0XHRcdFx0bGlzdGVuZXIoZXZlbnQpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogQ29udGludWVzIGV2ZXJ5IHBhdXNlZCBtdXRhdGlvbiwgZS5nLiB3aGVuIHRoZSBhcHAgY29tZXMgYmFjayBvbmxpbmUuXG5cdCogQGludGVybmFsXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSBldmVyeSBwYXVzZWQgbXV0YXRpb24gaGFzIGNvbnRpbnVlZCBhbmQgc2V0dGxlZC5cblx0Ki9cblx0cmVzdW1lUGF1c2VkTXV0YXRpb25zKCkge1xuXHRcdGNvbnN0IHBhdXNlZE11dGF0aW9ucyA9IHRoaXMuZ2V0QWxsKCkuZmlsdGVyKCh4KSA9PiB4LnN0YXRlLmlzUGF1c2VkKTtcblx0XHRyZXR1cm4gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiBQcm9taXNlLmFsbChwYXVzZWRNdXRhdGlvbnMubWFwKChtdXRhdGlvbikgPT4gbXV0YXRpb24uY29udGludWUoKS5jYXRjaChub29wKSkpKTtcblx0fVxufTtcbi8qKlxuKiBSZXR1cm5zIHRoZSBzY29wZSBpZCBvZiBhIG11dGF0aW9uLCB1c2VkIHRvIHJ1biBtdXRhdGlvbnMgd2l0aCB0aGUgc2FtZSBzY29wZSBvbmUgYWZ0ZXIgYW5vdGhlci5cbiogQHBhcmFtIG11dGF0aW9uIC0gVGhlIG11dGF0aW9uIHRvIHJlYWQgdGhlIHNjb3BlIG9mLlxuKiBAcmV0dXJucyBUaGUgbXV0YXRpb24ncyBgc2NvcGUuaWRgLCBvciBgdW5kZWZpbmVkYCBpZiBpdCBoYXMgbm8gc2NvcGUuXG4qL1xuZnVuY3Rpb24gc2NvcGVGb3IobXV0YXRpb24pIHtcblx0cmV0dXJuIG11dGF0aW9uLm9wdGlvbnMuc2NvcGU/LmlkO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBNdXRhdGlvbkNhY2hlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW11dGF0aW9uQ2FjaGUuanMubWFwIiwiaW1wb3J0IHsgaGFzaEtleSwgc2hhbGxvd0VxdWFsT2JqZWN0cyB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBnZXREZWZhdWx0U3RhdGUgfSBmcm9tIFwiLi9tdXRhdGlvbi5qc1wiO1xuLy8jcmVnaW9uIHNyYy9tdXRhdGlvbk9ic2VydmVyLnRzXG4vKipcbiogT2JzZXJ2ZXMgYSBzaW5nbGUgbXV0YXRpb24gYW5kIGRlcml2ZXMgYSBgTXV0YXRpb25PYnNlcnZlclJlc3VsdGAgZnJvbSBpdC5cbiogQSBmcmFtZXdvcmsgaG9vayBsaWtlIGB1c2VNdXRhdGlvbmAgY3JlYXRlcyBvbmUgYE11dGF0aW9uT2JzZXJ2ZXJgIHBlciBob29rXG4qIGNhbGwsIGtlZXBzIGl0IHN0YWJsZSBhY3Jvc3MgcmUtcmVuZGVycywgY2FsbHMgYHNldE9wdGlvbnNgIHdoZW4gdGhlIG9wdGlvbnNcbiogcGFzc2VkIHRvIHRoZSBob29rIGNoYW5nZSwgc3Vic2NyaWJlcyB0byBpdCB0byByZS1yZW5kZXIgb24gdXBkYXRlcywgYW5kXG4qIHJlYWRzIGBnZXRDdXJyZW50UmVzdWx0KClgIGZvciB0aGUgdmFsdWUgdG8gcmV0dXJuLiBDYWxsaW5nIGBtdXRhdGUoKWBcbiogYnVpbGRzIGEgbmV3IHVuZGVybHlpbmcgYE11dGF0aW9uYCBpbiB0aGUgYE11dGF0aW9uQ2FjaGVgIGFuZCBleGVjdXRlcyBpdC5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcihxdWVyeUNsaWVudCwge1xuKiAgIG11dGF0aW9uRm46ICh2YXJpYWJsZXM6IHsgdGl0bGU6IHN0cmluZyB9KSA9PiBhZGRQb3N0KHZhcmlhYmxlcyksXG4qIH0pXG4qIGBgYFxuKi9cbnZhciBNdXRhdGlvbk9ic2VydmVyID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuXHQjY2xpZW50O1xuXHQjY3VycmVudFJlc3VsdCA9IHZvaWQgMDtcblx0I2N1cnJlbnRNdXRhdGlvbjtcblx0I211dGF0ZU9wdGlvbnM7XG5cdGNvbnN0cnVjdG9yKGNsaWVudCwgb3B0aW9ucykge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy4jY2xpZW50ID0gY2xpZW50O1xuXHRcdHRoaXMuc2V0T3B0aW9ucyhvcHRpb25zKTtcblx0XHR0aGlzLmJpbmRNZXRob2RzKCk7XG5cdFx0dGhpcy4jdXBkYXRlUmVzdWx0KCk7XG5cdH1cblx0LyoqXG5cdCogQmluZHMgdGhlIG1ldGhvZHMgb2YgdGhlIHJlc3VsdCAoYG11dGF0ZWAgYW5kIGByZXNldGApIHRvIHRoZSBvYnNlcnZlciwgc28gdGhleSBrZWVwIHdvcmtpbmcgd2hlblxuXHQqIGRlc3RydWN0dXJlZCBmcm9tIGl0LlxuXHQqL1xuXHRiaW5kTWV0aG9kcygpIHtcblx0XHR0aGlzLm11dGF0ZSA9IHRoaXMubXV0YXRlLmJpbmQodGhpcyk7XG5cdFx0dGhpcy5yZXNldCA9IHRoaXMucmVzZXQuYmluZCh0aGlzKTtcblx0fVxuXHQvKipcblx0KiBVcGRhdGVzIHRoZSBvYnNlcnZlcidzIG9wdGlvbnMuXG5cdCpcblx0KiBJZiB0aGUgbmV3IGBtdXRhdGlvbktleWAgZGlmZmVycyBmcm9tIHRoZSBwcmV2aW91cyBvbmUgKGFuZCBib3RoIHdlcmVcblx0KiBkZWZpbmVkKSwgdGhlIG9ic2VydmVyIGlzIHJlc2V0LCBkZXRhY2hpbmcgaXQgZnJvbSB0aGUgbXV0YXRpb24gaXQgd2FzXG5cdCogb2JzZXJ2aW5nLiBPdGhlcndpc2UsIGlmIHRoZSBjdXJyZW50bHkgb2JzZXJ2ZWQgbXV0YXRpb24gaXMgc3RpbGxcblx0KiBgcGVuZGluZ2AsIGl0cyBvcHRpb25zIGFyZSB1cGRhdGVkIGluIHBsYWNlIGFzIHdlbGwuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgbmV3IG11dGF0aW9uIG9ic2VydmVyIG9wdGlvbnMuIFRoZXkgYXJlIGRlZmF1bHRlZCB3aXRoIHtAbGlua1xuXHQqIFF1ZXJ5Q2xpZW50I2RlZmF1bHRNdXRhdGlvbk9wdGlvbnN9IGJlZm9yZSBiZWluZyBhcHBsaWVkLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBvYnNlcnZlci5zZXRPcHRpb25zKHtcblx0KiAgIG11dGF0aW9uRm46ICh2YXJpYWJsZXM6IHsgdGl0bGU6IHN0cmluZyB9KSA9PiBhZGRQb3N0KHZhcmlhYmxlcyksXG5cdCogICBvblN1Y2Nlc3M6IChkYXRhKSA9PiBjb25zb2xlLmxvZyhkYXRhKSxcblx0KiB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRPcHRpb25zKG9wdGlvbnMpIHtcblx0XHRjb25zdCBwcmV2T3B0aW9ucyA9IHRoaXMub3B0aW9ucztcblx0XHR0aGlzLm9wdGlvbnMgPSB0aGlzLiNjbGllbnQuZGVmYXVsdE11dGF0aW9uT3B0aW9ucyhvcHRpb25zKTtcblx0XHRpZiAoIXNoYWxsb3dFcXVhbE9iamVjdHModGhpcy5vcHRpb25zLCBwcmV2T3B0aW9ucykpIHRoaXMuI2NsaWVudC5nZXRNdXRhdGlvbkNhY2hlKCkubm90aWZ5KHtcblx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJPcHRpb25zVXBkYXRlZFwiLFxuXHRcdFx0bXV0YXRpb246IHRoaXMuI2N1cnJlbnRNdXRhdGlvbixcblx0XHRcdG9ic2VydmVyOiB0aGlzXG5cdFx0fSk7XG5cdFx0aWYgKHByZXZPcHRpb25zPy5tdXRhdGlvbktleSAmJiB0aGlzLm9wdGlvbnMubXV0YXRpb25LZXkgJiYgaGFzaEtleShwcmV2T3B0aW9ucy5tdXRhdGlvbktleSkgIT09IGhhc2hLZXkodGhpcy5vcHRpb25zLm11dGF0aW9uS2V5KSkgdGhpcy5yZXNldCgpO1xuXHRcdGVsc2UgaWYgKHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8uc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIikgdGhpcy4jY3VycmVudE11dGF0aW9uLnNldE9wdGlvbnModGhpcy5vcHRpb25zKTtcblx0fVxuXHRvblN1YnNjcmliZSgpIHtcblx0XHRpZiAodGhpcy5saXN0ZW5lcnMuc2l6ZSA9PT0gMSAmJiB0aGlzLiNjdXJyZW50TXV0YXRpb24pIHtcblx0XHRcdHRoaXMuI2N1cnJlbnRNdXRhdGlvbi5hZGRPYnNlcnZlcih0aGlzKTtcblx0XHRcdHRoaXMuI3VwZGF0ZVJlc3VsdCgpO1xuXHRcdH1cblx0fVxuXHRvblVuc3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy5oYXNMaXN0ZW5lcnMoKSkgdGhpcy4jY3VycmVudE11dGF0aW9uPy5yZW1vdmVPYnNlcnZlcih0aGlzKTtcblx0fVxuXHQvKipcblx0KiBVcGRhdGVzIHRoZSBvYnNlcnZlcidzIHJlc3VsdCB3aGVuIHRoZSBvYnNlcnZlZCBtdXRhdGlvbiBjaGFuZ2VzLCBhbmQgbm90aWZpZXMgaXRzIGxpc3RlbmVycy5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gYWN0aW9uIC0gVGhlIGFjdGlvbiB0aGF0IHVwZGF0ZWQgdGhlIG9ic2VydmVkIG11dGF0aW9uLCBwYXNzZWQgb24gdG8gdGhlIG9ic2VydmVyJ3Ncblx0KiBjYWxsYmFja3MuXG5cdCovXG5cdG9uTXV0YXRpb25VcGRhdGUoYWN0aW9uKSB7XG5cdFx0dGhpcy4jdXBkYXRlUmVzdWx0KCk7XG5cdFx0dGhpcy4jbm90aWZ5KGFjdGlvbik7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgb2JzZXJ2ZXIncyBjdXJyZW50IHJlc3VsdCwgZGVyaXZlZCBmcm9tIHRoZSBvYnNlcnZlZFxuXHQqIG11dGF0aW9uJ3Mgc3RhdGUgKG9yIHRoZSBkZWZhdWx0LCBgaWRsZWAgc3RhdGUgaWYgbm8gbXV0YXRpb24gaGFzIGJlZW5cblx0KiBidWlsdCB5ZXQsIGUuZy4gYmVmb3JlIHRoZSBmaXJzdCBgbXV0YXRlKClgIGNhbGwgb3IgYWZ0ZXIgYHJlc2V0KClgKS5cblx0KiBAcmV0dXJucyBUaGUgb2JzZXJ2ZXIncyBsYXRlc3QgcmVzdWx0LlxuXHQqL1xuXHRnZXRDdXJyZW50UmVzdWx0KCkge1xuXHRcdHJldHVybiB0aGlzLiNjdXJyZW50UmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIERldGFjaGVzIHRoZSBvYnNlcnZlciBmcm9tIHRoZSBtdXRhdGlvbiBpdCBpcyBjdXJyZW50bHkgb2JzZXJ2aW5nIChpZlxuXHQqIGFueSkgYW5kIHJlc2V0cyB0aGUgb2JzZXJ2ZWQgcmVzdWx0IGJhY2sgdG8gaXRzIGRlZmF1bHQsIGBpZGxlYCBzdGF0ZS5cblx0KlxuXHQqIFRoaXMgZG9lcyBub3QgY2FuY2VsIGFuIGluLWZsaWdodCBtdXRhdGlvbjsgdGhlIG11dGF0aW9uIGl0c2VsZiBrZWVwc1xuXHQqIHJ1bm5pbmcgdG8gY29tcGxldGlvbiBhbmQgaXRzIG93biBjYWxsYmFja3Mgc3RpbGwgZmlyZSwgYnV0IHRoaXNcblx0KiBvYnNlcnZlciBzdG9wcyByZWZsZWN0aW5nIGl0cyBzdGF0ZSBhbmQgYSBzdWJzZXF1ZW50IGBtdXRhdGUoKWAgY2FsbFxuXHQqIHdpbGwgYnVpbGQgYSBicmFuZCBuZXcgbXV0YXRpb24uXG5cdCogQHNlZSB7QGxpbmsgTXV0YXRpb25PYnNlcnZlciNtdXRhdGV9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIG9ic2VydmVyLnJlc2V0KClcblx0KiBgYGBcblx0Ki9cblx0cmVzZXQoKSB7XG5cdFx0dGhpcy4jY3VycmVudE11dGF0aW9uPy5yZW1vdmVPYnNlcnZlcih0aGlzKTtcblx0XHR0aGlzLiNjdXJyZW50TXV0YXRpb24gPSB2b2lkIDA7XG5cdFx0dGhpcy4jdXBkYXRlUmVzdWx0KCk7XG5cdFx0dGhpcy4jbm90aWZ5KCk7XG5cdH1cblx0LyoqXG5cdCogQnVpbGRzIGEgbmV3IGBNdXRhdGlvbmAgaW4gdGhlIGBNdXRhdGlvbkNhY2hlYCB1c2luZyB0aGUgb2JzZXJ2ZXInc1xuXHQqIGN1cnJlbnQgb3B0aW9ucywgZGV0YWNoZXMgdGhpcyBvYnNlcnZlciBmcm9tIGFueSBwcmV2aW91c2x5IG9ic2VydmVkXG5cdCogbXV0YXRpb24sIGF0dGFjaGVzIGl0IHRvIHRoZSBuZXcgb25lLCBhbmQgZXhlY3V0ZXMgaXQgd2l0aCB0aGUgZ2l2ZW5cblx0KiB2YXJpYWJsZXMuXG5cdCpcblx0KiBUaGUgb3B0aW9uYWwgcGVyLWNhbGwgYG9wdGlvbnNgIChgb25TdWNjZXNzYC9gb25FcnJvcmAvYG9uU2V0dGxlZGApIGFyZVxuXHQqIGludm9rZWQgb25jZSB0aGUgbXV0YXRpb24gc2V0dGxlcywgaW4gYWRkaXRpb24gdG8gYW55IGNhbGxiYWNrcyBkZWZpbmVkXG5cdCogb24gdGhlIG9ic2VydmVyJ3Mgb3duIG9wdGlvbnMuXG5cdCogQHBhcmFtIHZhcmlhYmxlcyAtIFRoZSB2YXJpYWJsZXMgcGFzc2VkIHRvIHRoZSBgbXV0YXRpb25GbmAuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBQZXItY2FsbCBgb25TdWNjZXNzYCwgYG9uRXJyb3JgLCBhbmQgYG9uU2V0dGxlZGAgY2FsbGJhY2tzLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIG11dGF0aW9uJ3MgZGF0YSwgb3IgcmVqZWN0cyB3aXRoIGl0cyBlcnJvci5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogYXdhaXQgb2JzZXJ2ZXIubXV0YXRlKFxuXHQqICAgeyB0aXRsZTogJ05ldyBwb3N0JyB9LFxuXHQqICAgeyBvblN1Y2Nlc3M6IChkYXRhKSA9PiBjb25zb2xlLmxvZyhkYXRhKSB9LFxuXHQqIClcblx0KiBgYGBcblx0Ki9cblx0bXV0YXRlKHZhcmlhYmxlcywgb3B0aW9ucykge1xuXHRcdHRoaXMuI211dGF0ZU9wdGlvbnMgPSBvcHRpb25zO1xuXHRcdHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8ucmVtb3ZlT2JzZXJ2ZXIodGhpcyk7XG5cdFx0dGhpcy4jY3VycmVudE11dGF0aW9uID0gdGhpcy4jY2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKS5idWlsZCh0aGlzLiNjbGllbnQsIHRoaXMub3B0aW9ucyk7XG5cdFx0dGhpcy4jY3VycmVudE11dGF0aW9uLmFkZE9ic2VydmVyKHRoaXMpO1xuXHRcdHJldHVybiB0aGlzLiNjdXJyZW50TXV0YXRpb24uZXhlY3V0ZSh2YXJpYWJsZXMpO1xuXHR9XG5cdCN1cGRhdGVSZXN1bHQoKSB7XG5cdFx0Y29uc3Qgc3RhdGUgPSB0aGlzLiNjdXJyZW50TXV0YXRpb24/LnN0YXRlID8/IGdldERlZmF1bHRTdGF0ZSgpO1xuXHRcdHRoaXMuI2N1cnJlbnRSZXN1bHQgPSB7XG5cdFx0XHQuLi5zdGF0ZSxcblx0XHRcdGlzUGVuZGluZzogc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIixcblx0XHRcdGlzU3VjY2Vzczogc3RhdGUuc3RhdHVzID09PSBcInN1Y2Nlc3NcIixcblx0XHRcdGlzRXJyb3I6IHN0YXRlLnN0YXR1cyA9PT0gXCJlcnJvclwiLFxuXHRcdFx0aXNJZGxlOiBzdGF0ZS5zdGF0dXMgPT09IFwiaWRsZVwiLFxuXHRcdFx0bXV0YXRlOiB0aGlzLm11dGF0ZSxcblx0XHRcdHJlc2V0OiB0aGlzLnJlc2V0XG5cdFx0fTtcblx0fVxuXHQjbm90aWZ5KGFjdGlvbikge1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0Y29uc3QgbXV0YXRlT3B0aW9ucyA9IHRoaXMuI211dGF0ZU9wdGlvbnM7XG5cdFx0XHRpZiAobXV0YXRlT3B0aW9ucyAmJiB0aGlzLmhhc0xpc3RlbmVycygpKSB7XG5cdFx0XHRcdGNvbnN0IHZhcmlhYmxlcyA9IHRoaXMuI2N1cnJlbnRSZXN1bHQudmFyaWFibGVzO1xuXHRcdFx0XHRjb25zdCBvbk11dGF0ZVJlc3VsdCA9IHRoaXMuI2N1cnJlbnRSZXN1bHQuY29udGV4dDtcblx0XHRcdFx0Y29uc3QgY29udGV4dCA9IHtcblx0XHRcdFx0XHRjbGllbnQ6IHRoaXMuI2NsaWVudCxcblx0XHRcdFx0XHRtZXRhOiB0aGlzLm9wdGlvbnMubWV0YSxcblx0XHRcdFx0XHRtdXRhdGlvbktleTogdGhpcy5vcHRpb25zLm11dGF0aW9uS2V5XG5cdFx0XHRcdH07XG5cdFx0XHRcdGlmIChhY3Rpb24/LnR5cGUgPT09IFwic3VjY2Vzc1wiKSB7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdG11dGF0ZU9wdGlvbnMub25TdWNjZXNzPy4oYWN0aW9uLmRhdGEsIHZhcmlhYmxlcywgb25NdXRhdGVSZXN1bHQsIGNvbnRleHQpO1xuXHRcdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0bXV0YXRlT3B0aW9ucy5vblNldHRsZWQ/LihhY3Rpb24uZGF0YSwgbnVsbCwgdmFyaWFibGVzLCBvbk11dGF0ZVJlc3VsdCwgY29udGV4dCk7XG5cdFx0XHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRcdFx0UHJvbWlzZS5yZWplY3QoZSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9IGVsc2UgaWYgKGFjdGlvbj8udHlwZSA9PT0gXCJlcnJvclwiKSB7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdG11dGF0ZU9wdGlvbnMub25FcnJvcj8uKGFjdGlvbi5lcnJvciwgdmFyaWFibGVzLCBvbk11dGF0ZVJlc3VsdCwgY29udGV4dCk7XG5cdFx0XHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRcdFx0UHJvbWlzZS5yZWplY3QoZSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRtdXRhdGVPcHRpb25zLm9uU2V0dGxlZD8uKHZvaWQgMCwgYWN0aW9uLmVycm9yLCB2YXJpYWJsZXMsIG9uTXV0YXRlUmVzdWx0LCBjb250ZXh0KTtcblx0XHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRcdGxpc3RlbmVyKHRoaXMuI2N1cnJlbnRSZXN1bHQpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IE11dGF0aW9uT2JzZXJ2ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bXV0YXRpb25PYnNlcnZlci5qcy5tYXAiLCJpbXBvcnQgeyByZXBsYWNlRXF1YWxEZWVwLCBzaGFsbG93RXF1YWxPYmplY3RzIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIgfSBmcm9tIFwiLi9xdWVyeU9ic2VydmVyLmpzXCI7XG4vLyNyZWdpb24gc3JjL3F1ZXJpZXNPYnNlcnZlci50c1xuLyoqXG4qIFJldHVybnMgdGhlIGl0ZW1zIG9mIGBhcnJheTFgIHRoYXQgYXJlIG5vdCBpbiBgYXJyYXkyYC5cbiogQHBhcmFtIGFycmF5MSAtIFRoZSBpdGVtcyB0byBmaWx0ZXIuXG4qIEBwYXJhbSBhcnJheTIgLSBUaGUgaXRlbXMgdG8gZXhjbHVkZS5cbiogQHJldHVybnMgQSBuZXcgYXJyYXkgd2l0aCB0aGUgaXRlbXMgb2YgYGFycmF5MWAgdGhhdCBhcmUgbm90IGluIGBhcnJheTJgLlxuKi9cbmZ1bmN0aW9uIGRpZmZlcmVuY2UoYXJyYXkxLCBhcnJheTIpIHtcblx0Y29uc3QgZXhjbHVkZVNldCA9IG5ldyBTZXQoYXJyYXkyKTtcblx0cmV0dXJuIGFycmF5MS5maWx0ZXIoKHgpID0+ICFleGNsdWRlU2V0Lmhhcyh4KSk7XG59XG4vKipcbiogQSBgUXVlcmllc09ic2VydmVyYCB3YXRjaGVzIGFuIGFycmF5IG9mIHF1ZXJpZXMgYXQgb25jZSwgZXhwb3NpbmcgdGhlbSBhc1xuKiBhIHNpbmdsZSBhcnJheSBvZiBgUXVlcnlPYnNlcnZlclJlc3VsdGBzIChvciwgd2hlbiBhIGBjb21iaW5lYCBvcHRpb24gaXNcbiogZ2l2ZW4sIGFzIGEgY29tYmluZWQgdmFsdWUgZGVyaXZlZCBmcm9tIHRoYXQgYXJyYXkpLiBJdCBtYW5hZ2VzIG9uZVxuKiBpbnRlcm5hbCBgUXVlcnlPYnNlcnZlcmAgcGVyIHF1ZXJ5LCBhbmQgaXMgdGhlIHByaW1pdGl2ZSB0aGF0IGZyYW1ld29ya1xuKiBhZGFwdGVycyAoZS5nLiBgdXNlUXVlcmllc2ApIGJ1aWxkIHRoZWlyIGhvb2tzIG9uIHRvcCBvZi5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgUXVlcmllc09ic2VydmVyKHF1ZXJ5Q2xpZW50LCBbXG4qICAgeyBxdWVyeUtleTogWydwb3N0JywgMV0sIHF1ZXJ5Rm46IGZldGNoUG9zdCB9LFxuKiAgIHsgcXVlcnlLZXk6IFsncG9zdCcsIDJdLCBxdWVyeUZuOiBmZXRjaFBvc3QgfSxcbiogXSlcbipcbiogY29uc3QgdW5zdWJzY3JpYmUgPSBvYnNlcnZlci5zdWJzY3JpYmUoKHJlc3VsdCkgPT4ge1xuKiAgIGNvbnNvbGUubG9nKHJlc3VsdClcbiogfSlcbiogYGBgXG4qL1xudmFyIFF1ZXJpZXNPYnNlcnZlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I2NsaWVudDtcblx0I3Jlc3VsdDtcblx0I3F1ZXJpZXM7XG5cdCNvcHRpb25zO1xuXHQjb2JzZXJ2ZXJzO1xuXHQjY29tYmluZWRSZXN1bHQ7XG5cdCNsYXN0Q29tYmluZTtcblx0I2xhc3RSZXN1bHQ7XG5cdCNsYXN0UXVlcnlIYXNoZXM7XG5cdCNvYnNlcnZlck1hdGNoZXMgPSBbXTtcblx0Y29uc3RydWN0b3IoY2xpZW50LCBxdWVyaWVzLCBvcHRpb25zKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLiNjbGllbnQgPSBjbGllbnQ7XG5cdFx0dGhpcy4jb3B0aW9ucyA9IG9wdGlvbnM7XG5cdFx0dGhpcy4jcXVlcmllcyA9IFtdO1xuXHRcdHRoaXMuI29ic2VydmVycyA9IFtdO1xuXHRcdHRoaXMuI3Jlc3VsdCA9IFtdO1xuXHRcdHRoaXMuc2V0UXVlcmllcyhxdWVyaWVzKTtcblx0fVxuXHRvblN1YnNjcmliZSgpIHtcblx0XHRpZiAodGhpcy5saXN0ZW5lcnMuc2l6ZSA9PT0gMSkgdGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG5cdFx0XHRvYnNlcnZlci5zdWJzY3JpYmUoKHJlc3VsdCkgPT4ge1xuXHRcdFx0XHR0aGlzLiNvblVwZGF0ZShvYnNlcnZlciwgcmVzdWx0KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG5cdG9uVW5zdWJzY3JpYmUoKSB7XG5cdFx0aWYgKCF0aGlzLmxpc3RlbmVycy5zaXplKSB0aGlzLmRlc3Ryb3koKTtcblx0fVxuXHQvKipcblx0KiBTdG9wcyBvYnNlcnZpbmcgYWxsIHF1ZXJpZXM6IGNsZWFycyBhbGwgbGlzdGVuZXJzIGFuZCBkZXN0cm95cyBldmVyeVxuXHQqIHVuZGVybHlpbmcgYFF1ZXJ5T2JzZXJ2ZXJgIHRoaXMgb2JzZXJ2ZXIgbWFuYWdlcy5cblx0Ki9cblx0ZGVzdHJveSgpIHtcblx0XHR0aGlzLmxpc3RlbmVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0dGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG5cdFx0XHRvYnNlcnZlci5kZXN0cm95KCk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmVwbGFjZXMgdGhlIHNldCBvZiBxdWVyaWVzIGJlaW5nIG9ic2VydmVkLiBFeGlzdGluZyBgUXVlcnlPYnNlcnZlcmBzXG5cdCogYXJlIHJldXNlZCBmb3IgcXVlcmllcyB0aGF0IG1hdGNoIGFuIGFscmVhZHktb2JzZXJ2ZWQgcXVlcnkgaGFzaDtcblx0KiBvYnNlcnZlcnMgZm9yIHF1ZXJpZXMgdGhhdCBhcmUgbm8gbG9uZ2VyIHByZXNlbnQgYXJlIGRlc3Ryb3llZCwgYW5kIG5ld1xuXHQqIG9ic2VydmVycyBhcmUgY3JlYXRlZCBhbmQgc3Vic2NyaWJlZCB0byBmb3IgbmV3bHkgYWRkZWQgcXVlcmllcy5cblx0KiBAcGFyYW0gcXVlcmllcyAtIFRoZSBvcHRpb25zIG9mIHRoZSBxdWVyaWVzIHRvIG9ic2VydmUuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBSZXBsYWNlcyB0aGUgb2JzZXJ2ZXIncyBvcHRpb25zLCBlLmcuIGl0cyBgY29tYmluZWAgZnVuY3Rpb24uXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIG9ic2VydmVyLnNldFF1ZXJpZXMoW1xuXHQqICAgeyBxdWVyeUtleTogWydwb3N0JywgMV0sIHF1ZXJ5Rm46IGZldGNoUG9zdCB9LFxuXHQqICAgeyBxdWVyeUtleTogWydwb3N0JywgM10sIHF1ZXJ5Rm46IGZldGNoUG9zdCB9LFxuXHQqIF0pXG5cdCogYGBgXG5cdCovXG5cdHNldFF1ZXJpZXMocXVlcmllcywgb3B0aW9ucykge1xuXHRcdHRoaXMuI3F1ZXJpZXMgPSBxdWVyaWVzO1xuXHRcdHRoaXMuI29wdGlvbnMgPSBvcHRpb25zO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdGNvbnN0IHF1ZXJ5SGFzaGVzID0gcXVlcmllcy5tYXAoKHF1ZXJ5KSA9PiB0aGlzLiNjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhxdWVyeSkucXVlcnlIYXNoKTtcblx0XHRcdGlmIChuZXcgU2V0KHF1ZXJ5SGFzaGVzKS5zaXplICE9PSBxdWVyeUhhc2hlcy5sZW5ndGgpIGNvbnNvbGUud2FybihcIltRdWVyaWVzT2JzZXJ2ZXJdOiBEdXBsaWNhdGUgUXVlcmllcyBmb3VuZC4gVGhpcyBtaWdodCByZXN1bHQgaW4gdW5leHBlY3RlZCBiZWhhdmlvci5cIik7XG5cdFx0fVxuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0Y29uc3QgcHJldk9ic2VydmVycyA9IHRoaXMuI29ic2VydmVycztcblx0XHRcdGNvbnN0IG5ld09ic2VydmVyTWF0Y2hlcyA9IHRoaXMuI2ZpbmRNYXRjaGluZ09ic2VydmVycyh0aGlzLiNxdWVyaWVzKTtcblx0XHRcdG5ld09ic2VydmVyTWF0Y2hlcy5mb3JFYWNoKChtYXRjaCkgPT4gbWF0Y2gub2JzZXJ2ZXIuc2V0T3B0aW9ucyhtYXRjaC5kZWZhdWx0ZWRRdWVyeU9wdGlvbnMpKTtcblx0XHRcdGNvbnN0IG5ld09ic2VydmVycyA9IG5ld09ic2VydmVyTWF0Y2hlcy5tYXAoKG1hdGNoKSA9PiBtYXRjaC5vYnNlcnZlcik7XG5cdFx0XHRjb25zdCBuZXdSZXN1bHQgPSBuZXdPYnNlcnZlcnMubWFwKChvYnNlcnZlcikgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpKTtcblx0XHRcdGNvbnN0IGhhc0xlbmd0aENoYW5nZSA9IHByZXZPYnNlcnZlcnMubGVuZ3RoICE9PSBuZXdPYnNlcnZlcnMubGVuZ3RoO1xuXHRcdFx0Y29uc3QgaGFzSW5kZXhDaGFuZ2UgPSBuZXdPYnNlcnZlcnMuc29tZSgob2JzZXJ2ZXIsIGluZGV4KSA9PiBvYnNlcnZlciAhPT0gcHJldk9ic2VydmVyc1tpbmRleF0pO1xuXHRcdFx0Y29uc3QgaGFzU3RydWN0dXJhbENoYW5nZSA9IGhhc0xlbmd0aENoYW5nZSB8fCBoYXNJbmRleENoYW5nZTtcblx0XHRcdGNvbnN0IGhhc1Jlc3VsdENoYW5nZSA9IGhhc1N0cnVjdHVyYWxDaGFuZ2UgPyB0cnVlIDogbmV3UmVzdWx0LnNvbWUoKHJlc3VsdCwgaW5kZXgpID0+IHtcblx0XHRcdFx0Y29uc3QgcHJldiA9IHRoaXMuI3Jlc3VsdFtpbmRleF07XG5cdFx0XHRcdHJldHVybiAhcHJldiB8fCAhc2hhbGxvd0VxdWFsT2JqZWN0cyhyZXN1bHQsIHByZXYpO1xuXHRcdFx0fSk7XG5cdFx0XHRpZiAoIWhhc1N0cnVjdHVyYWxDaGFuZ2UgJiYgIWhhc1Jlc3VsdENoYW5nZSkgcmV0dXJuO1xuXHRcdFx0aWYgKGhhc1N0cnVjdHVyYWxDaGFuZ2UpIHtcblx0XHRcdFx0dGhpcy4jb2JzZXJ2ZXJNYXRjaGVzID0gbmV3T2JzZXJ2ZXJNYXRjaGVzO1xuXHRcdFx0XHR0aGlzLiNvYnNlcnZlcnMgPSBuZXdPYnNlcnZlcnM7XG5cdFx0XHR9XG5cdFx0XHR0aGlzLiNyZXN1bHQgPSBuZXdSZXN1bHQ7XG5cdFx0XHRpZiAoIXRoaXMuaGFzTGlzdGVuZXJzKCkpIHJldHVybjtcblx0XHRcdGlmIChoYXNTdHJ1Y3R1cmFsQ2hhbmdlKSB7XG5cdFx0XHRcdGRpZmZlcmVuY2UocHJldk9ic2VydmVycywgbmV3T2JzZXJ2ZXJzKS5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuXHRcdFx0XHRcdG9ic2VydmVyLmRlc3Ryb3koKTtcblx0XHRcdFx0fSk7XG5cdFx0XHRcdGRpZmZlcmVuY2UobmV3T2JzZXJ2ZXJzLCBwcmV2T2JzZXJ2ZXJzKS5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuXHRcdFx0XHRcdG9ic2VydmVyLnN1YnNjcmliZSgocmVzdWx0KSA9PiB7XG5cdFx0XHRcdFx0XHR0aGlzLiNvblVwZGF0ZShvYnNlcnZlciwgcmVzdWx0KTtcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0XHR0aGlzLiNub3RpZnkoKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBtb3N0IHJlY2VudGx5IGNvbXB1dGVkIGFycmF5IG9mIGBRdWVyeU9ic2VydmVyUmVzdWx0YHMsIG9uZVxuXHQqIHBlciBvYnNlcnZlZCBxdWVyeSwgaW4gdGhlIHNhbWUgb3JkZXIgYXMgdGhlIHF1ZXJpZXMgcGFzc2VkIHRvIHRoZVxuXHQqIGNvbnN0cnVjdG9yIG9yIGBzZXRRdWVyaWVzYC5cblx0KiBAcmV0dXJucyBUaGUgY3VycmVudCByZXN1bHRzLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCByZXN1bHRzID0gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpXG5cdCogY29uc3QgZGF0YSA9IHJlc3VsdHMubWFwKChyZXN1bHQpID0+IHJlc3VsdC5kYXRhKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRDdXJyZW50UmVzdWx0KCkge1xuXHRcdHJldHVybiB0aGlzLiNyZXN1bHQ7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgdW5kZXJseWluZyBgUXVlcnlgIGluc3RhbmNlcyBjdXJyZW50bHkgYmVpbmcgb2JzZXJ2ZWQsIGluXG5cdCogdGhlIHNhbWUgb3JkZXIgYXMgdGhlIHF1ZXJpZXMgcGFzc2VkIHRvIHRoZSBjb25zdHJ1Y3RvciBvciBgc2V0UXVlcmllc2AuXG5cdCogQHJldHVybnMgVGhlIG9ic2VydmVkIHF1ZXJpZXMuXG5cdCovXG5cdGdldFF1ZXJpZXMoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI29ic2VydmVycy5tYXAoKG9ic2VydmVyKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UXVlcnkoKSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgdW5kZXJseWluZyBgUXVlcnlPYnNlcnZlcmAgaW5zdGFuY2VzIHRoaXMgb2JzZXJ2ZXIgbWFuYWdlcyxcblx0KiBpbiB0aGUgc2FtZSBvcmRlciBhcyB0aGUgcXVlcmllcyBwYXNzZWQgdG8gdGhlIGNvbnN0cnVjdG9yIG9yXG5cdCogYHNldFF1ZXJpZXNgLlxuXHQqIEByZXR1cm5zIFRoZSBtYW5hZ2VkIHF1ZXJ5IG9ic2VydmVycy5cblx0Ki9cblx0Z2V0T2JzZXJ2ZXJzKCkge1xuXHRcdHJldHVybiB0aGlzLiNvYnNlcnZlcnM7XG5cdH1cblx0LyoqXG5cdCogVGhlIGBRdWVyaWVzT2JzZXJ2ZXJgIGNvdW50ZXJwYXJ0IG9mIHtAbGluayBRdWVyeU9ic2VydmVyI2dldE9wdGltaXN0aWNSZXN1bHR9IOKAlCBjb21wdXRlc1xuXHQqIHRoZSByZXN1bHQgZm9yIHRoZSBnaXZlbiAoYWxyZWFkeS1kZWZhdWx0ZWQpIHF1ZXJpZXMgcmlnaHQgbm93LCBzeW5jaHJvbm91c2x5LiBDYWxsZWQgYnlcblx0KiBmcmFtZXdvcmsgYWRhcHRlcnMgKGUuZy4gYHVzZVF1ZXJpZXNgKSBhaGVhZCBvZiBzdWJzY3JpYmluZywgcmV0dXJuaW5nIGEgdHVwbGUgb2YgdGhlIHJhd1xuXHQqIHBlci1xdWVyeSByZXN1bHRzLCBhIGZ1bmN0aW9uIHRvIGNvbXB1dGUgdGhlIGNvbWJpbmVkIHJlc3VsdCBmcm9tIHRoZW0sIGFuZCBhIGZ1bmN0aW9uIHRvXG5cdCogd3JhcCB0aGUgcmVzdWx0cyBmb3IgcHJvcGVydHktYWNjZXNzIHRyYWNraW5nLlxuXHQqIEBwYXJhbSBxdWVyaWVzIC0gVGhlIGRlZmF1bHRlZCBvcHRpb25zIG9mIHRoZSBxdWVyaWVzIHRvIGNvbXB1dGUgdGhlIHJlc3VsdCBmb3IuXG5cdCogQHBhcmFtIGNvbWJpbmUgLSBUaGUgYGNvbWJpbmVgIGZ1bmN0aW9uIHVzZWQgYnkgdGhlIHJldHVybmVkIGBjb21iaW5lUmVzdWx0YCwgaWYgYW55LlxuXHQqIEByZXR1cm5zIEEgdHVwbGUgb2YgdGhlIHBlci1xdWVyeSByZXN1bHRzLCBhIGZ1bmN0aW9uIHRoYXQgY29tcHV0ZXMgdGhlIGNvbWJpbmVkIHJlc3VsdCwgYW5kIGFcblx0KiBmdW5jdGlvbiB0aGF0IHJldHVybnMgdGhlIHJlc3VsdHMgd3JhcHBlZCBmb3IgcHJvcGVydHktYWNjZXNzIHRyYWNraW5nLlxuXHQqL1xuXHRnZXRPcHRpbWlzdGljUmVzdWx0KHF1ZXJpZXMsIGNvbWJpbmUpIHtcblx0XHRjb25zdCBtYXRjaGVzID0gdGhpcy4jZmluZE1hdGNoaW5nT2JzZXJ2ZXJzKHF1ZXJpZXMpO1xuXHRcdGNvbnN0IHJlc3VsdCA9IG1hdGNoZXMubWFwKChtYXRjaCkgPT4gbWF0Y2gub2JzZXJ2ZXIuZ2V0T3B0aW1pc3RpY1Jlc3VsdChtYXRjaC5kZWZhdWx0ZWRRdWVyeU9wdGlvbnMpKTtcblx0XHRjb25zdCBxdWVyeUhhc2hlcyA9IG1hdGNoZXMubWFwKChtYXRjaCkgPT4gbWF0Y2guZGVmYXVsdGVkUXVlcnlPcHRpb25zLnF1ZXJ5SGFzaCk7XG5cdFx0cmV0dXJuIFtcblx0XHRcdHJlc3VsdCxcblx0XHRcdChyKSA9PiB7XG5cdFx0XHRcdHJldHVybiB0aGlzLiNjb21iaW5lUmVzdWx0KHIgPz8gcmVzdWx0LCBjb21iaW5lLCBxdWVyeUhhc2hlcyk7XG5cdFx0XHR9LFxuXHRcdFx0KCkgPT4ge1xuXHRcdFx0XHRyZXR1cm4gdGhpcy4jdHJhY2tSZXN1bHQocmVzdWx0LCBtYXRjaGVzKTtcblx0XHRcdH1cblx0XHRdO1xuXHR9XG5cdCN0cmFja1Jlc3VsdChyZXN1bHQsIG1hdGNoZXMpIHtcblx0XHRjb25zdCB0cmFja2VkUHJvcHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHJldHVybiBtYXRjaGVzLm1hcCgobWF0Y2gsIGluZGV4KSA9PiB7XG5cdFx0XHRjb25zdCBvYnNlcnZlclJlc3VsdCA9IHJlc3VsdFtpbmRleF07XG5cdFx0XHRyZXR1cm4gIW1hdGNoLmRlZmF1bHRlZFF1ZXJ5T3B0aW9ucy5ub3RpZnlPbkNoYW5nZVByb3BzID8gbWF0Y2gub2JzZXJ2ZXIudHJhY2tSZXN1bHQob2JzZXJ2ZXJSZXN1bHQsIChhY2Nlc3NlZFByb3ApID0+IHtcblx0XHRcdFx0aWYgKCF0cmFja2VkUHJvcHMuaGFzKGFjY2Vzc2VkUHJvcCkpIHtcblx0XHRcdFx0XHR0cmFja2VkUHJvcHMuYWRkKGFjY2Vzc2VkUHJvcCk7XG5cdFx0XHRcdFx0bWF0Y2hlcy5mb3JFYWNoKChtKSA9PiB7XG5cdFx0XHRcdFx0XHRtLm9ic2VydmVyLnRyYWNrUHJvcChhY2Nlc3NlZFByb3ApO1xuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHR9XG5cdFx0XHR9KSA6IG9ic2VydmVyUmVzdWx0O1xuXHRcdH0pO1xuXHR9XG5cdCNjb21iaW5lUmVzdWx0KGlucHV0LCBjb21iaW5lLCBxdWVyeUhhc2hlcykge1xuXHRcdGlmIChjb21iaW5lKSB7XG5cdFx0XHRjb25zdCBsYXN0SGFzaGVzID0gdGhpcy4jbGFzdFF1ZXJ5SGFzaGVzO1xuXHRcdFx0Y29uc3QgcXVlcnlIYXNoZXNDaGFuZ2VkID0gcXVlcnlIYXNoZXMgIT09IHZvaWQgMCAmJiBsYXN0SGFzaGVzICE9PSB2b2lkIDAgJiYgKGxhc3RIYXNoZXMubGVuZ3RoICE9PSBxdWVyeUhhc2hlcy5sZW5ndGggfHwgcXVlcnlIYXNoZXMuc29tZSgoaGFzaCwgaSkgPT4gaGFzaCAhPT0gbGFzdEhhc2hlc1tpXSkpO1xuXHRcdFx0aWYgKHRoaXMuI3Jlc3VsdCAhPT0gdGhpcy4jbGFzdFJlc3VsdCB8fCBxdWVyeUhhc2hlc0NoYW5nZWQgfHwgY29tYmluZSAhPT0gdGhpcy4jbGFzdENvbWJpbmUpIHtcblx0XHRcdFx0dGhpcy4jbGFzdENvbWJpbmUgPSBjb21iaW5lO1xuXHRcdFx0XHR0aGlzLiNsYXN0UmVzdWx0ID0gdGhpcy4jcmVzdWx0O1xuXHRcdFx0XHRpZiAocXVlcnlIYXNoZXMgIT09IHZvaWQgMCkgdGhpcy4jbGFzdFF1ZXJ5SGFzaGVzID0gcXVlcnlIYXNoZXM7XG5cdFx0XHRcdHRoaXMuI2NvbWJpbmVkUmVzdWx0ID0gcmVwbGFjZUVxdWFsRGVlcCh0aGlzLiNjb21iaW5lZFJlc3VsdCwgY29tYmluZShpbnB1dCkpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHRoaXMuI2NvbWJpbmVkUmVzdWx0O1xuXHRcdH1cblx0XHRyZXR1cm4gaW5wdXQ7XG5cdH1cblx0I3Nob3VsZFNraXBDb21iaW5lKCkge1xuXHRcdHJldHVybiAhdGhpcy4jb3B0aW9ucz8uY29tYmluZSB8fCB0aGlzLiNvYnNlcnZlcnMuc29tZSgob2JzZXJ2ZXIsIGluZGV4KSA9PiB7XG5cdFx0XHRyZXR1cm4gb2JzZXJ2ZXIub3B0aW9ucy5zdXNwZW5zZSAmJiB0aGlzLiNyZXN1bHRbaW5kZXhdPy5kYXRhID09PSB2b2lkIDA7XG5cdFx0fSk7XG5cdH1cblx0I2ZpbmRNYXRjaGluZ09ic2VydmVycyhxdWVyaWVzKSB7XG5cdFx0Y29uc3QgcHJldk9ic2VydmVyc01hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0dGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG5cdFx0XHRjb25zdCBrZXkgPSBvYnNlcnZlci5vcHRpb25zLnF1ZXJ5SGFzaDtcblx0XHRcdGlmICgha2V5KSByZXR1cm47XG5cdFx0XHRjb25zdCBwcmV2aW91c09ic2VydmVycyA9IHByZXZPYnNlcnZlcnNNYXAuZ2V0KGtleSk7XG5cdFx0XHRpZiAocHJldmlvdXNPYnNlcnZlcnMpIHByZXZpb3VzT2JzZXJ2ZXJzLnB1c2gob2JzZXJ2ZXIpO1xuXHRcdFx0ZWxzZSBwcmV2T2JzZXJ2ZXJzTWFwLnNldChrZXksIFtvYnNlcnZlcl0pO1xuXHRcdH0pO1xuXHRcdGNvbnN0IG9ic2VydmVycyA9IFtdO1xuXHRcdHF1ZXJpZXMuZm9yRWFjaCgob3B0aW9ucykgPT4ge1xuXHRcdFx0Y29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHRoaXMuI2NsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdFx0Y29uc3Qgb2JzZXJ2ZXIgPSBwcmV2T2JzZXJ2ZXJzTWFwLmdldChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCk/LnNoaWZ0KCkgPz8gbmV3IFF1ZXJ5T2JzZXJ2ZXIodGhpcy4jY2xpZW50LCBkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRcdG9ic2VydmVycy5wdXNoKHtcblx0XHRcdFx0ZGVmYXVsdGVkUXVlcnlPcHRpb25zOiBkZWZhdWx0ZWRPcHRpb25zLFxuXHRcdFx0XHRvYnNlcnZlclxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdFx0cmV0dXJuIG9ic2VydmVycztcblx0fVxuXHQjb25VcGRhdGUob2JzZXJ2ZXIsIHJlc3VsdCkge1xuXHRcdGNvbnN0IGluZGV4ID0gdGhpcy4jb2JzZXJ2ZXJzLmluZGV4T2Yob2JzZXJ2ZXIpO1xuXHRcdGlmIChpbmRleCAhPT0gLTEpIHtcblx0XHRcdHRoaXMuI3Jlc3VsdCA9IHRoaXMuI3Jlc3VsdC5zbGljZSgpO1xuXHRcdFx0dGhpcy4jcmVzdWx0W2luZGV4XSA9IHJlc3VsdDtcblx0XHRcdHRoaXMuI25vdGlmeSgpO1xuXHRcdH1cblx0fVxuXHQjbm90aWZ5KCkge1xuXHRcdGlmICh0aGlzLmhhc0xpc3RlbmVycygpKSB7XG5cdFx0XHRjb25zdCBzaG91bGRTa2lwQ29tYmluZSA9IHRoaXMuI3Nob3VsZFNraXBDb21iaW5lKCk7XG5cdFx0XHRjb25zdCBwcmV2aW91c1Jlc3VsdCA9IHRoaXMuI2NvbWJpbmVkUmVzdWx0O1xuXHRcdFx0Y29uc3QgbmV3UmVzdWx0ID0gc2hvdWxkU2tpcENvbWJpbmUgPyBwcmV2aW91c1Jlc3VsdCA6IHRoaXMuI2NvbWJpbmVSZXN1bHQodGhpcy4jdHJhY2tSZXN1bHQodGhpcy4jcmVzdWx0LCB0aGlzLiNvYnNlcnZlck1hdGNoZXMpLCB0aGlzLiNvcHRpb25zPy5jb21iaW5lKTtcblx0XHRcdGlmIChzaG91bGRTa2lwQ29tYmluZSB8fCBwcmV2aW91c1Jlc3VsdCAhPT0gbmV3UmVzdWx0KSBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdFx0dGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcblx0XHRcdFx0XHRsaXN0ZW5lcih0aGlzLiNyZXN1bHQpO1xuXHRcdFx0XHR9KTtcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUXVlcmllc09ic2VydmVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJpZXNPYnNlcnZlci5qcy5tYXAiLCJpbXBvcnQgeyBoYXNoUXVlcnlLZXlCeU9wdGlvbnMsIG1hdGNoUXVlcnkgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgUXVlcnkgfSBmcm9tIFwiLi9xdWVyeS5qc1wiO1xuLy8jcmVnaW9uIHNyYy9xdWVyeUNhY2hlLnRzXG4vKipcbiogVGhlIGBRdWVyeUNhY2hlYCBpcyB0aGUgc3RvcmFnZSBtZWNoYW5pc20gZm9yIFRhblN0YWNrIFF1ZXJ5LiBJdCBzdG9yZXMgYWxsIHRoZSBkYXRhLCBtZXRhXG4qIGluZm9ybWF0aW9uLCBhbmQgc3RhdGUgb2YgdGhlIHF1ZXJpZXMgaXQgY29udGFpbnMuXG4qXG4qIE5vcm1hbGx5LCB5b3Ugd2lsbCBub3QgaW50ZXJhY3Qgd2l0aCB0aGUgYFF1ZXJ5Q2FjaGVgIGRpcmVjdGx5IGFuZCBpbnN0ZWFkIHVzZSBhIGBRdWVyeUNsaWVudGBcbiogZm9yIGEgc3BlY2lmaWMgY2FjaGUuIFlvdSBjYW4gc3Vic2NyaWJlIHRvIGl0IChpbmhlcml0ZWQgZnJvbSBgU3Vic2NyaWJhYmxlYCkgdG8gYmUgaW5mb3JtZWQgb2Zcbiogc2FmZS9rbm93biB1cGRhdGVzIHRvIHRoZSBjYWNoZSwgc3VjaCBhcyBxdWVyaWVzIGJlaW5nIGFkZGVkLCByZW1vdmVkLCBvciB1cGRhdGVkIOKAlCB1cGRhdGVzIG1hZGVcbiogb3V0c2lkZSBvZiB0aGUgY2FjaGUncyBvd24gdHJhY2tlZCBtZWNoYW5pc21zIChlLmcuIG11dGF0aW5nIGEgcXVlcnkncyBzdGF0ZSBvYmplY3QgZGlyZWN0bHkpIGRvXG4qIG5vdCBub3RpZnkgc3Vic2NyaWJlcnMuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHVuc3Vic2NyaWJlID0gcXVlcnlDYWNoZS5zdWJzY3JpYmUoKGV2ZW50KSA9PiB7XG4qICAgY29uc29sZS5sb2coZXZlbnQudHlwZSwgZXZlbnQucXVlcnkpXG4qIH0pXG4qIGBgYFxuKi9cbnZhciBRdWVyeUNhY2hlID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuXHQjcXVlcmllcztcblx0Y29uc3RydWN0b3IoY29uZmlnID0ge30pIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnO1xuXHRcdHRoaXMuI3F1ZXJpZXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIGV4aXN0aW5nIGBRdWVyeWAgaW5zdGFuY2UgZm9yIHRoZSBnaXZlbiBvcHRpb25zJyBgcXVlcnlLZXlgL2BxdWVyeUhhc2hgLCBvclxuXHQqIGJ1aWxkcyBhbmQgYWRkcyBhIG5ldyBvbmUgdG8gdGhlIGNhY2hlIGlmIG5vbmUgZXhpc3RzIHlldC4gVXNlZCBieSBmcmFtZXdvcmsgYWRhcHRlcnMgYW5kXG5cdCogcGx1Z2lucyAoZS5nLiBicm9hZGNhc3QvcGVyc2lzdGVuY2UpIHRoYXQgbmVlZCB0byBnZXQtb3ItY3JlYXRlIGEgYFF1ZXJ5YCBkaXJlY3RseSwgYnlwYXNzaW5nXG5cdCogdGhlIHJlYWN0aXZlIGBRdWVyeU9ic2VydmVyYCBtYWNoaW5lcnkuXG5cdCogQHBhcmFtIGNsaWVudCAtIFRoZSBjbGllbnQgdGhlIHF1ZXJ5IGJlbG9uZ3MgdG8sIHVzZWQgdG8gZGVmYXVsdCBpdHMgb3B0aW9ucy5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBxdWVyeSBvcHRpb25zLCBpbmNsdWRpbmcgdGhlIGBxdWVyeUtleWAuIEEgbmV3IHF1ZXJ5IGlzIGNyZWF0ZWQgd2l0aCB0aGVcblx0KiBvcHRpb25zIGRlZmF1bHRlZCBieSB7QGxpbmsgUXVlcnlDbGllbnQjZGVmYXVsdFF1ZXJ5T3B0aW9uc30uXG5cdCogQHBhcmFtIHN0YXRlIC0gVGhlIGluaXRpYWwgc3RhdGUgb2YgYSBuZXdseSBjcmVhdGVkIHF1ZXJ5LCBlLmcuIHdoZW4gaHlkcmF0aW5nLiBJZ25vcmVkIGlmIHRoZVxuXHQqIHF1ZXJ5IGFscmVhZHkgZXhpc3RzLlxuXHQqIEByZXR1cm5zIFRoZSBleGlzdGluZyBvciBuZXdseSBjcmVhdGVkIHF1ZXJ5LlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBxdWVyeUNhY2hlID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlDYWNoZSgpXG5cdCpcblx0KiBjb25zdCBxdWVyeSA9IHF1ZXJ5Q2FjaGUuYnVpbGQocXVlcnlDbGllbnQsIHtcblx0KiAgIHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sXG5cdCogICBxdWVyeUZuOiBmZXRjaFBvc3RzLFxuXHQqIH0pXG5cdCogYGBgXG5cdCovXG5cdGJ1aWxkKGNsaWVudCwgb3B0aW9ucywgc3RhdGUpIHtcblx0XHRjb25zdCBxdWVyeUtleSA9IG9wdGlvbnMucXVlcnlLZXk7XG5cdFx0Y29uc3QgcXVlcnlIYXNoID0gb3B0aW9ucy5xdWVyeUhhc2ggPz8gaGFzaFF1ZXJ5S2V5QnlPcHRpb25zKHF1ZXJ5S2V5LCBvcHRpb25zKTtcblx0XHRsZXQgcXVlcnkgPSB0aGlzLmdldChxdWVyeUhhc2gpO1xuXHRcdGlmICghcXVlcnkpIHtcblx0XHRcdHF1ZXJ5ID0gbmV3IFF1ZXJ5KHtcblx0XHRcdFx0Y2xpZW50LFxuXHRcdFx0XHRxdWVyeUtleSxcblx0XHRcdFx0cXVlcnlIYXNoLFxuXHRcdFx0XHRvcHRpb25zOiBjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKSxcblx0XHRcdFx0c3RhdGUsXG5cdFx0XHRcdGRlZmF1bHRPcHRpb25zOiBjbGllbnQuZ2V0UXVlcnlEZWZhdWx0cyhxdWVyeUtleSlcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy5hZGQocXVlcnkpO1xuXHRcdH1cblx0XHRyZXR1cm4gcXVlcnk7XG5cdH1cblx0LyoqXG5cdCogQWRkcyBhIHF1ZXJ5IHRvIHRoZSBjYWNoZS5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gcXVlcnkgLSBUaGUgcXVlcnkgdG8gYWRkLiBJZiBhIHF1ZXJ5IHdpdGggdGhlIHNhbWUgaGFzaCBpcyBhbHJlYWR5IGNhY2hlZCwgbm90aGluZ1xuXHQqIGhhcHBlbnMuXG5cdCovXG5cdGFkZChxdWVyeSkge1xuXHRcdGlmICghdGhpcy4jcXVlcmllcy5oYXMocXVlcnkucXVlcnlIYXNoKSkge1xuXHRcdFx0dGhpcy4jcXVlcmllcy5zZXQocXVlcnkucXVlcnlIYXNoLCBxdWVyeSk7XG5cdFx0XHR0aGlzLm5vdGlmeSh7XG5cdFx0XHRcdHR5cGU6IFwiYWRkZWRcIixcblx0XHRcdFx0cXVlcnlcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBEZXN0cm95cyB0aGUgZ2l2ZW4gYFF1ZXJ5YCBhbmQgcmVtb3ZlcyBpdCBmcm9tIHRoZSBjYWNoZSwgbm90aWZ5aW5nIHN1YnNjcmliZXJzIHdpdGggYVxuXHQqIGAncmVtb3ZlZCdgIGV2ZW50LiBBIG5vLW9wIGlmIHRoZSBxdWVyeSBpcyBubyBsb25nZXIgdGhlIG9uZSBjdXJyZW50bHkgc3RvcmVkIHVuZGVyIGl0cyBoYXNoXG5cdCogKGUuZy4gaXQgd2FzIGFscmVhZHkgcmVwbGFjZWQpLiBVc2VkIGJ5IHBsdWdpbnMgKGUuZy4gdGhlIGJyb2FkY2FzdCBjbGllbnQpIHRoYXQgbWlycm9yXG5cdCogcmVtb3ZhbHMgYWNyb3NzIGBRdWVyeUNhY2hlYCBpbnN0YW5jZXMuXG5cdCogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIHJlbW92ZS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuXHQqIGNvbnN0IHF1ZXJ5ID0gcXVlcnlDYWNoZS5maW5kKHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuXHQqXG5cdCogaWYgKHF1ZXJ5KSB7XG5cdCogICBxdWVyeUNhY2hlLnJlbW92ZShxdWVyeSlcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdHJlbW92ZShxdWVyeSkge1xuXHRcdGlmICh0aGlzLiNxdWVyaWVzLmdldChxdWVyeS5xdWVyeUhhc2gpID09PSBxdWVyeSkge1xuXHRcdFx0cXVlcnkuZGVzdHJveSgpO1xuXHRcdFx0dGhpcy4jcXVlcmllcy5kZWxldGUocXVlcnkucXVlcnlIYXNoKTtcblx0XHRcdHRoaXMubm90aWZ5KHtcblx0XHRcdFx0dHlwZTogXCJyZW1vdmVkXCIsXG5cdFx0XHRcdHF1ZXJ5XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogUmVtb3ZlcyBhbGwgcXVlcmllcyBmcm9tIHRoZSBjYWNoZS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuXHQqXG5cdCogcXVlcnlDYWNoZS5jbGVhcigpXG5cdCogYGBgXG5cdCovXG5cdGNsZWFyKCkge1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy5nZXRBbGwoKS5mb3JFYWNoKChxdWVyeSkgPT4ge1xuXHRcdFx0XHR0aGlzLnJlbW92ZShxdWVyeSk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBgUXVlcnlgIGluc3RhbmNlIHN0b3JlZCB1bmRlciB0aGUgZ2l2ZW4gYHF1ZXJ5SGFzaGAsIG9yIGB1bmRlZmluZWRgIGlmIG5vbmVcblx0KiBleGlzdHMuIFVubGlrZSB7QGxpbmsgUXVlcnlDYWNoZSNmaW5kfSwgdGhpcyBsb29rcyB1cCBieSB0aGUgYWxyZWFkeS1jb21wdXRlZCBoYXNoIHJhdGhlclxuXHQqIHRoYW4gYnkgYFF1ZXJ5RmlsdGVyc2AuIFVzZWQgYnkgcGx1Z2lucyAoZS5nLiBicm9hZGNhc3QvaHlkcmF0aW9uKSB0aGF0IGFscmVhZHkgaGF2ZSBhIGhhc2hcblx0KiB0byBsb29rIHVwIGRpcmVjdGx5LlxuXHQqIEBwYXJhbSBxdWVyeUhhc2ggLSBUaGUgaGFzaCBvZiB0aGUgcXVlcnkgdG8gbG9vayB1cC5cblx0KiBAcmV0dXJucyBUaGUgcXVlcnkgc3RvcmVkIHVuZGVyIHRoZSBoYXNoLCBvciBgdW5kZWZpbmVkYC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuXHQqIGNvbnN0IHF1ZXJ5SGFzaCA9IGhhc2hLZXkoWydwb3N0cyddKVxuXHQqXG5cdCogY29uc3QgcXVlcnkgPSBxdWVyeUNhY2hlLmdldChxdWVyeUhhc2gpXG5cdCogYGBgXG5cdCovXG5cdGdldChxdWVyeUhhc2gpIHtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcmllcy5nZXQocXVlcnlIYXNoKTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIGFsbCBxdWVyaWVzIHdpdGhpbiB0aGUgY2FjaGUuXG5cdCogQHJldHVybnMgRXZlcnkgcXVlcnkgaW4gdGhlIGNhY2hlLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBxdWVyeUNhY2hlID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlDYWNoZSgpXG5cdCpcblx0KiBjb25zdCBxdWVyaWVzID0gcXVlcnlDYWNoZS5nZXRBbGwoKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRBbGwoKSB7XG5cdFx0cmV0dXJuIFsuLi50aGlzLiNxdWVyaWVzLnZhbHVlcygpXTtcblx0fVxuXHQvKipcblx0KiBBIHNsaWdodGx5IG1vcmUgYWR2YW5jZWQgbWV0aG9kIHRoYXQgY2FuIGJlIHVzZWQgdG8gZ2V0IGFuIGV4aXN0aW5nIHF1ZXJ5IGluc3RhbmNlIGZyb20gdGhlXG5cdCogY2FjaGUuIFRoaXMgaW5zdGFuY2Ugbm90IG9ubHkgY29udGFpbnMgYWxsIHRoZSBzdGF0ZSBmb3IgdGhlIHF1ZXJ5LCBidXQgYWxsIG9mIHRoZSBpbnN0YW5jZXMsXG5cdCogYW5kIHVuZGVybHlpbmcgZ3V0cyBvZiB0aGUgcXVlcnkgYXMgd2VsbC4gSWYgdGhlIHF1ZXJ5IGRvZXMgbm90IGV4aXN0LCBgdW5kZWZpbmVkYCBpc1xuXHQqIHJldHVybmVkLlxuXHQqXG5cdCogVGhpcyBpcyBub3QgdHlwaWNhbGx5IG5lZWRlZCBmb3IgbW9zdCBhcHBsaWNhdGlvbnMsIGJ1dCBjYW4gY29tZSBpbiBoYW5keSB3aGVuIG5lZWRpbmcgbW9yZVxuXHQqIGluZm9ybWF0aW9uIGFib3V0IGEgcXVlcnkgaW4gcmFyZSBzY2VuYXJpb3MgKGUuZy4gbG9va2luZyBhdCBgcXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdGAgdG9cblx0KiBkZWNpZGUgd2hldGhlciBhIHF1ZXJ5IGlzIGZyZXNoIGVub3VnaCB0byBiZSB1c2VkIGFzIGFuIGluaXRpYWwgdmFsdWUpLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdG8gbWF0Y2gsIGluY2x1ZGluZyB0aGUgcmVxdWlyZWQgYHF1ZXJ5S2V5YC4gYGV4YWN0YCBkZWZhdWx0cyB0b1xuXHQqIGB0cnVlYC5cblx0KiBAcmV0dXJucyBUaGUgZmlyc3QgbWF0Y2hpbmcgcXVlcnksIG9yIGB1bmRlZmluZWRgLlxuXHQqIEBzZWUge0BsaW5rIFF1ZXJ5Q2FjaGUjZmluZEFsbH1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuXHQqXG5cdCogY29uc3QgcXVlcnkgPSBxdWVyeUNhY2hlLmZpbmQoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG5cdCogYGBgXG5cdCovXG5cdGZpbmQoZmlsdGVycykge1xuXHRcdGNvbnN0IGRlZmF1bHRlZEZpbHRlcnMgPSB7XG5cdFx0XHRleGFjdDogdHJ1ZSxcblx0XHRcdC4uLmZpbHRlcnNcblx0XHR9O1xuXHRcdHJldHVybiB0aGlzLmdldEFsbCgpLmZpbmQoKHF1ZXJ5KSA9PiBtYXRjaFF1ZXJ5KGRlZmF1bHRlZEZpbHRlcnMsIHF1ZXJ5KSk7XG5cdH1cblx0LyoqXG5cdCogQW4gZXZlbiBtb3JlIGFkdmFuY2VkIG1ldGhvZCB0aGF0IGNhbiBiZSB1c2VkIHRvIGdldCBleGlzdGluZyBxdWVyeSBpbnN0YW5jZXMgZnJvbSB0aGUgY2FjaGVcblx0KiB0aGF0IHBhcnRpYWxseSBtYXRjaCBhIHF1ZXJ5IGtleS4gSWYgbm8gcXVlcmllcyBtYXRjaCwgYW4gZW1wdHkgYXJyYXkgaXMgcmV0dXJuZWQuXG5cdCpcblx0KiBUaGlzIGlzIG5vdCB0eXBpY2FsbHkgbmVlZGVkIGZvciBtb3N0IGFwcGxpY2F0aW9ucywgYnV0IGNhbiBjb21lIGluIGhhbmR5IHdoZW4gbmVlZGluZyBtb3JlXG5cdCogaW5mb3JtYXRpb24gYWJvdXQgcXVlcmllcyBpbiByYXJlIHNjZW5hcmlvcy5cblx0KiBAcGFyYW0gZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRvIG1hdGNoLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5IHF1ZXJ5IGlzIHJldHVybmVkLlxuXHQqIEByZXR1cm5zIFRoZSBtYXRjaGluZyBxdWVyaWVzLlxuXHQqIEBzZWUge0BsaW5rIFF1ZXJ5Q2FjaGUjZmluZH1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuXHQqXG5cdCogY29uc3QgcXVlcmllcyA9IHF1ZXJ5Q2FjaGUuZmluZEFsbCh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcblx0KiBgYGBcblx0Ki9cblx0ZmluZEFsbChmaWx0ZXJzID0ge30pIHtcblx0XHRjb25zdCBxdWVyaWVzID0gdGhpcy5nZXRBbGwoKTtcblx0XHRyZXR1cm4gT2JqZWN0LmtleXMoZmlsdGVycykubGVuZ3RoID4gMCA/IHF1ZXJpZXMuZmlsdGVyKChxdWVyeSkgPT4gbWF0Y2hRdWVyeShmaWx0ZXJzLCBxdWVyeSkpIDogcXVlcmllcztcblx0fVxuXHQvKipcblx0KiBOb3RpZmllcyBldmVyeSBjYWNoZSBsaXN0ZW5lciBvZiBhbiBldmVudCwgaW4gb25lIGJhdGNoLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBldmVudCAtIFRoZSBldmVudCBwYXNzZWQgdG8gZXZlcnkgbGlzdGVuZXIuXG5cdCovXG5cdG5vdGlmeShldmVudCkge1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcblx0XHRcdFx0bGlzdGVuZXIoZXZlbnQpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogQ2FsbHMge0BsaW5rIFF1ZXJ5I29uRm9jdXN9IG9uIGV2ZXJ5IGNhY2hlZCBxdWVyeSwgaW4gb25lIGJhdGNoLlxuXHQqIEBpbnRlcm5hbFxuXHQqL1xuXHRvbkZvY3VzKCkge1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy5nZXRBbGwoKS5mb3JFYWNoKChxdWVyeSkgPT4ge1xuXHRcdFx0XHRxdWVyeS5vbkZvY3VzKCk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBDYWxscyB7QGxpbmsgUXVlcnkjb25PbmxpbmV9IG9uIGV2ZXJ5IGNhY2hlZCBxdWVyeSwgaW4gb25lIGJhdGNoLlxuXHQqIEBpbnRlcm5hbFxuXHQqL1xuXHRvbk9ubGluZSgpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMuZ2V0QWxsKCkuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnkub25PbmxpbmUoKTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBRdWVyeUNhY2hlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJ5Q2FjaGUuanMubWFwIiwiaW1wb3J0IHsgZnVuY3Rpb25hbFVwZGF0ZSwgaGFzaEtleSwgaGFzaFF1ZXJ5S2V5QnlPcHRpb25zLCBub29wLCBwYXJ0aWFsTWF0Y2hLZXksIHJlc29sdmVRdWVyeVZhbHVlLCBza2lwVG9rZW4gfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgZm9jdXNNYW5hZ2VyIH0gZnJvbSBcIi4vZm9jdXNNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgb25saW5lTWFuYWdlciB9IGZyb20gXCIuL29ubGluZU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IE11dGF0aW9uQ2FjaGUgfSBmcm9tIFwiLi9tdXRhdGlvbkNhY2hlLmpzXCI7XG5pbXBvcnQgeyBRdWVyeUNhY2hlIH0gZnJvbSBcIi4vcXVlcnlDYWNoZS5qc1wiO1xuLy8jcmVnaW9uIHNyYy9xdWVyeUNsaWVudC50c1xuLyoqXG4qIGBRdWVyeUNsaWVudGAgaXMgdXNlZCB0byBpbnRlcmFjdCB3aXRoIGEgY2FjaGUgb2YgcXVlcmllcyBhbmQgbXV0YXRpb25zLiBJdCBvd25zIGFcbiogYFF1ZXJ5Q2FjaGVgIGFuZCBhIGBNdXRhdGlvbkNhY2hlYCAoY3JlYXRpbmcgZGVmYXVsdCBvbmVzIGlmIG5vbmUgYXJlIHBhc3NlZCBpbikgYW5kIGhvbGRzXG4qIHRoZSBkZWZhdWx0IG9wdGlvbnMgdGhhdCBhcmUgYXBwbGllZCB0byBxdWVyaWVzIGFuZCBtdXRhdGlvbnMgY3JlYXRlZCB0aHJvdWdoIGl0LlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCh7XG4qICAgZGVmYXVsdE9wdGlvbnM6IHtcbiogICAgIHF1ZXJpZXM6IHtcbiogICAgICAgc3RhbGVUaW1lOiBJbmZpbml0eSxcbiogICAgIH0sXG4qICAgfSxcbiogfSlcbipcbiogYXdhaXQgcXVlcnlDbGllbnQucXVlcnkoeyBxdWVyeUtleTogWydwb3N0cyddLCBxdWVyeUZuOiBmZXRjaFBvc3RzIH0pXG4qIGBgYFxuKi9cbnZhciBRdWVyeUNsaWVudCA9IGNsYXNzIHtcblx0I3F1ZXJ5Q2FjaGU7XG5cdCNtdXRhdGlvbkNhY2hlO1xuXHQjZGVmYXVsdE9wdGlvbnM7XG5cdCNxdWVyeURlZmF1bHRzO1xuXHQjbXV0YXRpb25EZWZhdWx0cztcblx0I21vdW50Q291bnQ7XG5cdCN1bnN1YnNjcmliZUZvY3VzO1xuXHQjdW5zdWJzY3JpYmVPbmxpbmU7XG5cdGNvbnN0cnVjdG9yKGNvbmZpZyA9IHt9KSB7XG5cdFx0dGhpcy4jcXVlcnlDYWNoZSA9IGNvbmZpZy5xdWVyeUNhY2hlIHx8IG5ldyBRdWVyeUNhY2hlKCk7XG5cdFx0dGhpcy4jbXV0YXRpb25DYWNoZSA9IGNvbmZpZy5tdXRhdGlvbkNhY2hlIHx8IG5ldyBNdXRhdGlvbkNhY2hlKCk7XG5cdFx0dGhpcy4jZGVmYXVsdE9wdGlvbnMgPSBjb25maWcuZGVmYXVsdE9wdGlvbnMgfHwge307XG5cdFx0dGhpcy4jcXVlcnlEZWZhdWx0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0dGhpcy4jbXV0YXRpb25EZWZhdWx0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0dGhpcy4jbW91bnRDb3VudCA9IDA7XG5cdH1cblx0LyoqXG5cdCogQ2FsbGVkIGJ5IGEgZnJhbWV3b3JrIGFkYXB0ZXIncyBgUXVlcnlDbGllbnRQcm92aWRlcmAtZXF1aXZhbGVudCB3aGVuIGl0IG1vdW50cywgdG8gc3RhcnRcblx0KiBsaXN0ZW5pbmcgZm9yIGZvY3VzL29ubGluZSBldmVudHMgYW5kIHJlc3VtZSBwYXVzZWQgbXV0YXRpb25zLiBSZWYtY291bnRlZCB2aWEgYW4gaW50ZXJuYWxcblx0KiBtb3VudCBjb3VudCwgc28gbmVzdGVkIG9yIG11bHRpcGxlIHByb3ZpZGVycyBzaGFyaW5nIHRoZSBzYW1lIGBRdWVyeUNsaWVudGAgZG9uJ3QgdGVhciBkb3duXG5cdCogdGhlIHNoYXJlZCBsaXN0ZW5lcnMgdW50aWwgdGhlIGxhc3Qgb25lIHVubW91bnRzLlxuXHQqL1xuXHRtb3VudCgpIHtcblx0XHR0aGlzLiNtb3VudENvdW50Kys7XG5cdFx0aWYgKHRoaXMuI21vdW50Q291bnQgIT09IDEpIHJldHVybjtcblx0XHR0aGlzLiN1bnN1YnNjcmliZUZvY3VzID0gZm9jdXNNYW5hZ2VyLnN1YnNjcmliZShhc3luYyAoZm9jdXNlZCkgPT4ge1xuXHRcdFx0aWYgKGZvY3VzZWQpIHtcblx0XHRcdFx0YXdhaXQgdGhpcy5yZXN1bWVQYXVzZWRNdXRhdGlvbnMoKTtcblx0XHRcdFx0dGhpcy4jcXVlcnlDYWNoZS5vbkZvY3VzKCk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVPbmxpbmUgPSBvbmxpbmVNYW5hZ2VyLnN1YnNjcmliZShhc3luYyAob25saW5lKSA9PiB7XG5cdFx0XHRpZiAob25saW5lKSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMucmVzdW1lUGF1c2VkTXV0YXRpb25zKCk7XG5cdFx0XHRcdHRoaXMuI3F1ZXJ5Q2FjaGUub25PbmxpbmUoKTtcblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBUaGUgaW52ZXJzZSBvZiB7QGxpbmsgUXVlcnlDbGllbnQjbW91bnR9IOKAlCBjYWxsZWQgYnkgYSBmcmFtZXdvcmsgYWRhcHRlcidzXG5cdCogYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgLWVxdWl2YWxlbnQgd2hlbiBpdCB1bm1vdW50cy4gT25seSB0ZWFycyBkb3duIHRoZSBmb2N1cy9vbmxpbmVcblx0KiBsaXN0ZW5lcnMgb25jZSB0aGUgbW91bnQgY291bnQgcmV0dXJucyB0byBgMGAuXG5cdCovXG5cdHVubW91bnQoKSB7XG5cdFx0dGhpcy4jbW91bnRDb3VudC0tO1xuXHRcdGlmICh0aGlzLiNtb3VudENvdW50ICE9PSAwKSByZXR1cm47XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVGb2N1cz8uKCk7XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVGb2N1cyA9IHZvaWQgMDtcblx0XHR0aGlzLiN1bnN1YnNjcmliZU9ubGluZT8uKCk7XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVPbmxpbmUgPSB2b2lkIDA7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgbnVtYmVyIG9mIHF1ZXJpZXMgaW4gdGhlIGNhY2hlIHRoYXQgYXJlIGN1cnJlbnRseSBmZXRjaGluZywgb3B0aW9uYWxseVxuXHQqIG1hdGNoaW5nIGEgc2V0IG9mIGZpbHRlcnMuIFRoaXMgaW5jbHVkZXMgYmFja2dyb3VuZC1mZXRjaGluZywgbG9hZGluZyBuZXcgcGFnZXMsIGFuZFxuXHQqIGxvYWRpbmcgbW9yZSBpbmZpbml0ZSBxdWVyeSByZXN1bHRzLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gTmFycm93cyBkb3duIHdoaWNoIGZldGNoaW5nIHF1ZXJpZXMgYXJlIGNvdW50ZWQuIFdpdGhvdXQgZmlsdGVycywgZXZlcnlcblx0KiBmZXRjaGluZyBxdWVyeSBpcyBjb3VudGVkLlxuXHQqIEByZXR1cm5zIFRoZSBudW1iZXIgb2YgbWF0Y2hpbmcgcXVlcmllcyB3aG9zZSBgZmV0Y2hTdGF0dXNgIGlzIGAnZmV0Y2hpbmcnYC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaWYgKHF1ZXJ5Q2xpZW50LmlzRmV0Y2hpbmcoKSkge1xuXHQqICAgY29uc29sZS5sb2coJ0F0IGxlYXN0IG9uZSBxdWVyeSBpcyBmZXRjaGluZyEnKVxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0aXNGZXRjaGluZyhmaWx0ZXJzKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3F1ZXJ5Q2FjaGUuZmluZEFsbCh7XG5cdFx0XHQuLi5maWx0ZXJzLFxuXHRcdFx0ZmV0Y2hTdGF0dXM6IFwiZmV0Y2hpbmdcIlxuXHRcdH0pLmxlbmd0aDtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBudW1iZXIgb2YgbXV0YXRpb25zIGluIHRoZSBjYWNoZSB0aGF0IGFyZSBjdXJyZW50bHkgcGVuZGluZywgb3B0aW9uYWxseVxuXHQqIG1hdGNoaW5nIGEgc2V0IG9mIGZpbHRlcnMuXG5cdCogQHBhcmFtIGZpbHRlcnMgLSBOYXJyb3dzIGRvd24gd2hpY2ggcGVuZGluZyBtdXRhdGlvbnMgYXJlIGNvdW50ZWQuIFdpdGhvdXQgZmlsdGVycywgZXZlcnlcblx0KiBwZW5kaW5nIG11dGF0aW9uIGlzIGNvdW50ZWQuXG5cdCogQHJldHVybnMgVGhlIG51bWJlciBvZiBtYXRjaGluZyBtdXRhdGlvbnMgd2hvc2UgYHN0YXR1c2AgaXMgYCdwZW5kaW5nJ2AuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGlmIChxdWVyeUNsaWVudC5pc011dGF0aW5nKCkpIHtcblx0KiAgIGNvbnNvbGUubG9nKCdBdCBsZWFzdCBvbmUgbXV0YXRpb24gaXMgcGVuZGluZyEnKVxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0aXNNdXRhdGluZyhmaWx0ZXJzKSB7XG5cdFx0cmV0dXJuIHRoaXMuI211dGF0aW9uQ2FjaGUuZmluZEFsbCh7XG5cdFx0XHQuLi5maWx0ZXJzLFxuXHRcdFx0c3RhdHVzOiBcInBlbmRpbmdcIlxuXHRcdH0pLmxlbmd0aDtcblx0fVxuXHQvKipcblx0KiBJbXBlcmF0aXZlIChub24tcmVhY3RpdmUpIHdheSB0byByZXRyaWV2ZSBkYXRhIGZvciBhIFF1ZXJ5S2V5LlxuXHQqIFNob3VsZCBvbmx5IGJlIHVzZWQgaW4gY2FsbGJhY2tzIG9yIGZ1bmN0aW9ucyB3aGVyZSByZWFkaW5nIHRoZSBsYXRlc3QgZGF0YSBpcyBuZWNlc3NhcnksIGUuZy4gZm9yIG9wdGltaXN0aWMgdXBkYXRlcy5cblx0KlxuXHQqIEhpbnQ6IERvIG5vdCB1c2UgdGhpcyBmdW5jdGlvbiBpbnNpZGUgYSBjb21wb25lbnQsIGJlY2F1c2UgaXQgd29uJ3QgcmVjZWl2ZSB1cGRhdGVzLlxuXHQqIFVzZSBgdXNlUXVlcnlgIHRvIGNyZWF0ZSBhIGBRdWVyeU9ic2VydmVyYCB0aGF0IHN1YnNjcmliZXMgdG8gY2hhbmdlcy5cblx0KiBAcGFyYW0gcXVlcnlLZXkgLSBUaGUgcXVlcnkga2V5IG9mIHRoZSBxdWVyeSB0byByZWFkLlxuXHQqIEByZXR1cm5zIFRoZSBjYWNoZWQgZGF0YSBmb3IgdGhlIHF1ZXJ5LCBvciBgdW5kZWZpbmVkYCBpZiBubyBxdWVyeSB3aXRoIHRoaXMga2V5IGhhcyBiZWVuIG9ic2VydmVkIHlldC5cblx0KiBAc2VlIHtAbGluayBRdWVyeUNsaWVudCNnZXRRdWVyaWVzRGF0YX1cblx0Ki9cblx0Z2V0UXVlcnlEYXRhKHF1ZXJ5S2V5KSB7XG5cdFx0Y29uc3Qgb3B0aW9ucyA9IHRoaXMuZGVmYXVsdFF1ZXJ5T3B0aW9ucyh7IHF1ZXJ5S2V5IH0pO1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmdldChvcHRpb25zLnF1ZXJ5SGFzaCk/LnN0YXRlLmRhdGE7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgY2FjaGVkIGRhdGEgb2YgYSBxdWVyeSwgb3IgZmV0Y2hlcyBpdCBpZiB0aGVyZSBpcyBub25lLiBXaXRoIGByZXZhbGlkYXRlSWZTdGFsZWAsXG5cdCogc3RhbGUgY2FjaGVkIGRhdGEgaXMgYWxzbyByZWZldGNoZWQgaW4gdGhlIGJhY2tncm91bmQuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucy4gSWYgdGhlIHF1ZXJ5IGhhcyBubyBjYWNoZWQgZGF0YSB5ZXQsIGl0IGlzIGZldGNoZWQgd2l0aFxuXHQqIHRoZXNlIG9wdGlvbnMuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgdG8gdGhlIGNhY2hlZCBkYXRhLCBvciB0byB0aGUgZmV0Y2hlZCBkYXRhIGlmIG5vdGhpbmcgd2FzXG5cdCogY2FjaGVkIHlldC5cblx0KiBAZGVwcmVjYXRlZCBVc2UgcXVlcnlDbGllbnQucXVlcnkoeyAuLi5vcHRpb25zLCBzdGFsZVRpbWU6ICdzdGF0aWMnIH0pIGluc3RlYWQuIFRoaXMgbWV0aG9kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmV4dCBtYWpvciB2ZXJzaW9uLlxuXHQqL1xuXHRlbnN1cmVRdWVyeURhdGEob3B0aW9ucykge1xuXHRcdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSB0aGlzLmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyk7XG5cdFx0Y29uc3QgcXVlcnkgPSB0aGlzLiNxdWVyeUNhY2hlLmJ1aWxkKHRoaXMsIGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRcdGNvbnN0IGNhY2hlZERhdGEgPSBxdWVyeS5zdGF0ZS5kYXRhO1xuXHRcdGlmIChjYWNoZWREYXRhID09PSB2b2lkIDApIHJldHVybiB0aGlzLmZldGNoUXVlcnkob3B0aW9ucyk7XG5cdFx0aWYgKG9wdGlvbnMucmV2YWxpZGF0ZUlmU3RhbGUgJiYgcXVlcnkuaXNTdGFsZUJ5VGltZShyZXNvbHZlUXVlcnlWYWx1ZShkZWZhdWx0ZWRPcHRpb25zLnN0YWxlVGltZSwgcXVlcnkpKSkgdGhpcy5wcmVmZXRjaFF1ZXJ5KGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRcdHJldHVybiBQcm9taXNlLnJlc29sdmUoY2FjaGVkRGF0YSk7XG5cdH1cblx0LyoqXG5cdCogSW1wZXJhdGl2ZSAobm9uLXJlYWN0aXZlKSB3YXkgdG8gcmV0cmlldmUgdGhlIGNhY2hlZCBkYXRhIG9mIG11bHRpcGxlIHF1ZXJpZXMgYXQgb25jZS5cblx0KiBPbmx5IHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIGdpdmVuIGZpbHRlcnMgYXJlIHJldHVybmVkOyBpZiBub25lIG1hdGNoLCBhbiBlbXB0eSBhcnJheSBpc1xuXHQqIHJldHVybmVkLlxuXHQqXG5cdCogQmVjYXVzZSB0aGUgbWF0Y2hlZCBxdWVyaWVzIGNhbiBob2xkIGRhdGEgb2YgZGlmZmVyZW50IHNoYXBlcyAoZS5nLiBhIGJyb2FkIGZpbHRlciBjYW4gbWF0Y2hcblx0KiBxdWVyaWVzIHdpdGggdW5yZWxhdGVkIGRhdGEgdHlwZXMpLCB0aGUgYFRRdWVyeUZuRGF0YWAgZ2VuZXJpYyBkZWZhdWx0cyB0byBgdW5rbm93bmAgcmF0aGVyXG5cdCogdGhhbiBiZWluZyBpbmZlcnJlZC4gUGFzc2luZyBhIG1vcmUgc3BlY2lmaWMgdHlwZSBpcyBhIGNvbnZlbmllbmNlIGZvciBjYWxsIHNpdGVzIHRoYXQga25vd1xuXHQqIGV2ZXJ5IG1hdGNoZWQgcXVlcnkgaG9sZHMgdGhlIHNhbWUgc2hhcGUg4oCUIGl0IGlzIG5vdCBjaGVja2VkIGFnYWluc3QgdGhlIGFjdHVhbCBjYWNoZVxuXHQqIGNvbnRlbnRzLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdGhhdCBzZWxlY3Qgd2hpY2ggcXVlcmllcyB0byByZWFkLlxuXHQqIEByZXR1cm5zIEFuIGFycmF5IG9mIHF1ZXJ5IGtleSBhbmQgZGF0YSBwYWlycy4gVGhlIGRhdGEgaXMgYHVuZGVmaW5lZGAgZm9yIGEgcXVlcnkgd2l0aCBubyBjYWNoZWQgZGF0YS5cblx0KiBAc2VlIHtAbGluayBRdWVyeUNsaWVudCNnZXRRdWVyeURhdGF9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IGRhdGEgPSBxdWVyeUNsaWVudC5nZXRRdWVyaWVzRGF0YSh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcblx0KiBgYGBcblx0Ki9cblx0Z2V0UXVlcmllc0RhdGEoZmlsdGVycykge1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykubWFwKCh7IHF1ZXJ5S2V5LCBzdGF0ZSB9KSA9PiB7XG5cdFx0XHRyZXR1cm4gW3F1ZXJ5S2V5LCBzdGF0ZS5kYXRhXTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBTeW5jaHJvbm91cyB3YXkgdG8gaW1tZWRpYXRlbHkgdXBkYXRlIGEgcXVlcnkncyBjYWNoZWQgZGF0YS4gSWYgdGhlIHVwZGF0ZXIgKG9yIHRoZSB2YWx1ZVxuXHQqIHBhc3NlZCkgcmVzb2x2ZXMgdG8gYHVuZGVmaW5lZGAsIHRoZSBjYWNoZSBpcyBsZWZ0IHVudG91Y2hlZCBhbmQgbm8gcXVlcnkgaXMgY3JlYXRlZDtcblx0KiBvdGhlcndpc2UsIGlmIHRoZSBxdWVyeSBkb2VzIG5vdCBleGlzdCB5ZXQsIGl0IHdpbGwgYmUgY3JlYXRlZC4gVG8gdXBkYXRlIG11bHRpcGxlIHF1ZXJpZXNcblx0KiBhdCBvbmNlIGJ5IHBhcnRpYWxseSBtYXRjaGluZyBxdWVyeSBrZXlzLCB1c2Uge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldFF1ZXJpZXNEYXRhfSBpbnN0ZWFkLlxuXHQqXG5cdCogVXBkYXRlcyBtdXN0IGJlIHBlcmZvcm1lZCBpbW11dGFibHk6IGRvIG5vdCBtdXRhdGUgYG9sZERhdGFgLCBvciBkYXRhIHByZXZpb3VzbHkgcmV0cmlldmVkXG5cdCogdmlhIHtAbGluayBRdWVyeUNsaWVudCNnZXRRdWVyeURhdGF9LCBpbiBwbGFjZS5cblx0KiBAcGFyYW0gcXVlcnlLZXkgLSBUaGUgcXVlcnkga2V5IHRvIHNldCBkYXRhIGZvci5cblx0KiBAcGFyYW0gdXBkYXRlciAtIEVpdGhlciB0aGUgbmV3IGRhdGEsIG9yIGEgZnVuY3Rpb24gdGhhdCByZWNlaXZlcyB0aGUgY3VycmVudCBkYXRhICh3aGljaFxuXHQqIG1heSBiZSBgdW5kZWZpbmVkYCkgYW5kIHJldHVybnMgdGhlIG5ldyBkYXRhLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gU2V0IGB1cGRhdGVkQXRgIHRvIG92ZXJyaWRlIHRoZSB0aW1lc3RhbXAgdGhlIHdyaXR0ZW4gZGF0YSBpcyByZWNvcmRlZCB3aXRoLlxuXHQqIEByZXR1cm5zIFRoZSBkYXRhIHRoYXQgd2FzIHdyaXR0ZW4sIG9yIGB1bmRlZmluZWRgIGlmIHRoZSB1cGRhdGVyIHJldHVybmVkIGB1bmRlZmluZWRgIOKAlCBpbiB0aGF0IGNhc2Vcblx0KiB0aGUgd3JpdGUgaXMgc2tpcHBlZCBhbmQgdGhlIGNhY2hlIGlzIGxlZnQgdW5jaGFuZ2VkLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEoWydwb3N0cyddLCBuZXdQb3N0cylcblx0KlxuXHQqIC8vIE9yLCB1c2luZyBhbiB1cGRhdGVyIGZ1bmN0aW9uIHRoYXQgcmVjZWl2ZXMgdGhlIGN1cnJlbnQgZGF0YTpcblx0KiBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEoWydwb3N0cyddLCAob2xkUG9zdHMpID0+IFsuLi5vbGRQb3N0cywgbmV3UG9zdF0pXG5cdCogYGBgXG5cdCovXG5cdHNldFF1ZXJ5RGF0YShxdWVyeUtleSwgdXBkYXRlciwgb3B0aW9ucykge1xuXHRcdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSB0aGlzLmRlZmF1bHRRdWVyeU9wdGlvbnMoeyBxdWVyeUtleSB9KTtcblx0XHRjb25zdCBwcmV2RGF0YSA9IHRoaXMuI3F1ZXJ5Q2FjaGUuZ2V0KGRlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNoKT8uc3RhdGUuZGF0YTtcblx0XHRjb25zdCBkYXRhID0gZnVuY3Rpb25hbFVwZGF0ZSh1cGRhdGVyLCBwcmV2RGF0YSk7XG5cdFx0aWYgKGRhdGEgPT09IHZvaWQgMCkgcmV0dXJuO1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmJ1aWxkKHRoaXMsIGRlZmF1bHRlZE9wdGlvbnMpLnNldERhdGEoZGF0YSwge1xuXHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdG1hbnVhbDogdHJ1ZVxuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFN5bmNocm9ub3VzIHdheSB0byBpbW1lZGlhdGVseSB1cGRhdGUgdGhlIGNhY2hlZCBkYXRhIG9mIG11bHRpcGxlIHF1ZXJpZXMgYXQgb25jZSwgdXNpbmdcblx0KiBmaWx0ZXJzIG9yIHBhcnRpYWwgcXVlcnkga2V5IG1hdGNoaW5nLiBPbmx5IHF1ZXJpZXMgdGhhdCBhbHJlYWR5IGV4aXN0IGFuZCBtYXRjaCB0aGUgZ2l2ZW5cblx0KiBmaWx0ZXJzIGFyZSB1cGRhdGVkOyBubyBuZXcgY2FjaGUgZW50cmllcyBhcmUgY3JlYXRlZC4gSW50ZXJuYWxseSB0aGlzIGNhbGxzXG5cdCoge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldFF1ZXJ5RGF0YX0gZm9yIGVhY2ggbWF0Y2hpbmcgcXVlcnkuXG5cdCogQHBhcmFtIGZpbHRlcnMgLSBUaGUgZmlsdGVycyB0aGF0IHNlbGVjdCB3aGljaCBleGlzdGluZyBxdWVyaWVzIHRvIHVwZGF0ZS5cblx0KiBAcGFyYW0gdXBkYXRlciAtIEVpdGhlciB0aGUgbmV3IGRhdGEsIG9yIGEgZnVuY3Rpb24gdGhhdCByZWNlaXZlcyBlYWNoIG1hdGNoZWQgcXVlcnkncyBjdXJyZW50XG5cdCogZGF0YSAod2hpY2ggbWF5IGJlIGB1bmRlZmluZWRgKSBhbmQgcmV0dXJucyB0aGUgbmV3IGRhdGEuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBTZXQgYHVwZGF0ZWRBdGAgdG8gb3ZlcnJpZGUgdGhlIHRpbWVzdGFtcCB0aGUgd3JpdHRlbiBkYXRhIGlzIHJlY29yZGVkIHdpdGguXG5cdCogQHJldHVybnMgT25lIGBbcXVlcnlLZXksIGRhdGFdYCB0dXBsZSBwZXIgbWF0Y2hlZCBxdWVyeSwgaW4gdGhlIHNhbWUgc2hhcGUgYW5kIHdpdGggdGhlIHNhbWVcblx0KiBgdW5kZWZpbmVkYCBjYXNlIGFzIHtAbGluayBRdWVyeUNsaWVudCNzZXRRdWVyeURhdGF9LlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBxdWVyeUNsaWVudC5zZXRRdWVyaWVzRGF0YSh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSwgKG9sZFBvc3RzKSA9PlxuXHQqICAgb2xkUG9zdHMgPyBvbGRQb3N0cy5maWx0ZXIoKHBvc3QpID0+IHBvc3QuaWQgIT09IGRlbGV0ZWRJZCkgOiBvbGRQb3N0cyxcblx0KiApXG5cdCogYGBgXG5cdCovXG5cdHNldFF1ZXJpZXNEYXRhKGZpbHRlcnMsIHVwZGF0ZXIsIG9wdGlvbnMpIHtcblx0XHRyZXR1cm4gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykubWFwKCh7IHF1ZXJ5S2V5IH0pID0+IFtxdWVyeUtleSwgdGhpcy5zZXRRdWVyeURhdGEocXVlcnlLZXksIHVwZGF0ZXIsIG9wdGlvbnMpXSkpO1xuXHR9XG5cdC8qKlxuXHQqIEltcGVyYXRpdmUgKG5vbi1yZWFjdGl2ZSkgd2F5IHRvIHJldHJpZXZlIGFuIGV4aXN0aW5nIHF1ZXJ5J3Mgc3RhdGUuIElmIHRoZSBxdWVyeSBkb2VzIG5vdFxuXHQqIGV4aXN0LCBgdW5kZWZpbmVkYCBpcyByZXR1cm5lZC5cblx0KiBAcGFyYW0gcXVlcnlLZXkgLSBUaGUgcXVlcnkga2V5IG9mIHRoZSBxdWVyeSB0byByZWFkLlxuXHQqIEByZXR1cm5zIFRoZSBxdWVyeSdzIHN0YXRlLCBvciBgdW5kZWZpbmVkYCBpZiBubyBxdWVyeSB3aXRoIHRoaXMga2V5IGV4aXN0cy5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3Qgc3RhdGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeVN0YXRlKFsncG9zdHMnXSlcblx0KiBjb25zb2xlLmxvZyhzdGF0ZT8uZGF0YVVwZGF0ZWRBdClcblx0KiBgYGBcblx0Ki9cblx0Z2V0UXVlcnlTdGF0ZShxdWVyeUtleSkge1xuXHRcdGNvbnN0IG9wdGlvbnMgPSB0aGlzLmRlZmF1bHRRdWVyeU9wdGlvbnMoeyBxdWVyeUtleSB9KTtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5nZXQob3B0aW9ucy5xdWVyeUhhc2gpPy5zdGF0ZTtcblx0fVxuXHQvKipcblx0KiBSZW1vdmVzIHF1ZXJpZXMgZnJvbSB0aGUgY2FjaGUgdGhhdCBtYXRjaCB0aGUgZ2l2ZW4gZmlsdGVycy4gVW5saWtlXG5cdCoge0BsaW5rIFF1ZXJ5Q2xpZW50I2ludmFsaWRhdGVRdWVyaWVzfSBvciB7QGxpbmsgUXVlcnlDbGllbnQjcmVmZXRjaFF1ZXJpZXN9LCB0aGlzIHJlbW92ZXNcblx0KiBtYXRjaGluZyBxdWVyaWVzIGZyb20gdGhlIGNhY2hlIGluc3RlYWQgb2YgcmVmZXRjaGluZyB0aGVtLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5IHF1ZXJ5IGluXG5cdCogdGhlIGNhY2hlIGlzIHJlbW92ZWQuXG5cdCogQHBhcmFtIGZpbHRlcnMgLSBUaGUgZmlsdGVycyB0aGF0IHNlbGVjdCB3aGljaCBxdWVyaWVzIHRvIHJlbW92ZS4gV2l0aG91dCBmaWx0ZXJzLCBldmVyeSBxdWVyeVxuXHQqIGlzIHJlbW92ZWQuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIHF1ZXJ5Q2xpZW50LnJlbW92ZVF1ZXJpZXMoeyBxdWVyeUtleTogWydwb3N0cyddLCBleGFjdDogdHJ1ZSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRyZW1vdmVRdWVyaWVzKGZpbHRlcnMpIHtcblx0XHRjb25zdCBxdWVyeUNhY2hlID0gdGhpcy4jcXVlcnlDYWNoZTtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHF1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKS5mb3JFYWNoKChxdWVyeSkgPT4ge1xuXHRcdFx0XHRxdWVyeUNhY2hlLnJlbW92ZShxdWVyeSk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXNldHMgcXVlcmllcyBtYXRjaGluZyB0aGUgZ2l2ZW4gZmlsdGVycyBiYWNrIHRvIHRoZWlyIGluaXRpYWwgc3RhdGUgKGUuZy4gYW55XG5cdCogYGluaXRpYWxEYXRhYCksIG5vdGlmeWluZyBzdWJzY3JpYmVycyByYXRoZXIgdGhhbiByZW1vdmluZyB0aGVtLiBBY3RpdmUgcXVlcmllcyBhbW9uZyB0aGVcblx0KiBtYXRjaGVkIHNldCBhcmUgdGhlbiByZWZldGNoZWQsIGFuZCB0aGUgcmV0dXJuZWQgcHJvbWlzZSByZXNvbHZlcyBvbmNlIHRoYXQgcmVmZXRjaCBzZXR0bGVzLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdGhhdCBzZWxlY3Qgd2hpY2ggcXVlcmllcyB0byByZXNldC4gV2l0aG91dCBmaWx0ZXJzLCBldmVyeSBxdWVyeVxuXHQqIGlzIHJlc2V0LlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gUGFzc2VkIHRvIHRoZSByZWZldGNoIG9mIHRoZSBhY3RpdmUgbWF0Y2hlZCBxdWVyaWVzLCBlLmcuIGBjYW5jZWxSZWZldGNoYCBhbmRcblx0KiBgdGhyb3dPbkVycm9yYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIHRoZSByZWZldGNoIG9mIHRoZSBhY3RpdmUgbWF0Y2hlZCBxdWVyaWVzIHNldHRsZXMuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGF3YWl0IHF1ZXJ5Q2xpZW50LnJlc2V0UXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sIGV4YWN0OiB0cnVlIH0pXG5cdCogYGBgXG5cdCovXG5cdHJlc2V0UXVlcmllcyhmaWx0ZXJzLCBvcHRpb25zKSB7XG5cdFx0Y29uc3QgcXVlcnlDYWNoZSA9IHRoaXMuI3F1ZXJ5Q2FjaGU7XG5cdFx0cmV0dXJuIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0Y29uc3QgbWF0Y2hlZCA9IHF1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKTtcblx0XHRcdGNvbnN0IHF1ZXJpZXNUb1JlZmV0Y2ggPSBuZXcgU2V0KG1hdGNoZWQpO1xuXHRcdFx0bWF0Y2hlZC5mb3JFYWNoKChxdWVyeSkgPT4ge1xuXHRcdFx0XHRxdWVyeS5yZXNldCgpO1xuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gdGhpcy5yZWZldGNoUXVlcmllcyh7XG5cdFx0XHRcdHR5cGU6IFwiYWN0aXZlXCIsXG5cdFx0XHRcdHByZWRpY2F0ZTogKHF1ZXJ5KSA9PiBxdWVyaWVzVG9SZWZldGNoLmhhcyhxdWVyeSlcblx0XHRcdH0sIG9wdGlvbnMpO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIENhbmNlbHMgb3V0Z29pbmcgZmV0Y2hlcyBmb3IgcXVlcmllcyBtYXRjaGluZyB0aGUgZ2l2ZW4gZmlsdGVycy4gTW9zdCB1c2VmdWwgd2hlbiBwZXJmb3JtaW5nXG5cdCogb3B0aW1pc3RpYyB1cGRhdGVzLCBzaW5jZSBhbnkgb3V0Z29pbmcgcmVmZXRjaCB0aGF0IHJlc29sdmVzIGFmdGVyd2FyZHMgd291bGQgb3RoZXJ3aXNlXG5cdCogb3ZlcndyaXRlIHRoZSBvcHRpbWlzdGljIHVwZGF0ZS4gQnkgZGVmYXVsdCAoYHJldmVydDogdHJ1ZWApLCBhIGNhbmNlbGxlZCBxdWVyeSdzIGRhdGEgaXNcblx0KiByZXZlcnRlZCB0byBpdHMgc3RhdGUgYmVmb3JlIHRoZSBvdXRnb2luZyBmZXRjaCBzdGFydGVkLlxuXHQqXG5cdCogVGhlIHJldHVybmVkIHByb21pc2UgbmV2ZXIgcmVqZWN0cywgZXZlbiBpZiBpbmRpdmlkdWFsIGNhbmNlbGxhdGlvbnMgZmFpbC5cblx0KiBAcGFyYW0gZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRoYXQgc2VsZWN0IHdoaWNoIHF1ZXJpZXMgdG8gY2FuY2VsLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5IHF1ZXJ5XG5cdCogaXMgY2FuY2VsbGVkLlxuXHQqIEBwYXJhbSBjYW5jZWxPcHRpb25zIC0gUGFzc2VkIHRvIGVhY2ggbWF0Y2hlZCBxdWVyeSdzIGNhbmNlbGxhdGlvbi4gYHJldmVydGAgZGVmYXVsdHMgdG9cblx0KiBgdHJ1ZWAuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSBldmVyeSBjYW5jZWxsYXRpb24gaGFzIHNldHRsZWQuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGF3YWl0IHF1ZXJ5Q2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleTogWydwb3N0cyddLCBleGFjdDogdHJ1ZSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRjYW5jZWxRdWVyaWVzKGZpbHRlcnMsIGNhbmNlbE9wdGlvbnMgPSB7fSkge1xuXHRcdGNvbnN0IGRlZmF1bHRlZENhbmNlbE9wdGlvbnMgPSB7XG5cdFx0XHRyZXZlcnQ6IHRydWUsXG5cdFx0XHQuLi5jYW5jZWxPcHRpb25zXG5cdFx0fTtcblx0XHRjb25zdCBwcm9taXNlcyA9IG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4gdGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLm1hcCgocXVlcnkpID0+IHF1ZXJ5LmNhbmNlbChkZWZhdWx0ZWRDYW5jZWxPcHRpb25zKSkpO1xuXHRcdHJldHVybiBQcm9taXNlLmFsbChwcm9taXNlcykudGhlbihub29wKS5jYXRjaChub29wKTtcblx0fVxuXHQvKipcblx0KiBNYXJrcyBxdWVyaWVzIG1hdGNoaW5nIHRoZSBnaXZlbiBmaWx0ZXJzIGFzIGludmFsaWRhdGVkLiBVbmxpa2Vcblx0KiB7QGxpbmsgUXVlcnlDbGllbnQjcmVtb3ZlUXVlcmllc30sIGludmFsaWRhdGVkIHF1ZXJpZXMgc3RheSBpbiB0aGUgY2FjaGUuXG5cdCpcblx0KiBVbmxlc3MgYGZpbHRlcnMucmVmZXRjaFR5cGVgIGlzIGAnbm9uZSdgLCBtYXRjaGluZyBxdWVyaWVzIGFyZSB0aGVuIHJlZmV0Y2hlZCB2aWFcblx0KiB7QGxpbmsgUXVlcnlDbGllbnQjcmVmZXRjaFF1ZXJpZXN9LCB1c2luZyBgZmlsdGVycy5yZWZldGNoVHlwZWAgaWYgc2V0LCBvdGhlcndpc2Vcblx0KiBgZmlsdGVycy50eXBlYCwgb3RoZXJ3aXNlIGAnYWN0aXZlJ2AuXG5cdCogQHBhcmFtIGZpbHRlcnMgLSBUaGUgZmlsdGVycyB0aGF0IHNlbGVjdCB3aGljaCBxdWVyaWVzIHRvIGludmFsaWRhdGUsIHBsdXMgYHJlZmV0Y2hUeXBlYCB0b1xuXHQqIGNvbnRyb2wgd2hpY2ggb2YgdGhlbSB0byByZWZldGNoIGFmdGVyd2FyZHMuIFdpdGhvdXQgZmlsdGVycywgZXZlcnkgcXVlcnkgaXMgaW52YWxpZGF0ZWQuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBQYXNzZWQgdG8ge0BsaW5rIFF1ZXJ5Q2xpZW50I3JlZmV0Y2hRdWVyaWVzfSwgZS5nLiBgY2FuY2VsUmVmZXRjaGAgYW5kXG5cdCogYHRocm93T25FcnJvcmAuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgcmVmZXRjaCBzZXR0bGVzLCBvciBpbW1lZGlhdGVseSBpZiBgcmVmZXRjaFR5cGVgIGlzXG5cdCogYCdub25lJ2AuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGF3YWl0IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsncG9zdHMnXSwgcmVmZXRjaFR5cGU6ICdhY3RpdmUnIH0pXG5cdCogYGBgXG5cdCovXG5cdGludmFsaWRhdGVRdWVyaWVzKGZpbHRlcnMsIG9wdGlvbnMgPSB7fSkge1xuXHRcdHJldHVybiBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMuI3F1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKS5mb3JFYWNoKChxdWVyeSkgPT4ge1xuXHRcdFx0XHRxdWVyeS5pbnZhbGlkYXRlKCk7XG5cdFx0XHR9KTtcblx0XHRcdGlmIChmaWx0ZXJzPy5yZWZldGNoVHlwZSA9PT0gXCJub25lXCIpIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcblx0XHRcdHJldHVybiB0aGlzLnJlZmV0Y2hRdWVyaWVzKHtcblx0XHRcdFx0Li4uZmlsdGVycyxcblx0XHRcdFx0dHlwZTogZmlsdGVycz8ucmVmZXRjaFR5cGUgPz8gZmlsdGVycz8udHlwZSA/PyBcImFjdGl2ZVwiXG5cdFx0XHR9LCBvcHRpb25zKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZWZldGNoZXMgcXVlcmllcyBtYXRjaGluZyB0aGUgZ2l2ZW4gZmlsdGVycywgcmVnYXJkbGVzcyBvZiB3aGV0aGVyIHRoZXkgYXJlIHN0YWxlLiBXaXRob3V0XG5cdCogZmlsdGVycywgZXZlcnkgcXVlcnkgaW4gdGhlIGNhY2hlIGlzIHJlZmV0Y2hlZC4gUXVlcmllcyB0aGF0IGFyZSBkaXNhYmxlZCwgb3Igc3RhdGljIChvbmx5XG5cdCogaGF2ZSBvYnNlcnZlcnMgd2l0aCBhIHN0YXRpYyBgc3RhbGVUaW1lYCksIGFyZSBuZXZlciByZWZldGNoZWQuXG5cdCpcblx0KiBCeSBkZWZhdWx0IChgY2FuY2VsUmVmZXRjaDogdHJ1ZWApLCBhIGN1cnJlbnRseSBydW5uaW5nIGZldGNoIGlzIGNhbmNlbGxlZCBiZWZvcmUgdGhlIG5ld1xuXHQqIG9uZSBzdGFydHMuIFRoZSByZXR1cm5lZCBwcm9taXNlIHJlc29sdmVzIG9uY2UgYWxsIG1hdGNoaW5nIHF1ZXJpZXMgaGF2ZSBzZXR0bGVkOyBpdCBkb2VzXG5cdCogbm90IHJlamVjdCBvbiBpbmRpdmlkdWFsIHF1ZXJ5IGZhaWx1cmVzIHVubGVzcyBgdGhyb3dPbkVycm9yYCBpcyBzZXQuXG5cdCogQHBhcmFtIGZpbHRlcnMgLSBUaGUgZmlsdGVycyB0aGF0IHNlbGVjdCB3aGljaCBxdWVyaWVzIHRvIHJlZmV0Y2guIFdpdGhvdXQgZmlsdGVycywgZXZlcnkgcXVlcnlcblx0KiBpbiB0aGUgY2FjaGUgaXMgaW5jbHVkZWQuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBTZXQgYGNhbmNlbFJlZmV0Y2hgIHRvIGBmYWxzZWAgdG8ga2VlcCBhIHJ1bm5pbmcgZmV0Y2ggaW5zdGVhZCBvZiBjYW5jZWxsaW5nXG5cdCogaXQsIGFuZCBgdGhyb3dPbkVycm9yYCB0byBgdHJ1ZWAgdG8gcmVqZWN0IHdoZW4gYSByZWZldGNoIGZhaWxzLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIG9uY2UgZXZlcnkgbWF0Y2hlZCBxdWVyeSBoYXMgc2V0dGxlZC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogLy8gcmVmZXRjaCBhbGwgYWN0aXZlIHF1ZXJpZXMgcGFydGlhbGx5IG1hdGNoaW5nIGEgcXVlcnkga2V5OlxuXHQqIGF3YWl0IHF1ZXJ5Q2xpZW50LnJlZmV0Y2hRdWVyaWVzKHsgcXVlcnlLZXk6IFsncG9zdHMnXSwgdHlwZTogJ2FjdGl2ZScgfSlcblx0KiBgYGBcblx0Ki9cblx0cmVmZXRjaFF1ZXJpZXMoZmlsdGVycywgb3B0aW9ucyA9IHt9KSB7XG5cdFx0Y29uc3QgZmV0Y2hPcHRpb25zID0ge1xuXHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdGNhbmNlbFJlZmV0Y2g6IG9wdGlvbnMuY2FuY2VsUmVmZXRjaCA/PyB0cnVlXG5cdFx0fTtcblx0XHRjb25zdCBwcm9taXNlcyA9IG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4gdGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLmZpbHRlcigocXVlcnkpID0+ICFxdWVyeS5pc0Rpc2FibGVkKCkgJiYgIXF1ZXJ5LmlzU3RhdGljKCkpLm1hcCgocXVlcnkpID0+IHtcblx0XHRcdGxldCBwcm9taXNlID0gcXVlcnkuZmV0Y2godm9pZCAwLCBmZXRjaE9wdGlvbnMpO1xuXHRcdFx0aWYgKCFmZXRjaE9wdGlvbnMudGhyb3dPbkVycm9yKSBwcm9taXNlID0gcHJvbWlzZS5jYXRjaChub29wKTtcblx0XHRcdHJldHVybiBxdWVyeS5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJwYXVzZWRcIiA/IFByb21pc2UucmVzb2x2ZSgpIDogcHJvbWlzZTtcblx0XHR9KSk7XG5cdFx0cmV0dXJuIFByb21pc2UuYWxsKHByb21pc2VzKS50aGVuKG5vb3ApO1xuXHR9XG5cdC8qKlxuXHQqIEFzeW5jaHJvbm91cyBtZXRob2QgdG8gZmV0Y2ggYW5kIGNhY2hlIGEgcXVlcnksIHJlc29sdmluZyB3aXRoIHRoZSBkYXRhIG9yIHRocm93aW5nIHdpdGhcblx0KiB0aGUgZXJyb3IuXG5cdCpcblx0KiBJZiB0aGUgcXVlcnkgYWxyZWFkeSBleGlzdHMgaW4gdGhlIGNhY2hlIGFuZCBpdHMgZGF0YSBpcyBub3Qgc3RhbGUgKHBlciB0aGUgZ2l2ZW5cblx0KiBgc3RhbGVUaW1lYCksIHRoZSBjYWNoZWQgZGF0YSBpcyByZXR1cm5lZCB3aXRob3V0IGZldGNoaW5nLiBPdGhlcndpc2UsIHRoZSBxdWVyeSBpcyBmZXRjaGVkXG5cdCogYW5kIHRoZSBwcm9taXNlIHJlc29sdmVzIG9uY2UgdGhlIGZldGNoIHNldHRsZXMuIElmIGEgYHNlbGVjdGAgZnVuY3Rpb24gaXMgcHJvdmlkZWQsIGl0IGlzXG5cdCogYXBwbGllZCB0byB0aGUgZGF0YSBpbiBib3RoIGNhc2VzIChjYWNoZWQgb3IgZnJlc2hseSBmZXRjaGVkKSBiZWZvcmUgaXQgaXMgcmV0dXJuZWQuXG5cdCpcblx0KiBVbmxpa2UgYSByZWFjdGl2ZSBvYnNlcnZlciwgcmV0cmllcyBhcmUgZGlzYWJsZWQgYnkgZGVmYXVsdCBoZXJlIChgcmV0cnk6IGZhbHNlYCkgdW5sZXNzXG5cdCogZXhwbGljaXRseSBjb25maWd1cmVkLCBzaW5jZSB0aGVyZSBpcyBubyBjb21wb25lbnQgdG8gY2F0Y2ggYSB0aHJvd24gZXJyb3IgYW5kIHJldHJ5IHRocm91Z2hcblx0KiByZS1yZW5kZXIuXG5cdCpcblx0KiBUaGUgYWNjZXB0ZWQgb3B0aW9ucyBhcmUgYFF1ZXJ5T2JzZXJ2ZXJPcHRpb25zYCBtaW51cyB0aGUgZmllbGRzIHRoYXQgb25seSBtYWtlIHNlbnNlIGZvciBhXG5cdCogcmVhY3RpdmUgb2JzZXJ2ZXIg4oCUIGBlbmFibGVkYCwgYHJlZmV0Y2hJbnRlcnZhbGAsIGByZWZldGNoSW50ZXJ2YWxJbkJhY2tncm91bmRgLFxuXHQqIGByZWZldGNoT25XaW5kb3dGb2N1c2AsIGByZWZldGNoT25SZWNvbm5lY3RgLCBgcmVmZXRjaE9uTW91bnRgLCBgcmV0cnlPbk1vdW50YCxcblx0KiBgbm90aWZ5T25DaGFuZ2VQcm9wc2AsIGB0aHJvd09uRXJyb3JgLCBgc3VzcGVuc2VgLCBhbmQgYHBsYWNlaG9sZGVyRGF0YWAgYXJlIG5vdCBwYXJ0IG9mIHRoaXNcblx0KiBtZXRob2QncyBvcHRpb25zLlxuXHQqXG5cdCogVGhpcyBtZXRob2QgcmVwbGFjZXMgdGhlIGRlcHJlY2F0ZWQgYGZldGNoUXVlcnlgLCBhbmQg4oCUIGNvbWJpbmVkIHdpdGhcblx0KiBgeyBzdGFsZVRpbWU6ICdzdGF0aWMnIH1gIOKAlCB0aGUgZGVwcmVjYXRlZCBgZW5zdXJlUXVlcnlEYXRhYC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBxdWVyeSBvcHRpb25zLCBpbmNsdWRpbmcgdGhlIGBxdWVyeUtleWAgYW5kIHRoZSBgcXVlcnlGbmAgdXNlZCBpZiB0aGVcblx0KiBxdWVyeSBuZWVkcyB0byBmZXRjaC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB0byB0aGUgZGF0YSwgb3IgdG8gdGhlIHJlc3VsdCBvZiBgc2VsZWN0YCBpZiBwcm92aWRlZC4gSXRcblx0KiByZWplY3RzIHdpdGggdGhlIGVycm9yIGZyb20gdGhlIGZldGNoIG9yIGZyb20gYHNlbGVjdGAuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIHRyeSB7XG5cdCogICBjb25zdCBkYXRhID0gYXdhaXQgcXVlcnlDbGllbnQucXVlcnkoeyBxdWVyeUtleSwgcXVlcnlGbiwgc3RhbGVUaW1lOiAxMDAwMCB9KVxuXHQqIH0gY2F0Y2ggKGVycm9yKSB7XG5cdCogICBjb25zb2xlLmxvZyhlcnJvcilcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGFzeW5jIHF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnJldHJ5ID09PSB2b2lkIDApIGRlZmF1bHRlZE9wdGlvbnMucmV0cnkgPSBmYWxzZTtcblx0XHRjb25zdCBxdWVyeSA9IHRoaXMuI3F1ZXJ5Q2FjaGUuYnVpbGQodGhpcywgZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFx0Y29uc3QgcXVlcnlEYXRhID0gcXVlcnkuaXNTdGFsZUJ5VGltZShyZXNvbHZlUXVlcnlWYWx1ZShkZWZhdWx0ZWRPcHRpb25zLnN0YWxlVGltZSwgcXVlcnkpKSA/IGF3YWl0IHF1ZXJ5LmZldGNoKGRlZmF1bHRlZE9wdGlvbnMpIDogcXVlcnkuc3RhdGUuZGF0YTtcblx0XHRjb25zdCBzZWxlY3QgPSBkZWZhdWx0ZWRPcHRpb25zLnNlbGVjdDtcblx0XHRpZiAoc2VsZWN0KSByZXR1cm4gc2VsZWN0KHF1ZXJ5RGF0YSk7XG5cdFx0cmV0dXJuIHF1ZXJ5RGF0YTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIGFuZCBjYWNoZXMgYSBxdWVyeSwgb3IgcmV0dXJucyBpdHMgY2FjaGVkIGRhdGEgaWYgaXQgaXNuJ3Qgc3RhbGUuIFVubGlrZSBpbiBvYnNlcnZlcnMsXG5cdCogdGhlIGZldGNoIGlzbid0IHJldHJpZWQgdW5sZXNzIGByZXRyeWAgaXMgc2V0LlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIHF1ZXJ5IG9wdGlvbnMsIGluY2x1ZGluZyB0aGUgYHF1ZXJ5S2V5YCBhbmQgdGhlIGBxdWVyeUZuYCB1c2VkIGlmIHRoZVxuXHQqIHF1ZXJ5IG5lZWRzIHRvIGZldGNoLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHRvIHRoZSBjYWNoZWQgb3IgZmV0Y2hlZCBkYXRhLCBvciByZWplY3RzIHdpdGggdGhlIGZldGNoXG5cdCogZXJyb3IuXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHF1ZXJ5Q2xpZW50LnF1ZXJ5KG9wdGlvbnMpIGluc3RlYWQuIFRoaXMgbWV0aG9kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmV4dCBtYWpvciB2ZXJzaW9uLlxuXHQqL1xuXHRmZXRjaFF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnJldHJ5ID09PSB2b2lkIDApIGRlZmF1bHRlZE9wdGlvbnMucmV0cnkgPSBmYWxzZTtcblx0XHRjb25zdCBxdWVyeSA9IHRoaXMuI3F1ZXJ5Q2FjaGUuYnVpbGQodGhpcywgZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFx0cmV0dXJuIHF1ZXJ5LmlzU3RhbGVCeVRpbWUocmVzb2x2ZVF1ZXJ5VmFsdWUoZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSkgPyBxdWVyeS5mZXRjaChkZWZhdWx0ZWRPcHRpb25zKSA6IFByb21pc2UucmVzb2x2ZShxdWVyeS5zdGF0ZS5kYXRhKTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIGFuZCBjYWNoZXMgYSBxdWVyeSBsaWtlIHtAbGluayBRdWVyeUNsaWVudCNmZXRjaFF1ZXJ5fSwgYnV0IGlnbm9yZXMgdGhlIHJlc3VsdCBhbmQgYW55XG5cdCogZXJyb3IuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucywgaW5jbHVkaW5nIHRoZSBgcXVlcnlLZXlgIGFuZCB0aGUgYHF1ZXJ5Rm5gIHVzZWQgaWYgdGhlXG5cdCogcXVlcnkgbmVlZHMgdG8gZmV0Y2guXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgZmV0Y2ggc2V0dGxlcy4gSXQgbmV2ZXIgcmVqZWN0cy5cblx0KiBAZGVwcmVjYXRlZCBVc2UgcXVlcnlDbGllbnQucXVlcnkob3B0aW9ucykgaW5zdGVhZC4gWW91IGNhbiBzd2FsbG93IGVycm9ycyB3aXRoIGAuY2F0Y2gobm9vcClgLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0cHJlZmV0Y2hRdWVyeShvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuZmV0Y2hRdWVyeShvcHRpb25zKS50aGVuKG5vb3ApLmNhdGNoKG5vb3ApO1xuXHR9XG5cdC8qKlxuXHQqIEFzeW5jaHJvbm91cyBtZXRob2QgdG8gZmV0Y2ggYW5kIGNhY2hlIGFuIGluZmluaXRlIHF1ZXJ5LCByZXNvbHZpbmcgd2l0aCBhblxuXHQqIHtAbGluayBJbmZpbml0ZURhdGF9IG9iamVjdCBvciB0aHJvd2luZyB3aXRoIHRoZSBlcnJvci5cblx0KlxuXHQqIEJlaGF2ZXMgbGlrZSB7QGxpbmsgUXVlcnlDbGllbnQjcXVlcnl9LCBhY2NlcHRpbmcgdGhlIHNhbWUgb3B0aW9ucyAobWludXNcblx0KiBgaW5pdGlhbFBhZ2VQYXJhbWApLCBwbHVzIHRoZSByZXF1aXJlZCBgaW5pdGlhbFBhZ2VQYXJhbWAsIGFuZCBhbiBvcHRpb25hbCBgcGFnZXNgIC9cblx0KiBgZ2V0TmV4dFBhZ2VQYXJhbWAgcGFpciB1c2VkIHRvIHJlZmV0Y2ggYSBmaXhlZCBudW1iZXIgb2YgcGFnZXMgZnJvbSB0aGUgc3RhcnQuXG5cdCpcblx0KiBUaGlzIG1ldGhvZCByZXBsYWNlcyB0aGUgZGVwcmVjYXRlZCBgZmV0Y2hJbmZpbml0ZVF1ZXJ5YCwgYW5kIOKAlCBjb21iaW5lZCB3aXRoXG5cdCogYHsgc3RhbGVUaW1lOiAnc3RhdGljJyB9YCDigJQgdGhlIGRlcHJlY2F0ZWQgYGVuc3VyZUluZmluaXRlUXVlcnlEYXRhYC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBpbmZpbml0ZSBxdWVyeSBvcHRpb25zLCBpbmNsdWRpbmcgdGhlIGBxdWVyeUtleWAsIHRoZSBgcXVlcnlGbmAsIGFuZCB0aGVcblx0KiBgaW5pdGlhbFBhZ2VQYXJhbWAuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgdG8gdGhlIHtAbGluayBJbmZpbml0ZURhdGF9LCBvciB0byB0aGUgcmVzdWx0IG9mIGBzZWxlY3RgIGlmXG5cdCogcHJvdmlkZWQuIEl0IHJlamVjdHMgd2l0aCB0aGUgZXJyb3IgZnJvbSB0aGUgZmV0Y2ggb3IgZnJvbSBgc2VsZWN0YC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogdHJ5IHtcblx0KiAgIGNvbnN0IGRhdGEgPSBhd2FpdCBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5KHsgcXVlcnlLZXksIHF1ZXJ5Rm4sIGluaXRpYWxQYWdlUGFyYW06IDAgfSlcblx0KiAgIGNvbnNvbGUubG9nKGRhdGEucGFnZXMpXG5cdCogfSBjYXRjaCAoZXJyb3IpIHtcblx0KiAgIGNvbnNvbGUubG9nKGVycm9yKVxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0aW5maW5pdGVRdWVyeShvcHRpb25zKSB7XG5cdFx0b3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcblx0XHRyZXR1cm4gdGhpcy5xdWVyeShvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIGFuZCBjYWNoZXMgYW4gaW5maW5pdGUgcXVlcnksIG9yIHJldHVybnMgaXRzIGNhY2hlZCBkYXRhIGlmIGl0IGlzbid0IHN0YWxlLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIGluZmluaXRlIHF1ZXJ5IG9wdGlvbnMsIGluY2x1ZGluZyB0aGUgYHF1ZXJ5S2V5YCwgdGhlIGBxdWVyeUZuYCwgYW5kIHRoZVxuXHQqIGBpbml0aWFsUGFnZVBhcmFtYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB0byB0aGUgY2FjaGVkIG9yIGZldGNoZWQge0BsaW5rIEluZmluaXRlRGF0YX0sIG9yIHJlamVjdHMgd2l0aFxuXHQqIHRoZSBmZXRjaCBlcnJvci5cblx0KiBAZGVwcmVjYXRlZCBVc2UgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeShvcHRpb25zKSBpbnN0ZWFkLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0ZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRvcHRpb25zLl90eXBlID0gXCJpbmZpbml0ZVwiO1xuXHRcdHJldHVybiB0aGlzLmZldGNoUXVlcnkob3B0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogRmV0Y2hlcyBhbmQgY2FjaGVzIGFuIGluZmluaXRlIHF1ZXJ5IGxpa2Uge0BsaW5rIFF1ZXJ5Q2xpZW50I2ZldGNoSW5maW5pdGVRdWVyeX0sIGJ1dCBpZ25vcmVzXG5cdCogdGhlIHJlc3VsdCBhbmQgYW55IGVycm9yLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIGluZmluaXRlIHF1ZXJ5IG9wdGlvbnMsIGluY2x1ZGluZyB0aGUgYHF1ZXJ5S2V5YCwgdGhlIGBxdWVyeUZuYCwgYW5kIHRoZVxuXHQqIGBpbml0aWFsUGFnZVBhcmFtYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIHRoZSBmZXRjaCBzZXR0bGVzLiBJdCBuZXZlciByZWplY3RzLlxuXHQqIEBkZXByZWNhdGVkIFVzZSBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpIGluc3RlYWQuIFlvdSBjYW4gc3dhbGxvdyBlcnJvcnMgd2l0aCBgLmNhdGNoKG5vb3ApYC4gVGhpcyBtZXRob2Qgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uXG5cdCovXG5cdHByZWZldGNoSW5maW5pdGVRdWVyeShvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpLnRoZW4obm9vcCkuY2F0Y2gobm9vcCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgY2FjaGVkIGRhdGEgb2YgYW4gaW5maW5pdGUgcXVlcnksIG9yIGZldGNoZXMgaXQgaWYgdGhlcmUgaXMgbm9uZS4gV2l0aFxuXHQqIGByZXZhbGlkYXRlSWZTdGFsZWAsIHN0YWxlIGNhY2hlZCBkYXRhIGlzIGFsc28gcmVmZXRjaGVkIGluIHRoZSBiYWNrZ3JvdW5kLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIGluZmluaXRlIHF1ZXJ5IG9wdGlvbnMuIElmIHRoZSBxdWVyeSBoYXMgbm8gY2FjaGVkIGRhdGEgeWV0LCBpdCBpcyBmZXRjaGVkXG5cdCogd2l0aCB0aGVzZSBvcHRpb25zLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHRvIHRoZSBjYWNoZWQge0BsaW5rIEluZmluaXRlRGF0YX0sIG9yIHRvIHRoZSBmZXRjaGVkIGRhdGEgaWZcblx0KiBub3RoaW5nIHdhcyBjYWNoZWQgeWV0LlxuXHQqIEBkZXByZWNhdGVkIFVzZSBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5KHsgLi4ub3B0aW9ucywgc3RhbGVUaW1lOiAnc3RhdGljJyB9KSBpbnN0ZWFkLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0ZW5zdXJlSW5maW5pdGVRdWVyeURhdGEob3B0aW9ucykge1xuXHRcdG9wdGlvbnMuX3R5cGUgPSBcImluZmluaXRlXCI7XG5cdFx0cmV0dXJuIHRoaXMuZW5zdXJlUXVlcnlEYXRhKG9wdGlvbnMpO1xuXHR9XG5cdC8qKlxuXHQqIFJlc3VtZXMgbXV0YXRpb25zIHRoYXQgd2VyZSBwYXVzZWQgYmVjYXVzZSB0aGVyZSB3YXMgbm8gbmV0d29yayBjb25uZWN0aW9uLiBEb2VzIG5vdGhpbmdcblx0KiAocmVzb2x2aW5nIGltbWVkaWF0ZWx5KSBpZiB0aGUgY2xpZW50IGlzIGN1cnJlbnRseSBvZmZsaW5lLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIG9uY2UgdGhlIHJlc3VtZWQgbXV0YXRpb25zIGhhdmUgc2V0dGxlZC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5yZXN1bWVQYXVzZWRNdXRhdGlvbnMoKVxuXHQqIGBgYFxuXHQqL1xuXHRyZXN1bWVQYXVzZWRNdXRhdGlvbnMoKSB7XG5cdFx0aWYgKG9ubGluZU1hbmFnZXIuaXNPbmxpbmUoKSkgcmV0dXJuIHRoaXMuI211dGF0aW9uQ2FjaGUucmVzdW1lUGF1c2VkTXV0YXRpb25zKCk7XG5cdFx0cmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIHF1ZXJ5IGNhY2hlIHRoaXMgY2xpZW50IGlzIGNvbm5lY3RlZCB0by5cblx0KiBAcmV0dXJucyBUaGUge0BsaW5rIFF1ZXJ5Q2FjaGV9IGluc3RhbmNlLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KiBjb25zdCBxdWVyaWVzID0gcXVlcnlDYWNoZS5maW5kQWxsKHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRRdWVyeUNhY2hlKCkge1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG11dGF0aW9uIGNhY2hlIHRoaXMgY2xpZW50IGlzIGNvbm5lY3RlZCB0by5cblx0KiBAcmV0dXJucyBUaGUge0BsaW5rIE11dGF0aW9uQ2FjaGV9IGluc3RhbmNlLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKClcblx0KiBjb25zdCBtdXRhdGlvbnMgPSBtdXRhdGlvbkNhY2hlLmZpbmRBbGwoeyBzdGF0dXM6ICdwZW5kaW5nJyB9KVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRNdXRhdGlvbkNhY2hlKCkge1xuXHRcdHJldHVybiB0aGlzLiNtdXRhdGlvbkNhY2hlO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIGRlZmF1bHQgb3B0aW9ucyB0aGF0IHdlcmUgc2V0IHdoZW4gY3JlYXRpbmcgdGhlIGNsaWVudCwgb3IgdmlhXG5cdCoge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldERlZmF1bHRPcHRpb25zfS5cblx0KiBAcmV0dXJucyBUaGUgY2xpZW50J3MgY3VycmVudCBkZWZhdWx0IG9wdGlvbnMuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IFF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG5cdCogY29uc3QgZGVmYXVsdE9wdGlvbnMgPSBxdWVyeUNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpXG5cdCogYGBgXG5cdCovXG5cdGdldERlZmF1bHRPcHRpb25zKCkge1xuXHRcdHJldHVybiB0aGlzLiNkZWZhdWx0T3B0aW9ucztcblx0fVxuXHQvKipcblx0KiBEeW5hbWljYWxseSBzZXRzIHRoZSBkZWZhdWx0IG9wdGlvbnMgZm9yIHRoaXMgY2xpZW50LCBvdmVyd3JpdGluZyBhbnkgcHJldmlvdXNseSBkZWZpbmVkXG5cdCogZGVmYXVsdCBvcHRpb25zLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG5ldyBkZWZhdWx0IG9wdGlvbnMgZm9yIHF1ZXJpZXMgYW5kIG11dGF0aW9ucy5cblx0KiBAc2VlIHtAbGluayBRdWVyeUNsaWVudCNnZXREZWZhdWx0T3B0aW9uc31cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcblx0KiBxdWVyeUNsaWVudC5zZXREZWZhdWx0T3B0aW9ucyh7XG5cdCogICBxdWVyaWVzOiB7XG5cdCogICAgIHN0YWxlVGltZTogSW5maW5pdHksXG5cdCogICB9LFxuXHQqIH0pXG5cdCogYGBgXG5cdCovXG5cdHNldERlZmF1bHRPcHRpb25zKG9wdGlvbnMpIHtcblx0XHR0aGlzLiNkZWZhdWx0T3B0aW9ucyA9IG9wdGlvbnM7XG5cdH1cblx0LyoqXG5cdCogU2V0cyBkZWZhdWx0IG9wdGlvbnMgZm9yIHF1ZXJpZXMgd2hvc2UgcXVlcnkga2V5IHBhcnRpYWxseSBtYXRjaGVzIHRoZSBnaXZlbiBgcXVlcnlLZXlgLlxuXHQqXG5cdCogSWYgc2V2ZXJhbCByZWdpc3RlcmVkIHF1ZXJ5IGRlZmF1bHRzIG1hdGNoIGEgZ2l2ZW4gcXVlcnkga2V5LCB0aGV5IGFyZSBtZXJnZWQgdG9nZXRoZXIgaW5cblx0KiByZWdpc3RyYXRpb24gb3JkZXIgYnkge0BsaW5rIFF1ZXJ5Q2xpZW50I2dldFF1ZXJ5RGVmYXVsdHN9LCBzbyByZWdpc3RlciBkZWZhdWx0cyBmcm9tIHRoZVxuXHQqIG1vc3QgZ2VuZXJpYyBrZXkgdG8gdGhlIGxlYXN0IGdlbmVyaWMgb25lIOKAlCBtb3JlIHNwZWNpZmljIGRlZmF1bHRzIHNob3VsZCBiZSByZWdpc3RlcmVkXG5cdCogYWZ0ZXIgbW9yZSBnZW5lcmljIG9uZXMgc28gdGhleSB0YWtlIHByZWNlZGVuY2UuXG5cdCogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSB0aGF0IHF1ZXJ5IGtleXMgYXJlIHBhcnRpYWxseSBtYXRjaGVkIGFnYWluc3QuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgZGVmYXVsdCBvcHRpb25zIGFwcGxpZWQgdG8gbWF0Y2hpbmcgcXVlcmllcy5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnlDbGllbnQuc2V0UXVlcnlEZWZhdWx0cyhbJ3Bvc3RzJ10sIHsgcXVlcnlGbjogZmV0Y2hQb3N0cyB9KVxuXHQqXG5cdCogYXdhaXQgcXVlcnlDbGllbnQucXVlcnkoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG5cdCogYGBgXG5cdCovXG5cdHNldFF1ZXJ5RGVmYXVsdHMocXVlcnlLZXksIG9wdGlvbnMpIHtcblx0XHR0aGlzLiNxdWVyeURlZmF1bHRzLnNldChoYXNoS2V5KHF1ZXJ5S2V5KSwge1xuXHRcdFx0cXVlcnlLZXksXG5cdFx0XHRkZWZhdWx0T3B0aW9uczogb3B0aW9uc1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIGRlZmF1bHQgb3B0aW9ucyByZWdpc3RlcmVkIGZvciBxdWVyaWVzIHdob3NlIHF1ZXJ5IGtleSBwYXJ0aWFsbHkgbWF0Y2hlcyB0aGVcblx0KiBnaXZlbiBgcXVlcnlLZXlgLCB2aWEge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldFF1ZXJ5RGVmYXVsdHN9LiBJZiBtdWx0aXBsZSByZWdpc3RlcmVkIGRlZmF1bHRzXG5cdCogbWF0Y2gsIHRoZXkgYXJlIG1lcmdlZCB0b2dldGhlciBpbiByZWdpc3RyYXRpb24gb3JkZXIuXG5cdCogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSB0byBsb29rIHVwIHJlZ2lzdGVyZWQgZGVmYXVsdHMgZm9yLlxuXHQqIEByZXR1cm5zIFRoZSBtZXJnZWQgZGVmYXVsdCBvcHRpb25zIG9mIGV2ZXJ5IHJlZ2lzdHJhdGlvbiB0aGF0IG1hdGNoZXMsIG9yIGFuIGVtcHR5IG9iamVjdCBpZlxuXHQqIG5vbmUgbWF0Y2guXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IGRlZmF1bHRPcHRpb25zID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlEZWZhdWx0cyhbJ3Bvc3RzJ10pXG5cdCogYGBgXG5cdCovXG5cdGdldFF1ZXJ5RGVmYXVsdHMocXVlcnlLZXkpIHtcblx0XHRjb25zdCBkZWZhdWx0cyA9IFsuLi50aGlzLiNxdWVyeURlZmF1bHRzLnZhbHVlcygpXTtcblx0XHRjb25zdCByZXN1bHQgPSB7fTtcblx0XHRkZWZhdWx0cy5mb3JFYWNoKChxdWVyeURlZmF1bHQpID0+IHtcblx0XHRcdGlmIChwYXJ0aWFsTWF0Y2hLZXkocXVlcnlLZXksIHF1ZXJ5RGVmYXVsdC5xdWVyeUtleSkpIE9iamVjdC5hc3NpZ24ocmVzdWx0LCBxdWVyeURlZmF1bHQuZGVmYXVsdE9wdGlvbnMpO1xuXHRcdH0pO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH1cblx0LyoqXG5cdCogU2V0cyBkZWZhdWx0IG9wdGlvbnMgZm9yIG11dGF0aW9ucyB3aG9zZSBtdXRhdGlvbiBrZXkgcGFydGlhbGx5IG1hdGNoZXMgdGhlIGdpdmVuXG5cdCogYG11dGF0aW9uS2V5YC4gQXMgd2l0aCB7QGxpbmsgUXVlcnlDbGllbnQjc2V0UXVlcnlEZWZhdWx0c30sIHRoZSBvcmRlciBvZiByZWdpc3RyYXRpb25cblx0KiBtYXR0ZXJzIHdoZW4gc2V2ZXJhbCByZWdpc3RlcmVkIGRlZmF1bHRzIG1hdGNoIHRoZSBzYW1lIG11dGF0aW9uIGtleS5cblx0KiBAcGFyYW0gbXV0YXRpb25LZXkgLSBUaGUgbXV0YXRpb24ga2V5IHRoYXQgbXV0YXRpb24ga2V5cyBhcmUgcGFydGlhbGx5IG1hdGNoZWQgYWdhaW5zdC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBkZWZhdWx0IG9wdGlvbnMgYXBwbGllZCB0byBtYXRjaGluZyBtdXRhdGlvbnMuXG5cdCogQHNlZSB7QGxpbmsgUXVlcnlDbGllbnQjZ2V0TXV0YXRpb25EZWZhdWx0c31cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnlDbGllbnQuc2V0TXV0YXRpb25EZWZhdWx0cyhbJ2FkZFBvc3QnXSwgeyBtdXRhdGlvbkZuOiBhZGRQb3N0IH0pXG5cdCogYGBgXG5cdCovXG5cdHNldE11dGF0aW9uRGVmYXVsdHMobXV0YXRpb25LZXksIG9wdGlvbnMpIHtcblx0XHR0aGlzLiNtdXRhdGlvbkRlZmF1bHRzLnNldChoYXNoS2V5KG11dGF0aW9uS2V5KSwge1xuXHRcdFx0bXV0YXRpb25LZXksXG5cdFx0XHRkZWZhdWx0T3B0aW9uczogb3B0aW9uc1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIGRlZmF1bHQgb3B0aW9ucyByZWdpc3RlcmVkIGZvciBtdXRhdGlvbnMgd2hvc2UgbXV0YXRpb24ga2V5IHBhcnRpYWxseSBtYXRjaGVzXG5cdCogdGhlIGdpdmVuIGBtdXRhdGlvbktleWAsIHZpYSB7QGxpbmsgUXVlcnlDbGllbnQjc2V0TXV0YXRpb25EZWZhdWx0c30uIElmIG11bHRpcGxlIHJlZ2lzdGVyZWRcblx0KiBkZWZhdWx0cyBtYXRjaCwgdGhleSBhcmUgbWVyZ2VkIHRvZ2V0aGVyIGluIHJlZ2lzdHJhdGlvbiBvcmRlci5cblx0KiBAcGFyYW0gbXV0YXRpb25LZXkgLSBUaGUgbXV0YXRpb24ga2V5IHRvIGxvb2sgdXAgcmVnaXN0ZXJlZCBkZWZhdWx0cyBmb3IuXG5cdCogQHJldHVybnMgVGhlIG1lcmdlZCBkZWZhdWx0IG9wdGlvbnMgb2YgZXZlcnkgcmVnaXN0cmF0aW9uIHRoYXQgbWF0Y2hlcywgb3IgYW4gZW1wdHkgb2JqZWN0IGlmXG5cdCogbm9uZSBtYXRjaC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgZGVmYXVsdE9wdGlvbnMgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkRlZmF1bHRzKFsnYWRkUG9zdCddKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRNdXRhdGlvbkRlZmF1bHRzKG11dGF0aW9uS2V5KSB7XG5cdFx0Y29uc3QgZGVmYXVsdHMgPSBbLi4udGhpcy4jbXV0YXRpb25EZWZhdWx0cy52YWx1ZXMoKV07XG5cdFx0Y29uc3QgcmVzdWx0ID0ge307XG5cdFx0ZGVmYXVsdHMuZm9yRWFjaCgocXVlcnlEZWZhdWx0KSA9PiB7XG5cdFx0XHRpZiAocGFydGlhbE1hdGNoS2V5KG11dGF0aW9uS2V5LCBxdWVyeURlZmF1bHQubXV0YXRpb25LZXkpKSBPYmplY3QuYXNzaWduKHJlc3VsdCwgcXVlcnlEZWZhdWx0LmRlZmF1bHRPcHRpb25zKTtcblx0XHR9KTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIENhbGxlZCBieSBmcmFtZXdvcmsgYWRhcHRlcnMgKGUuZy4gaW5zaWRlIGB1c2VRdWVyeWApIHRvIHJlc29sdmUgdGhlIG9wdGlvbnMgcGFzc2VkIGJ5IHRoZVxuXHQqIGNhbGxlciBpbnRvIHRoZWlyIGZpbmFsLCBkZWZhdWx0ZWQgZm9ybTogbWVyZ2luZyB0aGUgY2xpZW50J3Mgb3duIGBkZWZhdWx0T3B0aW9ucy5xdWVyaWVzYCxcblx0KiB0aGVuIGBxdWVyeUNsaWVudC5zZXRRdWVyeURlZmF1bHRzYCBmb3IgdGhlIGdpdmVuIGBxdWVyeUtleWAsIHRoZW4gdGhlIGNhbGxlcidzIG9wdGlvbnMgb25cblx0KiB0b3AuIEEgbm8tb3AgaWYgdGhlIG9wdGlvbnMgYXJlIGFscmVhZHkgZGVmYXVsdGVkIChgX2RlZmF1bHRlZDogdHJ1ZWApLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIHF1ZXJ5IG9wdGlvbnMgcGFzc2VkIGJ5IHRoZSBjYWxsZXIuXG5cdCogQHJldHVybnMgVGhlIGRlZmF1bHRlZCBvcHRpb25zLCB3aXRoIGBxdWVyeUhhc2hgIGFuZCBkZXBlbmRlbnQgZGVmYXVsdHMgKGUuZy5cblx0KiBgcmVmZXRjaE9uUmVjb25uZWN0YCkgZmlsbGVkIGluLlxuXHQqL1xuXHRkZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpIHtcblx0XHRpZiAob3B0aW9ucy5fZGVmYXVsdGVkKSByZXR1cm4gb3B0aW9ucztcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0ge1xuXHRcdFx0Li4udGhpcy4jZGVmYXVsdE9wdGlvbnMucXVlcmllcyxcblx0XHRcdC4uLnRoaXMuZ2V0UXVlcnlEZWZhdWx0cyhvcHRpb25zLnF1ZXJ5S2V5KSxcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRfZGVmYXVsdGVkOiB0cnVlXG5cdFx0fTtcblx0XHRpZiAoIWRlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNoKSBkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCA9IGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5S2V5LCBkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRpZiAoZGVmYXVsdGVkT3B0aW9ucy5yZWZldGNoT25SZWNvbm5lY3QgPT09IHZvaWQgMCkgZGVmYXVsdGVkT3B0aW9ucy5yZWZldGNoT25SZWNvbm5lY3QgPSBkZWZhdWx0ZWRPcHRpb25zLm5ldHdvcmtNb2RlICE9PSBcImFsd2F5c1wiO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnRocm93T25FcnJvciA9PT0gdm9pZCAwKSBkZWZhdWx0ZWRPcHRpb25zLnRocm93T25FcnJvciA9ICEhZGVmYXVsdGVkT3B0aW9ucy5zdXNwZW5zZTtcblx0XHRpZiAoIWRlZmF1bHRlZE9wdGlvbnMubmV0d29ya01vZGUgJiYgZGVmYXVsdGVkT3B0aW9ucy5wZXJzaXN0ZXIpIGRlZmF1bHRlZE9wdGlvbnMubmV0d29ya01vZGUgPSBcIm9mZmxpbmVGaXJzdFwiO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikgZGVmYXVsdGVkT3B0aW9ucy5lbmFibGVkID0gZmFsc2U7XG5cdFx0cmV0dXJuIGRlZmF1bHRlZE9wdGlvbnM7XG5cdH1cblx0LyoqXG5cdCogVGhlIG11dGF0aW9uIGNvdW50ZXJwYXJ0IG9mIHtAbGluayBRdWVyeUNsaWVudCNkZWZhdWx0UXVlcnlPcHRpb25zfS4gQ2FsbGVkIGJ5IGZyYW1ld29ya1xuXHQqIGFkYXB0ZXJzIChlLmcuIGluc2lkZSBgdXNlTXV0YXRpb25gKSB0byBtZXJnZSB0aGUgY2xpZW50J3MgYGRlZmF1bHRPcHRpb25zLm11dGF0aW9uc2AsIHRoZW5cblx0KiBgcXVlcnlDbGllbnQuc2V0TXV0YXRpb25EZWZhdWx0c2AgZm9yIHRoZSBnaXZlbiBgbXV0YXRpb25LZXlgLCB0aGVuIHRoZSBjYWxsZXIncyBvcHRpb25zIG9uXG5cdCogdG9wLiBBIG5vLW9wIGlmIHRoZSBvcHRpb25zIGFyZSBhbHJlYWR5IGRlZmF1bHRlZCAoYF9kZWZhdWx0ZWQ6IHRydWVgKS5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBtdXRhdGlvbiBvcHRpb25zIHBhc3NlZCBieSB0aGUgY2FsbGVyLlxuXHQqIEByZXR1cm5zIFRoZSBkZWZhdWx0ZWQgb3B0aW9ucy5cblx0Ki9cblx0ZGVmYXVsdE11dGF0aW9uT3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0aWYgKG9wdGlvbnM/Ll9kZWZhdWx0ZWQpIHJldHVybiBvcHRpb25zO1xuXHRcdHJldHVybiB7XG5cdFx0XHQuLi50aGlzLiNkZWZhdWx0T3B0aW9ucy5tdXRhdGlvbnMsXG5cdFx0XHQuLi5vcHRpb25zPy5tdXRhdGlvbktleSAmJiB0aGlzLmdldE11dGF0aW9uRGVmYXVsdHMob3B0aW9ucy5tdXRhdGlvbktleSksXG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0X2RlZmF1bHRlZDogdHJ1ZVxuXHRcdH07XG5cdH1cblx0LyoqXG5cdCogQ2xlYXJzIGJvdGggdGhlIHF1ZXJ5IGNhY2hlIGFuZCB0aGUgbXV0YXRpb24gY2FjaGUgdGhpcyBjbGllbnQgaXMgY29ubmVjdGVkIHRvLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIHF1ZXJ5Q2xpZW50LmNsZWFyKClcblx0KiBgYGBcblx0Ki9cblx0Y2xlYXIoKSB7XG5cdFx0dGhpcy4jcXVlcnlDYWNoZS5jbGVhcigpO1xuXHRcdHRoaXMuI211dGF0aW9uQ2FjaGUuY2xlYXIoKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUXVlcnlDbGllbnQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcnlDbGllbnQuanMubWFwIiwiaW1wb3J0IHsgYWRkQ29uc3VtZUF3YXJlU2lnbmFsLCBhZGRUb0VuZCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyNyZWdpb24gc3JjL3N0cmVhbWVkUXVlcnkudHNcbi8qKlxuKiBUaGlzIGlzIGEgaGVscGVyIGZ1bmN0aW9uIHRvIGNyZWF0ZSBhIHF1ZXJ5IGZ1bmN0aW9uIHRoYXQgc3RyZWFtcyBkYXRhIGZyb20gYW4gQXN5bmNJdGVyYWJsZS5cbiogRGF0YSB3aWxsIGJlIGFuIEFycmF5IG9mIGFsbCB0aGUgY2h1bmtzIHJlY2VpdmVkLlxuKiBUaGUgcXVlcnkgd2lsbCBiZSBpbiBhICdwZW5kaW5nJyBzdGF0ZSB1bnRpbCB0aGUgZmlyc3QgY2h1bmsgb2YgZGF0YSBpcyByZWNlaXZlZCwgYnV0IHdpbGwgZ28gdG8gJ3N1Y2Nlc3MnIGFmdGVyIHRoYXQuXG4qIFRoZSBxdWVyeSB3aWxsIHN0YXkgaW4gZmV0Y2hTdGF0dXMgJ2ZldGNoaW5nJyB1bnRpbCB0aGUgc3RyZWFtIGVuZHMuXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIGBzdHJlYW1GbmAgdGhhdCByZXR1cm5zIGFuIEFzeW5jSXRlcmFibGUgdG8gc3RyZWFtIGRhdGEgZnJvbSwgYW5kIHRoZSBvcHRpb25hbFxuKiBgcmVmZXRjaE1vZGVgLCBgcmVkdWNlcmAsIGFuZCBgaW5pdGlhbFZhbHVlYCBvcHRpb25zLlxuKiBAcmV0dXJucyBBIHF1ZXJ5IGZ1bmN0aW9uIHRvIHBhc3MgYXMgYHF1ZXJ5Rm5gLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBhd2FpdCBxdWVyeUNsaWVudC5xdWVyeSh7XG4qICAgcXVlcnlLZXk6IFsnZGF0YSddLFxuKiAgIHF1ZXJ5Rm46IHN0cmVhbWVkUXVlcnkoe1xuKiAgICAgc3RyZWFtRm46IGZldGNoRGF0YUluQ2h1bmtzLFxuKiAgIH0pLFxuKiB9KVxuKiBgYGBcbiovXG5mdW5jdGlvbiBzdHJlYW1lZFF1ZXJ5KHsgc3RyZWFtRm4sIHJlZmV0Y2hNb2RlID0gXCJyZXNldFwiLCByZWR1Y2VyID0gKGl0ZW1zLCBjaHVuaykgPT4gYWRkVG9FbmQoaXRlbXMsIGNodW5rKSwgaW5pdGlhbFZhbHVlID0gW10gfSkge1xuXHRyZXR1cm4gYXN5bmMgKGNvbnRleHQpID0+IHtcblx0XHRjb25zdCBxdWVyeSA9IGNvbnRleHQuY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5maW5kKHtcblx0XHRcdHF1ZXJ5S2V5OiBjb250ZXh0LnF1ZXJ5S2V5LFxuXHRcdFx0ZXhhY3Q6IHRydWVcblx0XHR9KTtcblx0XHRjb25zdCBpc1JlZmV0Y2ggPSAhIXF1ZXJ5ICYmIHF1ZXJ5LmlzRmV0Y2hlZCgpO1xuXHRcdGlmIChpc1JlZmV0Y2ggJiYgcmVmZXRjaE1vZGUgPT09IFwicmVzZXRcIikgcXVlcnkuc2V0U3RhdGUoe1xuXHRcdFx0Li4ucXVlcnkucmVzZXRTdGF0ZSxcblx0XHRcdGZldGNoU3RhdHVzOiBcImZldGNoaW5nXCJcblx0XHR9KTtcblx0XHRsZXQgcmVzdWx0ID0gaW5pdGlhbFZhbHVlO1xuXHRcdGxldCBjYW5jZWxsZWQgPSBmYWxzZTtcblx0XHRjb25zdCBzdHJlYW0gPSBhd2FpdCBzdHJlYW1GbihhZGRDb25zdW1lQXdhcmVTaWduYWwoe1xuXHRcdFx0Y2xpZW50OiBjb250ZXh0LmNsaWVudCxcblx0XHRcdG1ldGE6IGNvbnRleHQubWV0YSxcblx0XHRcdHF1ZXJ5S2V5OiBjb250ZXh0LnF1ZXJ5S2V5LFxuXHRcdFx0cGFnZVBhcmFtOiBjb250ZXh0LnBhZ2VQYXJhbSxcblx0XHRcdGRpcmVjdGlvbjogY29udGV4dC5kaXJlY3Rpb25cblx0XHR9LCAoKSA9PiBjb250ZXh0LnNpZ25hbCwgKCkgPT4gY2FuY2VsbGVkID0gdHJ1ZSkpO1xuXHRcdGNvbnN0IGlzUmVwbGFjZVJlZmV0Y2ggPSBpc1JlZmV0Y2ggJiYgcmVmZXRjaE1vZGUgPT09IFwicmVwbGFjZVwiO1xuXHRcdGZvciBhd2FpdCAoY29uc3QgY2h1bmsgb2Ygc3RyZWFtKSB7XG5cdFx0XHRpZiAoY2FuY2VsbGVkKSBicmVhaztcblx0XHRcdGlmIChpc1JlcGxhY2VSZWZldGNoKSByZXN1bHQgPSByZWR1Y2VyKHJlc3VsdCwgY2h1bmspO1xuXHRcdFx0ZWxzZSBjb250ZXh0LmNsaWVudC5zZXRRdWVyeURhdGEoY29udGV4dC5xdWVyeUtleSwgKHByZXYpID0+IHJlZHVjZXIocHJldiA9PT0gdm9pZCAwID8gaW5pdGlhbFZhbHVlIDogcHJldiwgY2h1bmspKTtcblx0XHR9XG5cdFx0aWYgKGlzUmVwbGFjZVJlZmV0Y2ggJiYgIWNhbmNlbGxlZCkgY29udGV4dC5jbGllbnQuc2V0UXVlcnlEYXRhKGNvbnRleHQucXVlcnlLZXksIHJlc3VsdCk7XG5cdFx0Y29uc3QgZGF0YSA9IGNvbnRleHQuY2xpZW50LmdldFF1ZXJ5RGF0YShjb250ZXh0LnF1ZXJ5S2V5KTtcblx0XHRyZXR1cm4gZGF0YSA9PT0gdm9pZCAwID8gaW5pdGlhbFZhbHVlIDogZGF0YTtcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgc3RyZWFtZWRRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdHJlYW1lZFF1ZXJ5LmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvdHlwZXMudHNcbi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG5jb25zdCBkYXRhVGFnU3ltYm9sID0gU3ltYm9sKCk7XG5jb25zdCBkYXRhVGFnRXJyb3JTeW1ib2wgPSBTeW1ib2woKTtcbmNvbnN0IHVuc2V0TWFya2VyID0gU3ltYm9sKCk7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGRhdGFUYWdFcnJvclN5bWJvbCwgZGF0YVRhZ1N5bWJvbCwgdW5zZXRNYXJrZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dHlwZXMuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaHlkcmF0ZSB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy9IeWRyYXRpb25Cb3VuZGFyeS50c3hcbi8qKlxuKiBgSHlkcmF0aW9uQm91bmRhcnlgIGFkZHMgYSBwcmV2aW91c2x5IGRlaHlkcmF0ZWQgc3RhdGUgaW50byB0aGUgYHF1ZXJ5Q2xpZW50YCB0aGF0IHdvdWxkIGJlIHJldHVybmVkIGJ5XG4qIGB1c2VRdWVyeUNsaWVudCgpYC4gSWYgdGhlIGNsaWVudCBhbHJlYWR5IGNvbnRhaW5zIGRhdGEsIHRoZSBuZXcgcXVlcmllcyB3aWxsIGJlIGludGVsbGlnZW50bHkgbWVyZ2VkIGJhc2VkIG9uXG4qIHVwZGF0ZSB0aW1lc3RhbXAuXG4qXG4qIE5vdGU6IE9ubHkgYHF1ZXJpZXNgIGNhbiBiZSBkZWh5ZHJhdGVkIHdpdGggYW4gYEh5ZHJhdGlvbkJvdW5kYXJ5YC5cbiogQHBhcmFtIHByb3BzIC0gVGhlIGRlaHlkcmF0ZWQgYHN0YXRlYCB0byBoeWRyYXRlLCB0aGUgaHlkcmF0ZSBgb3B0aW9uc2AsIGFuIG9wdGlvbmFsIGN1c3RvbVxuKiBgcXVlcnlDbGllbnRgLCBhbmQgdGhlIGBjaGlsZHJlbmAgdG8gcmVuZGVyLlxuKiBAcmV0dXJucyBUaGUgcHJvdmlkZWQgYGNoaWxkcmVuYCwgcmVuZGVyZWQgdW5jb25kaXRpb25hbGx5LiBOZXcgcXVlcmllcyBpbiBgc3RhdGVgIGFyZSBoeWRyYXRlZCBpbnRvIHRoZVxuKiBjYWNoZSBkdXJpbmcgcmVuZGVyOyBmb3IgcXVlcmllcyBhbHJlYWR5IGluIHRoZSBjYWNoZSwgb25seSBuZXdlciBkZWh5ZHJhdGVkIGRhdGEgaXMgaHlkcmF0ZWQsIGluIGFuIGVmZmVjdFxuKiBhZnRlciBjb21taXQuXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBIeWRyYXRpb25Cb3VuZGFyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiA8SHlkcmF0aW9uQm91bmRhcnkgc3RhdGU9e2RlaHlkcmF0ZWRTdGF0ZX0+Li4uPC9IeWRyYXRpb25Cb3VuZGFyeT5cbiogfVxuKiBgYGBcbiogQGV4YW1wbGVcbiogU2VydmVyLXNpZGUgcHJlZmV0Y2ggaGFuZGVkIG9mZiB0byB0aGUgY2xpZW50IHZpYSBgZGVoeWRyYXRlYDpcbiogYGBgdHN4XG4qIGltcG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5LCBkZWh5ZHJhdGUsIG5vb3AgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGFzeW5jIGZ1bmN0aW9uIFNlcnZlckNvbXBvbmVudCgpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IGdldFF1ZXJ5Q2xpZW50KClcbipcbiogICBhd2FpdCBxdWVyeUNsaWVudFxuKiAgICAgLnF1ZXJ5KHtcbiogICAgICAgcXVlcnlLZXk6IFsncG9zdHMnXSxcbiogICAgICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcbiogICAgIH0pXG4qICAgICAuY2F0Y2gobm9vcClcbipcbiogICByZXR1cm4gKFxuKiAgICAgPEh5ZHJhdGlvbkJvdW5kYXJ5IHN0YXRlPXtkZWh5ZHJhdGUocXVlcnlDbGllbnQpfT5cbiogICAgICAgPFBvc3RzIC8+XG4qICAgICA8L0h5ZHJhdGlvbkJvdW5kYXJ5PlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5jb25zdCBIeWRyYXRpb25Cb3VuZGFyeSA9ICh7IGNoaWxkcmVuLCBvcHRpb25zID0ge30sIHN0YXRlLCBxdWVyeUNsaWVudCB9KSA9PiB7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0Y29uc3Qgb3B0aW9uc1JlZiA9IFJlYWN0LnVzZVJlZihvcHRpb25zKTtcblx0UmVhY3QudXNlRWZmZWN0KCgpID0+IHtcblx0XHRvcHRpb25zUmVmLmN1cnJlbnQgPSBvcHRpb25zO1xuXHR9KTtcblx0Y29uc3QgaHlkcmF0aW9uUXVldWUgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcblx0XHRpZiAoc3RhdGUpIHtcblx0XHRcdGlmICh0eXBlb2Ygc3RhdGUgIT09IFwib2JqZWN0XCIpIHJldHVybjtcblx0XHRcdGNvbnN0IHF1ZXJ5Q2FjaGUgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuXHRcdFx0Y29uc3QgcXVlcmllcyA9IHN0YXRlLnF1ZXJpZXMgfHwgW107XG5cdFx0XHRjb25zdCBuZXdRdWVyaWVzID0gW107XG5cdFx0XHRjb25zdCBleGlzdGluZ1F1ZXJpZXMgPSBbXTtcblx0XHRcdGZvciAoY29uc3QgZGVoeWRyYXRlZFF1ZXJ5IG9mIHF1ZXJpZXMpIHtcblx0XHRcdFx0Y29uc3QgZXhpc3RpbmdRdWVyeSA9IHF1ZXJ5Q2FjaGUuZ2V0KGRlaHlkcmF0ZWRRdWVyeS5xdWVyeUhhc2gpO1xuXHRcdFx0XHRpZiAoIWV4aXN0aW5nUXVlcnkpIG5ld1F1ZXJpZXMucHVzaChkZWh5ZHJhdGVkUXVlcnkpO1xuXHRcdFx0XHRlbHNlIGlmIChkZWh5ZHJhdGVkUXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCA+IGV4aXN0aW5nUXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCB8fCBkZWh5ZHJhdGVkUXVlcnkucHJvbWlzZSAmJiBleGlzdGluZ1F1ZXJ5LnN0YXRlLnN0YXR1cyAhPT0gXCJwZW5kaW5nXCIgJiYgZXhpc3RpbmdRdWVyeS5zdGF0ZS5mZXRjaFN0YXR1cyAhPT0gXCJmZXRjaGluZ1wiICYmIGRlaHlkcmF0ZWRRdWVyeS5kZWh5ZHJhdGVkQXQgPiBleGlzdGluZ1F1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQpIGV4aXN0aW5nUXVlcmllcy5wdXNoKGRlaHlkcmF0ZWRRdWVyeSk7XG5cdFx0XHR9XG5cdFx0XHRpZiAobmV3UXVlcmllcy5sZW5ndGggPiAwKSBoeWRyYXRlKGNsaWVudCwgeyBxdWVyaWVzOiBuZXdRdWVyaWVzIH0sIG9wdGlvbnNSZWYuY3VycmVudCk7XG5cdFx0XHRpZiAoZXhpc3RpbmdRdWVyaWVzLmxlbmd0aCA+IDApIHJldHVybiBleGlzdGluZ1F1ZXJpZXM7XG5cdFx0fVxuXHR9LCBbY2xpZW50LCBzdGF0ZV0pO1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGlmIChoeWRyYXRpb25RdWV1ZSkgaHlkcmF0ZShjbGllbnQsIHsgcXVlcmllczogaHlkcmF0aW9uUXVldWUgfSwgb3B0aW9uc1JlZi5jdXJyZW50KTtcblx0fSwgW2NsaWVudCwgaHlkcmF0aW9uUXVldWVdKTtcblx0cmV0dXJuIGNoaWxkcmVuO1xufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgSHlkcmF0aW9uQm91bmRhcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9SHlkcmF0aW9uQm91bmRhcnkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbi8vI3JlZ2lvbiBzcmMvSXNSZXN0b3JpbmdQcm92aWRlci50c1xuY29uc3QgSXNSZXN0b3JpbmdDb250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChmYWxzZSk7XG4vKipcbiogSWYgeW91IGFyZSB1c2luZyBgUGVyc2lzdFF1ZXJ5Q2xpZW50UHJvdmlkZXJgLCB5b3UgY2FuIGFsc28gdXNlIHRoZSBgdXNlSXNSZXN0b3JpbmdgIGhvb2sgYWxvbmdzaWRlIGl0IHRvXG4qIGNoZWNrIGlmIGEgcmVzdG9yZSBpcyBjdXJyZW50bHkgaW4gcHJvZ3Jlc3MuIGB1c2VRdWVyeWAgYW5kIGZyaWVuZHMgYWxzbyBjaGVjayB0aGlzIGludGVybmFsbHkgdG8gYXZvaWRcbiogcmFjZSBjb25kaXRpb25zIGJldHdlZW4gdGhlIHJlc3RvcmUgYW5kIG1vdW50aW5nIHF1ZXJpZXMuXG4qIEByZXR1cm5zIGB0cnVlYCB3aGlsZSBhIHBlcnNpc3RlZCBjbGllbnQgaXMgYmVpbmcgcmVzdG9yZWQsIGBmYWxzZWAgb3RoZXJ3aXNlLlxuKi9cbmNvbnN0IHVzZUlzUmVzdG9yaW5nID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChJc1Jlc3RvcmluZ0NvbnRleHQpO1xuLyoqXG4qIFRoZSBQcm92aWRlciB0aGF0IGBQZXJzaXN0UXVlcnlDbGllbnRQcm92aWRlcmAgdXNlcyB0byBzaWduYWwgd2hldGhlciBhIHBlcnNpc3RlZCBjbGllbnQgaXMgY3VycmVudGx5XG4qIGJlaW5nIHJlc3RvcmVkLCByZWFkIGJ5IGB1c2VJc1Jlc3RvcmluZ2AuXG4qL1xuY29uc3QgSXNSZXN0b3JpbmdQcm92aWRlciA9IElzUmVzdG9yaW5nQ29udGV4dC5Qcm92aWRlcjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgSXNSZXN0b3JpbmdQcm92aWRlciwgdXNlSXNSZXN0b3JpbmcgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9SXNSZXN0b3JpbmdQcm92aWRlci5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LnRzeFxuLyoqXG4qIENyZWF0ZXMgdGhlIHZhbHVlIHNoYXJlZCB0aHJvdWdoIHRoZSBib3VuZGFyeSdzIGNvbnRleHQsIHdoaWNoIHRyYWNrcyB3aGV0aGVyIGEgcmVzZXQgd2FzXG4qIHJlcXVlc3RlZC5cbiogQHJldHVybnMgVGhlIGBjbGVhclJlc2V0YCwgYGlzUmVzZXRgLCBhbmQgYHJlc2V0YCBmdW5jdGlvbnMgb2YgdGhlIGJvdW5kYXJ5LlxuKi9cbmZ1bmN0aW9uIGNyZWF0ZVZhbHVlKCkge1xuXHRsZXQgaXNSZXNldCA9IGZhbHNlO1xuXHRyZXR1cm4ge1xuXHRcdC8qKlxuXHRcdCogQ2xlYXJzIHRoZSByZXNldCBzdGF0ZSwgc28gcXVlcmllcyBrbm93IG5vdCB0byB0cnkgYWdhaW4gdW50aWwgdGhlIGJvdW5kYXJ5IGlzIHJlc2V0IGFnYWluLlxuXHRcdCovXG5cdFx0Y2xlYXJSZXNldDogKCkgPT4ge1xuXHRcdFx0aXNSZXNldCA9IGZhbHNlO1xuXHRcdH0sXG5cdFx0LyoqXG5cdFx0KiBSZXNldHMgYW55IHF1ZXJ5IGVycm9ycyB3aXRoaW4gdGhlIGJvdW5kYXJ5LCBzbyBxdWVyaWVzIGtub3cgdGhleSBjYW4gdHJ5IGFnYWluLlxuXHRcdCovXG5cdFx0cmVzZXQ6ICgpID0+IHtcblx0XHRcdGlzUmVzZXQgPSB0cnVlO1xuXHRcdH0sXG5cdFx0LyoqXG5cdFx0KiBSZXR1cm5zIHdoZXRoZXIgdGhlIGJvdW5kYXJ5IGhhcyBiZWVuIHJlc2V0IGFuZCBub3QgeWV0IGNsZWFyZWQuXG5cdFx0KiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIGJvdW5kYXJ5IGhhcyBiZWVuIHJlc2V0IGFuZCBub3QgeWV0IGNsZWFyZWQuXG5cdFx0Ki9cblx0XHRpc1Jlc2V0OiAoKSA9PiB7XG5cdFx0XHRyZXR1cm4gaXNSZXNldDtcblx0XHR9XG5cdH07XG59XG5jb25zdCBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeUNvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KGNyZWF0ZVZhbHVlKCkpO1xuLyoqXG4qIFRoaXMgaG9vayB3aWxsIHJlc2V0IGFueSBxdWVyeSBlcnJvcnMgd2l0aGluIHRoZSBjbG9zZXN0IGBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeWAuIElmIHRoZXJlIGlzIG5vIGJvdW5kYXJ5XG4qIGRlZmluZWQgaXQgd2lsbCByZXNldCB0aGVtIGdsb2JhbGx5LlxuKiBAcmV0dXJucyBUaGUgYm91bmRhcnkncyB7QGxpbmsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlWYWx1ZX0uXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG4qIGltcG9ydCB7IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBcHAoeyBjaGlsZHJlbiB9OiB7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuKiAgIGNvbnN0IHsgcmVzZXQgfSA9IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5KClcbipcbiogICByZXR1cm4gKFxuKiAgICAgPEVycm9yQm91bmRhcnlcbiogICAgICAgb25SZXNldD17cmVzZXR9XG4qICAgICAgIGZhbGxiYWNrUmVuZGVyPXsoeyByZXNldEVycm9yQm91bmRhcnkgfSkgPT4gKFxuKiAgICAgICAgIDxkaXY+XG4qICAgICAgICAgICBUaGVyZSB3YXMgYW4gZXJyb3IhXG4qICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHJlc2V0RXJyb3JCb3VuZGFyeSgpfT5UcnkgYWdhaW48L2J1dHRvbj5cbiogICAgICAgICA8L2Rpdj5cbiogICAgICAgKX1cbiogICAgID5cbiogICAgICAge2NoaWxkcmVufVxuKiAgICAgPC9FcnJvckJvdW5kYXJ5PlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5jb25zdCB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSA9ICgpID0+IFJlYWN0LnVzZUNvbnRleHQoUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlDb250ZXh0KTtcbi8qKlxuKiBXaGVuIHVzaW5nIGBzdXNwZW5zZWAgb3IgYHRocm93T25FcnJvcmAgaW4geW91ciBxdWVyaWVzLCB5b3UgbmVlZCBhIHdheSB0byBsZXQgcXVlcmllcyBrbm93IHRoYXQgeW91IHdhbnQgdG9cbiogdHJ5IGFnYWluIHdoZW4gcmUtcmVuZGVyaW5nIGFmdGVyIHNvbWUgZXJyb3Igb2NjdXJyZWQuIFdpdGggdGhlIGBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeWAgY29tcG9uZW50IHlvdSBjYW5cbiogcmVzZXQgYW55IHF1ZXJ5IGVycm9ycyB3aXRoaW4gdGhlIGJvdW5kYXJpZXMgb2YgdGhlIGNvbXBvbmVudC5cbiogQHBhcmFtIHByb3BzIC0gVGhlIGBjaGlsZHJlbmAgdG8gcmVuZGVyLlxuKiBAcmV0dXJucyBUaGUgYGNoaWxkcmVuYCwgcmVuZGVyZWQgYXMtaXMsIG9yIGNhbGxlZCB3aXRoIHRoZSBib3VuZGFyeSdzIHtAbGluayBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeVZhbHVlfVxuKiBpZiBgY2hpbGRyZW5gIGlzIGEgZnVuY3Rpb24uXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG4qIGltcG9ydCB7IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBcHAoKSB7XG4qICAgcmV0dXJuIChcbiogICAgIDxRdWVyeUVycm9yUmVzZXRCb3VuZGFyeT5cbiogICAgICAgeyh7IHJlc2V0IH0pID0+IChcbiogICAgICAgICA8RXJyb3JCb3VuZGFyeVxuKiAgICAgICAgICAgb25SZXNldD17cmVzZXR9XG4qICAgICAgICAgICBmYWxsYmFja1JlbmRlcj17KHsgcmVzZXRFcnJvckJvdW5kYXJ5IH0pID0+IChcbiogICAgICAgICAgICAgPGRpdj5cbiogICAgICAgICAgICAgICBUaGVyZSB3YXMgYW4gZXJyb3IhXG4qICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiByZXNldEVycm9yQm91bmRhcnkoKX0+VHJ5IGFnYWluPC9idXR0b24+XG4qICAgICAgICAgICAgIDwvZGl2PlxuKiAgICAgICAgICAgKX1cbiogICAgICAgICA+XG4qICAgICAgICAgICA8UGFnZSAvPlxuKiAgICAgICAgIDwvRXJyb3JCb3VuZGFyeT5cbiogICAgICAgKX1cbiogICAgIDwvUXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmNvbnN0IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5ID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xuXHRjb25zdCBbdmFsdWVdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gY3JlYXRlVmFsdWUoKSk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5Q29udGV4dC5Qcm92aWRlciwge1xuXHRcdHZhbHVlLFxuXHRcdGNoaWxkcmVuOiB0eXBlb2YgY2hpbGRyZW4gPT09IFwiZnVuY3Rpb25cIiA/IGNoaWxkcmVuKHZhbHVlKSA6IGNoaWxkcmVuXG5cdH0pO1xufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnksIHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBzaG91bGRUaHJvd0Vycm9yIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL2Vycm9yQm91bmRhcnlVdGlscy50c1xuLyoqXG4qIFR1cm5zIG9mZiBgcmV0cnlPbk1vdW50YCBmb3IgYSBxdWVyeSB0aGF0IHRocm93cyBpdHMgZXJyb3JzICh3aXRoIGBzdXNwZW5zZWAgb3IgYHRocm93T25FcnJvcmApLFxuKiB1bmxlc3MgdGhlIGVycm9yIGJvdW5kYXJ5IGhhcyBiZWVuIHJlc2V0LCBzbyBhIHJlbW91bnQgZG9lc24ndCByZXRyeSB0aGUgZmFpbGVkIHF1ZXJ5IGJlZm9yZSB0aGVcbiogdXNlciByZXNldHMgdGhlIGJvdW5kYXJ5LiBNdXRhdGVzIHRoZSBvcHRpb25zLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBkZWZhdWx0ZWQgcXVlcnkgb3B0aW9ucyB0byBhZGp1c3QuXG4qIEBwYXJhbSBlcnJvclJlc2V0Qm91bmRhcnkgLSBUaGUgdmFsdWUgb2YgdGhlIG5lYXJlc3QgYFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5YC5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5LCB1c2VkIHRvIGV2YWx1YXRlIGEgYHRocm93T25FcnJvcmAgZnVuY3Rpb24gYWdhaW5zdCBpdHMgZXJyb3IuXG4qL1xuY29uc3QgZW5zdXJlUHJldmVudEVycm9yQm91bmRhcnlSZXRyeSA9IChvcHRpb25zLCBlcnJvclJlc2V0Qm91bmRhcnksIHF1ZXJ5KSA9PiB7XG5cdGNvbnN0IHRocm93T25FcnJvciA9IHF1ZXJ5Py5zdGF0ZS5zdGF0dXMgPT09IFwiZXJyb3JcIiAmJiB0eXBlb2Ygb3B0aW9ucy50aHJvd09uRXJyb3IgPT09IFwiZnVuY3Rpb25cIiA/IHNob3VsZFRocm93RXJyb3Iob3B0aW9ucy50aHJvd09uRXJyb3IsIFtxdWVyeS5zdGF0ZS5lcnJvciwgcXVlcnldKSA6IG9wdGlvbnMudGhyb3dPbkVycm9yO1xuXHRpZiAob3B0aW9ucy5zdXNwZW5zZSB8fCB0aHJvd09uRXJyb3IpIHtcblx0XHRpZiAoIWVycm9yUmVzZXRCb3VuZGFyeS5pc1Jlc2V0KCkpIG9wdGlvbnMucmV0cnlPbk1vdW50ID0gZmFsc2U7XG5cdH1cbn07XG4vKipcbiogQ2xlYXJzIHRoZSByZXNldCBzdGF0ZSBvZiB0aGUgZXJyb3IgYm91bmRhcnkgYWZ0ZXIgdGhlIGNvbXBvbmVudCBtb3VudHMsIHNvIGxhdGVyIGVycm9ycyBhcmVcbiogdGhyb3duIHRvIHRoZSBib3VuZGFyeSBhZ2Fpbi5cbiogQHBhcmFtIGVycm9yUmVzZXRCb3VuZGFyeSAtIFRoZSB2YWx1ZSBvZiB0aGUgbmVhcmVzdCBgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlgLlxuKi9cbmNvbnN0IHVzZUNsZWFyUmVzZXRFcnJvckJvdW5kYXJ5ID0gKGVycm9yUmVzZXRCb3VuZGFyeSkgPT4ge1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGVycm9yUmVzZXRCb3VuZGFyeS5jbGVhclJlc2V0KCk7XG5cdH0sIFtlcnJvclJlc2V0Qm91bmRhcnldKTtcbn07XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgdGhlIHF1ZXJ5IGVycm9yIHNob3VsZCBiZSB0aHJvd24gdG8gdGhlIG5lYXJlc3QgZXJyb3IgYm91bmRhcnk6IHRoZSBxdWVyeSBlcnJvcmVkXG4qIGFuZCBpc24ndCBmZXRjaGluZywgdGhlIGJvdW5kYXJ5IGhhc24ndCBiZWVuIHJlc2V0LCBhbmQgZWl0aGVyIGBzdXNwZW5zZWAgaXMgZW5hYmxlZCB3aXRoIG5vIGRhdGFcbiogb3IgYHRocm93T25FcnJvcmAgc2F5cyBzby5cbiogQHBhcmFtIHBhcmFtcyAtIFRoZSBvYnNlcnZlciBgcmVzdWx0YCwgdGhlIGBlcnJvclJlc2V0Qm91bmRhcnlgLCB0aGUgYHRocm93T25FcnJvcmAgb3B0aW9uLCB0aGVcbiogYHF1ZXJ5YCwgYW5kIHRoZSBgc3VzcGVuc2VgIG9wdGlvbi5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBlcnJvciBzaG91bGQgYmUgdGhyb3duLlxuKi9cbmNvbnN0IGdldEhhc0Vycm9yID0gKHsgcmVzdWx0LCBlcnJvclJlc2V0Qm91bmRhcnksIHRocm93T25FcnJvciwgcXVlcnksIHN1c3BlbnNlIH0pID0+IHtcblx0cmV0dXJuIHJlc3VsdC5pc0Vycm9yICYmICFlcnJvclJlc2V0Qm91bmRhcnkuaXNSZXNldCgpICYmICFyZXN1bHQuaXNGZXRjaGluZyAmJiBxdWVyeSAmJiAoc3VzcGVuc2UgJiYgcmVzdWx0LmRhdGEgPT09IHZvaWQgMCB8fCBzaG91bGRUaHJvd0Vycm9yKHRocm93T25FcnJvciwgW3Jlc3VsdC5lcnJvciwgcXVlcnldKSk7XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5LCBnZXRIYXNFcnJvciwgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyb3JCb3VuZGFyeVV0aWxzLmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvc3VzcGVuc2UudHNcbi8qKlxuKiBUaGUgZGVmYXVsdCBgdGhyb3dPbkVycm9yYCBvZiB0aGUgc3VzcGVuc2UgaG9va3M6IHRocm93cyB0aGUgZXJyb3IgdG8gdGhlIG5lYXJlc3QgZXJyb3IgYm91bmRhcnlcbiogb25seSBpZiB0aGUgcXVlcnkgaGFzIG5vIGRhdGEgdG8gc2hvdy5cbiogQHBhcmFtIF9lcnJvciAtIFRoZSBlcnJvciBvZiB0aGUgcXVlcnkuIFVudXNlZC5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRoYXQgZXJyb3JlZC5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBoYXMgbm8gZGF0YS5cbiovXG5jb25zdCBkZWZhdWx0VGhyb3dPbkVycm9yID0gKF9lcnJvciwgcXVlcnkpID0+IHF1ZXJ5LnN0YXRlLmRhdGEgPT09IHZvaWQgMDtcbi8qKlxuKiBSYWlzZXMgYHN0YWxlVGltZWAgYW5kIGEgbnVtZXJpYyBgZ2NUaW1lYCB0byBhdCBsZWFzdCAxMDAwbXMgd2hlbiBgc3VzcGVuc2VgIGlzIGVuYWJsZWQsIHNvIGFcbiogY29tcG9uZW50IHRoYXQgcmVtb3VudHMgYWZ0ZXIgc3VzcGVuZGluZyBkb2Vzbid0IHJlZmV0Y2ggcmlnaHQgYXdheSBvciBmaW5kIHRoZSBxdWVyeSBnYXJiYWdlXG4qIGNvbGxlY3RlZC4gQSBgJ3N0YXRpYydgIGBzdGFsZVRpbWVgIGlzIGtlcHQgYXMgaXMuIE11dGF0ZXMgdGhlIG9wdGlvbnMuXG4qIEBwYXJhbSBkZWZhdWx0ZWRPcHRpb25zIC0gVGhlIGRlZmF1bHRlZCBxdWVyeSBvcHRpb25zIHRvIGFkanVzdC5cbiovXG5jb25zdCBlbnN1cmVTdXNwZW5zZVRpbWVycyA9IChkZWZhdWx0ZWRPcHRpb25zKSA9PiB7XG5cdGlmIChkZWZhdWx0ZWRPcHRpb25zLnN1c3BlbnNlKSB7XG5cdFx0Y29uc3QgTUlOX1NVU1BFTlNFX1RJTUVfTVMgPSAxZTM7XG5cdFx0Y29uc3QgY2xhbXAgPSAodmFsdWUpID0+IHZhbHVlID09PSBcInN0YXRpY1wiID8gdmFsdWUgOiBNYXRoLm1heCh2YWx1ZSA/PyBNSU5fU1VTUEVOU0VfVElNRV9NUywgTUlOX1NVU1BFTlNFX1RJTUVfTVMpO1xuXHRcdGNvbnN0IG9yaWdpbmFsU3RhbGVUaW1lID0gZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWU7XG5cdFx0ZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUgPSB0eXBlb2Ygb3JpZ2luYWxTdGFsZVRpbWUgPT09IFwiZnVuY3Rpb25cIiA/ICguLi5hcmdzKSA9PiBjbGFtcChvcmlnaW5hbFN0YWxlVGltZSguLi5hcmdzKSkgOiBjbGFtcChvcmlnaW5hbFN0YWxlVGltZSk7XG5cdFx0aWYgKHR5cGVvZiBkZWZhdWx0ZWRPcHRpb25zLmdjVGltZSA9PT0gXCJudW1iZXJcIikgZGVmYXVsdGVkT3B0aW9ucy5nY1RpbWUgPSBNYXRoLm1heChkZWZhdWx0ZWRPcHRpb25zLmdjVGltZSwgTUlOX1NVU1BFTlNFX1RJTUVfTVMpO1xuXHR9XG59O1xuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgcXVlcnkgc2hvdWxkIHN1c3BlbmQ6IGBzdXNwZW5zZWAgaXMgZW5hYmxlZCBhbmQgdGhlIHJlc3VsdCBpcyBzdGlsbCBgcGVuZGluZ2AuXG4qIEBwYXJhbSBkZWZhdWx0ZWRPcHRpb25zIC0gVGhlIGRlZmF1bHRlZCBxdWVyeSBvcHRpb25zLCBpZiBhbnkuXG4qIEBwYXJhbSByZXN1bHQgLSBUaGUgY3VycmVudCByZXN1bHQgb2YgdGhlIG9ic2VydmVyLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIGNvbXBvbmVudCBzaG91bGQgc3VzcGVuZC5cbiovXG5jb25zdCBzaG91bGRTdXNwZW5kID0gKGRlZmF1bHRlZE9wdGlvbnMsIHJlc3VsdCkgPT4gZGVmYXVsdGVkT3B0aW9ucz8uc3VzcGVuc2UgJiYgcmVzdWx0LmlzUGVuZGluZztcbi8qKlxuKiBGZXRjaGVzIHRoZSBxdWVyeSBmb3IgYSBzdXNwZW5kaW5nIGNvbXBvbmVudCwgd2l0aG91dCBhZmZlY3RpbmcgdGhlIG9ic2VydmVyJ3Mgb3duIHJlc3VsdC4gSWZcbiogdGhlIGZldGNoIGZhaWxzLCB0aGUgcmVzZXQgc3RhdGUgb2YgdGhlIGVycm9yIGJvdW5kYXJ5IGlzIGNsZWFyZWQsIHNvIHRoZSBlcnJvciBpcyB0aHJvd24gdG8gaXQuXG4qIEBwYXJhbSBkZWZhdWx0ZWRPcHRpb25zIC0gVGhlIGRlZmF1bHRlZCBxdWVyeSBvcHRpb25zIHRvIGZldGNoIHdpdGguXG4qIEBwYXJhbSBvYnNlcnZlciAtIFRoZSBvYnNlcnZlciBvZiB0aGUgcXVlcnkuXG4qIEBwYXJhbSBlcnJvclJlc2V0Qm91bmRhcnkgLSBUaGUgdmFsdWUgb2YgdGhlIG5lYXJlc3QgYFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5YC5cbiogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgZmV0Y2ggc2V0dGxlcy4gSXQgbmV2ZXIgcmVqZWN0cy5cbiovXG5jb25zdCBmZXRjaE9wdGltaXN0aWMgPSAoZGVmYXVsdGVkT3B0aW9ucywgb2JzZXJ2ZXIsIGVycm9yUmVzZXRCb3VuZGFyeSkgPT4gb2JzZXJ2ZXIuZmV0Y2hPcHRpbWlzdGljKGRlZmF1bHRlZE9wdGlvbnMpLmNhdGNoKCgpID0+IHtcblx0ZXJyb3JSZXNldEJvdW5kYXJ5LmNsZWFyUmVzZXQoKTtcbn0pO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBkZWZhdWx0VGhyb3dPbkVycm9yLCBlbnN1cmVTdXNwZW5zZVRpbWVycywgZmV0Y2hPcHRpbWlzdGljLCBzaG91bGRTdXNwZW5kIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN1c3BlbnNlLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VJc1Jlc3RvcmluZyB9IGZyb20gXCIuL0lzUmVzdG9yaW5nUHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSBcIi4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanNcIjtcbmltcG9ydCB7IGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnksIGdldEhhc0Vycm9yLCB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeSB9IGZyb20gXCIuL2Vycm9yQm91bmRhcnlVdGlscy5qc1wiO1xuaW1wb3J0IHsgZW5zdXJlU3VzcGVuc2VUaW1lcnMsIGZldGNoT3B0aW1pc3RpYywgc2hvdWxkU3VzcGVuZCB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFF1ZXJpZXNPYnNlcnZlciwgUXVlcnlPYnNlcnZlciwgbm9vcCwgbm90aWZ5TWFuYWdlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VRdWVyaWVzLnRzXG4vKipcbiogVGhlIGB1c2VRdWVyaWVzYCBob29rIGNhbiBiZSB1c2VkIHRvIGZldGNoIGEgdmFyaWFibGUgbnVtYmVyIG9mIHF1ZXJpZXMuXG4qXG4qIFRoZSBgcXVlcmllc2Aga2V5IGFjY2VwdHMgYW4gYXJyYXkgd2l0aCBxdWVyeSBvcHRpb24gb2JqZWN0cyBtb3N0bHkgaWRlbnRpY2FsIHRvIGB1c2VRdWVyeWAg4oCUIHRoZSB0b3AtbGV2ZWxcbiogYHN1YnNjcmliZWRgIG9wdGlvbiBpc24ndCBhY2NlcHRlZCBwZXIgcXVlcnkgKHNlZSBgcGxhY2Vob2xkZXJEYXRhYCBiZWxvdyBmb3IgYW5vdGhlciBkaWZmZXJlbmNlKS4gQSBjdXN0b21cbiogYFF1ZXJ5Q2xpZW50YCBpcyBzdXBwbGllZCBvbmNlLCBhcyBgdXNlUXVlcmllc2AnIG93biB0b3AtbGV2ZWwgc2Vjb25kIGFyZ3VtZW50LCByYXRoZXIgdGhhbiBwZXIgcXVlcnkuXG4qXG4qIEhhdmluZyB0aGUgc2FtZSBxdWVyeSBrZXkgbW9yZSB0aGFuIG9uY2UgaW4gdGhlIGFycmF5IG9mIHF1ZXJ5IG9iamVjdHMgbWF5IGNhdXNlIHNvbWUgZGF0YSB0byBiZSBzaGFyZWRcbiogYmV0d2VlbiBxdWVyaWVzLiBUbyBhdm9pZCB0aGlzLCBjb25zaWRlciBkZS1kdXBsaWNhdGluZyB0aGUgcXVlcmllcyBhbmQgbWFwIHRoZSByZXN1bHRzIGJhY2sgdG8gdGhlIGRlc2lyZWRcbiogc3RydWN0dXJlLlxuKlxuKiBUaGUgYGNvbWJpbmVgIG9wdGlvbiBjYW4gYmUgdXNlZCB0byBjb21iaW5lIHRoZSByZXN1bHRzIG9mIHRoZSBxdWVyaWVzIGludG8gYSBzaW5nbGUgdmFsdWUuIFRoZSByZXN1bHQgd2lsbFxuKiBiZSBzdHJ1Y3R1cmFsbHkgc2hhcmVkIHRvIGJlIGFzIHJlZmVyZW50aWFsbHkgc3RhYmxlIGFzIHBvc3NpYmxlLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBgcXVlcmllc2AgYXJyYXkgdG8gcnVuLCBhbmQgdGhlIG9wdGlvbmFsIGBjb21iaW5lYCBhbmQgYHN1YnNjcmliZWRgIG9wdGlvbnMuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHByb3ZpZGUgYSBjdXN0b20gYFF1ZXJ5Q2xpZW50YC4gT3RoZXJ3aXNlLCB0aGUgb25lIGZyb20gdGhlIG5lYXJlc3QgY29udGV4dFxuKiB3aWxsIGJlIHVzZWQuXG4qIEByZXR1cm5zIFRoZSBjb21iaW5lZCByZXN1bHQuIFdpdGhvdXQgYGNvbWJpbmVgLCB0aGlzIGlzIGFuIGFycmF5IHdpdGggYWxsIHRoZSBxdWVyeSByZXN1bHRzLCBpbiB0aGUgc2FtZVxuKiBvcmRlciBhcyB0aGUgaW5wdXQuIFdoZW4gYGNvbWJpbmVgIGlzIHByb3ZpZGVkLCB0aGlzIGlzIHRoZSB2YWx1ZSByZXR1cm5lZCBieSBgY29tYmluZWAgaW5zdGVhZC5cbiogQHRocm93cyB7RXJyb3J9IFRoZSBlcnJvciBvZiB0aGUgZmlyc3QgcXVlcnkgdGhhdCBzaG91bGQgYmUgdGhyb3duIHRvIHRoZSBuZWFyZXN0IGVycm9yIGJvdW5kYXJ5IChzZWVcbiogYHRocm93T25FcnJvcmApLiBXaGlsZSBzdXNwZW5kaW5nLCBpdCB0aHJvd3MgYSBwcm9taXNlIGluc3RlYWQuXG4qIEByZW1hcmtzIFRoZSBgY29tYmluZWAgZnVuY3Rpb24gb25seSByZS1ydW5zIGlmIGl0IGNoYW5nZWQgcmVmZXJlbnRpYWxseSwgb3IgaWYgYW55IG9mIHRoZSBxdWVyeSByZXN1bHRzXG4qIGNoYW5nZWQuIEFuIGlubGluZWQgYGNvbWJpbmVgIGZ1bmN0aW9uLCBhcyBzaG93biBpbiB0aGUgZXhhbXBsZSBiZWxvdywgdGhlcmVmb3JlIHJ1bnMgb24gZXZlcnkgcmVuZGVyIOKAlCB3cmFwXG4qIGl0IGluIGB1c2VDYWxsYmFja2AsIG9yIGV4dHJhY3QgaXQgdG8gYSBzdGFibGUgZnVuY3Rpb24gcmVmZXJlbmNlIGlmIGl0IGRvZXNuJ3QgaGF2ZSBhbnkgZGVwZW5kZW5jaWVzLCB0b1xuKiBhdm9pZCB0aGF0LlxuKlxuKiBVbmxpa2UgYHVzZVF1ZXJ5YCwgYHVzZVF1ZXJpZXNgIGNhbm5vdCBpbmZlciB0aGUgYGRhdGFgIGFyZ3VtZW50IG9mIGFuIF9pbmxpbmVfIGBzZWxlY3RgIGZyb20gaXRzIHNpYmxpbmdcbiogYHF1ZXJ5Rm5gLiBCZWNhdXNlIGB1c2VRdWVyaWVzYCBpbmZlcnMgdGhlIHR5cGUgb2YgdGhlIHdob2xlIGBxdWVyaWVzYCBhcnJheSBhdCBvbmNlLCB0aGUgYHNlbGVjdGAgcGFyYW1ldGVyXG4qIG9mIGEgcXVlcnkgb2JqZWN0IHdyaXR0ZW4gaW5saW5lIGNhbm5vdCBiZSBjb250ZXh0dWFsbHkgdHlwZWQgZnJvbSB0aGF0IHNhbWUgb2JqZWN0J3MgYHF1ZXJ5Rm5gLCBzbyBpdCBmYWxsc1xuKiBiYWNrIHRvIGB1bmtub3duYCDigJQgYSBba25vd24gVHlwZVNjcmlwdCBsaW1pdGF0aW9uXShodHRwczovL2dpdGh1Yi5jb20vVGFuU3RhY2svcXVlcnkvaXNzdWVzLzY1NTYpLiBBbm5vdGF0ZVxuKiB0aGUgYHNlbGVjdGAgcGFyYW1ldGVyIGV4cGxpY2l0bHksIG9yIGRlZmluZSB0aGUgcXVlcnkgd2l0aCB7QGxpbmsgcXVlcnlPcHRpb25zfSwgd2hpY2ggcmVzb2x2ZXMgaXRzIHR5cGVzIGluXG4qIGEgc2luZ2xlIG9iamVjdCBfYmVmb3JlXyBpdCByZWFjaGVzIGB1c2VRdWVyaWVzYCwgdG8gd29yayBhcm91bmQgdGhpcyDigJQgc2VlIHRoZSBleGFtcGxlIGJlbG93LiBUaGUgc2FtZVxuKiBsaW1pdGF0aW9uIGFwcGxpZXMgdG8ge0BsaW5rIHVzZVN1c3BlbnNlUXVlcmllc30uXG4qXG4qIGBwbGFjZWhvbGRlckRhdGFgIGlzIHN1cHBvcnRlZCBoZXJlIHRvbywgYnV0IHVubGlrZSBgdXNlUXVlcnlgLCBpdCBkb2Vzbid0IHJlY2VpdmUgaW5mb3JtYXRpb24gZnJvbVxuKiBwcmV2aW91c2x5IHJlbmRlcmVkIHF1ZXJpZXMsIGJlY2F1c2UgdGhlIG51bWJlciBvZiBxdWVyaWVzIGNhbiBkaWZmZXIgYmV0d2VlbiByZW5kZXJzLlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlUXVlcmllcyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUG9zdHMoeyBpZHMgfTogeyBpZHM6IEFycmF5PG51bWJlcj4gfSkge1xuKiAgIGNvbnN0IHBvc3RRdWVyaWVzID0gdXNlUXVlcmllcyh7XG4qICAgICBxdWVyaWVzOiBpZHMubWFwKChpZCkgPT4gKHtcbiogICAgICAgcXVlcnlLZXk6IFsncG9zdCcsIGlkXSxcbiogICAgICAgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KGlkKSxcbiogICAgICAgc3RhbGVUaW1lOiBJbmZpbml0eSxcbiogICAgIH0pKSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8dWw+XG4qICAgICAgIHtwb3N0UXVlcmllcy5tYXAoKHF1ZXJ5LCBpbmRleCkgPT4ge1xuKiAgICAgICAgIGlmIChxdWVyeS5pc1BlbmRpbmcpIHJldHVybiA8bGkga2V5PXtpZHNbaW5kZXhdfT5Mb2FkaW5nLi4uPC9saT5cbiogICAgICAgICBpZiAocXVlcnkuaXNFcnJvcikgcmV0dXJuIDxsaSBrZXk9e2lkc1tpbmRleF19PkVycm9yOiB7cXVlcnkuZXJyb3IubWVzc2FnZX08L2xpPlxuKiAgICAgICAgIHJldHVybiA8bGkga2V5PXtpZHNbaW5kZXhdfT57cXVlcnkuZGF0YS50aXRsZX08L2xpPlxuKiAgICAgICB9KX1cbiogICAgIDwvdWw+XG4qICAgKVxuKiB9XG4qIGBgYFxuKiBAZXhhbXBsZVxuKiBDb21iaW5pbmcgcmVzdWx0cyBpbnRvIGEgc2luZ2xlIHZhbHVlOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlUXVlcmllcyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUG9zdHMoeyBpZHMgfTogeyBpZHM6IEFycmF5PG51bWJlcj4gfSkge1xuKiAgIGNvbnN0IHsgZGF0YSwgaXNQZW5kaW5nLCBpc0Vycm9yIH0gPSB1c2VRdWVyaWVzKHtcbiogICAgIHF1ZXJpZXM6IGlkcy5tYXAoKGlkKSA9PiAoe1xuKiAgICAgICBxdWVyeUtleTogWydwb3N0JywgaWRdLFxuKiAgICAgICBxdWVyeUZuOiAoKSA9PiBmZXRjaFBvc3QoaWQpLFxuKiAgICAgfSkpLFxuKiAgICAgY29tYmluZTogKHBvc3RRdWVyaWVzKSA9PiB7XG4qICAgICAgIHJldHVybiB7XG4qICAgICAgICAgZGF0YTogcG9zdFF1ZXJpZXMubWFwKChxdWVyeSkgPT4gcXVlcnkuZGF0YSksXG4qICAgICAgICAgaXNQZW5kaW5nOiBwb3N0UXVlcmllcy5zb21lKChxdWVyeSkgPT4gcXVlcnkuaXNQZW5kaW5nKSxcbiogICAgICAgICBpc0Vycm9yOiBwb3N0UXVlcmllcy5zb21lKChxdWVyeSkgPT4gcXVlcnkuaXNFcnJvciksXG4qICAgICAgIH1cbiogICAgIH0sXG4qICAgfSlcbipcbiogICBpZiAoaXNQZW5kaW5nKSByZXR1cm4gJ0xvYWRpbmcuLi4nXG4qICAgaWYgKGlzRXJyb3IpIHJldHVybiAnRXJyb3IgbG9hZGluZyBwb3N0cydcbipcbiogICByZXR1cm4gKFxuKiAgICAgPHVsPlxuKiAgICAgICB7ZGF0YS5tYXAoKHBvc3QpID0+IChcbiogICAgICAgICA8bGkga2V5PXtwb3N0Py5pZH0+e3Bvc3Q/LnRpdGxlfTwvbGk+XG4qICAgICAgICkpfVxuKiAgICAgPC91bD5cbiogICApXG4qIH1cbiogYGBgXG4qIEBleGFtcGxlXG4qIFR5cGluZyBgc2VsZWN0YCB2aWEge0BsaW5rIHF1ZXJ5T3B0aW9uc30uIE5vdGUgdGhhdCBzcHJlYWRpbmcgYSBgcXVlcnlPcHRpb25zYCByZXN1bHQgYW5kIG92ZXJyaWRpbmdcbiogYHNlbGVjdGAgaW5saW5lIHN0aWxsIGZhbGxzIGJhY2sgdG8gYHVua25vd25gIOKAlCB3cmFwIHRoZSBzcHJlYWQgaW4gYHF1ZXJ5T3B0aW9uc2AgYWdhaW4gc28gdGhlIG92ZXJyaWRlIGlzXG4qIHJlc29sdmVkIGJlZm9yZSBpdCByZWFjaGVzIGB1c2VRdWVyaWVzYDpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHF1ZXJ5T3B0aW9ucywgdXNlUXVlcmllcyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogY29uc3QgcG9zdE9wdGlvbnMgPSAoaWQ6IG51bWJlcikgPT5cbiogICBxdWVyeU9wdGlvbnMoe1xuKiAgICAgcXVlcnlLZXk6IFsncG9zdCcsIGlkXSxcbiogICAgIHF1ZXJ5Rm46ICgpID0+IGZldGNoUG9zdChpZCksXG4qICAgfSlcbipcbiogZnVuY3Rpb24gUG9zdFRpdGxlKHsgaWQgfTogeyBpZDogbnVtYmVyIH0pIHtcbiogICBjb25zdCBbeyBkYXRhOiBicm9rZW4gfV0gPSB1c2VRdWVyaWVzKHtcbiogICAgIHF1ZXJpZXM6IFtcbiogICAgICAge1xuKiAgICAgICAgIC4uLnBvc3RPcHRpb25zKGlkKSxcbiogICAgICAgICAvLyDinYwgYGRhdGFgIGlzIGB1bmtub3duYCBoZXJlXG4qICAgICAgICAgc2VsZWN0OiAoZGF0YSkgPT4gZGF0YS50aXRsZSxcbiogICAgICAgfSxcbiogICAgIF0sXG4qICAgfSlcbipcbiogICBjb25zdCBbeyBkYXRhOiBmaXhlZCB9XSA9IHVzZVF1ZXJpZXMoe1xuKiAgICAgcXVlcmllczogW1xuKiAgICAgICBxdWVyeU9wdGlvbnMoe1xuKiAgICAgICAgIC4uLnBvc3RPcHRpb25zKGlkKSxcbiogICAgICAgICAvLyDinIUgYGRhdGFgIGlzIGBQb3N0YFxuKiAgICAgICAgIHNlbGVjdDogKGRhdGEpID0+IGRhdGEudGl0bGUsXG4qICAgICAgIH0pLFxuKiAgICAgXSxcbiogICB9KVxuKlxuKiAgIHJldHVybiA8aDE+e2ZpeGVkfTwvaDE+XG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlUXVlcmllcyh7IHF1ZXJpZXMsIC4uLm9wdGlvbnMgfSwgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRjb25zdCBpc1Jlc3RvcmluZyA9IHVzZUlzUmVzdG9yaW5nKCk7XG5cdGNvbnN0IGVycm9yUmVzZXRCb3VuZGFyeSA9IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5KCk7XG5cdGNvbnN0IHN1YnNjcmliZWQgPSBvcHRpb25zLnN1YnNjcmliZWQgIT09IGZhbHNlO1xuXHRjb25zdCBkZWZhdWx0ZWRRdWVyaWVzID0gUmVhY3QudXNlTWVtbygoKSA9PiBxdWVyaWVzLm1hcCgob3B0cykgPT4ge1xuXHRcdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSBjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRzKTtcblx0XHRkZWZhdWx0ZWRPcHRpb25zLl9vcHRpbWlzdGljUmVzdWx0cyA9IGlzUmVzdG9yaW5nID8gXCJpc1Jlc3RvcmluZ1wiIDogc3Vic2NyaWJlZCA/IFwib3B0aW1pc3RpY1wiIDogdm9pZCAwO1xuXHRcdHJldHVybiBkZWZhdWx0ZWRPcHRpb25zO1xuXHR9KSwgW1xuXHRcdHF1ZXJpZXMsXG5cdFx0Y2xpZW50LFxuXHRcdGlzUmVzdG9yaW5nLFxuXHRcdHN1YnNjcmliZWRcblx0XSk7XG5cdGRlZmF1bHRlZFF1ZXJpZXMuZm9yRWFjaCgocXVlcnlPcHRpb25zKSA9PiB7XG5cdFx0ZW5zdXJlU3VzcGVuc2VUaW1lcnMocXVlcnlPcHRpb25zKTtcblx0XHRjb25zdCBxdWVyeSA9IGNsaWVudC5nZXRRdWVyeUNhY2hlKCkuZ2V0KHF1ZXJ5T3B0aW9ucy5xdWVyeUhhc2gpO1xuXHRcdGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnkocXVlcnlPcHRpb25zLCBlcnJvclJlc2V0Qm91bmRhcnksIHF1ZXJ5KTtcblx0fSk7XG5cdHVzZUNsZWFyUmVzZXRFcnJvckJvdW5kYXJ5KGVycm9yUmVzZXRCb3VuZGFyeSk7XG5cdGNvbnN0IFtvYnNlcnZlcl0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiBuZXcgUXVlcmllc09ic2VydmVyKGNsaWVudCwgZGVmYXVsdGVkUXVlcmllcywgb3B0aW9ucykpO1xuXHRjb25zdCBbb3B0aW1pc3RpY1Jlc3VsdCwgZ2V0Q29tYmluZWRSZXN1bHQsIHRyYWNrUmVzdWx0XSA9IG9ic2VydmVyLmdldE9wdGltaXN0aWNSZXN1bHQoZGVmYXVsdGVkUXVlcmllcywgb3B0aW9ucy5jb21iaW5lKTtcblx0Y29uc3Qgc2hvdWxkU3Vic2NyaWJlID0gIWlzUmVzdG9yaW5nICYmIHN1YnNjcmliZWQ7XG5cdFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFJlYWN0LnVzZUNhbGxiYWNrKChvblN0b3JlQ2hhbmdlKSA9PiBzaG91bGRTdWJzY3JpYmUgPyBvYnNlcnZlci5zdWJzY3JpYmUobm90aWZ5TWFuYWdlci5iYXRjaENhbGxzKG9uU3RvcmVDaGFuZ2UpKSA6IG5vb3AsIFtvYnNlcnZlciwgc2hvdWxkU3Vic2NyaWJlXSksICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSwgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpKTtcblx0UmVhY3QudXNlRWZmZWN0KCgpID0+IHtcblx0XHRvYnNlcnZlci5zZXRRdWVyaWVzKGRlZmF1bHRlZFF1ZXJpZXMsIG9wdGlvbnMpO1xuXHR9LCBbXG5cdFx0ZGVmYXVsdGVkUXVlcmllcyxcblx0XHRvcHRpb25zLFxuXHRcdG9ic2VydmVyXG5cdF0pO1xuXHRjb25zdCBzdXNwZW5zZVByb21pc2VzID0gb3B0aW1pc3RpY1Jlc3VsdC5zb21lKChyZXN1bHQsIGluZGV4KSA9PiBzaG91bGRTdXNwZW5kKGRlZmF1bHRlZFF1ZXJpZXNbaW5kZXhdLCByZXN1bHQpKSA/IG9wdGltaXN0aWNSZXN1bHQuZmxhdE1hcCgocmVzdWx0LCBpbmRleCkgPT4ge1xuXHRcdGNvbnN0IG9wdHMgPSBkZWZhdWx0ZWRRdWVyaWVzW2luZGV4XTtcblx0XHRpZiAob3B0cyAmJiBzaG91bGRTdXNwZW5kKG9wdHMsIHJlc3VsdCkpIHtcblx0XHRcdGNvbnN0IHF1ZXJ5T2JzZXJ2ZXIgPSBuZXcgUXVlcnlPYnNlcnZlcihjbGllbnQsIG9wdHMpO1xuXHRcdFx0cmV0dXJuIGZldGNoT3B0aW1pc3RpYyhvcHRzLCBxdWVyeU9ic2VydmVyLCBlcnJvclJlc2V0Qm91bmRhcnkpO1xuXHRcdH1cblx0XHRyZXR1cm4gW107XG5cdH0pIDogW107XG5cdGlmIChzdXNwZW5zZVByb21pc2VzLmxlbmd0aCA+IDApIHRocm93IFByb21pc2UuYWxsKHN1c3BlbnNlUHJvbWlzZXMpO1xuXHRjb25zdCBmaXJzdFNpbmdsZVJlc3VsdFdoaWNoU2hvdWxkVGhyb3cgPSBvcHRpbWlzdGljUmVzdWx0LmZpbmQoKHJlc3VsdCwgaW5kZXgpID0+IHtcblx0XHRjb25zdCBxdWVyeSA9IGRlZmF1bHRlZFF1ZXJpZXNbaW5kZXhdO1xuXHRcdHJldHVybiBxdWVyeSAmJiBnZXRIYXNFcnJvcih7XG5cdFx0XHRyZXN1bHQsXG5cdFx0XHRlcnJvclJlc2V0Qm91bmRhcnksXG5cdFx0XHR0aHJvd09uRXJyb3I6IHF1ZXJ5LnRocm93T25FcnJvcixcblx0XHRcdHF1ZXJ5OiBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmdldChxdWVyeS5xdWVyeUhhc2gpLFxuXHRcdFx0c3VzcGVuc2U6IHF1ZXJ5LnN1c3BlbnNlXG5cdFx0fSk7XG5cdH0pO1xuXHRpZiAoZmlyc3RTaW5nbGVSZXN1bHRXaGljaFNob3VsZFRocm93KSB0aHJvdyBmaXJzdFNpbmdsZVJlc3VsdFdoaWNoU2hvdWxkVGhyb3cuZXJyb3I7XG5cdHJldHVybiBnZXRDb21iaW5lZFJlc3VsdCh0cmFja1Jlc3VsdCgpKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlUXVlcmllcyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VRdWVyaWVzLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VJc1Jlc3RvcmluZyB9IGZyb20gXCIuL0lzUmVzdG9yaW5nUHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSBcIi4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanNcIjtcbmltcG9ydCB7IGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnksIGdldEhhc0Vycm9yLCB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeSB9IGZyb20gXCIuL2Vycm9yQm91bmRhcnlVdGlscy5qc1wiO1xuaW1wb3J0IHsgZW5zdXJlU3VzcGVuc2VUaW1lcnMsIGZldGNoT3B0aW1pc3RpYywgc2hvdWxkU3VzcGVuZCB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IG5vb3AsIG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlQmFzZVF1ZXJ5LnRzXG4vKipcbiogQmFzZSBpbXBsZW1lbnRhdGlvbiBzaGFyZWQgYnkgYHVzZVF1ZXJ5YCwgYHVzZUluZmluaXRlUXVlcnlgLCBgdXNlU3VzcGVuc2VRdWVyeWAsIGFuZFxuKiBgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5YC5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgb3B0aW9ucyBwYXNzZWQgdG8gdGhlIGNhbGxpbmcgaG9vay5cbiogQHBhcmFtIE9ic2VydmVyIC0gVGhlIG9ic2VydmVyIGNsYXNzIGZyb20gcXVlcnktY29yZSAoYFF1ZXJ5T2JzZXJ2ZXJgIG9yXG4qIGBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXJgKS5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0XG4qIGNvbnRleHQgd2lsbCBiZSB1c2VkLlxuKiBAcmV0dXJucyBUaGUgcXVlcnkgcmVzdWx0LCB0cmFja2luZyB3aGljaCBwcm9wZXJ0aWVzIGFyZSByZWFkIHVubGVzcyBgbm90aWZ5T25DaGFuZ2VQcm9wc2AgaXNcbiogc2V0LlxuKiBAdGhyb3dzIHtFcnJvcn0gSWYgYG9wdGlvbnNgIGlzIG5vdCBhbiBvYmplY3QgKG91dHNpZGUgcHJvZHVjdGlvbiksIG9yIHRoZSBxdWVyeSBlcnJvciB3aGVuIGl0IHNob3VsZCBiZVxuKiB0aHJvd24gdG8gdGhlIG5lYXJlc3QgZXJyb3IgYm91bmRhcnkgKHNlZSBgdGhyb3dPbkVycm9yYCkuIFdoaWxlIHN1c3BlbmRpbmcsIGl0IHRocm93cyBhIHByb21pc2UgaW5zdGVhZC5cbiovXG5mdW5jdGlvbiB1c2VCYXNlUXVlcnkob3B0aW9ucywgT2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAodHlwZW9mIG9wdGlvbnMgIT09IFwib2JqZWN0XCIgfHwgQXJyYXkuaXNBcnJheShvcHRpb25zKSkgdGhyb3cgbmV3IEVycm9yKFwiQmFkIGFyZ3VtZW50IHR5cGUuIFN0YXJ0aW5nIHdpdGggdjUsIG9ubHkgdGhlIFxcXCJPYmplY3RcXFwiIGZvcm0gaXMgYWxsb3dlZCB3aGVuIGNhbGxpbmcgcXVlcnkgcmVsYXRlZCBmdW5jdGlvbnMuIFBsZWFzZSB1c2UgdGhlIGVycm9yIHN0YWNrIHRvIGZpbmQgdGhlIGN1bHByaXQgY2FsbC4gTW9yZSBpbmZvIGhlcmU6IGh0dHBzOi8vdGFuc3RhY2suY29tL3F1ZXJ5L2xhdGVzdC9kb2NzL3JlYWN0L2d1aWRlcy9taWdyYXRpbmctdG8tdjUjc3VwcG9ydHMtYS1zaW5nbGUtc2lnbmF0dXJlLW9uZS1vYmplY3RcIik7XG5cdH1cblx0Y29uc3QgaXNSZXN0b3JpbmcgPSB1c2VJc1Jlc3RvcmluZygpO1xuXHRjb25zdCBlcnJvclJlc2V0Qm91bmRhcnkgPSB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSgpO1xuXHRjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG5cdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSBjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcblx0Y29uc3QgcXVlcnkgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmdldChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCk7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAoIWRlZmF1bHRlZE9wdGlvbnMucXVlcnlGbikgY29uc29sZS5lcnJvcihgWyR7ZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUhhc2h9XTogTm8gcXVlcnlGbiB3YXMgcGFzc2VkIGFzIGFuIG9wdGlvbiwgYW5kIG5vIGRlZmF1bHQgcXVlcnlGbiB3YXMgZm91bmQuIFRoZSBxdWVyeUZuIHBhcmFtZXRlciBpcyBvbmx5IG9wdGlvbmFsIHdoZW4gdXNpbmcgYSBkZWZhdWx0IHF1ZXJ5Rm4uIE1vcmUgaW5mbyBoZXJlOiBodHRwczovL3RhbnN0YWNrLmNvbS9xdWVyeS9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvZ3VpZGVzL2RlZmF1bHQtcXVlcnktZnVuY3Rpb25gKTtcblx0fVxuXHRjb25zdCBzdWJzY3JpYmVkID0gb3B0aW9ucy5zdWJzY3JpYmVkICE9PSBmYWxzZTtcblx0ZGVmYXVsdGVkT3B0aW9ucy5fb3B0aW1pc3RpY1Jlc3VsdHMgPSBpc1Jlc3RvcmluZyA/IFwiaXNSZXN0b3JpbmdcIiA6IHN1YnNjcmliZWQgPyBcIm9wdGltaXN0aWNcIiA6IHZvaWQgMDtcblx0ZW5zdXJlU3VzcGVuc2VUaW1lcnMoZGVmYXVsdGVkT3B0aW9ucyk7XG5cdGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnkoZGVmYXVsdGVkT3B0aW9ucywgZXJyb3JSZXNldEJvdW5kYXJ5LCBxdWVyeSk7XG5cdHVzZUNsZWFyUmVzZXRFcnJvckJvdW5kYXJ5KGVycm9yUmVzZXRCb3VuZGFyeSk7XG5cdGNvbnN0IFtvYnNlcnZlcl0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiBuZXcgT2JzZXJ2ZXIoY2xpZW50LCBkZWZhdWx0ZWRPcHRpb25zKSk7XG5cdGNvbnN0IHJlc3VsdCA9IG9ic2VydmVyLmdldE9wdGltaXN0aWNSZXN1bHQoZGVmYXVsdGVkT3B0aW9ucyk7XG5cdGNvbnN0IHNob3VsZFN1YnNjcmliZSA9ICFpc1Jlc3RvcmluZyAmJiBzdWJzY3JpYmVkO1xuXHRSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShSZWFjdC51c2VDYWxsYmFjaygob25TdG9yZUNoYW5nZSkgPT4ge1xuXHRcdGNvbnN0IHVuc3Vic2NyaWJlID0gc2hvdWxkU3Vic2NyaWJlID8gb2JzZXJ2ZXIuc3Vic2NyaWJlKG5vdGlmeU1hbmFnZXIuYmF0Y2hDYWxscyhvblN0b3JlQ2hhbmdlKSkgOiBub29wO1xuXHRcdG9ic2VydmVyLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdHJldHVybiB1bnN1YnNjcmliZTtcblx0fSwgW29ic2VydmVyLCBzaG91bGRTdWJzY3JpYmVdKSwgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpLCAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCkpO1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdG9ic2VydmVyLnNldE9wdGlvbnMoZGVmYXVsdGVkT3B0aW9ucyk7XG5cdH0sIFtkZWZhdWx0ZWRPcHRpb25zLCBvYnNlcnZlcl0pO1xuXHRpZiAoc2hvdWxkU3VzcGVuZChkZWZhdWx0ZWRPcHRpb25zLCByZXN1bHQpKSB0aHJvdyBmZXRjaE9wdGltaXN0aWMoZGVmYXVsdGVkT3B0aW9ucywgb2JzZXJ2ZXIsIGVycm9yUmVzZXRCb3VuZGFyeSk7XG5cdGlmIChnZXRIYXNFcnJvcih7XG5cdFx0cmVzdWx0LFxuXHRcdGVycm9yUmVzZXRCb3VuZGFyeSxcblx0XHR0aHJvd09uRXJyb3I6IGRlZmF1bHRlZE9wdGlvbnMudGhyb3dPbkVycm9yLFxuXHRcdHF1ZXJ5LFxuXHRcdHN1c3BlbnNlOiBkZWZhdWx0ZWRPcHRpb25zLnN1c3BlbnNlXG5cdH0pKSB0aHJvdyByZXN1bHQuZXJyb3I7XG5cdHJldHVybiAhZGVmYXVsdGVkT3B0aW9ucy5ub3RpZnlPbkNoYW5nZVByb3BzID8gb2JzZXJ2ZXIudHJhY2tSZXN1bHQocmVzdWx0KSA6IHJlc3VsdDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlQmFzZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUJhc2VRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUJhc2VRdWVyeSB9IGZyb20gXCIuL3VzZUJhc2VRdWVyeS5qc1wiO1xuaW1wb3J0IHsgUXVlcnlPYnNlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VRdWVyeS50c1xuZnVuY3Rpb24gdXNlUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0cmV0dXJuIHVzZUJhc2VRdWVyeShvcHRpb25zLCBRdWVyeU9ic2VydmVyLCBxdWVyeUNsaWVudCk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVF1ZXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgZGVmYXVsdFRocm93T25FcnJvciB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlUXVlcnkgfSBmcm9tIFwiLi91c2VCYXNlUXVlcnkuanNcIjtcbmltcG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIsIHNraXBUb2tlbiB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VTdXNwZW5zZVF1ZXJ5LnRzXG4vKipcbiogVGhlIG9wdGlvbnMgZm9yIGB1c2VTdXNwZW5zZVF1ZXJ5YCBhcmUgdGhlIHNhbWUgYXMgZm9yIGB1c2VRdWVyeWAsIGV4Y2VwdCBmb3IgYHRocm93T25FcnJvcmAsIGBlbmFibGVkYCwgYW5kXG4qIGBwbGFjZWhvbGRlckRhdGFgIOKAlCBhbmQgYHF1ZXJ5Rm5gIG1heSBub3QgYmUgYHNraXBUb2tlbmAsIHNpbmNlIFN1c3BlbnNlIGhvb2tzIGNhbid0IHJlbmRlciBhIFwiZGlzYWJsZWRcIiBzdGF0ZS5cbipcbiogQ2F2ZWF0OiBjYW5jZWxsYXRpb24gZG9lcyBub3Qgd29yay5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUge0BsaW5rIFVzZVN1c3BlbnNlUXVlcnlPcHRpb25zfSB0byB1c2Ug4oCUIHRoZSBzYW1lIG9wdGlvbnMgYXMgYHVzZVF1ZXJ5YCwgbWludXMgdGhlIG9uZXMgbGlzdGVkIGFib3ZlLlxuKiBAcGFyYW0gcXVlcnlDbGllbnQgLSBVc2UgdGhpcyB0byB1c2UgYSBjdXN0b20gYFF1ZXJ5Q2xpZW50YC4gT3RoZXJ3aXNlLCB0aGUgb25lIGZyb20gdGhlIG5lYXJlc3QgY29udGV4dCB3aWxsXG4qIGJlIHVzZWQuXG4qIEByZXR1cm5zIFRoZSBzYW1lIG9iamVjdCBhcyBgdXNlUXVlcnlgLCBleGNlcHQgdGhhdCBgZGF0YWAgaXMgZ3VhcmFudGVlZCB0byBiZSBkZWZpbmVkLCBgaXNQbGFjZWhvbGRlckRhdGFgXG4qIGlzIG1pc3NpbmcsIGFuZCBgc3RhdHVzYCBpcyBlaXRoZXIgYHN1Y2Nlc3NgIG9yIGBlcnJvcmAgKHdpdGggdGhlIGRlcml2ZWQgZmxhZ3Mgc2V0IGFjY29yZGluZ2x5KS5cbiogQHJlbWFya3MgTXVsdGlwbGUgYHVzZVN1c3BlbnNlUXVlcnlgIGNhbGxzIGluIHRoZSBzYW1lIGNvbXBvbmVudCBzdXNwZW5kIHNlcmlhbGx5LCBjYXVzaW5nIGEgcmVxdWVzdFxuKiB3YXRlcmZhbGwg4oCUIGVhY2ggb25lIGJsb2NrcyByZW5kZXJpbmcgdW50aWwgaXQgcmVzb2x2ZXMsIHNvIHRoZSBuZXh0IGRvZXNuJ3QgZXZlbiBzdGFydCBmZXRjaGluZyB1bnRpbCB0aGVuLlxuKiBVc2Uge0BsaW5rIHVzZVN1c3BlbnNlUXVlcmllc30gaW5zdGVhZCB3aGVuIHlvdSBoYXZlIG1vcmUgdGhhbiBvbmUgc3VzcGVuc2VmdWwgcXVlcnkgaW4gYSBjb21wb25lbnQsIHNvIHRoZXlcbiogZmV0Y2ggaW4gcGFyYWxsZWwuXG4qIEBleGFtcGxlXG4qIFRoZSBxdWVyeSBlcnJvciBpcyB0aHJvd24gaWYgdGhlIGZldGNoIGZhaWxzIGFuZCBubyBjYWNoZWQgZGF0YSBleGlzdHMgeWV0LCBzbyBhbiBlcnJvciBib3VuZGFyeSBpc1xuKiByZXF1aXJlZCBhcm91bmQgYDxTdXNwZW5zZT5gLiBBIGZhaWxlZCBiYWNrZ3JvdW5kIHJlZmV0Y2ggaW5zdGVhZCBjb250aW51ZXMgdG8gcmVuZGVyIHRoZSBjYWNoZWQgZGF0YS5cbiogVXNlIHtAbGluayBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeX0gdG8gbGV0IHRoZSB1c2VyIHJldHJ5IGFmdGVyIHN1Y2ggYW4gZXJyb3I6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBTdXNwZW5zZSB9IGZyb20gJ3JlYWN0J1xuKiBpbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG4qIGltcG9ydCB7IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCB1c2VTdXNwZW5zZVF1ZXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBQb3N0cygpIHtcbiogICAvLyBgZGF0YWAgaXMgZ3VhcmFudGVlZCB0byBiZSBkZWZpbmVkIGhlcmUg4oCUIG5vIGBpc1BlbmRpbmdgIGNoZWNrIG5lZWRlZC5cbiogICBjb25zdCB7IGRhdGEsIGlzRmV0Y2hpbmcgfSA9IHVzZVN1c3BlbnNlUXVlcnkoe1xuKiAgICAgcXVlcnlLZXk6IFsncG9zdHMnXSxcbiogICAgIHF1ZXJ5Rm46IGZldGNoUG9zdHMsXG4qICAgfSlcbipcbiogICByZXR1cm4gKFxuKiAgICAgPGRpdj5cbiogICAgICAgPGgxPlBvc3RzIHtpc0ZldGNoaW5nID8gJyhyZWZyZXNoaW5nLi4uKScgOiBudWxsfTwvaDE+XG4qICAgICAgIDx1bD5cbiogICAgICAgICB7ZGF0YS5tYXAoKHBvc3QpID0+IChcbiogICAgICAgICAgIDxsaSBrZXk9e3Bvc3QuaWR9Pntwb3N0LnRpdGxlfTwvbGk+XG4qICAgICAgICAgKSl9XG4qICAgICAgIDwvdWw+XG4qICAgICA8L2Rpdj5cbiogICApXG4qIH1cbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiAoXG4qICAgICA8UXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgICAgIHsoeyByZXNldCB9KSA9PiAoXG4qICAgICAgICAgPEVycm9yQm91bmRhcnlcbiogICAgICAgICAgIG9uUmVzZXQ9e3Jlc2V0fVxuKiAgICAgICAgICAgZmFsbGJhY2tSZW5kZXI9eyh7IHJlc2V0RXJyb3JCb3VuZGFyeSB9KSA9PiAoXG4qICAgICAgICAgICAgIDxkaXY+XG4qICAgICAgICAgICAgICAgVGhlcmUgd2FzIGFuIGVycm9yIVxuKiAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVzZXRFcnJvckJvdW5kYXJ5KCl9PlRyeSBhZ2FpbjwvYnV0dG9uPlxuKiAgICAgICAgICAgICA8L2Rpdj5cbiogICAgICAgICAgICl9XG4qICAgICAgICAgPlxuKiAgICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8aDE+TG9hZGluZyBwb3N0cy4uLjwvaDE+fT5cbiogICAgICAgICAgICAgPFBvc3RzIC8+XG4qICAgICAgICAgICA8L1N1c3BlbnNlPlxuKiAgICAgICAgIDwvRXJyb3JCb3VuZGFyeT5cbiogICAgICAgKX1cbiogICAgIDwvUXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZVN1c3BlbnNlUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdGlmIChvcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikgY29uc29sZS5lcnJvcihcInNraXBUb2tlbiBpcyBub3QgYWxsb3dlZCBmb3IgdXNlU3VzcGVuc2VRdWVyeVwiKTtcblx0fVxuXHRyZXR1cm4gdXNlQmFzZVF1ZXJ5KHtcblx0XHQuLi5vcHRpb25zLFxuXHRcdGVuYWJsZWQ6IHRydWUsXG5cdFx0c3VzcGVuc2U6IHRydWUsXG5cdFx0dGhyb3dPbkVycm9yOiBkZWZhdWx0VGhyb3dPbkVycm9yLFxuXHRcdHBsYWNlaG9sZGVyRGF0YTogdm9pZCAwXG5cdH0sIFF1ZXJ5T2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlU3VzcGVuc2VRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VTdXNwZW5zZVF1ZXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgZGVmYXVsdFRocm93T25FcnJvciB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlUXVlcnkgfSBmcm9tIFwiLi91c2VCYXNlUXVlcnkuanNcIjtcbmltcG9ydCB7IEluZmluaXRlUXVlcnlPYnNlcnZlciwgc2tpcFRva2VuIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL3VzZVN1c3BlbnNlSW5maW5pdGVRdWVyeS50c1xuLyoqXG4qIFRoZSBvcHRpb25zIGZvciBgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5YCBhcmUgdGhlIHNhbWUgYXMgZm9yIGB1c2VJbmZpbml0ZVF1ZXJ5YCwgZXhjZXB0IGZvciBgdGhyb3dPbkVycm9yYCxcbiogYGVuYWJsZWRgLCBhbmQgYHBsYWNlaG9sZGVyRGF0YWAuXG4qXG4qIENhdmVhdDogY2FuY2VsbGF0aW9uIGRvZXMgbm90IHdvcmsuXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIHtAbGluayBVc2VTdXNwZW5zZUluZmluaXRlUXVlcnlPcHRpb25zfSB0byB1c2Ug4oCUIHRoZSBzYW1lIG9wdGlvbnMgYXMgYHVzZUluZmluaXRlUXVlcnlgLCBtaW51cyB0aGUgb25lcyBsaXN0ZWQgYWJvdmUuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgVGhlIHNhbWUgb2JqZWN0IGFzIGB1c2VJbmZpbml0ZVF1ZXJ5YCwgZXhjZXB0IHRoYXQgYGRhdGFgIGlzIGd1YXJhbnRlZWQgdG8gYmUgZGVmaW5lZCxcbiogYGlzUGxhY2Vob2xkZXJEYXRhYCBpcyBtaXNzaW5nLCBhbmQgYHN0YXR1c2AgaXMgZWl0aGVyIGBzdWNjZXNzYCBvciBgZXJyb3JgICh3aXRoIHRoZSBkZXJpdmVkIGZsYWdzIHNldFxuKiBhY2NvcmRpbmdseSkuXG4qIEByZW1hcmtzIE11bHRpcGxlIHN1c3BlbnNlZnVsIHF1ZXJ5IGNhbGxzIGluIHRoZSBzYW1lIGNvbXBvbmVudCBzdXNwZW5kIHNlcmlhbGx5LCBjYXVzaW5nIGEgcmVxdWVzdFxuKiB3YXRlcmZhbGwg4oCUIGVhY2ggb25lIGJsb2NrcyByZW5kZXJpbmcgdW50aWwgaXQgcmVzb2x2ZXMsIHNvIHRoZSBuZXh0IGRvZXNuJ3QgZXZlbiBzdGFydCBmZXRjaGluZyB1bnRpbFxuKiB0aGVuLiBUaGVyZSdzIG5vIHdheSB0byBwYXJhbGxlbGl6ZSBtdWx0aXBsZSBpbmZpbml0ZSBxdWVyaWVzIHVuZGVyIFN1c3BlbnNlLiBBbHNvIGtlZXAgaW4gbWluZCB0aGF0XG4qIGltcGVyYXRpdmUgZmV0Y2ggY2FsbHMsIHN1Y2ggYXMgYGZldGNoTmV4dFBhZ2VgLCBtYXkgaW50ZXJmZXJlIHdpdGggdGhlIGRlZmF1bHQgcmVmZXRjaCBiZWhhdmlvcixcbiogcmVzdWx0aW5nIGluIG91dGRhdGVkIGRhdGEuIE1ha2Ugc3VyZSB0byBjYWxsIHRoZXNlIGZ1bmN0aW9ucyBvbmx5IGluIHJlc3BvbnNlIHRvIHVzZXIgYWN0aW9ucywgb3IgYWRkXG4qIGNvbmRpdGlvbnMgbGlrZSBgaGFzTmV4dFBhZ2UgJiYgIWlzRmV0Y2hpbmdgLlxuKiBAc2VlIHtAbGluayB1c2VJbmZpbml0ZVF1ZXJ5fSBmb3IgdGhlIG5vbi1TdXNwZW5zZSB2ZXJzaW9uIG9mIHRoaXMgaG9vay5cbiogQGV4YW1wbGVcbiogVGhlIHF1ZXJ5IGVycm9yIGlzIHRocm93biBpZiBhIGZldGNoIGZhaWxzIGFuZCBubyBjYWNoZWQgZGF0YSBleGlzdHMgeWV0LCBzbyBhbiBlcnJvciBib3VuZGFyeSBpc1xuKiByZXF1aXJlZCBhcm91bmQgYDxTdXNwZW5zZT5gLiBBIGZhaWxlZCBiYWNrZ3JvdW5kIHJlZmV0Y2ggaW5zdGVhZCBjb250aW51ZXMgdG8gcmVuZGVyIHRoZSBjYWNoZWQgZGF0YS5cbiogVXNlIHtAbGluayBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeX0gdG8gbGV0IHRoZSB1c2VyIHJldHJ5IGFmdGVyIHN1Y2ggYW4gZXJyb3I6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBTdXNwZW5zZSB9IGZyb20gJ3JlYWN0J1xuKiBpbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG4qIGltcG9ydCB7XG4qICAgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnksXG4qICAgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LFxuKiB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUHJvamVjdHMoKSB7XG4qICAgLy8gYGRhdGFgIGlzIGd1YXJhbnRlZWQgdG8gYmUgZGVmaW5lZCBoZXJlIOKAlCBubyBgaXNQZW5kaW5nYCBjaGVjayBuZWVkZWQuXG4qICAgY29uc3QgeyBkYXRhLCBmZXRjaE5leHRQYWdlLCBoYXNOZXh0UGFnZSwgaXNGZXRjaGluZywgaXNGZXRjaGluZ05leHRQYWdlIH0gPVxuKiAgICAgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5KHtcbiogICAgICAgcXVlcnlLZXk6IFsncHJvamVjdHMnXSxcbiogICAgICAgcXVlcnlGbjogKHsgcGFnZVBhcmFtIH0pID0+IGZldGNoUHJvamVjdHMocGFnZVBhcmFtKSxcbiogICAgICAgaW5pdGlhbFBhZ2VQYXJhbTogMCxcbiogICAgICAgZ2V0TmV4dFBhZ2VQYXJhbTogKGxhc3RQYWdlKSA9PiBsYXN0UGFnZS5uZXh0SWQsXG4qICAgICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8ZGl2PlxuKiAgICAgICA8dWw+XG4qICAgICAgICAge2RhdGEucGFnZXMubWFwKChwYWdlKSA9PlxuKiAgICAgICAgICAgcGFnZS5wcm9qZWN0cy5tYXAoKHByb2plY3QpID0+IDxsaSBrZXk9e3Byb2plY3QuaWR9Pntwcm9qZWN0Lm5hbWV9PC9saT4pLFxuKiAgICAgICAgICl9XG4qICAgICAgIDwvdWw+XG4qICAgICAgIDxidXR0b25cbiogICAgICAgICBvbkNsaWNrPXsoKSA9PiBmZXRjaE5leHRQYWdlKCl9XG4qICAgICAgICAgZGlzYWJsZWQ9eyFoYXNOZXh0UGFnZSB8fCBpc0ZldGNoaW5nfVxuKiAgICAgICA+XG4qICAgICAgICAge2lzRmV0Y2hpbmdOZXh0UGFnZVxuKiAgICAgICAgICAgPyAnTG9hZGluZyBtb3JlLi4uJ1xuKiAgICAgICAgICAgOiBoYXNOZXh0UGFnZVxuKiAgICAgICAgICAgICA/ICdMb2FkIE1vcmUnXG4qICAgICAgICAgICAgIDogJ05vdGhpbmcgbW9yZSB0byBsb2FkJ31cbiogICAgICAgPC9idXR0b24+XG4qICAgICA8L2Rpdj5cbiogICApXG4qIH1cbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiAoXG4qICAgICA8UXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgICAgIHsoeyByZXNldCB9KSA9PiAoXG4qICAgICAgICAgPEVycm9yQm91bmRhcnlcbiogICAgICAgICAgIG9uUmVzZXQ9e3Jlc2V0fVxuKiAgICAgICAgICAgZmFsbGJhY2tSZW5kZXI9eyh7IHJlc2V0RXJyb3JCb3VuZGFyeSB9KSA9PiAoXG4qICAgICAgICAgICAgIDxkaXY+XG4qICAgICAgICAgICAgICAgVGhlcmUgd2FzIGFuIGVycm9yIVxuKiAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVzZXRFcnJvckJvdW5kYXJ5KCl9PlRyeSBhZ2FpbjwvYnV0dG9uPlxuKiAgICAgICAgICAgICA8L2Rpdj5cbiogICAgICAgICAgICl9XG4qICAgICAgICAgPlxuKiAgICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8aDE+TG9hZGluZyBwcm9qZWN0cy4uLjwvaDE+fT5cbiogICAgICAgICAgICAgPFByb2plY3RzIC8+XG4qICAgICAgICAgICA8L1N1c3BlbnNlPlxuKiAgICAgICAgIDwvRXJyb3JCb3VuZGFyeT5cbiogICAgICAgKX1cbiogICAgIDwvUXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0aWYgKG9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuKSBjb25zb2xlLmVycm9yKFwic2tpcFRva2VuIGlzIG5vdCBhbGxvd2VkIGZvciB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnlcIik7XG5cdH1cblx0cmV0dXJuIHVzZUJhc2VRdWVyeSh7XG5cdFx0Li4ub3B0aW9ucyxcblx0XHRlbmFibGVkOiB0cnVlLFxuXHRcdHN1c3BlbnNlOiB0cnVlLFxuXHRcdHRocm93T25FcnJvcjogZGVmYXVsdFRocm93T25FcnJvcixcblx0XHRwbGFjZWhvbGRlckRhdGE6IHZvaWQgMFxuXHR9LCBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IGRlZmF1bHRUaHJvd09uRXJyb3IgfSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuaW1wb3J0IHsgdXNlUXVlcmllcyB9IGZyb20gXCIuL3VzZVF1ZXJpZXMuanNcIjtcbmltcG9ydCB7IHNraXBUb2tlbiB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VTdXNwZW5zZVF1ZXJpZXMudHNcbmZ1bmN0aW9uIHVzZVN1c3BlbnNlUXVlcmllcyhvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRyZXR1cm4gdXNlUXVlcmllcyh7XG5cdFx0Li4ub3B0aW9ucyxcblx0XHRxdWVyaWVzOiBvcHRpb25zLnF1ZXJpZXMubWFwKChxdWVyeSkgPT4ge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0XHRpZiAocXVlcnkucXVlcnlGbiA9PT0gc2tpcFRva2VuKSBjb25zb2xlLmVycm9yKFwic2tpcFRva2VuIGlzIG5vdCBhbGxvd2VkIGZvciB1c2VTdXNwZW5zZVF1ZXJpZXNcIik7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHQuLi5xdWVyeSxcblx0XHRcdFx0c3VzcGVuc2U6IHRydWUsXG5cdFx0XHRcdHRocm93T25FcnJvcjogZGVmYXVsdFRocm93T25FcnJvcixcblx0XHRcdFx0ZW5hYmxlZDogdHJ1ZSxcblx0XHRcdFx0cGxhY2Vob2xkZXJEYXRhOiB2b2lkIDBcblx0XHRcdH07XG5cdFx0fSlcblx0fSwgcXVlcnlDbGllbnQpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VTdXNwZW5zZVF1ZXJpZXMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlU3VzcGVuc2VRdWVyaWVzLmpzLm1hcCIsImltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuaW1wb3J0IHsgbm9vcCB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VQcmVmZXRjaFF1ZXJ5LnRzeFxuLyoqXG4qIGB1c2VQcmVmZXRjaFF1ZXJ5YCBkb2VzIG5vdCByZXR1cm4gYW55dGhpbmcsIGl0IHNob3VsZCBiZSB1c2VkIGp1c3QgdG8gZmlyZSBhIHByZWZldGNoIGR1cmluZyByZW5kZXIsIGJlZm9yZVxuKiBhIHN1c3BlbnNlIGJvdW5kYXJ5IHRoYXQgd3JhcHMgYSBjb21wb25lbnQgdGhhdCB1c2VzIGB1c2VTdXNwZW5zZVF1ZXJ5YC4gWW91IGNhbiBwYXNzIGV2ZXJ5dGhpbmcgdG9cbiogYHVzZVByZWZldGNoUXVlcnlgIHRoYXQgeW91IGNhbiBwYXNzIHRvIGBxdWVyeUNsaWVudC5xdWVyeWAsIHRob3VnaCBgcXVlcnlLZXlgIGlzIGFsd2F5cyByZXF1aXJlZCwgYW5kXG4qIGBxdWVyeUZuYCBpcyByZXF1aXJlZCB1bmxlc3MgYSBkZWZhdWx0IHF1ZXJ5IGZ1bmN0aW9uIGhhcyBiZWVuIGRlZmluZWQuXG4qXG4qIFRoZSBwcmVmZXRjaCBpcyBza2lwcGVkIGlmIHRoZSBxdWVyeSBhbHJlYWR5IGhhcyBhbnkgY2FjaGVkIHN0YXRlIOKAlCBpbmNsdWRpbmcgYSBgcGVuZGluZ2AvYGVycm9yYCBzdGF0ZSBsZWZ0XG4qIG92ZXIgZnJvbSBhIHByZXZpb3VzIGF0dGVtcHQg4oCUIHNvIGNhbGxpbmcgdGhpcyBvbiBldmVyeSByZW5kZXIgaXMgY2hlYXAgYW5kIHdvbid0IHJlZmV0Y2ggZGF0YSB0aGF0J3NcbiogYWxyZWFkeSB0aGVyZSBvciBhbHJlYWR5IGluIGZsaWdodC5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUge0BsaW5rIFVzZVByZWZldGNoUXVlcnlPcHRpb25zfSB0byB1c2Ug4oCUIGV2ZXJ5dGhpbmcgeW91IGNhbiBwYXNzIHRvIGBxdWVyeUNsaWVudC5xdWVyeWAuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IFN1c3BlbnNlIH0gZnJvbSAncmVhY3QnXG4qIGltcG9ydCB7IHVzZVByZWZldGNoUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFwcCgpIHtcbiogICAvLyBGaXJlIHRoZSBwcmVmZXRjaCBkdXJpbmcgcmVuZGVyLCBiZWZvcmUgdGhlIHN1c3BlbnNlIGJvdW5kYXJ5IGJlbG93LlxuKiAgIHVzZVByZWZldGNoUXVlcnkoe1xuKiAgICAgcXVlcnlLZXk6IFsncG9zdHMnXSxcbiogICAgIHF1ZXJ5Rm46IGZldGNoUG9zdHMsXG4qICAgfSlcbipcbiogICByZXR1cm4gKFxuKiAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8aDE+TG9hZGluZyBwb3N0cy4uLjwvaDE+fT5cbiogICAgICAgPFBvc3RzIC8+XG4qICAgICA8L1N1c3BlbnNlPlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VQcmVmZXRjaFF1ZXJ5KG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0aWYgKCFjbGllbnQuZ2V0UXVlcnlTdGF0ZShvcHRpb25zLnF1ZXJ5S2V5KSkgY2xpZW50LnF1ZXJ5KG9wdGlvbnMpLmNhdGNoKG5vb3ApO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VQcmVmZXRjaFF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVByZWZldGNoUXVlcnkuanMubWFwIiwiaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyBub29wIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL3VzZVByZWZldGNoSW5maW5pdGVRdWVyeS50c3hcbi8qKlxuKiBgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5YCBkb2VzIG5vdCByZXR1cm4gYW55dGhpbmcsIGl0IHNob3VsZCBiZSB1c2VkIGp1c3QgdG8gZmlyZSBhIHByZWZldGNoIGR1cmluZyByZW5kZXIsXG4qIGJlZm9yZSBhIHN1c3BlbnNlIGJvdW5kYXJ5IHRoYXQgd3JhcHMgYSBjb21wb25lbnQgdGhhdCB1c2VzIGB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnlgLiBZb3UgY2FuIHBhc3NcbiogZXZlcnl0aGluZyB0byBgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5YCB0aGF0IHlvdSBjYW4gcGFzcyB0byBgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeWAsIHRob3VnaFxuKiBgcXVlcnlLZXlgLCBgaW5pdGlhbFBhZ2VQYXJhbWAsIGFuZCBgZ2V0TmV4dFBhZ2VQYXJhbWAgYXJlIGFsd2F5cyByZXF1aXJlZCwgYW5kIGBxdWVyeUZuYCBpcyByZXF1aXJlZCB1bmxlc3NcbiogYSBkZWZhdWx0IHF1ZXJ5IGZ1bmN0aW9uIGhhcyBiZWVuIGRlZmluZWQuXG4qXG4qIGBnZXROZXh0UGFnZVBhcmFtYCByZWNlaXZlcyBib3RoIHRoZSBsYXN0IHBhZ2Ugb2YgdGhlIGluZmluaXRlIGxpc3Qgb2YgZGF0YSBhbmQgdGhlIGZ1bGwgYXJyYXkgb2YgYWxsIHBhZ2VzLFxuKiBhcyB3ZWxsIGFzIHBhZ2VQYXJhbSBpbmZvcm1hdGlvbiwgYW5kIHNob3VsZCByZXR1cm4gYSBzaW5nbGUgdmFyaWFibGUgdGhhdCB3aWxsIGJlIHBhc3NlZCB0byB5b3VyIHF1ZXJ5XG4qIGZ1bmN0aW9uIGFzIGBjb250ZXh0LnBhZ2VQYXJhbWAuIFJldHVybiBgdW5kZWZpbmVkYCBvciBgbnVsbGAgdG8gaW5kaWNhdGUgdGhlcmUgaXMgbm8gbmV4dCBwYWdlIGF2YWlsYWJsZS5cbipcbiogVGhlIHByZWZldGNoIGlzIHNraXBwZWQgaWYgdGhlIHF1ZXJ5IGFscmVhZHkgaGFzIGFueSBjYWNoZWQgc3RhdGUg4oCUIGluY2x1ZGluZyBhIGBwZW5kaW5nYC9gZXJyb3JgIHN0YXRlIGxlZnRcbiogb3ZlciBmcm9tIGEgcHJldmlvdXMgYXR0ZW1wdCDigJQgc28gY2FsbGluZyB0aGlzIG9uIGV2ZXJ5IHJlbmRlciBpcyBjaGVhcCBhbmQgd29uJ3QgcmVmZXRjaCBkYXRhIHRoYXQnc1xuKiBhbHJlYWR5IHRoZXJlIG9yIGFscmVhZHkgaW4gZmxpZ2h0LlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSB7QGxpbmsgVXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5T3B0aW9uc30gdG8gdXNlIOKAlCBldmVyeXRoaW5nIHlvdSBjYW4gcGFzcyB0byBgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeWAuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IFN1c3BlbnNlIH0gZnJvbSAncmVhY3QnXG4qIGltcG9ydCB7IGluZmluaXRlUXVlcnlPcHRpb25zLCB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGNvbnN0IHByb2plY3RzT3B0aW9ucyA9IGluZmluaXRlUXVlcnlPcHRpb25zKHtcbiogICBxdWVyeUtleTogWydwcm9qZWN0cyddLFxuKiAgIHF1ZXJ5Rm46ICh7IHBhZ2VQYXJhbSB9KSA9PiBmZXRjaFByb2plY3RzKHBhZ2VQYXJhbSksXG4qICAgaW5pdGlhbFBhZ2VQYXJhbTogMCxcbiogICBnZXROZXh0UGFnZVBhcmFtOiAobGFzdFBhZ2UpID0+IGxhc3RQYWdlLm5leHRJZCxcbiogfSlcbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIC8vIEZpcmUgdGhlIHByZWZldGNoIGR1cmluZyByZW5kZXIsIGJlZm9yZSB0aGUgc3VzcGVuc2UgYm91bmRhcnkgYmVsb3cuXG4qICAgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5KHByb2plY3RzT3B0aW9ucylcbipcbiogICByZXR1cm4gKFxuKiAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8aDE+TG9hZGluZyBwcm9qZWN0cy4uLjwvaDE+fT5cbiogICAgICAgPFByb2plY3RzIC8+XG4qICAgICA8L1N1c3BlbnNlPlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRpZiAoIWNsaWVudC5nZXRRdWVyeVN0YXRlKG9wdGlvbnMucXVlcnlLZXkpKSBjbGllbnQuaW5maW5pdGVRdWVyeShvcHRpb25zKS5jYXRjaChub29wKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVByZWZldGNoSW5maW5pdGVRdWVyeS5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3F1ZXJ5T3B0aW9ucy50c1xuZnVuY3Rpb24gcXVlcnlPcHRpb25zKG9wdGlvbnMpIHtcblx0cmV0dXJuIG9wdGlvbnM7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHF1ZXJ5T3B0aW9ucyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeU9wdGlvbnMuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9pbmZpbml0ZVF1ZXJ5T3B0aW9ucy50c1xuZnVuY3Rpb24gaW5maW5pdGVRdWVyeU9wdGlvbnMob3B0aW9ucykge1xuXHRyZXR1cm4gb3B0aW9ucztcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaW5maW5pdGVRdWVyeU9wdGlvbnMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5maW5pdGVRdWVyeU9wdGlvbnMuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VJc0ZldGNoaW5nLnRzXG4vKipcbiogVGhlIGB1c2VJc0ZldGNoaW5nYCBob29rIHJldHVybnMgdGhlIGBudW1iZXJgIG9mIHRoZSBxdWVyaWVzIHRoYXQgeW91ciBhcHBsaWNhdGlvbiBpcyBsb2FkaW5nIG9yIGZldGNoaW5nIGluXG4qIHRoZSBiYWNrZ3JvdW5kICh1c2VmdWwgZm9yIGFwcC13aWRlIGxvYWRpbmcgaW5kaWNhdG9ycykuXG4qIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIHtAbGluayBRdWVyeUZpbHRlcnN9IHRvIG5hcnJvdyBkb3duIHRoZSBtYXRjaGVkIHF1ZXJpZXMuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgV2lsbCBiZSB0aGUgYG51bWJlcmAgb2YgdGhlIHF1ZXJpZXMgdGhhdCB5b3VyIGFwcGxpY2F0aW9uIGlzIGN1cnJlbnRseSBsb2FkaW5nIG9yIGZldGNoaW5nIGluIHRoZVxuKiBiYWNrZ3JvdW5kLlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlSXNGZXRjaGluZyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUG9zdHNGZXRjaGluZ0luZGljYXRvcigpIHtcbiogICAvLyBIb3cgbWFueSBxdWVyaWVzIG1hdGNoaW5nIHRoZSBwb3N0cyBwcmVmaXggYXJlIGZldGNoaW5nP1xuKiAgIGNvbnN0IGlzRmV0Y2hpbmdQb3N0cyA9IHVzZUlzRmV0Y2hpbmcoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG4qXG4qICAgcmV0dXJuIGlzRmV0Y2hpbmdQb3N0cyA/IDxzcGFuPlJlZnJlc2hpbmcgcG9zdHMuLi48L3NwYW4+IDogbnVsbFxuKiB9XG4qIGBgYFxuKiBAZXhhbXBsZVxuKiBBIGdsb2JhbCBsb2FkaW5nIGluZGljYXRvciBmb3IgYW55IHF1ZXJ5IGZldGNoaW5nIGluIHRoZSBiYWNrZ3JvdW5kLCBub3QganVzdCB0aGUgb25lcyBvbiBzY3JlZW46XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VJc0ZldGNoaW5nIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBHbG9iYWxMb2FkaW5nSW5kaWNhdG9yKCkge1xuKiAgIGNvbnN0IGlzRmV0Y2hpbmcgPSB1c2VJc0ZldGNoaW5nKClcbipcbiogICByZXR1cm4gaXNGZXRjaGluZyA/IChcbiogICAgIDxkaXY+UXVlcmllcyBhcmUgZmV0Y2hpbmcgaW4gdGhlIGJhY2tncm91bmQuLi48L2Rpdj5cbiogICApIDogbnVsbFxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZUlzRmV0Y2hpbmcoZmlsdGVycywgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRjb25zdCBxdWVyeUNhY2hlID0gY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKTtcblx0cmV0dXJuIFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFJlYWN0LnVzZUNhbGxiYWNrKChvblN0b3JlQ2hhbmdlKSA9PiBxdWVyeUNhY2hlLnN1YnNjcmliZShub3RpZnlNYW5hZ2VyLmJhdGNoQ2FsbHMob25TdG9yZUNoYW5nZSkpLCBbcXVlcnlDYWNoZV0pLCAoKSA9PiBjbGllbnQuaXNGZXRjaGluZyhmaWx0ZXJzKSwgKCkgPT4gY2xpZW50LmlzRmV0Y2hpbmcoZmlsdGVycykpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VJc0ZldGNoaW5nIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUlzRmV0Y2hpbmcuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciwgcmVwbGFjZUVxdWFsRGVlcCB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VNdXRhdGlvblN0YXRlLnRzXG4vKipcbiogVGhlIGB1c2VJc011dGF0aW5nYCBob29rIHJldHVybnMgdGhlIGBudW1iZXJgIG9mIG11dGF0aW9ucyB0aGF0IHlvdXIgYXBwbGljYXRpb24gY3VycmVudGx5IGhhcyBgcGVuZGluZ2BcbiogKHVzZWZ1bCBmb3IgYXBwLXdpZGUgbG9hZGluZyBpbmRpY2F0b3JzKS5cbiogQHBhcmFtIGZpbHRlcnMgLSBUaGUge0BsaW5rIE11dGF0aW9uRmlsdGVyc30gdG8gbmFycm93IGRvd24gdGhlIG1hdGNoZWQgbXV0YXRpb25zLlxuKiBAcGFyYW0gcXVlcnlDbGllbnQgLSBVc2UgdGhpcyB0byB1c2UgYSBjdXN0b20gYFF1ZXJ5Q2xpZW50YC4gT3RoZXJ3aXNlLCB0aGUgb25lIGZyb20gdGhlIG5lYXJlc3QgY29udGV4dCB3aWxsXG4qIGJlIHVzZWQuXG4qIEByZXR1cm5zIFdpbGwgYmUgdGhlIGBudW1iZXJgIG9mIHRoZSBtdXRhdGlvbnMgdGhhdCB5b3VyIGFwcGxpY2F0aW9uIGN1cnJlbnRseSBoYXMgYHBlbmRpbmdgLlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlSXNNdXRhdGluZyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUG9zdHNNdXRhdGluZ0luZGljYXRvcigpIHtcbiogICAvLyBIb3cgbWFueSBtdXRhdGlvbnMgbWF0Y2hpbmcgdGhlIHBvc3RzIHByZWZpeCBhcmUgaW4gcHJvZ3Jlc3M/XG4qICAgY29uc3QgaXNNdXRhdGluZ1Bvc3RzID0gdXNlSXNNdXRhdGluZyh7IG11dGF0aW9uS2V5OiBbJ3Bvc3RzJ10gfSlcbipcbiogICByZXR1cm4gaXNNdXRhdGluZ1Bvc3RzID8gPHNwYW4+U2F2aW5nIHBvc3RzLi4uPC9zcGFuPiA6IG51bGxcbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VJc011dGF0aW5nKGZpbHRlcnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0cmV0dXJuIHVzZU11dGF0aW9uU3RhdGUoeyBmaWx0ZXJzOiB7XG5cdFx0Li4uZmlsdGVycyxcblx0XHRzdGF0dXM6IFwicGVuZGluZ1wiXG5cdH0gfSwgY2xpZW50KS5sZW5ndGg7XG59XG4vKipcbiogQ3JlYXRlcyBzbmFwc2hvdCBnZXR0ZXJzIHRoYXQgc2hhcmUgZXF1YWwgc2VsZWN0ZWQgcmVzdWx0cyBhY3Jvc3MgcmVuZGVycy5cbiogQSBuZXcgZ2V0dGVyIGlzIGNyZWF0ZWQgb24gZWFjaCByZW5kZXIuIEVhY2ggZ2V0dGVyIGNhY2hlcyBpdHMgc25hcHNob3QgdW50aWwgdGhlIG1hdGNoaW5nIG11dGF0aW9uc1xuKiBvciB0aGVpciBzdGF0ZXMgY2hhbmdlLlxuKiBAcmV0dXJucyBBIGZhY3RvcnkgZm9yIHNuYXBzaG90IGdldHRlcnMgd2l0aCBhIHNoYXJlZCByZXN1bHQgY2FjaGUuXG4qL1xuZnVuY3Rpb24gY3JlYXRlU25hcHNob3RGYWN0b3J5KCkge1xuXHRsZXQgcHJldmlvdXNSZXN1bHQ7XG5cdHJldHVybiAobXV0YXRpb25DYWNoZSwgb3B0aW9ucykgPT4ge1xuXHRcdGxldCBpbnB1dHMgPSBbXTtcblx0XHRsZXQgc25hcHNob3Q7XG5cdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdGNvbnN0IG11dGF0aW9ucyA9IG11dGF0aW9uQ2FjaGUuZmluZEFsbChvcHRpb25zLmZpbHRlcnMpO1xuXHRcdFx0Y29uc3QgbmV4dElucHV0cyA9IG11dGF0aW9ucy5mbGF0TWFwKChtdXRhdGlvbikgPT4gW211dGF0aW9uLCBtdXRhdGlvbi5zdGF0ZV0pO1xuXHRcdFx0aWYgKCFzbmFwc2hvdCB8fCBuZXh0SW5wdXRzLmxlbmd0aCAhPT0gaW5wdXRzLmxlbmd0aCB8fCBuZXh0SW5wdXRzLnNvbWUoKGlucHV0LCBpbmRleCkgPT4gIU9iamVjdC5pcyhpbnB1dCwgaW5wdXRzW2luZGV4XSkpKSB7XG5cdFx0XHRcdGlucHV0cyA9IG5leHRJbnB1dHM7XG5cdFx0XHRcdHNuYXBzaG90ID0gcmVwbGFjZUVxdWFsRGVlcChwcmV2aW91c1Jlc3VsdCwgbXV0YXRpb25zLm1hcCgobXV0YXRpb24pID0+IG9wdGlvbnMuc2VsZWN0ID8gb3B0aW9ucy5zZWxlY3QobXV0YXRpb24pIDogbXV0YXRpb24uc3RhdGUpKTtcblx0XHRcdFx0cHJldmlvdXNSZXN1bHQgPSBzbmFwc2hvdDtcblx0XHRcdH1cblx0XHRcdHJldHVybiBzbmFwc2hvdDtcblx0XHR9O1xuXHR9O1xufVxuLyoqXG4qIGB1c2VNdXRhdGlvblN0YXRlYCBpcyBhIGhvb2sgdGhhdCBnaXZlcyB5b3UgYWNjZXNzIHRvIGFsbCBtdXRhdGlvbnMgaW4gdGhlIGBNdXRhdGlvbkNhY2hlYC4gWW91IGNhbiBwYXNzXG4qIGBmaWx0ZXJzYCAoe0BsaW5rIE11dGF0aW9uRmlsdGVyc30pIHRvIG5hcnJvdyBkb3duIHlvdXIgbXV0YXRpb25zLCBhbmQgYHNlbGVjdGAgdG8gdHJhbnNmb3JtIHRoZSBtdXRhdGlvblxuKiBzdGF0ZS5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgYGZpbHRlcnNgIHRvIG5hcnJvdyBkb3duIG1hdGNoZWQgbXV0YXRpb25zLCBhbmQgYW4gb3B0aW9uYWwgYHNlbGVjdGAgdG8gdHJhbnNmb3JtIHRoZVxuKiBtdXRhdGlvbiBzdGF0ZS5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBXaWxsIGJlIGFuIEFycmF5IG9mIHdoYXRldmVyIGBzZWxlY3RgIHJldHVybnMgZm9yIGVhY2ggbWF0Y2hpbmcgbXV0YXRpb24uXG4qIEBleGFtcGxlXG4qIEdldCBhbGwgdmFyaWFibGVzIG9mIGFsbCBydW5uaW5nIG11dGF0aW9uczpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uU3RhdGUgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIFBlbmRpbmdQb3N0cygpIHtcbiogICBjb25zdCBwZW5kaW5nVmFyaWFibGVzID0gdXNlTXV0YXRpb25TdGF0ZSh7XG4qICAgICBmaWx0ZXJzOiB7IHN0YXR1czogJ3BlbmRpbmcnIH0sXG4qICAgICBzZWxlY3Q6IChtdXRhdGlvbikgPT4gbXV0YXRpb24uc3RhdGUudmFyaWFibGVzLFxuKiAgIH0pXG4qXG4qICAgcmV0dXJuIDw+e3BlbmRpbmdWYXJpYWJsZXMubGVuZ3RofSBwb3N0cyBzYXZpbmcuLi48Lz5cbiogfVxuKiBgYGBcbiogQGV4YW1wbGVcbiogR2V0IGFsbCBkYXRhIGZvciBzcGVjaWZpYyBtdXRhdGlvbnMgdmlhIHRoZSBgbXV0YXRpb25LZXlgOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZU11dGF0aW9uU3RhdGUgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGNvbnN0IG11dGF0aW9uS2V5ID0gWydwb3N0cyddXG4qXG4qIGZ1bmN0aW9uIFBvc3RzKCkge1xuKiAgIC8vIFNvbWUgbXV0YXRpb24gdGhhdCB3ZSB3YW50IHRvIGdldCB0aGUgc3RhdGUgZm9yXG4qICAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XG4qICAgICBtdXRhdGlvbktleSxcbiogICAgIG11dGF0aW9uRm46IGNyZWF0ZVBvc3RzLFxuKiAgIH0pXG4qXG4qICAgY29uc3Qgc2F2ZWRQb3N0cyA9IHVzZU11dGF0aW9uU3RhdGUoe1xuKiAgICAgLy8gdGhpcyBtdXRhdGlvbiBrZXkgbmVlZHMgdG8gbWF0Y2ggdGhlIG11dGF0aW9uIGtleSBvZiB0aGUgZ2l2ZW4gbXV0YXRpb24gKHNlZSBhYm92ZSlcbiogICAgIGZpbHRlcnM6IHsgbXV0YXRpb25LZXksIHN0YXR1czogJ3N1Y2Nlc3MnIH0sXG4qICAgICBzZWxlY3Q6IChtdXRhdGlvbikgPT4gbXV0YXRpb24uc3RhdGUuZGF0YSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG11dGF0aW9uLm11dGF0ZShbJ05ldyBQb3N0J10pfT5cbiogICAgICAgQ3JlYXRlIHBvc3QgKHtzYXZlZFBvc3RzLmxlbmd0aH0gc2F2ZWQgc28gZmFyKVxuKiAgICAgPC9idXR0b24+XG4qICAgKVxuKiB9XG4qIGBgYFxuKiBAZXhhbXBsZVxuKiBBY2Nlc3MgdGhlIGxhdGVzdCBzdWNjZXNzZnVsIG11dGF0aW9uIGRhdGEgdmlhIHRoZSBgbXV0YXRpb25LZXlgLiBFYWNoIGludm9jYXRpb24gb2YgYG11dGF0ZWAgYWRkcyBhIG5ld1xuKiBlbnRyeSB0byB0aGUgbXV0YXRpb24gY2FjaGUgZm9yIGBnY1RpbWVgIG1pbGxpc2Vjb25kcyDigJQgd2l0aCB0aGUgYHN0YXR1czogJ3N1Y2Nlc3MnYCBmaWx0ZXIgYmVsb3csIGNoZWNrIHRoZVxuKiBsYXN0IGl0ZW0gdGhhdCBgdXNlTXV0YXRpb25TdGF0ZWAgcmV0dXJucyB0byBnZXQgdGhlIGxhdGVzdCBzdWNjZXNzZnVsIGludm9jYXRpb246XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VNdXRhdGlvblN0YXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBMYXRlc3RQb3N0KCkge1xuKiAgIGNvbnN0IHNhdmVkUG9zdHMgPSB1c2VNdXRhdGlvblN0YXRlKHtcbiogICAgIGZpbHRlcnM6IHsgbXV0YXRpb25LZXk6IFsncG9zdHMnXSwgc3RhdHVzOiAnc3VjY2VzcycgfSxcbiogICAgIHNlbGVjdDogKG11dGF0aW9uKSA9PiBtdXRhdGlvbi5zdGF0ZS5kYXRhLFxuKiAgIH0pXG4qXG4qICAgY29uc3QgbGF0ZXN0U2F2ZWRQb3N0ID0gc2F2ZWRQb3N0c1tzYXZlZFBvc3RzLmxlbmd0aCAtIDFdXG4qXG4qICAgcmV0dXJuIDw+e2xhdGVzdFNhdmVkUG9zdCA/ICdTYXZlZCcgOiAnTm90aGluZyBzYXZlZCB5ZXQnfTwvPlxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZU11dGF0aW9uU3RhdGUob3B0aW9ucyA9IHt9LCBxdWVyeUNsaWVudCkge1xuXHRjb25zdCBtdXRhdGlvbkNhY2hlID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpLmdldE11dGF0aW9uQ2FjaGUoKTtcblx0Y29uc3QgW2NyZWF0ZVNuYXBzaG90XSA9IFJlYWN0LnVzZVN0YXRlKCgpID0+IGNyZWF0ZVNuYXBzaG90RmFjdG9yeSgpKTtcblx0Y29uc3QgZ2V0U25hcHNob3QgPSBjcmVhdGVTbmFwc2hvdChtdXRhdGlvbkNhY2hlLCBvcHRpb25zKTtcblx0cmV0dXJuIFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFJlYWN0LnVzZUNhbGxiYWNrKChvblN0b3JlQ2hhbmdlKSA9PiBtdXRhdGlvbkNhY2hlLnN1YnNjcmliZShub3RpZnlNYW5hZ2VyLmJhdGNoQ2FsbHMob25TdG9yZUNoYW5nZSkpLCBbbXV0YXRpb25DYWNoZV0pLCBnZXRTbmFwc2hvdCwgZ2V0U25hcHNob3QpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VJc011dGF0aW5nLCB1c2VNdXRhdGlvblN0YXRlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZU11dGF0aW9uU3RhdGUuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTXV0YXRpb25PYnNlcnZlciwgbm9vcCwgbm90aWZ5TWFuYWdlciwgc2hvdWxkVGhyb3dFcnJvciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VNdXRhdGlvbi50c1xuLyoqXG4qIFVubGlrZSBxdWVyaWVzLCBtdXRhdGlvbnMgYXJlIHR5cGljYWxseSB1c2VkIHRvIGNyZWF0ZS91cGRhdGUvZGVsZXRlIGRhdGEgb3IgcGVyZm9ybSBzZXJ2ZXIgc2lkZS1lZmZlY3RzLlxuKiBgdXNlTXV0YXRpb25gIGlzIHRoZSBob29rIGZvciB0aGF0LlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSB7QGxpbmsgVXNlTXV0YXRpb25PcHRpb25zfSB0byB1c2Ug4oCUIGV2ZXJ5dGhpbmcgeW91IGNhbiBwYXNzIHRvIGB1c2VNdXRhdGlvbmAuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgYG11dGF0ZWAvYG11dGF0ZUFzeW5jYCBhbHNvIGFjY2VwdCBwZXItY2FsbCBgb25TdWNjZXNzYC9gb25FcnJvcmAvYG9uU2V0dGxlZGAgY2FsbGJhY2tzIGFzIGEgc2Vjb25kXG4qIGFyZ3VtZW50LCB1c2VmdWwgZm9yIHRyaWdnZXJpbmcgY2FsbC1zaXRlIHNpZGUgZWZmZWN0cyAoZS5nLiBuYXZpZ2F0aW9uKSB3aXRob3V0IGNvdXBsaW5nIHRoZW0gdG8gdGhlIHNoYXJlZFxuKiBtdXRhdGlvbiBkZWZpbml0aW9uLiBIb29rLWxldmVsIGNhbGxiYWNrcyAocGFzc2VkIHRvIGBvcHRpb25zYCkgZmlyZSBmb3IgZXZlcnkgbXV0YXRpb247IHBlci1jYWxsIGNhbGxiYWNrc1xuKiBmaXJlIG9ubHkgZm9yIHRoZSBsYXRlc3QgY2FsbCB5b3UndmUgbWFkZSwgYW5kIG9ubHkgd2hpbGUgdGhlIGNvbXBvbmVudCBpcyBzdGlsbCBtb3VudGVkIOKAlCB1bm1vdW50aW5nIGJlZm9yZVxuKiB0aGUgbXV0YXRpb24gc2V0dGxlcyByZW1vdmVzIHRoZSBzdWJzY3JpcHRpb24gYW5kIHByZXZlbnRzIHRoZW0gZnJvbSBmaXJpbmcuXG4qIEB0aHJvd3Mge0Vycm9yfSBUaGUgbXV0YXRpb24gZXJyb3IsIHdoZW4gYHRocm93T25FcnJvcmAgaXMgYHRydWVgIG9yIHJldHVybnMgYHRydWVgIGZvciBpdCwgc28gdGhhdCBpdCBpc1xuKiB0aHJvd24gdG8gdGhlIG5lYXJlc3QgZXJyb3IgYm91bmRhcnkuXG4qIEBzZWUge0BsaW5rIG11dGF0aW9uT3B0aW9uc30gdG8gc2hhcmUgdGhlc2Ugb3B0aW9ucyBhY3Jvc3MgbXVsdGlwbGUgYHVzZU11dGF0aW9uYCBjYWxsIHNpdGVzLCBvciB0byBsb29rXG4qIHRoZSBtdXRhdGlvbiB1cCBlbHNld2hlcmUgdmlhIGl0cyBgbXV0YXRpb25LZXlgIChlLmcuIHdpdGggYHVzZU11dGF0aW9uU3RhdGVgKS5cbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQWRkVG9kbygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvblN1Y2Nlc3M6ICgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8YnV0dG9uXG4qICAgICAgIG9uQ2xpY2s9eygpID0+XG4qICAgICAgICAgYWRkTXV0YXRpb24ubXV0YXRlKCdJdGVtJywge1xuKiAgICAgICAgICAgb25FcnJvcjogKGVycm9yKSA9PiBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gYWRkIGl0ZW06JywgZXJyb3IpLFxuKiAgICAgICAgIH0pXG4qICAgICAgIH1cbiogICAgID5cbiogICAgICAgQWRkXG4qICAgICA8L2J1dHRvbj5cbiogICApXG4qIH1cbiogYGBgXG4qIEBleGFtcGxlXG4qIFJlbmRlcmluZyB0aGUgbXV0YXRpb24ncyBvd24gc3RhdGUsIHJhdGhlciB0aGFuIGp1c3QgZmlyaW5nIGl0IG9mZjpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQWRkVG9kbygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvblN1Y2Nlc3M6ICgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8ZGl2PlxuKiAgICAgICB7YWRkTXV0YXRpb24uaXNQZW5kaW5nID8gKFxuKiAgICAgICAgICdBZGRpbmcgdG9kby4uLidcbiogICAgICAgKSA6IChcbiogICAgICAgICA8PlxuKiAgICAgICAgICAge2FkZE11dGF0aW9uLmlzRXJyb3IgPyAoXG4qICAgICAgICAgICAgIDxkaXY+QW4gZXJyb3Igb2NjdXJyZWQ6IHthZGRNdXRhdGlvbi5lcnJvci5tZXNzYWdlfTwvZGl2PlxuKiAgICAgICAgICAgKSA6IG51bGx9XG4qICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGFkZE11dGF0aW9uLm11dGF0ZSgnSXRlbScpfT5BZGQ8L2J1dHRvbj5cbiogICAgICAgICA8Lz5cbiogICAgICAgKX1cbiogICAgIDwvZGl2PlxuKiAgIClcbiogfVxuKiBgYGBcbiogQGV4YW1wbGVcbiogT3B0aW1pc3RpYyB1cGRhdGUgdmlhIGBvbk11dGF0ZWAsIHJvbGxpbmcgYmFjayBvbiBgb25FcnJvcmA6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFkZFRvZG8oKSB7XG4qICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4qXG4qICAgY29uc3QgYWRkTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XG4qICAgICBtdXRhdGlvbkZuOiBhZGRUb2RvLFxuKiAgICAgb25NdXRhdGU6IGFzeW5jIChuZXdUb2RvKSA9PiB7XG4qICAgICAgIGF3YWl0IHF1ZXJ5Q2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleTogWyd0b2RvcyddIH0pXG4qICAgICAgIGNvbnN0IHByZXZpb3VzVG9kb3MgPSBxdWVyeUNsaWVudC5nZXRRdWVyeURhdGE8QXJyYXk8c3RyaW5nPj4oWyd0b2RvcyddKVxuKlxuKiAgICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGE8QXJyYXk8c3RyaW5nPj4oWyd0b2RvcyddLCAob2xkKSA9PiBbXG4qICAgICAgICAgLi4uKG9sZCA/PyBbXSksXG4qICAgICAgICAgbmV3VG9kbyxcbiogICAgICAgXSlcbipcbiogICAgICAgLy8gUGFzc2VkIHRvIGBvbkVycm9yYCBhcyBgb25NdXRhdGVSZXN1bHRgIGlmIHRoZSBtdXRhdGlvbiBmYWlscy5cbiogICAgICAgcmV0dXJuIHsgcHJldmlvdXNUb2RvcyB9XG4qICAgICB9LFxuKiAgICAgb25FcnJvcjogKF9lcnIsIF9uZXdUb2RvLCBvbk11dGF0ZVJlc3VsdCkgPT4ge1xuKiAgICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEoWyd0b2RvcyddLCBvbk11dGF0ZVJlc3VsdD8ucHJldmlvdXNUb2RvcylcbiogICAgIH0sXG4qICAgICBvblNldHRsZWQ6ICgpID0+IHtcbiogICAgICAgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWyd0b2RvcyddIH0pXG4qICAgICB9LFxuKiAgIH0pXG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gYWRkTXV0YXRpb24ubXV0YXRlKCdJdGVtJyl9PkFkZDwvYnV0dG9uPlxuKiAgIClcbiogfVxuKiBgYGBcbiogQGV4YW1wbGVcbiogQ2FsbGJhY2tzIHBhc3NlZCBwZXIgY2FsbCB0byBgbXV0YXRlYCBvbmx5IGZpcmUgZm9yIHRoZSBsYXN0IGNhbGwg4oCUIGBtdXRhdGVBc3luY2AgZ2l2ZXMgeW91IGFcbiogcHJvbWlzZSBwZXIgY2FsbCBpbnN0ZWFkLCBzbyB5b3UgY2FuIHdhaXQgZm9yIGFsbCBvZiB0aGVtIHdoZW4gdGhleSBzdWNjZWVkOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBZGRUb2RvcygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvblN1Y2Nlc3M6ICgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KSxcbiogICB9KVxuKlxuKiAgIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZUFkZEFsbCh0b2RvczogQXJyYXk8c3RyaW5nPikge1xuKiAgICAgdHJ5IHtcbiogICAgICAgYXdhaXQgUHJvbWlzZS5hbGwodG9kb3MubWFwKCh0b2RvKSA9PiBhZGRNdXRhdGlvbi5tdXRhdGVBc3luYyh0b2RvKSkpXG4qICAgICB9IGNhdGNoIChlcnJvcikge1xuKiAgICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gYWRkIHRvZG9zOicsIGVycm9yKVxuKiAgICAgfVxuKiAgIH1cbipcbiogICByZXR1cm4gKFxuKiAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBZGRBbGwoWydUb2RvIDEnLCAnVG9kbyAyJywgJ1RvZG8gMyddKX0+XG4qICAgICAgIEFkZCBhbGxcbiogICAgIDwvYnV0dG9uPlxuKiAgIClcbiogfVxuKiBgYGBcbiogQGV4YW1wbGVcbiogSWYgc29tZSBvZiB0aGUgbXV0YXRpb25zIGFib3ZlIGNhbiBmYWlsIGluZGVwZW5kZW50bHkgb2YgdGhlIG90aGVycywgYW5kIHlvdSB3YW50IHRvIGtub3cgd2hpY2ggb25lc1xuKiBkaWQg4oCUIHJhdGhlciB0aGFuIGxvc2luZyB0aGF0IGluZm9ybWF0aW9uIHRoZSBtb21lbnQgdGhlIGZpcnN0IG9uZSByZWplY3RzIOKAlCBzd2FwIGBQcm9taXNlLmFsbGAgZm9yXG4qIGBQcm9taXNlLmFsbFNldHRsZWRgOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBZGRUb2RvcygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvblN1Y2Nlc3M6ICgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KSxcbiogICB9KVxuKlxuKiAgIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZUFkZEFsbCh0b2RvczogQXJyYXk8c3RyaW5nPikge1xuKiAgICAgY29uc3QgYWRkUmVzdWx0cyA9IGF3YWl0IFByb21pc2UuYWxsU2V0dGxlZChcbiogICAgICAgdG9kb3MubWFwKCh0b2RvKSA9PiBhZGRNdXRhdGlvbi5tdXRhdGVBc3luYyh0b2RvKSksXG4qICAgICApXG4qXG4qICAgICBhZGRSZXN1bHRzLmZvckVhY2goKGFkZFJlc3VsdCwgaW5kZXgpID0+IHtcbiogICAgICAgaWYgKGFkZFJlc3VsdC5zdGF0dXMgPT09ICdyZWplY3RlZCcpIHtcbiogICAgICAgICBjb25zb2xlLmVycm9yKGBGYWlsZWQgdG8gYWRkIFwiJHt0b2Rvc1tpbmRleF19XCI6YCwgYWRkUmVzdWx0LnJlYXNvbilcbiogICAgICAgfVxuKiAgICAgfSlcbiogICB9XG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlQWRkQWxsKFsnVG9kbyAxJywgJ1RvZG8gMicsICdUb2RvIDMnXSl9PlxuKiAgICAgICBBZGQgYWxsXG4qICAgICA8L2J1dHRvbj5cbiogICApXG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlTXV0YXRpb24ob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRjb25zdCBbb2JzZXJ2ZXJdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoY2xpZW50LCBvcHRpb25zKSk7XG5cdFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0b2JzZXJ2ZXIuc2V0T3B0aW9ucyhvcHRpb25zKTtcblx0fSwgW29ic2VydmVyLCBvcHRpb25zXSk7XG5cdGNvbnN0IHJlc3VsdCA9IFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFJlYWN0LnVzZUNhbGxiYWNrKChvblN0b3JlQ2hhbmdlKSA9PiBvYnNlcnZlci5zdWJzY3JpYmUobm90aWZ5TWFuYWdlci5iYXRjaENhbGxzKG9uU3RvcmVDaGFuZ2UpKSwgW29ic2VydmVyXSksICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSwgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpKTtcblx0Y29uc3QgbXV0YXRlID0gUmVhY3QudXNlQ2FsbGJhY2soKC4uLmFyZ3MpID0+IHtcblx0XHRvYnNlcnZlci5tdXRhdGUoYXJnc1swXSwgYXJnc1sxXSkuY2F0Y2gobm9vcCk7XG5cdH0sIFtvYnNlcnZlcl0pO1xuXHRpZiAocmVzdWx0LmVycm9yICYmIHNob3VsZFRocm93RXJyb3Iob2JzZXJ2ZXIub3B0aW9ucy50aHJvd09uRXJyb3IsIFtyZXN1bHQuZXJyb3JdKSkgdGhyb3cgcmVzdWx0LmVycm9yO1xuXHRyZXR1cm4ge1xuXHRcdC4uLnJlc3VsdCxcblx0XHRtdXRhdGUsXG5cdFx0bXV0YXRlQXN5bmM6IHJlc3VsdC5tdXRhdGVcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlTXV0YXRpb24gfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlTXV0YXRpb24uanMubWFwIiwiLy8jcmVnaW9uIHNyYy9tdXRhdGlvbk9wdGlvbnMudHNcbmZ1bmN0aW9uIG11dGF0aW9uT3B0aW9ucyhvcHRpb25zKSB7XG5cdHJldHVybiBvcHRpb25zO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBtdXRhdGlvbk9wdGlvbnMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bXV0YXRpb25PcHRpb25zLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlQmFzZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlQmFzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlSW5maW5pdGVRdWVyeS50c1xuZnVuY3Rpb24gdXNlSW5maW5pdGVRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRyZXR1cm4gdXNlQmFzZVF1ZXJ5KG9wdGlvbnMsIEluZmluaXRlUXVlcnlPYnNlcnZlciwgcXVlcnlDbGllbnQpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VJbmZpbml0ZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUluZmluaXRlUXVlcnkuanMubWFwIiwiaW1wb3J0IHsgUXVlcnlDbGllbnRDb250ZXh0LCBRdWVyeUNsaWVudFByb3ZpZGVyLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5IH0gZnJvbSBcIi4vSHlkcmF0aW9uQm91bmRhcnkuanNcIjtcbmltcG9ydCB7IElzUmVzdG9yaW5nUHJvdmlkZXIsIHVzZUlzUmVzdG9yaW5nIH0gZnJvbSBcIi4vSXNSZXN0b3JpbmdQcm92aWRlci5qc1wiO1xuaW1wb3J0IHsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnksIHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSBcIi4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJpZXMgfSBmcm9tIFwiLi91c2VRdWVyaWVzLmpzXCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCIuL3VzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VTdXNwZW5zZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlU3VzcGVuc2VRdWVyeS5qc1wiO1xuaW1wb3J0IHsgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VTdXNwZW5zZVF1ZXJpZXMgfSBmcm9tIFwiLi91c2VTdXNwZW5zZVF1ZXJpZXMuanNcIjtcbmltcG9ydCB7IHVzZVByZWZldGNoUXVlcnkgfSBmcm9tIFwiLi91c2VQcmVmZXRjaFF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnkgfSBmcm9tIFwiLi91c2VQcmVmZXRjaEluZmluaXRlUXVlcnkuanNcIjtcbmltcG9ydCB7IHF1ZXJ5T3B0aW9ucyB9IGZyb20gXCIuL3F1ZXJ5T3B0aW9ucy5qc1wiO1xuaW1wb3J0IHsgaW5maW5pdGVRdWVyeU9wdGlvbnMgfSBmcm9tIFwiLi9pbmZpbml0ZVF1ZXJ5T3B0aW9ucy5qc1wiO1xuaW1wb3J0IHsgdXNlSXNGZXRjaGluZyB9IGZyb20gXCIuL3VzZUlzRmV0Y2hpbmcuanNcIjtcbmltcG9ydCB7IHVzZUlzTXV0YXRpbmcsIHVzZU11dGF0aW9uU3RhdGUgfSBmcm9tIFwiLi91c2VNdXRhdGlvblN0YXRlLmpzXCI7XG5pbXBvcnQgeyB1c2VNdXRhdGlvbiB9IGZyb20gXCIuL3VzZU11dGF0aW9uLmpzXCI7XG5pbXBvcnQgeyBtdXRhdGlvbk9wdGlvbnMgfSBmcm9tIFwiLi9tdXRhdGlvbk9wdGlvbnMuanNcIjtcbmltcG9ydCB7IHVzZUluZmluaXRlUXVlcnkgfSBmcm9tIFwiLi91c2VJbmZpbml0ZVF1ZXJ5LmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvaW5kZXgudHNcbi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5LCBJc1Jlc3RvcmluZ1Byb3ZpZGVyLCBRdWVyeUNsaWVudENvbnRleHQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIsIFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCBpbmZpbml0ZVF1ZXJ5T3B0aW9ucywgbXV0YXRpb25PcHRpb25zLCBxdWVyeU9wdGlvbnMsIHVzZUluZmluaXRlUXVlcnksIHVzZUlzRmV0Y2hpbmcsIHVzZUlzTXV0YXRpbmcsIHVzZUlzUmVzdG9yaW5nLCB1c2VNdXRhdGlvbiwgdXNlTXV0YXRpb25TdGF0ZSwgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5LCB1c2VQcmVmZXRjaFF1ZXJ5LCB1c2VRdWVyaWVzLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQsIHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnksIHVzZVN1c3BlbnNlUXVlcmllcywgdXNlU3VzcGVuc2VRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQU9BLElBQU0scUJBQUEsYUFBMkIsY0FBYyxLQUFLLENBQUM7Ozs7Ozs7OztBQVNyRCxJQUFNLGtCQUFrQixnQkFBZ0I7Q0FDdkMsTUFBTSxTQUFBLGFBQWUsV0FBVyxrQkFBa0I7Q0FDbEQsSUFBSSxhQUFhLE9BQU87Q0FDeEIsSUFBSSxDQUFDLFFBQVEsTUFBTSxJQUFJLE1BQU0sd0RBQXdEO0NBQ3JGLE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxJQUFNLHVCQUF1QixFQUFFLFFBQVEsZUFBZTtDQUNyRCxhQUFNLGdCQUFnQjtFQUNyQixPQUFPLE1BQU07RUFDYixhQUFhO0dBQ1osT0FBTyxRQUFRO0VBQ2hCO0NBQ0QsR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUNYLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLG1CQUFtQixVQUFVO0VBQ3ZELE9BQU87RUFDUDtDQUNELENBQUM7QUFDRjs7O0FDbERBLElBQU0seUJBQXlCO0NBQzlCLGFBQWEsVUFBVSxVQUFVLFdBQVcsVUFBVSxLQUFLO0NBQzNELGVBQWUsY0FBYyxhQUFhLFNBQVM7Q0FDbkQsY0FBYyxVQUFVLFVBQVUsWUFBWSxVQUFVLEtBQUs7Q0FDN0QsZ0JBQWdCLGVBQWUsY0FBYyxVQUFVO0FBQ3hEOzs7Ozs7Ozs7Ozs7QUFZQSxJQUFJLGlCQUFpQixNQUFNO0NBQzFCLFlBQVk7Q0FDWixrQkFBa0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEJsQixtQkFBbUIsVUFBVTtFQUUzQixJQUFJLEtBQUssbUJBQW1CLGFBQWEsS0FBSyxXQUFXLFFBQVEsTUFBTSw4R0FBOEc7R0FDcEwsVUFBVSxLQUFLO0dBQ2Y7RUFDRCxDQUFDO0VBRUYsS0FBSyxZQUFZO0VBQzBCLEtBQUssa0JBQWtCO0NBQ25FOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXVCQSxXQUFXLFVBQVUsT0FBTztFQUNnQixLQUFLLGtCQUFrQjtFQUNsRSxPQUFPLEtBQUssVUFBVSxXQUFXLFVBQVUsS0FBSztDQUNqRDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JBLGFBQWEsV0FBVztFQUN2QixLQUFLLFVBQVUsYUFBYSxTQUFTO0NBQ3RDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW9CQSxZQUFZLFVBQVUsT0FBTztFQUNlLEtBQUssa0JBQWtCO0VBQ2xFLE9BQU8sS0FBSyxVQUFVLFlBQVksVUFBVSxLQUFLO0NBQ2xEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsY0FBYyxZQUFZO0VBQ3pCLEtBQUssVUFBVSxjQUFjLFVBQVU7Q0FDeEM7QUFDRDs7OztBQUlBLElBQU0saUJBQWlCLElBQUksZUFBZTs7Ozs7Ozs7O0FBUzFDLFNBQVMscUJBQXFCLFVBQVU7Q0FDdkMsV0FBVyxVQUFVLENBQUM7QUFDdkI7Ozs7OztBQzNKQSxJQUFNLFdBQVcsT0FBTyxXQUFXLGVBQWUsVUFBVTtBQUM1RCxTQUFTLE9BQU8sQ0FBQzs7Ozs7Ozs7QUFRakIsU0FBUyxpQkFBaUIsU0FBUyxPQUFPO0NBQ3pDLE9BQU8sT0FBTyxZQUFZLGFBQWEsUUFBUSxLQUFLLElBQUk7QUFDekQ7Ozs7OztBQU1BLFNBQVMsZUFBZSxPQUFPO0NBQzlCLE9BQU8sT0FBTyxVQUFVLFlBQVksU0FBUyxLQUFLLFVBQVU7QUFDN0Q7Ozs7Ozs7O0FBUUEsU0FBUyxlQUFlLFdBQVcsV0FBVztDQUM3QyxPQUFPLEtBQUssSUFBSSxhQUFhLGFBQWEsS0FBSyxLQUFLLElBQUksR0FBRyxDQUFDO0FBQzdEOzs7Ozs7OztBQVFBLFNBQVMsa0JBQWtCLE9BQU8sT0FBTztDQUN4QyxPQUFPLE9BQU8sVUFBVSxhQUFhLE1BQU0sS0FBSyxJQUFJO0FBQ3JEOzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JBLFNBQVMsV0FBVyxTQUFTLE9BQU87Q0FDbkMsTUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFPLGFBQWEsV0FBVyxVQUFVLFVBQVU7Q0FDekUsSUFBSSxVQUFVO0VBQ2IsSUFBSSxPQUNDO09BQUEsTUFBTSxjQUFjLHNCQUFzQixVQUFVLE1BQU0sT0FBTyxHQUFHLE9BQU87RUFBQSxPQUN6RSxJQUFJLENBQUMsZ0JBQWdCLE1BQU0sVUFBVSxRQUFRLEdBQUcsT0FBTztDQUMvRDtDQUNBLElBQUksU0FBUyxPQUFPO0VBQ25CLE1BQU0sV0FBVyxNQUFNLFNBQVM7RUFDaEMsSUFBSSxTQUFTLFlBQVksQ0FBQyxVQUFVLE9BQU87RUFDM0MsSUFBSSxTQUFTLGNBQWMsVUFBVSxPQUFPO0NBQzdDO0NBQ0EsSUFBSSxPQUFPLFVBQVUsYUFBYSxNQUFNLFFBQVEsTUFBTSxPQUFPLE9BQU87Q0FDcEUsSUFBSSxlQUFlLGdCQUFnQixNQUFNLE1BQU0sYUFBYSxPQUFPO0NBQ25FLElBQUksYUFBYSxDQUFDLFVBQVUsS0FBSyxHQUFHLE9BQU87Q0FDM0MsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQSxTQUFTLGNBQWMsU0FBUyxVQUFVO0NBQ3pDLE1BQU0sRUFBRSxPQUFPLFFBQVEsV0FBVyxnQkFBZ0I7Q0FDbEQsSUFBSSxhQUFhO0VBQ2hCLElBQUksQ0FBQyxTQUFTLFFBQVEsYUFBYSxPQUFPO0VBQzFDLElBQUksT0FDQztPQUFBLFFBQVEsU0FBUyxRQUFRLFdBQVcsTUFBTSxRQUFRLFdBQVcsR0FBRyxPQUFPO0VBQUEsT0FDckUsSUFBSSxDQUFDLGdCQUFnQixTQUFTLFFBQVEsYUFBYSxXQUFXLEdBQUcsT0FBTztDQUNoRjtDQUNBLElBQUksVUFBVSxTQUFTLE1BQU0sV0FBVyxRQUFRLE9BQU87Q0FDdkQsSUFBSSxhQUFhLENBQUMsVUFBVSxRQUFRLEdBQUcsT0FBTztDQUM5QyxPQUFPO0FBQ1I7Ozs7Ozs7QUFPQSxTQUFTLHNCQUFzQixVQUFVLFNBQVM7Q0FDakQsUUFBUSxTQUFTLGtCQUFrQixRQUFBLENBQVMsUUFBUTtBQUNyRDs7Ozs7Ozs7Ozs7O0FBWUEsU0FBUyxRQUFRLFVBQVU7Q0FDMUIsT0FBTyxLQUFLLFVBQVUsV0FBVyxHQUFHLFFBQVEsY0FBYyxHQUFHLElBQUksT0FBTyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsUUFBUSxRQUFRO0VBQ2hILE9BQU8sT0FBTyxJQUFJO0VBQ2xCLE9BQU87Q0FDUixHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUc7QUFDYjtBQUNBLFNBQVMsZ0JBQWdCLEdBQUcsR0FBRztDQUM5QixJQUFJLE1BQU0sR0FBRyxPQUFPO0NBQ3BCLElBQUksT0FBTyxNQUFNLE9BQU8sR0FBRyxPQUFPO0NBQ2xDLElBQUksS0FBSyxLQUFLLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxVQUFVO0VBQzdELElBQUksTUFBTSxRQUFRLENBQUMsS0FBSyxNQUFNLFFBQVEsQ0FBQyxHQUFHO0dBQ3pDLElBQUksRUFBRSxTQUFTLEVBQUUsUUFBUSxPQUFPO0dBQ2hDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLEVBQUUsR0FBRyxPQUFPO0dBQzVFLE9BQU87RUFDUjtFQUNBLE1BQU0sUUFBUSxPQUFPLEtBQUssQ0FBQztFQUMzQixLQUFLLE1BQU0sT0FBTyxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsSUFBSSxHQUFHLE9BQU87RUFDdEUsT0FBTztDQUNSO0NBQ0EsT0FBTztBQUNSO0FBQ0EsSUFBTSxTQUFTLE9BQU8sVUFBVTtBQUNoQyxTQUFTLGlCQUFpQixHQUFHLEdBQUcsUUFBUSxHQUFHO0NBQzFDLElBQUksTUFBTSxHQUFHLE9BQU87Q0FDcEIsSUFBSSxRQUFRLEtBQUssT0FBTztDQUN4QixNQUFNLFFBQVEsYUFBYSxDQUFDLEtBQUssYUFBYSxDQUFDO0NBQy9DLElBQUksQ0FBQyxTQUFTLEVBQUUsY0FBYyxDQUFDLEtBQUssY0FBYyxDQUFDLElBQUksT0FBTztDQUM5RCxNQUFNLFNBQVMsUUFBUSxJQUFJLE9BQU8sS0FBSyxDQUFDLEVBQUEsQ0FBRztDQUMzQyxNQUFNLFNBQVMsUUFBUSxJQUFJLE9BQU8sS0FBSyxDQUFDO0NBQ3hDLE1BQU0sUUFBUSxPQUFPO0NBQ3JCLE1BQU0sT0FBTyxRQUFRLElBQUksTUFBTSxLQUFLLElBQUksQ0FBQztDQUN6QyxJQUFJLGFBQWE7Q0FDakIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sS0FBSztFQUMvQixNQUFNLE1BQU0sUUFBUSxJQUFJLE9BQU87RUFDL0IsTUFBTSxRQUFRLEVBQUU7RUFDaEIsTUFBTSxRQUFRLEVBQUU7RUFDaEIsSUFBSSxVQUFVLE9BQU87R0FDcEIsS0FBSyxPQUFPO0dBQ1osSUFBSSxRQUFRLElBQUksUUFBUSxPQUFPLEtBQUssR0FBRyxHQUFHLEdBQUc7R0FDN0M7RUFDRDtFQUNBLElBQUksVUFBVSxRQUFRLFVBQVUsUUFBUSxPQUFPLFVBQVUsWUFBWSxPQUFPLFVBQVUsVUFBVTtHQUMvRixLQUFLLE9BQU87R0FDWjtFQUNEO0VBQ0EsTUFBTSxJQUFJLGlCQUFpQixPQUFPLE9BQU8sUUFBUSxDQUFDO0VBQ2xELEtBQUssT0FBTztFQUNaLElBQUksTUFBTSxPQUFPO0NBQ2xCO0NBQ0EsT0FBTyxVQUFVLFNBQVMsZUFBZSxRQUFRLElBQUk7QUFDdEQ7Ozs7Ozs7QUFPQSxTQUFTLG9CQUFvQixHQUFHLEdBQUc7Q0FDbEMsSUFBSSxDQUFDLEtBQUssT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsT0FBTztDQUNsRSxLQUFLLE1BQU0sT0FBTyxHQUFHLElBQUksRUFBRSxTQUFTLEVBQUUsTUFBTSxPQUFPO0NBQ25ELE9BQU87QUFDUjs7Ozs7O0FBTUEsU0FBUyxhQUFhLE9BQU87Q0FDNUIsT0FBTyxNQUFNLFFBQVEsS0FBSyxLQUFLLE1BQU0sV0FBVyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUM7QUFDcEU7Ozs7Ozs7QUFPQSxTQUFTLGNBQWMsR0FBRztDQUN6QixJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxPQUFPO0NBQ25DLE1BQU0sa0JBQWtCLE9BQU8sZUFBZSxDQUFDO0NBQy9DLE1BQU0sT0FBTyxpQkFBaUI7Q0FDOUIsSUFBSSxTQUFTLEtBQUssR0FBRyxPQUFPO0NBQzVCLElBQUksT0FBTyxTQUFTLFlBQVksT0FBTztDQUN2QyxNQUFNLE9BQU8sS0FBSztDQUNsQixJQUFJLENBQUMsbUJBQW1CLElBQUksR0FBRyxPQUFPO0NBQ3RDLElBQUksQ0FBQyxLQUFLLGVBQWUsZUFBZSxHQUFHLE9BQU87Q0FDbEQsSUFBSSxvQkFBb0IsT0FBTyxXQUFXLE9BQU87Q0FDakQsT0FBTztBQUNSOzs7Ozs7QUFNQSxTQUFTLG1CQUFtQixHQUFHO0NBQzlCLE9BQU8sT0FBTyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU07QUFDOUM7Ozs7OztBQU1BLFNBQVMsTUFBTSxTQUFTO0NBQ3ZCLE9BQU8sSUFBSSxTQUFTLFlBQVk7RUFDL0IsZUFBZSxXQUFXLFNBQVMsT0FBTztDQUMzQyxDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7O0FBV0EsU0FBUyxZQUFZLFVBQVUsTUFBTSxTQUFTO0NBQzdDLElBQUksT0FBTyxRQUFRLHNCQUFzQixZQUFZLE9BQU8sUUFBUSxrQkFBa0IsVUFBVSxJQUFJO01BQy9GLElBQUksUUFBUSxzQkFBc0IsT0FDSyxJQUFJO0VBQzlDLE9BQU8saUJBQWlCLFVBQVUsSUFBSTtDQUN2QyxTQUFTLE9BQU87RUFDZixRQUFRLE1BQU0sMEpBQTBKLFFBQVEsVUFBVSxLQUFLLE9BQU87RUFDdE0sTUFBTTtDQUNQO0NBR0QsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JBLFNBQVMsaUJBQWlCLGNBQWM7Q0FDdkMsT0FBTztBQUNSOzs7Ozs7Ozs7O0FBVUEsU0FBUyxTQUFTLE9BQU8sTUFBTSxNQUFNLEdBQUc7Q0FDdkMsTUFBTSxXQUFXLENBQUMsR0FBRyxPQUFPLElBQUk7Q0FDaEMsT0FBTyxPQUFPLFNBQVMsU0FBUyxNQUFNLFNBQVMsTUFBTSxDQUFDLElBQUk7QUFDM0Q7Ozs7Ozs7Ozs7QUFVQSxTQUFTLFdBQVcsT0FBTyxNQUFNLE1BQU0sR0FBRztDQUN6QyxNQUFNLFdBQVcsQ0FBQyxNQUFNLEdBQUcsS0FBSztDQUNoQyxPQUFPLE9BQU8sU0FBUyxTQUFTLE1BQU0sU0FBUyxNQUFNLEdBQUcsRUFBRSxJQUFJO0FBQy9EOzs7Ozs7Ozs7Ozs7O0FBYUEsSUFBTSxZQUFZLE9BQU87Ozs7Ozs7OztBQVN6QixTQUFTLGNBQWMsU0FBUyxjQUFjO0NBRTVDLElBQUksUUFBUSxZQUFZLFdBQVcsUUFBUSxNQUFNLHlHQUF5RyxRQUFRLFVBQVUsRUFBRTtDQUUvSyxJQUFJLENBQUMsUUFBUSxXQUFXLGNBQWMsZ0JBQWdCLGFBQWEsYUFBYTtDQUNoRixJQUFJLENBQUMsUUFBUSxXQUFXLFFBQVEsWUFBWSxXQUFXLGFBQWEsUUFBUSx1QkFBdUIsSUFBSSxNQUFNLHFCQUFxQixRQUFRLFVBQVUsRUFBRSxDQUFDO0NBQ3ZKLE9BQU8sUUFBUTtBQUNoQjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxTQUFTLGlCQUFpQixjQUFjLFFBQVE7Q0FDL0MsSUFBSSxPQUFPLGlCQUFpQixZQUFZLE9BQU8sYUFBYSxHQUFHLE1BQU07Q0FDckUsT0FBTyxDQUFDLENBQUM7QUFDVjs7Ozs7Ozs7OztBQVVBLFNBQVMsc0JBQXNCLFFBQVEsV0FBVyxhQUFhO0NBQzlELElBQUksV0FBVztDQUNmLElBQUk7Q0FDSixPQUFPLGVBQWUsUUFBUSxVQUFVO0VBQ3ZDLFlBQVk7RUFDWixXQUFXO0dBQ1YsV0FBVyxVQUFVO0dBQ3JCLElBQUksVUFBVSxPQUFPO0dBQ3JCLFdBQVc7R0FDWCxJQUFJLE9BQU8sU0FBUyxZQUFZO1FBQzNCLE9BQU8saUJBQWlCLFNBQVMsYUFBYSxFQUFFLE1BQU0sS0FBSyxDQUFDO0dBQ2pFLE9BQU87RUFDUjtDQUNELENBQUM7Q0FDRCxPQUFPO0FBQ1I7OztBQ25YQSxJQUFJLG1CQUFtQkE7Ozs7O0FBS3ZCLElBQU1DLG1CQUFpQixXQUFXOzs7Ozs7Ozs7Ozs7Ozs7OztBQWlCbEMsSUFBTSxxQkFBcUI7Q0FDMUIsVUFBQTs7Ozs7O0NBTUEsWUFBWSxlQUFlO0VBQzFCLGFBQWE7Q0FDZDtBQUNEOzs7Ozs7OztBQzVCQSxJQUFJLGVBQWUsTUFBTTtDQUN4QixjQUFjO0VBQ2IsS0FBSyw0QkFBNEIsSUFBSSxJQUFJO0VBQ3pDLEtBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxJQUFJO0NBQzFDOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLFVBQVUsVUFBVTtFQUNuQixLQUFLLFVBQVUsSUFBSSxRQUFRO0VBQzNCLEtBQUssWUFBWTtFQUNqQixhQUFhO0dBQ1osS0FBSyxVQUFVLE9BQU8sUUFBUTtHQUM5QixLQUFLLGNBQWM7RUFDcEI7Q0FDRDs7Ozs7Q0FLQSxlQUFlO0VBQ2QsT0FBTyxLQUFLLFVBQVUsT0FBTztDQUM5Qjs7Ozs7Q0FLQSxjQUFjLENBQUM7Ozs7O0NBS2YsZ0JBQWdCLENBQUM7QUFDbEI7Ozs7Ozs7O0FDNUNBLElBQUksZUFBZSxjQUFjLGFBQWE7Q0FDN0M7Q0FDQTtDQUNBO0NBQ0EsY0FBYztFQUNiLE1BQU07RUFDTixLQUFLLFVBQVUsWUFBWTtHQUMxQixJQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sa0JBQWtCO0lBQzdELE1BQU0saUJBQWlCLFFBQVE7SUFDL0IsT0FBTyxpQkFBaUIsb0JBQW9CLFVBQVUsS0FBSztJQUMzRCxhQUFhO0tBQ1osT0FBTyxvQkFBb0Isb0JBQW9CLFFBQVE7SUFDeEQ7R0FDRDtFQUNEO0NBQ0Q7Q0FDQSxjQUFjO0VBQ2IsSUFBSSxDQUFDLEtBQUssVUFBVSxLQUFLLGlCQUFpQixLQUFLLE1BQU07Q0FDdEQ7Q0FDQSxnQkFBZ0I7RUFDZixJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUc7R0FDekIsS0FBSyxXQUFXO0dBQ2hCLEtBQUssV0FBVyxLQUFLO0VBQ3RCO0NBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTJCQSxpQkFBaUIsT0FBTztFQUN2QixLQUFLLFNBQVM7RUFDZCxLQUFLLFdBQVc7RUFDaEIsS0FBSyxXQUFXLE9BQU8sWUFBWTtHQUNsQyxJQUFJLE9BQU8sWUFBWSxXQUFXLEtBQUssV0FBVyxPQUFPO1FBQ3BELEtBQUssUUFBUTtFQUNuQixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsV0FBVyxTQUFTO0VBQ25CLElBQUksS0FBSyxhQUFhLFNBQVM7R0FDOUIsS0FBSyxXQUFXO0dBQ2hCLEtBQUssUUFBUTtFQUNkO0NBQ0Q7Ozs7Q0FJQSxVQUFVO0VBQ1QsTUFBTSxZQUFZLEtBQUssVUFBVTtFQUNqQyxLQUFLLFVBQVUsU0FBUyxhQUFhO0dBQ3BDLFNBQVMsU0FBUztFQUNuQixDQUFDO0NBQ0Y7Ozs7O0NBS0EsWUFBWTtFQUNYLElBQUksT0FBTyxLQUFLLGFBQWEsV0FBVyxPQUFPLEtBQUs7RUFDcEQsT0FBTyxXQUFXLFVBQVUsb0JBQW9CO0NBQ2pEO0FBQ0Q7Ozs7QUFJQSxJQUFNLGVBQWUsSUFBSSxhQUFhOzs7Ozs7Ozs7O0FDdEd0QyxTQUFTLGVBQWUsU0FBUztDQUNoQyxJQUFJO0NBQ0osUUFBUSxNQUFNLFdBQVc7RUFDeEIsT0FBTztFQUNQLE9BQU87Q0FDUixHQUFHLElBQUksQ0FBQyxFQUFFLFFBQVEsSUFBSTtDQUN0QixJQUFJLFNBQVMsS0FBSyxHQUFHLE9BQU8sRUFBRSxLQUFLO0FBQ3BDOzs7Ozs7QUFNQSxTQUFTLGtCQUFrQixVQUFVO0NBQ3BDLE9BQU87RUFDTixhQUFhLFNBQVMsUUFBUTtFQUM5QixPQUFPLFNBQVM7RUFDaEIsR0FBRyxTQUFTLFFBQVEsU0FBUyxFQUFFLE9BQU8sU0FBUyxRQUFRLE1BQU07RUFDN0QsR0FBRyxTQUFTLFFBQVEsRUFBRSxNQUFNLFNBQVMsS0FBSztDQUMzQztBQUNEOzs7Ozs7Ozs7OztBQVdBLFNBQVMsaUJBQWlCLE9BQU8sZUFBZSxvQkFBb0I7Q0FDbkUsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLGFBQWEsQ0FBQyxDQUFDLE9BQU8sVUFBVTtFQUNuRSxJQUFJLHFCQUFxQixLQUFLLE1BQU0sT0FBTyxPQUFPLFFBQVEsT0FBTyxLQUFLO0VBQzNCLFFBQVEsTUFBTSwrREFBK0QsTUFBTSxVQUFVLEtBQUssTUFBTSxrREFBa0Q7RUFDck0sT0FBTyxRQUFRLHVCQUF1QixJQUFJLE1BQU0sVUFBVSxDQUFDO0NBQzVELENBQUM7Q0FDRCxTQUFTLE1BQU0sSUFBSTtDQUNuQixPQUFPO0FBQ1I7Ozs7Ozs7Ozs7OztBQVlBLFNBQVMsZUFBZSxPQUFPLGVBQWUsb0JBQW9CO0NBQ2pFLE9BQU87RUFDTixjQUFjLEtBQUssSUFBSTtFQUN2QixPQUFPO0dBQ04sR0FBRyxNQUFNO0dBQ1QsR0FBRyxNQUFNLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRSxNQUFNLGdCQUFnQixjQUFjLE1BQU0sTUFBTSxJQUFJLElBQUksTUFBTSxNQUFNLEtBQUs7RUFDOUc7RUFDQSxVQUFVLE1BQU07RUFDaEIsV0FBVyxNQUFNO0VBQ2pCLEdBQUcsTUFBTSxNQUFNLFdBQVcsYUFBYSxFQUFFLFNBQVMsaUJBQWlCLE9BQU8sZUFBZSxrQkFBa0IsRUFBRTtFQUM3RyxHQUFHLE1BQU0sUUFBUSxFQUFFLE1BQU0sTUFBTSxLQUFLO0VBQ3BDLEdBQUcsTUFBTSxhQUFhLEVBQUUsV0FBVyxNQUFNLFVBQVU7Q0FDcEQ7QUFDRDs7Ozs7OztBQU9BLFNBQVMsK0JBQStCLFVBQVU7Q0FDakQsT0FBTyxTQUFTLE1BQU07QUFDdkI7Ozs7Ozs7QUFPQSxTQUFTLDRCQUE0QixPQUFPO0NBQzNDLE9BQU8sTUFBTSxNQUFNLFdBQVc7QUFDL0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdUJBLFNBQVMsVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0NBQ3hDLE1BQU0saUJBQWlCLFFBQVEsMkJBQTJCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxXQUFXLDJCQUEyQjtDQUMzSCxNQUFNLFlBQVksT0FBTyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsYUFBYSxlQUFlLFFBQVEsSUFBSSxDQUFDLGtCQUFrQixRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7Q0FDeEksTUFBTSxjQUFjLFFBQVEsd0JBQXdCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxXQUFXLHdCQUF3QjtDQUNsSCxNQUFNLHFCQUFxQixRQUFRLHNCQUFzQixPQUFPLGtCQUFrQixDQUFDLENBQUMsV0FBVztDQUMvRixNQUFNLGdCQUFnQixRQUFRLGlCQUFpQixPQUFPLGtCQUFrQixDQUFDLENBQUMsV0FBVztDQUNyRixPQUFPO0VBQ047RUFDQSxTQUFTLE9BQU8sY0FBYyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVLFlBQVksS0FBSyxJQUFJLENBQUMsZUFBZSxPQUFPLGVBQWUsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUM7Q0FDako7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXNCQSxTQUFTLFFBQVEsUUFBUSxpQkFBaUIsU0FBUztDQUNsRCxNQUFNLGdCQUFnQixPQUFPLGlCQUFpQjtDQUM5QyxNQUFNLGFBQWEsT0FBTyxjQUFjO0NBQ3hDLE1BQU0sa0JBQWtCLFNBQVMsZ0JBQWdCLG1CQUFtQixPQUFPLGtCQUFrQixDQUFDLENBQUMsU0FBUztDQUN4RyxnQkFBZ0IsV0FBVyxTQUFTLEVBQUUsT0FBTyxHQUFHLHNCQUFzQjtFQUNyRSxjQUFjLE1BQU0sUUFBUTtHQUMzQixHQUFHLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxTQUFTO0dBQ3ZDLEdBQUcsU0FBUyxnQkFBZ0I7R0FDNUIsR0FBRztFQUNKLEdBQUcsS0FBSztDQUNULENBQUM7Q0FDRCxnQkFBZ0IsU0FBUyxTQUFTLEVBQUUsVUFBVSxPQUFPLFdBQVcsTUFBTSxTQUFTLGNBQWMsZ0JBQWdCO0VBQzVHLE1BQU0sV0FBVyxVQUFVLGVBQWUsT0FBTyxJQUFJLEtBQUs7RUFDMUQsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLElBQUksVUFBVSxPQUFPLE1BQU07RUFDL0QsTUFBTSxPQUFPLFlBQVksS0FBSyxJQUFJLFVBQVUsa0JBQWtCLGdCQUFnQixPQUFPLElBQUk7RUFDekYsSUFBSSxRQUFRLFdBQVcsSUFBSSxTQUFTO0VBQ3BDLE1BQU0seUJBQXlCLE9BQU8sTUFBTSxXQUFXO0VBQ3ZELE1BQU0sMEJBQTBCLE9BQU8sTUFBTSxnQkFBZ0I7RUFDN0QsSUFBSSxPQUFPO0dBQ1YsTUFBTSxtQkFBbUIsWUFBWSxlQUFlLE1BQU0sTUFBTTtHQUNoRSxJQUFJLE1BQU0sZ0JBQWdCLE1BQU0sTUFBTSxpQkFBaUIsa0JBQWtCO0lBQ3hFLE1BQU0sRUFBRSxhQUFhLFVBQVUsR0FBRyxvQkFBb0I7SUFDdEQsTUFBTSxTQUFTO0tBQ2QsR0FBRztLQUNIO0tBQ0EsR0FBRyxNQUFNLFdBQVcsYUFBYSxTQUFTLEtBQUssS0FBSztNQUNuRCxRQUFRO01BQ1IsZUFBZTtNQUNmLEdBQUcsQ0FBQywyQkFBMkIsRUFBRSxhQUFhLE9BQU87S0FDdEQ7SUFDRCxDQUFDO0dBQ0Y7RUFDRCxPQUFPLFFBQVEsV0FBVyxNQUFNLFFBQVE7R0FDdkMsR0FBRyxPQUFPLGtCQUFrQixDQUFDLENBQUMsU0FBUztHQUN2QyxHQUFHLFNBQVMsZ0JBQWdCO0dBQzVCO0dBQ0E7R0FDQTtHQUNBLE9BQU87RUFDUixHQUFHO0dBQ0YsR0FBRztHQUNIO0dBQ0EsYUFBYTtHQUNiLFFBQVEsTUFBTSxXQUFXLGFBQWEsU0FBUyxLQUFLLElBQUksWUFBWSxNQUFNO0dBQzFFLEdBQUcsTUFBTSxXQUFXLGFBQWEsU0FBUyxLQUFLLEtBQUssRUFBRSxlQUFlLGFBQWE7RUFDbkYsQ0FBQztFQUNELElBQUksV0FBVyxDQUFDLFlBQVksQ0FBQywwQkFBMEIsQ0FBQywyQkFBMkIsZUFBZSxNQUFNLE1BQU0sZUFBZSxNQUFNLE1BQU0sS0FBSyxHQUFHLEVBQUUsZ0JBQWdCLFFBQVEsUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDaE8sQ0FBQztBQUNGOzs7Ozs7O0FDNUxBLElBQU0sbUJBQW1COzs7Ozs7QUFNekIsU0FBUyxzQkFBc0I7Q0FDOUIsSUFBSSxRQUFRLENBQUM7Q0FDYixJQUFJLGVBQWU7Q0FDbkIsSUFBSSxZQUFZLGFBQWE7RUFDNUIsU0FBUztDQUNWO0NBQ0EsSUFBSSxpQkFBaUIsYUFBYTtFQUNqQyxTQUFTO0NBQ1Y7Q0FDQSxJQUFJLGFBQWE7Q0FDakIsTUFBTSxZQUFZLGFBQWE7RUFDOUIsSUFBSSxjQUFjLE1BQU0sS0FBSyxRQUFRO09BQ2hDLGlCQUFpQjtHQUNyQixTQUFTLFFBQVE7RUFDbEIsQ0FBQztDQUNGO0NBQ0EsTUFBTSxjQUFjO0VBQ25CLE1BQU0sZ0JBQWdCO0VBQ3RCLFFBQVEsQ0FBQztFQUNULElBQUksY0FBYyxRQUFRLGlCQUFpQjtHQUMxQyxvQkFBb0I7SUFDbkIsY0FBYyxTQUFTLGFBQWE7S0FDbkMsU0FBUyxRQUFRO0lBQ2xCLENBQUM7R0FDRixDQUFDO0VBQ0YsQ0FBQztDQUNGO0NBQ0EsT0FBTzs7Ozs7Ozs7O0VBU04sUUFBUSxhQUFhO0dBQ3BCLElBQUk7R0FDSjtHQUNBLElBQUk7SUFDSCxTQUFTLFNBQVM7R0FDbkIsVUFBVTtJQUNUO0lBQ0EsSUFBSSxDQUFDLGNBQWMsTUFBTTtHQUMxQjtHQUNBLE9BQU87RUFDUjs7Ozs7O0VBTUEsYUFBYSxhQUFhO0dBQ3pCLFFBQVEsR0FBRyxTQUFTO0lBQ25CLGVBQWU7S0FDZCxTQUFTLEdBQUcsSUFBSTtJQUNqQixDQUFDO0dBQ0Y7RUFDRDs7Ozs7RUFLQTs7Ozs7O0VBTUEsb0JBQW9CLE9BQU87R0FDMUIsV0FBVztFQUNaOzs7Ozs7Ozs7Ozs7OztFQWNBLHlCQUF5QixPQUFPO0dBQy9CLGdCQUFnQjtFQUNqQjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQW1CQSxlQUFlLE9BQU87R0FDckIsYUFBYTtFQUNkO0NBQ0Q7QUFDRDs7OztBQUlBLElBQU0sZ0JBQWdCLG9CQUFvQjs7Ozs7Ozs7Ozs7O0FDbkgxQyxJQUFJLGdCQUFnQixjQUFjLGFBQWE7Q0FDOUMsVUFBVTtDQUNWO0NBQ0E7Q0FDQSxjQUFjO0VBQ2IsTUFBTTtFQUNOLEtBQUssVUFBVSxhQUFhO0dBQzNCLElBQUksT0FBTyxXQUFXLGVBQWUsT0FBTyxrQkFBa0I7SUFDN0QsTUFBTSx1QkFBdUIsU0FBUyxJQUFJO0lBQzFDLE1BQU0sd0JBQXdCLFNBQVMsS0FBSztJQUM1QyxPQUFPLGlCQUFpQixVQUFVLGdCQUFnQixLQUFLO0lBQ3ZELE9BQU8saUJBQWlCLFdBQVcsaUJBQWlCLEtBQUs7SUFDekQsYUFBYTtLQUNaLE9BQU8sb0JBQW9CLFVBQVUsY0FBYztLQUNuRCxPQUFPLG9CQUFvQixXQUFXLGVBQWU7SUFDdEQ7R0FDRDtFQUNEO0NBQ0Q7Q0FDQSxjQUFjO0VBQ2IsSUFBSSxDQUFDLEtBQUssVUFBVSxLQUFLLGlCQUFpQixLQUFLLE1BQU07Q0FDdEQ7Q0FDQSxnQkFBZ0I7RUFDZixJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUc7R0FDekIsS0FBSyxXQUFXO0dBQ2hCLEtBQUssV0FBVyxLQUFLO0VBQ3RCO0NBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBb0JBLGlCQUFpQixPQUFPO0VBQ3ZCLEtBQUssU0FBUztFQUNkLEtBQUssV0FBVztFQUNoQixLQUFLLFdBQVcsTUFBTSxLQUFLLFVBQVUsS0FBSyxJQUFJLENBQUM7Q0FDaEQ7Ozs7Ozs7Ozs7Ozs7OztDQWVBLFVBQVUsUUFBUTtFQUNqQixJQUFJLEtBQUssWUFBWSxRQUFRO0dBQzVCLEtBQUssVUFBVTtHQUNmLEtBQUssVUFBVSxTQUFTLGFBQWE7SUFDcEMsU0FBUyxNQUFNO0dBQ2hCLENBQUM7RUFDRjtDQUNEOzs7OztDQUtBLFdBQVc7RUFDVixPQUFPLEtBQUs7Q0FDYjtBQUNEOzs7O0FBSUEsSUFBTSxnQkFBZ0IsSUFBSSxjQUFjOzs7Ozs7OztBQ3RGeEMsU0FBUyxrQkFBa0IsY0FBYztDQUN4QyxPQUFPLEtBQUssSUFBSSxNQUFNLEtBQUssY0FBYyxHQUFHO0FBQzdDOzs7Ozs7QUFNQSxTQUFTLFNBQVMsYUFBYTtDQUM5QixRQUFRLGVBQWUsY0FBYyxXQUFXLGNBQWMsU0FBUyxJQUFJO0FBQzVFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbUJBLElBQUksaUJBQWlCLGNBQWMsTUFBTTtDQUN4QyxZQUFZLFNBQVM7RUFDcEIsTUFBTSxnQkFBZ0I7RUFDdEIsS0FBSyxTQUFTLFNBQVM7RUFDdkIsS0FBSyxTQUFTLFNBQVM7Q0FDeEI7QUFDRDs7Ozs7OztBQU9BLFNBQVMsaUJBQWlCLE9BQU87Q0FDaEMsT0FBTyxpQkFBaUI7QUFDekI7Ozs7Ozs7Ozs7QUFVQSxTQUFTLGNBQWMsUUFBUTtDQUM5QixJQUFJLG1CQUFtQjtDQUN2QixJQUFJLGVBQWU7Q0FDbkIsSUFBSTtDQUNKLElBQUksU0FBUztDQUNiLElBQUk7Q0FDSixJQUFJO0NBQ0osTUFBTSxVQUFVLElBQUksU0FBUyxTQUFTLFdBQVc7RUFDaEQsaUJBQWlCO0VBQ2pCLGdCQUFnQjtDQUNqQixDQUFDO0NBQ0QsUUFBUSxNQUFNLElBQUk7Q0FDbEIsTUFBTSxtQkFBbUIsV0FBVztDQUNwQyxNQUFNLFVBQVUsa0JBQWtCO0VBQ2pDLElBQUksQ0FBQyxXQUFXLEdBQUc7R0FDbEIsTUFBTSxRQUFRLElBQUksZUFBZSxhQUFhO0dBQzlDLE9BQU8sS0FBSztHQUNaLE9BQU8sV0FBVyxLQUFLO0VBQ3hCO0NBQ0Q7Q0FDQSxNQUFNLG9CQUFvQjtFQUN6QixtQkFBbUI7Q0FDcEI7Q0FDQSxNQUFNLHNCQUFzQjtFQUMzQixtQkFBbUI7Q0FDcEI7Q0FDQSxNQUFNLG9CQUFvQixhQUFhLFVBQVUsTUFBTSxPQUFPLGdCQUFnQixZQUFZLGNBQWMsU0FBUyxNQUFNLE9BQU8sT0FBTztDQUNySSxNQUFNLGlCQUFpQixTQUFTLE9BQU8sV0FBVyxLQUFLLE9BQU8sT0FBTztDQUNyRSxNQUFNLFdBQVcsVUFBVTtFQUMxQixJQUFJLENBQUMsV0FBVyxHQUFHO0dBQ2xCLGFBQWE7R0FDYixTQUFTO0dBQ1QsZUFBZSxLQUFLO0VBQ3JCO0NBQ0Q7Q0FDQSxNQUFNLFVBQVUsVUFBVTtFQUN6QixJQUFJLENBQUMsV0FBVyxHQUFHO0dBQ2xCLGFBQWE7R0FDYixTQUFTO0dBQ1QsY0FBYyxLQUFLO0VBQ3BCO0NBQ0Q7Q0FDQSxNQUFNLFNBQVMsY0FBYztFQUM1QixPQUFPLElBQUksU0FBUyxvQkFBb0I7R0FDdkMsY0FBYyxVQUFVO0lBQ3ZCLElBQUksV0FBVyxLQUFLLFVBQVUsR0FBRyxnQkFBZ0IsS0FBSztHQUN2RDtHQUNBLE9BQU8sVUFBVTtFQUNsQixDQUFDLENBQUMsQ0FBQyxXQUFXO0dBQ2IsYUFBYSxLQUFLO0dBQ2xCLElBQUksQ0FBQyxXQUFXLEdBQUcsT0FBTyxhQUFhO0VBQ3hDLENBQUM7Q0FDRjtDQUNBLE1BQU0sWUFBWTtFQUNqQixJQUFJLFdBQVcsR0FBRztFQUNsQixJQUFJO0VBQ0osTUFBTSxpQkFBaUIsaUJBQWlCLElBQUksT0FBTyxpQkFBaUIsS0FBSztFQUN6RSxJQUFJO0dBQ0gsaUJBQWlCLGtCQUFrQixPQUFPLEdBQUc7RUFDOUMsU0FBUyxPQUFPO0dBQ2YsaUJBQWlCLFFBQVEsT0FBTyxLQUFLO0VBQ3RDO0VBQ0EsUUFBUSxRQUFRLGNBQWMsQ0FBQyxDQUFDLEtBQUssT0FBTyxDQUFDLENBQUMsT0FBTyxVQUFVO0dBQzlELElBQUksV0FBVyxHQUFHO0dBQ2xCLE1BQU0sUUFBUSxPQUFPLFVBQVVDLFdBQVMsSUFBSSxJQUFJO0dBQ2hELE1BQU0sYUFBYSxPQUFPLGNBQWM7R0FDeEMsTUFBTSxRQUFRLE9BQU8sZUFBZSxhQUFhLFdBQVcsY0FBYyxLQUFLLElBQUk7R0FDbkYsTUFBTSxjQUFjLFVBQVUsUUFBUSxPQUFPLFVBQVUsWUFBWSxlQUFlLFNBQVMsT0FBTyxVQUFVLGNBQWMsTUFBTSxjQUFjLEtBQUs7R0FDbkosSUFBSSxvQkFBb0IsQ0FBQyxhQUFhO0lBQ3JDLE9BQU8sS0FBSztJQUNaO0dBQ0Q7R0FDQTtHQUNBLE9BQU8sU0FBUyxjQUFjLEtBQUs7R0FDbkMsTUFBTSxLQUFLLENBQUMsQ0FBQyxXQUFXO0lBQ3ZCLE9BQU8sWUFBWSxJQUFJLEtBQUssSUFBSSxNQUFNLFdBQVc7R0FDbEQsQ0FBQyxDQUFDLENBQUMsV0FBVztJQUNiLElBQUksa0JBQWtCLE9BQU8sS0FBSztTQUM3QixJQUFJO0dBQ1YsQ0FBQztFQUNGLENBQUM7Q0FDRjtDQUNBLE9BQU87RUFDTjtFQUNBLGNBQWM7RUFDZDtFQUNBLGdCQUFnQjtHQUNmLGFBQWE7R0FDYixPQUFPO0VBQ1I7RUFDQTtFQUNBO0VBQ0E7RUFDQSxhQUFhO0dBQ1osSUFBSSxTQUFTLEdBQUcsSUFBSTtRQUNmLE1BQU0sUUFBUSxDQUFDLENBQUMsS0FBSyxHQUFHO0dBQzdCLE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7QUMzSkEsSUFBSSxZQUFZLE1BQU07Q0FDckI7Ozs7OztDQU1BLFVBQVU7RUFDVCxLQUFLLGVBQWU7Q0FDckI7Ozs7O0NBS0EsYUFBYTtFQUNaLEtBQUssZUFBZTtFQUNwQixJQUFJLGVBQWUsS0FBSyxNQUFNLEdBQUcsS0FBSyxhQUFhLGVBQWUsaUJBQWlCO0dBQ2xGLEtBQUssZUFBZTtFQUNyQixHQUFHLEtBQUssTUFBTTtDQUNmOzs7Ozs7Q0FNQSxhQUFhLFdBQVc7RUFDdkIsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFVBQVUsR0FBRyxjQUFjQyxXQUFTLElBQUksV0FBVyxJQUFJO0NBQ3BGOzs7O0NBSUEsaUJBQWlCO0VBQ2hCLElBQUksS0FBSyxlQUFlLEtBQUssR0FBRztHQUMvQixlQUFlLGFBQWEsS0FBSyxVQUFVO0dBQzNDLEtBQUssYUFBYSxLQUFLO0VBQ3hCO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7QUNuQ0EsU0FBUyxzQkFBc0IsT0FBTztDQUNyQyxPQUFPLEVBQUUsVUFBVSxTQUFTLFVBQVU7RUFDckMsTUFBTSxVQUFVLFFBQVE7RUFDeEIsTUFBTSxZQUFZLFFBQVEsY0FBYyxNQUFNLFdBQVc7RUFDekQsTUFBTSxXQUFXLFFBQVEsTUFBTSxNQUFNLFNBQVMsQ0FBQztFQUMvQyxNQUFNLGdCQUFnQixRQUFRLE1BQU0sTUFBTSxjQUFjLENBQUM7RUFDekQsSUFBSSxTQUFTO0dBQ1osT0FBTyxDQUFDO0dBQ1IsWUFBWSxDQUFDO0VBQ2Q7RUFDQSxJQUFJLGNBQWM7RUFDbEIsTUFBTSxVQUFVLFlBQVk7R0FDM0IsSUFBSSxZQUFZO0dBQ2hCLE1BQU0scUJBQXFCLFdBQVc7SUFDckMsc0JBQXNCLGNBQWMsUUFBUSxjQUFjLFlBQVksSUFBSTtHQUMzRTtHQUNBLE1BQU0sVUFBVSxjQUFjLFFBQVEsU0FBUyxRQUFRLFlBQVk7R0FDbkUsTUFBTSxZQUFZLE9BQU8sTUFBTSxPQUFPLGFBQWE7SUFDbEQsSUFBSSxXQUFXLE9BQU8sUUFBUSxPQUFPLFFBQVEsT0FBTyxNQUFNO0lBQzFELElBQUksU0FBUyxRQUFRLEtBQUssTUFBTSxRQUFRLE9BQU8sUUFBUSxRQUFRLElBQUk7SUFDbkUsTUFBTSw2QkFBNkI7S0FDbEMsTUFBTSxpQkFBaUI7TUFDdEIsUUFBUSxRQUFRO01BQ2hCLFVBQVUsUUFBUTtNQUNsQixXQUFXO01BQ1gsV0FBVyxXQUFXLGFBQWE7TUFDbkMsTUFBTSxRQUFRLFFBQVE7S0FDdkI7S0FDQSxrQkFBa0IsY0FBYztLQUNoQyxPQUFPO0lBQ1I7SUFDQSxNQUFNLGlCQUFpQixxQkFBcUI7SUFDNUMsTUFBTSxPQUFPLE1BQU0sUUFBUSxjQUFjO0lBQ3pDLE1BQU0sRUFBRSxhQUFhLFFBQVE7SUFDN0IsTUFBTSxRQUFRLFdBQVcsYUFBYTtJQUN0QyxPQUFPO0tBQ04sT0FBTyxNQUFNLEtBQUssT0FBTyxNQUFNLFFBQVE7S0FDdkMsWUFBWSxNQUFNLEtBQUssWUFBWSxPQUFPLFFBQVE7SUFDbkQ7R0FDRDtHQUNBLElBQUksYUFBYSxTQUFTLFFBQVE7SUFDakMsTUFBTSxXQUFXLGNBQWM7SUFDL0IsTUFBTSxjQUFjLFdBQVcsdUJBQXVCO0lBQ3RELE1BQU0sVUFBVTtLQUNmLE9BQU87S0FDUCxZQUFZO0lBQ2I7SUFDQSxTQUFTLE1BQU0sVUFBVSxTQUFTLFlBQVksU0FBUyxPQUFPLEdBQUcsUUFBUTtHQUMxRSxPQUFPO0lBQ04sTUFBTSxpQkFBaUIsU0FBUyxTQUFTO0lBQ3pDLEdBQUc7S0FDRixNQUFNLFFBQVEsZ0JBQWdCLElBQUksY0FBYyxPQUFPLEtBQUssSUFBSSxRQUFRLG1CQUFtQixjQUFjLEtBQUssaUJBQWlCLFNBQVMsTUFBTTtLQUM5SSxJQUFJLGNBQWMsS0FBSyxTQUFTLE1BQU07S0FDdEMsU0FBUyxNQUFNLFVBQVUsUUFBUSxLQUFLO0tBQ3RDO0lBQ0QsU0FBUyxjQUFjO0dBQ3hCO0dBQ0EsT0FBTztFQUNSO0VBQ0EsSUFBSSxRQUFRLFFBQVEsV0FBVyxRQUFRLGdCQUFnQjtHQUN0RCxPQUFPLFFBQVEsUUFBUSxZQUFZLFNBQVM7SUFDM0MsUUFBUSxRQUFRO0lBQ2hCLFVBQVUsUUFBUTtJQUNsQixNQUFNLFFBQVEsUUFBUTtJQUN0QixRQUFRLFFBQVE7R0FDakIsR0FBRyxLQUFLO0VBQ1Q7T0FDSyxRQUFRLFVBQVU7Q0FDeEIsRUFBRTtBQUNIOzs7Ozs7O0FBT0EsU0FBUyxpQkFBaUIsU0FBUyxFQUFFLE9BQU8sY0FBYztDQUN6RCxNQUFNLFlBQVksTUFBTSxTQUFTO0NBQ2pDLE9BQU8sTUFBTSxTQUFTLElBQUksUUFBUSxpQkFBaUIsTUFBTSxZQUFZLE9BQU8sV0FBVyxZQUFZLFVBQVUsSUFBSSxLQUFLO0FBQ3ZIOzs7Ozs7Ozs7QUFTQSxTQUFTLHFCQUFxQixTQUFTLEVBQUUsT0FBTyxjQUFjO0NBQzdELE9BQU8sTUFBTSxTQUFTLElBQUksUUFBUSx1QkFBdUIsTUFBTSxJQUFJLE9BQU8sV0FBVyxJQUFJLFVBQVUsSUFBSSxLQUFLO0FBQzdHOzs7Ozs7O0FBT0EsU0FBUyxZQUFZLFNBQVMsTUFBTTtDQUNuQyxJQUFJLENBQUMsTUFBTSxPQUFPO0NBQ2xCLE9BQU8saUJBQWlCLFNBQVMsSUFBSSxLQUFLO0FBQzNDOzs7Ozs7OztBQVFBLFNBQVMsZ0JBQWdCLFNBQVMsTUFBTTtDQUN2QyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsc0JBQXNCLE9BQU87Q0FDbkQsT0FBTyxxQkFBcUIsU0FBUyxJQUFJLEtBQUs7QUFDL0M7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pHQSxJQUFJLFFBQVEsY0FBYyxVQUFVO0NBQ25DO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxZQUFZLFFBQVE7RUFDbkIsTUFBTTtFQUNOLEtBQUssdUJBQXVCO0VBQzVCLEtBQUssa0JBQWtCLE9BQU87RUFDOUIsS0FBSyxXQUFXLE9BQU8sT0FBTztFQUM5QixLQUFLLFlBQVksQ0FBQztFQUNsQixLQUFLLFVBQVUsT0FBTztFQUN0QixLQUFLLFNBQVMsS0FBSyxRQUFRLGNBQWM7RUFDekMsS0FBSyxXQUFXLE9BQU87RUFDdkIsS0FBSyxZQUFZLE9BQU87RUFDeEIsS0FBSyxnQkFBZ0JDLGtCQUFnQixLQUFLLE9BQU87RUFDakQsS0FBSyxRQUFRLE9BQU8sU0FBUyxLQUFLO0VBQ2xDLEtBQUssV0FBVztDQUNqQjs7Ozs7Q0FLQSxJQUFJLE9BQU87RUFDVixPQUFPLEtBQUssUUFBUTtDQUNyQjs7Ozs7O0NBTUEsSUFBSSxZQUFZO0VBQ2YsT0FBTyxLQUFLO0NBQ2I7Ozs7OztDQU1BLElBQUksVUFBVTtFQUNiLE9BQU8sS0FBSyxVQUFVO0NBQ3ZCOzs7Ozs7O0NBT0EsV0FBVyxTQUFTO0VBQ25CLEtBQUssVUFBVTtHQUNkLEdBQUcsS0FBSztHQUNSLEdBQUc7RUFDSjtFQUNBLElBQUksU0FBUyxPQUFPLEtBQUssYUFBYSxRQUFRO0VBQzlDLEtBQUssYUFBYSxLQUFLLFFBQVEsTUFBTTtFQUNyQyxJQUFJLEtBQUssU0FBUyxLQUFLLE1BQU0sU0FBUyxLQUFLLEdBQUc7R0FDN0MsTUFBTSxlQUFlQSxrQkFBZ0IsS0FBSyxPQUFPO0dBQ2pELElBQUksYUFBYSxTQUFTLEtBQUssR0FBRztJQUNqQyxLQUFLLFNBQVMsYUFBYSxhQUFhLE1BQU0sYUFBYSxhQUFhLENBQUM7SUFDekUsS0FBSyxnQkFBZ0I7R0FDdEI7RUFDRDtDQUNEO0NBQ0EsaUJBQWlCO0VBQ2hCLElBQUksQ0FBQyxLQUFLLFVBQVUsVUFBVSxLQUFLLE1BQU0sZ0JBQWdCLFFBQVEsS0FBSyxPQUFPLE9BQU8sSUFBSTtDQUN6Rjs7Ozs7Ozs7O0NBU0EsUUFBUSxTQUFTLFNBQVM7RUFDekIsTUFBTSxPQUFPLFlBQVksS0FBSyxNQUFNLE1BQU0sU0FBUyxLQUFLLE9BQU87RUFDL0QsS0FBSyxVQUFVO0dBQ2Q7R0FDQSxNQUFNO0dBQ04sZUFBZSxTQUFTO0dBQ3hCLFFBQVEsU0FBUztFQUNsQixDQUFDO0VBQ0QsT0FBTztDQUNSOzs7Ozs7O0NBT0EsU0FBUyxPQUFPO0VBQ2YsS0FBSyxVQUFVO0dBQ2QsTUFBTTtHQUNOO0VBQ0QsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7O0NBYUEsT0FBTyxTQUFTO0VBQ2YsTUFBTSxVQUFVLEtBQUssVUFBVTtFQUMvQixLQUFLLFVBQVUsT0FBTyxPQUFPO0VBQzdCLE9BQU8sVUFBVSxRQUFRLEtBQUssSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJLElBQUksUUFBUSxRQUFRO0NBQ25FOzs7Ozs7O0NBT0EsVUFBVTtFQUNULE1BQU0sUUFBUTtFQUNkLEtBQUssT0FBTyxFQUFFLFFBQVEsS0FBSyxDQUFDO0NBQzdCOzs7Ozs7Q0FNQSxJQUFJLGFBQWE7RUFDaEIsT0FBTyxLQUFLO0NBQ2I7Ozs7OztDQU1BLFFBQVE7RUFDUCxLQUFLLFFBQVE7RUFDYixLQUFLLFNBQVMsS0FBSyxVQUFVO0NBQzlCOzs7Ozs7Q0FNQSxXQUFXO0VBQ1YsT0FBTyxLQUFLLFVBQVUsTUFBTSxhQUFhLGtCQUFrQixTQUFTLFFBQVEsU0FBUyxJQUFJLE1BQU0sS0FBSztDQUNyRzs7Ozs7Ozs7OztDQVVBLGFBQWE7RUFDWixJQUFJLEtBQUssa0JBQWtCLElBQUksR0FBRyxPQUFPLENBQUMsS0FBSyxTQUFTO0VBQ3hELE9BQU8sS0FBSyxRQUFRLFlBQVksYUFBYSxDQUFDLEtBQUssVUFBVTtDQUM5RDs7Ozs7O0NBTUEsWUFBWTtFQUNYLE9BQU8sS0FBSyxNQUFNLGtCQUFrQixLQUFLLE1BQU0sbUJBQW1CO0NBQ25FOzs7Ozs7Q0FNQSxXQUFXO0VBQ1YsSUFBSSxLQUFLLGtCQUFrQixJQUFJLEdBQUcsT0FBTyxLQUFLLFVBQVUsTUFBTSxhQUFhLGtCQUFrQixTQUFTLFFBQVEsV0FBVyxJQUFJLE1BQU0sUUFBUTtFQUMzSSxPQUFPO0NBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLFVBQVU7RUFDVCxJQUFJLEtBQUssa0JBQWtCLElBQUksR0FBRyxPQUFPLEtBQUssVUFBVSxNQUFNLGFBQWEsU0FBUyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU87RUFDOUcsT0FBTyxLQUFLLE1BQU0sU0FBUyxLQUFLLEtBQUssS0FBSyxNQUFNO0NBQ2pEOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxjQUFjLFlBQVksR0FBRztFQUM1QixJQUFJLEtBQUssTUFBTSxTQUFTLEtBQUssR0FBRyxPQUFPO0VBQ3ZDLElBQUksY0FBYyxVQUFVLE9BQU87RUFDbkMsSUFBSSxLQUFLLE1BQU0sZUFBZSxPQUFPO0VBQ3JDLE9BQU8sQ0FBQyxlQUFlLEtBQUssTUFBTSxlQUFlLFNBQVM7Q0FDM0Q7Ozs7OztDQU1BLFVBQVU7RUFDVCxLQUFLLFVBQVUsTUFBTSxNQUFNLEVBQUUseUJBQXlCLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxlQUFlLE1BQU0sQ0FBQztFQUMxRixLQUFLLFVBQVUsU0FBUztDQUN6Qjs7Ozs7O0NBTUEsV0FBVztFQUNWLEtBQUssVUFBVSxNQUFNLE1BQU0sRUFBRSx1QkFBdUIsQ0FBQyxDQUFDLEVBQUUsUUFBUSxFQUFFLGVBQWUsTUFBTSxDQUFDO0VBQ3hGLEtBQUssVUFBVSxTQUFTO0NBQ3pCOzs7Ozs7O0NBT0EsWUFBWSxVQUFVO0VBQ3JCLElBQUksQ0FBQyxLQUFLLFVBQVUsU0FBUyxRQUFRLEdBQUc7R0FDdkMsS0FBSyxVQUFVLEtBQUssUUFBUTtHQUM1QixLQUFLLGVBQWU7R0FDcEIsS0FBSyxPQUFPLE9BQU87SUFDbEIsTUFBTTtJQUNOLE9BQU87SUFDUDtHQUNELENBQUM7RUFDRjtDQUNEOzs7Ozs7OztDQVFBLGVBQWUsVUFBVTtFQUN4QixNQUFNLFFBQVEsS0FBSyxVQUFVLFFBQVEsUUFBUTtFQUM3QyxJQUFJLFVBQVUsSUFBSTtHQUNqQixLQUFLLFVBQVUsT0FBTyxPQUFPLENBQUM7R0FDOUIsSUFBSSxDQUFDLEtBQUssVUFBVSxRQUFRO0lBQzNCLElBQUksS0FBSyxVQUFVO0tBQ2xCLElBQUksS0FBSyx3QkFBd0IsS0FBSyxNQUFNLGdCQUFnQixZQUFZLEtBQUssTUFBTSxXQUFXLFdBQVcsS0FBSyxTQUFTLE9BQU8sRUFBRSxRQUFRLEtBQUssQ0FBQztVQUN6SSxLQUFLLFNBQVMsWUFBWTtJQUNoQztJQUNBLEtBQUssV0FBVztHQUNqQjtHQUNBLEtBQUssT0FBTyxPQUFPO0lBQ2xCLE1BQU07SUFDTixPQUFPO0lBQ1A7R0FDRCxDQUFDO0VBQ0Y7Q0FDRDs7Ozs7Ozs7Ozs7Q0FXQSxvQkFBb0I7RUFDbkIsT0FBTyxLQUFLLFVBQVU7Q0FDdkI7Ozs7Ozs7Ozs7Q0FVQSxhQUFhO0VBQ1osSUFBSSxDQUFDLEtBQUssTUFBTSxlQUFlLEtBQUssVUFBVSxFQUFFLE1BQU0sYUFBYSxDQUFDO0NBQ3JFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsTUFBTSxNQUFNLFNBQVMsY0FBYztFQUNsQyxJQUFJLEtBQUssTUFBTSxnQkFBZ0IsVUFBVSxLQUFLLFVBQVUsT0FBTyxNQUFNLFlBQVk7R0FDaEYsSUFBSSxLQUFLLE1BQU0sU0FBUyxLQUFLLEtBQUssY0FBYyxlQUFlLEtBQUssT0FBTyxFQUFFLFFBQVEsS0FBSyxDQUFDO1FBQ3RGLElBQUksS0FBSyxVQUFVO0lBQ3ZCLEtBQUssU0FBUyxjQUFjO0lBQzVCLE9BQU8sS0FBSyxTQUFTO0dBQ3RCO0VBQ0Q7RUFDQSxJQUFJLFNBQVMsS0FBSyxXQUFXLE9BQU87RUFDcEMsSUFBSSxDQUFDLEtBQUssUUFBUSxTQUFTO0dBQzFCLE1BQU0sV0FBVyxLQUFLLFVBQVUsTUFBTSxNQUFNLEVBQUUsUUFBUSxPQUFPO0dBQzdELElBQUksVUFBVSxLQUFLLFdBQVcsU0FBUyxPQUFPO0VBQy9DO0VBRUMsSUFBSSxDQUFDLE1BQU0sUUFBUSxLQUFLLFFBQVEsUUFBUSxHQUFHLFFBQVEsTUFBTSxxSUFBcUk7RUFFL0wsTUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0I7RUFDNUMsTUFBTSxxQkFBcUIsV0FBVztHQUNyQyxPQUFPLGVBQWUsUUFBUSxVQUFVO0lBQ3ZDLFlBQVk7SUFDWixXQUFXO0tBQ1YsS0FBSyx1QkFBdUI7S0FDNUIsT0FBTyxnQkFBZ0I7SUFDeEI7R0FDRCxDQUFDO0VBQ0Y7RUFDQSxNQUFNLGdCQUFnQjtHQUNyQixNQUFNLFVBQVUsY0FBYyxLQUFLLFNBQVMsWUFBWTtHQUN4RCxNQUFNLDZCQUE2QjtJQUNsQyxNQUFNLGlCQUFpQjtLQUN0QixRQUFRLEtBQUs7S0FDYixVQUFVLEtBQUs7S0FDZixNQUFNLEtBQUs7SUFDWjtJQUNBLGtCQUFrQixjQUFjO0lBQ2hDLE9BQU87R0FDUjtHQUNBLE1BQU0saUJBQWlCLHFCQUFxQjtHQUM1QyxLQUFLLHVCQUF1QjtHQUM1QixJQUFJLEtBQUssUUFBUSxXQUFXLE9BQU8sS0FBSyxRQUFRLFVBQVUsU0FBUyxnQkFBZ0IsSUFBSTtHQUN2RixPQUFPLFFBQVEsY0FBYztFQUM5QjtFQUNBLE1BQU0sMkJBQTJCO0dBQ2hDLE1BQU0sVUFBVTtJQUNmO0lBQ0EsU0FBUyxLQUFLO0lBQ2QsVUFBVSxLQUFLO0lBQ2YsUUFBUSxLQUFLO0lBQ2IsT0FBTyxLQUFLO0lBQ1o7R0FDRDtHQUNBLGtCQUFrQixPQUFPO0dBQ3pCLE9BQU87RUFDUjtFQUNBLE1BQU0sVUFBVSxtQkFBbUI7RUFDbkMsQ0FBQyxLQUFLLGVBQWUsYUFBYSxzQkFBc0IsS0FBSyxRQUFRLEtBQUssSUFBSSxLQUFLLFFBQVEsU0FBQSxFQUFXLFFBQVEsU0FBUyxJQUFJO0VBQzNILEtBQUssZUFBZSxLQUFLO0VBQ3pCLElBQUksS0FBSyxNQUFNLGdCQUFnQixVQUFVLEtBQUssTUFBTSxjQUFjLFFBQVEsY0FBYyxNQUFNLEtBQUssVUFBVTtHQUM1RyxNQUFNO0dBQ04sTUFBTSxRQUFRLGNBQWM7RUFDN0IsQ0FBQztFQUNELE1BQU0sVUFBVSxLQUFLLFdBQVcsY0FBYztHQUM3QyxnQkFBZ0IsY0FBYztHQUM5QixJQUFJLFFBQVE7R0FDWixXQUFXLFVBQVU7SUFDcEIsSUFBSSxpQkFBaUIsa0JBQWtCLE1BQU0sUUFBUSxLQUFLLFNBQVM7S0FDbEUsR0FBRyxLQUFLO0tBQ1IsYUFBYTtJQUNkLENBQUM7SUFDRCxnQkFBZ0IsTUFBTTtHQUN2QjtHQUNBLFNBQVMsY0FBYyxVQUFVO0lBQ2hDLEtBQUssVUFBVTtLQUNkLE1BQU07S0FDTjtLQUNBO0lBQ0QsQ0FBQztHQUNGO0dBQ0EsZUFBZTtJQUNkLEtBQUssVUFBVSxFQUFFLE1BQU0sUUFBUSxDQUFDO0dBQ2pDO0dBQ0Esa0JBQWtCO0lBQ2pCLEtBQUssVUFBVSxFQUFFLE1BQU0sV0FBVyxDQUFDO0dBQ3BDO0dBQ0EsT0FBTyxRQUFRLFFBQVE7R0FDdkIsWUFBWSxRQUFRLFFBQVE7R0FDNUIsYUFBYSxRQUFRLFFBQVE7R0FDN0IsY0FBYztFQUNmLENBQUM7RUFDRCxJQUFJO0dBQ0gsTUFBTSxPQUFPLE1BQU0sUUFBUSxNQUFNO0dBQ2pDLElBQUksU0FBUyxLQUFLLEdBQUc7SUFDdUIsUUFBUSxNQUFNLHlJQUF5SSxLQUFLLFdBQVc7SUFDbE4sTUFBTSxJQUFJLE1BQU0sR0FBRyxLQUFLLFVBQVUsbUJBQW1CO0dBQ3REO0dBQ0EsS0FBSyxRQUFRLElBQUk7R0FDakIsS0FBSyxPQUFPLE9BQU8sWUFBWSxNQUFNLElBQUk7R0FDekMsS0FBSyxPQUFPLE9BQU8sWUFBWSxNQUFNLEtBQUssTUFBTSxPQUFPLElBQUk7R0FDM0QsT0FBTztFQUNSLFNBQVMsT0FBTztHQUNmLElBQUksaUJBQWlCLGdCQUFnQjtJQUNwQyxJQUFJLE1BQU0sUUFBUSxPQUFPLEtBQUssU0FBUztTQUNsQyxJQUFJLE1BQU0sUUFBUTtLQUN0QixJQUFJLEtBQUssTUFBTSxTQUFTLEtBQUssR0FBRyxNQUFNO0tBQ3RDLE9BQU8sS0FBSyxNQUFNO0lBQ25CO0dBQ0Q7R0FDQSxLQUFLLFVBQVU7SUFDZCxNQUFNO0lBQ047R0FDRCxDQUFDO0dBQ0QsS0FBSyxPQUFPLE9BQU8sVUFBVSxPQUFPLElBQUk7R0FDeEMsS0FBSyxPQUFPLE9BQU8sWUFBWSxLQUFLLE1BQU0sTUFBTSxPQUFPLElBQUk7R0FDM0QsTUFBTTtFQUNQLFVBQVU7R0FDVCxJQUFJLEtBQUssYUFBYSxTQUFTLEtBQUssV0FBVyxLQUFLO0dBQ3BELEtBQUssV0FBVztFQUNqQjtDQUNEO0NBQ0EsVUFBVSxRQUFRO0VBQ2pCLE1BQU0sV0FBVyxVQUFVO0dBQzFCLFFBQVEsT0FBTyxNQUFmO0lBQ0MsS0FBSyxVQUFVLE9BQU87S0FDckIsR0FBRztLQUNILG1CQUFtQixPQUFPO0tBQzFCLG9CQUFvQixPQUFPO0lBQzVCO0lBQ0EsS0FBSyxTQUFTLE9BQU87S0FDcEIsR0FBRztLQUNILGFBQWE7SUFDZDtJQUNBLEtBQUssWUFBWSxPQUFPO0tBQ3ZCLEdBQUc7S0FDSCxhQUFhO0lBQ2Q7SUFDQSxLQUFLLFNBQVMsT0FBTztLQUNwQixHQUFHO0tBQ0gsR0FBRyxXQUFXLE1BQU0sTUFBTSxLQUFLLE9BQU87S0FDdEMsV0FBVyxPQUFPLFFBQVE7SUFDM0I7SUFDQSxLQUFLO0tBQ0osTUFBTSxXQUFXO01BQ2hCLEdBQUc7TUFDSCxHQUFHLGFBQWEsT0FBTyxNQUFNLE9BQU8sYUFBYTtNQUNqRCxpQkFBaUIsTUFBTSxrQkFBa0I7TUFDekMsR0FBRyxDQUFDLE9BQU8sVUFBVTtPQUNwQixhQUFhO09BQ2IsbUJBQW1CO09BQ25CLG9CQUFvQjtNQUNyQjtLQUNEO0tBQ0EsS0FBSyxlQUFlLE9BQU8sU0FBUyxXQUFXLEtBQUs7S0FDcEQsT0FBTztJQUNSLEtBQUs7S0FDSixNQUFNLFFBQVEsT0FBTztLQUNyQixPQUFPO01BQ04sR0FBRztNQUNIO01BQ0Esa0JBQWtCLE1BQU0sbUJBQW1CO01BQzNDLGdCQUFnQixLQUFLLElBQUk7TUFDekIsbUJBQW1CLE1BQU0sb0JBQW9CO01BQzdDLG9CQUFvQjtNQUNwQixhQUFhO01BQ2IsUUFBUTtNQUNSLGVBQWU7S0FDaEI7SUFDRCxLQUFLLGNBQWMsT0FBTztLQUN6QixHQUFHO0tBQ0gsZUFBZTtJQUNoQjtJQUNBLEtBQUssWUFBWSxPQUFPO0tBQ3ZCLEdBQUc7S0FDSCxHQUFHLE9BQU87SUFDWDtHQUNEO0VBQ0Q7RUFDQSxLQUFLLFFBQVEsUUFBUSxLQUFLLEtBQUs7RUFDL0IsY0FBYyxZQUFZO0dBQ3pCLEtBQUssVUFBVSxNQUFNLENBQUMsQ0FBQyxTQUFTLGFBQWE7SUFDNUMsU0FBUyxjQUFjO0dBQ3hCLENBQUM7R0FDRCxLQUFLLE9BQU8sT0FBTztJQUNsQixPQUFPO0lBQ1AsTUFBTTtJQUNOO0dBQ0QsQ0FBQztFQUNGLENBQUM7Q0FDRjtBQUNEOzs7Ozs7Ozs7QUFTQSxTQUFTLFdBQVcsTUFBTSxTQUFTO0NBQ2xDLE9BQU87RUFDTixtQkFBbUI7RUFDbkIsb0JBQW9CO0VBQ3BCLGFBQWEsU0FBUyxRQUFRLFdBQVcsSUFBSSxhQUFhO0VBQzFELEdBQUcsU0FBUyxLQUFLLEtBQUs7R0FDckIsT0FBTztHQUNQLFFBQVE7RUFDVDtDQUNEO0FBQ0Q7Ozs7Ozs7QUFPQSxTQUFTLGFBQWEsTUFBTSxlQUFlO0NBQzFDLE9BQU87RUFDTjtFQUNBLGVBQWUsaUJBQWlCLEtBQUssSUFBSTtFQUN6QyxPQUFPO0VBQ1AsZUFBZTtFQUNmLFFBQVE7Q0FDVDtBQUNEOzs7Ozs7O0FBT0EsU0FBU0Esa0JBQWdCLFNBQVM7Q0FDakMsTUFBTSxPQUFPLE9BQU8sUUFBUSxnQkFBZ0IsYUFBYSxRQUFRLFlBQVksSUFBSSxRQUFRO0NBQ3pGLE1BQU0sVUFBVSxTQUFTLEtBQUs7Q0FDOUIsTUFBTSx1QkFBdUIsVUFBVSxPQUFPLFFBQVEseUJBQXlCLGFBQWEsUUFBUSxxQkFBcUIsSUFBSSxRQUFRLHVCQUF1QjtDQUM1SixPQUFPO0VBQ047RUFDQSxpQkFBaUI7RUFDakIsZUFBZSxVQUFVLHdCQUF3QixLQUFLLElBQUksSUFBSTtFQUM5RCxPQUFPO0VBQ1Asa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixtQkFBbUI7RUFDbkIsb0JBQW9CO0VBQ3BCLFdBQVc7RUFDWCxlQUFlO0VBQ2YsUUFBUSxVQUFVLFlBQVk7RUFDOUIsYUFBYTtDQUNkO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxakJBLElBQUksZ0JBQWdCLGNBQWMsYUFBYTtDQUM5QztDQUNBLGdCQUFnQixLQUFLO0NBQ3JCLDRCQUE0QixLQUFLO0NBQ2pDLGlCQUFpQixLQUFLO0NBQ3RCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLGdDQUFnQyxJQUFJLElBQUk7Q0FDeEMsWUFBWSxRQUFRLFNBQVM7RUFDNUIsTUFBTTtFQUNOLEtBQUssVUFBVTtFQUNmLEtBQUssVUFBVTtFQUNmLEtBQUssZUFBZTtFQUNwQixLQUFLLFlBQVk7RUFDakIsS0FBSyxXQUFXLE9BQU87Q0FDeEI7Ozs7O0NBS0EsY0FBYztFQUNiLEtBQUssVUFBVSxLQUFLLFFBQVEsS0FBSyxJQUFJO0NBQ3RDO0NBQ0EsY0FBYztFQUNiLElBQUksS0FBSyxVQUFVLFNBQVMsR0FBRztHQUM5QixLQUFLLGNBQWMsWUFBWSxJQUFJO0dBQ25DLElBQUksbUJBQW1CLEtBQUssZUFBZSxLQUFLLE9BQU8sR0FBRyxLQUFLLGNBQWM7UUFDeEUsS0FBSyxhQUFhO0dBQ3ZCLEtBQUssY0FBYztFQUNwQjtDQUNEO0NBQ0EsZ0JBQWdCO0VBQ2YsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUFHLEtBQUssUUFBUTtDQUN4Qzs7Ozs7OztDQU9BLHlCQUF5QjtFQUN4QixPQUFPLGNBQWMsS0FBSyxlQUFlLEtBQUssU0FBUyxLQUFLLFFBQVEsa0JBQWtCO0NBQ3ZGOzs7Ozs7O0NBT0EsMkJBQTJCO0VBQzFCLE9BQU8sY0FBYyxLQUFLLGVBQWUsS0FBSyxTQUFTLEtBQUssUUFBUSxvQkFBb0I7Q0FDekY7Ozs7OztDQU1BLFVBQVU7RUFDVCxLQUFLLDRCQUE0QixJQUFJLElBQUk7RUFDekMsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxzQkFBc0I7RUFDM0IsS0FBSyxjQUFjLGVBQWUsSUFBSTtDQUN2Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsV0FBVyxTQUFTO0VBQ25CLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLE1BQU0sWUFBWSxLQUFLO0VBQ3ZCLEtBQUssVUFBVSxLQUFLLFFBQVEsb0JBQW9CLE9BQU87RUFDdkQsSUFBSSxLQUFLLFFBQVEsWUFBWSxLQUFLLEtBQUssT0FBTyxLQUFLLFFBQVEsWUFBWSxhQUFhLE9BQU8sS0FBSyxRQUFRLFlBQVksY0FBYyxPQUFPLGtCQUFrQixLQUFLLFFBQVEsU0FBUyxLQUFLLGFBQWEsTUFBTSxXQUFXLE1BQU0sSUFBSSxNQUFNLHVFQUF1RTtFQUMzUyxLQUFLLGFBQWE7RUFDbEIsS0FBSyxjQUFjLFdBQVcsS0FBSyxPQUFPO0VBQzFDLElBQUksWUFBWSxjQUFjLENBQUMsb0JBQW9CLEtBQUssU0FBUyxXQUFXLEdBQUcsS0FBSyxRQUFRLGNBQWMsQ0FBQyxDQUFDLE9BQU87R0FDbEgsTUFBTTtHQUNOLE9BQU8sS0FBSztHQUNaLFVBQVU7RUFDWCxDQUFDO0VBQ0QsTUFBTSxVQUFVLEtBQUssYUFBYTtFQUNsQyxJQUFJLFdBQVcsc0JBQXNCLEtBQUssZUFBZSxXQUFXLEtBQUssU0FBUyxXQUFXLEdBQUcsS0FBSyxjQUFjO0VBQ25ILEtBQUssYUFBYTtFQUNsQixJQUFJLFlBQVksS0FBSyxrQkFBa0IsYUFBYSxrQkFBa0IsS0FBSyxRQUFRLFNBQVMsS0FBSyxhQUFhLE1BQU0sa0JBQWtCLFlBQVksU0FBUyxLQUFLLGFBQWEsS0FBSyxrQkFBa0IsS0FBSyxRQUFRLFdBQVcsS0FBSyxhQUFhLE1BQU0sa0JBQWtCLFlBQVksV0FBVyxLQUFLLGFBQWEsSUFBSSxLQUFLLG9CQUFvQjtFQUM1VSxNQUFNLHNCQUFzQixLQUFLLHdCQUF3QjtFQUN6RCxJQUFJLFlBQVksS0FBSyxrQkFBa0IsYUFBYSxrQkFBa0IsS0FBSyxRQUFRLFNBQVMsS0FBSyxhQUFhLE1BQU0sa0JBQWtCLFlBQVksU0FBUyxLQUFLLGFBQWEsS0FBSyx3QkFBd0IsS0FBSywwQkFBMEIsS0FBSyx1QkFBdUIsbUJBQW1CO0NBQ3pSOzs7Ozs7Ozs7Q0FTQSxvQkFBb0IsU0FBUztFQUM1QixNQUFNLFFBQVEsS0FBSyxRQUFRLGNBQWMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxTQUFTLE9BQU87RUFDdEUsTUFBTSxTQUFTLEtBQUssYUFBYSxPQUFPLE9BQU87RUFDL0MsSUFBSSxDQUFDLG9CQUFvQixLQUFLLGlCQUFpQixHQUFHLE1BQU0sR0FBRztHQUMxRCxLQUFLLGlCQUFpQjtHQUN0QixLQUFLLHdCQUF3QixLQUFLO0dBQ2xDLEtBQUssc0JBQXNCLEtBQUssY0FBYztFQUMvQztFQUNBLE9BQU87Q0FDUjs7Ozs7Ozs7Ozs7OztDQWFBLG1CQUFtQjtFQUNsQixPQUFPLEtBQUs7Q0FDYjs7Ozs7Ozs7OztDQVVBLFlBQVksUUFBUSxlQUFlO0VBQ2xDLE9BQU8sSUFBSSxNQUFNLFFBQVEsRUFBRSxNQUFNLFFBQVEsUUFBUTtHQUNoRCxLQUFLLFVBQVUsR0FBRztHQUNsQixnQkFBZ0IsR0FBRztHQUNuQixPQUFPLFFBQVEsSUFBSSxRQUFRLEdBQUc7RUFDL0IsRUFBRSxDQUFDO0NBQ0o7Ozs7Ozs7O0NBUUEsVUFBVSxLQUFLO0VBQ2QsS0FBSyxjQUFjLElBQUksR0FBRztDQUMzQjs7Ozs7Q0FLQSxrQkFBa0I7RUFDakIsT0FBTyxLQUFLO0NBQ2I7Ozs7Ozs7Ozs7Ozs7Q0FhQSxRQUFRLEVBQUUsR0FBRyxZQUFZLENBQUMsR0FBRztFQUM1QixPQUFPLEtBQUssTUFBTSxFQUFFLEdBQUcsUUFBUSxDQUFDO0NBQ2pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsZ0JBQWdCLFNBQVM7RUFDeEIsTUFBTSxtQkFBbUIsS0FBSyxRQUFRLG9CQUFvQixPQUFPO0VBQ2pFLE1BQU0sUUFBUSxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsTUFBTSxLQUFLLFNBQVMsZ0JBQWdCO0VBQy9FLElBQUksb0JBQW9CLENBQUM7RUFDekIsSUFBSTtFQUNKLE1BQU0sZUFBZSxJQUFJLFNBQVMsWUFBWTtHQUM3QyxlQUFlO0dBQ2YsY0FBYyxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsV0FBVyxVQUFVO0lBQy9ELElBQUksTUFBTSxTQUFTLGFBQWEsTUFBTSxNQUFNLGNBQWMsTUFBTSxhQUFhLE1BQU0sTUFBTSxTQUFTLEtBQUssR0FBRztLQUN6RyxZQUFZO0tBQ1osUUFBUSxLQUFLLGFBQWEsT0FBTyxnQkFBZ0IsQ0FBQztJQUNuRDtHQUNELENBQUM7RUFDRixDQUFDO0VBQ0QsT0FBTyxRQUFRLEtBQUssQ0FBQyxNQUFNLE1BQU0sZ0JBQWdCLENBQUMsQ0FBQyxXQUFXO0dBQzdELE1BQU0sU0FBUyxLQUFLLGFBQWEsT0FBTyxnQkFBZ0I7R0FDeEQsZUFBZSxNQUFNO0dBQ3JCLE9BQU87RUFDUixDQUFDLENBQUMsQ0FBQyxjQUFjO0dBQ2hCLFlBQVk7RUFDYixDQUFDLEdBQUcsWUFBWSxDQUFDO0NBQ2xCOzs7Ozs7O0NBT0EsTUFBTSxjQUFjO0VBQ25CLE9BQU8sS0FBSyxjQUFjO0dBQ3pCLEdBQUc7R0FDSCxlQUFlLGFBQWEsaUJBQWlCO0VBQzlDLENBQUMsQ0FBQyxDQUFDLFdBQVc7R0FDYixLQUFLLGFBQWE7R0FDbEIsT0FBTyxLQUFLO0VBQ2IsQ0FBQztDQUNGO0NBQ0EsY0FBYyxjQUFjO0VBQzNCLEtBQUssYUFBYTtFQUNsQixJQUFJLFVBQVUsS0FBSyxjQUFjLE1BQU0sS0FBSyxTQUFTLFlBQVk7RUFDakUsSUFBSSxDQUFDLGNBQWMsY0FBYyxVQUFVLFFBQVEsTUFBTSxJQUFJO0VBQzdELE9BQU87Q0FDUjtDQUNBLHFCQUFxQixTQUFTO0VBQzdCLE9BQU8sQ0FBQ0MsV0FBUyxLQUFLLGtCQUFrQixLQUFLLFFBQVEsU0FBUyxLQUFLLGFBQWEsTUFBTSxTQUFTLGVBQWUsT0FBTztDQUN0SDtDQUNBLHNCQUFzQjtFQUNyQixLQUFLLG1CQUFtQjtFQUN4QixNQUFNLFlBQVksa0JBQWtCLEtBQUssUUFBUSxXQUFXLEtBQUssYUFBYTtFQUM5RSxJQUFJLEtBQUssZUFBZSxXQUFXLENBQUMsS0FBSyxxQkFBcUIsU0FBUyxHQUFHO0VBQzFFLE1BQU0sVUFBVSxlQUFlLEtBQUssZUFBZSxlQUFlLFNBQVMsSUFBSTtFQUMvRSxLQUFLLGtCQUFrQixlQUFlLGlCQUFpQjtHQUN0RCxJQUFJLENBQUMsS0FBSyxlQUFlLFNBQVMsS0FBSyxhQUFhO0VBQ3JELEdBQUcsT0FBTztDQUNYO0NBQ0EsMEJBQTBCO0VBQ3pCLE9BQU8sa0JBQWtCLEtBQUssUUFBUSxpQkFBaUIsS0FBSyxhQUFhLEtBQUs7Q0FDL0U7Q0FDQSx1QkFBdUIsY0FBYztFQUNwQyxLQUFLLHNCQUFzQjtFQUMzQixLQUFLLDBCQUEwQjtFQUMvQixJQUFJLEtBQUssNEJBQTRCLEtBQUssQ0FBQyxLQUFLLHFCQUFxQixLQUFLLHVCQUF1QixHQUFHO0VBQ3BHLEtBQUsscUJBQXFCLGVBQWUsa0JBQWtCO0dBQzFELElBQUksS0FBSyxRQUFRLCtCQUErQixhQUFhLFVBQVUsR0FBRyxLQUFLLGNBQWM7RUFDOUYsR0FBRyxLQUFLLHVCQUF1QjtDQUNoQztDQUNBLGdCQUFnQjtFQUNmLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssdUJBQXVCLEtBQUssd0JBQXdCLENBQUM7Q0FDM0Q7Q0FDQSxxQkFBcUI7RUFDcEIsSUFBSSxLQUFLLG9CQUFvQixLQUFLLEdBQUc7R0FDcEMsZUFBZSxhQUFhLEtBQUssZUFBZTtHQUNoRCxLQUFLLGtCQUFrQixLQUFLO0VBQzdCO0NBQ0Q7Q0FDQSx3QkFBd0I7RUFDdkIsSUFBSSxLQUFLLHVCQUF1QixLQUFLLEdBQUc7R0FDdkMsZUFBZSxjQUFjLEtBQUssa0JBQWtCO0dBQ3BELEtBQUsscUJBQXFCLEtBQUs7RUFDaEM7Q0FDRDs7Ozs7Ozs7Q0FRQSxhQUFhLE9BQU8sU0FBUztFQUM1QixNQUFNLFlBQVksS0FBSztFQUN2QixNQUFNLGNBQWMsS0FBSztFQUN6QixNQUFNLGFBQWEsS0FBSztFQUN4QixNQUFNLGtCQUFrQixLQUFLO0VBQzdCLE1BQU0sb0JBQW9CLEtBQUs7RUFDL0IsTUFBTSxvQkFBb0IsVUFBVSxZQUFZLE1BQU0sUUFBUSxLQUFLO0VBQ25FLE1BQU0sRUFBRSxVQUFVO0VBQ2xCLElBQUksV0FBVyxFQUFFLEdBQUcsTUFBTTtFQUMxQixJQUFJLG9CQUFvQjtFQUN4QixJQUFJO0VBQ0osSUFBSSxRQUFRLG9CQUFvQjtHQUMvQixNQUFNLFVBQVUsS0FBSyxhQUFhO0dBQ2xDLE1BQU0sZUFBZSxDQUFDLFdBQVcsbUJBQW1CLE9BQU8sT0FBTztHQUNsRSxNQUFNLGtCQUFrQixXQUFXLHNCQUFzQixPQUFPLFdBQVcsU0FBUyxXQUFXO0dBQy9GLElBQUksZ0JBQWdCLGlCQUFpQixXQUFXO0lBQy9DLEdBQUc7SUFDSCxHQUFHLFdBQVcsTUFBTSxNQUFNLE1BQU0sT0FBTztHQUN4QztHQUNBLElBQUksUUFBUSx1QkFBdUIsZUFBZSxTQUFTLGNBQWM7RUFDMUU7RUFDQSxJQUFJLEVBQUUsT0FBTyxnQkFBZ0IsV0FBVztFQUN4QyxPQUFPLFNBQVM7RUFDaEIsSUFBSSxhQUFhO0VBQ2pCLElBQUksUUFBUSxvQkFBb0IsS0FBSyxLQUFLLFNBQVMsS0FBSyxLQUFLLFdBQVcsV0FBVztHQUNsRixJQUFJO0dBQ0osSUFBSSxZQUFZLHFCQUFxQixRQUFRLG9CQUFvQixtQkFBbUIsaUJBQWlCO0lBQ3BHLGtCQUFrQixXQUFXO0lBQzdCLGFBQWE7R0FDZCxPQUFPLGtCQUFrQixPQUFPLFFBQVEsb0JBQW9CLGFBQWEsUUFBUSxnQkFBZ0IsS0FBSywyQkFBMkIsTUFBTSxNQUFNLEtBQUsseUJBQXlCLElBQUksUUFBUTtHQUN2TCxJQUFJLG9CQUFvQixLQUFLLEdBQUc7SUFDL0IsU0FBUztJQUNULE9BQU8sWUFBWSxZQUFZLE1BQU0saUJBQWlCLE9BQU87SUFDN0Qsb0JBQW9CO0dBQ3JCO0VBQ0Q7RUFDQSxJQUFJLFFBQVEsVUFBVSxTQUFTLEtBQUssS0FBSyxDQUFDLFlBQVk7R0FDckQsSUFBSSxjQUFjLFNBQVMsaUJBQWlCLFFBQVEsUUFBUSxXQUFXLEtBQUssV0FBVyxPQUFPLEtBQUs7UUFDOUYsSUFBSTtJQUNSLEtBQUssWUFBWSxRQUFRO0lBQ3pCLE9BQU8sUUFBUSxPQUFPLElBQUk7SUFDMUIsT0FBTyxZQUFZLFlBQVksTUFBTSxNQUFNLE9BQU87SUFDbEQsS0FBSyxnQkFBZ0I7SUFDckIsS0FBSyxlQUFlO0dBQ3JCLFNBQVMsYUFBYTtJQUNyQixLQUFLLGVBQWU7R0FDckI7RUFDRCxPQUFPLElBQUksU0FBUyxLQUFLLEdBQUcsS0FBSyxlQUFlO0VBQ2hELElBQUksS0FBSyxjQUFjO0dBQ3RCLFFBQVEsS0FBSztHQUNiLE9BQU8sS0FBSztHQUNaLGlCQUFpQixLQUFLLElBQUk7R0FDMUIsU0FBUztHQUNULG9CQUFvQjtFQUNyQjtFQUNBLE1BQU0sYUFBYSxTQUFTLGdCQUFnQjtFQUM1QyxNQUFNLFlBQVksV0FBVztFQUM3QixNQUFNLFVBQVUsV0FBVztFQUMzQixNQUFNLFlBQVksYUFBYTtFQUMvQixNQUFNLFVBQVUsU0FBUyxLQUFLO0VBQzlCLE9BQU87R0FDTjtHQUNBLGFBQWEsU0FBUztHQUN0QjtHQUNBLFdBQVcsV0FBVztHQUN0QjtHQUNBLGtCQUFrQjtHQUNsQjtHQUNBO0dBQ0EsZUFBZSxTQUFTO0dBQ3hCO0dBQ0E7R0FDQSxjQUFjLFNBQVM7R0FDdkIsZUFBZSxTQUFTO0dBQ3hCLGtCQUFrQixTQUFTO0dBQzNCLFdBQVcsTUFBTSxVQUFVO0dBQzNCLHFCQUFxQixTQUFTLGtCQUFrQixrQkFBa0IsbUJBQW1CLFNBQVMsbUJBQW1CLGtCQUFrQjtHQUNuSTtHQUNBLGNBQWMsY0FBYyxDQUFDO0dBQzdCLGdCQUFnQixXQUFXLENBQUM7R0FDNUIsVUFBVSxTQUFTLGdCQUFnQjtHQUNuQztHQUNBLGdCQUFnQixXQUFXO0dBQzNCLFNBQVMsUUFBUSxPQUFPLE9BQU87R0FDL0IsU0FBUyxLQUFLO0dBQ2QsV0FBVyxrQkFBa0IsUUFBUSxTQUFTLEtBQUssTUFBTTtFQUMxRDtDQUNEOzs7Ozs7Q0FNQSxlQUFlO0VBQ2QsTUFBTSxhQUFhLEtBQUs7RUFDeEIsTUFBTSxhQUFhLEtBQUssYUFBYSxLQUFLLGVBQWUsS0FBSyxPQUFPO0VBQ3JFLEtBQUssc0JBQXNCLEtBQUssY0FBYztFQUM5QyxLQUFLLHdCQUF3QixLQUFLO0VBQ2xDLElBQUksS0FBSyxvQkFBb0IsU0FBUyxLQUFLLEdBQUcsS0FBSyw0QkFBNEIsS0FBSztFQUNwRixJQUFJLG9CQUFvQixZQUFZLFVBQVUsR0FBRztFQUNqRCxLQUFLLGlCQUFpQjtFQUN0QixNQUFNLDhCQUE4QjtHQUNuQyxJQUFJLENBQUMsWUFBWSxPQUFPO0dBQ3hCLE1BQU0sRUFBRSx3QkFBd0IsS0FBSztHQUNyQyxNQUFNLDJCQUEyQixPQUFPLHdCQUF3QixhQUFhLG9CQUFvQixJQUFJO0dBQ3JHLElBQUksNkJBQTZCLFNBQVMsQ0FBQyw0QkFBNEIsQ0FBQyxLQUFLLGNBQWMsTUFBTSxPQUFPO0dBQ3hHLE1BQU0sZ0JBQWdCLElBQUksSUFBSSw0QkFBNEIsS0FBSyxhQUFhO0dBQzVFLElBQUksS0FBSyxRQUFRLGNBQWMsY0FBYyxJQUFJLE9BQU87R0FDeEQsT0FBTyxPQUFPLEtBQUssS0FBSyxjQUFjLENBQUMsQ0FBQyxNQUFNLFFBQVE7SUFDckQsTUFBTSxXQUFXO0lBQ2pCLE9BQU8sS0FBSyxlQUFlLGNBQWMsV0FBVyxhQUFhLGNBQWMsSUFBSSxRQUFRO0dBQzVGLENBQUM7RUFDRjtFQUNBLE1BQU0sa0JBQWtCLHNCQUFzQjtFQUM5QyxjQUFjLFlBQVk7R0FDekIsSUFBSSxpQkFBaUIsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUN6RCxTQUFTLEtBQUssY0FBYztHQUM3QixDQUFDO0dBQ0QsS0FBSyxRQUFRLGNBQWMsQ0FBQyxDQUFDLE9BQU87SUFDbkMsT0FBTyxLQUFLO0lBQ1osTUFBTTtHQUNQLENBQUM7RUFDRixDQUFDO0NBQ0Y7Q0FDQSxlQUFlO0VBQ2QsTUFBTSxRQUFRLEtBQUssUUFBUSxjQUFjLENBQUMsQ0FBQyxNQUFNLEtBQUssU0FBUyxLQUFLLE9BQU87RUFDM0UsSUFBSSxVQUFVLEtBQUssZUFBZTtFQUNsQyxNQUFNLFlBQVksS0FBSztFQUN2QixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLDRCQUE0QixNQUFNO0VBQ3ZDLElBQUksS0FBSyxhQUFhLEdBQUc7R0FDeEIsV0FBVyxlQUFlLElBQUk7R0FDOUIsTUFBTSxZQUFZLElBQUk7RUFDdkI7Q0FDRDs7Ozs7O0NBTUEsZ0JBQWdCO0VBQ2YsS0FBSyxhQUFhO0VBQ2xCLElBQUksS0FBSyxhQUFhLEdBQUcsS0FBSyxjQUFjO0NBQzdDO0FBQ0Q7Ozs7Ozs7O0FBUUEsU0FBUyxrQkFBa0IsT0FBTyxTQUFTO0NBQzFDLE9BQU8sa0JBQWtCLFFBQVEsU0FBUyxLQUFLLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRSxNQUFNLE1BQU0sV0FBVyxXQUFXLGtCQUFrQixRQUFRLGNBQWMsS0FBSyxNQUFNO0FBQ3JMOzs7Ozs7OztBQVFBLFNBQVMsbUJBQW1CLE9BQU8sU0FBUztDQUMzQyxPQUFPLGtCQUFrQixPQUFPLE9BQU8sS0FBSyxNQUFNLE1BQU0sU0FBUyxLQUFLLEtBQUssY0FBYyxPQUFPLFNBQVMsUUFBUSxjQUFjO0FBQ2hJOzs7Ozs7Ozs7O0FBVUEsU0FBUyxjQUFjLE9BQU8sU0FBUyxPQUFPO0NBQzdDLElBQUksa0JBQWtCLFFBQVEsU0FBUyxLQUFLLE1BQU0sU0FBUyxrQkFBa0IsUUFBUSxXQUFXLEtBQUssTUFBTSxVQUFVO0VBQ3BILE1BQU0sUUFBUSxrQkFBa0IsT0FBTyxLQUFLO0VBQzVDLE9BQU8sVUFBVSxZQUFZLFVBQVUsU0FBUyxRQUFRLE9BQU8sT0FBTztDQUN2RTtDQUNBLE9BQU87QUFDUjs7Ozs7Ozs7OztBQVVBLFNBQVMsc0JBQXNCLE9BQU8sV0FBVyxTQUFTLGFBQWE7Q0FDdEUsUUFBUSxVQUFVLGFBQWEsa0JBQWtCLFlBQVksU0FBUyxLQUFLLE1BQU0sV0FBVyxDQUFDLFFBQVEsWUFBWSxNQUFNLE1BQU0sV0FBVyxZQUFZLFFBQVEsT0FBTyxPQUFPO0FBQzNLOzs7Ozs7O0FBT0EsU0FBUyxRQUFRLE9BQU8sU0FBUztDQUNoQyxPQUFPLGtCQUFrQixRQUFRLFNBQVMsS0FBSyxNQUFNLFNBQVMsTUFBTSxjQUFjLGtCQUFrQixRQUFRLFdBQVcsS0FBSyxDQUFDO0FBQzlIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuZkEsSUFBSSx3QkFBd0IsY0FBYyxjQUFjO0NBQ3ZELFlBQVksUUFBUSxTQUFTO0VBQzVCLE1BQU0sUUFBUSxPQUFPO0NBQ3RCO0NBQ0EsY0FBYztFQUNiLE1BQU0sWUFBWTtFQUNsQixLQUFLLGdCQUFnQixLQUFLLGNBQWMsS0FBSyxJQUFJO0VBQ2pELEtBQUssb0JBQW9CLEtBQUssa0JBQWtCLEtBQUssSUFBSTtDQUMxRDs7Ozs7Ozs7Q0FRQSxXQUFXLFNBQVM7RUFDbkIsUUFBUSxRQUFRO0VBQ2hCLE1BQU0sV0FBVyxPQUFPO0NBQ3pCOzs7Ozs7Ozs7Q0FTQSxvQkFBb0IsU0FBUztFQUM1QixRQUFRLFFBQVE7RUFDaEIsT0FBTyxNQUFNLG9CQUFvQixPQUFPO0NBQ3pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQkEsY0FBYyxTQUFTO0VBQ3RCLE9BQU8sS0FBSyxNQUFNO0dBQ2pCLEdBQUc7R0FDSCxNQUFNLEVBQUUsV0FBVyxFQUFFLFdBQVcsVUFBVSxFQUFFO0VBQzdDLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUJBLGtCQUFrQixTQUFTO0VBQzFCLE9BQU8sS0FBSyxNQUFNO0dBQ2pCLEdBQUc7R0FDSCxNQUFNLEVBQUUsV0FBVyxFQUFFLFdBQVcsV0FBVyxFQUFFO0VBQzlDLENBQUM7Q0FDRjtDQUNBLGFBQWEsT0FBTyxTQUFTO0VBQzVCLE1BQU0sRUFBRSxVQUFVO0VBQ2xCLE1BQU0sZUFBZSxNQUFNLGFBQWEsT0FBTyxPQUFPO0VBQ3RELE1BQU0sRUFBRSxZQUFZLGNBQWMsU0FBUyxtQkFBbUI7RUFDOUQsTUFBTSxpQkFBaUIsTUFBTSxXQUFXLFdBQVc7RUFDbkQsTUFBTSx1QkFBdUIsV0FBVyxtQkFBbUI7RUFDM0QsTUFBTSxxQkFBcUIsY0FBYyxtQkFBbUI7RUFDNUQsTUFBTSwyQkFBMkIsV0FBVyxtQkFBbUI7RUFDL0QsTUFBTSx5QkFBeUIsY0FBYyxtQkFBbUI7RUFDaEUsT0FBTztHQUNOLEdBQUc7R0FDSCxlQUFlLEtBQUs7R0FDcEIsbUJBQW1CLEtBQUs7R0FDeEIsYUFBYSxZQUFZLFNBQVMsTUFBTSxJQUFJO0dBQzVDLGlCQUFpQixnQkFBZ0IsU0FBUyxNQUFNLElBQUk7R0FDcEQ7R0FDQTtHQUNBO0dBQ0E7R0FDQSxnQkFBZ0Isa0JBQWtCLENBQUMsd0JBQXdCLENBQUM7R0FDNUQsY0FBYyxnQkFBZ0IsQ0FBQyxzQkFBc0IsQ0FBQztFQUN2RDtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1R0EsSUFBSSxXQUFXLGNBQWMsVUFBVTtDQUN0QztDQUNBO0NBQ0E7Q0FDQTtDQUNBLFlBQVksUUFBUTtFQUNuQixNQUFNO0VBQ04sS0FBSyxVQUFVLE9BQU87RUFDdEIsS0FBSyxhQUFhLE9BQU87RUFDekIsS0FBSyxpQkFBaUIsT0FBTztFQUM3QixLQUFLLGFBQWEsQ0FBQztFQUNuQixLQUFLLFFBQVEsT0FBTyxTQUFTLGdCQUFnQjtFQUM3QyxLQUFLLFdBQVcsT0FBTyxPQUFPO0VBQzlCLEtBQUssV0FBVztDQUNqQjs7Ozs7O0NBTUEsV0FBVyxTQUFTO0VBQ25CLEtBQUssVUFBVTtFQUNmLEtBQUssYUFBYSxLQUFLLFFBQVEsTUFBTTtDQUN0Qzs7Ozs7Q0FLQSxJQUFJLE9BQU87RUFDVixPQUFPLEtBQUssUUFBUTtDQUNyQjs7Ozs7OztDQU9BLFlBQVksVUFBVTtFQUNyQixJQUFJLENBQUMsS0FBSyxXQUFXLFNBQVMsUUFBUSxHQUFHO0dBQ3hDLEtBQUssV0FBVyxLQUFLLFFBQVE7R0FDN0IsS0FBSyxlQUFlO0dBQ3BCLEtBQUssZUFBZSxPQUFPO0lBQzFCLE1BQU07SUFDTixVQUFVO0lBQ1Y7R0FDRCxDQUFDO0VBQ0Y7Q0FDRDs7Ozs7O0NBTUEsZUFBZSxVQUFVO0VBQ3hCLEtBQUssYUFBYSxLQUFLLFdBQVcsUUFBUSxNQUFNLE1BQU0sUUFBUTtFQUM5RCxLQUFLLFdBQVc7RUFDaEIsS0FBSyxlQUFlLE9BQU87R0FDMUIsTUFBTTtHQUNOLFVBQVU7R0FDVjtFQUNELENBQUM7Q0FDRjtDQUNBLGlCQUFpQjtFQUNoQixJQUFJLENBQUMsS0FBSyxXQUFXLFFBQVE7R0FDNUIsSUFBSSxLQUFLLE1BQU0sV0FBVyxXQUFXLEtBQUssV0FBVztRQUNoRCxLQUFLLGVBQWUsT0FBTyxJQUFJO0VBQ3JDO0NBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsV0FBVztFQUNWLE9BQU8sS0FBSyxVQUFVLFNBQVMsTUFBTSxLQUFLLE1BQU0sV0FBVyxZQUFZLEtBQUssUUFBUSxLQUFLLE1BQU0sU0FBUyxJQUFJLFFBQVEsUUFBUTtDQUM3SDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQStCQSxNQUFNLFFBQVEsV0FBVztFQUN4QixNQUFNLG1CQUFtQjtHQUN4QixLQUFLLFVBQVUsRUFBRSxNQUFNLFdBQVcsQ0FBQztFQUNwQztFQUNBLE1BQU0sb0JBQW9CO0dBQ3pCLFFBQVEsS0FBSztHQUNiLE1BQU0sS0FBSyxRQUFRO0dBQ25CLGFBQWEsS0FBSyxRQUFRO0VBQzNCO0VBQ0EsTUFBTSxVQUFVLEtBQUssV0FBVyxjQUFjO0dBQzdDLFVBQVU7SUFDVCxJQUFJLENBQUMsS0FBSyxRQUFRLFlBQVksT0FBTyxRQUFRLHVCQUF1QixJQUFJLE1BQU0scUJBQXFCLENBQUM7SUFDcEcsT0FBTyxLQUFLLFFBQVEsV0FBVyxXQUFXLGlCQUFpQjtHQUM1RDtHQUNBLFNBQVMsY0FBYyxVQUFVO0lBQ2hDLEtBQUssVUFBVTtLQUNkLE1BQU07S0FDTjtLQUNBO0lBQ0QsQ0FBQztHQUNGO0dBQ0EsZUFBZTtJQUNkLEtBQUssVUFBVSxFQUFFLE1BQU0sUUFBUSxDQUFDO0dBQ2pDO0dBQ0E7R0FDQSxPQUFPLEtBQUssUUFBUSxTQUFTO0dBQzdCLFlBQVksS0FBSyxRQUFRO0dBQ3pCLGFBQWEsS0FBSyxRQUFRO0dBQzFCLGNBQWMsS0FBSyxlQUFlLE9BQU8sSUFBSTtFQUM5QyxDQUFDO0VBQ0QsTUFBTSxXQUFXLEtBQUssTUFBTSxXQUFXO0VBQ3ZDLE1BQU0sV0FBVyxDQUFDLFFBQVEsU0FBUztFQUNuQyxJQUFJO0dBQ0gsSUFBSSxVQUFVLFdBQVc7UUFDcEI7SUFDSixLQUFLLFVBQVU7S0FDZCxNQUFNO0tBQ047S0FDQTtJQUNELENBQUM7SUFDRCxJQUFJLEtBQUssZUFBZSxPQUFPLFVBQVUsTUFBTSxLQUFLLGVBQWUsT0FBTyxTQUFTLFdBQVcsTUFBTSxpQkFBaUI7SUFDckgsTUFBTSxVQUFVLE1BQU0sS0FBSyxRQUFRLFdBQVcsV0FBVyxpQkFBaUI7SUFDMUUsSUFBSSxZQUFZLEtBQUssTUFBTSxTQUFTLEtBQUssVUFBVTtLQUNsRCxNQUFNO0tBQ047S0FDQTtLQUNBO0lBQ0QsQ0FBQztHQUNGO0dBQ0EsTUFBTSxPQUFPLE1BQU0sUUFBUSxNQUFNO0dBQ2pDLE1BQU0sS0FBSyxlQUFlLE9BQU8sWUFBWSxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7R0FDekcsTUFBTSxLQUFLLFFBQVEsWUFBWSxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsaUJBQWlCO0dBQ3JGLE1BQU0sS0FBSyxlQUFlLE9BQU8sWUFBWSxNQUFNLE1BQU0sS0FBSyxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7R0FDMUgsTUFBTSxLQUFLLFFBQVEsWUFBWSxNQUFNLE1BQU0sV0FBVyxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7R0FDM0YsS0FBSyxVQUFVO0lBQ2QsTUFBTTtJQUNOO0dBQ0QsQ0FBQztHQUNELE9BQU87RUFDUixTQUFTLE9BQU87R0FDZixJQUFJO0lBQ0gsTUFBTSxLQUFLLGVBQWUsT0FBTyxVQUFVLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtHQUN6RyxTQUFTLEdBQUc7SUFDWCxRQUFRLE9BQU8sQ0FBQztHQUNqQjtHQUNBLElBQUk7SUFDSCxNQUFNLEtBQUssUUFBUSxVQUFVLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7R0FDckYsU0FBUyxHQUFHO0lBQ1gsUUFBUSxPQUFPLENBQUM7R0FDakI7R0FDQSxJQUFJO0lBQ0gsTUFBTSxLQUFLLGVBQWUsT0FBTyxZQUFZLEtBQUssR0FBRyxPQUFPLEtBQUssTUFBTSxXQUFXLEtBQUssTUFBTSxTQUFTLE1BQU0saUJBQWlCO0dBQzlILFNBQVMsR0FBRztJQUNYLFFBQVEsT0FBTyxDQUFDO0dBQ2pCO0dBQ0EsSUFBSTtJQUNILE1BQU0sS0FBSyxRQUFRLFlBQVksS0FBSyxHQUFHLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7R0FDL0YsU0FBUyxHQUFHO0lBQ1gsUUFBUSxPQUFPLENBQUM7R0FDakI7R0FDQSxLQUFLLFVBQVU7SUFDZCxNQUFNO0lBQ047R0FDRCxDQUFDO0dBQ0QsTUFBTTtFQUNQLFVBQVU7R0FDVCxJQUFJLEtBQUssYUFBYSxTQUFTLEtBQUssV0FBVyxLQUFLO0dBQ3BELEtBQUssZUFBZSxRQUFRLElBQUk7RUFDakM7Q0FDRDtDQUNBLFVBQVUsUUFBUTtFQUNqQixNQUFNLFdBQVcsVUFBVTtHQUMxQixRQUFRLE9BQU8sTUFBZjtJQUNDLEtBQUssVUFBVSxPQUFPO0tBQ3JCLEdBQUc7S0FDSCxjQUFjLE9BQU87S0FDckIsZUFBZSxPQUFPO0lBQ3ZCO0lBQ0EsS0FBSyxTQUFTLE9BQU87S0FDcEIsR0FBRztLQUNILFVBQVU7SUFDWDtJQUNBLEtBQUssWUFBWSxPQUFPO0tBQ3ZCLEdBQUc7S0FDSCxVQUFVO0lBQ1g7SUFDQSxLQUFLLFdBQVcsT0FBTztLQUN0QixHQUFHO0tBQ0gsU0FBUyxPQUFPO0tBQ2hCLE1BQU0sS0FBSztLQUNYLGNBQWM7S0FDZCxlQUFlO0tBQ2YsT0FBTztLQUNQLFVBQVUsT0FBTztLQUNqQixRQUFRO0tBQ1IsV0FBVyxPQUFPO0tBQ2xCLGFBQWEsS0FBSyxJQUFJO0lBQ3ZCO0lBQ0EsS0FBSyxXQUFXLE9BQU87S0FDdEIsR0FBRztLQUNILE1BQU0sT0FBTztLQUNiLGNBQWM7S0FDZCxlQUFlO0tBQ2YsT0FBTztLQUNQLFFBQVE7S0FDUixVQUFVO0lBQ1g7SUFDQSxLQUFLLFNBQVMsT0FBTztLQUNwQixHQUFHO0tBQ0gsTUFBTSxLQUFLO0tBQ1gsT0FBTyxPQUFPO0tBQ2QsY0FBYyxNQUFNLGVBQWU7S0FDbkMsZUFBZSxPQUFPO0tBQ3RCLFVBQVU7S0FDVixRQUFRO0lBQ1Q7R0FDRDtFQUNEO0VBQ0EsS0FBSyxRQUFRLFFBQVEsS0FBSyxLQUFLO0VBQy9CLGNBQWMsWUFBWTtHQUN6QixLQUFLLFdBQVcsU0FBUyxhQUFhO0lBQ3JDLFNBQVMsaUJBQWlCLE1BQU07R0FDakMsQ0FBQztHQUNELEtBQUssZUFBZSxPQUFPO0lBQzFCLFVBQVU7SUFDVixNQUFNO0lBQ047R0FDRCxDQUFDO0VBQ0YsQ0FBQztDQUNGO0FBQ0Q7Ozs7O0FBS0EsU0FBUyxrQkFBa0I7Q0FDMUIsT0FBTztFQUNOLFNBQVMsS0FBSztFQUNkLE1BQU0sS0FBSztFQUNYLE9BQU87RUFDUCxjQUFjO0VBQ2QsZUFBZTtFQUNmLFVBQVU7RUFDVixRQUFRO0VBQ1IsV0FBVyxLQUFLO0VBQ2hCLGFBQWE7Q0FDZDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7O0FDblNBLElBQUksZ0JBQWdCLGNBQWMsYUFBYTtDQUM5QztDQUNBO0NBQ0E7Q0FDQSxZQUFZLFNBQVMsQ0FBQyxHQUFHO0VBQ3hCLE1BQU07RUFDTixLQUFLLFNBQVM7RUFDZCxLQUFLLDZCQUE2QixJQUFJLElBQUk7RUFDMUMsS0FBSywwQkFBMEIsSUFBSSxJQUFJO0VBQ3ZDLEtBQUssY0FBYztDQUNwQjs7Ozs7Ozs7OztDQVVBLE1BQU0sUUFBUSxTQUFTLE9BQU87RUFDN0IsTUFBTSxXQUFXLElBQUksU0FBUztHQUM3QjtHQUNBLGVBQWU7R0FDZixZQUFZLEVBQUUsS0FBSztHQUNuQixTQUFTLE9BQU8sdUJBQXVCLE9BQU87R0FDOUM7RUFDRCxDQUFDO0VBQ0QsS0FBSyxJQUFJLFFBQVE7RUFDakIsT0FBTztDQUNSOzs7Ozs7Q0FNQSxJQUFJLFVBQVU7RUFDYixLQUFLLFdBQVcsSUFBSSxRQUFRO0VBQzVCLE1BQU0sUUFBUSxTQUFTLFFBQVE7RUFDL0IsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUM5QixNQUFNLGtCQUFrQixLQUFLLFFBQVEsSUFBSSxLQUFLO0dBQzlDLElBQUksaUJBQWlCLGdCQUFnQixLQUFLLFFBQVE7UUFDN0MsS0FBSyxRQUFRLElBQUksT0FBTyxDQUFDLFFBQVEsQ0FBQztFQUN4QztFQUNBLEtBQUssT0FBTztHQUNYLE1BQU07R0FDTjtFQUNELENBQUM7Q0FDRjs7Ozs7O0NBTUEsT0FBTyxVQUFVO0VBQ2hCLElBQUksS0FBSyxXQUFXLE9BQU8sUUFBUSxHQUFHO0dBQ3JDLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDL0IsSUFBSSxPQUFPLFVBQVUsVUFBVTtJQUM5QixNQUFNLGtCQUFrQixLQUFLLFFBQVEsSUFBSSxLQUFLO0lBQzlDLElBQUksaUJBQWlCO0tBQ3BCLElBQUksZ0JBQWdCLFNBQVMsR0FBRztNQUMvQixNQUFNLFFBQVEsZ0JBQWdCLFFBQVEsUUFBUTtNQUM5QyxJQUFJLFVBQVUsSUFBSSxnQkFBZ0IsT0FBTyxPQUFPLENBQUM7S0FDbEQsT0FBTyxJQUFJLGdCQUFnQixPQUFPLFVBQVUsS0FBSyxRQUFRLE9BQU8sS0FBSztJQUN0RTtHQUNEO0VBQ0Q7RUFDQSxLQUFLLE9BQU87R0FDWCxNQUFNO0dBQ047RUFDRCxDQUFDO0NBQ0Y7Ozs7Ozs7O0NBUUEsT0FBTyxVQUFVO0VBQ2hCLE1BQU0sUUFBUSxTQUFTLFFBQVE7RUFDL0IsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUM5QixNQUFNLHVCQUF1QixLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsRUFBRSxNQUFNLE1BQU0sRUFBRSxNQUFNLFdBQVcsU0FBUztHQUM5RixPQUFPLENBQUMsd0JBQXdCLHlCQUF5QjtFQUMxRCxPQUFPLE9BQU87Q0FDZjs7Ozs7Ozs7Q0FRQSxRQUFRLFVBQVU7RUFDakIsTUFBTSxRQUFRLFNBQVMsUUFBUTtFQUMvQixJQUFJLE9BQU8sVUFBVSxVQUFVLFFBQVEsS0FBSyxRQUFRLElBQUksS0FBSyxDQUFDLEVBQUUsTUFBTSxNQUFNLE1BQU0sWUFBWSxFQUFFLE1BQU0sUUFBUSxFQUFBLEVBQUksU0FBUyxLQUFLLFFBQVEsUUFBUTtPQUMzSSxPQUFPLFFBQVEsUUFBUTtDQUM3Qjs7Ozs7Ozs7OztDQVVBLFFBQVE7RUFDUCxjQUFjLFlBQVk7R0FDekIsTUFBTSxZQUFZLEtBQUssT0FBTztHQUM5QixLQUFLLFdBQVcsTUFBTTtHQUN0QixLQUFLLFFBQVEsTUFBTTtHQUNuQixVQUFVLFNBQVMsYUFBYTtJQUMvQixLQUFLLE9BQU87S0FDWCxNQUFNO0tBQ047SUFDRCxDQUFDO0dBQ0YsQ0FBQztFQUNGLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxTQUFTO0VBQ1IsT0FBTyxNQUFNLEtBQUssS0FBSyxVQUFVO0NBQ2xDOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxLQUFLLFNBQVM7RUFDYixNQUFNLG1CQUFtQjtHQUN4QixPQUFPO0dBQ1AsR0FBRztFQUNKO0VBQ0EsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLE1BQU0sYUFBYSxjQUFjLGtCQUFrQixRQUFRLENBQUM7Q0FDbEY7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLFFBQVEsVUFBVSxDQUFDLEdBQUc7RUFDckIsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFFBQVEsYUFBYSxjQUFjLFNBQVMsUUFBUSxDQUFDO0NBQzNFOzs7Ozs7Q0FNQSxPQUFPLE9BQU87RUFDYixjQUFjLFlBQVk7R0FDekIsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUNwQyxTQUFTLEtBQUs7R0FDZixDQUFDO0VBQ0YsQ0FBQztDQUNGOzs7Ozs7Q0FNQSx3QkFBd0I7RUFDdkIsTUFBTSxrQkFBa0IsS0FBSyxPQUFPLENBQUMsQ0FBQyxRQUFRLE1BQU0sRUFBRSxNQUFNLFFBQVE7RUFDcEUsT0FBTyxjQUFjLFlBQVksUUFBUSxJQUFJLGdCQUFnQixLQUFLLGFBQWEsU0FBUyxTQUFTLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUM7Q0FDakg7QUFDRDs7Ozs7O0FBTUEsU0FBUyxTQUFTLFVBQVU7Q0FDM0IsT0FBTyxTQUFTLFFBQVEsT0FBTztBQUNoQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5TUEsSUFBSSxtQkFBbUIsY0FBYyxhQUFhO0NBQ2pEO0NBQ0EsaUJBQWlCLEtBQUs7Q0FDdEI7Q0FDQTtDQUNBLFlBQVksUUFBUSxTQUFTO0VBQzVCLE1BQU07RUFDTixLQUFLLFVBQVU7RUFDZixLQUFLLFdBQVcsT0FBTztFQUN2QixLQUFLLFlBQVk7RUFDakIsS0FBSyxjQUFjO0NBQ3BCOzs7OztDQUtBLGNBQWM7RUFDYixLQUFLLFNBQVMsS0FBSyxPQUFPLEtBQUssSUFBSTtFQUNuQyxLQUFLLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBSTtDQUNsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JBLFdBQVcsU0FBUztFQUNuQixNQUFNLGNBQWMsS0FBSztFQUN6QixLQUFLLFVBQVUsS0FBSyxRQUFRLHVCQUF1QixPQUFPO0VBQzFELElBQUksQ0FBQyxvQkFBb0IsS0FBSyxTQUFTLFdBQVcsR0FBRyxLQUFLLFFBQVEsaUJBQWlCLENBQUMsQ0FBQyxPQUFPO0dBQzNGLE1BQU07R0FDTixVQUFVLEtBQUs7R0FDZixVQUFVO0VBQ1gsQ0FBQztFQUNELElBQUksYUFBYSxlQUFlLEtBQUssUUFBUSxlQUFlLFFBQVEsWUFBWSxXQUFXLE1BQU0sUUFBUSxLQUFLLFFBQVEsV0FBVyxHQUFHLEtBQUssTUFBTTtPQUMxSSxJQUFJLEtBQUssa0JBQWtCLE1BQU0sV0FBVyxXQUFXLEtBQUssaUJBQWlCLFdBQVcsS0FBSyxPQUFPO0NBQzFHO0NBQ0EsY0FBYztFQUNiLElBQUksS0FBSyxVQUFVLFNBQVMsS0FBSyxLQUFLLGtCQUFrQjtHQUN2RCxLQUFLLGlCQUFpQixZQUFZLElBQUk7R0FDdEMsS0FBSyxjQUFjO0VBQ3BCO0NBQ0Q7Q0FDQSxnQkFBZ0I7RUFDZixJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUcsS0FBSyxrQkFBa0IsZUFBZSxJQUFJO0NBQ3JFOzs7Ozs7O0NBT0EsaUJBQWlCLFFBQVE7RUFDeEIsS0FBSyxjQUFjO0VBQ25CLEtBQUssUUFBUSxNQUFNO0NBQ3BCOzs7Ozs7O0NBT0EsbUJBQW1CO0VBQ2xCLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxRQUFRO0VBQ1AsS0FBSyxrQkFBa0IsZUFBZSxJQUFJO0VBQzFDLEtBQUssbUJBQW1CLEtBQUs7RUFDN0IsS0FBSyxjQUFjO0VBQ25CLEtBQUssUUFBUTtDQUNkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQkEsT0FBTyxXQUFXLFNBQVM7RUFDMUIsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxrQkFBa0IsZUFBZSxJQUFJO0VBQzFDLEtBQUssbUJBQW1CLEtBQUssUUFBUSxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sS0FBSyxTQUFTLEtBQUssT0FBTztFQUN4RixLQUFLLGlCQUFpQixZQUFZLElBQUk7RUFDdEMsT0FBTyxLQUFLLGlCQUFpQixRQUFRLFNBQVM7Q0FDL0M7Q0FDQSxnQkFBZ0I7RUFDZixNQUFNLFFBQVEsS0FBSyxrQkFBa0IsU0FBUyxnQkFBZ0I7RUFDOUQsS0FBSyxpQkFBaUI7R0FDckIsR0FBRztHQUNILFdBQVcsTUFBTSxXQUFXO0dBQzVCLFdBQVcsTUFBTSxXQUFXO0dBQzVCLFNBQVMsTUFBTSxXQUFXO0dBQzFCLFFBQVEsTUFBTSxXQUFXO0dBQ3pCLFFBQVEsS0FBSztHQUNiLE9BQU8sS0FBSztFQUNiO0NBQ0Q7Q0FDQSxRQUFRLFFBQVE7RUFDZixjQUFjLFlBQVk7R0FDekIsTUFBTSxnQkFBZ0IsS0FBSztHQUMzQixJQUFJLGlCQUFpQixLQUFLLGFBQWEsR0FBRztJQUN6QyxNQUFNLFlBQVksS0FBSyxlQUFlO0lBQ3RDLE1BQU0saUJBQWlCLEtBQUssZUFBZTtJQUMzQyxNQUFNLFVBQVU7S0FDZixRQUFRLEtBQUs7S0FDYixNQUFNLEtBQUssUUFBUTtLQUNuQixhQUFhLEtBQUssUUFBUTtJQUMzQjtJQUNBLElBQUksUUFBUSxTQUFTLFdBQVc7S0FDL0IsSUFBSTtNQUNILGNBQWMsWUFBWSxPQUFPLE1BQU0sV0FBVyxnQkFBZ0IsT0FBTztLQUMxRSxTQUFTLEdBQUc7TUFDWCxRQUFRLE9BQU8sQ0FBQztLQUNqQjtLQUNBLElBQUk7TUFDSCxjQUFjLFlBQVksT0FBTyxNQUFNLE1BQU0sV0FBVyxnQkFBZ0IsT0FBTztLQUNoRixTQUFTLEdBQUc7TUFDWCxRQUFRLE9BQU8sQ0FBQztLQUNqQjtJQUNELE9BQU8sSUFBSSxRQUFRLFNBQVMsU0FBUztLQUNwQyxJQUFJO01BQ0gsY0FBYyxVQUFVLE9BQU8sT0FBTyxXQUFXLGdCQUFnQixPQUFPO0tBQ3pFLFNBQVMsR0FBRztNQUNYLFFBQVEsT0FBTyxDQUFDO0tBQ2pCO0tBQ0EsSUFBSTtNQUNILGNBQWMsWUFBWSxLQUFLLEdBQUcsT0FBTyxPQUFPLFdBQVcsZ0JBQWdCLE9BQU87S0FDbkYsU0FBUyxHQUFHO01BQ1gsUUFBUSxPQUFPLENBQUM7S0FDakI7SUFDRDtHQUNEO0dBQ0EsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUNwQyxTQUFTLEtBQUssY0FBYztHQUM3QixDQUFDO0VBQ0YsQ0FBQztDQUNGO0FBQ0Q7Ozs7Ozs7OztBQ3ZMQSxTQUFTLFdBQVcsUUFBUSxRQUFRO0NBQ25DLE1BQU0sYUFBYSxJQUFJLElBQUksTUFBTTtDQUNqQyxPQUFPLE9BQU8sUUFBUSxNQUFNLENBQUMsV0FBVyxJQUFJLENBQUMsQ0FBQztBQUMvQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxJQUFJLGtCQUFrQixjQUFjLGFBQWE7Q0FDaEQ7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsbUJBQW1CLENBQUM7Q0FDcEIsWUFBWSxRQUFRLFNBQVMsU0FBUztFQUNyQyxNQUFNO0VBQ04sS0FBSyxVQUFVO0VBQ2YsS0FBSyxXQUFXO0VBQ2hCLEtBQUssV0FBVyxDQUFDO0VBQ2pCLEtBQUssYUFBYSxDQUFDO0VBQ25CLEtBQUssVUFBVSxDQUFDO0VBQ2hCLEtBQUssV0FBVyxPQUFPO0NBQ3hCO0NBQ0EsY0FBYztFQUNiLElBQUksS0FBSyxVQUFVLFNBQVMsR0FBRyxLQUFLLFdBQVcsU0FBUyxhQUFhO0dBQ3BFLFNBQVMsV0FBVyxXQUFXO0lBQzlCLEtBQUssVUFBVSxVQUFVLE1BQU07R0FDaEMsQ0FBQztFQUNGLENBQUM7Q0FDRjtDQUNBLGdCQUFnQjtFQUNmLElBQUksQ0FBQyxLQUFLLFVBQVUsTUFBTSxLQUFLLFFBQVE7Q0FDeEM7Ozs7O0NBS0EsVUFBVTtFQUNULEtBQUssNEJBQTRCLElBQUksSUFBSTtFQUN6QyxLQUFLLFdBQVcsU0FBUyxhQUFhO0dBQ3JDLFNBQVMsUUFBUTtFQUNsQixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkEsV0FBVyxTQUFTLFNBQVM7RUFDNUIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssV0FBVztFQUMyQjtHQUMxQyxNQUFNLGNBQWMsUUFBUSxLQUFLLFVBQVUsS0FBSyxRQUFRLG9CQUFvQixLQUFLLENBQUMsQ0FBQyxTQUFTO0dBQzVGLElBQUksSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLFNBQVMsWUFBWSxRQUFRLFFBQVEsS0FBSyx1RkFBdUY7RUFDM0o7RUFDQSxjQUFjLFlBQVk7R0FDekIsTUFBTSxnQkFBZ0IsS0FBSztHQUMzQixNQUFNLHFCQUFxQixLQUFLLHVCQUF1QixLQUFLLFFBQVE7R0FDcEUsbUJBQW1CLFNBQVMsVUFBVSxNQUFNLFNBQVMsV0FBVyxNQUFNLHFCQUFxQixDQUFDO0dBQzVGLE1BQU0sZUFBZSxtQkFBbUIsS0FBSyxVQUFVLE1BQU0sUUFBUTtHQUNyRSxNQUFNLFlBQVksYUFBYSxLQUFLLGFBQWEsU0FBUyxpQkFBaUIsQ0FBQztHQUM1RSxNQUFNLGtCQUFrQixjQUFjLFdBQVcsYUFBYTtHQUM5RCxNQUFNLGlCQUFpQixhQUFhLE1BQU0sVUFBVSxVQUFVLGFBQWEsY0FBYyxNQUFNO0dBQy9GLE1BQU0sc0JBQXNCLG1CQUFtQjtHQUMvQyxNQUFNLGtCQUFrQixzQkFBc0IsT0FBTyxVQUFVLE1BQU0sUUFBUSxVQUFVO0lBQ3RGLE1BQU0sT0FBTyxLQUFLLFFBQVE7SUFDMUIsT0FBTyxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsUUFBUSxJQUFJO0dBQ2xELENBQUM7R0FDRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsaUJBQWlCO0dBQzlDLElBQUkscUJBQXFCO0lBQ3hCLEtBQUssbUJBQW1CO0lBQ3hCLEtBQUssYUFBYTtHQUNuQjtHQUNBLEtBQUssVUFBVTtHQUNmLElBQUksQ0FBQyxLQUFLLGFBQWEsR0FBRztHQUMxQixJQUFJLHFCQUFxQjtJQUN4QixXQUFXLGVBQWUsWUFBWSxDQUFDLENBQUMsU0FBUyxhQUFhO0tBQzdELFNBQVMsUUFBUTtJQUNsQixDQUFDO0lBQ0QsV0FBVyxjQUFjLGFBQWEsQ0FBQyxDQUFDLFNBQVMsYUFBYTtLQUM3RCxTQUFTLFdBQVcsV0FBVztNQUM5QixLQUFLLFVBQVUsVUFBVSxNQUFNO0tBQ2hDLENBQUM7SUFDRixDQUFDO0dBQ0Y7R0FDQSxLQUFLLFFBQVE7RUFDZCxDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7OztDQVlBLG1CQUFtQjtFQUNsQixPQUFPLEtBQUs7Q0FDYjs7Ozs7O0NBTUEsYUFBYTtFQUNaLE9BQU8sS0FBSyxXQUFXLEtBQUssYUFBYSxTQUFTLGdCQUFnQixDQUFDO0NBQ3BFOzs7Ozs7O0NBT0EsZUFBZTtFQUNkLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7Ozs7Q0FZQSxvQkFBb0IsU0FBUyxTQUFTO0VBQ3JDLE1BQU0sVUFBVSxLQUFLLHVCQUF1QixPQUFPO0VBQ25ELE1BQU0sU0FBUyxRQUFRLEtBQUssVUFBVSxNQUFNLFNBQVMsb0JBQW9CLE1BQU0scUJBQXFCLENBQUM7RUFDckcsTUFBTSxjQUFjLFFBQVEsS0FBSyxVQUFVLE1BQU0sc0JBQXNCLFNBQVM7RUFDaEYsT0FBTztHQUNOO0lBQ0MsTUFBTTtJQUNOLE9BQU8sS0FBSyxlQUFlLEtBQUssUUFBUSxTQUFTLFdBQVc7R0FDN0Q7U0FDTTtJQUNMLE9BQU8sS0FBSyxhQUFhLFFBQVEsT0FBTztHQUN6QztFQUNEO0NBQ0Q7Q0FDQSxhQUFhLFFBQVEsU0FBUztFQUM3QixNQUFNLCtCQUErQixJQUFJLElBQUk7RUFDN0MsT0FBTyxRQUFRLEtBQUssT0FBTyxVQUFVO0dBQ3BDLE1BQU0saUJBQWlCLE9BQU87R0FDOUIsT0FBTyxDQUFDLE1BQU0sc0JBQXNCLHNCQUFzQixNQUFNLFNBQVMsWUFBWSxpQkFBaUIsaUJBQWlCO0lBQ3RILElBQUksQ0FBQyxhQUFhLElBQUksWUFBWSxHQUFHO0tBQ3BDLGFBQWEsSUFBSSxZQUFZO0tBQzdCLFFBQVEsU0FBUyxNQUFNO01BQ3RCLEVBQUUsU0FBUyxVQUFVLFlBQVk7S0FDbEMsQ0FBQztJQUNGO0dBQ0QsQ0FBQyxJQUFJO0VBQ04sQ0FBQztDQUNGO0NBQ0EsZUFBZSxPQUFPLFNBQVMsYUFBYTtFQUMzQyxJQUFJLFNBQVM7R0FDWixNQUFNLGFBQWEsS0FBSztHQUN4QixNQUFNLHFCQUFxQixnQkFBZ0IsS0FBSyxLQUFLLGVBQWUsS0FBSyxNQUFNLFdBQVcsV0FBVyxZQUFZLFVBQVUsWUFBWSxNQUFNLE1BQU0sTUFBTSxTQUFTLFdBQVcsRUFBRTtHQUMvSyxJQUFJLEtBQUssWUFBWSxLQUFLLGVBQWUsc0JBQXNCLFlBQVksS0FBSyxjQUFjO0lBQzdGLEtBQUssZUFBZTtJQUNwQixLQUFLLGNBQWMsS0FBSztJQUN4QixJQUFJLGdCQUFnQixLQUFLLEdBQUcsS0FBSyxtQkFBbUI7SUFDcEQsS0FBSyxrQkFBa0IsaUJBQWlCLEtBQUssaUJBQWlCLFFBQVEsS0FBSyxDQUFDO0dBQzdFO0dBQ0EsT0FBTyxLQUFLO0VBQ2I7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxxQkFBcUI7RUFDcEIsT0FBTyxDQUFDLEtBQUssVUFBVSxXQUFXLEtBQUssV0FBVyxNQUFNLFVBQVUsVUFBVTtHQUMzRSxPQUFPLFNBQVMsUUFBUSxZQUFZLEtBQUssUUFBUSxNQUFNLEVBQUUsU0FBUyxLQUFLO0VBQ3hFLENBQUM7Q0FDRjtDQUNBLHVCQUF1QixTQUFTO0VBQy9CLE1BQU0sbUNBQW1DLElBQUksSUFBSTtFQUNqRCxLQUFLLFdBQVcsU0FBUyxhQUFhO0dBQ3JDLE1BQU0sTUFBTSxTQUFTLFFBQVE7R0FDN0IsSUFBSSxDQUFDLEtBQUs7R0FDVixNQUFNLG9CQUFvQixpQkFBaUIsSUFBSSxHQUFHO0dBQ2xELElBQUksbUJBQW1CLGtCQUFrQixLQUFLLFFBQVE7UUFDakQsaUJBQWlCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQztFQUMxQyxDQUFDO0VBQ0QsTUFBTSxZQUFZLENBQUM7RUFDbkIsUUFBUSxTQUFTLFlBQVk7R0FDNUIsTUFBTSxtQkFBbUIsS0FBSyxRQUFRLG9CQUFvQixPQUFPO0dBQ2pFLE1BQU0sV0FBVyxpQkFBaUIsSUFBSSxpQkFBaUIsU0FBUyxDQUFDLEVBQUUsTUFBTSxLQUFLLElBQUksY0FBYyxLQUFLLFNBQVMsZ0JBQWdCO0dBQzlILFVBQVUsS0FBSztJQUNkLHVCQUF1QjtJQUN2QjtHQUNELENBQUM7RUFDRixDQUFDO0VBQ0QsT0FBTztDQUNSO0NBQ0EsVUFBVSxVQUFVLFFBQVE7RUFDM0IsTUFBTSxRQUFRLEtBQUssV0FBVyxRQUFRLFFBQVE7RUFDOUMsSUFBSSxVQUFVLElBQUk7R0FDakIsS0FBSyxVQUFVLEtBQUssUUFBUSxNQUFNO0dBQ2xDLEtBQUssUUFBUSxTQUFTO0dBQ3RCLEtBQUssUUFBUTtFQUNkO0NBQ0Q7Q0FDQSxVQUFVO0VBQ1QsSUFBSSxLQUFLLGFBQWEsR0FBRztHQUN4QixNQUFNLG9CQUFvQixLQUFLLG1CQUFtQjtHQUNsRCxNQUFNLGlCQUFpQixLQUFLO0dBQzVCLE1BQU0sWUFBWSxvQkFBb0IsaUJBQWlCLEtBQUssZUFBZSxLQUFLLGFBQWEsS0FBSyxTQUFTLEtBQUssZ0JBQWdCLEdBQUcsS0FBSyxVQUFVLE9BQU87R0FDekosSUFBSSxxQkFBcUIsbUJBQW1CLFdBQVcsY0FBYyxZQUFZO0lBQ2hGLEtBQUssVUFBVSxTQUFTLGFBQWE7S0FDcEMsU0FBUyxLQUFLLE9BQU87SUFDdEIsQ0FBQztHQUNGLENBQUM7RUFDRjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1T0EsSUFBSSxhQUFhLGNBQWMsYUFBYTtDQUMzQztDQUNBLFlBQVksU0FBUyxDQUFDLEdBQUc7RUFDeEIsTUFBTTtFQUNOLEtBQUssU0FBUztFQUNkLEtBQUssMkJBQTJCLElBQUksSUFBSTtDQUN6Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCQSxNQUFNLFFBQVEsU0FBUyxPQUFPO0VBQzdCLE1BQU0sV0FBVyxRQUFRO0VBQ3pCLE1BQU0sWUFBWSxRQUFRLGFBQWEsc0JBQXNCLFVBQVUsT0FBTztFQUM5RSxJQUFJLFFBQVEsS0FBSyxJQUFJLFNBQVM7RUFDOUIsSUFBSSxDQUFDLE9BQU87R0FDWCxRQUFRLElBQUksTUFBTTtJQUNqQjtJQUNBO0lBQ0E7SUFDQSxTQUFTLE9BQU8sb0JBQW9CLE9BQU87SUFDM0M7SUFDQSxnQkFBZ0IsT0FBTyxpQkFBaUIsUUFBUTtHQUNqRCxDQUFDO0dBQ0QsS0FBSyxJQUFJLEtBQUs7RUFDZjtFQUNBLE9BQU87Q0FDUjs7Ozs7OztDQU9BLElBQUksT0FBTztFQUNWLElBQUksQ0FBQyxLQUFLLFNBQVMsSUFBSSxNQUFNLFNBQVMsR0FBRztHQUN4QyxLQUFLLFNBQVMsSUFBSSxNQUFNLFdBQVcsS0FBSztHQUN4QyxLQUFLLE9BQU87SUFDWCxNQUFNO0lBQ047R0FDRCxDQUFDO0VBQ0Y7Q0FDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsT0FBTyxPQUFPO0VBQ2IsSUFBSSxLQUFLLFNBQVMsSUFBSSxNQUFNLFNBQVMsTUFBTSxPQUFPO0dBQ2pELE1BQU0sUUFBUTtHQUNkLEtBQUssU0FBUyxPQUFPLE1BQU0sU0FBUztHQUNwQyxLQUFLLE9BQU87SUFDWCxNQUFNO0lBQ047R0FDRCxDQUFDO0VBQ0Y7Q0FDRDs7Ozs7Ozs7OztDQVVBLFFBQVE7RUFDUCxjQUFjLFlBQVk7R0FDekIsS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLFVBQVU7SUFDaEMsS0FBSyxPQUFPLEtBQUs7R0FDbEIsQ0FBQztFQUNGLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxJQUFJLFdBQVc7RUFDZCxPQUFPLEtBQUssU0FBUyxJQUFJLFNBQVM7Q0FDbkM7Ozs7Ozs7Ozs7O0NBV0EsU0FBUztFQUNSLE9BQU8sQ0FBQyxHQUFHLEtBQUssU0FBUyxPQUFPLENBQUM7Q0FDbEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFCQSxLQUFLLFNBQVM7RUFDYixNQUFNLG1CQUFtQjtHQUN4QixPQUFPO0dBQ1AsR0FBRztFQUNKO0VBQ0EsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLE1BQU0sVUFBVSxXQUFXLGtCQUFrQixLQUFLLENBQUM7Q0FDekU7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLFFBQVEsVUFBVSxDQUFDLEdBQUc7RUFDckIsTUFBTSxVQUFVLEtBQUssT0FBTztFQUM1QixPQUFPLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLElBQUksUUFBUSxRQUFRLFVBQVUsV0FBVyxTQUFTLEtBQUssQ0FBQyxJQUFJO0NBQ2xHOzs7Ozs7Q0FNQSxPQUFPLE9BQU87RUFDYixjQUFjLFlBQVk7R0FDekIsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUNwQyxTQUFTLEtBQUs7R0FDZixDQUFDO0VBQ0YsQ0FBQztDQUNGOzs7OztDQUtBLFVBQVU7RUFDVCxjQUFjLFlBQVk7R0FDekIsS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLFVBQVU7SUFDaEMsTUFBTSxRQUFRO0dBQ2YsQ0FBQztFQUNGLENBQUM7Q0FDRjs7Ozs7Q0FLQSxXQUFXO0VBQ1YsY0FBYyxZQUFZO0dBQ3pCLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVO0lBQ2hDLE1BQU0sU0FBUztHQUNoQixDQUFDO0VBQ0YsQ0FBQztDQUNGO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbk5BLElBQUksY0FBYyxNQUFNO0NBQ3ZCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxZQUFZLFNBQVMsQ0FBQyxHQUFHO0VBQ3hCLEtBQUssY0FBYyxPQUFPLGNBQWMsSUFBSSxXQUFXO0VBQ3ZELEtBQUssaUJBQWlCLE9BQU8saUJBQWlCLElBQUksY0FBYztFQUNoRSxLQUFLLGtCQUFrQixPQUFPLGtCQUFrQixDQUFDO0VBQ2pELEtBQUssaUNBQWlDLElBQUksSUFBSTtFQUM5QyxLQUFLLG9DQUFvQyxJQUFJLElBQUk7RUFDakQsS0FBSyxjQUFjO0NBQ3BCOzs7Ozs7O0NBT0EsUUFBUTtFQUNQLEtBQUs7RUFDTCxJQUFJLEtBQUssZ0JBQWdCLEdBQUc7RUFDNUIsS0FBSyxvQkFBb0IsYUFBYSxVQUFVLE9BQU8sWUFBWTtHQUNsRSxJQUFJLFNBQVM7SUFDWixNQUFNLEtBQUssc0JBQXNCO0lBQ2pDLEtBQUssWUFBWSxRQUFRO0dBQzFCO0VBQ0QsQ0FBQztFQUNELEtBQUsscUJBQXFCLGNBQWMsVUFBVSxPQUFPLFdBQVc7R0FDbkUsSUFBSSxRQUFRO0lBQ1gsTUFBTSxLQUFLLHNCQUFzQjtJQUNqQyxLQUFLLFlBQVksU0FBUztHQUMzQjtFQUNELENBQUM7Q0FDRjs7Ozs7O0NBTUEsVUFBVTtFQUNULEtBQUs7RUFDTCxJQUFJLEtBQUssZ0JBQWdCLEdBQUc7RUFDNUIsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyxvQkFBb0IsS0FBSztFQUM5QixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLHFCQUFxQixLQUFLO0NBQ2hDOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxXQUFXLFNBQVM7RUFDbkIsT0FBTyxLQUFLLFlBQVksUUFBUTtHQUMvQixHQUFHO0dBQ0gsYUFBYTtFQUNkLENBQUMsQ0FBQyxDQUFDO0NBQ0o7Ozs7Ozs7Ozs7Ozs7O0NBY0EsV0FBVyxTQUFTO0VBQ25CLE9BQU8sS0FBSyxlQUFlLFFBQVE7R0FDbEMsR0FBRztHQUNILFFBQVE7RUFDVCxDQUFDLENBQUMsQ0FBQztDQUNKOzs7Ozs7Ozs7OztDQVdBLGFBQWEsVUFBVTtFQUN0QixNQUFNLFVBQVUsS0FBSyxvQkFBb0IsRUFBRSxTQUFTLENBQUM7RUFDckQsT0FBTyxLQUFLLFlBQVksSUFBSSxRQUFRLFNBQVMsQ0FBQyxFQUFFLE1BQU07Q0FDdkQ7Ozs7Ozs7Ozs7Q0FVQSxnQkFBZ0IsU0FBUztFQUN4QixNQUFNLG1CQUFtQixLQUFLLG9CQUFvQixPQUFPO0VBQ3pELE1BQU0sUUFBUSxLQUFLLFlBQVksTUFBTSxNQUFNLGdCQUFnQjtFQUMzRCxNQUFNLGFBQWEsTUFBTSxNQUFNO0VBQy9CLElBQUksZUFBZSxLQUFLLEdBQUcsT0FBTyxLQUFLLFdBQVcsT0FBTztFQUN6RCxJQUFJLFFBQVEscUJBQXFCLE1BQU0sY0FBYyxrQkFBa0IsaUJBQWlCLFdBQVcsS0FBSyxDQUFDLEdBQUcsS0FBSyxjQUFjLGdCQUFnQjtFQUMvSSxPQUFPLFFBQVEsUUFBUSxVQUFVO0NBQ2xDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLGVBQWUsU0FBUztFQUN2QixPQUFPLEtBQUssWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxVQUFVLFlBQVk7R0FDckUsT0FBTyxDQUFDLFVBQVUsTUFBTSxJQUFJO0VBQzdCLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F1QkEsYUFBYSxVQUFVLFNBQVMsU0FBUztFQUN4QyxNQUFNLG1CQUFtQixLQUFLLG9CQUFvQixFQUFFLFNBQVMsQ0FBQztFQUM5RCxNQUFNLFdBQVcsS0FBSyxZQUFZLElBQUksaUJBQWlCLFNBQVMsQ0FBQyxFQUFFLE1BQU07RUFDekUsTUFBTSxPQUFPLGlCQUFpQixTQUFTLFFBQVE7RUFDL0MsSUFBSSxTQUFTLEtBQUssR0FBRztFQUNyQixPQUFPLEtBQUssWUFBWSxNQUFNLE1BQU0sZ0JBQWdCLENBQUMsQ0FBQyxRQUFRLE1BQU07R0FDbkUsR0FBRztHQUNILFFBQVE7RUFDVCxDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsZUFBZSxTQUFTLFNBQVMsU0FBUztFQUN6QyxPQUFPLGNBQWMsWUFBWSxLQUFLLFlBQVksUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsZUFBZSxDQUFDLFVBQVUsS0FBSyxhQUFhLFVBQVUsU0FBUyxPQUFPLENBQUMsQ0FBQyxDQUFDO0NBQ3BKOzs7Ozs7Ozs7Ozs7Q0FZQSxjQUFjLFVBQVU7RUFDdkIsTUFBTSxVQUFVLEtBQUssb0JBQW9CLEVBQUUsU0FBUyxDQUFDO0VBQ3JELE9BQU8sS0FBSyxZQUFZLElBQUksUUFBUSxTQUFTLENBQUMsRUFBRTtDQUNqRDs7Ozs7Ozs7Ozs7OztDQWFBLGNBQWMsU0FBUztFQUN0QixNQUFNLGFBQWEsS0FBSztFQUN4QixjQUFjLFlBQVk7R0FDekIsV0FBVyxRQUFRLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUM5QyxXQUFXLE9BQU8sS0FBSztHQUN4QixDQUFDO0VBQ0YsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxhQUFhLFNBQVMsU0FBUztFQUM5QixNQUFNLGFBQWEsS0FBSztFQUN4QixPQUFPLGNBQWMsWUFBWTtHQUNoQyxNQUFNLFVBQVUsV0FBVyxRQUFRLE9BQU87R0FDMUMsTUFBTSxtQkFBbUIsSUFBSSxJQUFJLE9BQU87R0FDeEMsUUFBUSxTQUFTLFVBQVU7SUFDMUIsTUFBTSxNQUFNO0dBQ2IsQ0FBQztHQUNELE9BQU8sS0FBSyxlQUFlO0lBQzFCLE1BQU07SUFDTixZQUFZLFVBQVUsaUJBQWlCLElBQUksS0FBSztHQUNqRCxHQUFHLE9BQU87RUFDWCxDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxjQUFjLFNBQVMsZ0JBQWdCLENBQUMsR0FBRztFQUMxQyxNQUFNLHlCQUF5QjtHQUM5QixRQUFRO0dBQ1IsR0FBRztFQUNKO0VBQ0EsTUFBTSxXQUFXLGNBQWMsWUFBWSxLQUFLLFlBQVksUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLFVBQVUsTUFBTSxPQUFPLHNCQUFzQixDQUFDLENBQUM7RUFDakksT0FBTyxRQUFRLElBQUksUUFBUSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDbkQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsa0JBQWtCLFNBQVMsVUFBVSxDQUFDLEdBQUc7RUFDeEMsT0FBTyxjQUFjLFlBQVk7R0FDaEMsS0FBSyxZQUFZLFFBQVEsT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVO0lBQ3BELE1BQU0sV0FBVztHQUNsQixDQUFDO0dBQ0QsSUFBSSxTQUFTLGdCQUFnQixRQUFRLE9BQU8sUUFBUSxRQUFRO0dBQzVELE9BQU8sS0FBSyxlQUFlO0lBQzFCLEdBQUc7SUFDSCxNQUFNLFNBQVMsZUFBZSxTQUFTLFFBQVE7R0FDaEQsR0FBRyxPQUFPO0VBQ1gsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW9CQSxlQUFlLFNBQVMsVUFBVSxDQUFDLEdBQUc7RUFDckMsTUFBTSxlQUFlO0dBQ3BCLEdBQUc7R0FDSCxlQUFlLFFBQVEsaUJBQWlCO0VBQ3pDO0VBQ0EsTUFBTSxXQUFXLGNBQWMsWUFBWSxLQUFLLFlBQVksUUFBUSxPQUFPLENBQUMsQ0FBQyxRQUFRLFVBQVUsQ0FBQyxNQUFNLFdBQVcsS0FBSyxDQUFDLE1BQU0sU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFVBQVU7R0FDdkosSUFBSSxVQUFVLE1BQU0sTUFBTSxLQUFLLEdBQUcsWUFBWTtHQUM5QyxJQUFJLENBQUMsYUFBYSxjQUFjLFVBQVUsUUFBUSxNQUFNLElBQUk7R0FDNUQsT0FBTyxNQUFNLE1BQU0sZ0JBQWdCLFdBQVcsUUFBUSxRQUFRLElBQUk7RUFDbkUsQ0FBQyxDQUFDO0VBQ0YsT0FBTyxRQUFRLElBQUksUUFBUSxDQUFDLENBQUMsS0FBSyxJQUFJO0NBQ3ZDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW1DQSxNQUFNLE1BQU0sU0FBUztFQUNwQixNQUFNLG1CQUFtQixLQUFLLG9CQUFvQixPQUFPO0VBQ3pELElBQUksaUJBQWlCLFVBQVUsS0FBSyxHQUFHLGlCQUFpQixRQUFRO0VBQ2hFLE1BQU0sUUFBUSxLQUFLLFlBQVksTUFBTSxNQUFNLGdCQUFnQjtFQUMzRCxNQUFNLFlBQVksTUFBTSxjQUFjLGtCQUFrQixpQkFBaUIsV0FBVyxLQUFLLENBQUMsSUFBSSxNQUFNLE1BQU0sTUFBTSxnQkFBZ0IsSUFBSSxNQUFNLE1BQU07RUFDaEosTUFBTSxTQUFTLGlCQUFpQjtFQUNoQyxJQUFJLFFBQVEsT0FBTyxPQUFPLFNBQVM7RUFDbkMsT0FBTztDQUNSOzs7Ozs7Ozs7O0NBVUEsV0FBVyxTQUFTO0VBQ25CLE1BQU0sbUJBQW1CLEtBQUssb0JBQW9CLE9BQU87RUFDekQsSUFBSSxpQkFBaUIsVUFBVSxLQUFLLEdBQUcsaUJBQWlCLFFBQVE7RUFDaEUsTUFBTSxRQUFRLEtBQUssWUFBWSxNQUFNLE1BQU0sZ0JBQWdCO0VBQzNELE9BQU8sTUFBTSxjQUFjLGtCQUFrQixpQkFBaUIsV0FBVyxLQUFLLENBQUMsSUFBSSxNQUFNLE1BQU0sZ0JBQWdCLElBQUksUUFBUSxRQUFRLE1BQU0sTUFBTSxJQUFJO0NBQ3BKOzs7Ozs7Ozs7Q0FTQSxjQUFjLFNBQVM7RUFDdEIsT0FBTyxLQUFLLFdBQVcsT0FBTyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDdEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F5QkEsY0FBYyxTQUFTO0VBQ3RCLFFBQVEsUUFBUTtFQUNoQixPQUFPLEtBQUssTUFBTSxPQUFPO0NBQzFCOzs7Ozs7Ozs7Q0FTQSxtQkFBbUIsU0FBUztFQUMzQixRQUFRLFFBQVE7RUFDaEIsT0FBTyxLQUFLLFdBQVcsT0FBTztDQUMvQjs7Ozs7Ozs7O0NBU0Esc0JBQXNCLFNBQVM7RUFDOUIsT0FBTyxLQUFLLG1CQUFtQixPQUFPLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSTtDQUM5RDs7Ozs7Ozs7OztDQVVBLHdCQUF3QixTQUFTO0VBQ2hDLFFBQVEsUUFBUTtFQUNoQixPQUFPLEtBQUssZ0JBQWdCLE9BQU87Q0FDcEM7Ozs7Ozs7Ozs7Ozs7Q0FhQSx3QkFBd0I7RUFDdkIsSUFBSSxjQUFjLFNBQVMsR0FBRyxPQUFPLEtBQUssZUFBZSxzQkFBc0I7RUFDL0UsT0FBTyxRQUFRLFFBQVE7Q0FDeEI7Ozs7Ozs7Ozs7Ozs7Q0FhQSxnQkFBZ0I7RUFDZixPQUFPLEtBQUs7Q0FDYjs7Ozs7Ozs7Ozs7OztDQWFBLG1CQUFtQjtFQUNsQixPQUFPLEtBQUs7Q0FDYjs7Ozs7Ozs7Ozs7OztDQWFBLG9CQUFvQjtFQUNuQixPQUFPLEtBQUs7Q0FDYjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JBLGtCQUFrQixTQUFTO0VBQzFCLEtBQUssa0JBQWtCO0NBQ3hCOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxpQkFBaUIsVUFBVSxTQUFTO0VBQ25DLEtBQUssZUFBZSxJQUFJLFFBQVEsUUFBUSxHQUFHO0dBQzFDO0dBQ0EsZ0JBQWdCO0VBQ2pCLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7OztDQWFBLGlCQUFpQixVQUFVO0VBQzFCLE1BQU0sV0FBVyxDQUFDLEdBQUcsS0FBSyxlQUFlLE9BQU8sQ0FBQztFQUNqRCxNQUFNLFNBQVMsQ0FBQztFQUNoQixTQUFTLFNBQVMsaUJBQWlCO0dBQ2xDLElBQUksZ0JBQWdCLFVBQVUsYUFBYSxRQUFRLEdBQUcsT0FBTyxPQUFPLFFBQVEsYUFBYSxjQUFjO0VBQ3hHLENBQUM7RUFDRCxPQUFPO0NBQ1I7Ozs7Ozs7Ozs7Ozs7Q0FhQSxvQkFBb0IsYUFBYSxTQUFTO0VBQ3pDLEtBQUssa0JBQWtCLElBQUksUUFBUSxXQUFXLEdBQUc7R0FDaEQ7R0FDQSxnQkFBZ0I7RUFDakIsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7O0NBYUEsb0JBQW9CLGFBQWE7RUFDaEMsTUFBTSxXQUFXLENBQUMsR0FBRyxLQUFLLGtCQUFrQixPQUFPLENBQUM7RUFDcEQsTUFBTSxTQUFTLENBQUM7RUFDaEIsU0FBUyxTQUFTLGlCQUFpQjtHQUNsQyxJQUFJLGdCQUFnQixhQUFhLGFBQWEsV0FBVyxHQUFHLE9BQU8sT0FBTyxRQUFRLGFBQWEsY0FBYztFQUM5RyxDQUFDO0VBQ0QsT0FBTztDQUNSOzs7Ozs7Ozs7O0NBVUEsb0JBQW9CLFNBQVM7RUFDNUIsSUFBSSxRQUFRLFlBQVksT0FBTztFQUMvQixNQUFNLG1CQUFtQjtHQUN4QixHQUFHLEtBQUssZ0JBQWdCO0dBQ3hCLEdBQUcsS0FBSyxpQkFBaUIsUUFBUSxRQUFRO0dBQ3pDLEdBQUc7R0FDSCxZQUFZO0VBQ2I7RUFDQSxJQUFJLENBQUMsaUJBQWlCLFdBQVcsaUJBQWlCLFlBQVksc0JBQXNCLGlCQUFpQixVQUFVLGdCQUFnQjtFQUMvSCxJQUFJLGlCQUFpQix1QkFBdUIsS0FBSyxHQUFHLGlCQUFpQixxQkFBcUIsaUJBQWlCLGdCQUFnQjtFQUMzSCxJQUFJLGlCQUFpQixpQkFBaUIsS0FBSyxHQUFHLGlCQUFpQixlQUFlLENBQUMsQ0FBQyxpQkFBaUI7RUFDakcsSUFBSSxDQUFDLGlCQUFpQixlQUFlLGlCQUFpQixXQUFXLGlCQUFpQixjQUFjO0VBQ2hHLElBQUksaUJBQWlCLFlBQVksV0FBVyxpQkFBaUIsVUFBVTtFQUN2RSxPQUFPO0NBQ1I7Ozs7Ozs7OztDQVNBLHVCQUF1QixTQUFTO0VBQy9CLElBQUksU0FBUyxZQUFZLE9BQU87RUFDaEMsT0FBTztHQUNOLEdBQUcsS0FBSyxnQkFBZ0I7R0FDeEIsR0FBRyxTQUFTLGVBQWUsS0FBSyxvQkFBb0IsUUFBUSxXQUFXO0dBQ3ZFLEdBQUc7R0FDSCxZQUFZO0VBQ2I7Q0FDRDs7Ozs7Ozs7Ozs7Q0FXQSxRQUFRO0VBQ1AsS0FBSyxZQUFZLE1BQU07RUFDdkIsS0FBSyxlQUFlLE1BQU07Q0FDM0I7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNXJCQSxTQUFTLGNBQWMsRUFBRSxVQUFVLGNBQWMsU0FBUyxXQUFXLE9BQU8sVUFBVSxTQUFTLE9BQU8sS0FBSyxHQUFHLGVBQWUsQ0FBQyxLQUFLO0NBQ2xJLE9BQU8sT0FBTyxZQUFZO0VBQ3pCLE1BQU0sUUFBUSxRQUFRLE9BQU8sY0FBYyxDQUFDLENBQUMsS0FBSztHQUNqRCxVQUFVLFFBQVE7R0FDbEIsT0FBTztFQUNSLENBQUM7RUFDRCxNQUFNLFlBQVksQ0FBQyxDQUFDLFNBQVMsTUFBTSxVQUFVO0VBQzdDLElBQUksYUFBYSxnQkFBZ0IsU0FBUyxNQUFNLFNBQVM7R0FDeEQsR0FBRyxNQUFNO0dBQ1QsYUFBYTtFQUNkLENBQUM7RUFDRCxJQUFJLFNBQVM7RUFDYixJQUFJLFlBQVk7RUFDaEIsTUFBTSxTQUFTLE1BQU0sU0FBUyxzQkFBc0I7R0FDbkQsUUFBUSxRQUFRO0dBQ2hCLE1BQU0sUUFBUTtHQUNkLFVBQVUsUUFBUTtHQUNsQixXQUFXLFFBQVE7R0FDbkIsV0FBVyxRQUFRO0VBQ3BCLFNBQVMsUUFBUSxjQUFjLFlBQVksSUFBSSxDQUFDO0VBQ2hELE1BQU0sbUJBQW1CLGFBQWEsZ0JBQWdCO0VBQ3RELFdBQVcsTUFBTSxTQUFTLFFBQVE7R0FDakMsSUFBSSxXQUFXO0dBQ2YsSUFBSSxrQkFBa0IsU0FBUyxRQUFRLFFBQVEsS0FBSztRQUMvQyxRQUFRLE9BQU8sYUFBYSxRQUFRLFdBQVcsU0FBUyxRQUFRLFNBQVMsS0FBSyxJQUFJLGVBQWUsTUFBTSxLQUFLLENBQUM7RUFDbkg7RUFDQSxJQUFJLG9CQUFvQixDQUFDLFdBQVcsUUFBUSxPQUFPLGFBQWEsUUFBUSxVQUFVLE1BQU07RUFDeEYsTUFBTSxPQUFPLFFBQVEsT0FBTyxhQUFhLFFBQVEsUUFBUTtFQUN6RCxPQUFPLFNBQVMsS0FBSyxJQUFJLGVBQWU7Q0FDekM7QUFDRDs7OztBQ2hEQSxJQUFNLGdCQUFnQixPQUFPO0FBQzdCLElBQU0scUJBQXFCLE9BQU87QUFDbEMsSUFBTSxjQUFjLE9BQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzJDM0IsSUFBTSxxQkFBcUIsRUFBRSxVQUFVLFVBQVUsQ0FBQyxHQUFHLE9BQU8sa0JBQWtCO0NBQzdFLE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxhQUFBLGFBQW1CLE9BQU8sT0FBTztDQUN2QyxhQUFNLGdCQUFnQjtFQUNyQixXQUFXLFVBQVU7Q0FDdEIsQ0FBQztDQUNELE1BQU0saUJBQUEsYUFBdUIsY0FBYztFQUMxQyxJQUFJLE9BQU87R0FDVixJQUFJLE9BQU8sVUFBVSxVQUFVO0dBQy9CLE1BQU0sYUFBYSxPQUFPLGNBQWM7R0FDeEMsTUFBTSxVQUFVLE1BQU0sV0FBVyxDQUFDO0dBQ2xDLE1BQU0sYUFBYSxDQUFDO0dBQ3BCLE1BQU0sa0JBQWtCLENBQUM7R0FDekIsS0FBSyxNQUFNLG1CQUFtQixTQUFTO0lBQ3RDLE1BQU0sZ0JBQWdCLFdBQVcsSUFBSSxnQkFBZ0IsU0FBUztJQUM5RCxJQUFJLENBQUMsZUFBZSxXQUFXLEtBQUssZUFBZTtTQUM5QyxJQUFJLGdCQUFnQixNQUFNLGdCQUFnQixjQUFjLE1BQU0saUJBQWlCLGdCQUFnQixXQUFXLGNBQWMsTUFBTSxXQUFXLGFBQWEsY0FBYyxNQUFNLGdCQUFnQixjQUFjLGdCQUFnQixlQUFlLGNBQWMsTUFBTSxlQUFlLGdCQUFnQixLQUFLLGVBQWU7R0FDcFQ7R0FDQSxJQUFJLFdBQVcsU0FBUyxHQUFHLFFBQVEsUUFBUSxFQUFFLFNBQVMsV0FBVyxHQUFHLFdBQVcsT0FBTztHQUN0RixJQUFJLGdCQUFnQixTQUFTLEdBQUcsT0FBTztFQUN4QztDQUNELEdBQUcsQ0FBQyxRQUFRLEtBQUssQ0FBQztDQUNsQixhQUFNLGdCQUFnQjtFQUNyQixJQUFJLGdCQUFnQixRQUFRLFFBQVEsRUFBRSxTQUFTLGVBQWUsR0FBRyxXQUFXLE9BQU87Q0FDcEYsR0FBRyxDQUFDLFFBQVEsY0FBYyxDQUFDO0NBQzNCLE9BQU87QUFDUjs7O0FDdEVBLElBQU0scUJBQUEsYUFBMkIsY0FBYyxLQUFLOzs7Ozs7O0FBT3BELElBQU0sdUJBQUEsYUFBNkIsV0FBVyxrQkFBa0I7Ozs7O0FBS2hFLElBQU0sc0JBQXNCLG1CQUFtQjs7Ozs7Ozs7QUNOL0MsU0FBUyxjQUFjO0NBQ3RCLElBQUksVUFBVTtDQUNkLE9BQU87Ozs7RUFJTixrQkFBa0I7R0FDakIsVUFBVTtFQUNYOzs7O0VBSUEsYUFBYTtHQUNaLFVBQVU7RUFDWDs7Ozs7RUFLQSxlQUFlO0dBQ2QsT0FBTztFQUNSO0NBQ0Q7QUFDRDtBQUNBLElBQU0saUNBQUEsYUFBdUMsY0FBYyxZQUFZLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBNkJ4RSxJQUFNLG1DQUFBLGFBQXlDLFdBQVcsOEJBQThCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0N4RixJQUFNLDJCQUEyQixFQUFFLGVBQWU7Q0FDakQsTUFBTSxDQUFDLFNBQUEsYUFBZSxlQUFlLFlBQVksQ0FBQztDQUNsRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSwrQkFBK0IsVUFBVTtFQUNuRTtFQUNBLFVBQVUsT0FBTyxhQUFhLGFBQWEsU0FBUyxLQUFLLElBQUk7Q0FDOUQsQ0FBQztBQUNGOzs7Ozs7Ozs7OztBQzFGQSxJQUFNLG1DQUFtQyxTQUFTLG9CQUFvQixVQUFVO0NBQy9FLE1BQU0sZUFBZSxPQUFPLE1BQU0sV0FBVyxXQUFXLE9BQU8sUUFBUSxpQkFBaUIsYUFBYSxpQkFBaUIsUUFBUSxjQUFjLENBQUMsTUFBTSxNQUFNLE9BQU8sS0FBSyxDQUFDLElBQUksUUFBUTtDQUNsTCxJQUFJLFFBQVEsWUFBWSxjQUNuQjtNQUFBLENBQUMsbUJBQW1CLFFBQVEsR0FBRyxRQUFRLGVBQWU7Q0FBQTtBQUU1RDs7Ozs7O0FBTUEsSUFBTSw4QkFBOEIsdUJBQXVCO0NBQzFELGFBQU0sZ0JBQWdCO0VBQ3JCLG1CQUFtQixXQUFXO0NBQy9CLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztBQUN4Qjs7Ozs7Ozs7O0FBU0EsSUFBTSxlQUFlLEVBQUUsUUFBUSxvQkFBb0IsY0FBYyxPQUFPLGVBQWU7Q0FDdEYsT0FBTyxPQUFPLFdBQVcsQ0FBQyxtQkFBbUIsUUFBUSxLQUFLLENBQUMsT0FBTyxjQUFjLFVBQVUsWUFBWSxPQUFPLFNBQVMsS0FBSyxLQUFLLGlCQUFpQixjQUFjLENBQUMsT0FBTyxPQUFPLEtBQUssQ0FBQztBQUNyTDs7Ozs7Ozs7OztBQzlCQSxJQUFNLHVCQUF1QixRQUFRLFVBQVUsTUFBTSxNQUFNLFNBQVMsS0FBSzs7Ozs7OztBQU96RSxJQUFNLHdCQUF3QixxQkFBcUI7Q0FDbEQsSUFBSSxpQkFBaUIsVUFBVTtFQUM5QixNQUFNLHVCQUF1QjtFQUM3QixNQUFNLFNBQVMsVUFBVSxVQUFVLFdBQVcsUUFBUSxLQUFLLElBQUksU0FBUyxzQkFBc0Isb0JBQW9CO0VBQ2xILE1BQU0sb0JBQW9CLGlCQUFpQjtFQUMzQyxpQkFBaUIsWUFBWSxPQUFPLHNCQUFzQixjQUFjLEdBQUcsU0FBUyxNQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyxJQUFJLE1BQU0saUJBQWlCO0VBQy9JLElBQUksT0FBTyxpQkFBaUIsV0FBVyxVQUFVLGlCQUFpQixTQUFTLEtBQUssSUFBSSxpQkFBaUIsUUFBUSxvQkFBb0I7Q0FDbEk7QUFDRDs7Ozs7OztBQU9BLElBQU0saUJBQWlCLGtCQUFrQixXQUFXLGtCQUFrQixZQUFZLE9BQU87Ozs7Ozs7OztBQVN6RixJQUFNLG1CQUFtQixrQkFBa0IsVUFBVSx1QkFBdUIsU0FBUyxnQkFBZ0IsZ0JBQWdCLENBQUMsQ0FBQyxZQUFZO0NBQ2xJLG1CQUFtQixXQUFXO0FBQy9CLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2lHRCxTQUFTLFdBQVcsRUFBRSxTQUFTLEdBQUcsV0FBVyxhQUFhO0NBQ3pELE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxjQUFjLGVBQWU7Q0FDbkMsTUFBTSxxQkFBcUIsMkJBQTJCO0NBQ3RELE1BQU0sYUFBYSxRQUFRLGVBQWU7Q0FDMUMsTUFBTSxtQkFBQSxhQUF5QixjQUFjLFFBQVEsS0FBSyxTQUFTO0VBQ2xFLE1BQU0sbUJBQW1CLE9BQU8sb0JBQW9CLElBQUk7RUFDeEQsaUJBQWlCLHFCQUFxQixjQUFjLGdCQUFnQixhQUFhLGVBQWUsS0FBSztFQUNyRyxPQUFPO0NBQ1IsQ0FBQyxHQUFHO0VBQ0g7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsaUJBQWlCLFNBQVMsaUJBQWlCO0VBQzFDLHFCQUFxQixZQUFZO0VBQ2pDLE1BQU0sUUFBUSxPQUFPLGNBQWMsQ0FBQyxDQUFDLElBQUksYUFBYSxTQUFTO0VBQy9ELGdDQUFnQyxjQUFjLG9CQUFvQixLQUFLO0NBQ3hFLENBQUM7Q0FDRCwyQkFBMkIsa0JBQWtCO0NBQzdDLE1BQU0sQ0FBQyxZQUFBLGFBQWtCLGVBQWUsSUFBSSxnQkFBZ0IsUUFBUSxrQkFBa0IsT0FBTyxDQUFDO0NBQzlGLE1BQU0sQ0FBQyxrQkFBa0IsbUJBQW1CLGVBQWUsU0FBUyxvQkFBb0Isa0JBQWtCLFFBQVEsT0FBTztDQUN6SCxNQUFNLGtCQUFrQixDQUFDLGVBQWU7Q0FDeEMsYUFBTSxxQkFBQSxhQUEyQixhQUFhLGtCQUFrQixrQkFBa0IsU0FBUyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsSUFBSSxNQUFNLENBQUMsVUFBVSxlQUFlLENBQUMsU0FBUyxTQUFTLGlCQUFpQixTQUFTLFNBQVMsaUJBQWlCLENBQUM7Q0FDeFAsYUFBTSxnQkFBZ0I7RUFDckIsU0FBUyxXQUFXLGtCQUFrQixPQUFPO0NBQzlDLEdBQUc7RUFDRjtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsTUFBTSxtQkFBbUIsaUJBQWlCLE1BQU0sUUFBUSxVQUFVLGNBQWMsaUJBQWlCLFFBQVEsTUFBTSxDQUFDLElBQUksaUJBQWlCLFNBQVMsUUFBUSxVQUFVO0VBQy9KLE1BQU0sT0FBTyxpQkFBaUI7RUFDOUIsSUFBSSxRQUFRLGNBQWMsTUFBTSxNQUFNLEdBRXJDLE9BQU8sZ0JBQWdCLE1BQU0sSUFESCxjQUFjLFFBQVEsSUFDbkIsR0FBZSxrQkFBa0I7RUFFL0QsT0FBTyxDQUFDO0NBQ1QsQ0FBQyxJQUFJLENBQUM7Q0FDTixJQUFJLGlCQUFpQixTQUFTLEdBQUcsTUFBTSxRQUFRLElBQUksZ0JBQWdCO0NBQ25FLE1BQU0sb0NBQW9DLGlCQUFpQixNQUFNLFFBQVEsVUFBVTtFQUNsRixNQUFNLFFBQVEsaUJBQWlCO0VBQy9CLE9BQU8sU0FBUyxZQUFZO0dBQzNCO0dBQ0E7R0FDQSxjQUFjLE1BQU07R0FDcEIsT0FBTyxPQUFPLGNBQWMsQ0FBQyxDQUFDLElBQUksTUFBTSxTQUFTO0dBQ2pELFVBQVUsTUFBTTtFQUNqQixDQUFDO0NBQ0YsQ0FBQztDQUNELElBQUksbUNBQW1DLE1BQU0sa0NBQWtDO0NBQy9FLE9BQU8sa0JBQWtCLFlBQVksQ0FBQztBQUN2Qzs7Ozs7Ozs7Ozs7Ozs7OztBQ3pLQSxTQUFTLGFBQWEsU0FBUyxVQUFVLGFBQWE7Q0FFcEQsSUFBSSxPQUFPLFlBQVksWUFBWSxNQUFNLFFBQVEsT0FBTyxHQUFHLE1BQU0sSUFBSSxNQUFNLGdTQUFnUztDQUU1VyxNQUFNLGNBQWMsZUFBZTtDQUNuQyxNQUFNLHFCQUFxQiwyQkFBMkI7Q0FDdEQsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLG1CQUFtQixPQUFPLG9CQUFvQixPQUFPO0NBQzNELE1BQU0sUUFBUSxPQUFPLGNBQWMsQ0FBQyxDQUFDLElBQUksaUJBQWlCLFNBQVM7Q0FFbEUsSUFBSSxDQUFDLGlCQUFpQixTQUFTLFFBQVEsTUFBTSxJQUFJLGlCQUFpQixVQUFVLG1QQUFtUDtDQUVoVSxNQUFNLGFBQWEsUUFBUSxlQUFlO0NBQzFDLGlCQUFpQixxQkFBcUIsY0FBYyxnQkFBZ0IsYUFBYSxlQUFlLEtBQUs7Q0FDckcscUJBQXFCLGdCQUFnQjtDQUNyQyxnQ0FBZ0Msa0JBQWtCLG9CQUFvQixLQUFLO0NBQzNFLDJCQUEyQixrQkFBa0I7Q0FDN0MsTUFBTSxDQUFDLFlBQUEsYUFBa0IsZUFBZSxJQUFJLFNBQVMsUUFBUSxnQkFBZ0IsQ0FBQztDQUM5RSxNQUFNLFNBQVMsU0FBUyxvQkFBb0IsZ0JBQWdCO0NBQzVELE1BQU0sa0JBQWtCLENBQUMsZUFBZTtDQUN4QyxhQUFNLHFCQUFBLGFBQTJCLGFBQWEsa0JBQWtCO0VBQy9ELE1BQU0sY0FBYyxrQkFBa0IsU0FBUyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsSUFBSTtFQUNwRyxTQUFTLGFBQWE7RUFDdEIsT0FBTztDQUNSLEdBQUcsQ0FBQyxVQUFVLGVBQWUsQ0FBQyxTQUFTLFNBQVMsaUJBQWlCLFNBQVMsU0FBUyxpQkFBaUIsQ0FBQztDQUNyRyxhQUFNLGdCQUFnQjtFQUNyQixTQUFTLFdBQVcsZ0JBQWdCO0NBQ3JDLEdBQUcsQ0FBQyxrQkFBa0IsUUFBUSxDQUFDO0NBQy9CLElBQUksY0FBYyxrQkFBa0IsTUFBTSxHQUFHLE1BQU0sZ0JBQWdCLGtCQUFrQixVQUFVLGtCQUFrQjtDQUNqSCxJQUFJLFlBQVk7RUFDZjtFQUNBO0VBQ0EsY0FBYyxpQkFBaUI7RUFDL0I7RUFDQSxVQUFVLGlCQUFpQjtDQUM1QixDQUFDLEdBQUcsTUFBTSxPQUFPO0NBQ2pCLE9BQU8sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsWUFBWSxNQUFNLElBQUk7QUFDL0U7OztBQ3ZEQSxTQUFTLFNBQVMsU0FBUyxhQUFhO0NBQ3ZDLE9BQU8sYUFBYSxTQUFTLGVBQWUsV0FBVztBQUN4RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNnRUEsU0FBUyxpQkFBaUIsU0FBUyxhQUFhO0NBRTlDLElBQUksUUFBUSxZQUFZLFdBQVcsUUFBUSxNQUFNLCtDQUErQztDQUVqRyxPQUFPLGFBQWE7RUFDbkIsR0FBRztFQUNILFNBQVM7RUFDVCxVQUFVO0VBQ1YsY0FBYztFQUNkLGlCQUFpQixLQUFLO0NBQ3ZCLEdBQUcsZUFBZSxXQUFXO0FBQzlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNRQSxTQUFTLHlCQUF5QixTQUFTLGFBQWE7Q0FFdEQsSUFBSSxRQUFRLFlBQVksV0FBVyxRQUFRLE1BQU0sdURBQXVEO0NBRXpHLE9BQU8sYUFBYTtFQUNuQixHQUFHO0VBQ0gsU0FBUztFQUNULFVBQVU7RUFDVixjQUFjO0VBQ2QsaUJBQWlCLEtBQUs7Q0FDdkIsR0FBRyx1QkFBdUIsV0FBVztBQUN0Qzs7O0FDL0ZBLFNBQVMsbUJBQW1CLFNBQVMsYUFBYTtDQUNqRCxPQUFPLFdBQVc7RUFDakIsR0FBRztFQUNILFNBQVMsUUFBUSxRQUFRLEtBQUssVUFBVTtHQUV0QyxJQUFJLE1BQU0sWUFBWSxXQUFXLFFBQVEsTUFBTSxpREFBaUQ7R0FFakcsT0FBTztJQUNOLEdBQUc7SUFDSCxVQUFVO0lBQ1YsY0FBYztJQUNkLFNBQVM7SUFDVCxpQkFBaUIsS0FBSztHQUN2QjtFQUNELENBQUM7Q0FDRixHQUFHLFdBQVc7QUFDZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNjQSxTQUFTLGlCQUFpQixTQUFTLGFBQWE7Q0FDL0MsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxJQUFJLENBQUMsT0FBTyxjQUFjLFFBQVEsUUFBUSxHQUFHLE9BQU8sTUFBTSxPQUFPLENBQUMsQ0FBQyxNQUFNLElBQUk7QUFDOUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTUEsU0FBUyx5QkFBeUIsU0FBUyxhQUFhO0NBQ3ZELE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsSUFBSSxDQUFDLE9BQU8sY0FBYyxRQUFRLFFBQVEsR0FBRyxPQUFPLGNBQWMsT0FBTyxDQUFDLENBQUMsTUFBTSxJQUFJO0FBQ3RGOzs7QUM5Q0EsU0FBUyxhQUFhLFNBQVM7Q0FDOUIsT0FBTztBQUNSOzs7QUNGQSxTQUFTLHFCQUFxQixTQUFTO0NBQ3RDLE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbUNBLFNBQVMsY0FBYyxTQUFTLGFBQWE7Q0FDNUMsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLGFBQWEsT0FBTyxjQUFjO0NBQ3hDLE9BQUEsYUFBYSxxQkFBQSxhQUEyQixhQUFhLGtCQUFrQixXQUFXLFVBQVUsY0FBYyxXQUFXLGFBQWEsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLFNBQVMsT0FBTyxXQUFXLE9BQU8sU0FBUyxPQUFPLFdBQVcsT0FBTyxDQUFDO0FBQ3hOOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEJBLFNBQVMsY0FBYyxTQUFTLGFBQWE7Q0FDNUMsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxPQUFPLGlCQUFpQixFQUFFLFNBQVM7RUFDbEMsR0FBRztFQUNILFFBQVE7Q0FDVCxFQUFFLEdBQUcsTUFBTSxDQUFDLENBQUM7QUFDZDs7Ozs7OztBQU9BLFNBQVMsd0JBQXdCO0NBQ2hDLElBQUk7Q0FDSixRQUFRLGVBQWUsWUFBWTtFQUNsQyxJQUFJLFNBQVMsQ0FBQztFQUNkLElBQUk7RUFDSixhQUFhO0dBQ1osTUFBTSxZQUFZLGNBQWMsUUFBUSxRQUFRLE9BQU87R0FDdkQsTUFBTSxhQUFhLFVBQVUsU0FBUyxhQUFhLENBQUMsVUFBVSxTQUFTLEtBQUssQ0FBQztHQUM3RSxJQUFJLENBQUMsWUFBWSxXQUFXLFdBQVcsT0FBTyxVQUFVLFdBQVcsTUFBTSxPQUFPLFVBQVUsQ0FBQyxPQUFPLEdBQUcsT0FBTyxPQUFPLE1BQU0sQ0FBQyxHQUFHO0lBQzVILFNBQVM7SUFDVCxXQUFXLGlCQUFpQixnQkFBZ0IsVUFBVSxLQUFLLGFBQWEsUUFBUSxTQUFTLFFBQVEsT0FBTyxRQUFRLElBQUksU0FBUyxLQUFLLENBQUM7SUFDbkksaUJBQWlCO0dBQ2xCO0dBQ0EsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXNFQSxTQUFTLGlCQUFpQixVQUFVLENBQUMsR0FBRyxhQUFhO0NBQ3BELE1BQU0sZ0JBQWdCLGVBQWUsV0FBVyxDQUFDLENBQUMsaUJBQWlCO0NBQ25FLE1BQU0sQ0FBQyxrQkFBQSxhQUF3QixlQUFlLHNCQUFzQixDQUFDO0NBQ3JFLE1BQU0sY0FBYyxlQUFlLGVBQWUsT0FBTztDQUN6RCxPQUFBLGFBQWEscUJBQUEsYUFBMkIsYUFBYSxrQkFBa0IsY0FBYyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLGFBQWEsV0FBVztBQUNwTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNkNBLFNBQVMsWUFBWSxTQUFTLGFBQWE7Q0FDMUMsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLENBQUMsWUFBQSxhQUFrQixlQUFlLElBQUksaUJBQWlCLFFBQVEsT0FBTyxDQUFDO0NBQzdFLGFBQU0sZ0JBQWdCO0VBQ3JCLFNBQVMsV0FBVyxPQUFPO0NBQzVCLEdBQUcsQ0FBQyxVQUFVLE9BQU8sQ0FBQztDQUN0QixNQUFNLFNBQUEsYUFBZSxxQkFBQSxhQUEyQixhQUFhLGtCQUFrQixTQUFTLFVBQVUsY0FBYyxXQUFXLGFBQWEsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFNBQVMsU0FBUyxpQkFBaUIsU0FBUyxTQUFTLGlCQUFpQixDQUFDO0NBQzdOLE1BQU0sU0FBQSxhQUFlLGFBQWEsR0FBRyxTQUFTO0VBQzdDLFNBQVMsT0FBTyxLQUFLLElBQUksS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDN0MsR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUNiLElBQUksT0FBTyxTQUFTLGlCQUFpQixTQUFTLFFBQVEsY0FBYyxDQUFDLE9BQU8sS0FBSyxDQUFDLEdBQUcsTUFBTSxPQUFPO0NBQ2xHLE9BQU87RUFDTixHQUFHO0VBQ0g7RUFDQSxhQUFhLE9BQU87Q0FDckI7QUFDRDs7O0FDNUxBLFNBQVMsZ0JBQWdCLFNBQVM7Q0FDakMsT0FBTztBQUNSOzs7QUNDQSxTQUFTLGlCQUFpQixTQUFTLGFBQWE7Q0FDL0MsT0FBTyxhQUFhLFNBQVMsdUJBQXVCLFdBQVc7QUFDaEUiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzNiwzNywzOCwzOSw0MCw0MSw0Miw0M119