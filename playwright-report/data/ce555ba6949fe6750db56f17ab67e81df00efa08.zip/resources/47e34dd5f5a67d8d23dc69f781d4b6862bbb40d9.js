"use client";
import { r as __toESM, t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-Bk_YeHJf.js?v=1500aecb";
import { t as require_react } from "/node_modules/.vite/deps/react-Bk9vEtng.js?v=1500aecb";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-XdfVfXhi.js?v=1500aecb";
//#region node_modules/@tanstack/router-core/dist/esm/not-found.js
/**
* Create a not-found error object recognized by TanStack Router.
*
* Throw this from loaders/actions to trigger the nearest `notFoundComponent`.
* Use `routeId` to target a specific route's not-found boundary. If `throw`
* is true, the error is thrown instead of returned.
*
* @param options Optional settings including `routeId`, `headers`, and `throw`.
* @returns A not-found error object that can be thrown or returned.
* @link https://tanstack.com/router/latest/docs/router/framework/react/api/router/notFoundFunction
*/
function notFound(options = {}) {
	options.isNotFound = true;
	if (options.throw) throw options;
	return options;
}
/** Determine if a value is a TanStack Router not-found error. */
function isNotFound(obj) {
	return obj?.isNotFound === true;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/root.js
/** Stable identifier used for the root route in a route tree. */
var rootRouteId = "__root__";
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/redirect.js
/**
* Create a redirect Response understood by TanStack Router.
*
* Use from route `loader`/`beforeLoad` or server functions to trigger a
* navigation. If `throw: true` is set, the redirect is thrown instead of
* returned. External `href` values are classified as full-document
* navigations when the router resolves the redirect.
*
* @param opts Options for the redirect. Common fields:
* - `href`: absolute URL for external redirects.
* - `statusCode`: HTTP status code to use (defaults to 307).
* - `headers`: additional headers to include on the Response.
* - Standard navigation options like `to`, `params`, `search`, `replace`,
*   and `reloadDocument` for internal redirects.
* @returns A Response augmented with router navigation options.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/redirectFunction
*/
function redirect(opts) {
	opts.statusCode = opts.statusCode || opts.code || 307;
	const headers = new Headers(opts.headers);
	if (opts.href && headers.get("Location") === null) headers.set("Location", opts.href);
	const response = new Response(null, {
		status: opts.statusCode,
		headers
	});
	response.options = opts;
	if (opts.throw) throw response;
	return response;
}
/** Check whether a value is a TanStack Router redirect Response. */
function isRedirect(obj) {
	return obj instanceof Response && !!obj.options;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/utils.js
/**
* Return the last element of an array.
* Intended for non-empty arrays used within router internals.
*/
function last(arr) {
	return arr[arr.length - 1];
}
/**
* Apply a value-or-updater to a previous value.
* Accepts either a literal value or a function of the previous value.
*/
function functionalUpdate(updater, previous) {
	if (typeof updater === "function") return updater(previous);
	return updater;
}
var hasOwn = Object.prototype.hasOwnProperty;
function hasKeys(obj) {
	for (const key in obj) if (hasOwn.call(obj, key)) return true;
	return false;
}
var createNull = () => Object.create(null);
var nullReplaceEqualDeep = (prev, next) => replaceEqualDeep(prev, next, true);
function replaceEqualDeep(prev, next, _nullProto, _depth = 0) {
	if (prev === next) return prev;
	if (_depth++ > 500) return next;
	const array = Array.isArray(prev) && Array.isArray(next);
	if (!array && !(isPlainObject(prev) && isPlainObject(next))) return next;
	const prevKeys = Object.keys(prev);
	const previousCount = prevKeys.length;
	const nextKeys = Object.keys(next);
	const length = nextKeys.length;
	if (array ? previousCount !== prev.length || length !== next.length || previousCount && last(prevKeys) !== `${previousCount - 1}` || length && last(nextKeys) !== `${length - 1}` : previousCount !== Object.getOwnPropertyNames(prev).length || length !== Object.getOwnPropertyNames(next).length || Object.getOwnPropertySymbols(next).length) return next;
	let i = 0;
	let child;
	let previous;
	let key;
	if (array) {
		for (; i < length; i++) {
			key = i;
			previous = prev[key];
			child = next[key];
			child = previous === child ? previous : typeof previous === "object" ? replaceEqualDeep(previous, child, _nullProto, _depth) : child;
			if (child !== previous) break;
		}
		if (i === length && previousCount === length) return prev;
	} else {
		let equal = previousCount === length;
		let unchanged = true;
		for (; i < length; i++) {
			key = nextKeys[i];
			previous = prev[key];
			const incoming = next[key];
			child = previous === incoming ? previous : typeof previous === "object" ? replaceEqualDeep(previous, incoming, _nullProto, _depth) : incoming;
			equal &&= child === previous && (prevKeys[i] === key || hasOwn.call(prev, key));
			unchanged &&= Object.is(child, incoming);
			prevKeys[i] = child;
		}
		if (equal) return Object.getOwnPropertySymbols(prev).length ? next : prev;
		if (unchanged) return next;
	}
	const copy = array ? nextKeys.fill(0) : _nullProto ? createNull() : {};
	for (let j = 0; j < length; j++) {
		key = array ? j : nextKeys[j];
		if (array) {
			previous = prev[key];
			if (j > i) {
				child = next[key];
				child = previous === child ? previous : typeof previous === "object" ? replaceEqualDeep(previous, child, _nullProto, _depth) : child;
			}
			copy[key] = j < i ? previous : child;
		} else copy[key] = prevKeys[j];
	}
	return copy;
}
function isPlainObject(o) {
	if (!o || typeof o !== "object") return false;
	return (Object.getPrototypeOf(o)?.constructor ?? Object) === Object;
}
/**
* Perform a deep equality check optimized for router state comparisons.
*
* - `partial`: `b` may omit keys that `a` has (arrays stay length-exact).
* - `explicitUndefined`: keys holding `undefined` take part in the comparison
*   instead of being ignored.
*
* Internal: the flags are positional so hot callers pass no options object.
*/
function deepEqual(a, b, partial, explicitUndefined) {
	if (a === b) return true;
	if (Array.isArray(a) && Array.isArray(b)) {
		if (a.length !== b.length) return false;
		for (let i = 0, l = a.length; i < l; i++) {
			const av = a[i];
			const bv = b[i];
			if (av !== bv && !deepEqual(av, bv, partial, explicitUndefined)) return false;
		}
		return true;
	}
	if (isPlainObject(a) && isPlainObject(b)) {
		if (partial) {
			for (const k in b) if (explicitUndefined || b[k] !== void 0) {
				if (!deepEqual(a[k], b[k], partial, explicitUndefined)) return false;
			}
			return true;
		}
		let aCount = 0;
		if (explicitUndefined) aCount = Object.keys(a).length;
		else for (const k in a) if (a[k] !== void 0) aCount++;
		for (const k in b) if (explicitUndefined || b[k] !== void 0) {
			if (aCount-- === 0 || !deepEqual(a[k], b[k], partial, explicitUndefined)) return false;
		}
		return aCount === 0;
	}
	return false;
}
/**
* Create a promise with exposed resolve/reject and status fields.
* Useful for coordinating async router lifecycle operations.
*/
function createControlledPromise(onResolve) {
	let resolveLoadPromise;
	let rejectLoadPromise;
	const controlledPromise = new Promise((resolve, reject) => {
		resolveLoadPromise = resolve;
		rejectLoadPromise = reject;
	});
	controlledPromise.status = "pending";
	controlledPromise.resolve = (value) => {
		controlledPromise.status = "resolved";
		controlledPromise.value = value;
		resolveLoadPromise(value);
		onResolve?.(value);
	};
	controlledPromise.reject = (e) => {
		controlledPromise.status = "rejected";
		rejectLoadPromise(e);
	};
	return controlledPromise;
}
/**
* Heuristically detect dynamic import "module not found" errors
* across major browsers for lazy route component handling.
*/
function isModuleNotFoundError(error) {
	if (typeof error?.message !== "string") return false;
	return error.message.startsWith("Failed to fetch dynamically imported module") || error.message.startsWith("error loading dynamically imported module") || error.message.startsWith("Importing a module script failed");
}
function findLast(array, predicate) {
	for (let i = array.length - 1; i >= 0; i--) {
		const item = array[i];
		if (predicate(item)) return item;
	}
}
/**
* Re-encode characters that are unsafe in URL paths.
* Includes ASCII control characters (0x00-0x1F, 0x7F) and a subset of the
* WHATWG URL "path percent-encode set" (", <, >, `, {, }).
*
* Space (0x20) is intentionally excluded — decodeURI decodes %20 to space
* and the router stores decoded spaces in location.pathname. The existing
* encodePathLikeUrl already handles re-encoding spaces for outgoing URLs.
*
* These characters are decoded by decodeURI but must remain percent-encoded
* in paths to match how upstream layers (CDNs, edge middleware, browsers)
* interpret the URL, preventing infinite redirect loops and path mismatches.
*/
var PATH_UNSAFE_RE = /[\x00-\x1f\x7f"<>`{}]/g;
function sanitizePathSegment(segment) {
	return segment.replace(PATH_UNSAFE_RE, (ch) => "%" + ch.charCodeAt(0).toString(16).toUpperCase().padStart(2, "0"));
}
function decodeSegment(segment) {
	let decoded;
	try {
		decoded = decodeURI(segment);
	} catch {
		decoded = segment.replaceAll(/%[0-9A-F]{2}/gi, (match) => {
			try {
				return decodeURI(match);
			} catch {
				return match;
			}
		});
	}
	return sanitizePathSegment(decoded);
}
/**
* Default list of URL protocols to allow in links, redirects, and navigation.
* Any absolute URL protocol not in this list is treated as dangerous by default.
*/
var DEFAULT_PROTOCOL_ALLOWLIST = [
	"http:",
	"https:",
	"mailto:",
	"tel:"
];
/**
* Extract the explicit URL scheme, including its colon, using WHATWG
* normalization rules. This does not validate the rest of the URL.
*
* Returning `undefined` means "no explicit scheme", not "safe URL";
* protocol-relative URLs such as "//evil.example" require a separate check.
*/
function getUrlScheme(url) {
	if (url[0] === "/") return;
	if (!url.includes(":")) return;
	return /^[\x00-\x20]*([a-z][a-z\d+.\t\n\r-]*:)/i.exec(url)?.[1]?.replace(/[\t\n\r]/g, "").toLowerCase();
}
var protocolRelativePrefixRegex = /^[\x00-\x20]*[\\/][\t\n\r]*[\\/]/;
/**
* Check if a URL string uses a protocol that is not in the allowlist or is
* protocol-relative (e.g. "//evil.example"), which can navigate to another host.
* Returns true for blocked protocols like javascript:, blob:, and data:, as
* well as slash/backslash variants of protocol-relative URLs.
*
* Scheme parsing normalizes:
* - Mixed case (JavaScript: → javascript:)
* - Whitespace/control characters (java\nscript: → javascript:)
* - Leading whitespace
*
* For relative URLs without a protocol-relative prefix, returns false.
*
* @param url - The URL string to check
* @param allowlist - Set of protocols to allow
* @returns true if the URL uses a protocol that is not allowed or can escape
* the current origin through a protocol-relative URL
*/
function isDangerousProtocol(url, allowlist) {
	if (!url) return false;
	if (protocolRelativePrefixRegex.test(url)) return true;
	const scheme = getUrlScheme(url);
	return scheme ? !allowlist.has(scheme) : false;
}
var HTML_ESCAPE_LOOKUP = {
	"&": "\\u0026",
	">": "\\u003e",
	"<": "\\u003c",
	"\u2028": "\\u2028",
	"\u2029": "\\u2029"
};
var HTML_ESCAPE_REGEX = /[&><\u2028\u2029]/g;
/**
* Escape HTML special characters in a string to prevent XSS attacks
* when embedding strings in script tags during SSR.
*
* This is essential for preventing XSS vulnerabilities when user-controlled
* content is embedded in inline scripts.
*/
function escapeHtml(str) {
	return str.replace(HTML_ESCAPE_REGEX, (match) => HTML_ESCAPE_LOOKUP[match]);
}
function decodePath(path) {
	if (!path) return path;
	let result = path;
	if (/[%\\\x00-\x1f\x7f]/.test(path)) {
		const re = /%25|%5C/gi;
		let cursor = 0;
		let match;
		result = "";
		while (null !== (match = re.exec(path))) {
			result += decodeSegment(path.slice(cursor, match.index)) + match[0];
			cursor = re.lastIndex;
		}
		result += decodeSegment(cursor ? path.slice(cursor) : path);
	}
	return result;
}
/**
* Encodes a path the same way `new URL()` would, but without the overhead of full URL parsing.
*
* This function encodes:
* - Whitespace characters (spaces → %20, tabs → %09, etc.)
* - Non-ASCII/Unicode characters (emojis, accented characters, etc.)
*
* It preserves:
* - Already percent-encoded sequences (won't double-encode %2F, %25, etc.)
* - ASCII special characters valid in URL paths (@, $, &, +, etc.)
* - Forward slashes as path separators
*
* Used to generate proper href values for SSR without constructing URL objects.
*
* @example
* encodePathLikeUrl('/path/file name.pdf') // '/path/file%20name.pdf'
* encodePathLikeUrl('/path/日本語') // '/path/%E6%97%A5%E6%9C%AC%E8%AA%9E'
* encodePathLikeUrl('/path/already%20encoded') // '/path/already%20encoded' (preserved)
*/
function encodePathLikeUrl(path) {
	if (!/[\s\u0080-\uFFFF]/.test(path)) return path;
	return path.replace(/\s|[^\u0000-\u007F]/gu, encodeURIComponent);
}
function arraysEqual(a, b) {
	if (a === b) return true;
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
	return true;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/path.js
/** Join path segments, cleaning duplicate slashes between parts. */
function joinPaths(paths) {
	return cleanPath(paths.filter((val) => {
		return val !== void 0;
	}).join("/"));
}
/** Remove repeated slashes from a path string. */
function cleanPath(path) {
	return path.replace(/\/{2,}/g, "/");
}
/** Trim leading slashes (except preserving root '/'). */
function trimPathLeft(path) {
	return path === "/" ? path : path.replace(/^\/+/, "");
}
/** Trim trailing slashes (except preserving root '/'). */
function trimPathRight(path) {
	const len = path.length;
	return len > 1 && path[len - 1] === "/" ? path.replace(/\/+$/, "") : path;
}
/** Trim both leading and trailing slashes. */
function trimPath(path) {
	return trimPathRight(trimPathLeft(path));
}
/** Remove a trailing slash from value when appropriate for comparisons. */
function removeTrailingSlash(value, basepath) {
	if (value?.endsWith("/") && value !== "/" && value !== `${basepath}/`) return value.slice(0, -1);
	return value;
}
/**
* Resolve a destination path against a base, honoring trailing-slash policy
* and supporting relative segments (`.`/`..`) and absolute `to` values.
*
* Internal: parameters are positional so the router's hot callers pass no
* options object.
*/
function resolvePath(base, to, trailingSlash = "never", cache) {
	if (to.includes("//")) to = cleanPath(to);
	if (to.startsWith("/")) {
		if (to.length === 1 || trailingSlash === "preserve") return to;
		if (trailingSlash === "always") return to.endsWith("/") ? to : `${to}/`;
		return to.endsWith("/") ? to.slice(0, -1) : to;
	}
	const isBase = to === ".";
	let key;
	if (cache) {
		key = isBase ? base : base + "\0" + to;
		const cached = cache.get(key);
		if (cached) return cached;
	}
	let baseSegments;
	if (isBase) baseSegments = base.split("/");
	else {
		if (base.includes("//")) base = cleanPath(base);
		baseSegments = base.split("/");
		while (baseSegments.length > 1 && last(baseSegments) === "") baseSegments.pop();
		const toSegments = to.split("/");
		for (let index = 0, length = toSegments.length; index < length; index++) {
			const value = toSegments[index];
			if (value === "") {
				if (!index) baseSegments = [value];
				else if (index === length - 1) baseSegments.push(value);
			} else if (value === "..") {
				if (baseSegments.length > 1) baseSegments.pop();
				else baseSegments = [""];
			} else if (value === ".") {} else baseSegments.push(value);
		}
	}
	if (baseSegments.length > 1) {
		if (last(baseSegments) === "") {
			if (trailingSlash === "never") baseSegments.pop();
		} else if (trailingSlash === "always") baseSegments.push("");
	}
	const joined = baseSegments.join("/");
	const result = (isBase ? cleanPath(joined) : joined) || "/";
	if (key && cache) cache.set(key, result);
	return result;
}
/**
* Create a pre-compiled decode config from allowed characters.
* Created once for the router's fixed encoding configuration.
*/
function compileDecodeCharMap(pathParamsAllowedCharacters) {
	const charMap = new Map(pathParamsAllowedCharacters.map((char) => [encodeURIComponent(char), char]));
	const regex = new RegExp([...charMap.keys()].join("|").replace(/[.*()]/g, "\\$&"), "g");
	return (encoded) => encoded.replace(regex, (match) => charMap.get(match) ?? match);
}
/** A splat is missing when it has no value; `0` and `false` are stringified like any other param. */
function isMissingSplat(value) {
	return value == null || value === "";
}
function encodeParam(key, value, decoder) {
	if (typeof value !== "string") return "" + (value ?? void 0);
	const splat = key === "_splat";
	if (splat && (!value || /^[a-zA-Z0-9\-._~!/]*$/.test(value))) return value;
	let encoded = encodeURIComponent(value);
	if (splat) encoded = encoded.replaceAll("%2F", "/");
	return decoder ? decoder(encoded) : encoded;
}
/** Substitute current values into parsed segments, optionally collecting raw params. */
function interpolatePath(path, segments, params, decoder, usedParams) {
	const trailingSlash = path.endsWith("/") ? "/" : "";
	let joined = "";
	for (const part of segments) {
		if (typeof part === "string") {
			joined += part;
			continue;
		}
		const [kind, key, prefix, rawSuffix] = part;
		const splat = kind === 2;
		const suffix = splat && rawSuffix !== void 0 ? rawSuffix + trailingSlash : rawSuffix;
		let paramValue = params[key];
		if (kind === 3 && paramValue == null) continue;
		if (usedParams) {
			usedParams[key] = paramValue;
			if (splat) usedParams["*"] = paramValue;
		}
		if (splat && isMissingSplat(paramValue)) {
			if (prefix === "/" && !suffix) continue;
			paramValue = "";
		}
		joined += prefix + encodeParam(key, paramValue, decoder) + (suffix || "");
	}
	return joined + trailingSlash || "/";
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/sieve-cache.js
/**
* A fixed-capacity cache using the SIEVE eviction algorithm
* (https://cachemon.github.io/SIEVE-website/).
*
* Entries live in the Map's FIFO insertion order; a hit only flips a `visited`
* bit instead of relinking the entry, which makes `get` (by far the hottest
* operation here) one `Map.get` plus a boolean store. Eviction sweeps a `hand`
* from the oldest entry towards the newest, clearing `visited` bits until it
* finds an unvisited entry to drop, so entries touched since the last sweep
* survive one more round. This keeps LRU-like hit ratios while being
* scan-resistant.
*/
function createSieveCache(max) {
	const cache = /* @__PURE__ */ new Map();
	let hand;
	let newest;
	return {
		get(key) {
			const entry = cache.get(key);
			if (!entry) return;
			entry.visited = true;
			return entry.value;
		},
		set(key, value) {
			const existing = cache.get(key);
			if (existing) {
				existing.value = value;
				return;
			}
			if (cache.size >= max) {
				let node = hand?.next().value;
				while (!node || node.visited) {
					if (node) node.visited = false;
					else hand = cache.values();
					node = hand.next().value;
				}
				if (node === newest) hand = void 0;
				cache.delete(node.key);
			}
			const entry = {
				key,
				value,
				visited: false
			};
			newest = entry;
			cache.set(key, entry);
		},
		clear() {
			cache.clear();
			hand = void 0;
			newest = void 0;
		}
	};
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/new-process-route-tree.js
var SEGMENT_TYPE_INDEX = 4;
var SEGMENT_TYPE_PATHLESS = 5;
function getParamNames(data) {
	const cached = data.names;
	if (cached) return cached;
	const keys = [];
	for (const segment of data) if (typeof segment !== "string") keys.push(segment[1]);
	return data.names = keys;
}
/** Parse one segment for matching and retain the same record for interpolation. */
function parseSegment(path, start, end) {
	const part = path.slice(start, end);
	if (part.charCodeAt(0) === 36) return part.length === 1 ? [
		2,
		"_splat",
		"",
		void 0
	] : [
		1,
		part.slice(1),
		"",
		""
	];
	const open = part.indexOf("{");
	if (open >= 0) {
		const close = part.indexOf("}", open);
		const optional = part.charCodeAt(open + 1) === 45;
		const nameStart = open + (optional ? 3 : 2);
		if (close >= 0 && part.charCodeAt(nameStart - 1) === 36 && (!optional || nameStart < close)) {
			const key = part.slice(nameStart, close);
			return [
				optional ? 3 : key ? 1 : 2,
				key || "_splat",
				part.slice(0, open),
				path.slice(start + close + 1, key ? end : path.length)
			];
		}
	}
	return part;
}
function parseSegments(defaultCaseSensitive, route, start, node, dynamicListsToSort, parentInterpolation) {
	let cursor = start;
	const path = route.fullPath ?? route.from;
	const options = route.options;
	const length = path.length;
	const literalEnd = path.endsWith("/") ? length - 1 : length;
	const caseSensitive = options?.caseSensitive ?? defaultCaseSensitive;
	const parseParams = options?.params?.parse ?? options?.parseParams;
	let interpolation;
	let literalStart = parentInterpolation ? start - 1 : 0;
	if (!node || path.includes("$")) {
		interpolation = parentInterpolation?.slice() ?? [];
		const tail = last(interpolation);
		if (tail && typeof tail !== "string" && tail[0] === 2) {
			interpolation[interpolation.length - 1] = [
				tail[0],
				tail[1],
				tail[2],
				tail[3] === void 0 ? void 0 : tail[3] + path.substring(start - (path[start - 2] === "/" ? 2 : 1), literalEnd)
			];
			literalStart = length;
		}
	}
	while (cursor < length) {
		const start = cursor;
		const next = path.indexOf("/", start);
		let end = next === -1 ? length : next;
		const segment = parseSegment(path, start, end);
		cursor = end + 1;
		let nextNode;
		if (typeof segment === "string") {
			if (!node) continue;
			let name = segment;
			let staticChildren;
			if (caseSensitive) staticChildren = node.static ??= /* @__PURE__ */ new Map();
			else {
				name = segment.toLowerCase();
				staticChildren = node.staticInsensitive ??= /* @__PURE__ */ new Map();
			}
			const existingNode = staticChildren.get(name);
			if (existingNode) nextNode = existingNode;
			else {
				const next = createSegmentNode(node);
				nextNode = next;
				staticChildren.set(name, next);
			}
		} else {
			const kind = segment[0];
			let prefix = segment[2];
			let suffix = segment[3] ?? "";
			if (kind === 2) {
				end = length;
				cursor = end + 1;
			}
			if (interpolation && literalStart < end) {
				if (literalStart < start - 1) interpolation.push(path.slice(literalStart, start - 1));
				segment[2] = "/" + prefix;
				if (kind === 2 && segment[3] !== void 0 && literalEnd < length) segment[3] = suffix.slice(0, -1);
				interpolation.push(segment);
				literalStart = end;
			}
			if (!node) continue;
			const actuallyCaseSensitive = caseSensitive && !!(prefix || suffix);
			if (!caseSensitive) {
				prefix = prefix.toLowerCase();
				suffix = suffix.toLowerCase();
			}
			const siblings = kind === 1 ? node.dynamic ??= [] : kind === 3 ? node.optional ??= [] : node.wildcard ??= [];
			const existingNode = kind !== 2 && !parseParams && siblings.find((s) => !s.parse && s.caseSensitive === actuallyCaseSensitive && s.prefix === prefix && s.suffix === suffix);
			if (existingNode) nextNode = existingNode;
			else {
				const next = createSegmentNode(node, kind, actuallyCaseSensitive, prefix, suffix);
				nextNode = next;
				siblings.push(next);
				if (siblings.length === 2) dynamicListsToSort?.push(siblings);
			}
		}
		node = nextNode;
	}
	if (interpolation && literalStart < literalEnd) interpolation.push(path.slice(literalStart, literalEnd));
	const segmentData = interpolation?.slice();
	if (!node) return segmentData;
	if (parseParams && route.children && !route.isRoot && route.id && route.id.charCodeAt(route.id.lastIndexOf("/") + 1) === 95) {
		const pathlessNode = createSegmentNode(node, SEGMENT_TYPE_PATHLESS);
		(node.pathless ??= []).push(pathlessNode);
		node = pathlessNode;
	}
	const isLeaf = (route.path || !route.children) && !route.isRoot;
	if (isLeaf && literalEnd < length) {
		const indexNode = createSegmentNode(node, SEGMENT_TYPE_INDEX);
		node.index = indexNode;
		node = indexNode;
	}
	node.parse = parseParams ?? null;
	node.priority = options?.params?.priority ?? 0;
	if (!node.route) {
		node.data = segmentData;
		if (isLeaf) node.route = route;
	}
	return [
		node,
		cursor,
		segmentData
	];
}
function sortDynamic(a, b) {
	if (a.parse && !b.parse) return -1;
	if (!a.parse && b.parse) return 1;
	if (a.parse && b.parse && (a.priority || b.priority)) return b.priority - a.priority;
	if (a.prefix && b.prefix && a.prefix !== b.prefix) {
		if (a.prefix.startsWith(b.prefix)) return -1;
		if (b.prefix.startsWith(a.prefix)) return 1;
	}
	if (a.suffix && b.suffix && a.suffix !== b.suffix) {
		if (a.suffix.endsWith(b.suffix)) return -1;
		if (b.suffix.endsWith(a.suffix)) return 1;
	}
	if (a.prefix && !b.prefix) return -1;
	if (!a.prefix && b.prefix) return 1;
	if (a.suffix && !b.suffix) return -1;
	if (!a.suffix && b.suffix) return 1;
	if (a.caseSensitive && !b.caseSensitive) return -1;
	if (!a.caseSensitive && b.caseSensitive) return 1;
	return 0;
}
function createSegmentNode(parent, kind = 0, caseSensitive, prefix, suffix) {
	return {
		kind,
		depth: parent ? parent.depth + 1 : 0,
		pathless: null,
		index: null,
		static: null,
		staticInsensitive: null,
		dynamic: null,
		optional: null,
		wildcard: null,
		route: null,
		data: void 0,
		parent,
		parse: null,
		priority: 0,
		caseSensitive,
		prefix,
		suffix
	};
}
function processRouteMasks(routeList, processedTree) {
	const segmentTree = createSegmentNode();
	const dynamicListsToSort = [];
	function visit(route, start, parentNode, parentInterpolation) {
		const [node, cursor, segments] = parseSegments(false, route, start, parentNode, dynamicListsToSort, parentInterpolation);
		if (route.children) for (const child of route.children) visit(child, cursor, node, segments);
	}
	for (const route of routeList) visit(route, 1, segmentTree);
	for (const nodes of dynamicListsToSort) nodes.sort(sortDynamic);
	processedTree.masksTree = segmentTree;
	processedTree.flatCache = createSieveCache(1e3);
}
/**
* Take an arbitrary list of routes, create a tree from them (if it hasn't been created already), and match a path against it.
*/
function findFlatMatch(path, processedTree) {
	path ||= "/";
	const cached = processedTree.flatCache.get(path);
	if (cached !== void 0) return cached;
	const result = findMatch(path, processedTree.masksTree);
	processedTree.flatCache.set(path, result);
	return result;
}
/**
* @deprecated keep until v2 so that `router.matchRoute` can keep not caring about the actual route tree
*/
function findSingleMatch(from, caseSensitive, fuzzy, path, processedTree) {
	from ||= "/";
	path ||= "/";
	const key = caseSensitive ? `case\0${from}` : from;
	let tree = processedTree.singleCache.get(key);
	if (!tree) {
		tree = createSegmentNode();
		parseSegments(caseSensitive, { from }, 1, tree);
		processedTree.singleCache.set(key, tree);
	}
	return findMatch(path, tree, fuzzy);
}
function findRouteMatch(path, processedTree, fuzzy = false) {
	const key = fuzzy ? path : `nofuzz\0${path}`;
	const cached = processedTree.matchCache.get(key);
	if (cached !== void 0) return cached;
	path ||= "/";
	let result;
	try {
		result = findMatch(path, processedTree.segmentTree, fuzzy);
	} catch (err) {
		if (err instanceof URIError) result = null;
		else throw err;
	}
	if (result) result.branch = buildRouteBranch(result.route);
	processedTree.matchCache.set(key, result);
	return result;
}
/**
* Processes a route tree into a segment trie for efficient path matching.
* Also builds lookup maps for routes by ID and by trimmed full path.
*/
function processRouteTree(routeTree, caseSensitive = false) {
	const segmentTree = createSegmentNode();
	const dynamicListsToSort = [];
	const routesById = {};
	const routesByPath = {};
	let index = 0;
	function visit(route, start, parentNode, parentInterpolation) {
		route.init(index);
		if (route.id in routesById) throw new Error(`Invariant failed: Duplicate routes found with id: ${String(route.id)}`);
		routesById[route.id] = route;
		if (index !== 0 && route.path) {
			const trimmedFullPath = trimPathRight(route.fullPath);
			if (!routesByPath[trimmedFullPath] || route.fullPath.endsWith("/")) routesByPath[trimmedFullPath] = route;
		}
		index++;
		const [node, cursor, segments] = parseSegments(caseSensitive, route, start, parentNode, dynamicListsToSort, parentInterpolation);
		route._interpolation = segments;
		if (route.children) for (const child of route.children) visit(child, cursor, node, segments);
	}
	visit(routeTree, 1, segmentTree);
	for (const nodes of dynamicListsToSort) nodes.sort(sortDynamic);
	return {
		processedTree: {
			segmentTree,
			singleCache: createSieveCache(1e3),
			matchCache: createSieveCache(1e3),
			flatCache: null,
			masksTree: null
		},
		routesById,
		routesByPath
	};
}
function findMatch(path, segmentTree, fuzzy = false) {
	const parts = path.split("/");
	const leaf = getNodeMatch(path, parts, segmentTree, fuzzy);
	if (!leaf) return null;
	const [rawParams] = extractParams(path, parts, leaf);
	return {
		route: leaf.node.route,
		rawParams
	};
}
/**
* This function is "resumable":
* - the `leaf` input can contain `extract` and `rawParams` properties from a previous `extractParams` call
* - the returned `state` can be passed back as `extract` in a future call to continue extracting params from where we left off
*
* Inputs are *not* mutated.
*/
function extractParams(path, parts, leaf) {
	const list = buildBranch(leaf.node);
	const names = leaf.node.data && getParamNames(leaf.node.data);
	const rawParams = Object.create(null);
	/** which segment of the path we're currently processing */
	let partIndex = leaf.extract?.part ?? 0;
	/** which node of the route tree branch we're currently processing */
	let nodeIndex = leaf.extract?.node ?? 0;
	/** index of the 1st character of the segment we're processing in the path string */
	let pathIndex = leaf.extract?.path ?? 0;
	/** Next original parameter name, independent of pathless/static nodes. */
	let paramIndex = leaf.extract?.param ?? 0;
	for (; nodeIndex < list.length; partIndex++, nodeIndex++, pathIndex++) {
		const node = list[nodeIndex];
		if (node.kind === SEGMENT_TYPE_INDEX) break;
		if (node.kind === SEGMENT_TYPE_PATHLESS) {
			partIndex--;
			pathIndex--;
			continue;
		}
		const part = parts[partIndex];
		const currentPathIndex = pathIndex;
		if (part) pathIndex += part.length;
		if (node.kind === 1 || node.kind === 3) {
			const name = names[paramIndex++];
			if (node.kind === 3 && leaf.skipped & 1 << nodeIndex) {
				partIndex--;
				pathIndex = currentPathIndex - 1;
				continue;
			}
			const value = node.suffix || node.prefix ? part.substring(node.prefix.length, part.length - node.suffix.length) : part;
			if (value || node.kind === 1) rawParams[name] = decodeURIComponent(value);
		} else if (node.kind === 2) {
			const n = node;
			const value = path.substring(currentPathIndex + n.prefix.length, path.length - n.suffix.length);
			const splat = decodeURIComponent(value);
			rawParams["*"] = splat;
			rawParams._splat = splat;
			break;
		}
	}
	if (leaf.rawParams) Object.assign(rawParams, leaf.rawParams);
	return [rawParams, {
		part: partIndex,
		node: nodeIndex,
		path: pathIndex,
		param: paramIndex
	}];
}
function buildRouteBranch(route) {
	const list = [route];
	while (route.parentRoute) {
		route = route.parentRoute;
		list.push(route);
	}
	list.reverse();
	return list;
}
function buildBranch(node) {
	const list = Array(node.depth + 1);
	do {
		list[node.depth] = node;
		node = node.parent;
	} while (node);
	return list;
}
function getNodeMatch(path, parts, segmentTree, fuzzy) {
	if (path === "/" && segmentTree.index) return {
		node: segmentTree.index,
		skipped: 0
	};
	const trailingSlash = !last(parts);
	const pathIsIndex = trailingSlash && path !== "/";
	const partsLength = parts.length - (trailingSlash ? 1 : 0);
	const stack = [{
		node: segmentTree,
		index: 1,
		skipped: 0,
		statics: 0,
		dynamics: 0,
		optionals: 0
	}];
	let bestFuzzy = null;
	let bestMatch = null;
	while (stack.length) {
		const frame = stack.pop();
		const { node, index, skipped, statics, dynamics, optionals } = frame;
		let { extract, rawParams } = frame;
		if (node.kind === 2 && node.route && !isFrameMoreSpecific(bestMatch, frame)) continue;
		if (node.parse) {
			if (!validateParseParams(path, parts, frame)) continue;
			rawParams = frame.rawParams;
			extract = frame.extract;
		}
		if (fuzzy && node.route && node.kind !== SEGMENT_TYPE_INDEX && isFrameMoreSpecific(bestFuzzy, frame)) bestFuzzy = frame;
		const isBeyondPath = index === partsLength;
		if (isBeyondPath) {
			if (node.route && (!pathIsIndex || node.kind === SEGMENT_TYPE_INDEX || node.kind === 2) && isFrameMoreSpecific(bestMatch, frame)) bestMatch = frame;
			if (!node.optional && !node.wildcard && !node.index && !node.pathless) continue;
		}
		const part = isBeyondPath ? void 0 : parts[index];
		let lowerPart;
		if (isBeyondPath && node.index) {
			const indexFrame = {
				node: node.index,
				index,
				skipped,
				statics,
				dynamics,
				optionals,
				extract,
				rawParams
			};
			let indexValid = true;
			if (node.index.parse) {
				if (!validateParseParams(path, parts, indexFrame)) indexValid = false;
			}
			if (indexValid) {
				if (!dynamics && !optionals && !skipped && isPerfectStaticMatch(statics, partsLength)) return indexFrame;
				if (isFrameMoreSpecific(bestMatch, indexFrame)) bestMatch = indexFrame;
			}
		}
		if (node.wildcard) for (let i = node.wildcard.length - 1; i >= 0; i--) {
			const segment = node.wildcard[i];
			const { prefix, suffix } = segment;
			if (prefix) {
				if (isBeyondPath) continue;
				if (!(segment.caseSensitive ? part : lowerPart ??= part.toLowerCase()).startsWith(prefix)) continue;
			}
			if (suffix) {
				if (isBeyondPath) continue;
				const end = parts.slice(index).join("/");
				const suffixPart = end.slice(-suffix.length);
				if ((segment.caseSensitive ? suffixPart : suffixPart.toLowerCase()) !== suffix || end.length - suffix.length < prefix.length) continue;
			}
			stack.push({
				node: segment,
				index: partsLength,
				skipped,
				statics,
				dynamics,
				optionals,
				extract,
				rawParams
			});
		}
		if (node.optional) {
			const nextSkipped = skipped | 1 << node.depth + 1;
			for (let i = node.optional.length - 1; i >= 0; i--) {
				const segment = node.optional[i];
				stack.push({
					node: segment,
					index,
					skipped: nextSkipped,
					statics,
					dynamics,
					optionals,
					extract,
					rawParams
				});
			}
			if (!isBeyondPath) for (let i = node.optional.length - 1; i >= 0; i--) {
				const segment = node.optional[i];
				const { prefix, suffix } = segment;
				if (prefix || suffix) {
					const casePart = segment.caseSensitive ? part : lowerPart ??= part.toLowerCase();
					if (prefix && !casePart.startsWith(prefix)) continue;
					if (suffix && casePart.indexOf(suffix, casePart.length - suffix.length) < prefix.length) continue;
				}
				stack.push({
					node: segment,
					index: index + 1,
					skipped,
					statics,
					dynamics,
					optionals: optionals + segmentScore(partsLength, index),
					extract,
					rawParams
				});
			}
		}
		if (!isBeyondPath && node.dynamic && part) for (let i = node.dynamic.length - 1; i >= 0; i--) {
			const segment = node.dynamic[i];
			const { prefix, suffix } = segment;
			if (prefix || suffix) {
				const casePart = segment.caseSensitive ? part : lowerPart ??= part.toLowerCase();
				if (prefix && !casePart.startsWith(prefix)) continue;
				if (suffix && casePart.indexOf(suffix, casePart.length - suffix.length) < prefix.length) continue;
			}
			stack.push({
				node: segment,
				index: index + 1,
				skipped,
				statics,
				dynamics: dynamics + segmentScore(partsLength, index),
				optionals,
				extract,
				rawParams
			});
		}
		if (!isBeyondPath && node.staticInsensitive) {
			const match = node.staticInsensitive.get(lowerPart ??= part.toLowerCase());
			if (match) stack.push({
				node: match,
				index: index + 1,
				skipped,
				statics: statics + segmentScore(partsLength, index),
				dynamics,
				optionals,
				extract,
				rawParams
			});
		}
		if (!isBeyondPath && node.static) {
			const match = node.static.get(part);
			if (match) stack.push({
				node: match,
				index: index + 1,
				skipped,
				statics: statics + segmentScore(partsLength, index),
				dynamics,
				optionals,
				extract,
				rawParams
			});
		}
		if (node.pathless) for (let i = node.pathless.length - 1; i >= 0; i--) {
			const segment = node.pathless[i];
			stack.push({
				node: segment,
				index,
				skipped,
				statics,
				dynamics,
				optionals,
				extract,
				rawParams
			});
		}
	}
	if (bestMatch) return bestMatch;
	if (fuzzy && bestFuzzy) {
		let sliceIndex = bestFuzzy.index;
		for (let i = 0; i < bestFuzzy.index; i++) sliceIndex += parts[i].length;
		const splat = sliceIndex === path.length ? "/" : path.slice(sliceIndex);
		bestFuzzy.rawParams ??= Object.create(null);
		bestFuzzy.rawParams["**"] = decodeURIComponent(splat);
		return bestFuzzy;
	}
	return null;
}
function segmentScore(partsLength, index) {
	return 2 ** (partsLength - index - 1);
}
function isPerfectStaticMatch(statics, partsLength) {
	return statics === 2 ** (partsLength - 1) - 1;
}
function validateParseParams(path, parts, frame) {
	let rawParams;
	let state;
	try {
		[rawParams, state] = extractParams(path, parts, frame);
	} catch {
		return null;
	}
	frame.rawParams = rawParams;
	frame.extract = state;
	if (!frame.node.parse) return true;
	try {
		if (frame.node.parse(rawParams) === false) return null;
	} catch {}
	return true;
}
function isFrameMoreSpecific(prev, next) {
	if (!prev) return true;
	return next.statics > prev.statics || next.statics === prev.statics && (next.dynamics > prev.dynamics || next.dynamics === prev.dynamics && (next.optionals > prev.optionals || next.optionals === prev.optionals && ((next.node.kind === SEGMENT_TYPE_INDEX) > (prev.node.kind === SEGMENT_TYPE_INDEX) || next.node.kind === SEGMENT_TYPE_INDEX === (prev.node.kind === SEGMENT_TYPE_INDEX) && next.node.depth > prev.node.depth)));
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/scroll-restoration.js
function getSafeSessionStorage() {
	try {
		return sessionStorage;
	} catch {
		return;
	}
}
var storageKey = "tsr-scroll-restoration-v1_3";
var safeSessionStorage = getSafeSessionStorage();
function createScrollRestorationCache() {
	try {
		return JSON.parse(safeSessionStorage?.getItem("tsr-scroll-restoration-v1_3") || "{}");
	} catch {
		return {};
	}
}
var scrollRestorationCache = /* @__PURE__ */ createScrollRestorationCache();
var scrollRestorationIdAttribute = "data-scroll-restoration-id";
/**
* The default `getKey` function for `useScrollRestoration`.
* It returns the `key` from the location state or the `href` of the location.
*
* The `location.href` is used as a fallback to support the use case where the location state is not available like the initial render.
*/
var defaultGetScrollRestorationKey = (location) => {
	return location.state.__TSR_key || location.href;
};
function getScrollRestorationSelector(element) {
	const attrId = element.getAttribute(scrollRestorationIdAttribute);
	if (attrId) return `[${scrollRestorationIdAttribute}="${attrId}"]`;
	let selector = "";
	let el = element;
	let parent;
	while (parent = el.parentNode) {
		let index = 1;
		let sibling = el;
		while (sibling = sibling.previousElementSibling) index++;
		const part = `${el.localName}:nth-child(${index})`;
		selector = selector ? `${part} > ${selector}` : part;
		el = parent;
	}
	return selector;
}
function getElementScrollRestorationEntry(router, options) {
	const entries = scrollRestorationCache[(options.getKey || defaultGetScrollRestorationKey)(router.latestLocation)];
	if (!entries) return;
	if (options.id) return entries[`[${scrollRestorationIdAttribute}="${options.id}"]`];
	const element = options.getElement?.();
	if (!element) return;
	return entries[element === window ? windowScrollTarget : getScrollRestorationSelector(element)];
}
var ignoreScroll = false;
var windowScrollTarget = "window";
function getElement(selector) {
	try {
		return typeof selector === "function" ? selector() : document.querySelector(selector);
	} catch {}
}
function getScrollToTopElements(scrollToTopSelectors) {
	const elements = /* @__PURE__ */ new Set();
	for (const selector of scrollToTopSelectors) {
		if (selector === windowScrollTarget) continue;
		const element = getElement(selector);
		if (element) elements.add(element);
	}
	return elements;
}
function setupScrollRestoration(router, force) {
	const shouldSetupScrollRestoration = force ?? router.options.scrollRestoration;
	const scroll = router._scroll;
	if (shouldSetupScrollRestoration) scroll.e = true;
	if (router.isServer) return;
	const getKey = router.options.getScrollRestorationKey || defaultGetScrollRestorationKey;
	const trackedScrollTargets = /* @__PURE__ */ new Set();
	const snapshotCurrentScrollTargets = (restoreKey) => {
		const keyEntry = scrollRestorationCache[restoreKey] ||= {};
		for (const target of trackedScrollTargets) if (target === document) keyEntry[windowScrollTarget] = {
			scrollX,
			scrollY
		};
		else if (target.isConnected) keyEntry[getScrollRestorationSelector(target)] = {
			scrollX: target.scrollLeft,
			scrollY: target.scrollTop
		};
	};
	if (shouldSetupScrollRestoration && !scroll.s) {
		scroll.s = true;
		ignoreScroll = false;
		history.scrollRestoration = "manual";
		document.addEventListener("scroll", (event) => {
			if (ignoreScroll) return;
			trackedScrollTargets.add(event.target);
		}, true);
		router.subscribe("onBeforeLoad", (event) => {
			if (event.fromLocation) snapshotCurrentScrollTargets(getKey(event.fromLocation));
			trackedScrollTargets.clear();
		});
		addEventListener("pagehide", () => {
			history.scrollRestoration = "auto";
			snapshotCurrentScrollTargets(getKey(router.stores.resolvedLocation.get() ?? router.stores.location.get()));
			try {
				safeSessionStorage?.setItem(storageKey, JSON.stringify(scrollRestorationCache));
			} catch {
				console.warn("[ts-router] Could not persist scroll restoration state to sessionStorage.");
			}
		});
		addEventListener("pageshow", (event) => {
			if (event.persisted) history.scrollRestoration = "manual";
		});
	}
	if (scroll.r) return;
	scroll.r = true;
	router.subscribe("onRendered", (event) => {
		const behavior = router.options.scrollRestorationBehavior;
		const scrollToTopSelectors = router.options.scrollToTopSelectors;
		const shouldResetScroll = scroll.n;
		const hashNavigation = scroll.h;
		let scrollToTopElements;
		trackedScrollTargets.clear();
		scroll.n = true;
		scroll.h = false;
		if (typeof router.options.scrollRestoration === "function" && !router.options.scrollRestoration({ location: router.latestLocation })) return;
		const cacheKey = getKey(event.toLocation);
		const fromCacheKey = event.fromLocation && getKey(event.fromLocation);
		if (scroll.e && fromCacheKey && fromCacheKey !== cacheKey) {
			const fromElementEntries = scrollRestorationCache[fromCacheKey];
			if (fromElementEntries) {
				let toElementEntries = scrollRestorationCache[cacheKey];
				for (const elementSelector in fromElementEntries) {
					if (elementSelector === windowScrollTarget) {
						if (shouldResetScroll) continue;
					} else {
						const element = getElement(elementSelector);
						if (!element) continue;
						if (shouldResetScroll && scrollToTopSelectors) {
							scrollToTopElements ??= getScrollToTopElements(scrollToTopSelectors);
							if (scrollToTopElements.has(element)) continue;
						}
					}
					if (!toElementEntries) toElementEntries = scrollRestorationCache[cacheKey] = {};
					toElementEntries[elementSelector] ??= fromElementEntries[elementSelector];
				}
			}
		}
		ignoreScroll = true;
		try {
			const hash = event.toLocation.hash;
			const hashScrollIntoViewOptions = event.toLocation.state.__hashScrollIntoViewOptions ?? true;
			let windowRestored = false;
			if (shouldResetScroll) {
				if (!hash && scrollToTopSelectors) scrollToTopElements ??= getScrollToTopElements(scrollToTopSelectors);
				const skipWindowRestore = hash && hashScrollIntoViewOptions && hashNavigation;
				const elementEntries = scroll.e ? scrollRestorationCache[cacheKey] : void 0;
				if (elementEntries) for (const elementSelector in elementEntries) {
					const { scrollX, scrollY } = elementEntries[elementSelector];
					if (elementSelector === windowScrollTarget) {
						if (skipWindowRestore) continue;
						scrollTo({
							top: scrollY,
							left: scrollX,
							behavior
						});
						windowRestored = true;
					} else {
						const element = getElement(elementSelector);
						if (element) {
							element.scrollLeft = scrollX;
							element.scrollTop = scrollY;
							scrollToTopElements?.delete(element);
						}
					}
				}
				if (!hash) {
					const scrollOptions = {
						top: 0,
						left: 0,
						behavior
					};
					if (!windowRestored) scrollTo(scrollOptions);
					if (scrollToTopElements) for (const element of scrollToTopElements) element.scrollTo(scrollOptions);
				}
			}
			if (!windowRestored && hash && hashScrollIntoViewOptions) document.getElementById(hash)?.scrollIntoView(hashScrollIntoViewOptions);
		} finally {
			ignoreScroll = false;
		}
	});
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/qss.js
/**
* Program is a reimplementation of the `qss` package:
* Copyright (c) Luke Edwards luke.edwards05@gmail.com, MIT License
* https://github.com/lukeed/qss/blob/master/license.md
*
* This reimplementation uses modern browser APIs
* (namely URLSearchParams) and TypeScript while still
* maintaining the original functionality and interface.
*
* Update: this implementation has also been mangled to
* fit exactly our use-case (single value per key in encoding).
*/
/**
* Encodes an object into a query string.
* @param obj - The object to encode into a query string.
* @param stringify - An optional custom stringify function.
* @returns The encoded query string.
* @example
* ```
* // Example input: encode({ token: 'foo', key: 'value' })
* // Expected output: "token=foo&key=value"
* ```
*/
function encode(obj, stringify = String) {
	let result;
	for (const key in obj) {
		const val = obj[key];
		if (val !== void 0) (result ||= new URLSearchParams()).set(key, stringify(val));
	}
	return result ? result.toString() : "";
}
/**
* Converts a string value to its appropriate type (string, number, boolean).
* @param mix - The string value to convert.
* @returns The converted value.
* @example
* // Example input: toValue("123")
* // Expected output: 123
*/
function toValue(str) {
	if (!str) return "";
	if (str === "false") return false;
	if (str === "true") return true;
	return +str * 0 === 0 && +str + "" === str ? +str : str;
}
/**
* Decodes a query string into an object.
* @param str - The query string to decode.
* @returns The decoded key-value pairs in an object format.
* @example
* // Example input: decode("token=foo&key=value")
* // Expected output: { "token": "foo", "key": "value" }
*/
function decode(str) {
	const searchParams = new URLSearchParams(str);
	const result = Object.create(null);
	for (const [key, value] of searchParams.entries()) {
		const previousValue = result[key];
		if (previousValue == null) result[key] = toValue(value);
		else if (Array.isArray(previousValue)) previousValue.push(toValue(value));
		else result[key] = [previousValue, toValue(value)];
	}
	return result;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/searchParams.js
var jsonStart = /^(?:\s|["[{\d-]|fa|nu|tr)/;
/** Default `parseSearch` that strips leading '?' and JSON-parses values. */
var defaultParseSearch = parseSearchWith(JSON.parse);
/** Default `stringifySearch` using JSON.stringify for complex values. */
var defaultStringifySearch = stringifySearchWith(JSON.stringify, JSON.parse);
/**
* Build a `parseSearch` function using a provided JSON-like parser.
*
* The returned function strips a leading `?`, decodes values, and attempts to
* JSON-parse string values using the given `parser`.
*
* @param parser Function to parse a string value (e.g. `JSON.parse`).
* @returns A `parseSearch` function compatible with `Router` options.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/custom-search-param-serialization
*/
function parseSearchWith(parser) {
	const isJsonParser = parser === JSON.parse;
	return (searchStr) => {
		if (searchStr[0] === "?") searchStr = searchStr.slice(1);
		const query = decode(searchStr);
		for (const key in query) {
			const value = query[key];
			if (typeof value === "string") {
				if (isJsonParser && !jsonStart.test(value)) continue;
				try {
					query[key] = parser(value);
				} catch (_err) {}
			}
		}
		return query;
	};
}
/**
* Build a `stringifySearch` function using a provided serializer.
*
* Non-primitive values are serialized with `stringify`. If a `parser` is
* supplied, string values that are parseable are re-serialized to ensure
* symmetry with `parseSearch`.
*
* @param stringify Function to serialize a value (e.g. `JSON.stringify`).
* @param parser Optional parser to detect parseable strings.
* @returns A `stringifySearch` function compatible with `Router` options.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/custom-search-param-serialization
*/
function stringifySearchWith(stringify, parser) {
	const isJsonParser = parser === JSON.parse;
	function stringifyValue(val) {
		if (val && typeof val === "object") try {
			return stringify(val);
		} catch (_err) {}
		else if (parser && typeof val === "string") {
			if (isJsonParser && !jsonStart.test(val)) return val;
			try {
				parser(val);
				return stringify(val);
			} catch (_err) {}
		}
		return val;
	}
	return (search) => {
		const searchStr = encode(search, stringifyValue);
		return searchStr ? `?${searchStr}` : "";
	};
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/rewrite.js
/** Compose multiple rewrite pairs into a single in/out rewrite. */
function composeRewrites(rewrites) {
	return {
		input: ({ url }) => {
			for (const rewrite of rewrites) url = executeRewriteInput(rewrite, url);
			return url;
		},
		output: ({ url }) => {
			for (let i = rewrites.length - 1; i >= 0; i--) url = executeRewriteOutput(rewrites[i], url);
			return url;
		}
	};
}
/** Create a rewrite pair that strips/adds a basepath on input/output. */
function rewriteBasepath(basepath, caseSensitive, rewrite) {
	const trimmedBasepath = trimPath(basepath);
	const normalizedBasepath = `/${trimmedBasepath}`;
	const checkBasepath = caseSensitive ? normalizedBasepath : normalizedBasepath.toLowerCase();
	const checkBasepathWithSlash = `${checkBasepath}/`;
	const basepathRewrite = {
		input: ({ url }) => {
			const pathname = caseSensitive ? url.pathname : url.pathname.toLowerCase();
			if (pathname === checkBasepath) url.pathname = "/";
			else if (pathname.startsWith(checkBasepathWithSlash)) url.pathname = url.pathname.slice(normalizedBasepath.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = cleanPath(`/${trimmedBasepath}${url.pathname}`);
			return url;
		}
	};
	return rewrite ? {
		input: ({ url }) => executeRewriteInput(rewrite, basepathRewrite.input({ url })),
		output: ({ url }) => basepathRewrite.output({ url: executeRewriteOutput(rewrite, url) })
	} : basepathRewrite;
}
/** Execute a location input rewrite if provided. */
function executeRewriteInput(rewrite, url) {
	const res = rewrite?.input?.({ url });
	if (res) {
		if (typeof res === "string") return new URL(res);
		else if (res instanceof URL) return res;
	}
	return url;
}
/** Execute a location output rewrite if provided. */
function executeRewriteOutput(rewrite, url) {
	const res = rewrite?.output?.({ url });
	if (res) {
		if (typeof res === "string") return new URL(res);
		else if (res instanceof URL) return res;
	}
	return url;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/stores.js
/** SSR non-reactive createMutableStore */
function createNonReactiveMutableStore(initialValue) {
	let value = initialValue;
	return {
		get() {
			return value;
		},
		set(nextOrUpdater) {
			value = functionalUpdate(nextOrUpdater, value);
		}
	};
}
/** SSR non-reactive createReadonlyStore */
function createNonReactiveReadonlyStore(read) {
	return { get() {
		return read();
	} };
}
function createRouterStores(initialLocation, config) {
	const { createMutableStore, createReadonlyStore, batch } = config;
	const byRoute = /* @__PURE__ */ new Map();
	const status = createMutableStore("idle");
	const location = createMutableStore(initialLocation);
	const resolvedLocation = createMutableStore(void 0);
	const ids = createMutableStore([]);
	const matches = createReadonlyStore(() => ids.get().map((id) => byRoute.get(id).get()));
	const __store = createReadonlyStore(() => ({
		status: status.get(),
		isLoading: status.get() === "pending",
		matches: matches.get(),
		location: location.get(),
		resolvedLocation: resolvedLocation.get()
	}));
	function getMatchStore(routeId) {
		let matchStore = byRoute.get(routeId);
		if (!matchStore) {
			matchStore = createMutableStore(void 0);
			byRoute.set(routeId, matchStore);
		}
		return matchStore;
	}
	const store = {
		status,
		location,
		resolvedLocation,
		ids,
		matches,
		byRoute,
		__store,
		getMatchStore,
		setMatches
	};
	function setMatches(nextMatches) {
		const previousIds = ids.get();
		const nextIds = nextMatches.map((match) => match.routeId);
		batch(() => {
			if (!arraysEqual(previousIds, nextIds)) ids.set(nextIds);
			for (const id of previousIds) if (!nextIds.includes(id)) byRoute.get(id).set(() => void 0);
			for (const nextMatch of nextMatches) {
				const matchStore = getMatchStore(nextMatch.routeId);
				if (matchStore.get() !== nextMatch) matchStore.set(nextMatch);
			}
		});
	}
	return store;
}
//#endregion
//#region node_modules/@tanstack/history/dist/esm/index.js
var stateIndexKey = "__TSR_index";
var popStateEvent = "popstate";
var beforeUnloadEvent = "beforeunload";
/**
* Turn protocol-relative inputs such as "//evil.example" into paths
* such as "/evil.example", keeping navigation on the current origin.
*
* For HTTP(S) URLs, WHATWG parsing ignores leading C0 controls and spaces,
* removes tabs/newlines, and treats backslashes as slashes, so inputs like
* "/\evil.example" also need normalization. This only allocates when those
* rules would make the input protocol-relative.
*/
var protocolRelativePrefix = /^[\x00-\x20]*(?:[\\/][\t\n\r]*){2,}/;
function normalizeProtocolRelative(url) {
	const match = protocolRelativePrefix.exec(url);
	return match ? "/" + url.slice(match[0].length) : url;
}
function normalizeHref(href) {
	if (/[\x00-\x1f\x7f]/.test(href)) href = href.replace(/[\x00-\x1f\x7f]/g, (character) => "	\n\r".includes(character) ? "" : encodeURIComponent(character));
	return normalizeProtocolRelative(href);
}
function createHistory(opts) {
	let location = opts.getLocation();
	const subscribers = /* @__PURE__ */ new Set();
	const notify = (action) => {
		location = opts.getLocation();
		subscribers.forEach((subscriber) => subscriber({
			location,
			action
		}));
	};
	const handleIndexChange = (action) => {
		if (opts.notifyOnIndexChange ?? true) notify(action);
		else location = opts.getLocation();
	};
	const tryNavigation = async (args) => {
		const blockers = args.navigateOpts?.ignoreBlocker ? void 0 : opts.getBlockers?.();
		if (typeof document !== "undefined" && blockers?.length && (args.type === "PUSH" || args.type === "REPLACE")) for (const blocker of blockers) {
			const nextLocation = parseHref(args.path, args.state);
			if (await blocker.blockerFn({
				currentLocation: location,
				nextLocation,
				action: args.type
			})) {
				opts.onBlocked?.();
				return;
			}
		}
		args.task();
	};
	return {
		get location() {
			return location;
		},
		get length() {
			return opts.getLength();
		},
		subscribers,
		subscribe: (cb) => {
			subscribers.add(cb);
			return () => {
				subscribers.delete(cb);
			};
		},
		push: (path, state, navigateOpts) => {
			const currentIndex = location.state[stateIndexKey];
			state = assignKeyAndIndex(currentIndex + 1, state);
			tryNavigation({
				task: () => {
					opts.pushState(path, state);
					notify({ type: "PUSH" });
				},
				navigateOpts,
				type: "PUSH",
				path,
				state
			});
		},
		replace: (path, state, navigateOpts) => {
			const currentIndex = location.state[stateIndexKey];
			state = assignKeyAndIndex(currentIndex, state);
			tryNavigation({
				task: () => {
					opts.replaceState(path, state);
					notify({ type: "REPLACE" });
				},
				navigateOpts,
				type: "REPLACE",
				path,
				state
			});
		},
		go: (index, navigateOpts) => {
			tryNavigation({
				task: () => {
					opts.go(index, navigateOpts?.ignoreBlocker ?? false);
					handleIndexChange({
						type: "GO",
						index
					});
				},
				navigateOpts,
				type: "GO"
			});
		},
		back: (navigateOpts) => {
			tryNavigation({
				task: () => {
					opts.back(navigateOpts?.ignoreBlocker ?? false);
					handleIndexChange({ type: "BACK" });
				},
				navigateOpts,
				type: "BACK"
			});
		},
		forward: (navigateOpts) => {
			tryNavigation({
				task: () => {
					opts.forward(navigateOpts?.ignoreBlocker ?? false);
					handleIndexChange({ type: "FORWARD" });
				},
				navigateOpts,
				type: "FORWARD"
			});
		},
		canGoBack: () => location.state[stateIndexKey] !== 0,
		createHref: (str) => opts.createHref(str),
		block: (blocker) => {
			if (!opts.setBlockers) return () => {};
			const blockers = opts.getBlockers?.() ?? [];
			opts.setBlockers([...blockers, blocker]);
			return () => {
				const blockers = opts.getBlockers?.() ?? [];
				opts.setBlockers?.(blockers.filter((b) => b !== blocker));
			};
		},
		flush: () => opts.flush?.(),
		destroy: () => opts.destroy?.(),
		notify,
		_getBlockers: () => opts.getBlockers?.() ?? []
	};
}
function assignKeyAndIndex(index, state) {
	const key = createRandomKey();
	return {
		...state,
		key,
		__TSR_key: key,
		[stateIndexKey]: index
	};
}
/**
* Creates a history object that can be used to interact with the browser's
* navigation. This is a lightweight API wrapping the browser's native methods.
* It is designed to work with TanStack Router, but could be used as a standalone API as well.
* IMPORTANT: This API implements history throttling via a microtask to prevent
* excessive calls to the history API. In some browsers, calling history.pushState or
* history.replaceState in quick succession can cause the browser to ignore subsequent
* calls. This API smooths out those differences and ensures that your application
* state will *eventually* match the browser state. In most cases, this is not a problem,
* but if you need to ensure that the browser state is up to date, you can use the
* `history.flush` method to immediately flush all pending state changes to the browser URL.
* @param opts
* @param opts.getHref A function that returns the current href (path + search + hash)
* @param opts.createHref A function that takes a path and returns a href (path + search + hash)
* @returns A history instance
*/
function createBrowserHistory(opts) {
	const win = opts?.window ?? (typeof document !== "undefined" ? window : void 0);
	const originalPushState = win.history.pushState;
	const originalReplaceState = win.history.replaceState;
	let blockers = [];
	const _getBlockers = () => blockers;
	const _setBlockers = (newBlockers) => blockers = newBlockers;
	const createHref = (path) => normalizeHref(opts?.createHref ? opts.createHref(path) : path);
	const parseLocation = opts?.parseLocation ?? (() => parseHref(`${win.location.pathname}${win.location.search}${win.location.hash}`, win.history.state));
	if (!win.history.state?.__TSR_key && !win.history.state?.key) {
		const addedKey = createRandomKey();
		win.history.replaceState({
			[stateIndexKey]: 0,
			key: addedKey,
			__TSR_key: addedKey
		}, "");
	}
	let currentLocation = parseLocation();
	let rollbackLocation;
	let nextPopIsGo = false;
	let ignoreNextPop = false;
	let skipBlockerNextPop = false;
	let ignoreNextBeforeUnload = false;
	const getLocation = () => currentLocation;
	let next;
	const flush = () => {
		if (!next) return;
		history._ignoreSubscribers = true;
		(next[2] ? win.history.pushState : win.history.replaceState)(next[1], "", next[0]);
		history._ignoreSubscribers = false;
		next = void 0;
		rollbackLocation = void 0;
	};
	const queueHistoryAction = (isPush, destHref, state) => {
		const href = opts?.createHref ? createHref(destHref) : void 0;
		const hasPendingAction = !!next;
		if (!hasPendingAction) rollbackLocation = currentLocation;
		currentLocation = parseHref(destHref, state);
		next = [
			href ?? currentLocation.href,
			state,
			next?.[2] || isPush
		];
		if (!hasPendingAction) queueMicrotask(() => flush());
	};
	const onPushPop = (type) => {
		currentLocation = parseLocation();
		history.notify({ type });
	};
	const onPushPopEvent = async () => {
		ignoreNextBeforeUnload = false;
		if (ignoreNextPop) {
			ignoreNextPop = false;
			return;
		}
		const nextLocation = parseLocation();
		const delta = nextLocation.state[stateIndexKey] - currentLocation.state[stateIndexKey];
		const isForward = delta === 1;
		const isBack = delta === -1;
		const isGo = !isForward && !isBack || nextPopIsGo;
		nextPopIsGo = false;
		const action = isGo ? "GO" : isBack ? "BACK" : "FORWARD";
		const notify = isGo ? {
			type: "GO",
			index: delta
		} : { type: isBack ? "BACK" : "FORWARD" };
		if (skipBlockerNextPop) skipBlockerNextPop = false;
		else {
			const blockers = _getBlockers();
			if (typeof document !== "undefined" && blockers.length) {
				for (const blocker of blockers) if (await blocker.blockerFn({
					currentLocation,
					nextLocation,
					action
				})) {
					ignoreNextPop = true;
					win.history.go(-delta);
					history.notify(notify);
					return;
				}
			}
		}
		currentLocation = parseLocation();
		history.notify(notify);
	};
	const onBeforeUnload = (e) => {
		if (ignoreNextBeforeUnload) {
			ignoreNextBeforeUnload = false;
			return;
		}
		let shouldBlock = false;
		const blockers = _getBlockers();
		if (typeof document !== "undefined" && blockers.length) for (const blocker of blockers) {
			const shouldHaveBeforeUnload = blocker.enableBeforeUnload ?? true;
			if (shouldHaveBeforeUnload === true) {
				shouldBlock = true;
				break;
			}
			if (typeof shouldHaveBeforeUnload === "function" && shouldHaveBeforeUnload() === true) {
				shouldBlock = true;
				break;
			}
		}
		if (shouldBlock) {
			e.preventDefault();
			return e.returnValue = "";
		}
	};
	const history = createHistory({
		getLocation,
		getLength: () => win.history.length,
		pushState: (href, state) => queueHistoryAction(true, href, state),
		replaceState: (href, state) => queueHistoryAction(false, href, state),
		back: (ignoreBlocker) => {
			if (ignoreBlocker) {
				skipBlockerNextPop = true;
				ignoreNextBeforeUnload = true;
			}
			return win.history.back();
		},
		forward: (ignoreBlocker) => {
			if (ignoreBlocker) {
				skipBlockerNextPop = true;
				ignoreNextBeforeUnload = true;
			}
			win.history.forward();
		},
		go: (n, ignoreBlocker) => {
			nextPopIsGo = true;
			if (ignoreBlocker) {
				skipBlockerNextPop = true;
				ignoreNextBeforeUnload = true;
			}
			win.history.go(n);
		},
		createHref,
		flush,
		destroy: () => {
			win.history.pushState = originalPushState;
			win.history.replaceState = originalReplaceState;
			win.removeEventListener(beforeUnloadEvent, onBeforeUnload, { capture: true });
			win.removeEventListener(popStateEvent, onPushPopEvent);
		},
		onBlocked: () => {
			if (rollbackLocation && currentLocation !== rollbackLocation) currentLocation = rollbackLocation;
		},
		getBlockers: _getBlockers,
		setBlockers: _setBlockers,
		notifyOnIndexChange: false
	});
	history._ignoreNextBeforeUnload = (href) => {
		ignoreNextBeforeUnload = false;
		try {
			href = new URL(href, win.document.baseURI).href;
			ignoreNextBeforeUnload = /^https?:/.test(href) && (!href.includes("#") || href.split("#")[0] !== win.location.href.split("#")[0]);
		} catch {}
	};
	win.addEventListener(beforeUnloadEvent, onBeforeUnload, { capture: true });
	win.addEventListener(popStateEvent, onPushPopEvent);
	win.history.pushState = function(...args) {
		const res = originalPushState.apply(win.history, args);
		if (!history._ignoreSubscribers) onPushPop("PUSH");
		return res;
	};
	win.history.replaceState = function(...args) {
		const res = originalReplaceState.apply(win.history, args);
		if (!history._ignoreSubscribers) onPushPop("REPLACE");
		return res;
	};
	return history;
}
/**
* Create a hash-based history implementation.
* Useful for static hosts or environments without server URL rewriting.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/history-types
*/
function createHashHistory(opts) {
	const win = opts?.window ?? (typeof document !== "undefined" ? window : void 0);
	return createBrowserHistory({
		window: win,
		parseLocation: () => {
			const hash = win.location.hash;
			let hashIndex = hash.indexOf("#", 1);
			if (hashIndex < 0) hashIndex = hash.length;
			return parseHref(`${hash ? hash.slice(1, hashIndex) : "/"}${win.location.search}${hash.slice(hashIndex)}`, win.history.state);
		},
		createHref: (href) => `${win.location.pathname}${win.location.search}#${href}`
	});
}
/**
* Create an in-memory history implementation.
* Ideal for server rendering, tests, and non-DOM environments.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/history-types
*/
function createMemoryHistory(opts = { initialEntries: ["/"] }) {
	const entries = opts.initialEntries;
	let index = opts.initialIndex ? Math.min(Math.max(opts.initialIndex, 0), entries.length - 1) : entries.length - 1;
	const states = entries.map((_entry, index) => assignKeyAndIndex(index, void 0));
	const getLocation = () => parseHref(entries[index], states[index]);
	let blockers = [];
	const _getBlockers = () => blockers;
	const _setBlockers = (newBlockers) => blockers = newBlockers;
	return createHistory({
		getLocation,
		getLength: () => entries.length,
		pushState: (path, state) => {
			index = index < entries.length - 1 ? index + 1 : entries.length;
			states[index] = state;
			entries[index] = path;
			if (index < entries.length - 1) {
				entries.length = index + 1;
				states.length = index + 1;
			}
		},
		replaceState: (path, state) => {
			states[index] = state;
			entries[index] = path;
		},
		back: () => {
			index = Math.max(index - 1, 0);
		},
		forward: () => {
			index = Math.min(index + 1, entries.length - 1);
		},
		go: (n) => {
			index = Math.min(Math.max(index + n, 0), entries.length - 1);
		},
		createHref: normalizeHref,
		getBlockers: _getBlockers,
		setBlockers: _setBlockers
	});
}
function parseHref(href, state) {
	const sanitizedHref = normalizeHref(href);
	const hashIndex = sanitizedHref.indexOf("#");
	const searchIndex = sanitizedHref.indexOf("?");
	if (!state) {
		const key = createRandomKey();
		state = {
			[stateIndexKey]: 0,
			key,
			__TSR_key: key
		};
	}
	return {
		href: sanitizedHref,
		pathname: sanitizedHref.slice(0, hashIndex > -1 ? searchIndex > -1 ? Math.min(hashIndex, searchIndex) : hashIndex : searchIndex > -1 ? searchIndex : sanitizedHref.length),
		hash: hashIndex > -1 ? sanitizedHref.slice(hashIndex) : "",
		search: searchIndex > -1 ? sanitizedHref.slice(searchIndex, hashIndex === -1 ? void 0 : hashIndex) : "",
		state
	};
}
function createRandomKey() {
	return (Math.random() + 1).toString(36).slice(7);
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/router.js
function isExternalUrl(url, origin) {
	return url.protocol !== "http:" && url.protocol !== "https:" || url.origin !== origin || !!url.username || !!url.password;
}
function getUrlPath(url) {
	return url.pathname + url.search + url.hash;
}
function routeNeedsLoad(route) {
	return route.options.loader || route.options.beforeLoad || route.lazyFn || route.options.component?.preload || route.options.pendingComponent?.preload;
}
/**
* Convert an unknown error into a minimal, serializable object.
* Includes name and message (and stack in development).
*/
function defaultSerializeError(err) {
	if (err instanceof Error) {
		const obj = {
			name: err.name,
			message: err.message
		};
		obj.stack = err.stack;
		return obj;
	}
	return { data: err };
}
/**
* Compute whether path, href or hash changed between previous and current
* resolved locations.
*/
function getLocationChangeInfo(location, resolvedLocation) {
	return {
		fromLocation: resolvedLocation,
		toLocation: location,
		pathChanged: resolvedLocation?.pathname !== location.pathname,
		hrefChanged: resolvedLocation?.href !== location.href,
		hashChanged: resolvedLocation?.hash !== location.hash
	};
}
/**
* Return only state owned by the application, excluding volatile history
* bookkeeping. Mask payloads (`__tempLocation`/`__tempKey`) are kept: they
* distinguish otherwise-identical locations.
*/
function _getUserHistoryState({ key: _key, __TSR_key: _tsrKey, __TSR_index: _tsrIndex, __hashScrollIntoViewOptions: _hashScroll, ...state }) {
	return state;
}
function lifecycleEnd(matches) {
	return matches.findIndex((match) => match.status === "error" || match.status === "notFound" || match._notFound) + 1;
}
/** Run route lifecycle callbacks in leave/enter/stay phases. */
function runRouteLifecycle(router, previous, matches, previousEnd, nextEnd, owner) {
	if (previousEnd) previous = previous.slice(0, previousEnd);
	if (nextEnd) matches = matches.slice(0, nextEnd);
	for (const match of previous) {
		if (owner && router._tx !== owner) return;
		if (!matches.some((candidate) => candidate.routeId === match.routeId)) router.routesById[match.routeId].options.onLeave?.(match);
	}
	for (const match of matches) {
		if (owner && router._tx !== owner) return;
		router.routesById[match.routeId].options[previous.some((candidate) => candidate.routeId === match.routeId) ? "onStay" : "onEnter"]?.(match);
	}
}
/**
* Core, framework-agnostic router engine that powers TanStack Router.
*
* Provides navigation, matching, loading, preloading, caching and event APIs
* used by framework adapters (React/Solid). Prefer framework helpers like
* `createRouter` in app code.
*
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/RouterType
*/
var RouterCore = class {
	/**
	* @deprecated Use the `createRouter` function instead
	*/
	constructor(options, getStoreConfig) {
		this.tempLocationKey = `${Math.round(Math.random() * 1e7)}`;
		this._scroll = { n: true };
		this.subscribers = /* @__PURE__ */ new Set();
		this._cache = /* @__PURE__ */ new Map();
		this._committed = [];
		this.startTransition = async (fn) => {
			fn();
			return false;
		};
		this.update = (newOptions) => {
			if (newOptions.notFoundRoute) console.warn("The notFoundRoute API is deprecated and will be removed in the next major version. See https://tanstack.com/router/v1/docs/framework/react/guide/not-found-errors#migrating-from-notfoundroute for more info.");
			const prevOptions = this.options;
			this.options = {
				...prevOptions,
				...newOptions
			};
			this.isServer = this.options.isServer ?? void 0 ?? typeof document === "undefined";
			if (!this.isServer) this.staticLocations = /* @__PURE__ */ new WeakMap();
			this.protocolAllowlist = new Set(this.options.protocolAllowlist);
			if (!this.history || this.options.history && this.options.history !== this.history) {
				if (!this.options.history) {
					if (!this.isServer) this.history = createBrowserHistory();
				} else this.history = this.options.history;
			}
			this.origin = this.options.origin;
			if (!this.origin) {
				if (!this.isServer && window?.origin && window.origin !== "null") this.origin = window.origin;
				else this.origin = "http://localhost";
			}
			const nextBasepath = this.options.basepath ?? "/";
			const nextRewriteOption = this.options.rewrite;
			const rewriteChanged = this.basepath !== nextBasepath || prevOptions?.rewrite !== nextRewriteOption || prevOptions?.caseSensitive !== this.options.caseSensitive;
			if (rewriteChanged) {
				this.basepath = nextBasepath;
				this.rewrite = nextBasepath !== "/" && trimPath(nextBasepath) ? rewriteBasepath(nextBasepath, this.options.caseSensitive, nextRewriteOption) : nextRewriteOption;
			}
			if (this.history) this.updateLatestLocation();
			if (this.options.routeTree !== this.routeTree || this.isServer && prevOptions?.caseSensitive !== this.options.caseSensitive) {
				this.routeTree = this.options.routeTree;
				let processRouteTreeResult;
				processRouteTreeResult = this.buildRouteTree();
				this.setRoutes(processRouteTreeResult);
			}
			if (!this.stores) {
				if (this.latestLocation) {
					const config = this.getStoreConfig(this);
					this.batch = config.batch;
					this.stores = createRouterStores(this.latestLocation, config);
					if (!this.isServer) setupScrollRestoration(this);
				}
			} else if (rewriteChanged) this.stores.location.set(this.latestLocation);
		};
		this.updateLatestLocation = () => {
			this.latestLocation = this.parseLocation(this.history.location, this.latestLocation);
		};
		this.buildRouteTree = () => {
			const result = processRouteTree(this.routeTree, this.options.caseSensitive);
			if (this.options.routeMasks) processRouteMasks(this.options.routeMasks, result.processedTree);
			return {
				...result,
				resolvePathCache: createSieveCache(1e3)
			};
		};
		this.subscribe = (eventType, fn) => {
			const listener = {
				eventType,
				fn
			};
			this.subscribers.add(listener);
			return () => {
				this.subscribers.delete(listener);
			};
		};
		this.emit = (routerEvent) => {
			for (const listener of this.subscribers) if (listener.eventType === routerEvent.type) try {
				listener.fn(routerEvent);
			} catch (e) {
				console.error(e);
			}
		};
		this.parseLocation = (locationToParse, previousLocation) => {
			const parse = ({ pathname, search, hash, href }, state) => {
				if (!this.rewrite && !/[ \x00-\x1f\x7f\u0080-\uffff]/.test(pathname)) {
					const parsedSearch = this.options.parseSearch(search);
					const searchStr = this.options.stringifySearch(parsedSearch);
					return {
						href: pathname + searchStr + hash,
						publicHref: pathname + searchStr + hash,
						pathname: decodePath(pathname),
						external: false,
						searchStr,
						search: nullReplaceEqualDeep(previousLocation?.search, parsedSearch),
						hash: decodePath(hash.slice(1)),
						state: replaceEqualDeep(previousLocation?.state, state)
					};
				}
				const url = executeRewriteInput(this.rewrite, new URL(href, this.origin));
				const parsedSearch = this.options.parseSearch(url.search);
				const searchStr = this.options.stringifySearch(parsedSearch);
				url.search = searchStr;
				return {
					href: url.href.replace(url.origin, ""),
					publicHref: href,
					pathname: decodePath(normalizeProtocolRelative(url.pathname)),
					external: !!this.rewrite && isExternalUrl(url, this.origin),
					searchStr,
					search: nullReplaceEqualDeep(previousLocation?.search, parsedSearch),
					hash: decodePath(url.hash.slice(1)),
					state: replaceEqualDeep(previousLocation?.state, state)
				};
			};
			const location = parse(locationToParse, locationToParse.state);
			const { __tempLocation, __tempKey } = location.state;
			if (__tempLocation && (!__tempKey || __tempKey === this.tempLocationKey)) {
				const parsedTempLocation = parse(__tempLocation, {
					...__tempLocation.state,
					__tempLocation: void 0,
					key: location.state.key,
					__TSR_key: location.state.__TSR_key
				});
				parsedTempLocation.maskedLocation = location;
				return parsedTempLocation;
			}
			return location;
		};
		this.matchRoutes = (pathnameOrNext, locationSearchOrOpts, opts) => {
			if (typeof pathnameOrNext === "string") return this.matchRoutesInternal({
				pathname: pathnameOrNext,
				search: locationSearchOrOpts
			}, opts);
			return this.matchRoutesInternal(pathnameOrNext, locationSearchOrOpts);
		};
		this.getMatchedRoutes = (pathname) => {
			const rawParams = Object.create(null);
			const match = findRouteMatch(trimPathRight(pathname), this.processedTree, true);
			if (match) Object.assign(rawParams, match.rawParams);
			return [
				match?.branch || [this.routesById["__root__"]],
				rawParams,
				match?.route
			];
		};
		this.buildLocation = (opts) => {
			if (!this.isServer) {
				const cached = this.staticLocations.get(opts);
				if (cached) return cached;
			}
			let usedCurrent = false;
			const build = (dest = {}) => {
				if (dest.href) {
					const parsed = parseHref(dest.href, {});
					dest = {
						...dest,
						to: executeRewriteInput(this.rewrite, new URL(parsed.pathname, this.origin)).pathname,
						search: this.options.parseSearch(parsed.search),
						hash: parsed.hash.slice(1)
					};
				}
				const currentLocation = opts._fromLocation || this._pendingLocation || this.latestLocation;
				let lightweight;
				const current = () => {
					usedCurrent = true;
					return currentLocation;
				};
				const currentMatch = () => lightweight ??= this.matchRoutesLightweight(current());
				if (dest.from && dest._isNavigate) {
					const [allFromMatches] = this.getMatchedRoutes(dest.from);
					const [matchedRoutes, fullPath] = currentMatch();
					const matchedFrom = findLast(matchedRoutes, (d) => {
						return comparePaths(d.fullPath, dest.from);
					});
					const matchedCurrent = findLast(allFromMatches, (d) => {
						return comparePaths(d.fullPath, fullPath);
					});
					if (!matchedFrom && !matchedCurrent) console.warn(`Could not find match for from: ${dest.from}`);
				}
				const to = dest.to ? `${dest.to}` : ".";
				const nextTo = resolvePath(to[0] === "/" ? "" : dest.unsafeRelative === "path" ? current().pathname : dest.from ?? currentMatch()[1], to, this.options.trailingSlash, this.resolvePathCache);
				const destRoute = this.routesByPath[trimPathRight(nextTo)];
				const isTemplate = nextTo.includes("$");
				let destRoutes;
				if (destRoute) destRoutes = destRoute._branch ??= buildRouteBranch(destRoute);
				else if (isTemplate) destRoutes = [];
				else {
					const [matchedRoutes, rawParams, foundRoute] = this.getMatchedRoutes(nextTo);
					destRoutes = matchedRoutes;
					if (this.options.notFoundRoute && (!foundRoute || foundRoute.path !== "/" && rawParams["**"])) destRoutes = [...destRoutes, this.options.notFoundRoute];
				}
				const interpolation = isTemplate ? destRoute?._interpolation ?? parseSegments(false, { fullPath: nextTo }, 0) : void 0;
				let nextParams;
				for (const route of destRoutes) {
					const fn = route.options.params?.stringify ?? route.options.stringifyParams;
					if (fn) {
						const fromParams = currentMatch()[3];
						nextParams ??= resolveNextParams(dest.params, fromParams);
						if (!hasKeys(nextParams)) break;
						if (nextParams === fromParams) nextParams = Object.assign(createNull(), nextParams);
						try {
							Object.assign(nextParams, fn(nextParams));
						} catch {}
					}
				}
				nextParams ??= resolveNextParams(dest.params, needsInheritedParams(dest.params, interpolation) ? currentMatch()[3] : EMPTY_RECORD);
				const nextPathname = opts.leaveParams ? nextTo : normalizeProtocolRelative(decodePath(interpolation ? interpolatePath(nextTo, interpolation, nextParams, this.pathParamsDecoder) : nextTo));
				if (destRoute && !opts.leaveParams) try {
					const foundRoute = this.getMatchedRoutes(nextPathname)[2];
					if (foundRoute?.id !== destRoute.id) console.warn(`Generated path "${nextPathname}" for route "${destRoute.id}" matched route "${foundRoute?.id}" instead. This can happen when multiple route templates resolve to the same URL. Use the route template that matches the intended route, or adjust params.stringify if it changed the target path.`);
				} catch {}
				const middlewares = getSearchMiddlewares(destRoutes, opts._includeValidateSearch);
				const fromSearch = () => {
					let search = currentMatch()[2];
					if (opts._includeValidateSearch && this.options.search?.strict) {
						const validatedSearch = {};
						destRoutes.forEach((route) => {
							if (route.options.validateSearch) try {
								Object.assign(validatedSearch, validateSearch(route.options.validateSearch, {
									...validatedSearch,
									...search
								}));
							} catch {}
						});
						search = validatedSearch;
					}
					return search;
				};
				const nextSearch = middlewares.length ? applySearchMiddleware(middlewares, fromSearch(), dest) : dest.search === true ? fromSearch() : typeof dest.search === "function" ? dest.search(fromSearch()) : dest.search || EMPTY_RECORD;
				const searchStr = this.options.stringifySearch(nextSearch);
				const hash = dest.hash === true ? current().hash : typeof dest.hash === "function" ? dest.hash(current().hash) : dest.hash || void 0;
				const hashStr = hash ? `#${hash}` : "";
				const nextState = !dest.state ? EMPTY_RECORD : dest.state === true ? current().state : typeof dest.state === "function" ? dest.state(current().state) : dest.state;
				const fullPath = `${nextPathname}${searchStr}${hashStr}`;
				let href;
				let publicHref;
				let external = false;
				if (this.rewrite) {
					const url = new URL(fullPath, this.origin);
					const origin = url.origin;
					const rewrittenUrl = executeRewriteOutput(this.rewrite, url);
					href = getUrlPath(url);
					if (isExternalUrl(rewrittenUrl, origin)) {
						publicHref = rewrittenUrl.href;
						external = true;
					} else publicHref = normalizeProtocolRelative(getUrlPath(rewrittenUrl));
				} else {
					href = encodePathLikeUrl(fullPath);
					publicHref = href;
				}
				return {
					publicHref,
					href,
					pathname: nextPathname,
					search: nextSearch,
					searchStr,
					state: nextState,
					hash: hash ?? "",
					external,
					unmaskOnReload: dest.unmaskOnReload
				};
			};
			const next = build(opts);
			if (opts.mask) next.maskedLocation = build({
				from: opts.from,
				...opts.mask
			});
			else if (this.options.routeMasks) {
				const match = findFlatMatch(next.pathname, this.processedTree);
				if (match) {
					const params = Object.assign(createNull(), match.rawParams);
					const { from: _from, params: maskParams, ...maskProps } = match.route;
					const nextParams = resolveNextParams(maskParams, params);
					next.maskedLocation = build({
						from: opts.from,
						...maskProps,
						params: nextParams
					});
				}
			}
			if (!this.isServer && !usedCurrent && opts._fromLocation) this.staticLocations.set(opts, next);
			return next;
		};
		this.commitLocation = async ({ viewTransition, ignoreBlocker, ...next }) => {
			if (this.isServer) return;
			const nextLocation = next.maskedLocation ?? next;
			if (nextLocation.external && !this.isServer) return documentNavigation(this, nextLocation.publicHref, {
				replace: next.replace,
				ignoreBlocker
			});
			let historyAction;
			const isSameLocation = trimPathRight(this.latestLocation.href) === trimPathRight(next.href) && deepEqual(_getUserHistoryState(next.state), _getUserHistoryState(this.latestLocation.state));
			const previousCommitPromise = this._commitPromise;
			let resolve;
			const commitPromise = new Promise((done) => {
				resolve = done;
			});
			commitPromise.resolve = () => {
				resolve();
				previousCommitPromise?.resolve();
			};
			this._commitPromise = commitPromise;
			if (isSameLocation) this.load();
			else {
				let { maskedLocation, hashScrollIntoView, ...nextHistory } = next;
				if (maskedLocation) {
					nextHistory = {
						...maskedLocation,
						state: {
							...maskedLocation.state,
							__tempKey: void 0,
							__tempLocation: {
								...nextHistory,
								search: nextHistory.searchStr,
								state: {
									...nextHistory.state,
									__tempKey: void 0,
									__tempLocation: void 0,
									__TSR_key: void 0,
									key: void 0
								}
							}
						}
					};
					if (nextHistory.unmaskOnReload ?? this.options.unmaskOnReload ?? false) nextHistory.state.__tempKey = this.tempLocationKey;
				}
				nextHistory.state = {
					...nextHistory.state,
					__hashScrollIntoViewOptions: hashScrollIntoView ?? this.options.defaultHashScrollIntoView ?? true
				};
				this.shouldViewTransition = viewTransition;
				historyAction = next.replace ? "REPLACE" : "PUSH";
				this.history[historyAction === "REPLACE" ? "replace" : "push"](nextHistory.publicHref, nextHistory.state, { ignoreBlocker });
				if (!this.history.subscribers.size) this.load({ action: { type: historyAction } });
			}
			this._scroll.n = next.resetScroll ?? true;
			return this._commitPromise;
		};
		this.buildAndCommitLocation = ({ replace, resetScroll, hashScrollIntoView, viewTransition, ignoreBlocker, ...rest } = {}) => {
			if (this.isServer) return Promise.resolve();
			const location = this.buildLocation({
				...rest,
				_includeValidateSearch: true
			});
			this._pendingLocation = location;
			const commitPromise = this.commitLocation({
				...location,
				viewTransition,
				replace,
				resetScroll,
				hashScrollIntoView,
				ignoreBlocker
			});
			queueMicrotask(() => {
				if (this._pendingLocation === location) this._pendingLocation = void 0;
			});
			return commitPromise;
		};
		this.navigate = async ({ to, reloadDocument, href, publicHref, ...rest }) => {
			if (this.isServer) return;
			const hrefScheme = href ? getUrlScheme(href) : void 0;
			if (hrefScheme || reloadDocument) {
				if (to !== void 0 || !href) {
					const location = this.buildLocation({
						to,
						...rest
					});
					const publicLocation = location.maskedLocation ?? location;
					href ??= publicLocation.publicHref;
					publicHref ??= publicLocation.publicHref;
				}
				const reloadHref = !hrefScheme && publicHref ? publicHref : href;
				return documentNavigation(this, reloadHref, rest);
			}
			return this.buildAndCommitLocation({
				...rest,
				href,
				to,
				_isNavigate: true
			});
		};
		this.load = async (opts) => {
			if (this.isServer) return loadServerRoute(this, opts);
			this.updateLatestLocation();
			if (opts?.action) this._scroll.h = opts.action.type === "PUSH" || opts.action.type === "REPLACE";
			await loadClientRoute(this, opts);
		};
		this.startViewTransition = (fn) => {
			const shouldViewTransition = this.shouldViewTransition ?? this.options.defaultViewTransition;
			this.shouldViewTransition = void 0;
			if (shouldViewTransition && !(typeof document === "undefined") && typeof document.startViewTransition === "function") {
				let startViewTransitionParams;
				if (typeof shouldViewTransition === "object" && window.CSS?.supports?.("selector(:active-view-transition-type(a))")) {
					const next = this.latestLocation;
					const prevLocation = this.stores.resolvedLocation.get();
					const resolvedViewTransitionTypes = typeof shouldViewTransition.types === "function" ? shouldViewTransition.types(getLocationChangeInfo(next, prevLocation)) : shouldViewTransition.types;
					if (resolvedViewTransitionTypes === false) return fn();
					startViewTransitionParams = {
						update: fn,
						types: resolvedViewTransitionTypes
					};
				} else startViewTransitionParams = fn;
				return document.startViewTransition(startViewTransitionParams).updateCallbackDone;
			}
			return fn();
		};
		this.invalidate = (opts) => {
			const committedMatches = this._committed;
			const filter = opts?.filter;
			const preloads = this._preloads;
			const invalidIds = /* @__PURE__ */ new Set();
			const consider = (match) => {
				if (!filter || filter(match)) invalidIds.add(match.id);
			};
			committedMatches.forEach(consider);
			this._cache.forEach(consider);
			preloads?.forEach((matches) => matches.forEach(consider));
			this._tx?.[3].forEach(consider);
			const abort = [];
			for (const [controller, matches] of preloads ?? []) if (matches.some((match) => invalidIds.has(match.id))) {
				preloads.delete(controller);
				abort.push(controller);
			}
			const invalidate = (d) => {
				if (invalidIds.has(d.id)) {
					const route = this.routesById[d.routeId];
					const next = {
						...d,
						invalid: true,
						...(opts?.forcePending || d.status === "error" || d.status === "notFound") && routeNeedsLoad(route) ? {
							status: "pending",
							error: void 0
						} : void 0
					};
					d._flight = void 0;
					return next;
				}
				return d;
			};
			this._committed = committedMatches.map(invalidate);
			for (const [id, match] of this._cache) if (invalidIds.has(id)) {
				match.invalid = true;
				if (opts?.forcePending) match.status = "pending";
			}
			for (const id of invalidIds) {
				const flight = this._flights?.get(id);
				this._flights?.delete(id);
				if (flight && !flight[2]) abort.push(flight[1]);
			}
			for (const controller of abort) controller.abort();
			this.shouldViewTransition = false;
			return this.load({ sync: opts?.sync });
		};
		this.resolveRedirect = (redirect) => {
			const options = redirect.options;
			let href = redirect.headers.get("Location") || options.href;
			if (!href) {
				const location = this.buildLocation(options);
				href = (location.maskedLocation ?? location).publicHref || "/";
			}
			let scheme;
			if (protocolRelativePrefixRegex.test(href) || (scheme = getUrlScheme(href)) && !this.protocolAllowlist.has(scheme)) throw new Error(`Redirect blocked: unsafe protocol in href "${href}". Allowed protocols: ${Array.from(this.protocolAllowlist).join(", ")}.`);
			if (scheme === "http:" || scheme === "https:") {
				const url = new URL(href);
				if (url.pathname.startsWith("//")) href = url.href;
				else if (!isExternalUrl(url, this.origin)) {
					href = getUrlPath(url);
					scheme = void 0;
				}
			}
			if (scheme) options.reloadDocument = true;
			options.href = href;
			redirect.headers.set("Location", href);
			return redirect;
		};
		this.clearCache = (opts) => {
			const cached = this._cache;
			const preloads = this._preloads;
			const filter = opts?.filter;
			const discarded = [];
			const discardedIds = [];
			for (const [id, match] of cached) if (!filter || filter(match)) {
				discardedIds.push(id);
				discarded.push(match);
			}
			const abort = [];
			for (const [controller, matches] of preloads ?? []) if (!filter || matches.some(filter)) {
				abort.push(controller);
				discarded.push(...matches);
			}
			for (const id of discardedIds) cached.delete(id);
			for (const controller of abort) preloads.delete(controller);
			for (const match of discarded) {
				const flight = match._flight;
				match._flight = void 0;
				if (flight && !--flight[2]) {
					if (this._flights?.get(match.id) === flight) this._flights.delete(match.id);
					abort.push(flight[1]);
				}
			}
			for (const controller of abort) controller.abort();
		};
		this.loadRouteChunk = loadRouteChunk;
		this.preloadRoute = (opts) => preloadClientRoute(this, opts);
		this.matchRoute = (location, opts) => {
			const matchLocation = {
				...location,
				to: location.to ? resolvePath(location.from || "", location.to, this.options.trailingSlash, this.resolvePathCache) : void 0,
				params: location.params || {},
				leaveParams: true
			};
			const next = this.buildLocation(matchLocation);
			const isPending = this.stores.status.get() === "pending";
			if (opts?.pending && !isPending) return false;
			const baseLocation = opts?.pending ?? !isPending ? this.latestLocation : this.stores.resolvedLocation.get() || this.stores.location.get();
			const match = findSingleMatch(next.pathname, opts?.caseSensitive ?? false, opts?.fuzzy ?? false, baseLocation.pathname, this.processedTree);
			if (!match) return false;
			if (location.params) {
				if (!deepEqual(match.rawParams, location.params, true)) return false;
			}
			if (opts?.includeSearch ?? true) return deepEqual(baseLocation.search, next.search, true) ? match.rawParams : false;
			return match.rawParams;
		};
		this.getStoreConfig = getStoreConfig;
		if (options.pathParamsAllowedCharacters?.length) this.pathParamsDecoder = compileDecodeCharMap(options.pathParamsAllowedCharacters);
		this.update({
			defaultPreloadDelay: 50,
			defaultPendingMs: 1e3,
			defaultPendingMinMs: 500,
			context: void 0,
			...options,
			caseSensitive: options.caseSensitive ?? false,
			notFoundMode: options.notFoundMode ?? "fuzzy",
			stringifySearch: options.stringifySearch ?? defaultStringifySearch,
			parseSearch: options.parseSearch ?? defaultParseSearch,
			protocolAllowlist: options.protocolAllowlist ?? DEFAULT_PROTOCOL_ALLOWLIST
		});
		if (!(typeof document === "undefined")) self.__TSR_ROUTER__ = this;
	}
	isShell() {
		return !!this.options.isShell;
	}
	get state() {
		return this.stores.__store.get();
	}
	setRoutes(caches) {
		Object.assign(this, caches);
		this.lightweightCache = /* @__PURE__ */ new WeakMap();
		if (!this.isServer) this.staticLocations = /* @__PURE__ */ new WeakMap();
		const notFoundRoute = this.options.notFoundRoute;
		if (notFoundRoute) {
			notFoundRoute.init(99999999999);
			if (this.routesById[notFoundRoute.id] !== notFoundRoute) notFoundRoute._interpolation = parseSegments(false, notFoundRoute, 0);
			this.routesById[notFoundRoute.id] = notFoundRoute;
		}
	}
	matchRoutesInternal(next, opts) {
		const [initialMatchedRoutes, rawParams, foundRoute] = this.getMatchedRoutes(next.pathname);
		let matchedRoutes = initialMatchedRoutes;
		let isGlobalNotFound = false;
		if (foundRoute ? foundRoute.path !== "/" && rawParams["**"] : trimPathRight(next.pathname)) {
			if (this.options.notFoundRoute) matchedRoutes = [...matchedRoutes, this.options.notFoundRoute];
			else isGlobalNotFound = true;
		}
		const _notFoundRouteId = isGlobalNotFound ? findGlobalNotFoundRouteId(this.options.notFoundMode, matchedRoutes) : void 0;
		const matches = new Array(matchedRoutes.length);
		const committed = this._committed;
		const previousAt = (route, index) => {
			const match = committed[index];
			return match?.routeId === route.id ? match : route === this.options.notFoundRoute ? committed.find((candidate) => candidate.routeId === route.id) : void 0;
		};
		let strictParams;
		for (let index = 0; index < matchedRoutes.length; index++) {
			const route = matchedRoutes[index];
			const parentMatch = matches[index - 1];
			let preMatchSearch;
			let strictMatchSearch;
			let searchError;
			{
				const parentSearch = parentMatch?.search ?? next.search;
				const parentStrictSearch = parentMatch?._strictSearch ?? void 0;
				try {
					const strictSearch = validateSearch(route.options.validateSearch, { ...parentSearch }) ?? void 0;
					preMatchSearch = {
						...parentSearch,
						...strictSearch
					};
					strictMatchSearch = {
						...parentStrictSearch,
						...strictSearch
					};
				} catch (err) {
					let searchParamError = err;
					if (!(err instanceof SearchParamError)) searchParamError = new SearchParamError(err.message, { cause: err });
					if (opts?.throwOnError) throw searchParamError;
					preMatchSearch = parentSearch;
					strictMatchSearch = {};
					searchError = searchParamError;
				}
			}
			let loaderDeps = "";
			let loaderDepsHash = "";
			try {
				loaderDeps = route.options.loaderDeps?.({ search: preMatchSearch }) ?? "";
				loaderDepsHash = loaderDeps ? JSON.stringify(loaderDeps) || "" : "";
			} catch (cause) {
				if (opts?.throwOnError) throw cause;
				searchError ??= cause;
			}
			const usedParams = createNull();
			const interpolatedPath = route._interpolation ? interpolatePath(route.fullPath, route._interpolation, rawParams, this.pathParamsDecoder, usedParams) : route.fullPath;
			const matchId = route.id + interpolatedPath + loaderDepsHash;
			const previousMatch = previousAt(route, index);
			const existingMatch = opts?._rematerialize ? void 0 : this._cache.get(matchId) ?? (previousMatch?.id === matchId ? previousMatch : void 0);
			strictParams = existingMatch?._strictParams ?? Object.assign(usedParams, strictParams);
			let paramsError;
			if (!existingMatch) try {
				extractStrictParams(route, strictParams);
			} catch (err) {
				if (isNotFound(err) || isRedirect(err)) paramsError = err;
				else paramsError = new PathParamError(err.message, { cause: err });
				if (opts?.throwOnError) throw paramsError;
			}
			const cause = previousMatch ? "stay" : "enter";
			let match;
			if (existingMatch) match = {
				...existingMatch,
				cause,
				search: previousMatch ? nullReplaceEqualDeep(previousMatch.search, preMatchSearch) : nullReplaceEqualDeep(existingMatch.search, preMatchSearch),
				_strictSearch: strictMatchSearch,
				searchError
			};
			else {
				const status = routeNeedsLoad(route) ? "pending" : "success";
				match = {
					id: matchId,
					ssr: this.isServer ? void 0 : route.options.ssr,
					index,
					routeId: route.id,
					params: previousMatch?.params ?? strictParams,
					_strictParams: strictParams,
					pathname: interpolatedPath,
					updatedAt: Date.now(),
					search: previousMatch ? nullReplaceEqualDeep(previousMatch.search, preMatchSearch) : preMatchSearch,
					_strictSearch: strictMatchSearch,
					searchError,
					status,
					isFetching: false,
					error: void 0,
					paramsError,
					context: {},
					abortController: opts?._controller ?? new AbortController(),
					cause,
					loaderDeps: previousMatch ? replaceEqualDeep(previousMatch.loaderDeps, loaderDeps) : loaderDeps,
					invalid: false,
					preload: false,
					staticData: route.options.staticData || {},
					fullPath: route.fullPath
				};
			}
			const _notFound = _notFoundRouteId === route.id;
			if (match._notFound && !_notFound) match.error = void 0;
			match._notFound = _notFound;
			matches[index] = match;
		}
		for (let index = 0; index < matches.length; index++) {
			const match = matches[index];
			match.params = match.cause === "stay" ? nullReplaceEqualDeep(match.params, strictParams) : strictParams;
			if (opts?._controller) match.context = {};
		}
		return matches;
	}
	/**
	* Lightweight route matching for buildLocation.
	* Only computes fullPath, accumulated search, and params - skipping expensive
	* operations like AbortController, loaderDeps, and full match objects.
	*/
	matchRoutesLightweight(location) {
		const lastRouteId = last(this.stores.ids.get());
		const lastStateMatch = lastRouteId ? this.stores.byRoute.get(lastRouteId).get() : void 0;
		const lastStateMatchId = lastStateMatch?.id;
		const cached = this.lightweightCache.get(location);
		if (cached && cached[0] === lastStateMatchId) return cached[1];
		const [matchedRoutes, rawParams] = this.getMatchedRoutes(location.pathname);
		const lastRoute = last(matchedRoutes);
		const accumulatedSearch = { ...location.search };
		for (const route of matchedRoutes) try {
			Object.assign(accumulatedSearch, validateSearch(route.options.validateSearch, accumulatedSearch));
		} catch {}
		const canReuseParams = lastStateMatch && lastStateMatch.routeId === lastRoute.id && lastStateMatch.pathname === location.pathname;
		let params;
		if (canReuseParams) params = lastStateMatch.params;
		else {
			const strictParams = rawParams;
			for (const route of matchedRoutes) try {
				extractStrictParams(route, strictParams);
			} catch {}
			params = strictParams;
		}
		const result = [
			matchedRoutes,
			lastRoute.fullPath,
			accumulatedSearch,
			params
		];
		this.lightweightCache.set(location, [lastStateMatchId, result]);
		return result;
	}
};
async function documentNavigation(router, href, { replace, ignoreBlocker }) {
	if (isDangerousProtocol(href, router.protocolAllowlist)) {
		console.warn(`Blocked navigation to dangerous protocol: ${href}`);
		return;
	}
	if (!ignoreBlocker) {
		const blockers = router.history._getBlockers();
		for (const blocker of blockers) if (blocker?.blockerFn) {
			if (await blocker.blockerFn({
				currentLocation: router.history.location,
				nextLocation: router.history.location,
				action: replace ? "REPLACE" : "PUSH"
			})) return;
		}
	}
	router.history._ignoreNextBeforeUnload?.(href);
	if (replace) window.location.replace(href);
	else window.location.href = href;
}
RouterCore.prototype._replaceRouteChunk = replaceRouteChunk;
RouterCore.prototype._refreshRoute = async function() {
	this._serverResult = void 0;
	this.updateLatestLocation();
	await refreshClientRoute(this);
};
/** Error thrown when search parameter validation fails. */
var SearchParamError = class extends Error {};
/** Error thrown when path parameter parsing/validation fails. */
var PathParamError = class extends Error {};
var normalize$2 = (str) => str.endsWith("/") && str.length > 1 ? str.slice(0, -1) : str;
function comparePaths(a, b) {
	return normalize$2(a) === normalize$2(b);
}
/**
* Lazily import a module function and forward arguments to it, retaining
* parameter and return types for the selected export key.
*/
function lazyFn(fn, key) {
	return async (...args) => {
		return (await fn())[key || "default"](...args);
	};
}
function validateSearch(validateSearch, input) {
	if (validateSearch == null) return {};
	if ("~standard" in validateSearch) {
		const result = validateSearch["~standard"].validate(input);
		if (result instanceof Promise) throw new SearchParamError("Async validation not supported");
		if (result.issues) throw new SearchParamError(JSON.stringify(result.issues, void 0, 2), { cause: result });
		return result.value;
	}
	if ("parse" in validateSearch) return validateSearch.parse(input);
	if (typeof validateSearch === "function") return validateSearch(input);
	return {};
}
function resolveNextParams(spec, base) {
	if (spec === void 0 || spec === true) return base;
	const next = Object.create(null);
	if (spec === false || spec === null) return next;
	if (typeof spec === "function") {
		Object.assign(next, base);
		return Object.assign(next, spec(next));
	}
	return Object.assign(next, base, spec);
}
function needsInheritedParams(spec, interpolation) {
	if (typeof spec === "function") return true;
	if (!interpolation || spec === false || spec === null) return false;
	return spec === void 0 || spec === true || interpolation.some((part) => typeof part !== "string" && !hasOwn.call(spec, part[1]));
}
var EMPTY_RECORD = Object.freeze({});
function getSearchMiddlewares(destRoutes, includeValidateSearch) {
	const middlewares = [];
	for (let i = 0; i < destRoutes.length; i++) {
		const routeOptions = destRoutes[i].options;
		if ("search" in routeOptions) {
			if (routeOptions.search?.middlewares) middlewares.push(...routeOptions.search.middlewares);
		} else if (routeOptions.preSearchFilters || routeOptions.postSearchFilters) {
			const legacyMiddleware = ({ search, next }) => {
				const result = next(routeOptions.preSearchFilters ? routeOptions.preSearchFilters.reduce((prev, next) => next(prev), search) : search);
				return routeOptions.postSearchFilters ? routeOptions.postSearchFilters.reduce((prev, next) => next(prev), result) : result;
			};
			middlewares.push(legacyMiddleware);
		}
		const routeValidateSearch = routeOptions.validateSearch;
		if (includeValidateSearch && routeValidateSearch) {
			const validate = ({ search, next, meta }) => {
				const result = next(search);
				try {
					const validated = validateSearch(routeValidateSearch, result);
					if (meta && validated) {
						for (const key in validated) if (!(key in result)) (meta.defaulted ||= /* @__PURE__ */ new Map()).set(key, validated[key]);
					}
					return {
						...result,
						...validated
					};
				} catch {}
				return result;
			};
			middlewares.push(validate);
		}
	}
	return middlewares;
}
function applySearchMiddleware(middlewares, search, dest) {
	const applyNext = (index, currentSearch, meta) => {
		if (index >= middlewares.length) {
			if (!dest.search) return {};
			if (dest.search === true) return currentSearch;
			const result = functionalUpdate(dest.search, currentSearch);
			if (meta) meta.explicit = result;
			return result;
		}
		const next = (newSearch, collectMeta) => {
			if (collectMeta) {
				const nextMeta = meta || {};
				return {
					search: applyNext(index + 1, newSearch, nextMeta),
					meta: nextMeta
				};
			}
			return applyNext(index + 1, newSearch, meta);
		};
		return middlewares[index]({
			search: currentSearch,
			next,
			meta
		});
	};
	return applyNext(0, search);
}
function findGlobalNotFoundRouteId(notFoundMode, routes) {
	if (notFoundMode !== "root") {
		let fallback;
		for (let i = routes.length - 1; i >= 0; i--) {
			const route = routes[i];
			if (route.options.notFoundComponent) return route.id;
			fallback ||= route.children && route.id;
		}
		if (fallback) return fallback;
	}
	return rootRouteId;
}
function extractStrictParams(route, accumulatedParams) {
	const parseParams = route.options.params?.parse ?? route.options.parseParams;
	if (parseParams) Object.assign(accumulatedParams, parseParams(accumulatedParams));
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/load-client.js
function replaceRouteChunk(route, lazyFn) {
	route.lazyFn = lazyFn ?? route.lazyFn;
	route._lazy = void 0;
}
function preloadComponent(route, type) {
	return route.options[type]?.preload?.();
}
function loadComponents(route, onPendingReady) {
	const component = preloadComponent(route, "component");
	let pending = preloadComponent(route, "pendingComponent");
	if (onPendingReady) {
		if (pending) pending = pending.then(onPendingReady);
		else onPendingReady();
	}
	if (component && pending) return Promise.all([component, pending]).then(() => {});
	return component ?? pending;
}
function loadRouteChunk(route, componentType, onPendingReady) {
	const afterLazy = () => componentType === false ? void 0 : componentType ? preloadComponent(route, componentType) : loadComponents(route, onPendingReady);
	const current = route._lazy;
	if (current) return current === true ? afterLazy() : current.then(afterLazy);
	if (!route.lazyFn) return afterLazy();
	const promise = route.lazyFn().then((lazyRoute) => {
		if (route._lazy === promise) {
			const { id: _id, ...options } = lazyRoute.options;
			Object.assign(route.options, options);
			route._lazy = true;
		}
	}, (error) => {
		if (route._lazy === promise) route._lazy = void 0;
		throw error;
	});
	route._lazy = promise;
	return promise.then(afterLazy);
}
/** Return the structural lane through the first terminal render boundary. */
function _getRenderedMatches(matches) {
	const end = matches.findIndex((match) => match.status !== "success" || match._notFound) + 1;
	return end && end < matches.length ? matches.slice(0, end) : matches;
}
/**
* Truthy when the transaction publishing `location` leaves `routeId` out of its
* matches, so subscribers scoped to that route can skip the publication: the
* route unmounts when the transaction commits, and a transaction that ends
* otherwise is superseded or redirected by a newer publication. Only valid
* synchronously inside the publication: the transaction's matches are emptied
* at commit and before following a redirect. Publications without a matching
* transaction (hydration) and scopes without a route never depart.
*/
function _isRouteDeparting(router, routeId, location) {
	const tx = router._tx;
	return routeId && tx?.[2] === location && !tx[3].some((match) => match.routeId === routeId);
}
/** Return the lane whose document assets belong to the current presentation. */
function _getAssetMatches(matches) {
	let end = matches.length;
	for (let index = 0; index < end; index++) {
		const match = matches[index];
		if (match._assetEnd !== void 0) {
			end = Math.min(end, Math.max(index + 1, match._assetEnd));
			continue;
		}
		if (match.status !== "success" || match._notFound) {
			end = index + 1;
			break;
		}
	}
	return end < matches.length ? matches.slice(0, end) : matches;
}
var SUCCESS$1 = 0;
var ERROR$1 = 1;
var NOT_FOUND$1 = 2;
var REDIRECTED$1 = 3;
var CANCELED_OUTCOME = [4];
function isControl(result) {
	return typeof result[0] === "number";
}
function waitFor$1(value, signal) {
	if (signal.aborted) return Promise.race([Promise.reject(signal), value]);
	return new Promise((resolve, reject) => {
		const abort = () => reject(signal);
		signal.addEventListener("abort", abort, { once: true });
		Promise.resolve(value).then(resolve, reject).then(() => signal.removeEventListener("abort", abort));
	});
}
function getRoute$1(router, match) {
	return router.routesById[match.routeId];
}
function normalize$1(value, rejected, routeId) {
	if (isRedirect(value)) return [REDIRECTED$1, value];
	if (isNotFound(value)) {
		value.routeId ||= routeId;
		return [NOT_FOUND$1, value];
	}
	if (!rejected) return [SUCCESS$1, value];
	if (typeof value?.then === "function") value = new Error("A Promise was thrown", { cause: value });
	return [ERROR$1, value];
}
function normalizeError$1(route, cause) {
	let outcome = normalize$1(cause, true, route.id);
	if (outcome[0] !== ERROR$1) return outcome;
	try {
		route.options.onError?.(outcome[1]);
	} catch (onErrorCause) {
		outcome = normalize$1(onErrorCause, true, route.id);
	}
	return outcome;
}
function normalizeLaneError(router, lane, route, cause, options) {
	if (options[0].signal.aborted) return CANCELED_OUTCOME;
	return materializeRedirect$1(router, lane, route, normalizeError$1(route, cause), options);
}
async function contextualize$1(router, lane, options, end, planSuccessfulLane, retainedEnd) {
	const [location, matches] = lane;
	const signal = options[0].signal;
	const preload = !!options[3];
	for (let index = options[6] ?? 0; index < end; index++) {
		const match = matches[index];
		const route = getRoute$1(router, match);
		match.abortController = options[0];
		const parentContext = matches[index - 1]?.context ?? router.options.context ?? {};
		const common = {
			params: match.params,
			location,
			navigate: (opts) => router.navigate({
				...opts,
				_fromLocation: location
			}),
			buildLocation: router.buildLocation,
			cause: preload ? "preload" : match.cause,
			abortController: options[0],
			preload,
			matches,
			routeId: route.id
		};
		try {
			const routeContext = match._ctx ||= route.options.context ? route.options.context({
				...common,
				deps: match.loaderDeps,
				context: parentContext
			}) || {} : void 0;
			match.context = {
				...parentContext,
				...routeContext
			};
		} catch (cause) {
			releaseFlight(router, match);
			return [index, normalizeLaneError(router, lane, route, cause, options)];
		}
		if (signal.aborted) return [index, CANCELED_OUTCOME];
		const validationError = match.paramsError ?? match.searchError;
		if (validationError !== void 0) {
			releaseFlight(router, match);
			return [index, normalizeLaneError(router, lane, route, validationError, options)];
		}
		const beforeLoad = route.options.beforeLoad;
		if (!beforeLoad) continue;
		const previousStatus = match.status;
		if (index >= retainedEnd) {
			match.status = "pending";
			options[7]?.();
		}
		try {
			setFetching(router, match, "beforeLoad", options[0]);
			const value = beforeLoad({
				...common,
				search: match.search,
				context: match.context,
				...router.options.additionalContext
			});
			const result = await (typeof value?.then === "function" ? waitFor$1(value, signal) : value);
			if (signal.aborted) return [index, CANCELED_OUTCOME];
			const outcome = materializeRedirect$1(router, lane, route, normalize$1(result, false, route.id), options);
			if (outcome[0] !== SUCCESS$1) {
				releaseFlight(router, match);
				return [index, outcome];
			}
			match.context = {
				...match.context,
				...result
			};
		} catch (cause) {
			releaseFlight(router, match);
			return [index, normalizeLaneError(router, lane, route, cause, options)];
		} finally {
			match.status = previousStatus;
			setFetching(router, match, false, options[0]);
		}
	}
	planSuccessfulLane();
}
function releaseOwnedFlight(router, match, flight) {
	if (!flight || --flight[2]) return;
	if (router._flights?.get(match.id) === flight) {
		const current = router._tx;
		if (current && !current[0].signal.aborted && !current[3].includes(match) && current[3].some((candidate) => candidate.id === match.id) && current[3].some((candidate) => candidate.isFetching === "beforeLoad")) return;
		router._flights.delete(match.id);
	}
	return flight[1];
}
function releaseFlight(router, match) {
	const flight = match._flight;
	match._flight = void 0;
	releaseOwnedFlight(router, match, flight)?.abort();
}
/**
* Not passing in a `next` ownership recipient
* is equivalent to discarding the match resources
*/
function transferMatchResources(router, previous, next, deferSameIdFlight) {
	const abort = [];
	for (const match of previous) if (!next?.includes(match)) {
		const flight = match._flight;
		match._flight = void 0;
		if (deferSameIdFlight && flight?.[2] === 1 && router._flights?.get(match.id) === flight && next?.some((candidate) => candidate.id === match.id)) flight[2] = 0;
		else {
			const controller = releaseOwnedFlight(router, match, flight);
			if (controller) abort.push(controller);
		}
	}
	for (const controller of abort) controller.abort();
}
function acquireMatchResources(matches) {
	for (const match of matches) {
		const flight = match._flight;
		if (flight) flight[2]++;
	}
}
function setFetching(router, match, value, owner) {
	match.isFetching = value;
	if (owner && router._tx?.[0] !== owner) return;
	const store = router.stores.byRoute.get(match.routeId);
	const presented = store?.get();
	if (presented?.id === match.id) store.set({
		...presented,
		isFetching: value
	});
}
function getLoaderContext$1(router, lane, match, route, controller, parentMatchPromise, preload) {
	const location = lane[0];
	return {
		params: match.params,
		location,
		navigate: (opts) => router.navigate({
			...opts,
			_fromLocation: location
		}),
		cause: preload ? "preload" : match.cause,
		abortController: controller,
		preload,
		deps: match.loaderDeps,
		parentMatchPromise,
		context: match.context,
		route,
		...router.options.additionalContext
	};
}
async function loadResource(router, lane, match, route, loader, parentMatchPromise, options) {
	const owner = options[0];
	const signal = owner.signal;
	if (signal.aborted) return CANCELED_OUTCOME;
	if (!loader) return [SUCCESS$1, void 0];
	let flight = match._flight;
	setFetching(router, match, "loader", owner);
	try {
		if (!flight) {
			const controller = new AbortController();
			flight = [
				Promise.resolve().then(() => loader(getLoaderContext$1(router, lane, match, route, controller, parentMatchPromise, !!options[3]))).then((value) => normalize$1(value, false, route.id), (cause) => normalize$1(cause, true, route.id)).then((result) => {
					if (result[0] !== SUCCESS$1 && router._flights?.get(match.id) === flight) {
						router._flights.delete(match.id);
						if (!flight[2]) controller.abort();
					}
					return result[0] === ERROR$1 && flight[2] ? normalizeError$1(route, result[1]) : result;
				}),
				controller,
				1
			];
			(router._flights ??= /* @__PURE__ */ new Map()).set(match.id, flight);
		}
		match._flight = flight;
		match.abortController = flight[1];
		return materializeRedirect$1(router, lane, route, await waitFor$1(flight[0], signal), options);
	} catch (cause) {
		if (cause !== signal || !signal.aborted) throw cause;
		releaseFlight(router, match);
		return CANCELED_OUTCOME;
	} finally {
		setFetching(router, match, false, owner);
	}
}
function settleInto(match, result, preload) {
	if (result[0] === REDIRECTED$1) return;
	match.status = "success";
	match.error = void 0;
	if (result[0] === SUCCESS$1) {
		match.loaderData = result[1];
		match.invalid = false;
		match.updatedAt = Date.now();
		match.preload = preload;
	} else match.invalid = true;
}
function cacheLoaderMatch(router, match, planned) {
	const current = router._cache.get(match.id);
	if (current !== planned || router._committed.some((candidate) => candidate.id === match.id && candidate._flight === match._flight)) return;
	const cached = {
		...match,
		_notFound: void 0,
		context: {}
	};
	if (cached._flight) cached._flight[2]++;
	router._cache.set(match.id, cached);
	if (current) releaseFlight(router, current);
}
function getParentSnapshot(match, outcome) {
	if (outcome[0] === ERROR$1 || outcome[0] === NOT_FOUND$1) return {
		...match,
		status: outcome[0] === ERROR$1 ? "error" : "notFound",
		error: outcome[1],
		_flight: void 0
	};
	return match;
}
function createLoaderTask$1(router, lane, index, tasks, semanticParent, options, retainedEnd) {
	const match = lane[1][index];
	const route = getRoute$1(router, match);
	const preload = !!options[3];
	const plannedCacheMatch = router._cache.get(match.id);
	let configured;
	let reload = false;
	let reloadFailure;
	try {
		if (match.status === "success") {
			configured = route.options.shouldReload;
			if (typeof configured === "function") configured = configured(getLoaderContext$1(router, lane, match, route, options[0], semanticParent, preload));
			if (options[0].signal.aborted) reloadFailure = CANCELED_OUTCOME;
		}
		if (!reloadFailure) {
			if (match.status !== "success") reload = true;
			else {
				const staleAge = preload || match.preload ? route.options.preloadStaleTime ?? router.options.defaultPreloadStaleTime ?? 3e4 : route.options.staleTime ?? router.options.defaultStaleTime ?? 0;
				reload = !!(match.invalid || configured || configured === void 0 && Date.now() - match.updatedAt >= staleAge && (options[5] || match.cause === "enter" || options[2].some((candidate) => candidate.routeId === match.routeId && candidate.id !== match.id)));
			}
		}
	} catch (cause) {
		match.invalid = true;
		releaseFlight(router, match);
		reloadFailure = normalizeLaneError(router, lane, route, cause, options);
	}
	const routeLoader = route.options.loader;
	const isLoaderFn = typeof routeLoader === "function";
	const loader = isLoaderFn ? routeLoader : routeLoader?.handler;
	const preloadable = !preload || route.options.preload !== false;
	let donor = preloadable && routeLoader && !router._tx?.[6] ? router._flights?.get(match.id) : void 0;
	if (donor === match._flight || reloadFailure) donor = void 0;
	else if (donor && !reload && !preload && configured === void 0) reload = true;
	else if (!reload) donor = void 0;
	const background = !!(routeLoader && reload && match.status === "success" && !preload && !options[4] && ((isLoaderFn ? void 0 : routeLoader.staleReloadMode) ?? router.options.defaultStaleReloadMode) !== "blocking");
	const loaded = reload && preloadable;
	const blocking = loaded && !background && (match.status !== "success" || !!routeLoader);
	const onReady = index >= retainedEnd ? options[7] : void 0;
	const onLazyReady = route.lazyFn && route._lazy !== true ? onReady : void 0;
	if (loaded && !routeLoader) {
		match.invalid = false;
		match.updatedAt = Date.now();
	}
	if (donor) donor[2]++;
	if (blocking) {
		const acceptedFlight = match._flight;
		match._flight = donor;
		releaseOwnedFlight(router, match, acceptedFlight)?.abort();
		if (index >= retainedEnd) match.status = "pending";
		onReady?.();
	}
	if (!loaded) match.isFetching = false;
	const outcome = !reloadFailure && blocking ? loadResource(router, lane, match, route, loader, semanticParent, options).then((result) => {
		settleInto(match, result, preload);
		if (result[0] === SUCCESS$1) {
			if (routeLoader && !options[0].signal.aborted) cacheLoaderMatch(router, match, plannedCacheMatch);
			if (index >= retainedEnd) match.status = "pending";
		}
		return result;
	}) : Promise.resolve(reloadFailure ?? [SUCCESS$1, match.loaderData]);
	const chunkFailure = (async () => {
		try {
			const chunk = loadRouteChunk(route, void 0, onLazyReady);
			if (chunk) await waitFor$1(chunk, options[0].signal);
		} catch (cause) {
			if (!lane[1].some((candidate, candidateIndex) => candidateIndex <= index && (candidate.status === "error" || candidate.status === "notFound" || candidate._notFound))) return [index, normalizeLaneError(router, lane, route, cause, options)];
		}
		const result = await outcome;
		if (blocking && result[0] === SUCCESS$1 && match.status === "pending" && !options[0].signal.aborted) {
			match.status = "success";
			onReady?.();
		}
	})();
	tasks.push([
		index,
		outcome,
		chunkFailure
	]);
	if (!background) return outcome.then((result) => getParentSnapshot(match, result));
	const candidate = {
		...match,
		status: "pending",
		preload: false,
		_flight: donor
	};
	match.invalid = false;
	match.isFetching = "loader";
	const backgroundOutcome = loadResource(router, lane, candidate, route, loader, semanticParent, options).then((result) => {
		match.isFetching = false;
		settleInto(candidate, result, false);
		return result;
	});
	(lane[2] ??= []).push([
		index,
		backgroundOutcome,
		chunkFailure,
		candidate
	]);
	return backgroundOutcome.then((result) => getParentSnapshot(candidate, result));
}
async function getNotFoundBoundary$1(router, matches, indexed, signal, fallback = 0) {
	const cause = indexed?.[1][1];
	let index = cause?.routeId ? matches.findIndex((match) => match.routeId === cause.routeId) : indexed?.[0] ?? matches.length - 1;
	if (index < 0) index = 0;
	for (let i = index; i >= 0; i--) {
		const route = getRoute$1(router, matches[i]);
		try {
			const loading = loadRouteChunk(route, false);
			if (loading) await waitFor$1(loading, signal);
		} catch (cause) {
			if (cause === signal && signal.aborted) throw cause;
		}
		if (route.options.notFoundComponent) return i;
	}
	return cause?.routeId ? index : fallback;
}
function discardBackground(router, lane) {
	if (lane[2]) {
		transferMatchResources(router, lane[2].map((task) => task[3]));
		lane[2] = void 0;
	}
}
async function settleTasks(tasks, serialFailure, redirectTasks, gate) {
	let loaderFailure;
	try {
		await Promise.all(tasks.map((task) => task[1].then(async (outcome) => {
			const taskIndex = task[0];
			if (gate && taskIndex >= await gate) return;
			if (outcome[0] >= REDIRECTED$1) throw [taskIndex, outcome];
			if (!loaderFailure && outcome[0] !== SUCCESS$1) {
				loaderFailure = [taskIndex, outcome];
				await Promise.all((redirectTasks ?? []).map((nextTask) => {
					if (nextTask[0] <= taskIndex) return;
					return nextTask[1].then((nextOutcome) => {
						if (nextOutcome[0] === REDIRECTED$1) throw [nextTask[0], nextOutcome];
					});
				}));
			}
		})));
	} catch (cause) {
		return cause;
	}
	return serialFailure ?? loaderFailure;
}
function materializeRedirect$1(router, lane, route, outcome, options, failed) {
	while (outcome[0] === REDIRECTED$1) {
		const redirect = outcome[1];
		const redirectOptions = redirect.options;
		try {
			if (redirectOptions.href || redirect.headers.has("Location")) {
				router.resolveRedirect(redirect);
				if (redirectOptions.reloadDocument) return outcome;
			}
			if (redirectOptions.reloadDocument ? options[3] : options[1] >= 20) return outcome;
			const location = router.buildLocation({
				...redirectOptions,
				_fromLocation: lane[0],
				_includeValidateSearch: true
			});
			const publicLocation = location.maskedLocation ?? location;
			if (publicLocation.external) {
				const resolved = redirect.clone();
				resolved.options = { ...redirectOptions };
				resolved.headers.set("Location", publicLocation.publicHref);
				router.resolveRedirect(resolved);
				return options[3] ? [REDIRECTED$1, resolved] : [
					REDIRECTED$1,
					resolved,
					publicLocation
				];
			}
			return [
				REDIRECTED$1,
				redirect,
				location
			];
		} catch (cause) {
			outcome = failed ? [ERROR$1, cause] : normalizeError$1(route, cause);
			failed = true;
		}
	}
	return outcome;
}
async function reduceLane(router, lane, tasks, controller, settlement, onReady) {
	const matches = lane[1];
	let failure = await settlement;
	let redirectLimitExceeded = false;
	const plannedBoundary = matches.findIndex((match) => match._notFound);
	const boundaryOf = (found) => found[1][0] === NOT_FOUND$1 ? getNotFoundBoundary$1(router, matches, found, controller.signal) : found[0];
	let readinessEnd = plannedBoundary < 0 ? matches.length : plannedBoundary;
	if ((failure?.[1][0] ?? 0) >= REDIRECTED$1) readinessEnd = 0;
	else if (failure) {
		readinessEnd = failure[2] ??= await boundaryOf(failure);
		for (const task of tasks) {
			if (task[0] >= readinessEnd) break;
			const outcome = await task[1];
			if (outcome[0] !== SUCCESS$1 && outcome[0] < REDIRECTED$1 && !("loaderData" in matches[task[0]])) {
				failure = [task[0], outcome];
				readinessEnd = failure[2] = await boundaryOf(failure);
				break;
			}
		}
	}
	for (const task of tasks) {
		if (task[0] >= readinessEnd) break;
		const chunkFailure = await task[2];
		if (!chunkFailure) continue;
		failure = chunkFailure;
		break;
	}
	if ((failure?.[1][0] ?? 0) >= REDIRECTED$1) {
		const outcome = failure[1];
		if (outcome[0] !== REDIRECTED$1 || outcome[1].options.reloadDocument || outcome[2]) {
			discardBackground(router, lane);
			return outcome;
		}
		redirectLimitExceeded = true;
		failure = [0, [ERROR$1, /* @__PURE__ */ new Error("Too many redirects")]];
	}
	const boundary = failure ? failure[2] ?? await boundaryOf(failure) : plannedBoundary;
	if (boundary >= 0) {
		const outcome = failure?.[1];
		const kind = outcome?.[0];
		const match = matches[boundary];
		const cause = outcome?.[1];
		const install = () => {
			if (outcome) {
				match._notFound = void 0;
				if (kind === ERROR$1) match.status = "error";
				else {
					cause.routeId = match.routeId;
					if (match.routeId === router.routeTree.id) {
						match.status = "success";
						match._notFound = true;
					} else match.status = "notFound";
				}
				match.error = cause;
				match.isFetching = false;
			}
		};
		install();
		if (!outcome) onReady?.();
		const route = getRoute$1(router, match);
		try {
			await waitFor$1(outcome ? Promise.resolve().then(() => loadRouteChunk(route, kind === ERROR$1 ? "errorComponent" : "notFoundComponent")) : Promise.all([loadRouteChunk(route), loadRouteChunk(route, "notFoundComponent")]), controller.signal);
		} catch (cause) {
			if (cause === controller.signal && controller.signal.aborted) {
				discardBackground(router, lane);
				return CANCELED_OUTCOME;
			}
		}
		if (!outcome) match.status = "success";
		else if (redirectLimitExceeded) {
			controller.abort();
			await Promise.all([
				...tasks.map((task) => task[1]),
				...tasks.map((task) => task[2]),
				...(lane[2] ?? []).map((task) => task[1])
			]);
			discardBackground(router, lane);
			transferMatchResources(router, matches);
			install();
		}
	}
	return lane;
}
async function projectLane$1(router, lane, signal, start = 0, end = lane[1].length) {
	const matches = lane[1];
	for (let index = start; index < end; index++) {
		const match = matches[index];
		const routeOptions = getRoute$1(router, match).options;
		if (routeOptions.head || routeOptions.scripts) try {
			const context = {
				ssr: router.options.ssr,
				matches,
				match,
				params: match.params,
				loaderData: match.loaderData
			};
			const [head, scripts] = await waitFor$1(Promise.all([routeOptions.head?.(context), routeOptions.scripts?.(context)]), signal);
			match.meta = head?.meta;
			match.links = head?.links;
			match.headScripts = head?.scripts;
			match.styles = head?.styles;
			match.scripts = scripts;
		} catch (cause) {
			if (cause === signal && signal.aborted) break;
			console.error(cause);
		}
		if (match.status !== "success" || match._notFound) break;
	}
	return lane;
}
async function executeClientLane(router, location, matches, options) {
	const matched = [location, matches];
	const signal = options[0].signal;
	let reduced;
	try {
		const presented = router.stores.matches.get();
		let plannedBoundary = matches.findIndex((match) => match._notFound);
		if (router.options.notFoundMode !== "root" && plannedBoundary >= 0) {
			const boundary = await getNotFoundBoundary$1(router, matches, void 0, signal, plannedBoundary);
			matches[plannedBoundary]._notFound = void 0;
			matches[boundary]._notFound = true;
			plannedBoundary = boundary;
		}
		let end = plannedBoundary < 0 ? matches.length : plannedBoundary + 1;
		let retainedEnd = 0;
		while (retainedEnd < end && retainedEnd !== plannedBoundary) {
			const match = matches[retainedEnd];
			const committed = options[2][retainedEnd];
			const visible = presented[retainedEnd];
			if (committed?.id !== match.id || committed.status !== "success" || match.preload || visible?.id !== match.id || visible.status !== "success") break;
			retainedEnd++;
			if (committed._notFound || visible._notFound) break;
		}
		const tasks = [];
		const start = options[6] ?? 0;
		let semanticParent = start ? Promise.resolve(matches[start - 1]) : void 0;
		const planSuccessfulLane = () => {
			for (let index = start; index < end; index++) {
				if (signal.aborted) break;
				semanticParent = createLoaderTask$1(router, matched, index, tasks, semanticParent, options, retainedEnd);
			}
		};
		const failure = await contextualize$1(router, matched, options, end, planSuccessfulLane, retainedEnd);
		if (failure) {
			options[4] = true;
			end = failure[0];
			if (failure[1][0] === NOT_FOUND$1) {
				const boundary = await getNotFoundBoundary$1(router, matches, failure, signal);
				failure[2] = boundary;
				end = Math.min(end, boundary + 1);
			} else if (failure[1][0] >= REDIRECTED$1) end = 0;
			planSuccessfulLane();
		}
		if (!signal.aborted && !options[3]) {
			const abort = [];
			for (const [id, flight] of router._flights ?? []) if (!flight[2]) {
				router._flights.delete(id);
				abort.push(flight[1]);
			}
			for (const controller of abort) controller.abort();
		}
		const reduction = reduceLane(router, matched, tasks, options[0], settleTasks(tasks, failure, matched[2]), options[7]);
		if (matched[2]?.length) matched[3] = settleTasks(matched[2], void 0, void 0, reduction.then((foreground) => isControl(foreground) ? 0 : _getRenderedMatches(matches).length, () => 0));
		reduced = await reduction;
	} catch (cause) {
		discardBackground(router, matched);
		if (cause === signal && signal.aborted) return CANCELED_OUTCOME;
		throw cause;
	}
	if (isControl(reduced)) return reduced;
	return projectLane$1(router, reduced, signal, options[6] === matches.length ? options[6] : 0);
}
/**
* Waits for `pendingMs`, then presents the complete lane. Rendering applies the
* selected boundary cutoff while retaining every match's structural state.
* A replacement load for the same match keeps the timer; choosing a different
* match resets it. `pendingMinMs` starts after the fallback renders.
*/
function offerPending(router, tx) {
	if (router._tx !== tx) return;
	const matches = tx[3];
	const presented = router.stores.matches.get();
	let session = router._pending;
	for (let index = 0; index < matches.length; index++) {
		const match = matches[index];
		const success = match.status === "success" && !match._notFound;
		const presentedPending = presented[index]?.id === match.id && presented[index]?.status === "pending";
		if (success && !presentedPending) continue;
		const route = getRoute$1(router, match);
		const delay = success || match.invalid ? 0 : route.options.pendingMs ?? router.options.defaultPendingMs;
		const component = route.options.pendingComponent ?? router.options.defaultPendingComponent;
		if (!component || typeof delay !== "number" || delay === Infinity) {
			if (session) {
				session[0] = tx;
				session[2] = 0;
				session[4] = true;
			}
			return;
		}
		const min = route.options.pendingMinMs ?? router.options.defaultPendingMinMs ?? 0;
		let tookOver = false;
		if (session?.[1] === match.id) {
			tookOver = session[0] !== tx;
			session[0] = tx;
		} else {
			clearTimeout(session?.[3]);
			router._pending = session = void 0;
		}
		if (!session) router._pending = session = [
			tx,
			match.id,
			presentedPending ? Date.now() + min : tx[4] + delay,
			void 0,
			presentedPending || void 0,
			component
		];
		if (session[4] && !tookOver && session[5] === component) return;
		session[5] = component;
		if (!session[4]) {
			clearTimeout(session[3]);
			const remaining = session[2] - Date.now();
			if (remaining > 0) {
				session[3] = setTimeout(() => offerPending(router, tx), remaining);
				return;
			}
			session[2] = 0;
		}
		const offered = matches.map((match) => ({
			...match,
			_flight: void 0
		}));
		offered[index].status = "pending";
		const ack = session[4] = router.startTransition(() => router.stores.setMatches(offered), offered).then((rendered) => {
			if (rendered && router._pending === session && session[4] === ack && !session[2]) session[2] = Date.now() + min;
			return rendered;
		});
		return;
	}
}
/**
* Cancels pending UI timing unless the current successor can take over the
* same boundary that remains painted.
*/
function finishPending(router, tx) {
	const session = router._pending;
	if (router._tx === tx || !router._tx?.[3].some((match) => match.id === session?.[1])) {
		clearTimeout(session?.[3]);
		router._pending = void 0;
	}
}
async function awaitPendingMinimum(router, tx) {
	const session = router._pending;
	if (!session) return;
	clearTimeout(session[3]);
	const remaining = session[2] - Date.now();
	if (!session[4] || remaining <= 0 || !_getRenderedMatches(tx[3]).some((match) => match.id === session[1])) return;
	let timer;
	try {
		await waitFor$1(new Promise((resolve) => {
			timer = setTimeout(resolve, remaining);
		}), tx[0].signal);
	} catch {}
	clearTimeout(timer);
}
function publishMatches(router, matches) {
	router._committed = matches;
	router.stores.setMatches(matches);
}
function commitMatches(router, tx, matches, resolvedPrefix) {
	const previous = router._committed;
	const previousEnd = router._lifecycleEnd;
	const previousCached = router._cache;
	for (const match of matches) {
		match.preload = false;
		if (resolvedPrefix) match._assetEnd = void 0;
	}
	const cut = _getRenderedMatches(matches).length;
	const cached = /* @__PURE__ */ new Map();
	if (!tx[6]) {
		const now = Date.now();
		const superseded = /* @__PURE__ */ new Set();
		for (let index = 0; index < matches.length; index++) {
			const match = matches[index];
			if (index < cut || match.status === "success") superseded.add(match.id);
		}
		for (const match of [...previous, ...previousCached.values()]) {
			if (match.status !== "success" || superseded.has(match.id)) continue;
			const route = getRoute$1(router, match);
			if (!route.options.loader || now - match.updatedAt >= (match.preload ? route.options.preloadGcTime ?? router.options.defaultPreloadGcTime ?? 3e5 : route.options.gcTime ?? router.options.defaultGcTime ?? 3e5)) continue;
			cached.set(match.id, previousCached.get(match.id) === match ? match : {
				...match,
				_flight: void 0,
				isFetching: false,
				context: {}
			});
		}
	}
	tx[3] = [];
	router._cache = cached;
	const nextEnd = router._lifecycleEnd = lifecycleEnd(matches);
	publishMatches(router, matches);
	transferMatchResources(router, [...previousCached.values(), ...previous].filter((match) => match._flight && cached.get(match.id) !== match), matches);
	{
		const handoff = tx[6]?.[0];
		if (handoff && router._handoff === handoff) handoff[1]();
	}
	runRouteLifecycle(router, previous, matches, previousEnd, nextEnd, tx);
}
/**
* Resolve once the router has settled on a transaction other than `owner`.
* Each transaction's completion follows its current successor, so all waiters
* share the same chain instead of polling every successor independently.
*/
async function awaitCurrent(router, owner) {
	let current = router._tx;
	while (current && current !== owner) {
		owner = current;
		await current[5];
		current = router._tx;
	}
}
function followRedirect(router, tx, outcome) {
	const options = outcome[1].options;
	const location = outcome[2];
	if (!location) return router.navigate({
		...options,
		replace: true,
		ignoreBlocker: true
	});
	if (options.reloadDocument) return router.navigate({
		href: (location.maskedLocation ?? location).publicHref,
		reloadDocument: true,
		replace: true,
		ignoreBlocker: true
	});
	location._redirects = tx[1] + 1;
	router._pendingLocation = location;
	const committed = router.commitLocation({
		...location,
		viewTransition: options.viewTransition,
		replace: true,
		resetScroll: options.resetScroll,
		hashScrollIntoView: options.hashScrollIntoView,
		ignoreBlocker: true
	});
	queueMicrotask(() => {
		if (router._pendingLocation === location) router._pendingLocation = void 0;
	});
	return committed;
}
async function runBackground(router, tx, base, tasks, settlement) {
	const next = base.map((match) => ({ ...match }));
	acquireMatchResources(next);
	for (const task of tasks) {
		releaseFlight(router, next[task[0]]);
		next[task[0]] = task[3];
	}
	const lane = [tx[2], next];
	let reduced;
	try {
		reduced = await reduceLane(router, lane, tasks, tx[0], settlement);
	} catch (cause) {
		transferMatchResources(router, next);
		throw cause;
	}
	if (isControl(reduced)) {
		transferMatchResources(router, next);
		if (reduced[0] === REDIRECTED$1 && router._tx === tx && router._committed === base) await followRedirect(router, tx, reduced);
		return;
	}
	await projectLane$1(router, reduced, tx[0].signal);
	if (router._tx !== tx || router._committed !== base) {
		transferMatchResources(router, next);
		return;
	}
	for (const match of next) {
		const cached = router._cache.get(match.id);
		if (cached?._flight && cached._flight === match._flight) {
			router._cache.delete(match.id);
			releaseFlight(router, cached);
		}
	}
	publishMatches(router, next);
	transferMatchResources(router, base, next);
}
async function runClientTransaction(router, tx, forceStaleReload, onReady, sync, resolvedPrefix) {
	const result = await executeClientLane(router, tx[2], tx[3], [
		tx[0],
		tx[1],
		router._committed,
		void 0,
		sync,
		forceStaleReload,
		resolvedPrefix,
		onReady
	]);
	if (isControl(result)) {
		const follow = result[0] === REDIRECTED$1 && router._tx === tx;
		if (!follow || result[1].options.reloadDocument) finishPending(router, tx);
		transferMatchResources(router, tx[3]);
		tx[3] = [];
		if (!follow) return;
		if (router._tx !== tx) {
			finishPending(router, tx);
			return;
		}
		if (tx[6]) router._refreshNextLoad = true;
		await followRedirect(router, tx, result);
		return;
	}
	const matches = result[1];
	if (router._tx === tx) await awaitPendingMinimum(router, tx);
	if (router._tx !== tx) {
		finishPending(router, tx);
		transferMatchResources(router, matches);
		discardBackground(router, result);
		return;
	}
	const toLocation = tx[2];
	const changeInfo = getLocationChangeInfo(toLocation, router.stores.resolvedLocation.get());
	const background = result[2];
	await router.startViewTransition(async () => {
		if (router._tx === tx) await awaitPendingMinimum(router, tx);
		if (router._tx !== tx) {
			finishPending(router, tx);
			transferMatchResources(router, matches);
			discardBackground(router, result);
			return;
		}
		const commit = () => {
			finishPending(router, tx);
			commitMatches(router, tx, matches, resolvedPrefix);
			if (router._tx !== tx) return;
			router.emit({
				type: "onLoad",
				...changeInfo
			});
			if (router._tx === tx) router.emit({
				type: "onBeforeRouteMount",
				...changeInfo
			});
		};
		const rendered = await router.startTransition(commit, matches);
		if (tx[6]) tx[6] = void 0;
		if (router._tx !== tx) {
			discardBackground(router, result);
			return;
		}
		if (background?.length) runBackground(router, tx, matches, background, result[3]).catch(console.error);
		router.batch(() => {
			router.stores.resolvedLocation.set(toLocation);
			router.stores.status.set("idle");
			if (router._tx === tx) router.emit({
				type: "onResolved",
				...changeInfo
			});
			if (rendered && router._tx === tx) router.emit({
				type: "onRendered",
				...changeInfo
			});
		});
		if (router._tx !== tx) return;
		router._commitPromise?.resolve();
		router._commitPromise = void 0;
	});
}
async function loadClientRoute(router, opts) {
	let rematerialize = false;
	rematerialize = !!router._refreshNextLoad || !!router._tx?.[6];
	const previousOwner = router._tx;
	const resolvedLocation = router.stores.resolvedLocation.get();
	const previousLocation = resolvedLocation ?? router.stores.location.get();
	const location = router.latestLocation;
	const pendingLocation = router._pendingLocation;
	const redirects = pendingLocation?.href === location.href ? pendingLocation._redirects ?? 0 : 0;
	const handoff = router._handoff;
	const hydrationController = rematerialize ? void 0 : handoff?.[0]();
	const preflight = new AbortController();
	const previousPreflight = router._preflight;
	router._preflight = preflight;
	if (!rematerialize && !hydrationController) handoff?.[1]();
	previousPreflight?.abort();
	if (!preflight.signal.aborted) {
		const changeInfo = getLocationChangeInfo(location, resolvedLocation);
		router.emit({
			type: "onBeforeNavigate",
			...changeInfo
		});
		if (!preflight.signal.aborted) router.emit({
			type: "onBeforeLoad",
			...changeInfo
		});
	}
	if (preflight.signal.aborted) {
		await awaitCurrent(router, previousOwner);
		return;
	}
	const sameHref = previousLocation.href === location.href;
	let controller = preflight;
	const matches = rematerialize ? router.matchRoutes(location, {
		_controller: preflight,
		_rematerialize: true
	}) : router.matchRoutes(location, { _controller: preflight });
	acquireMatchResources(matches);
	const resolvedPrefix = hydrationController ? handoff[1](matches) : void 0;
	if (resolvedPrefix) controller = hydrationController;
	else hydrationController?.abort();
	if (preflight.signal.aborted) {
		transferMatchResources(router, matches);
		await awaitCurrent(router, previousOwner);
		return;
	}
	router._preflight = void 0;
	let settle;
	const run = () => runClientTransaction(router, tx, sameHref, () => offerPending(router, tx), opts?.sync, resolvedPrefix);
	const done = opts?.sync ? new Promise((resolve) => settle = resolve) : Promise.resolve().then(run);
	const tx = [
		controller,
		redirects,
		location,
		matches,
		Date.now(),
		done.then(() => awaitCurrent(router, tx))
	];
	if (rematerialize) {
		tx[6] = [handoff];
		router._refreshNextLoad = void 0;
	}
	router._tx = tx;
	if (previousOwner) {
		for (const match of router.stores.matches.get()) {
			if (router._tx !== tx) break;
			if (match.isFetching) setFetching(router, match, false);
		}
		previousOwner[0].abort();
		transferMatchResources(router, previousOwner[3], tx[3], true);
	}
	if (router._tx !== tx) {
		transferMatchResources(router, tx[3]);
		tx[3] = [];
		settle?.();
		await awaitCurrent(router, tx);
		return;
	}
	router.batch(() => {
		router.stores.status.set("pending");
		router.stores.location.set(location);
	});
	if (resolvedPrefix || !router._committed.length && matches[0]?.status !== "success" && !matches.some((match) => match._notFound)) offerPending(router, tx);
	settle?.(run());
	await tx[5];
}
async function refreshClientRoute(router) {
	const pending = router._tx;
	if (pending && !pending[6] && router.stores.status.get() === "pending") {
		await pending[5];
		if (router._tx !== pending) await awaitCurrent(router, pending);
	}
	router._flights?.clear();
	router.clearCache();
	router._refreshNextLoad = true;
	await loadClientRoute(router, { sync: true });
}
async function preloadClientRoute(router, opts) {
	if (router._refreshNextLoad || router._tx?.[6]) return;
	let location = router.buildLocation(opts);
	for (let redirects = 0;; redirects++) {
		const base = router._committed;
		const controller = new AbortController();
		let matches;
		let active;
		let result;
		try {
			try {
				matches = router.matchRoutes(location, { _controller: controller });
				acquireMatchResources(matches);
				active = (router._preloads ??= /* @__PURE__ */ new Map()).set(controller, matches);
				result = await executeClientLane(router, location, matches, [
					controller,
					redirects,
					base,
					true
				]);
			} finally {
				if (active) {
					active = active.delete(controller);
					transferMatchResources(router, matches);
				}
				controller.abort();
			}
			if (!isControl(result)) return result[1];
			if (!active || result.length < 3 || router._refreshNextLoad || router._tx?.[6]) return;
			location = result[2];
		} catch (cause) {
			if (!isNotFound(cause)) console.error(cause);
			return;
		}
	}
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/await-signal.js
function observeLate(callback, value) {
	if (!callback) return;
	try {
		const result = callback(value);
		if (result !== void 0) Promise.resolve(result).catch(() => {});
	} catch {}
}
/**
* Await `value` unless `signal` aborts first. A result that settles after the
* abort is passed to `onLate` / `onLateError` instead.
*
* One abort listener per wait: SSR requests nest at most a few waits on one
* signal, so pooling them was measurably slower than this.
*/
function waitForReason(value, signal, onLate, onLateError) {
	const promise = Promise.resolve(value);
	if (signal.aborted) {
		promise.then((result) => observeLate(onLate, result), (error) => observeLate(onLateError, error));
		return Promise.reject(signal.reason);
	}
	return new Promise((resolve, reject) => {
		const abort = () => reject(signal.reason);
		signal.addEventListener("abort", abort, { once: true });
		promise.then((result) => {
			signal.removeEventListener("abort", abort);
			if (signal.aborted) observeLate(onLate, result);
			else resolve(result);
		}, (error) => {
			signal.removeEventListener("abort", abort);
			if (signal.aborted) observeLate(onLateError, error);
			else reject(error);
		});
	});
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/load-server.js
var SUCCESS = 0;
var ERROR = 1;
var NOT_FOUND = 2;
var REDIRECTED = 3;
var SKIPPED = 4;
var MATCH_SETTLED_ABORT_REASON = Object.freeze({
	name: "AbortError",
	message: "TanStack Router aborted this server match because it settled."
});
var REDIRECT_ABORT_REASON = Object.freeze({
	name: "AbortError",
	message: "TanStack Router aborted this server match because of a redirect."
});
function getRoute(router, match) {
	return router.routesById[match.routeId];
}
function normalize(value, rejected) {
	if (isRedirect(value)) return [REDIRECTED, value];
	if (isNotFound(value)) return [NOT_FOUND, value];
	if (rejected && typeof value?.then === "function") value = new Error("A Promise was thrown", { cause: value });
	return rejected ? [ERROR, value] : [SUCCESS, value];
}
function normalizeError(router, lane, route, cause, signal, notify = true) {
	signal?.throwIfAborted();
	let outcome = normalize(cause, true);
	if (outcome[0] !== ERROR) return materializeRedirect(router, lane, route, outcome, signal, notify);
	try {
		route.options.onError?.(outcome[1]);
	} catch (onErrorCause) {
		outcome = normalize(onErrorCause, true);
	}
	signal?.throwIfAborted();
	return materializeRedirect(router, lane, route, outcome, signal, notify);
}
function materializeRedirect(router, lane, route, outcome, signal, notify = true) {
	if (outcome[0] !== REDIRECTED) return outcome;
	signal?.throwIfAborted();
	try {
		outcome[1].options._fromLocation = lane.location;
		router.resolveRedirect(outcome[1]);
		signal?.throwIfAborted();
		return outcome;
	} catch (cause) {
		signal?.throwIfAborted();
		return notify ? normalizeError(router, lane, route, cause, signal, false) : [ERROR, cause];
	}
}
function maybe(value, cause) {
	if (cause !== void 0) return {
		status: "error",
		error: cause
	};
	return {
		status: "success",
		value
	};
}
function navigateFrom(router, location) {
	return (options) => router.navigate({
		...options,
		_fromLocation: location
	});
}
function waitFor(value, signal) {
	return signal ? waitForReason(value, signal) : value;
}
function resolveSsr(router, lane, index) {
	const match = lane.matches[index];
	const route = getRoute(router, match);
	const parentSsr = lane.matches[index - 1]?.ssr;
	if (router.isShell()) return route.id === rootRouteId;
	if (parentSsr === false) return false;
	const inherit = (value) => {
		return value === true && parentSsr === "data-only" ? "data-only" : value;
	};
	const defaultSsr = router.options.defaultSsr ?? true;
	const inheritedDefault = inherit(defaultSsr);
	match.ssr = inheritedDefault;
	const option = route.options.ssr;
	if (option === void 0) return inheritedDefault;
	if (typeof option !== "function") return inherit(option);
	const context = {
		search: maybe(match.search, match.searchError),
		params: maybe(match.params, match.paramsError),
		location: lane.location,
		matches: lane.matches.map((candidate) => ({
			index: candidate.index,
			pathname: candidate.pathname,
			fullPath: candidate.fullPath,
			staticData: candidate.staticData,
			id: candidate.id,
			routeId: candidate.routeId,
			search: maybe(candidate.search, candidate.searchError),
			params: maybe(candidate.params, candidate.paramsError),
			ssr: candidate.ssr
		}))
	};
	try {
		return Promise.resolve(option(context)).then((value) => inherit(value ?? defaultSsr));
	} catch (cause) {
		return Promise.reject(cause);
	}
}
function stampNotFound(match, outcome) {
	if (outcome[0] === NOT_FOUND && !outcome[1].routeId) outcome[1].routeId = match.routeId;
	return outcome;
}
async function contextualize(router, lane, signal) {
	const globalBoundary = lane.matches.findIndex((match) => match._notFound);
	let end = globalBoundary < 0 ? lane.matches.length : globalBoundary + 1;
	let failure;
	let parentContext = { ...router.options.context ?? {} };
	for (let index = 0; index < end; index++) {
		const match = lane.matches[index];
		const route = getRoute(router, match);
		try {
			const ssr = resolveSsr(router, lane, index);
			match.ssr = ssr instanceof Promise ? await ssr : ssr;
		} catch (cause) {
			signal?.throwIfAborted();
			failure = [index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))];
			end = index;
		}
		signal?.throwIfAborted();
		if (failure?.[1][0] === REDIRECTED) break;
		match.__beforeLoadContext = void 0;
		let context = parentContext;
		try {
			let routeContext;
			if (route.options.context) {
				const routeContextOptions = {
					deps: match.loaderDeps,
					params: match.params,
					context: parentContext,
					location: lane.location,
					navigate: navigateFrom(router, lane.location),
					buildLocation: router.buildLocation,
					cause: match.cause,
					abortController: match.abortController,
					preload: false,
					matches: lane.matches,
					routeId: route.id
				};
				routeContext = route.options.context(routeContextOptions) ?? void 0;
			}
			context = {
				...parentContext,
				...routeContext
			};
			match.context = context;
		} catch (cause) {
			signal?.throwIfAborted();
			if (!failure) failure = [index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))];
			end = index;
			break;
		}
		signal?.throwIfAborted();
		if (failure) break;
		const validationError = match.paramsError ?? match.searchError;
		if (validationError !== void 0) {
			failure = [index, stampNotFound(match, normalizeError(router, lane, route, validationError, signal))];
			end = index;
			break;
		}
		signal?.throwIfAborted();
		if (match.ssr === false || !route.options.beforeLoad) {
			parentContext = context;
			continue;
		}
		const abortController = match.abortController;
		const options = {
			search: match.search,
			abortController,
			params: match.params,
			preload: false,
			context,
			location: lane.location,
			navigate: navigateFrom(router, lane.location),
			buildLocation: router.buildLocation,
			cause: match.cause,
			matches: lane.matches,
			routeId: route.id,
			...router.options.additionalContext
		};
		try {
			const beforeLoadContext = await route.options.beforeLoad(options);
			signal?.throwIfAborted();
			const outcome = stampNotFound(match, materializeRedirect(router, lane, route, normalize(beforeLoadContext, false), signal));
			if (outcome[0] !== SUCCESS) {
				failure = [index, outcome];
				end = index;
				break;
			}
			match.__beforeLoadContext = beforeLoadContext;
			match.context = {
				...context,
				...beforeLoadContext
			};
			parentContext = match.context;
		} catch (cause) {
			signal?.throwIfAborted();
			failure = [index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))];
			end = index;
			break;
		}
	}
	return {
		location: lane.location,
		matches: lane.matches,
		end,
		failure
	};
}
function getLoaderContext(router, lane, match, route, index, tasks) {
	return {
		params: match.params,
		deps: match.loaderDeps,
		preload: false,
		parentMatchPromise: tasks[index - 1]?.match,
		abortController: match.abortController,
		context: match.context,
		location: lane.location,
		navigate: navigateFrom(router, lane.location),
		cause: match.cause,
		route,
		...router.options.additionalContext
	};
}
function createLoaderTask(router, lane, index, tasks, signal) {
	const match = lane.matches[index];
	const route = getRoute(router, match);
	let outcome;
	if (match.ssr === false) outcome = Promise.resolve([SKIPPED]);
	else {
		const routeLoader = route.options.loader;
		const loader = typeof routeLoader === "function" ? routeLoader : routeLoader?.handler;
		if (!loader) outcome = Promise.resolve([SUCCESS, void 0]);
		else outcome = Promise.resolve().then(() => loader(getLoaderContext(router, lane, match, route, index, tasks))).then((result) => normalize(result, false), (cause) => normalize(cause, true)).then((result) => {
			if (signal?.aborted || match.abortController.signal.reason === REDIRECT_ABORT_REASON) return [SKIPPED];
			if (result[0] === ERROR) result = normalizeError(router, lane, route, result[1], signal);
			else result = materializeRedirect(router, lane, route, result, signal);
			return stampNotFound(match, result);
		});
	}
	const parentMatch = outcome.then((result) => {
		const snapshot = { ...match };
		if (result[0] === SUCCESS) {
			snapshot.loaderData = result[1];
			snapshot.status = "success";
			snapshot.error = void 0;
			snapshot.invalid = false;
			snapshot.isFetching = false;
		} else if (result[0] === ERROR) {
			snapshot.status = "error";
			snapshot.error = result[1];
		} else if (result[0] === NOT_FOUND) {
			snapshot.status = "notFound";
			snapshot.error = result[1];
		}
		return snapshot;
	});
	return {
		index,
		outcome,
		match: parentMatch
	};
}
async function getNotFoundBoundary(router, matches, indexed, signal, fallback = 0) {
	const cause = indexed?.[1][1];
	let index = cause?.routeId ? matches.findIndex((match) => match.routeId === cause.routeId) : indexed?.[0] ?? matches.length - 1;
	if (index < 0) index = 0;
	for (let candidate = index; candidate >= 0; candidate--) {
		const route = getRoute(router, matches[candidate]);
		try {
			const loading = loadRouteChunk(route, false);
			if (loading) await loading;
		} catch {
			signal?.throwIfAborted();
		}
		signal?.throwIfAborted();
		if (route.options.notFoundComponent) return candidate;
	}
	return cause?.routeId ? index : fallback;
}
function abortMatches(matches, start = 0, reason = MATCH_SETTLED_ABORT_REASON) {
	for (let index = start; index < matches.length; index++) matches[index].abortController.abort(reason);
}
async function applyFailure(router, lane, indexed, signal) {
	if (!indexed) {
		const boundary = lane.matches.findIndex((match) => match._notFound);
		if (boundary >= 0) {
			abortMatches(lane.matches, boundary + 1);
			return {
				status: 404,
				boundary,
				kind: NOT_FOUND
			};
		}
		return { status: 200 };
	}
	const [index, outcome] = indexed;
	if (outcome[0] === ERROR) {
		const match = lane.matches[index];
		match._notFound = void 0;
		match.status = "error";
		match.error = outcome[1];
		match.isFetching = false;
		abortMatches(lane.matches, index + 1);
		return {
			status: 500,
			boundary: index,
			kind: ERROR
		};
	}
	const boundary = indexed[2] ?? await getNotFoundBoundary(router, lane.matches, indexed, signal);
	const match = lane.matches[boundary];
	const cause = outcome[1];
	cause.routeId = match.routeId;
	match._notFound = void 0;
	if (match.routeId === router.routeTree.id) {
		match.status = "success";
		match._notFound = true;
		match.error = cause;
	} else {
		match.status = "notFound";
		match.error = cause;
	}
	match.isFetching = false;
	abortMatches(lane.matches, boundary + 1);
	return {
		status: 404,
		boundary,
		kind: NOT_FOUND
	};
}
async function loadNormalChunks(router, lane, end, signal) {
	const chunks = [];
	for (let index = 0; index < lane.matches.length; index++) {
		const match = lane.matches[index];
		if (index >= end || match.ssr !== true || match.status !== "success") continue;
		const route = getRoute(router, match);
		try {
			const loading = loadRouteChunk(route);
			if (loading) {
				const chunk = loading.then(() => {
					signal?.throwIfAborted();
				}, (cause) => {
					signal?.throwIfAborted();
					return [index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))];
				});
				chunk.catch(() => {});
				chunks.push(chunk);
			}
		} catch (cause) {
			signal?.throwIfAborted();
			chunks.push([index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))]);
		}
	}
	for (const chunk of chunks) {
		const indexed = Array.isArray(chunk) ? chunk : await chunk;
		if (indexed) return indexed;
	}
}
async function projectLane(router, lane, signal) {
	for (const match of lane.matches) {
		const routeOptions = getRoute(router, match).options;
		if (routeOptions.head || routeOptions.scripts || routeOptions.headers) {
			const context = {
				ssr: router.options.ssr,
				matches: lane.matches,
				match,
				params: match.params,
				loaderData: match.loaderData
			};
			try {
				const [head, scripts, headers] = await Promise.all([
					routeOptions.head?.(context),
					routeOptions.scripts?.(context),
					routeOptions.headers?.(context)
				]);
				signal?.throwIfAborted();
				match.meta = head?.meta;
				match.links = head?.links;
				match.headScripts = head?.scripts;
				match.styles = head?.styles;
				match.scripts = scripts;
				match.headers = headers;
			} catch (cause) {
				signal?.throwIfAborted();
				console.error(cause);
			}
		}
		if (match.ssr === false || match.status !== "success" || match._notFound) break;
	}
}
async function executeServerLane(router, location, matchedMatches, signal) {
	const matched = {
		location,
		matches: matchedMatches.map((match) => ({
			...match,
			__beforeLoadContext: void 0,
			context: {},
			isFetching: false,
			abortController: new AbortController()
		}))
	};
	const abortLane = () => abortMatches(matched.matches, 0, signal?.reason ?? MATCH_SETTLED_ABORT_REASON);
	if (signal?.aborted) {
		abortLane();
		signal.throwIfAborted();
	}
	signal?.addEventListener("abort", abortLane, { once: true });
	try {
		const plannedGlobalBoundary = matched.matches.findIndex((match) => match._notFound);
		if (router.options.notFoundMode !== "root" && plannedGlobalBoundary >= 0) {
			const boundary = await getNotFoundBoundary(router, matched.matches, void 0, signal, plannedGlobalBoundary);
			if (boundary !== plannedGlobalBoundary) {
				matched.matches[plannedGlobalBoundary]._notFound = void 0;
				matched.matches[boundary]._notFound = true;
			}
		}
		const lane = await contextualize(router, matched, signal);
		signal?.throwIfAborted();
		let loaderEnd = lane.end;
		if (lane.failure?.[1][0] === REDIRECTED) loaderEnd = 0;
		else if (lane.failure?.[1][0] === NOT_FOUND) {
			lane.failure[2] = await getNotFoundBoundary(router, lane.matches, lane.failure, signal);
			loaderEnd = Math.min(loaderEnd, lane.failure[2] + 1);
		}
		const tasks = [];
		for (let index = 0; index < loaderEnd; index++) {
			const task = createLoaderTask(router, lane, index, tasks, signal);
			tasks.push(task);
		}
		let loaderFailure;
		let control = lane.failure?.[1][0] === REDIRECTED ? lane.failure : void 0;
		try {
			await Promise.all(tasks.map((task) => task.outcome.then((loadedOutcome) => {
				const match = lane.matches[task.index];
				const outcome = loadedOutcome;
				if (outcome[0] === SUCCESS) {
					match.loaderData = outcome[1];
					match.status = "success";
					match.error = void 0;
					match.invalid = false;
					match.isFetching = false;
					match.updatedAt = Date.now();
				} else if (outcome[0] === REDIRECTED) {
					control = [task.index, outcome];
					throw control;
				} else {
					if (match.ssr !== false) {
						match.status = "success";
						match.error = void 0;
						match.invalid = true;
						match.isFetching = false;
					}
					if (!loaderFailure && outcome[0] !== SKIPPED) loaderFailure = [task.index, outcome];
				}
			})));
		} catch (cause) {
			if (!Array.isArray(cause)) throw cause;
			control = cause;
		}
		signal?.throwIfAborted();
		if (control?.[1][0] === REDIRECTED) {
			abortMatches(lane.matches, 0, REDIRECT_ABORT_REASON);
			return {
				type: "redirect",
				redirect: control[1][1]
			};
		}
		let failure = lane.failure ?? loaderFailure;
		const plannedBoundary = lane.matches.findIndex((match) => match._notFound);
		let readinessEnd;
		if (failure) {
			const outcomeEnd = failure[2] ??= failure[1][0] === NOT_FOUND ? await getNotFoundBoundary(router, lane.matches, failure, signal) : failure[0];
			for (const task of tasks) {
				if (task.index >= outcomeEnd) break;
				const outcome = await task.outcome;
				if (outcome[0] !== SUCCESS && outcome[0] < REDIRECTED && !("loaderData" in lane.matches[task.index])) {
					failure = [task.index, outcome];
					failure[2] = outcome[0] === NOT_FOUND ? await getNotFoundBoundary(router, lane.matches, failure, signal) : task.index;
					break;
				}
			}
			readinessEnd = failure[2];
		} else readinessEnd = plannedBoundary < 0 ? lane.matches.length : plannedBoundary;
		const requiredFailure = await loadNormalChunks(router, lane, readinessEnd, signal);
		signal?.throwIfAborted();
		if (requiredFailure) {
			if (requiredFailure[1][0] === REDIRECTED) {
				abortMatches(lane.matches, 0, REDIRECT_ABORT_REASON);
				return {
					type: "redirect",
					redirect: requiredFailure[1][1]
				};
			}
			failure = requiredFailure;
		}
		const terminal = await applyFailure(router, lane, failure, signal);
		if (terminal.boundary !== void 0) {
			const match = lane.matches[terminal.boundary];
			if (match.ssr === true) {
				const route = getRoute(router, match);
				try {
					if (terminal.kind === ERROR) await loadRouteChunk(route, "errorComponent");
					else if (match._notFound) await Promise.all([loadRouteChunk(route), loadRouteChunk(route, "notFoundComponent")]);
					else await loadRouteChunk(route, "notFoundComponent");
				} catch {}
				signal?.throwIfAborted();
			}
		}
		signal?.throwIfAborted();
		await projectLane(router, {
			location: lane.location,
			matches: lane.matches
		}, signal);
		signal?.throwIfAborted();
		router.serverSsr?.onCleanup((settled) => {
			if (!settled) abortLane();
		});
		return {
			type: "render",
			status: terminal.status,
			matches: lane.matches
		};
	} finally {
		signal?.removeEventListener("abort", abortLane);
	}
}
async function loadServerRoute(router, opts) {
	if (!opts?._skipLocationUpdate) router.updateLatestLocation();
	const next = router.latestLocation;
	const previous = router._committed;
	const previousEnd = router._lifecycleEnd;
	let result;
	try {
		const canonical = router.buildLocation({
			to: next.pathname,
			search: true,
			params: true,
			hash: true,
			state: true,
			_includeValidateSearch: true
		});
		if (next.publicHref !== canonical.publicHref) throw redirect({ href: canonical.publicHref || "/" });
		const changeInfo = getLocationChangeInfo(next, router.stores.resolvedLocation.get());
		router.emit({
			type: "onBeforeNavigate",
			...changeInfo
		});
		router.emit({
			type: "onBeforeLoad",
			...changeInfo
		});
		opts?._signal?.throwIfAborted();
		result = await waitFor(executeServerLane(router, next, router.matchRoutes(next), opts?._signal), opts?._signal);
		opts?._signal?.throwIfAborted();
	} catch (cause) {
		opts?._signal?.throwIfAborted();
		if (!isRedirect(cause)) throw cause;
		cause.options._fromLocation = next;
		result = {
			type: "redirect",
			redirect: router.resolveRedirect(cause)
		};
	}
	router._serverResult = result;
	let nextEnd = 0;
	router.batch(() => {
		router.stores.location.set(next);
		router.stores.status.set("idle");
		if (result.type === "render") {
			router._committed = result.matches;
			nextEnd = router._lifecycleEnd = lifecycleEnd(result.matches);
			router.stores.setMatches(result.matches);
			router.stores.resolvedLocation.set(next);
		}
	});
	if (result.type === "render") runRouteLifecycle(router, previous, result.matches, previousEnd, nextEnd);
	router._commitPromise?.resolve();
	router._commitPromise = void 0;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/utils.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* React.use if available (React 19+), undefined otherwise.
* Use dynamic lookup to avoid Webpack compilation errors with React 18.
*/
var reactUse = import_react.use;
var useLayoutEffect = typeof window === "undefined" ? import_react.useEffect : import_react.useLayoutEffect;
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/defer.js
/**
* Well-known symbol used by {@link defer} to tag a promise with
* its deferred state. Consumers can read `promise[TSR_DEFERRED_PROMISE]`
* to access `status`, `data`, or `error`.
*/
var TSR_DEFERRED_PROMISE = Symbol.for("TSR_DEFERRED_PROMISE");
/**
* Wrap a promise with a deferred state for use with `<Await>` and `useAwaited`.
*
* The returned promise is augmented with internal state (status/data/error)
* so UI can read progress or suspend until it settles.
*
* @param _promise The promise to wrap.
* @param options Optional config. Provide `serializeError` to customize how
* errors are serialized for transfer.
* @returns The same promise with attached deferred metadata.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/deferFunction
*/
function defer(_promise, options) {
	const promise = _promise;
	if (promise[TSR_DEFERRED_PROMISE]) return promise;
	promise[TSR_DEFERRED_PROMISE] = { status: "pending" };
	promise.then((data) => {
		promise[TSR_DEFERRED_PROMISE].status = "success";
		promise[TSR_DEFERRED_PROMISE].data = data;
	}).catch((error) => {
		promise[TSR_DEFERRED_PROMISE].status = "error";
		promise[TSR_DEFERRED_PROMISE].error = {
			data: (options?.serializeError ?? defaultSerializeError)(error),
			__isServerError: true
		};
	});
	return promise;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/link.js
var preloadWarning = "Error preloading route! ☝️";
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/manifest.js
var DEV_STYLES_ATTR = "data-tanstack-router-dev-styles";
function getAssetCrossOrigin(assetCrossOrigin, kind) {
	if (!assetCrossOrigin) return;
	if (typeof assetCrossOrigin === "string") return assetCrossOrigin;
	return assetCrossOrigin[kind];
}
function getManifestScriptFormat(manifest) {
	return manifest?.scriptFormat ?? "module";
}
function getScriptPreloadAttrs(manifest, link, assetCrossOrigin) {
	const preloadLink = resolveManifestAssetLink(link);
	const crossOrigin = getAssetCrossOrigin(assetCrossOrigin, "script") ?? preloadLink.crossOrigin;
	return {
		...getManifestScriptFormat(manifest) === "iife" ? {
			rel: "preload",
			as: "script"
		} : { rel: "modulepreload" },
		href: preloadLink.href,
		fetchPriority: "low",
		...crossOrigin ? { crossOrigin } : {}
	};
}
function resolveManifestAssetLink(link) {
	if (typeof link === "string") return {
		href: link,
		crossOrigin: void 0
	};
	return link;
}
function appendUniqueUserTags(target, tags) {
	if (tags.length === 0) return;
	if (tags.length === 1) {
		target.push(tags[0]);
		return;
	}
	const seen = /* @__PURE__ */ new Set();
	for (const tag of tags) {
		const key = JSON.stringify(tag);
		if (seen.has(key)) continue;
		seen.add(key);
		target.push(tag);
	}
}
function resolveManifestCssLink(link) {
	if (typeof link === "string") return {
		href: link,
		crossOrigin: void 0
	};
	return link;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/Matches.js
/**
* Narrows matches based on a path
* @experimental
*/
var isMatch = (match, path) => {
	const parts = path.split(".");
	let part;
	let i = 0;
	let value = match;
	while ((part = parts[i++]) != null && value != null) value = value[part];
	return value != null;
};
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/ssr/bodyScripts.js
function getSsrBodyScriptParts(matches, manifest, nonce, routeScriptAttrs) {
	const assetMatches = _getAssetMatches(matches);
	const routeScripts = [];
	const manifestScripts = [];
	for (const match of assetMatches) for (const script of Array.isArray(match.scripts) ? match.scripts : []) {
		if (!script) continue;
		const { children, ...attrs } = script;
		routeScripts.push({
			tag: "script",
			attrs: {
				...attrs,
				...routeScriptAttrs,
				nonce
			},
			children
		});
	}
	if (manifest) for (const match of assetMatches) for (const asset of manifest.routes[match.routeId]?.scripts ?? []) manifestScripts.push({
		tag: "script",
		attrs: {
			...asset.attrs,
			nonce
		},
		children: asset.children
	});
	return [routeScripts, manifestScripts];
}
function composeSsrBodyScripts([routeScripts, manifestScripts], initialHydrationScripts) {
	if (!initialHydrationScripts) return [...routeScripts, ...manifestScripts];
	return [
		...initialHydrationScripts.before,
		...routeScripts,
		...manifestScripts,
		initialHydrationScripts.boundary
	];
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/route.js
var BaseRoute = class {
	get to() {
		return this._to;
	}
	get id() {
		return this._id;
	}
	get path() {
		return this._path;
	}
	get fullPath() {
		return this._fullPath;
	}
	constructor(options) {
		this.init = (originalIndex) => {
			this.originalIndex = originalIndex;
			this._branch = void 0;
			const options = this.options;
			const isRoot = !options?.path && !options?.id;
			this.parentRoute = this.options.getParentRoute?.();
			if (isRoot) this._path = rootRouteId;
			else if (!this.parentRoute) throw new Error(`Invariant failed: Child Route instances must pass a 'getParentRoute: () => ParentRoute' option that returns a Route instance.`);
			let path = isRoot ? rootRouteId : options?.path;
			if (path && path !== "/") path = trimPathLeft(path);
			const customId = options?.id || path;
			const id = isRoot ? rootRouteId : cleanPath((this.parentRoute.id === "__root__" ? "" : this.parentRoute.id) + "/" + (customId ?? ""));
			if (path === "__root__") path = "/";
			const fullPath = id === "__root__" ? "/" : path === void 0 ? this.parentRoute.fullPath : cleanPath(this.parentRoute.fullPath + "/" + path);
			this._path = path;
			this._id = id;
			this._fullPath = fullPath;
			this._to = trimPathRight(fullPath);
		};
		this.addChildren = (children) => {
			return this._addFileChildren(children);
		};
		this._addFileChildren = (children) => {
			if (Array.isArray(children)) this.children = children;
			if (typeof children === "object" && children !== null) this.children = Object.values(children);
			return this;
		};
		this._addFileTypes = () => {
			return this;
		};
		this.updateLoader = (options) => {
			Object.assign(this.options, options);
			return this;
		};
		this.update = (options) => {
			Object.assign(this.options, options);
			return this;
		};
		this.lazy = (lazyFn) => {
			this.lazyFn = lazyFn;
			return this;
		};
		this.redirect = (opts) => redirect({
			from: this.fullPath,
			...opts
		});
		this.options = options || {};
		this.isRoot = !options?.getParentRoute;
		if (options?.id && options?.path) throw new Error(`Route cannot have both an 'id' and a 'path' option.`);
	}
};
var BaseRouteApi = class {
	constructor({ id }) {
		this.notFound = (opts) => {
			return notFound({
				routeId: this.id,
				...opts
			});
		};
		this.redirect = (opts) => redirect({
			from: this.id,
			...opts
		});
		this.id = id;
	}
};
var BaseRootRoute = class extends BaseRoute {
	constructor(options) {
		super(options);
	}
};
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/config.js
var createRouterConfig = (options) => {
	return {
		serializationAdapters: options.serializationAdapters,
		defaultSsr: options.defaultSsr
	};
};
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/searchMiddleware.js
/**
* Retain specified search params across navigations.
*
* If `keys` is `true`, retain all current params. Otherwise, copy only the
* listed keys from the current search into the next search.
*
* @param keys `true` to retain all, or a list of keys to retain.
* @returns A search middleware suitable for route `search.middlewares`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/retainSearchParamsFunction
*/
function retainSearchParams(keys) {
	return ({ search, next }) => {
		const { search: resultSearch, meta } = next(search, true);
		if (keys === true) {
			const copy = {
				...search,
				...resultSearch
			};
			const removed = meta.removed;
			const explicit = meta.explicit;
			for (const key of removed?.keys() || []) if (explicit && hasOwn.call(explicit, key) || deepEqual(search[key], removed.get(key))) delete copy[key];
			for (const key of meta.removedAny || []) delete copy[key];
			for (const key of meta.defaulted?.keys() || []) if (key in search && !meta.removedAny?.has(key) && !(meta.removed?.has(key) && (explicit && hasOwn.call(explicit, key) || deepEqual(search[key], meta.removed.get(key))))) copy[key] = search[key];
			return copy;
		}
		const copy = { ...resultSearch };
		const explicit = meta.explicit;
		for (const key of keys) {
			const stringKey = key;
			if (!(meta.removedAny?.has(stringKey) || meta.removed?.has(stringKey) && (explicit && hasOwn.call(explicit, stringKey) || deepEqual(search[key], meta.removed.get(stringKey)))) && (!(key in copy) || key in search && meta.defaulted?.has(stringKey) && deepEqual(copy[key], meta.defaulted.get(stringKey)))) copy[key] = search[key];
		}
		return copy;
	};
}
/**
* Remove optional or default-valued search params from navigations.
*
* - Pass `true` (only if there are no required search params) to strip all.
* - Pass an array to always remove those optional keys.
* - Pass an object of default values; keys equal (deeply) to the defaults are removed.
*
* @returns A search middleware suitable for route `search.middlewares`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/stripSearchParamsFunction
*/
function stripSearchParams(input) {
	return (({ search, next, meta }) => {
		if (input === true) {
			Object.keys(search).forEach((key) => {
				if (meta) (meta.removedAny ||= /* @__PURE__ */ new Set()).add(key);
			});
			return {};
		}
		const result = { ...next(search) };
		if (Array.isArray(input)) input.forEach((key) => {
			delete result[key];
			if (meta) (meta.removedAny ||= /* @__PURE__ */ new Set()).add(key);
		});
		else Object.entries(input).forEach(([key, value]) => {
			if (deepEqual(result[key], value)) {
				delete result[key];
				if (meta) (meta.removed ||= /* @__PURE__ */ new Map()).set(key, value);
			}
		});
		return result;
	});
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/ssr/serializer/transformer.js
/**
* Create a strongly-typed serialization adapter for SSR hydration.
* Use to register custom types with the router serializer.
*/
function createSerializationAdapter(opts) {
	if (!opts.key || /[\0"\\<\b\t\f\r\n\u2028\u2029\uD800-\uDFFF]/.test(opts.key)) throw new Error(`createSerializationAdapter: key ${JSON.stringify(opts.key)} is invalid. Serialization adapter keys must be non-empty and not contain NUL, ", \\, <, backspace, tab, form feed, line terminators, or UTF-16 surrogate code units.`);
	return opts;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/awaited.js
var import_jsx_runtime = require_jsx_runtime();
/** Suspend until a deferred promise resolves or rejects and return its data. */
function useAwaited({ promise: _promise }) {
	if (reactUse) return reactUse(_promise);
	const promise = defer(_promise);
	if (promise[TSR_DEFERRED_PROMISE].status === "pending") throw promise;
	if (promise[TSR_DEFERRED_PROMISE].status === "error") throw promise[TSR_DEFERRED_PROMISE].error;
	return promise[TSR_DEFERRED_PROMISE].data;
}
/**
* Component that suspends on a deferred promise and renders its child with
* the resolved value. Optionally provides a Suspense fallback.
*/
function Await(props) {
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AwaitInner, { ...props });
	if (props.fallback) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: props.fallback,
		children: inner
	});
	return inner;
}
function AwaitInner(props) {
	const data = useAwaited(props);
	return props.children(data);
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/nonRouteComponentContext.js
var nonRouteComponentContext = import_react.createContext(void 0);
function wrapInNonRouteComponentContext(element, component) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(nonRouteComponentContext.Provider, {
		value: component,
		children: element
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/CatchBoundary.js
var CatchBoundary = class extends import_react.Component {
	constructor(..._args) {
		super(..._args);
		this.state = { error: 0 };
		this.reset = () => {
			this.setState({ error: 0 });
		};
	}
	static getDerivedStateFromProps(props, state) {
		const resetKey = props.getResetKey();
		if (state.error && state.resetKey !== resetKey) return {
			resetKey,
			error: 0
		};
		return { resetKey };
	}
	static getDerivedStateFromError(error) {
		return { error: [error] };
	}
	componentDidCatch(error, errorInfo) {
		this.props.onCatch?.(error, errorInfo);
	}
	render() {
		const error = this.state.error;
		if (error) return wrapInNonRouteComponentContext(import_react.createElement(this.props.errorComponent ?? ErrorComponent, {
			error: error[0],
			reset: this.reset
		}), "errorComponent");
		return this.props.children;
	}
};
function ErrorComponent({ error }) {
	const [show, setShow] = import_react.useState(true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			padding: ".5rem",
			maxWidth: "100%"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: ".5rem"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					style: { fontSize: "1rem" },
					children: "Something went wrong!"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					style: {
						appearance: "none",
						fontSize: ".6em",
						border: "1px solid currentColor",
						padding: ".1rem .2rem",
						fontWeight: "bold",
						borderRadius: ".25rem"
					},
					onClick: () => setShow((d) => !d),
					children: show ? "Hide Error" : "Show Error"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { height: ".25rem" } }),
			show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				style: {
					fontSize: ".7em",
					border: "1px solid red",
					borderRadius: ".25rem",
					padding: ".3rem",
					color: "red",
					overflow: "auto"
				},
				children: error?.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: error.message }) : null
			}) }) : null
		]
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/ClientOnly.js
var getSnapshot = () => true;
var getServerSnapshot = () => false;
/**
* Render the children only after the JS has loaded client-side. Use an optional
* fallback component if the JS is not yet loaded.
*
* @example
* Render a Chart component if JS loads, renders a simple FakeChart
* component server-side or if there is no JS. The FakeChart can have only the
* UI without the behavior or be a loading spinner or skeleton.
*
* ```tsx
* return (
*   <ClientOnly fallback={<FakeChart />}>
*     <Chart />
*   </ClientOnly>
* )
* ```
*/
function ClientOnly({ children, fallback = null }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: useHydrated() ? children : fallback });
}
/** @internal */
function useHydrated(enabled = true) {
	return import_react.useSyncExternalStore(subscribe, getSnapshot, enabled ? getServerSnapshot : getSnapshot);
}
function subscribe() {
	return () => {};
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/routerContext.js
var routerContext = import_react.createContext(null);
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useRouter.js
/**
* Access the current TanStack Router instance from React context.
* Must be used within a `RouterProvider`.
*
* Options:
* - `warn`: Log a warning if no router context is found (default: true).
*
* @returns The registered router instance.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useRouterHook
*/
function useRouter(opts) {
	const value = import_react.useContext(routerContext);
	if (!value) warnMissingRouter(opts);
	return value;
}
function warnMissingRouter(opts) {
	if (opts?.warn ?? true) console.warn("Warning: useRouter must be used inside a <RouterProvider> component!");
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/matchContext.js
function createLinkScope(router, routeId) {
	const store = router.stores.location;
	const listeners = /* @__PURE__ */ new Set();
	let source;
	let unsubscribe;
	const update = (location) => {
		if (!_isRouteDeparting(router, routeId, location)) {
			source = location;
			listeners.forEach((listener) => listener());
		}
	};
	return [() => source ?? store.get(), (listener) => {
		if (!listeners.size) {
			source = store.get();
			unsubscribe = store.subscribe(update).unsubscribe;
		}
		listeners.add(listener);
		return () => {
			listeners.delete(listener);
			if (!listeners.size) {
				unsubscribe();
				source = void 0;
			}
		};
	}];
}
var matchContext = import_react.createContext(void 0);
var dummyMatchContext = import_react.createContext(void 0);
//#endregion
//#region node_modules/@tanstack/store/dist/alien.js
/* @__NO_SIDE_EFFECTS__ */
function createReactiveSystem({ update, notify, unwatched }) {
	return {
		link,
		unlink,
		propagate,
		checkDirty,
		shallowPropagate
	};
	function link(dep, sub, version) {
		const prevDep = sub.depsTail;
		if (prevDep !== void 0 && prevDep.dep === dep) return;
		const nextDep = prevDep !== void 0 ? prevDep.nextDep : sub.deps;
		if (nextDep !== void 0 && nextDep.dep === dep) {
			nextDep.version = version;
			sub.depsTail = nextDep;
			return;
		}
		const prevSub = dep.subsTail;
		if (prevSub !== void 0 && prevSub.version === version && prevSub.sub === sub) return;
		const newLink = sub.depsTail = dep.subsTail = {
			version,
			dep,
			sub,
			prevDep,
			nextDep,
			prevSub,
			nextSub: void 0
		};
		if (nextDep !== void 0) nextDep.prevDep = newLink;
		if (prevDep !== void 0) prevDep.nextDep = newLink;
		else sub.deps = newLink;
		if (prevSub !== void 0) prevSub.nextSub = newLink;
		else dep.subs = newLink;
	}
	function unlink(link, sub = link.sub) {
		const dep = link.dep;
		const prevDep = link.prevDep;
		const nextDep = link.nextDep;
		const nextSub = link.nextSub;
		const prevSub = link.prevSub;
		if (nextDep !== void 0) nextDep.prevDep = prevDep;
		else sub.depsTail = prevDep;
		if (prevDep !== void 0) prevDep.nextDep = nextDep;
		else sub.deps = nextDep;
		if (nextSub !== void 0) nextSub.prevSub = prevSub;
		else dep.subsTail = prevSub;
		if (prevSub !== void 0) prevSub.nextSub = nextSub;
		else if ((dep.subs = nextSub) === void 0) unwatched(dep);
		return nextDep;
	}
	function propagate(link) {
		let next = link.nextSub;
		let stack;
		top: do {
			const sub = link.sub;
			let flags = sub.flags;
			if (!(flags & 60)) sub.flags = flags | 32;
			else if (!(flags & 12)) flags = 0;
			else if (!(flags & 4)) sub.flags = flags & -9 | 32;
			else if (!(flags & 48) && isValidLink(link, sub)) {
				sub.flags = flags | 40;
				flags &= 1;
			} else flags = 0;
			if (flags & 2) notify(sub);
			if (flags & 1) {
				const subSubs = sub.subs;
				if (subSubs !== void 0) {
					const nextSub = (link = subSubs).nextSub;
					if (nextSub !== void 0) {
						stack = {
							value: next,
							prev: stack
						};
						next = nextSub;
					}
					continue;
				}
			}
			if ((link = next) !== void 0) {
				next = link.nextSub;
				continue;
			}
			while (stack !== void 0) {
				link = stack.value;
				stack = stack.prev;
				if (link !== void 0) {
					next = link.nextSub;
					continue top;
				}
			}
			break;
		} while (true);
	}
	function checkDirty(link, sub) {
		let stack;
		let checkDepth = 0;
		let dirty = false;
		top: do {
			const dep = link.dep;
			const flags = dep.flags;
			if (sub.flags & 16) dirty = true;
			else if ((flags & 17) === 17) {
				if (update(dep)) {
					const subs = dep.subs;
					if (subs.nextSub !== void 0) shallowPropagate(subs);
					dirty = true;
				}
			} else if ((flags & 33) === 33) {
				if (link.nextSub !== void 0 || link.prevSub !== void 0) stack = {
					value: link,
					prev: stack
				};
				link = dep.deps;
				sub = dep;
				++checkDepth;
				continue;
			}
			if (!dirty) {
				const nextDep = link.nextDep;
				if (nextDep !== void 0) {
					link = nextDep;
					continue;
				}
			}
			while (checkDepth--) {
				const firstSub = sub.subs;
				const hasMultipleSubs = firstSub.nextSub !== void 0;
				if (hasMultipleSubs) {
					link = stack.value;
					stack = stack.prev;
				} else link = firstSub;
				if (dirty) {
					if (update(sub)) {
						if (hasMultipleSubs) shallowPropagate(firstSub);
						sub = link.sub;
						continue;
					}
					dirty = false;
				} else sub.flags &= -33;
				sub = link.sub;
				const nextDep = link.nextDep;
				if (nextDep !== void 0) {
					link = nextDep;
					continue top;
				}
			}
			return dirty;
		} while (true);
	}
	function shallowPropagate(link) {
		do {
			const sub = link.sub;
			const flags = sub.flags;
			if ((flags & 48) === 32) {
				sub.flags = flags | 16;
				if ((flags & 6) === 2) notify(sub);
			}
		} while ((link = link.nextSub) !== void 0);
	}
	function isValidLink(checkLink, sub) {
		let link = sub.depsTail;
		while (link !== void 0) {
			if (link === checkLink) return true;
			link = link.prevDep;
		}
		return false;
	}
}
//#endregion
//#region node_modules/@tanstack/store/dist/atom.js
function toObserver(nextHandler, errorHandler, completionHandler) {
	const isObserver = typeof nextHandler === "object";
	const self = isObserver ? nextHandler : void 0;
	return {
		next: (isObserver ? nextHandler.next : nextHandler)?.bind(self),
		error: (isObserver ? nextHandler.error : errorHandler)?.bind(self),
		complete: (isObserver ? nextHandler.complete : completionHandler)?.bind(self)
	};
}
var queuedEffects = [];
var cycle = 0;
var { link, unlink, propagate, checkDirty, shallowPropagate } = /* @__PURE__ */ createReactiveSystem({
	update(atom) {
		return atom._update();
	},
	notify(effect) {
		queuedEffects[queuedEffectsLength++] = effect;
		effect.flags &= -3;
	},
	unwatched(atom) {
		if (atom.depsTail !== void 0) {
			atom.depsTail = void 0;
			atom.flags = 17;
			purgeDeps(atom);
		}
	}
});
var notifyIndex = 0;
var queuedEffectsLength = 0;
var activeSub;
var batchDepth = 0;
function batch(fn) {
	try {
		++batchDepth;
		fn();
	} finally {
		if (!--batchDepth) flush();
	}
}
function purgeDeps(sub) {
	const depsTail = sub.depsTail;
	let dep = depsTail !== void 0 ? depsTail.nextDep : sub.deps;
	while (dep !== void 0) dep = unlink(dep, sub);
}
function flush() {
	if (batchDepth > 0) return;
	while (notifyIndex < queuedEffectsLength) {
		const effect = queuedEffects[notifyIndex];
		queuedEffects[notifyIndex++] = void 0;
		effect.notify();
	}
	notifyIndex = 0;
	queuedEffectsLength = 0;
}
function createAtom(valueOrFn, options) {
	const isComputed = typeof valueOrFn === "function";
	const getter = valueOrFn;
	const atom = {
		_snapshot: isComputed ? void 0 : valueOrFn,
		subs: void 0,
		subsTail: void 0,
		deps: void 0,
		depsTail: void 0,
		flags: isComputed ? 0 : 1,
		get() {
			if (activeSub !== void 0) link(atom, activeSub, cycle);
			return atom._snapshot;
		},
		subscribe(observerOrFn) {
			const obs = toObserver(observerOrFn);
			const observed = { current: false };
			const e = effect(() => {
				atom.get();
				if (!observed.current) observed.current = true;
				else {
					activeSub = void 0;
					obs.next?.(atom._snapshot);
				}
			});
			return { unsubscribe: () => {
				e.stop();
			} };
		},
		_update(getValue) {
			const prevSub = activeSub;
			const compare = options?.compare ?? Object.is;
			if (isComputed) {
				activeSub = atom;
				++cycle;
				atom.depsTail = void 0;
			} else if (getValue === void 0) return false;
			if (isComputed) atom.flags = 5;
			try {
				const oldValue = atom._snapshot;
				const newValue = typeof getValue === "function" ? getValue(oldValue) : getValue === void 0 && isComputed ? getter(oldValue) : getValue;
				if (oldValue === void 0 || !compare(oldValue, newValue)) {
					atom._snapshot = newValue;
					return true;
				}
				return false;
			} finally {
				activeSub = prevSub;
				if (isComputed) atom.flags &= -5;
				purgeDeps(atom);
			}
		}
	};
	if (isComputed) {
		atom.flags = 17;
		atom.get = function() {
			const flags = atom.flags;
			if (flags & 16 || flags & 32 && checkDirty(atom.deps, atom)) {
				if (atom._update()) {
					const subs = atom.subs;
					if (subs !== void 0) shallowPropagate(subs);
				}
			} else if (flags & 32) atom.flags = flags & -33;
			if (activeSub !== void 0) link(atom, activeSub, cycle);
			return atom._snapshot;
		};
	} else atom.set = function(valueOrFn) {
		if (atom._update(valueOrFn)) {
			const subs = atom.subs;
			if (subs !== void 0) {
				propagate(subs);
				shallowPropagate(subs);
				flush();
			}
		}
	};
	return atom;
}
function effect(fn) {
	const run = () => {
		const prevSub = activeSub;
		activeSub = effectObj;
		++cycle;
		effectObj.depsTail = void 0;
		effectObj.flags = 6;
		try {
			return fn();
		} finally {
			activeSub = prevSub;
			effectObj.flags &= -5;
			purgeDeps(effectObj);
		}
	};
	const effectObj = {
		deps: void 0,
		depsTail: void 0,
		subs: void 0,
		subsTail: void 0,
		flags: 6,
		notify() {
			const flags = this.flags;
			if (flags & 16 || flags & 32 && checkDirty(this.deps, this)) run();
			else this.flags = 2;
		},
		stop() {
			this.flags = 0;
			this.depsTail = void 0;
			purgeDeps(this);
		}
	};
	run();
	return effectObj;
}
//#endregion
//#region node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js
/**
* @license React
* use-sync-external-store-shim.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_use_sync_external_store_shim_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		function useSyncExternalStore$2(subscribe, getSnapshot) {
			didWarnOld18Alpha || void 0 === React.startTransition || (didWarnOld18Alpha = !0, console.error("You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."));
			var value = getSnapshot();
			if (!didWarnUncachedGetSnapshot) {
				var cachedValue = getSnapshot();
				objectIs(value, cachedValue) || (console.error("The result of getSnapshot should be cached to avoid an infinite loop"), didWarnUncachedGetSnapshot = !0);
			}
			cachedValue = useState({ inst: {
				value,
				getSnapshot
			} });
			var inst = cachedValue[0].inst, forceUpdate = cachedValue[1];
			useLayoutEffect(function() {
				inst.value = value;
				inst.getSnapshot = getSnapshot;
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
			}, [
				subscribe,
				value,
				getSnapshot
			]);
			useEffect(function() {
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				return subscribe(function() {
					checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				});
			}, [subscribe]);
			useDebugValue(value);
			return value;
		}
		function checkIfSnapshotChanged(inst) {
			var latestGetSnapshot = inst.getSnapshot;
			inst = inst.value;
			try {
				var nextValue = latestGetSnapshot();
				return !objectIs(inst, nextValue);
			} catch (error) {
				return !0;
			}
		}
		function useSyncExternalStore$1(subscribe, getSnapshot) {
			return getSnapshot();
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_react(), objectIs = "function" === typeof Object.is ? Object.is : is, useState = React.useState, useEffect = React.useEffect, useLayoutEffect = React.useLayoutEffect, useDebugValue = React.useDebugValue, didWarnOld18Alpha = !1, didWarnUncachedGetSnapshot = !1, shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
		exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
//#endregion
//#region node_modules/use-sync-external-store/shim/index.js
var require_shim = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_use_sync_external_store_shim_development();
}));
//#endregion
//#region node_modules/use-sync-external-store/cjs/use-sync-external-store-shim/with-selector.development.js
/**
* @license React
* use-sync-external-store-shim/with-selector.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_with_selector_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_react(), shim = require_shim(), objectIs = "function" === typeof Object.is ? Object.is : is, useSyncExternalStore = shim.useSyncExternalStore, useRef = React.useRef, useEffect = React.useEffect, useMemo = React.useMemo, useDebugValue = React.useDebugValue;
		exports.useSyncExternalStoreWithSelector = function(subscribe, getSnapshot, getServerSnapshot, selector, isEqual) {
			var instRef = useRef(null);
			if (null === instRef.current) {
				var inst = {
					hasValue: !1,
					value: null
				};
				instRef.current = inst;
			} else inst = instRef.current;
			instRef = useMemo(function() {
				function memoizedSelector(nextSnapshot) {
					if (!hasMemo) {
						hasMemo = !0;
						memoizedSnapshot = nextSnapshot;
						nextSnapshot = selector(nextSnapshot);
						if (void 0 !== isEqual && inst.hasValue) {
							var currentSelection = inst.value;
							if (isEqual(currentSelection, nextSnapshot)) return memoizedSelection = currentSelection;
						}
						return memoizedSelection = nextSnapshot;
					}
					currentSelection = memoizedSelection;
					if (objectIs(memoizedSnapshot, nextSnapshot)) return currentSelection;
					var nextSelection = selector(nextSnapshot);
					if (void 0 !== isEqual && isEqual(currentSelection, nextSelection)) return memoizedSnapshot = nextSnapshot, currentSelection;
					memoizedSnapshot = nextSnapshot;
					return memoizedSelection = nextSelection;
				}
				var hasMemo = !1, memoizedSnapshot, memoizedSelection, maybeGetServerSnapshot = void 0 === getServerSnapshot ? null : getServerSnapshot;
				return [function() {
					return memoizedSelector(getSnapshot());
				}, null === maybeGetServerSnapshot ? void 0 : function() {
					return memoizedSelector(maybeGetServerSnapshot());
				}];
			}, [
				getSnapshot,
				getServerSnapshot,
				selector,
				isEqual
			]);
			var value = useSyncExternalStore(subscribe, instRef[0], instRef[1]);
			useEffect(function() {
				inst.hasValue = !0;
				inst.value = value;
			}, [value]);
			useDebugValue(value);
			return value;
		};
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
//#endregion
//#region node_modules/@tanstack/react-store/dist/useSelector.js
var import_with_selector = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_with_selector_development();
})))();
function defaultCompare(a, b) {
	return a === b;
}
/**
* Selects a slice of state from an atom or store and subscribes the component
* to that selection.
*
* This is the primary React read hook for TanStack Store. It works with any
* source that exposes `get()` and `subscribe()`, including atoms, readonly
* atoms, stores, and readonly stores.
*
* Omit the selector to subscribe to the whole value.
*
* @example
* ```tsx
* const count = useSelector(counterStore, (state) => state.count)
* ```
*
* @example
* ```tsx
* const value = useSelector(countAtom)
* ```
*/
function useSelector(source, selector = (s) => s, options) {
	const compare = options?.compare ?? defaultCompare;
	const subscribe = (0, import_react.useCallback)((handleStoreChange) => {
		const { unsubscribe } = source.subscribe(handleStoreChange);
		return unsubscribe;
	}, [source]);
	const getSnapshot = (0, import_react.useCallback)(() => source.get(), [source]);
	return (0, import_with_selector.useSyncExternalStoreWithSelector)(subscribe, getSnapshot, getSnapshot, selector, compare);
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useMatch.js
var dummyMatch = {};
function useStructuralSharing(opts, router) {
	const previousResult = import_react.useRef();
	return (slice) => {
		const selected = opts?.select ? opts.select(slice) : slice;
		if (opts?.structuralSharing ?? router.options.defaultStructuralSharing) return previousResult.current = replaceEqualDeep(previousResult.current, selected);
		return selected;
	};
}
/**
* Read and select the nearest or targeted route match.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useMatchHook
*/
function useMatch(opts) {
	const router = useRouter();
	const nearestRouteId = import_react.useContext(opts.from ? dummyMatchContext : matchContext);
	const routeId = opts.from ?? nearestRouteId;
	const matchStore = router.stores.getMatchStore(routeId);
	if (router.isServer) {
		const match = matchStore.get();
		if (!match) {
			if (opts.shouldThrow ?? true) throw new Error(`Invariant failed: Could not find ${opts.from ? `an active match from "${opts.from}"` : "a nearest match!"}`);
			return;
		}
		return opts.select ? opts.select(match) : match;
	}
	const selector = useStructuralSharing(opts, router);
	const matchSelection = useSelector(matchStore, (match) => match ? selector(match) : dummyMatch);
	if (matchSelection !== dummyMatch) return matchSelection;
	if (opts.shouldThrow ?? true) throw new Error(`Invariant failed: Could not find ${opts.from ? `an active match from "${opts.from}"` : "a nearest match!"}`);
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useLoaderData.js
/**
* Read and select the current route's loader data with type‑safety.
*
* Options:
* - `from`/`strict`: Choose which route's data to read and strictness
* - `select`: Map the loader data to a derived value
* - `structuralSharing`: Enable structural sharing for stable references
*
* @returns The loader data (or selected value) for the matched route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useLoaderDataHook
*/
function useLoaderData(opts) {
	return useMatch({
		from: opts.from,
		strict: opts.strict,
		structuralSharing: opts.structuralSharing,
		select: (match) => {
			return opts.select ? opts.select(match.loaderData) : match.loaderData;
		}
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useLoaderDeps.js
/**
* Read and select the current route's loader dependencies object.
*
* Options:
* - `from`: Choose which route's loader deps to read
* - `select`: Map the deps to a derived value
* - `structuralSharing`: Enable structural sharing for stable references
*
* @returns The loader deps (or selected value) for the matched route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useLoaderDepsHook
*/
function useLoaderDeps(opts) {
	const { select, ...rest } = opts;
	return useMatch({
		...rest,
		select: (match) => {
			return select ? select(match.loaderDeps) : match.loaderDeps;
		}
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useParams.js
/**
* Access the current route's path parameters with type-safety.
*
* Options:
* - `from`/`strict`: Specify the matched route and whether to enforce strict typing
* - `select`: Project the params object to a derived value for memoized renders
* - `structuralSharing`: Enable structural sharing for stable references
* - `shouldThrow`: Throw if the route is not found in strict contexts
*
* @returns The params object (or selected value) for the matched route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useParamsHook
*/
function useParams(opts) {
	return useMatch({
		from: opts.from,
		shouldThrow: opts.shouldThrow,
		structuralSharing: opts.structuralSharing,
		strict: opts.strict,
		select: (match) => {
			const params = opts.strict === false ? match.params : match._strictParams;
			return opts.select ? opts.select(params) : params;
		}
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useSearch.js
/**
* Read and select the current route's search parameters with type-safety.
*
* Options:
* - `from`/`strict`: Control which route's search is read and how strictly it's typed
* - `select`: Map the search object to a derived value for render optimization
* - `structuralSharing`: Enable structural sharing for stable references
* - `shouldThrow`: Throw when the route is not found (strict contexts)
*
* @returns The search object (or selected value) for the matched route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useSearchHook
*/
function useSearch(opts) {
	return useMatch({
		from: opts.from,
		strict: opts.strict,
		shouldThrow: opts.shouldThrow,
		structuralSharing: opts.structuralSharing,
		select: (match) => {
			return opts.select ? opts.select(match.search) : match.search;
		}
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useNavigate.js
/**
* Imperative navigation hook.
*
* Returns a stable `navigate(options)` function to change the current location
* programmatically. Prefer the `Link` component for user-initiated navigation,
* and use this hook from effects, callbacks, or handlers where imperative
* navigation is required.
*
* Options:
* - `from`: Optional route base used to resolve relative `to` paths.
*
* @returns A function that accepts `NavigateOptions`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useNavigateHook
*/
function useNavigate(_defaultOpts) {
	const router = useRouter();
	return import_react.useCallback((options) => {
		return router.navigate({
			...options,
			from: options.from ?? _defaultOpts?.from
		});
	}, [_defaultOpts?.from, router]);
}
/**
* Component that triggers a navigation when rendered. Navigation executes
* in an effect after mount/update.
*
* Props are the same as `NavigateOptions` used by `navigate()`.
*
* @returns null
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/navigateComponent
*/
function Navigate(props) {
	const router = useRouter();
	const navigate = useNavigate();
	const previousPropsRef = import_react.useRef(null);
	useLayoutEffect(() => {
		if (previousPropsRef.current !== props) {
			navigate(props);
			previousPropsRef.current = props;
		}
	}, [
		router,
		props,
		navigate
	]);
	return null;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useRouteContext.js
function useRouteContext(opts) {
	return useMatch({
		...opts,
		select: (match) => opts.select ? opts.select(match.context) : match.context
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/link.js
function useStableValues(...values) {
	const ref = import_react.useRef(values);
	const stable = ref.current;
	values.forEach((value, index) => {
		if (!deepEqual(stable[index], value, false, true)) stable[index] = value;
	});
	return ref.current;
}
function preloadLink(router, options) {
	router.preloadRoute(options).catch((err) => {
		console.warn(err);
		console.warn(preloadWarning);
	});
}
function resolveExternalLink(to, protocolAllowlist) {
	const scheme = typeof to === "string" && getUrlScheme(to);
	if (!scheme) return;
	if (!protocolAllowlist.has(scheme)) {
		console.warn(`Blocked Link with dangerous protocol: ${to}`);
		return null;
	}
	return to;
}
function resolveIsActive(location, next, activeOptions, basepath) {
	const currentPath = removeTrailingSlash(location.pathname, basepath);
	const nextPath = removeTrailingSlash(next.pathname, basepath);
	if (activeOptions?.exact ? currentPath !== nextPath : !(currentPath.startsWith(nextPath) && (currentPath.length === nextPath.length || currentPath[nextPath.length] === "/"))) return false;
	if (activeOptions?.includeSearch ?? true) {
		if (!deepEqual(location.search, next.search, !activeOptions?.exact, activeOptions?.explicitUndefined)) return false;
	}
	return !activeOptions?.includeHash || location.hash === next.hash;
}
function useLinkProps(options, forwardedRef, host) {
	const router = useRouter();
	if (router.isServer) return getServerLinkProps(router, options, forwardedRef, host);
	const innerRef = import_react.useRef(null);
	const mergedRef = import_react.useCallback((element) => {
		innerRef.current = element;
		if (typeof forwardedRef === "function") return forwardedRef(element);
		if (forwardedRef) forwardedRef.current = element;
	}, [forwardedRef]);
	const { activeOptions, to, preload: userPreload, preloadDelay: userPreloadDelay, disabled, target, onClick, onBlur, onFocus, onMouseEnter, onMouseLeave, onTouchStart } = options;
	const [stableSearch, stableParams, stableActiveOptions] = useStableValues(options.search, options.params, activeOptions);
	const routeId = import_react.useContext(matchContext);
	const scope = (router.stores._linkScopes ??= {})[routeId] ??= createLinkScope(router, routeId);
	const [dest, getLinkState, getHydrationState] = import_react.useMemo(() => {
		const directExternalLink = resolveExternalLink(to, router.protocolAllowlist);
		if (directExternalLink !== void 0) {
			const state = [directExternalLink ?? void 0];
			return [options, () => state];
		}
		const dest = { ...options };
		let source;
		let state;
		let hydrationState;
		const getLinkState = () => {
			const location = scope[0]();
			if (location !== source) {
				dest._fromLocation = location;
				const next = router.buildLocation(dest);
				const href = getHrefOption(next, router, disabled);
				const isActive = disabled || href && !getUrlScheme(href) ? resolveIsActive(location, next, stableActiveOptions, router.basepath) : void 0;
				if (!state || state[0] !== href || state[1] !== isActive) state = [href, isActive];
				source = location;
			}
			return state;
		};
		return [
			dest,
			getLinkState,
			stableActiveOptions?.includeHash && (() => {
				const state = getLinkState();
				return state[1] ? hydrationState ??= [state[0], false] : state;
			})
		];
	}, [
		router,
		scope,
		options.from,
		options.hash,
		options.href,
		to,
		stableSearch,
		stableParams,
		options.state,
		options.mask,
		options.unsafeRelative,
		stableActiveOptions,
		disabled
	]);
	const [href, isActive] = import_react.useSyncExternalStore(scope[1], getLinkState, getHydrationState || getLinkState);
	const externalLink = isActive === void 0 && href;
	const linkDisabled = disabled || href === void 0;
	const hasRenderFetched = import_react.useRef(false);
	const preload = options.reloadDocument || externalLink || linkDisabled ? false : userPreload ?? router.options.defaultPreload;
	const preloadDelay = userPreloadDelay ?? router.options.defaultPreloadDelay ?? 0;
	const enqueuePreload = import_react.useCallback((e) => {
		const isIntersecting = e?.isIntersecting;
		if (!(isIntersecting ?? preload === "intent")) {
			if (isIntersecting === false) cancelPreload(innerRef);
			return;
		}
		if (!preloadDelay) {
			preloadLink(router, dest);
			return;
		}
		innerRef.t ??= setTimeout(() => {
			innerRef.t = void 0;
			preloadLink(router, dest);
		}, preloadDelay);
	}, [
		router,
		dest,
		innerRef,
		preload,
		preloadDelay
	]);
	import_react.useEffect(() => {
		if (!preload) return;
		if (preload === "render" && !hasRenderFetched.current) {
			hasRenderFetched.current = true;
			preloadLink(router, dest);
		}
		let active = true;
		let observer;
		if (preload === "viewport" && innerRef.current && typeof IntersectionObserver === "function") {
			observer = new IntersectionObserver((entries) => {
				if (active) enqueuePreload(entries.pop());
			}, { rootMargin: "100px" });
			observer.observe(innerRef.current);
		}
		return () => {
			active = false;
			observer?.disconnect();
			cancelPreload(innerRef);
		};
	}, [
		router,
		dest,
		preload,
		enqueuePreload,
		innerRef
	]);
	const props = collectElementProps(options, host);
	props.ref = forwardedRef ? mergedRef : innerRef;
	if (externalLink) {
		props.href = externalLink;
		return props;
	}
	const handleClick = (e) => {
		const effectiveTarget = target ?? e.currentTarget.getAttribute("target");
		if (!linkDisabled && !(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) && !e.defaultPrevented && (!effectiveTarget || effectiveTarget === "_self") && e.button === 0) {
			e.preventDefault();
			cancelPreload(innerRef);
			router.navigate({
				...options,
				_fromLocation: dest._fromLocation
			});
		}
	};
	const handleTouchStart = () => {
		if (preload === "intent") preloadLink(router, dest);
	};
	const handleLeave = () => {
		if (preload === "intent") cancelPreload(innerRef);
	};
	props.onClick = composeHandlers(onClick, handleClick);
	props.onBlur = composeHandlers(onBlur, handleLeave);
	props.onFocus = composeHandlers(onFocus, enqueuePreload);
	props.onMouseEnter = composeHandlers(onMouseEnter, enqueuePreload);
	props.onMouseLeave = composeHandlers(onMouseLeave, handleLeave);
	props.onTouchStart = composeHandlers(onTouchStart, handleTouchStart);
	return applyLinkState(props, options, isActive, href, linkDisabled, host);
}
var STATIC_EMPTY_OBJECT = {};
var STATIC_ACTIVE_OBJECT = { className: "active" };
var ROUTER_OPTION_KEYS = /* @__PURE__ */ new Set([
	"to",
	"params",
	"search",
	"hash",
	"state",
	"mask",
	"from",
	"unsafeRelative",
	"reloadDocument",
	"preload",
	"preloadDelay",
	"preloadIntentProximity",
	"hashScrollIntoView",
	"replace",
	"startTransition",
	"resetScroll",
	"viewTransition",
	"ignoreBlocker",
	"activeProps",
	"inactiveProps",
	"activeOptions",
	"_asChild"
]);
function collectElementProps(options, host) {
	const props = {};
	for (const key in options) {
		if (ROUTER_OPTION_KEYS.has(key) || key === "type" && host !== void 0 || key === "disabled" && host === "a") continue;
		props[key] = options[key];
	}
	return props;
}
function applyLinkState(props, options, isActive, href, linkDisabled, host) {
	const { activeProps, inactiveProps, className, style, target } = options;
	const stateProps = functionalUpdate(isActive ? activeProps : inactiveProps, {}) ?? (isActive ? STATIC_ACTIVE_OBJECT : STATIC_EMPTY_OBJECT);
	Object.assign(props, stateProps);
	props.href = href;
	if (host !== "a") props.disabled = linkDisabled;
	props.target = target;
	const stateStyle = stateProps.style;
	if (style || stateStyle) props.style = style && stateStyle ? {
		...style,
		...stateStyle
	} : style || stateStyle;
	const stateClassName = stateProps.className;
	if (className || stateClassName) props.className = className ? stateClassName ? `${className} ${stateClassName}` : className : stateClassName;
	if (linkDisabled) {
		props.role = "link";
		props["aria-disabled"] = true;
	}
	if (isActive) {
		props["data-status"] = "active";
		props["aria-current"] = "page";
	}
	return props;
}
function getServerLinkProps(router, options, forwardedRef, host) {
	const { to, disabled, activeOptions } = options;
	const directExternalLink = resolveExternalLink(to, router.protocolAllowlist);
	const next = directExternalLink === void 0 ? router.buildLocation(options) : void 0;
	const hrefOption = next ? getHrefOption(next, router, disabled) : directExternalLink ?? void 0;
	const linkDisabled = disabled || !hrefOption;
	const externalLink = directExternalLink ?? (hrefOption && getUrlScheme(hrefOption) ? hrefOption : void 0);
	const props = collectElementProps(options, host);
	props.ref = forwardedRef;
	if (externalLink) {
		props.href = externalLink;
		return props;
	}
	return applyLinkState(props, options, !!next && !(!disabled && !hrefOption) && !activeOptions?.includeHash && resolveIsActive(router.stores.location.get(), next, activeOptions, router.basepath), hrefOption, linkDisabled, host);
}
var cancelPreload = (ref) => {
	clearTimeout(ref.t);
	ref.t = void 0;
};
var composeHandlers = (first, second) => {
	if (!first) return second;
	return (event) => event.defaultPrevented || (first(event), event.defaultPrevented || second(event));
};
function getHrefOption(next, router, disabled) {
	if (disabled) return;
	const location = next.maskedLocation ?? next;
	const href = location.external ? location.publicHref : router.history.createHref(location.publicHref) || "/";
	if ((location.external || href !== location.publicHref) && isDangerousProtocol(href, router.protocolAllowlist)) {
		console.warn(`Blocked Link with dangerous protocol: ${href}`);
		return;
	}
	return href;
}
/**
* Creates a typed Link-like component that preserves TanStack Router's
* navigation semantics and type-safety while delegating rendering to the
* provided host component.
*
* Useful for integrating design system anchors/buttons while keeping
* router-aware props (eg. `to`, `params`, `search`, `preload`).
*
* @param Comp The host component to render (eg. a design-system Link/Button)
* @returns A router-aware component with the same API as `Link`.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/custom-link
*/
function createLink(Comp) {
	return import_react.forwardRef(function CreatedLink(props, ref) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			...props,
			_asChild: Comp,
			ref
		});
	});
}
/**
* A strongly-typed anchor component for declarative navigation.
* Handles path, search, hash and state updates with optional route preloading
* and active-state styling.
*
* Props:
* - `preload`: Controls route preloading (eg. 'intent', 'render', 'viewport', true/false)
* - `preloadDelay`: Delay in ms before preloading on focus, hover, or viewport entry
* - `activeProps`/`inactiveProps`: Additional props merged when link is active/inactive
* - `resetScroll`/`hashScrollIntoView`: Control scroll behavior on navigation
* - `viewTransition`/`startTransition`: Use View Transitions/React transitions for navigation
* - `ignoreBlocker`: Bypass registered blockers
*
* @returns An anchor-like element that navigates without full page reloads.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/linkComponent
*/
var Link = import_react.memo(import_react.forwardRef((props, ref) => {
	const host = props._asChild || "a";
	const linkProps = useLinkProps(props, ref, host);
	const children = typeof props.children === "function" ? props.children({ isActive: linkProps["data-status"] === "active" }) : props.children;
	return import_react.createElement(host, linkProps, children);
}), areLinkPropsEqual);
function areLinkPropsEqual(prev, next) {
	let extraKeys = 0;
	for (const key in next) {
		extraKeys++;
		if (prev[key] === next[key]) continue;
		if (!ROUTER_OPTION_KEYS.has(key) || !deepEqual(prev[key], next[key], false, true)) return false;
	}
	for (const _key in prev) extraKeys--;
	return extraKeys === 0;
}
/**
* Validate and reuse navigation options for `Link`, `navigate` or `redirect`.
* Accepts a literal options object and returns it typed for later spreading.
* @example
* const opts = linkOptions({ to: '/dashboard', search: { tab: 'home' } })
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/linkOptions
*/
var linkOptions = (options) => {
	return options;
};
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/route.js
/**
* Returns a route-specific API that exposes type-safe hooks pre-bound
* to a single route ID. Useful for consuming a route's APIs from files
* where the route object isn't directly imported (e.g. code-split files).
*
* @param id Route ID string literal for the target route.
* @returns A `RouteApi` instance bound to the given route ID.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/getRouteApiFunction
*/
function getRouteApi(id) {
	return new RouteApi({ id });
}
var RouteApi = class extends BaseRouteApi {
	/**
	* @deprecated Use the `getRouteApi` function instead.
	*/
	constructor({ id }) {
		super({ id });
		this.useMatch = (opts) => {
			return useMatch({
				...opts,
				from: this.id
			});
		};
		this.useRouteContext = (opts) => {
			return useRouteContext({
				...opts,
				from: this.id
			});
		};
		this.useSearch = (opts) => {
			return useSearch({
				...opts,
				from: this.id
			});
		};
		this.useParams = (opts) => {
			return useParams({
				...opts,
				from: this.id
			});
		};
		this.useLoaderDeps = (opts) => {
			return useLoaderDeps({
				...opts,
				from: this.id,
				strict: false
			});
		};
		this.useLoaderData = (opts) => {
			return useLoaderData({
				...opts,
				from: this.id,
				strict: false
			});
		};
		this.useNavigate = () => {
			return useNavigate({ from: useRouter().routesById[this.id].fullPath });
		};
		this.notFound = (opts) => {
			return notFound({
				routeId: this.id,
				...opts
			});
		};
		this.Link = import_react.forwardRef((props, ref) => {
			const fullPath = useRouter().routesById[this.id].fullPath;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				ref,
				from: fullPath,
				...props
			});
		});
	}
};
var Route = class extends BaseRoute {
	/**
	* @deprecated Use the `createRoute` function instead.
	*/
	constructor(options) {
		super(options);
		this.useMatch = (opts) => {
			return useMatch({
				...opts,
				from: this.id
			});
		};
		this.useRouteContext = (opts) => {
			return useRouteContext({
				...opts,
				from: this.id
			});
		};
		this.useSearch = (opts) => {
			return useSearch({
				...opts,
				from: this.id
			});
		};
		this.useParams = (opts) => {
			return useParams({
				...opts,
				from: this.id
			});
		};
		this.useLoaderDeps = (opts) => {
			return useLoaderDeps({
				...opts,
				from: this.id
			});
		};
		this.useLoaderData = (opts) => {
			return useLoaderData({
				...opts,
				from: this.id
			});
		};
		this.useNavigate = () => {
			return useNavigate({ from: this.fullPath });
		};
		this.Link = import_react.forwardRef((props, ref) => {
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				ref,
				from: this.fullPath,
				...props
			});
		});
	}
};
/**
* Creates a non-root Route instance for code-based routing.
*
* Use this to define a route that will be composed into a route tree
* (typically via a parent route's `addChildren`). If you're using file-based
* routing, prefer `createFileRoute`.
*
* @param options Route options (path, component, loader, context, etc.).
* @returns A Route instance to be attached to the route tree.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRouteFunction
*/
function createRoute(options) {
	return new Route(options);
}
/**
* Creates a root route factory that requires a router context type.
*
* Use when your root route expects `context` to be provided to `createRouter`.
* The returned function behaves like `createRootRoute` but enforces a context type.
*
* @returns A factory function to configure and return a root route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRootRouteWithContextFunction
*/
function createRootRouteWithContext() {
	return (options) => {
		return createRootRoute(options);
	};
}
/**
* @deprecated Use the `createRootRouteWithContext` function instead.
*/
var rootRouteWithContext = createRootRouteWithContext;
var RootRoute = class extends BaseRootRoute {
	/**
	* @deprecated `RootRoute` is now an internal implementation detail. Use `createRootRoute()` instead.
	*/
	constructor(options) {
		super(options);
		this.useMatch = (opts) => {
			return useMatch({
				...opts,
				from: this.id
			});
		};
		this.useRouteContext = (opts) => {
			return useRouteContext({
				...opts,
				from: this.id
			});
		};
		this.useSearch = (opts) => {
			return useSearch({
				...opts,
				from: this.id
			});
		};
		this.useParams = (opts) => {
			return useParams({
				...opts,
				from: this.id
			});
		};
		this.useLoaderDeps = (opts) => {
			return useLoaderDeps({
				...opts,
				from: this.id
			});
		};
		this.useLoaderData = (opts) => {
			return useLoaderData({
				...opts,
				from: this.id
			});
		};
		this.useNavigate = () => {
			return useNavigate({ from: this.fullPath });
		};
		this.Link = import_react.forwardRef((props, ref) => {
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				ref,
				from: this.fullPath,
				...props
			});
		});
	}
};
/**
* Creates a root Route instance used to build your route tree.
*
* Typically paired with `createRouter({ routeTree })`. If you need to require
* a typed router context, use `createRootRouteWithContext` instead.
*
* @param options Root route options (component, error, pending, etc.).
* @returns A root route instance.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRootRouteFunction
*/
function createRootRoute(options) {
	return new RootRoute(options);
}
function createRouteMask(opts) {
	return opts;
}
var NotFoundRoute = class extends Route {
	constructor(options) {
		super({
			...options,
			id: "404"
		});
	}
};
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/fileRoute.js
/**
* Creates a file-based Route factory for a given path.
*
* Used by TanStack Router's file-based routing to associate a file with a
* route. The returned function accepts standard route options. In normal usage
* the `path` string is inserted and maintained by the `tsr` generator.
*
* @param path File path literal for the route (usually auto-generated).
* @returns A function that accepts Route options and returns a Route instance.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createFileRouteFunction
*/
function createFileRoute(path) {
	return (options) => {
		const route = createRoute(options);
		route.isRoot = false;
		return route;
	};
}
/** 
@deprecated It's no longer recommended to use the `FileRoute` class directly.
Instead, use `createFileRoute('/path/to/file')(options)` to create a file route.
*/
var FileRoute = class {
	constructor(path, _opts) {
		this.path = path;
		this.createRoute = (options) => {
			if (!this.silent) console.warn("Warning: FileRoute is deprecated and will be removed in the next major version. Use the createFileRoute(path)(options) function instead.");
			const route = createRoute(options);
			route.isRoot = false;
			return route;
		};
		this.silent = _opts?.silent;
	}
};
/**
@deprecated It's recommended not to split loaders into separate files.
Instead, place the loader function in the main route file via `createFileRoute`.
*/
function FileRouteLoader(_path) {
	console.warn(`Warning: FileRouteLoader is deprecated and will be removed in the next major version. Please place the loader function in the main route file, inside the \`createFileRoute('/path/to/file')(options)\` options`);
	return (loaderFn) => loaderFn;
}
var LazyRoute = class {
	constructor(opts) {
		this.useMatch = (opts) => {
			return useMatch({
				...opts,
				from: this.options.id
			});
		};
		this.useRouteContext = (opts) => {
			return useRouteContext({
				...opts,
				from: this.options.id
			});
		};
		this.useSearch = (opts) => {
			return useSearch({
				...opts,
				from: this.options.id
			});
		};
		this.useParams = (opts) => {
			return useParams({
				...opts,
				from: this.options.id
			});
		};
		this.useLoaderDeps = (opts) => {
			return useLoaderDeps({
				...opts,
				from: this.options.id
			});
		};
		this.useLoaderData = (opts) => {
			return useLoaderData({
				...opts,
				from: this.options.id
			});
		};
		this.useNavigate = () => {
			return useNavigate({ from: useRouter().routesById[this.options.id].fullPath });
		};
		this.options = opts;
	}
};
/**
* Creates a lazily-configurable code-based route stub by ID.
*
* Use this for code-splitting with code-based routes. The returned function
* accepts only non-critical route options like `component`, `pendingComponent`,
* `errorComponent`, and `notFoundComponent` which are applied when the route
* is matched.
*
* @param id Route ID string literal to associate with the lazy route.
* @returns A function that accepts lazy route options and returns a `LazyRoute`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createLazyRouteFunction
*/
function createLazyRoute(id) {
	return (opts) => {
		return new LazyRoute({
			id,
			...opts
		});
	};
}
/**
* Creates a lazily-configurable file-based route stub by file path.
*
* Use this for code-splitting with file-based routes (eg. `.lazy.tsx` files).
* The returned function accepts only non-critical route options like
* `component`, `pendingComponent`, `errorComponent`, and `notFoundComponent`.
*
* @param id File path literal for the route file.
* @returns A function that accepts lazy route options and returns a `LazyRoute`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createLazyFileRouteFunction
*/
function createLazyFileRoute(id) {
	if (typeof id === "object") return new LazyRoute(id);
	return (opts) => new LazyRoute({
		id,
		...opts
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/lazyRouteComponent.js
/**
* Wrap a dynamic import to create a route component that supports
* `.preload()` and friendly reload-on-module-missing behavior.
*
* @param importer Function returning a module promise
* @param exportName Named export to use (default: `default`)
* @returns A lazy route component compatible with TanStack Router
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/lazyRouteComponentFunction
*/
function lazyRouteComponent(importer, exportName) {
	let loadPromise;
	let comp;
	let error;
	const load = () => {
		if (!loadPromise) {
			error = void 0;
			loadPromise = importer().then((res) => {
				if (!(typeof window === "undefined")) {
					loadPromise = void 0;
					lazyComp.preload = void 0;
				}
				comp = res[exportName ?? "default"];
			}).catch((err) => {
				loadPromise = void 0;
				error = err;
			});
		}
		return loadPromise;
	};
	const lazyComp = function Lazy(props) {
		if (error) {
			if (isModuleNotFoundError(error) && !(typeof window === "undefined") && typeof sessionStorage !== "undefined") {
				const storageKey = `tanstack_router_reload:${error.message}`;
				if (!sessionStorage.getItem(storageKey)) {
					sessionStorage.setItem(storageKey, "1");
					window.location.reload();
					throw new Promise(() => {});
				}
			}
			throw error;
		}
		if (!comp) {
			if (reactUse) reactUse(load());
			else throw load();
		}
		return import_react.createElement(comp, props);
	};
	lazyComp.preload = load;
	return lazyComp;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/not-found.js
function CatchNotFound(props) {
	const router = useRouter();
	if (router.isServer) {
		const resetKey = `not-found-${router.stores.location.get().pathname}-${router.stores.status.get()}`;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchBoundary, {
			getResetKey: () => resetKey,
			onCatch: (error, errorInfo) => {
				if (isNotFound(error)) props.onCatch?.(error, errorInfo);
				else throw error;
			},
			errorComponent: ({ error }) => {
				if (isNotFound(error)) return props.fallback?.(error);
				else throw error;
			},
			children: props.children
		});
	}
	const resetKey = `not-found-${useSelector(router.stores.location, (location) => location.pathname)}-${useSelector(router.stores.status)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchBoundary, {
		getResetKey: () => resetKey,
		onCatch: (error, errorInfo) => {
			if (isNotFound(error)) props.onCatch?.(error, errorInfo);
			else throw error;
		},
		errorComponent: ({ error }) => {
			if (isNotFound(error)) return props.fallback?.(error);
			else throw error;
		},
		children: props.children
	});
}
function DefaultGlobalNotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Not Found" });
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/ScriptOnce.js
/**
* Server-only helper to emit a script tag exactly once during SSR.
*/
function ScriptOnce({ children }) {
	const router = useRouter();
	if (!router.isServer) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
		nonce: router.options.ssr?.nonce,
		dangerouslySetInnerHTML: { __html: children + ";document.currentScript.remove()" }
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/renderRouteNotFound.js
/**
* Renders a not found component for a route when no matching route is found.
*
* @param router - The router instance containing the route configuration
* @param route - The route that triggered the not found state
* @param data - Additional data to pass to the not found component
* @returns The rendered not found component or a default fallback component
*/
function renderRouteNotFound(router, route, data) {
	if (!route.options.notFoundComponent) {
		if (router.options.defaultNotFoundComponent) return wrapInNonRouteComponentContext(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(router.options.defaultNotFoundComponent, { ...data }), "notFoundComponent");
		if (!route.options.notFoundComponent) console.warn(`Warning: A notFoundError was encountered on the route with ID "${route.id}", but a notFoundComponent option was not configured, nor was a router level defaultNotFoundComponent configured. Consider configuring at least one of these to avoid TanStack Router's overly generic defaultNotFoundComponent (<p>Not Found</p>)`);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DefaultGlobalNotFound, {});
	}
	return wrapInNonRouteComponentContext(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(route.options.notFoundComponent, { ...data }), "notFoundComponent");
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/scroll-restoration-script/client.js
function getScrollRestorationScriptForRouter(_router) {
	return null;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/scroll-restoration.js
function ScrollRestoration$1() {
	const script = getScrollRestorationScriptForRouter(useRouter());
	if (!script) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScriptOnce, { children: script });
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/Match.js
function renderPending(router, route) {
	const PendingComponent = route?.options.pendingComponent ?? router.options.defaultPendingComponent;
	if (!PendingComponent) return null;
	return wrapInNonRouteComponentContext(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingComponent, {}), "pendingComponent");
}
var outletMatchSelectionEqual = (a, b) => a[0] === b[0] && a[1] === b[1];
var canWrapInSuspense = (router, route, ssr) => !route.isRoot || route.options.shellComponent || route.options.wrapInSuspense || ssr === false || ssr === "data-only" || !(router.isServer || router.ssr);
var Match = import_react.memo(function MatchImpl({ routeId }) {
	const router = useRouter();
	if (router.isServer) return matchView(router, router.stores.byRoute.get(routeId).get());
	return matchView(router, useSelector(router.stores.getMatchStore(routeId)));
});
function matchView(router, match) {
	const route = router.routesById[match.routeId];
	const pendingElement = renderPending(router, route);
	const routeErrorComponent = route.options.errorComponent ?? router.options.defaultErrorComponent;
	const routeOnCatch = route.options.onCatch ?? router.options.defaultOnCatch;
	const routeNotFoundComponent = route.isRoot ? route.options.notFoundComponent ?? router.options.notFoundRoute?.options.component : route.options.notFoundComponent;
	const resolvedNoSsr = match.ssr === false || match.ssr === "data-only";
	const wrapInSuspense = canWrapInSuspense(router, route, match.ssr) && (route.options.wrapInSuspense ?? pendingElement ?? (route.options.errorComponent?.preload || resolvedNoSsr));
	let content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchInner, { match });
	if (resolvedNoSsr) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientOnly, {
		fallback: pendingElement,
		children: content
	});
	if (routeNotFoundComponent) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchNotFound, {
		fallback: (error) => {
			error.routeId ??= match.routeId;
			if (error.routeId !== match.routeId) throw error;
			return wrapInNonRouteComponentContext(import_react.createElement(routeNotFoundComponent, error), "notFoundComponent");
		},
		children: content
	});
	if (routeErrorComponent) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchBoundary, {
		getResetKey: () => match,
		errorComponent: routeErrorComponent,
		onCatch: (error, errorInfo) => {
			if (isNotFound(error)) {
				error.routeId ??= match.routeId;
				throw error;
			}
			console.warn(`Warning: Error in route match: ${match.id}`);
			routeOnCatch?.(error, errorInfo);
		},
		children: content
	});
	if (wrapInSuspense) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: pendingElement,
		children: content
	});
	const scrollRestoration = router.isServer && route.parentRoute?.id === "__root__" && router.options.scrollRestoration ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollRestoration$1, {}) : null;
	const ShellComponent = route.isRoot && route.options.shellComponent;
	return ShellComponent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(matchContext.Provider, {
		value: match.routeId,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ShellComponent, { children: [content, scrollRestoration] })
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(matchContext.Provider, {
		value: match.routeId,
		children: [content, scrollRestoration]
	});
}
var MatchInner = import_react.memo(function MatchInnerImpl({ match }) {
	const router = useRouter();
	const routeId = match.routeId;
	const route = router.routesById[routeId];
	const key = import_react.useMemo(() => {
		const remountDeps = (route.options.remountDeps ?? router.options.defaultRemountDeps)?.({
			routeId,
			loaderDeps: match.loaderDeps,
			params: match._strictParams,
			search: match._strictSearch
		});
		return remountDeps ? JSON.stringify(remountDeps) : void 0;
	}, [
		routeId,
		match.loaderDeps,
		match._strictParams,
		match._strictSearch,
		route.options.remountDeps,
		router.options.defaultRemountDeps
	]);
	const out = import_react.useMemo(() => {
		const Comp = route.options.component ?? router.options.defaultComponent;
		return Comp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comp, {}, key) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
	}, [
		key,
		route.options.component,
		router.options.defaultComponent
	]);
	if (match.status === "pending") {
		if (router.ssr && !canWrapInSuspense(router, route, match.ssr)) return out;
		if (router._tx) throw router._tx[5];
		return renderPending(router, route);
	}
	if (match.status === "notFound") return renderRouteNotFound(router, route, match.error);
	if (match.status === "error") {
		if (router.isServer) {
			const RouteErrorComponent = (route.options.errorComponent ?? router.options.defaultErrorComponent) || ErrorComponent;
			return wrapInNonRouteComponentContext(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RouteErrorComponent, {
				error: match.error,
				reset: void 0,
				info: { componentStack: "" }
			}), "errorComponent");
		}
		throw match.error;
	}
	return out;
});
/**
* Render the next child match in the route tree. Typically used inside
* a route component to render nested routes.
*
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/outletComponent
*/
var Outlet = import_react.memo(function OutletImpl() {
	{
		const nonRouteComponent = import_react.useContext(nonRouteComponentContext);
		if (nonRouteComponent) console.warn(`Warning: An <Outlet /> was rendered inside a ${nonRouteComponent}. <Outlet /> should only be rendered inside a route component.`);
	}
	const router = useRouter();
	const routeId = import_react.useContext(matchContext);
	let parentGlobalNotFound;
	let parentNotFoundError;
	let childRouteId;
	if (router.isServer) {
		const matches = router.stores.matches.get();
		const parentIndex = matches.findIndex((match) => match.routeId === routeId);
		const parentMatch = matches[parentIndex];
		parentGlobalNotFound = !!parentMatch._notFound;
		parentNotFoundError = parentMatch.error;
		childRouteId = matches[parentIndex + 1]?.routeId;
	} else {
		const parentMatchStore = router.stores.getMatchStore(routeId);
		[parentGlobalNotFound, parentNotFoundError] = useSelector(parentMatchStore, (match) => [!!match._notFound, match.error], { compare: outletMatchSelectionEqual });
		childRouteId = useSelector(router.stores.ids, (ids) => {
			return ids[ids.indexOf(routeId) + 1];
		});
	}
	if (parentGlobalNotFound) return renderRouteNotFound(router, router.routesById[routeId], parentNotFoundError);
	if (!childRouteId) return null;
	const nextMatch = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Match, { routeId: childRouteId });
	if (routeId === "__root__") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: renderPending(router),
		children: nextMatch
	});
	return nextMatch;
});
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/Transitioner.js
function settleOwner(owner, rendered) {
	const settle = owner[1];
	owner.length = 0;
	settle?.(rendered);
}
function Transitioner({ t }) {
	const router = useRouter();
	const acknowledgement = router._rendered ??= [];
	const mounted = import_react.useRef(false);
	router.startTransition = (fn, expected) => new Promise((resolve) => {
		settleOwner(acknowledgement, false);
		acknowledgement.push(expected, resolve);
		t(router);
		import_react.startTransition(fn);
	});
	useLayoutEffect(() => {
		const unsub = router.history.subscribe(router.load);
		if (mounted?.current) return unsub;
		if (mounted) mounted.current = true;
		router.updateLatestLocation();
		const location = router.latestLocation;
		const nextLocation = router.buildLocation({
			to: location.pathname,
			search: true,
			params: true,
			hash: true,
			state: true,
			_includeValidateSearch: true
		});
		if (trimPathRight(location.publicHref) !== trimPathRight(nextLocation.publicHref)) {
			router.commitLocation({
				...nextLocation,
				replace: true,
				ignoreBlocker: true
			});
			return unsub;
		}
		const resolvedLocation = router.stores.resolvedLocation.get();
		if (resolvedLocation?.href === location.href && resolvedLocation.state.__TSR_key === location.state.__TSR_key) acknowledgement.push(router.stores.matches.get(), (rendered) => {
			if (rendered) router.emit({
				type: "onRendered",
				...getLocationChangeInfo(resolvedLocation, resolvedLocation)
			});
		});
		else if (!router._tx) router.load({ sync: true }).catch(console.error);
		return unsub;
	}, [router, router.history]);
	return null;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/Matches.js
/**
* Internal component that renders the router's active match tree with
* suspense, error, and not-found boundaries. Rendered by `RouterProvider`.
*/
function Matches() {
	const router = useRouter();
	const rootRoute = router.routesById[rootRouteId];
	const pendingElement = renderPending(router, rootRoute);
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [!router.isServer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transitioner, { t: import_react.useState()[1] }), router.isServer || router.ssr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchesInner, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: pendingElement,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchesInner, {})
	})] });
	return router.options.InnerWrap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(router.options.InnerWrap, { children: inner }) : inner;
}
function MatchesInner() {
	const router = useRouter();
	const acknowledgement = router._rendered;
	const matches = router.isServer ? router.stores.matches.get() : useSelector(router.stores.matches, (value) => acknowledgement[0] ?? value);
	const match = matches[0];
	const routeId = match?.routeId;
	useLayoutEffect(() => {
		if (acknowledgement[0] === matches) settleOwner(acknowledgement, true);
	}, [acknowledgement, matches]);
	const matchComponent = routeId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Match, { routeId }) : null;
	return router.options.disableGlobalCatchBoundary ? matchComponent : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchBoundary, {
		getResetKey: () => match,
		onCatch: (error) => {
			console.warn(`Warning: The following error wasn't caught by any route! At the very least, consider setting an 'errorComponent' in your RootRoute!`);
			console.warn("Warning:", error);
		},
		children: matchComponent
	});
}
/**
* Create a matcher function for testing locations against route definitions.
*
* The returned function accepts standard navigation options (`to`, `params`,
* `search`, etc.) and returns either `false` (no match) or the matched params
* object when the route matches the current or pending location.
*
* Useful for conditional rendering and active UI states because it subscribes
* the component to the router state used for matching. The returned function's
* identity changes when that state changes. For imperative checks in event
* handlers, get the router with `useRouter` and call `router.matchRoute(...)`
* to avoid that subscription.
*
* @returns A `matchRoute(options)` function that returns `false` or params.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useMatchRouteHook
*/
function useMatchRoute() {
	const router = useRouter();
	if (router.isServer) return (opts) => {
		const { pending, caseSensitive, fuzzy, includeSearch, ...rest } = opts;
		return router.matchRoute(rest, {
			pending,
			caseSensitive,
			fuzzy,
			includeSearch
		});
	};
	return import_react.useCallback((opts) => {
		const { pending, caseSensitive, fuzzy, includeSearch, ...rest } = opts;
		return router.matchRoute(rest, {
			pending,
			caseSensitive,
			fuzzy,
			includeSearch
		});
	}, [
		router,
		useSelector(router.stores.location, (location) => location.href),
		useSelector(router.stores.resolvedLocation, (location) => location?.href),
		useSelector(router.stores.status)
	]);
}
/**
* Component that conditionally renders its children based on whether a route
* matches the provided `from`/`to` options. If `children` is a function, it
* receives the matched params object.
*
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/matchRouteComponent
*/
function MatchRoute(props) {
	const params = useMatchRoute()(props);
	if (typeof props.children === "function") return props.children(params);
	return params ? props.children : null;
}
function useMatches(opts) {
	const router = useRouter();
	if (router.isServer) {
		const matches = router.stores.matches.get();
		return opts?.select ? opts.select(matches) : matches;
	}
	return useSelector(router.stores.matches, useStructuralSharing(opts, router));
}
/**
* Read the presented route matches above the current match, or select a
* derived value from them.
*/
function useParentMatches(opts) {
	const contextRouteId = import_react.useContext(matchContext);
	return useMatches({
		select: (matches) => {
			matches = matches.slice(0, matches.findIndex((d) => d.routeId === contextRouteId));
			return opts?.select ? opts.select(matches) : matches;
		},
		structuralSharing: opts?.structuralSharing
	});
}
/**
* Read the presented route matches below the current match, or select a
* derived value from them.
*/
function useChildMatches(opts) {
	const contextRouteId = import_react.useContext(matchContext);
	return useMatches({
		select: (matches) => {
			matches = matches.slice(matches.findIndex((d) => d.routeId === contextRouteId) + 1);
			return opts?.select ? opts.select(matches) : matches;
		},
		structuralSharing: opts?.structuralSharing
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/routerStores.js
var getStoreFactory = (opts) => {
	if (opts.isServer) return {
		createMutableStore: createNonReactiveMutableStore,
		createReadonlyStore: createNonReactiveReadonlyStore,
		batch: (fn) => fn()
	};
	return {
		createMutableStore: createAtom,
		createReadonlyStore: createAtom,
		batch
	};
};
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/router.js
/**
* Creates a new Router instance for React.
*
* Pass the returned router to `RouterProvider` to enable routing.
* Notable options: `routeTree` (your route definitions) and `context`
* (required if the root route was created with `createRootRouteWithContext`).
*
* @param options Router options used to configure the router.
* @returns A Router instance to be provided to `RouterProvider`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRouterFunction
*/
var createRouter = (options) => {
	return new Router(options);
};
var Router = class extends RouterCore {
	constructor(options) {
		super(options, getStoreFactory);
	}
};
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/RouterProvider.js
/**
* Low-level provider that places the router into React context and optionally
* updates router options from props. Most apps should use `RouterProvider`.
*/
function RouterContextProvider({ router, children, ...rest }) {
	if (hasKeys(rest)) router.update({
		...router.options,
		...rest,
		context: {
			...router.options.context,
			...rest.context
		}
	});
	const provider = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(routerContext.Provider, {
		value: router,
		children
	});
	if (router.options.Wrap) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(router.options.Wrap, { children: provider });
	return provider;
}
/**
* Renders the current match presentation and provides the router to the React
* tree via context.
*
* Accepts mutable router options via props. Configure initialization-only
* options with `createRouter`.
*
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRouterFunction
*/
function RouterProvider({ router, ...rest }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RouterContextProvider, {
		router,
		...rest,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Matches, {})
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/ScrollRestoration.js
function useScrollRestoration() {
	setupScrollRestoration(useRouter(), true);
}
/**
* @deprecated Use the `scrollRestoration` router option instead.
*/
function ScrollRestoration(_props) {
	useScrollRestoration();
	console.warn("The ScrollRestoration component is deprecated. Use createRouter's `scrollRestoration` option instead.");
	return null;
}
function useElementScrollRestoration(options) {
	useScrollRestoration();
	return getElementScrollRestorationEntry(useRouter(), options);
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useBlocker.js
function _resolveBlockerOpts(opts, condition) {
	if (opts === void 0) return {
		shouldBlockFn: () => true,
		withResolver: false
	};
	if ("shouldBlockFn" in opts) return opts;
	if (typeof opts === "function") {
		const shouldBlock = Boolean(condition ?? true);
		const _customBlockerFn = async () => {
			if (shouldBlock) return await opts();
			return false;
		};
		return {
			shouldBlockFn: _customBlockerFn,
			enableBeforeUnload: shouldBlock,
			withResolver: false
		};
	}
	const shouldBlock = Boolean(opts.condition ?? true);
	const fn = opts.blockerFn;
	const _customBlockerFn = async () => {
		if (shouldBlock && fn !== void 0) return await fn();
		return shouldBlock;
	};
	return {
		shouldBlockFn: _customBlockerFn,
		enableBeforeUnload: shouldBlock,
		withResolver: fn === void 0
	};
}
function useBlocker(opts, condition) {
	const { shouldBlockFn, enableBeforeUnload = true, disabled = false, withResolver = false } = _resolveBlockerOpts(opts, condition);
	const router = useRouter();
	const { history } = router;
	const [resolver, setResolver] = import_react.useState({
		status: "idle",
		current: void 0,
		next: void 0,
		action: void 0,
		proceed: void 0,
		reset: void 0
	});
	import_react.useEffect(() => {
		const blockerFnComposed = async (blockerFnArgs) => {
			function getLocation(location) {
				const parsedLocation = router.parseLocation(location);
				const [, rawParams, foundRoute] = router.getMatchedRoutes(parsedLocation.pathname);
				if (foundRoute === void 0) return {
					routeId: "__notFound__",
					fullPath: parsedLocation.pathname,
					pathname: parsedLocation.pathname,
					params: rawParams,
					search: router.options.parseSearch(location.search)
				};
				return {
					routeId: foundRoute.id,
					fullPath: foundRoute.fullPath,
					pathname: parsedLocation.pathname,
					params: rawParams,
					search: router.options.parseSearch(location.search)
				};
			}
			const current = getLocation(blockerFnArgs.currentLocation);
			const next = getLocation(blockerFnArgs.nextLocation);
			if (current.routeId === "__notFound__" && next.routeId !== "__notFound__") return false;
			const shouldBlock = await shouldBlockFn({
				action: blockerFnArgs.action,
				current,
				next
			});
			if (!withResolver) return shouldBlock;
			if (!shouldBlock) return false;
			const canNavigateAsync = await new Promise((resolve) => {
				setResolver({
					status: "blocked",
					current,
					next,
					action: blockerFnArgs.action,
					proceed: () => resolve(false),
					reset: () => resolve(true)
				});
			});
			setResolver({
				status: "idle",
				current: void 0,
				next: void 0,
				action: void 0,
				proceed: void 0,
				reset: void 0
			});
			return canNavigateAsync;
		};
		return disabled ? void 0 : history.block({
			blockerFn: blockerFnComposed,
			enableBeforeUnload
		});
	}, [
		shouldBlockFn,
		enableBeforeUnload,
		disabled,
		withResolver,
		history,
		router
	]);
	return resolver;
}
var _resolvePromptBlockerArgs = (props) => {
	if ("shouldBlockFn" in props) return { ...props };
	const shouldBlock = Boolean(props.condition ?? true);
	const fn = props.blockerFn;
	const _customBlockerFn = async () => {
		if (shouldBlock && fn !== void 0) return await fn();
		return shouldBlock;
	};
	return {
		shouldBlockFn: _customBlockerFn,
		enableBeforeUnload: shouldBlock,
		withResolver: fn === void 0
	};
};
function Block(opts) {
	const { children, ...rest } = opts;
	const resolver = useBlocker(_resolvePromptBlockerArgs(rest));
	return children ? typeof children === "function" ? children(resolver) : children : null;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useRouterState.js
/**
* Subscribe to the router's state store with optional selection and
* structural sharing for render optimization.
*
* Options:
* - `select`: Project the full router state to a derived slice
* - `structuralSharing`: Replace-equal semantics for stable references
* - `router`: Read state from a specific router instance instead of context
*
* @returns The selected router state (or the full state by default).
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useRouterStateHook
*/
function useRouterState(opts) {
	const contextRouter = useRouter({ warn: opts?.router === void 0 });
	const router = opts?.router || contextRouter;
	if (router.isServer) {
		const state = router.stores.__store.get();
		return opts?.select ? opts.select(state) : state;
	}
	return useSelector(router.stores.__store, useStructuralSharing(opts, router));
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useLocation.js
/**
* Read the current location from the router state with optional selection.
* Useful for subscribing to just the pieces of location you care about.
*
* Options:
* - `select`: Project the `location` object to a derived value
* - `structuralSharing`: Enable structural sharing for stable references
*
* @returns The current location (or selected value).
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useLocationHook
*/
function useLocation(opts) {
	const router = useRouter();
	if (router.isServer) {
		const location = router.stores.location.get();
		return opts?.select ? opts.select(location) : location;
	}
	return useSelector(router.stores.location, useStructuralSharing(opts, router));
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useCanGoBack.js
function useCanGoBack() {
	const router = useRouter();
	if (router.isServer) return router.stores.location.get().state.__TSR_index !== 0;
	return useSelector(router.stores.location, (location) => location.state.__TSR_index !== 0);
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/Asset.js
var INLINE_CSS_HYDRATION_ATTR = "data-tsr-inline-css";
var noopScriptHandler = () => {};
function setScriptAttrs(script, attrs) {
	if (!attrs) return;
	for (const [key, value] of Object.entries(attrs)) if (key !== "suppressHydrationWarning" && value !== void 0 && value !== false) script.setAttribute(key, typeof value === "boolean" ? "" : String(value));
}
function Asset(asset) {
	const { attrs, children, nonce, preventScriptHoist } = asset;
	const innerHTML = import_react.useMemo(() => children === void 0 ? void 0 : { __html: children }, [children]);
	switch (asset.tag) {
		case "title": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", {
			...attrs,
			suppressHydrationWarning: true,
			children
		});
		case "meta": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			...attrs,
			suppressHydrationWarning: true
		});
		case "link": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("link", {
			...attrs,
			precedence: attrs?.precedence ?? (attrs?.rel === "stylesheet" ? "default" : void 0),
			nonce,
			suppressHydrationWarning: true
		});
		case "style":
			if (asset.inlineCss && (process.env.TSS_INLINE_CSS_ENABLED === "true" || process.env.TSS_INLINE_CSS_ENABLED === void 0 && void 0)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineCssStyle, {
				attrs,
				nonce,
				children
			});
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", {
				...attrs,
				dangerouslySetInnerHTML: innerHTML,
				nonce
			});
		case "script": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Script, {
			attrs,
			preventScriptHoist,
			children
		});
		default: return null;
	}
}
function InlineCssStyle({ attrs, children, nonce }) {
	const isInlineCssPlaceholder = children === void 0;
	const [hydratedInlineCss] = import_react.useState(() => {
		if (!isInlineCssPlaceholder || typeof document === "undefined") return;
		return document.querySelector(`style[${INLINE_CSS_HYDRATION_ATTR}]`)?.textContent ?? void 0;
	});
	const html = isInlineCssPlaceholder ? hydratedInlineCss ?? "" : children ?? "";
	const innerHTML = import_react.useMemo(() => ({ __html: html }), [html]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", {
		...attrs,
		[INLINE_CSS_HYDRATION_ATTR]: "",
		dangerouslySetInnerHTML: innerHTML,
		nonce,
		suppressHydrationWarning: true
	});
}
function Script({ attrs, children, preventScriptHoist }) {
	const router = useRouter();
	const hydrated = useHydrated();
	const innerHTML = import_react.useMemo(() => children === void 0 ? void 0 : { __html: children }, [children]);
	const dataScript = typeof attrs?.type === "string" && attrs.type !== "" && attrs.type !== "text/javascript" && attrs.type !== "module";
	if (attrs?.src && typeof children === "string" && children.trim().length) console.warn("[TanStack Router] <Script> received both `src` and `children`. The `children` content will be ignored. Remove `children` or remove `src`.");
	import_react.useEffect(() => {
		if (dataScript) return;
		if (attrs?.src) {
			const link = document.createElement("a");
			link.href = attrs.src;
			const normSrc = link.href;
			for (const el of document.scripts) if (el.src === normSrc) return;
			const script = document.createElement("script");
			setScriptAttrs(script, attrs);
			document.head.appendChild(script);
			return () => script.remove();
		}
		if (typeof children === "string") {
			const typeAttr = typeof attrs?.type === "string" ? attrs.type : "text/javascript";
			const nonceAttr = typeof attrs?.nonce === "string" ? attrs.nonce : void 0;
			for (const el of document.scripts) {
				if (el.hasAttribute("src")) continue;
				const sType = el.getAttribute("type") ?? "text/javascript";
				const sNonce = el.getAttribute("nonce") ?? void 0;
				if (el.textContent === children && sType === typeAttr && sNonce === nonceAttr) return;
			}
			const script = document.createElement("script");
			script.textContent = children;
			setScriptAttrs(script, attrs);
			document.head.appendChild(script);
			return () => script.remove();
		}
	}, [
		attrs,
		children,
		dataScript
	]);
	if (router.isServer) {
		if (attrs?.src) {
			if (!preventScriptHoist) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
				...attrs,
				suppressHydrationWarning: true
			});
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
				...attrs,
				onLoad: noopScriptHandler,
				suppressHydrationWarning: true
			});
		}
		if (typeof children === "string") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			...attrs,
			dangerouslySetInnerHTML: innerHTML,
			suppressHydrationWarning: true
		});
		return null;
	}
	if (dataScript && typeof children === "string") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
		...attrs,
		suppressHydrationWarning: true,
		dangerouslySetInnerHTML: innerHTML
	});
	if (!hydrated) {
		if (attrs?.src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			...attrs,
			suppressHydrationWarning: true
		});
		if (typeof children === "string") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			...attrs,
			dangerouslySetInnerHTML: innerHTML,
			suppressHydrationWarning: true
		});
	}
	return null;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/headContentUtils.js
function buildTagsFromMatches(router, nonce, matches, assetCrossOrigin) {
	matches = _getAssetMatches(matches);
	const routeMeta = matches.map((match) => match.meta).filter((meta) => meta !== void 0);
	const resultMeta = [];
	const metaByAttribute = {};
	let title;
	for (let i = routeMeta.length - 1; i >= 0; i--) {
		const metas = routeMeta[i];
		for (let j = metas.length - 1; j >= 0; j--) {
			const m = metas[j];
			if (!m) continue;
			if (m.title) {
				if (!title) title = {
					tag: "title",
					children: m.title
				};
			} else if ("script:ld+json" in m) try {
				const json = JSON.stringify(m["script:ld+json"]);
				resultMeta.push({
					tag: "script",
					attrs: { type: "application/ld+json" },
					children: escapeHtml(json)
				});
			} catch {}
			else {
				const attribute = m.name ?? m.property;
				if (attribute) {
					if (metaByAttribute[attribute]) continue;
					else metaByAttribute[attribute] = true;
				}
				resultMeta.push({
					tag: "meta",
					attrs: {
						...m,
						nonce
					}
				});
			}
		}
	}
	if (title) resultMeta.push(title);
	if (nonce) resultMeta.push({
		tag: "meta",
		attrs: {
			property: "csp-nonce",
			content: nonce
		}
	});
	resultMeta.reverse();
	const constructedLinks = matches.flatMap((match) => match.links ?? []).filter((link) => link !== void 0).map((link) => ({
		tag: "link",
		attrs: {
			...link,
			nonce
		}
	}));
	const manifest = router.ssr?.manifest;
	const manifestCssTags = [];
	if (manifest) {
		matches.forEach((match) => {
			(manifest.routes[match.routeId]?.css)?.forEach((link) => {
				const resolvedLink = resolveManifestCssLink(link);
				manifestCssTags.push({
					tag: "link",
					attrs: {
						rel: "stylesheet",
						...resolvedLink,
						crossOrigin: getAssetCrossOrigin(assetCrossOrigin, "stylesheet") ?? resolvedLink.crossOrigin,
						suppressHydrationWarning: true,
						nonce
					}
				});
			});
		});
		if (manifest.inlineStyle) manifestCssTags.push({
			tag: "style",
			attrs: {
				...manifest.inlineStyle.attrs,
				nonce
			},
			children: manifest.inlineStyle.children,
			inlineCss: true
		});
	}
	const preloadLinks = [];
	if (manifest) matches.forEach((match) => {
		manifest.routes[match.routeId]?.preloads?.forEach((preload) => {
			preloadLinks.push({
				tag: "link",
				attrs: {
					...getScriptPreloadAttrs(manifest, preload, assetCrossOrigin),
					nonce
				}
			});
		});
	});
	const styles = matches.flatMap((match) => match.styles ?? []).filter((style) => style !== void 0).map(({ children, ...attrs }) => ({
		tag: "style",
		attrs: {
			...attrs,
			nonce
		},
		children
	}));
	const headScripts = matches.flatMap((match) => match.headScripts ?? []).filter((script) => script !== void 0).map(({ children, ...script }) => ({
		tag: "script",
		attrs: {
			...script,
			nonce
		},
		children
	}));
	const tags = [];
	appendUniqueUserTags(tags, resultMeta);
	tags.push(...preloadLinks);
	appendUniqueUserTags(tags, constructedLinks);
	tags.push(...manifestCssTags);
	appendUniqueUserTags(tags, styles);
	appendUniqueUserTags(tags, headScripts);
	return tags;
}
/**
* Build the head/link/meta/script tags from the renderable presented prefix.
* Used internally by `HeadContent`.
*/
var useTags = (assetCrossOrigin) => {
	const router = useRouter();
	const nonce = router.options.ssr?.nonce;
	if (router.isServer) return buildTagsFromMatches(router, nonce, router.stores.matches.get(), assetCrossOrigin);
	const selectTags = import_react.useCallback((matches) => buildTagsFromMatches(router, nonce, matches, assetCrossOrigin), [
		assetCrossOrigin,
		nonce,
		router
	]);
	return useSelector(router.stores.matches, selectTags, { compare: deepEqual });
};
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/Scripts.js
var routeScriptAttrs = { suppressHydrationWarning: true };
/**
* Render body script tags collected from route matches and SSR manifests.
* During streaming SSR, `<Scripts>` marks where late hydration scripts may
* begin to be inserted.
*/
var Scripts = () => {
	const router = useRouter();
	const nonce = router.options.ssr?.nonce;
	const getParts = (matches) => {
		const parts = getSsrBodyScriptParts(matches, router.ssr?.manifest, nonce, routeScriptAttrs);
		for (const script of parts[1]) if (typeof script.attrs?.src === "string") {
			const scriptWithHoist = script;
			scriptWithHoist.preventScriptHoist = true;
		}
		return parts;
	};
	const getScripts = (matches) => {
		return composeSsrBodyScripts(getParts(matches));
	};
	if (router.isServer) return renderScripts(composeSsrBodyScripts(getParts(router.stores.matches.get()), router.serverSsr?.takeInitialHydrationScriptTags()));
	return renderScripts(useSelector(router.stores.matches, getScripts, { compare: deepEqual }));
};
function renderScripts(scripts) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: scripts.map((asset, i) => /* @__PURE__ */ (0, import_react.createElement)(Asset, {
		...asset,
		key: `tsr-scripts-${asset.tag}-${i}`
	})) });
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/HeadContent.dev.js
/**
* Render route-managed head tags (title, meta, links, styles, head scripts).
* Place inside the document head of your app shell.
*
* Development version: filters out dev styles link after hydration and
* includes a fallback cleanup effect for hydration mismatch cases.
*
* @link https://tanstack.com/router/latest/docs/framework/react/guide/document-head-management
*/
function HeadContent(props) {
	const tags = useTags(props.assetCrossOrigin);
	const nonce = useRouter().options.ssr?.nonce;
	const hydrated = useHydrated();
	import_react.useEffect(() => {
		if (hydrated) document.querySelectorAll(`link[${DEV_STYLES_ATTR}]`).forEach((el) => el.remove());
	}, [hydrated]);
	const filteredTags = hydrated ? tags.filter((tag) => tag.tag !== "link" || tag.attrs?.["data-tanstack-router-dev-styles"] !== true) : tags;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: filteredTags.map((tag) => /* @__PURE__ */ (0, import_react.createElement)(Asset, {
		...tag,
		key: `tsr-meta-${JSON.stringify(tag)}`,
		nonce
	})) });
}
//#endregion
export { Asset, Await, Block, CatchBoundary, CatchNotFound, ClientOnly, DEFAULT_PROTOCOL_ALLOWLIST, DefaultGlobalNotFound, ErrorComponent, FileRoute, FileRouteLoader, HeadContent, LazyRoute, Link, Match, MatchRoute, Matches, Navigate, NotFoundRoute, Outlet, RootRoute, Route, RouteApi, Router, RouterContextProvider, RouterProvider, ScriptOnce, Scripts, ScrollRestoration, SearchParamError, cleanPath, composeRewrites, createBrowserHistory, createControlledPromise, createFileRoute, createHashHistory, createHistory, createLazyFileRoute, createLazyRoute, createLink, createMemoryHistory, createRootRoute, createRootRouteWithContext, createRoute, createRouteMask, createRouter, createRouterConfig, createSerializationAdapter, deepEqual, defaultParseSearch, defaultStringifySearch, defer, functionalUpdate, getRouteApi, interpolatePath, isMatch, isNotFound, isRedirect, joinPaths, lazyFn, lazyRouteComponent, linkOptions, notFound, parseSearchWith, reactUse, redirect, replaceEqualDeep, resolvePath, retainSearchParams, rootRouteId, rootRouteWithContext, stringifySearchWith, stripSearchParams, trimPath, trimPathLeft, trimPathRight, useAwaited, useBlocker, useCanGoBack, useChildMatches, useElementScrollRestoration, useHydrated, useLayoutEffect, useLinkProps, useLoaderData, useLoaderDeps, useLocation, useMatch, useMatchRoute, useMatches, useNavigate, useParams, useParentMatches, useRouteContext, useRouter, useRouterState, useSearch, useTags };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHRhbnN0YWNrX3JlYWN0LXJvdXRlci5qcyIsIm5hbWVzIjpbIm5vcm1hbGl6ZSIsIlNVQ0NFU1MiLCJFUlJPUiIsIk5PVF9GT1VORCIsIlJFRElSRUNURUQiLCJ3YWl0Rm9yIiwiZ2V0Um91dGUiLCJub3JtYWxpemUiLCJub3JtYWxpemVFcnJvciIsIm1hdGVyaWFsaXplUmVkaXJlY3QiLCJjb250ZXh0dWFsaXplIiwiZ2V0TG9hZGVyQ29udGV4dCIsImNyZWF0ZUxvYWRlclRhc2siLCJnZXROb3RGb3VuZEJvdW5kYXJ5IiwicHJvamVjdExhbmUiLCJcInVzZVwiIiwidXNlQ2FsbGJhY2siLCJ1c2VTeW5jRXh0ZXJuYWxTdG9yZVdpdGhTZWxlY3RvciIsIlNjcm9sbFJlc3RvcmF0aW9uIiwianN4IiwiU2Nyb2xsUmVzdG9yYXRpb24iLCJGcmFnbWVudCIsIkZyYWdtZW50IiwiRnJhZ21lbnQiXSwic291cmNlcyI6WyIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vbm90LWZvdW5kLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3Jvb3QuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vcmVkaXJlY3QuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vdXRpbHMuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vcGF0aC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9zaWV2ZS1jYWNoZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9uZXctcHJvY2Vzcy1yb3V0ZS10cmVlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3Njcm9sbC1yZXN0b3JhdGlvbi5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9xc3MuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vc2VhcmNoUGFyYW1zLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3Jld3JpdGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vc3RvcmVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL2hpc3RvcnkvZGlzdC9lc20vaW5kZXguanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vcm91dGVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL2xvYWQtY2xpZW50LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL2F3YWl0LXNpZ25hbC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9sb2FkLXNlcnZlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXRpbHMuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vZGVmZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vbGluay5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9tYW5pZmVzdC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9NYXRjaGVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3Nzci9ib2R5U2NyaXB0cy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9yb3V0ZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9jb25maWcuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vc2VhcmNoTWlkZGxld2FyZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9zc3Ivc2VyaWFsaXplci90cmFuc2Zvcm1lci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vYXdhaXRlZC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vbm9uUm91dGVDb21wb25lbnRDb250ZXh0LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9DYXRjaEJvdW5kYXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9DbGllbnRPbmx5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9yb3V0ZXJDb250ZXh0LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VSb3V0ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL21hdGNoQ29udGV4dC5qcyIsIi4uLy4uL0B0YW5zdGFjay9zdG9yZS9kaXN0L2FsaWVuLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3N0b3JlL2Rpc3QvYXRvbS5qcyIsIi4uLy4uL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlL2Nqcy91c2Utc3luYy1leHRlcm5hbC1zdG9yZS1zaGltLmRldmVsb3BtZW50LmpzIiwiLi4vLi4vdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUvc2hpbS9pbmRleC5qcyIsIi4uLy4uL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlL2Nqcy91c2Utc3luYy1leHRlcm5hbC1zdG9yZS1zaGltL3dpdGgtc2VsZWN0b3IuZGV2ZWxvcG1lbnQuanMiLCIuLi8uLi91c2Utc3luYy1leHRlcm5hbC1zdG9yZS9zaGltL3dpdGgtc2VsZWN0b3IuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtc3RvcmUvZGlzdC91c2VTZWxlY3Rvci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXNlTWF0Y2guanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3VzZUxvYWRlckRhdGEuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3VzZUxvYWRlckRlcHMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3VzZVBhcmFtcy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXNlU2VhcmNoLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VOYXZpZ2F0ZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXNlUm91dGVDb250ZXh0LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9saW5rLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9yb3V0ZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vZmlsZVJvdXRlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9sYXp5Um91dGVDb21wb25lbnQuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL25vdC1mb3VuZC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vU2NyaXB0T25jZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vcmVuZGVyUm91dGVOb3RGb3VuZC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9zY3JvbGwtcmVzdG9yYXRpb24tc2NyaXB0L2NsaWVudC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vc2Nyb2xsLXJlc3RvcmF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9NYXRjaC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vVHJhbnNpdGlvbmVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9NYXRjaGVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9yb3V0ZXJTdG9yZXMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3JvdXRlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vUm91dGVyUHJvdmlkZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL1Njcm9sbFJlc3RvcmF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VCbG9ja2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VSb3V0ZXJTdGF0ZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXNlTG9jYXRpb24uanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3VzZUNhbkdvQmFjay5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vQXNzZXQuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL2hlYWRDb250ZW50VXRpbHMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL1NjcmlwdHMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL0hlYWRDb250ZW50LmRldi5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyNyZWdpb24gc3JjL25vdC1mb3VuZC50c1xuLyoqXG4qIENyZWF0ZSBhIG5vdC1mb3VuZCBlcnJvciBvYmplY3QgcmVjb2duaXplZCBieSBUYW5TdGFjayBSb3V0ZXIuXG4qXG4qIFRocm93IHRoaXMgZnJvbSBsb2FkZXJzL2FjdGlvbnMgdG8gdHJpZ2dlciB0aGUgbmVhcmVzdCBgbm90Rm91bmRDb21wb25lbnRgLlxuKiBVc2UgYHJvdXRlSWRgIHRvIHRhcmdldCBhIHNwZWNpZmljIHJvdXRlJ3Mgbm90LWZvdW5kIGJvdW5kYXJ5LiBJZiBgdGhyb3dgXG4qIGlzIHRydWUsIHRoZSBlcnJvciBpcyB0aHJvd24gaW5zdGVhZCBvZiByZXR1cm5lZC5cbipcbiogQHBhcmFtIG9wdGlvbnMgT3B0aW9uYWwgc2V0dGluZ3MgaW5jbHVkaW5nIGByb3V0ZUlkYCwgYGhlYWRlcnNgLCBhbmQgYHRocm93YC5cbiogQHJldHVybnMgQSBub3QtZm91bmQgZXJyb3Igb2JqZWN0IHRoYXQgY2FuIGJlIHRocm93biBvciByZXR1cm5lZC5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL3JvdXRlci9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9ub3RGb3VuZEZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gbm90Rm91bmQob3B0aW9ucyA9IHt9KSB7XG5cdG9wdGlvbnMuaXNOb3RGb3VuZCA9IHRydWU7XG5cdGlmIChvcHRpb25zLnRocm93KSB0aHJvdyBvcHRpb25zO1xuXHRyZXR1cm4gb3B0aW9ucztcbn1cbi8qKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIFRhblN0YWNrIFJvdXRlciBub3QtZm91bmQgZXJyb3IuICovXG5mdW5jdGlvbiBpc05vdEZvdW5kKG9iaikge1xuXHRyZXR1cm4gb2JqPy5pc05vdEZvdW5kID09PSB0cnVlO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpc05vdEZvdW5kLCBub3RGb3VuZCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1ub3QtZm91bmQuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9yb290LnRzXG4vKiogU3RhYmxlIGlkZW50aWZpZXIgdXNlZCBmb3IgdGhlIHJvb3Qgcm91dGUgaW4gYSByb3V0ZSB0cmVlLiAqL1xuY29uc3Qgcm9vdFJvdXRlSWQgPSBcIl9fcm9vdF9fXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHJvb3RSb3V0ZUlkIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvb3QuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9yZWRpcmVjdC50c1xuLyoqXG4qIENyZWF0ZSBhIHJlZGlyZWN0IFJlc3BvbnNlIHVuZGVyc3Rvb2QgYnkgVGFuU3RhY2sgUm91dGVyLlxuKlxuKiBVc2UgZnJvbSByb3V0ZSBgbG9hZGVyYC9gYmVmb3JlTG9hZGAgb3Igc2VydmVyIGZ1bmN0aW9ucyB0byB0cmlnZ2VyIGFcbiogbmF2aWdhdGlvbi4gSWYgYHRocm93OiB0cnVlYCBpcyBzZXQsIHRoZSByZWRpcmVjdCBpcyB0aHJvd24gaW5zdGVhZCBvZlxuKiByZXR1cm5lZC4gRXh0ZXJuYWwgYGhyZWZgIHZhbHVlcyBhcmUgY2xhc3NpZmllZCBhcyBmdWxsLWRvY3VtZW50XG4qIG5hdmlnYXRpb25zIHdoZW4gdGhlIHJvdXRlciByZXNvbHZlcyB0aGUgcmVkaXJlY3QuXG4qXG4qIEBwYXJhbSBvcHRzIE9wdGlvbnMgZm9yIHRoZSByZWRpcmVjdC4gQ29tbW9uIGZpZWxkczpcbiogLSBgaHJlZmA6IGFic29sdXRlIFVSTCBmb3IgZXh0ZXJuYWwgcmVkaXJlY3RzLlxuKiAtIGBzdGF0dXNDb2RlYDogSFRUUCBzdGF0dXMgY29kZSB0byB1c2UgKGRlZmF1bHRzIHRvIDMwNykuXG4qIC0gYGhlYWRlcnNgOiBhZGRpdGlvbmFsIGhlYWRlcnMgdG8gaW5jbHVkZSBvbiB0aGUgUmVzcG9uc2UuXG4qIC0gU3RhbmRhcmQgbmF2aWdhdGlvbiBvcHRpb25zIGxpa2UgYHRvYCwgYHBhcmFtc2AsIGBzZWFyY2hgLCBgcmVwbGFjZWAsXG4qICAgYW5kIGByZWxvYWREb2N1bWVudGAgZm9yIGludGVybmFsIHJlZGlyZWN0cy5cbiogQHJldHVybnMgQSBSZXNwb25zZSBhdWdtZW50ZWQgd2l0aCByb3V0ZXIgbmF2aWdhdGlvbiBvcHRpb25zLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvcmVkaXJlY3RGdW5jdGlvblxuKi9cbmZ1bmN0aW9uIHJlZGlyZWN0KG9wdHMpIHtcblx0b3B0cy5zdGF0dXNDb2RlID0gb3B0cy5zdGF0dXNDb2RlIHx8IG9wdHMuY29kZSB8fCAzMDc7XG5cdGNvbnN0IGhlYWRlcnMgPSBuZXcgSGVhZGVycyhvcHRzLmhlYWRlcnMpO1xuXHRpZiAob3B0cy5ocmVmICYmIGhlYWRlcnMuZ2V0KFwiTG9jYXRpb25cIikgPT09IG51bGwpIGhlYWRlcnMuc2V0KFwiTG9jYXRpb25cIiwgb3B0cy5ocmVmKTtcblx0Y29uc3QgcmVzcG9uc2UgPSBuZXcgUmVzcG9uc2UobnVsbCwge1xuXHRcdHN0YXR1czogb3B0cy5zdGF0dXNDb2RlLFxuXHRcdGhlYWRlcnNcblx0fSk7XG5cdHJlc3BvbnNlLm9wdGlvbnMgPSBvcHRzO1xuXHRpZiAob3B0cy50aHJvdykgdGhyb3cgcmVzcG9uc2U7XG5cdHJldHVybiByZXNwb25zZTtcbn1cbi8qKiBDaGVjayB3aGV0aGVyIGEgdmFsdWUgaXMgYSBUYW5TdGFjayBSb3V0ZXIgcmVkaXJlY3QgUmVzcG9uc2UuICovXG5mdW5jdGlvbiBpc1JlZGlyZWN0KG9iaikge1xuXHRyZXR1cm4gb2JqIGluc3RhbmNlb2YgUmVzcG9uc2UgJiYgISFvYmoub3B0aW9ucztcbn1cbi8qKiBUcnVlIGlmIHZhbHVlIGlzIGEgcmVkaXJlY3Qgd2l0aCBhIHJlc29sdmVkIGBocmVmYCBsb2NhdGlvbi4gKi9cbmZ1bmN0aW9uIGlzUmVzb2x2ZWRSZWRpcmVjdChvYmopIHtcblx0cmV0dXJuIGlzUmVkaXJlY3Qob2JqKSAmJiAhIW9iai5vcHRpb25zLmhyZWY7XG59XG4vKiogUGFyc2UgYSBzZXJpYWxpemVkIHJlZGlyZWN0IG9iamVjdCBiYWNrIGludG8gYSByZWRpcmVjdCBSZXNwb25zZS4gKi9cbmZ1bmN0aW9uIHBhcnNlUmVkaXJlY3Qob2JqKSB7XG5cdGlmIChvYmogIT09IG51bGwgJiYgdHlwZW9mIG9iaiA9PT0gXCJvYmplY3RcIiAmJiBvYmouaXNTZXJpYWxpemVkUmVkaXJlY3QpIHJldHVybiByZWRpcmVjdChvYmopO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpc1JlZGlyZWN0LCBpc1Jlc29sdmVkUmVkaXJlY3QsIHBhcnNlUmVkaXJlY3QsIHJlZGlyZWN0IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlZGlyZWN0LmpzLm1hcCIsImltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuLy8jcmVnaW9uIHNyYy91dGlscy50c1xuLyoqXG4qIFJldHVybiB0aGUgbGFzdCBlbGVtZW50IG9mIGFuIGFycmF5LlxuKiBJbnRlbmRlZCBmb3Igbm9uLWVtcHR5IGFycmF5cyB1c2VkIHdpdGhpbiByb3V0ZXIgaW50ZXJuYWxzLlxuKi9cbmZ1bmN0aW9uIGxhc3QoYXJyKSB7XG5cdHJldHVybiBhcnJbYXJyLmxlbmd0aCAtIDFdO1xufVxuLyoqXG4qIEFwcGx5IGEgdmFsdWUtb3ItdXBkYXRlciB0byBhIHByZXZpb3VzIHZhbHVlLlxuKiBBY2NlcHRzIGVpdGhlciBhIGxpdGVyYWwgdmFsdWUgb3IgYSBmdW5jdGlvbiBvZiB0aGUgcHJldmlvdXMgdmFsdWUuXG4qL1xuZnVuY3Rpb24gZnVuY3Rpb25hbFVwZGF0ZSh1cGRhdGVyLCBwcmV2aW91cykge1xuXHRpZiAodHlwZW9mIHVwZGF0ZXIgPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIHVwZGF0ZXIocHJldmlvdXMpO1xuXHRyZXR1cm4gdXBkYXRlcjtcbn1cbmNvbnN0IGhhc093biA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5mdW5jdGlvbiBoYXNLZXlzKG9iaikge1xuXHRmb3IgKGNvbnN0IGtleSBpbiBvYmopIGlmIChoYXNPd24uY2FsbChvYmosIGtleSkpIHJldHVybiB0cnVlO1xuXHRyZXR1cm4gZmFsc2U7XG59XG5jb25zdCBjcmVhdGVOdWxsID0gKCkgPT4gT2JqZWN0LmNyZWF0ZShudWxsKTtcbmNvbnN0IG51bGxSZXBsYWNlRXF1YWxEZWVwID0gKHByZXYsIG5leHQpID0+IHJlcGxhY2VFcXVhbERlZXAocHJldiwgbmV4dCwgdHJ1ZSk7XG5mdW5jdGlvbiByZXBsYWNlRXF1YWxEZWVwKHByZXYsIG5leHQsIF9udWxsUHJvdG8sIF9kZXB0aCA9IDApIHtcblx0aWYgKGlzU2VydmVyKSByZXR1cm4gbmV4dDtcblx0aWYgKHByZXYgPT09IG5leHQpIHJldHVybiBwcmV2O1xuXHRpZiAoX2RlcHRoKysgPiA1MDApIHJldHVybiBuZXh0O1xuXHRjb25zdCBhcnJheSA9IEFycmF5LmlzQXJyYXkocHJldikgJiYgQXJyYXkuaXNBcnJheShuZXh0KTtcblx0aWYgKCFhcnJheSAmJiAhKGlzUGxhaW5PYmplY3QocHJldikgJiYgaXNQbGFpbk9iamVjdChuZXh0KSkpIHJldHVybiBuZXh0O1xuXHRjb25zdCBwcmV2S2V5cyA9IE9iamVjdC5rZXlzKHByZXYpO1xuXHRjb25zdCBwcmV2aW91c0NvdW50ID0gcHJldktleXMubGVuZ3RoO1xuXHRjb25zdCBuZXh0S2V5cyA9IE9iamVjdC5rZXlzKG5leHQpO1xuXHRjb25zdCBsZW5ndGggPSBuZXh0S2V5cy5sZW5ndGg7XG5cdGlmIChhcnJheSA/IHByZXZpb3VzQ291bnQgIT09IHByZXYubGVuZ3RoIHx8IGxlbmd0aCAhPT0gbmV4dC5sZW5ndGggfHwgcHJldmlvdXNDb3VudCAmJiBsYXN0KHByZXZLZXlzKSAhPT0gYCR7cHJldmlvdXNDb3VudCAtIDF9YCB8fCBsZW5ndGggJiYgbGFzdChuZXh0S2V5cykgIT09IGAke2xlbmd0aCAtIDF9YCA6IHByZXZpb3VzQ291bnQgIT09IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHByZXYpLmxlbmd0aCB8fCBsZW5ndGggIT09IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKG5leHQpLmxlbmd0aCB8fCBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKG5leHQpLmxlbmd0aCkgcmV0dXJuIG5leHQ7XG5cdGxldCBpID0gMDtcblx0bGV0IGNoaWxkO1xuXHRsZXQgcHJldmlvdXM7XG5cdGxldCBrZXk7XG5cdGlmIChhcnJheSkge1xuXHRcdGZvciAoOyBpIDwgbGVuZ3RoOyBpKyspIHtcblx0XHRcdGtleSA9IGk7XG5cdFx0XHRwcmV2aW91cyA9IHByZXZba2V5XTtcblx0XHRcdGNoaWxkID0gbmV4dFtrZXldO1xuXHRcdFx0Y2hpbGQgPSBwcmV2aW91cyA9PT0gY2hpbGQgPyBwcmV2aW91cyA6IHR5cGVvZiBwcmV2aW91cyA9PT0gXCJvYmplY3RcIiA/IHJlcGxhY2VFcXVhbERlZXAocHJldmlvdXMsIGNoaWxkLCBfbnVsbFByb3RvLCBfZGVwdGgpIDogY2hpbGQ7XG5cdFx0XHRpZiAoY2hpbGQgIT09IHByZXZpb3VzKSBicmVhaztcblx0XHR9XG5cdFx0aWYgKGkgPT09IGxlbmd0aCAmJiBwcmV2aW91c0NvdW50ID09PSBsZW5ndGgpIHJldHVybiBwcmV2O1xuXHR9IGVsc2Uge1xuXHRcdGxldCBlcXVhbCA9IHByZXZpb3VzQ291bnQgPT09IGxlbmd0aDtcblx0XHRsZXQgdW5jaGFuZ2VkID0gdHJ1ZTtcblx0XHRmb3IgKDsgaSA8IGxlbmd0aDsgaSsrKSB7XG5cdFx0XHRrZXkgPSBuZXh0S2V5c1tpXTtcblx0XHRcdHByZXZpb3VzID0gcHJldltrZXldO1xuXHRcdFx0Y29uc3QgaW5jb21pbmcgPSBuZXh0W2tleV07XG5cdFx0XHRjaGlsZCA9IHByZXZpb3VzID09PSBpbmNvbWluZyA/IHByZXZpb3VzIDogdHlwZW9mIHByZXZpb3VzID09PSBcIm9iamVjdFwiID8gcmVwbGFjZUVxdWFsRGVlcChwcmV2aW91cywgaW5jb21pbmcsIF9udWxsUHJvdG8sIF9kZXB0aCkgOiBpbmNvbWluZztcblx0XHRcdGVxdWFsICYmPSBjaGlsZCA9PT0gcHJldmlvdXMgJiYgKHByZXZLZXlzW2ldID09PSBrZXkgfHwgaGFzT3duLmNhbGwocHJldiwga2V5KSk7XG5cdFx0XHR1bmNoYW5nZWQgJiY9IE9iamVjdC5pcyhjaGlsZCwgaW5jb21pbmcpO1xuXHRcdFx0cHJldktleXNbaV0gPSBjaGlsZDtcblx0XHR9XG5cdFx0aWYgKGVxdWFsKSByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhwcmV2KS5sZW5ndGggPyBuZXh0IDogcHJldjtcblx0XHRpZiAodW5jaGFuZ2VkKSByZXR1cm4gbmV4dDtcblx0fVxuXHRjb25zdCBjb3B5ID0gYXJyYXkgPyBuZXh0S2V5cy5maWxsKDApIDogX251bGxQcm90byA/IGNyZWF0ZU51bGwoKSA6IHt9O1xuXHRmb3IgKGxldCBqID0gMDsgaiA8IGxlbmd0aDsgaisrKSB7XG5cdFx0a2V5ID0gYXJyYXkgPyBqIDogbmV4dEtleXNbal07XG5cdFx0aWYgKGFycmF5KSB7XG5cdFx0XHRwcmV2aW91cyA9IHByZXZba2V5XTtcblx0XHRcdGlmIChqID4gaSkge1xuXHRcdFx0XHRjaGlsZCA9IG5leHRba2V5XTtcblx0XHRcdFx0Y2hpbGQgPSBwcmV2aW91cyA9PT0gY2hpbGQgPyBwcmV2aW91cyA6IHR5cGVvZiBwcmV2aW91cyA9PT0gXCJvYmplY3RcIiA/IHJlcGxhY2VFcXVhbERlZXAocHJldmlvdXMsIGNoaWxkLCBfbnVsbFByb3RvLCBfZGVwdGgpIDogY2hpbGQ7XG5cdFx0XHR9XG5cdFx0XHRjb3B5W2tleV0gPSBqIDwgaSA/IHByZXZpb3VzIDogY2hpbGQ7XG5cdFx0fSBlbHNlIGNvcHlba2V5XSA9IHByZXZLZXlzW2pdO1xuXHR9XG5cdHJldHVybiBjb3B5O1xufVxuZnVuY3Rpb24gaXNQbGFpbk9iamVjdChvKSB7XG5cdGlmICghbyB8fCB0eXBlb2YgbyAhPT0gXCJvYmplY3RcIikgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gKE9iamVjdC5nZXRQcm90b3R5cGVPZihvKT8uY29uc3RydWN0b3IgPz8gT2JqZWN0KSA9PT0gT2JqZWN0O1xufVxuLyoqXG4qIFBlcmZvcm0gYSBkZWVwIGVxdWFsaXR5IGNoZWNrIG9wdGltaXplZCBmb3Igcm91dGVyIHN0YXRlIGNvbXBhcmlzb25zLlxuKlxuKiAtIGBwYXJ0aWFsYDogYGJgIG1heSBvbWl0IGtleXMgdGhhdCBgYWAgaGFzIChhcnJheXMgc3RheSBsZW5ndGgtZXhhY3QpLlxuKiAtIGBleHBsaWNpdFVuZGVmaW5lZGA6IGtleXMgaG9sZGluZyBgdW5kZWZpbmVkYCB0YWtlIHBhcnQgaW4gdGhlIGNvbXBhcmlzb25cbiogICBpbnN0ZWFkIG9mIGJlaW5nIGlnbm9yZWQuXG4qXG4qIEludGVybmFsOiB0aGUgZmxhZ3MgYXJlIHBvc2l0aW9uYWwgc28gaG90IGNhbGxlcnMgcGFzcyBubyBvcHRpb25zIG9iamVjdC5cbiovXG5mdW5jdGlvbiBkZWVwRXF1YWwoYSwgYiwgcGFydGlhbCwgZXhwbGljaXRVbmRlZmluZWQpIHtcblx0aWYgKGEgPT09IGIpIHJldHVybiB0cnVlO1xuXHRpZiAoQXJyYXkuaXNBcnJheShhKSAmJiBBcnJheS5pc0FycmF5KGIpKSB7XG5cdFx0aWYgKGEubGVuZ3RoICE9PSBiLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXHRcdGZvciAobGV0IGkgPSAwLCBsID0gYS5sZW5ndGg7IGkgPCBsOyBpKyspIHtcblx0XHRcdGNvbnN0IGF2ID0gYVtpXTtcblx0XHRcdGNvbnN0IGJ2ID0gYltpXTtcblx0XHRcdGlmIChhdiAhPT0gYnYgJiYgIWRlZXBFcXVhbChhdiwgYnYsIHBhcnRpYWwsIGV4cGxpY2l0VW5kZWZpbmVkKSkgcmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxuXHRpZiAoaXNQbGFpbk9iamVjdChhKSAmJiBpc1BsYWluT2JqZWN0KGIpKSB7XG5cdFx0aWYgKHBhcnRpYWwpIHtcblx0XHRcdGZvciAoY29uc3QgayBpbiBiKSBpZiAoZXhwbGljaXRVbmRlZmluZWQgfHwgYltrXSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdGlmICghZGVlcEVxdWFsKGFba10sIGJba10sIHBhcnRpYWwsIGV4cGxpY2l0VW5kZWZpbmVkKSkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fVxuXHRcdGxldCBhQ291bnQgPSAwO1xuXHRcdGlmIChleHBsaWNpdFVuZGVmaW5lZCkgYUNvdW50ID0gT2JqZWN0LmtleXMoYSkubGVuZ3RoO1xuXHRcdGVsc2UgZm9yIChjb25zdCBrIGluIGEpIGlmIChhW2tdICE9PSB2b2lkIDApIGFDb3VudCsrO1xuXHRcdGZvciAoY29uc3QgayBpbiBiKSBpZiAoZXhwbGljaXRVbmRlZmluZWQgfHwgYltrXSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRpZiAoYUNvdW50LS0gPT09IDAgfHwgIWRlZXBFcXVhbChhW2tdLCBiW2tdLCBwYXJ0aWFsLCBleHBsaWNpdFVuZGVmaW5lZCkpIHJldHVybiBmYWxzZTtcblx0XHR9XG5cdFx0cmV0dXJuIGFDb3VudCA9PT0gMDtcblx0fVxuXHRyZXR1cm4gZmFsc2U7XG59XG4vKipcbiogQ3JlYXRlIGEgcHJvbWlzZSB3aXRoIGV4cG9zZWQgcmVzb2x2ZS9yZWplY3QgYW5kIHN0YXR1cyBmaWVsZHMuXG4qIFVzZWZ1bCBmb3IgY29vcmRpbmF0aW5nIGFzeW5jIHJvdXRlciBsaWZlY3ljbGUgb3BlcmF0aW9ucy5cbiovXG5mdW5jdGlvbiBjcmVhdGVDb250cm9sbGVkUHJvbWlzZShvblJlc29sdmUpIHtcblx0bGV0IHJlc29sdmVMb2FkUHJvbWlzZTtcblx0bGV0IHJlamVjdExvYWRQcm9taXNlO1xuXHRjb25zdCBjb250cm9sbGVkUHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRyZXNvbHZlTG9hZFByb21pc2UgPSByZXNvbHZlO1xuXHRcdHJlamVjdExvYWRQcm9taXNlID0gcmVqZWN0O1xuXHR9KTtcblx0Y29udHJvbGxlZFByb21pc2Uuc3RhdHVzID0gXCJwZW5kaW5nXCI7XG5cdGNvbnRyb2xsZWRQcm9taXNlLnJlc29sdmUgPSAodmFsdWUpID0+IHtcblx0XHRjb250cm9sbGVkUHJvbWlzZS5zdGF0dXMgPSBcInJlc29sdmVkXCI7XG5cdFx0Y29udHJvbGxlZFByb21pc2UudmFsdWUgPSB2YWx1ZTtcblx0XHRyZXNvbHZlTG9hZFByb21pc2UodmFsdWUpO1xuXHRcdG9uUmVzb2x2ZT8uKHZhbHVlKTtcblx0fTtcblx0Y29udHJvbGxlZFByb21pc2UucmVqZWN0ID0gKGUpID0+IHtcblx0XHRjb250cm9sbGVkUHJvbWlzZS5zdGF0dXMgPSBcInJlamVjdGVkXCI7XG5cdFx0cmVqZWN0TG9hZFByb21pc2UoZSk7XG5cdH07XG5cdHJldHVybiBjb250cm9sbGVkUHJvbWlzZTtcbn1cbi8qKlxuKiBIZXVyaXN0aWNhbGx5IGRldGVjdCBkeW5hbWljIGltcG9ydCBcIm1vZHVsZSBub3QgZm91bmRcIiBlcnJvcnNcbiogYWNyb3NzIG1ham9yIGJyb3dzZXJzIGZvciBsYXp5IHJvdXRlIGNvbXBvbmVudCBoYW5kbGluZy5cbiovXG5mdW5jdGlvbiBpc01vZHVsZU5vdEZvdW5kRXJyb3IoZXJyb3IpIHtcblx0aWYgKHR5cGVvZiBlcnJvcj8ubWVzc2FnZSAhPT0gXCJzdHJpbmdcIikgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gZXJyb3IubWVzc2FnZS5zdGFydHNXaXRoKFwiRmFpbGVkIHRvIGZldGNoIGR5bmFtaWNhbGx5IGltcG9ydGVkIG1vZHVsZVwiKSB8fCBlcnJvci5tZXNzYWdlLnN0YXJ0c1dpdGgoXCJlcnJvciBsb2FkaW5nIGR5bmFtaWNhbGx5IGltcG9ydGVkIG1vZHVsZVwiKSB8fCBlcnJvci5tZXNzYWdlLnN0YXJ0c1dpdGgoXCJJbXBvcnRpbmcgYSBtb2R1bGUgc2NyaXB0IGZhaWxlZFwiKTtcbn1cbmZ1bmN0aW9uIGlzUHJvbWlzZSh2YWx1ZSkge1xuXHRyZXR1cm4gQm9vbGVhbih2YWx1ZSAmJiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIHZhbHVlLnRoZW4gPT09IFwiZnVuY3Rpb25cIik7XG59XG5mdW5jdGlvbiBmaW5kTGFzdChhcnJheSwgcHJlZGljYXRlKSB7XG5cdGZvciAobGV0IGkgPSBhcnJheS5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdGNvbnN0IGl0ZW0gPSBhcnJheVtpXTtcblx0XHRpZiAocHJlZGljYXRlKGl0ZW0pKSByZXR1cm4gaXRlbTtcblx0fVxufVxuLyoqXG4qIFJlLWVuY29kZSBjaGFyYWN0ZXJzIHRoYXQgYXJlIHVuc2FmZSBpbiBVUkwgcGF0aHMuXG4qIEluY2x1ZGVzIEFTQ0lJIGNvbnRyb2wgY2hhcmFjdGVycyAoMHgwMC0weDFGLCAweDdGKSBhbmQgYSBzdWJzZXQgb2YgdGhlXG4qIFdIQVRXRyBVUkwgXCJwYXRoIHBlcmNlbnQtZW5jb2RlIHNldFwiIChcIiwgPCwgPiwgYCwgeywgfSkuXG4qXG4qIFNwYWNlICgweDIwKSBpcyBpbnRlbnRpb25hbGx5IGV4Y2x1ZGVkIOKAlCBkZWNvZGVVUkkgZGVjb2RlcyAlMjAgdG8gc3BhY2VcbiogYW5kIHRoZSByb3V0ZXIgc3RvcmVzIGRlY29kZWQgc3BhY2VzIGluIGxvY2F0aW9uLnBhdGhuYW1lLiBUaGUgZXhpc3RpbmdcbiogZW5jb2RlUGF0aExpa2VVcmwgYWxyZWFkeSBoYW5kbGVzIHJlLWVuY29kaW5nIHNwYWNlcyBmb3Igb3V0Z29pbmcgVVJMcy5cbipcbiogVGhlc2UgY2hhcmFjdGVycyBhcmUgZGVjb2RlZCBieSBkZWNvZGVVUkkgYnV0IG11c3QgcmVtYWluIHBlcmNlbnQtZW5jb2RlZFxuKiBpbiBwYXRocyB0byBtYXRjaCBob3cgdXBzdHJlYW0gbGF5ZXJzIChDRE5zLCBlZGdlIG1pZGRsZXdhcmUsIGJyb3dzZXJzKVxuKiBpbnRlcnByZXQgdGhlIFVSTCwgcHJldmVudGluZyBpbmZpbml0ZSByZWRpcmVjdCBsb29wcyBhbmQgcGF0aCBtaXNtYXRjaGVzLlxuKi9cbmNvbnN0IFBBVEhfVU5TQUZFX1JFID0gL1tcXHgwMC1cXHgxZlxceDdmXCI8PmB7fV0vZztcbmZ1bmN0aW9uIHNhbml0aXplUGF0aFNlZ21lbnQoc2VnbWVudCkge1xuXHRyZXR1cm4gc2VnbWVudC5yZXBsYWNlKFBBVEhfVU5TQUZFX1JFLCAoY2gpID0+IFwiJVwiICsgY2guY2hhckNvZGVBdCgwKS50b1N0cmluZygxNikudG9VcHBlckNhc2UoKS5wYWRTdGFydCgyLCBcIjBcIikpO1xufVxuZnVuY3Rpb24gZGVjb2RlU2VnbWVudChzZWdtZW50KSB7XG5cdGxldCBkZWNvZGVkO1xuXHR0cnkge1xuXHRcdGRlY29kZWQgPSBkZWNvZGVVUkkoc2VnbWVudCk7XG5cdH0gY2F0Y2gge1xuXHRcdGRlY29kZWQgPSBzZWdtZW50LnJlcGxhY2VBbGwoLyVbMC05QS1GXXsyfS9naSwgKG1hdGNoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRyZXR1cm4gZGVjb2RlVVJJKG1hdGNoKTtcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRyZXR1cm4gbWF0Y2g7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIHNhbml0aXplUGF0aFNlZ21lbnQoZGVjb2RlZCk7XG59XG4vKipcbiogRGVmYXVsdCBsaXN0IG9mIFVSTCBwcm90b2NvbHMgdG8gYWxsb3cgaW4gbGlua3MsIHJlZGlyZWN0cywgYW5kIG5hdmlnYXRpb24uXG4qIEFueSBhYnNvbHV0ZSBVUkwgcHJvdG9jb2wgbm90IGluIHRoaXMgbGlzdCBpcyB0cmVhdGVkIGFzIGRhbmdlcm91cyBieSBkZWZhdWx0LlxuKi9cbmNvbnN0IERFRkFVTFRfUFJPVE9DT0xfQUxMT1dMSVNUID0gW1xuXHRcImh0dHA6XCIsXG5cdFwiaHR0cHM6XCIsXG5cdFwibWFpbHRvOlwiLFxuXHRcInRlbDpcIlxuXTtcbi8qKlxuKiBFeHRyYWN0IHRoZSBleHBsaWNpdCBVUkwgc2NoZW1lLCBpbmNsdWRpbmcgaXRzIGNvbG9uLCB1c2luZyBXSEFUV0dcbiogbm9ybWFsaXphdGlvbiBydWxlcy4gVGhpcyBkb2VzIG5vdCB2YWxpZGF0ZSB0aGUgcmVzdCBvZiB0aGUgVVJMLlxuKlxuKiBSZXR1cm5pbmcgYHVuZGVmaW5lZGAgbWVhbnMgXCJubyBleHBsaWNpdCBzY2hlbWVcIiwgbm90IFwic2FmZSBVUkxcIjtcbiogcHJvdG9jb2wtcmVsYXRpdmUgVVJMcyBzdWNoIGFzIFwiLy9ldmlsLmV4YW1wbGVcIiByZXF1aXJlIGEgc2VwYXJhdGUgY2hlY2suXG4qL1xuZnVuY3Rpb24gZ2V0VXJsU2NoZW1lKHVybCkge1xuXHRpZiAodXJsWzBdID09PSBcIi9cIikgcmV0dXJuO1xuXHRpZiAoIXVybC5pbmNsdWRlcyhcIjpcIikpIHJldHVybjtcblx0cmV0dXJuIC9eW1xceDAwLVxceDIwXSooW2Etel1bYS16XFxkKy5cXHRcXG5cXHItXSo6KS9pLmV4ZWModXJsKT8uWzFdPy5yZXBsYWNlKC9bXFx0XFxuXFxyXS9nLCBcIlwiKS50b0xvd2VyQ2FzZSgpO1xufVxuY29uc3QgcHJvdG9jb2xSZWxhdGl2ZVByZWZpeFJlZ2V4ID0gL15bXFx4MDAtXFx4MjBdKltcXFxcL11bXFx0XFxuXFxyXSpbXFxcXC9dLztcbi8qKlxuKiBDaGVjayBpZiBhIFVSTCBzdHJpbmcgdXNlcyBhIHByb3RvY29sIHRoYXQgaXMgbm90IGluIHRoZSBhbGxvd2xpc3Qgb3IgaXNcbiogcHJvdG9jb2wtcmVsYXRpdmUgKGUuZy4gXCIvL2V2aWwuZXhhbXBsZVwiKSwgd2hpY2ggY2FuIG5hdmlnYXRlIHRvIGFub3RoZXIgaG9zdC5cbiogUmV0dXJucyB0cnVlIGZvciBibG9ja2VkIHByb3RvY29scyBsaWtlIGphdmFzY3JpcHQ6LCBibG9iOiwgYW5kIGRhdGE6LCBhc1xuKiB3ZWxsIGFzIHNsYXNoL2JhY2tzbGFzaCB2YXJpYW50cyBvZiBwcm90b2NvbC1yZWxhdGl2ZSBVUkxzLlxuKlxuKiBTY2hlbWUgcGFyc2luZyBub3JtYWxpemVzOlxuKiAtIE1peGVkIGNhc2UgKEphdmFTY3JpcHQ6IOKGkiBqYXZhc2NyaXB0OilcbiogLSBXaGl0ZXNwYWNlL2NvbnRyb2wgY2hhcmFjdGVycyAoamF2YVxcbnNjcmlwdDog4oaSIGphdmFzY3JpcHQ6KVxuKiAtIExlYWRpbmcgd2hpdGVzcGFjZVxuKlxuKiBGb3IgcmVsYXRpdmUgVVJMcyB3aXRob3V0IGEgcHJvdG9jb2wtcmVsYXRpdmUgcHJlZml4LCByZXR1cm5zIGZhbHNlLlxuKlxuKiBAcGFyYW0gdXJsIC0gVGhlIFVSTCBzdHJpbmcgdG8gY2hlY2tcbiogQHBhcmFtIGFsbG93bGlzdCAtIFNldCBvZiBwcm90b2NvbHMgdG8gYWxsb3dcbiogQHJldHVybnMgdHJ1ZSBpZiB0aGUgVVJMIHVzZXMgYSBwcm90b2NvbCB0aGF0IGlzIG5vdCBhbGxvd2VkIG9yIGNhbiBlc2NhcGVcbiogdGhlIGN1cnJlbnQgb3JpZ2luIHRocm91Z2ggYSBwcm90b2NvbC1yZWxhdGl2ZSBVUkxcbiovXG5mdW5jdGlvbiBpc0Rhbmdlcm91c1Byb3RvY29sKHVybCwgYWxsb3dsaXN0KSB7XG5cdGlmICghdXJsKSByZXR1cm4gZmFsc2U7XG5cdGlmIChwcm90b2NvbFJlbGF0aXZlUHJlZml4UmVnZXgudGVzdCh1cmwpKSByZXR1cm4gdHJ1ZTtcblx0Y29uc3Qgc2NoZW1lID0gZ2V0VXJsU2NoZW1lKHVybCk7XG5cdHJldHVybiBzY2hlbWUgPyAhYWxsb3dsaXN0LmhhcyhzY2hlbWUpIDogZmFsc2U7XG59XG5jb25zdCBIVE1MX0VTQ0FQRV9MT09LVVAgPSB7XG5cdFwiJlwiOiBcIlxcXFx1MDAyNlwiLFxuXHRcIj5cIjogXCJcXFxcdTAwM2VcIixcblx0XCI8XCI6IFwiXFxcXHUwMDNjXCIsXG5cdFwiXFx1MjAyOFwiOiBcIlxcXFx1MjAyOFwiLFxuXHRcIlxcdTIwMjlcIjogXCJcXFxcdTIwMjlcIlxufTtcbmNvbnN0IEhUTUxfRVNDQVBFX1JFR0VYID0gL1smPjxcXHUyMDI4XFx1MjAyOV0vZztcbi8qKlxuKiBFc2NhcGUgSFRNTCBzcGVjaWFsIGNoYXJhY3RlcnMgaW4gYSBzdHJpbmcgdG8gcHJldmVudCBYU1MgYXR0YWNrc1xuKiB3aGVuIGVtYmVkZGluZyBzdHJpbmdzIGluIHNjcmlwdCB0YWdzIGR1cmluZyBTU1IuXG4qXG4qIFRoaXMgaXMgZXNzZW50aWFsIGZvciBwcmV2ZW50aW5nIFhTUyB2dWxuZXJhYmlsaXRpZXMgd2hlbiB1c2VyLWNvbnRyb2xsZWRcbiogY29udGVudCBpcyBlbWJlZGRlZCBpbiBpbmxpbmUgc2NyaXB0cy5cbiovXG5mdW5jdGlvbiBlc2NhcGVIdG1sKHN0cikge1xuXHRyZXR1cm4gc3RyLnJlcGxhY2UoSFRNTF9FU0NBUEVfUkVHRVgsIChtYXRjaCkgPT4gSFRNTF9FU0NBUEVfTE9PS1VQW21hdGNoXSk7XG59XG5mdW5jdGlvbiBkZWNvZGVQYXRoKHBhdGgpIHtcblx0aWYgKCFwYXRoKSByZXR1cm4gcGF0aDtcblx0bGV0IHJlc3VsdCA9IHBhdGg7XG5cdGlmICgvWyVcXFxcXFx4MDAtXFx4MWZcXHg3Zl0vLnRlc3QocGF0aCkpIHtcblx0XHRjb25zdCByZSA9IC8lMjV8JTVDL2dpO1xuXHRcdGxldCBjdXJzb3IgPSAwO1xuXHRcdGxldCBtYXRjaDtcblx0XHRyZXN1bHQgPSBcIlwiO1xuXHRcdHdoaWxlIChudWxsICE9PSAobWF0Y2ggPSByZS5leGVjKHBhdGgpKSkge1xuXHRcdFx0cmVzdWx0ICs9IGRlY29kZVNlZ21lbnQocGF0aC5zbGljZShjdXJzb3IsIG1hdGNoLmluZGV4KSkgKyBtYXRjaFswXTtcblx0XHRcdGN1cnNvciA9IHJlLmxhc3RJbmRleDtcblx0XHR9XG5cdFx0cmVzdWx0ICs9IGRlY29kZVNlZ21lbnQoY3Vyc29yID8gcGF0aC5zbGljZShjdXJzb3IpIDogcGF0aCk7XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn1cbi8qKlxuKiBFbmNvZGVzIGEgcGF0aCB0aGUgc2FtZSB3YXkgYG5ldyBVUkwoKWAgd291bGQsIGJ1dCB3aXRob3V0IHRoZSBvdmVyaGVhZCBvZiBmdWxsIFVSTCBwYXJzaW5nLlxuKlxuKiBUaGlzIGZ1bmN0aW9uIGVuY29kZXM6XG4qIC0gV2hpdGVzcGFjZSBjaGFyYWN0ZXJzIChzcGFjZXMg4oaSICUyMCwgdGFicyDihpIgJTA5LCBldGMuKVxuKiAtIE5vbi1BU0NJSS9Vbmljb2RlIGNoYXJhY3RlcnMgKGVtb2ppcywgYWNjZW50ZWQgY2hhcmFjdGVycywgZXRjLilcbipcbiogSXQgcHJlc2VydmVzOlxuKiAtIEFscmVhZHkgcGVyY2VudC1lbmNvZGVkIHNlcXVlbmNlcyAod29uJ3QgZG91YmxlLWVuY29kZSAlMkYsICUyNSwgZXRjLilcbiogLSBBU0NJSSBzcGVjaWFsIGNoYXJhY3RlcnMgdmFsaWQgaW4gVVJMIHBhdGhzIChALCAkLCAmLCArLCBldGMuKVxuKiAtIEZvcndhcmQgc2xhc2hlcyBhcyBwYXRoIHNlcGFyYXRvcnNcbipcbiogVXNlZCB0byBnZW5lcmF0ZSBwcm9wZXIgaHJlZiB2YWx1ZXMgZm9yIFNTUiB3aXRob3V0IGNvbnN0cnVjdGluZyBVUkwgb2JqZWN0cy5cbipcbiogQGV4YW1wbGVcbiogZW5jb2RlUGF0aExpa2VVcmwoJy9wYXRoL2ZpbGUgbmFtZS5wZGYnKSAvLyAnL3BhdGgvZmlsZSUyMG5hbWUucGRmJ1xuKiBlbmNvZGVQYXRoTGlrZVVybCgnL3BhdGgv5pel5pys6KqeJykgLy8gJy9wYXRoLyVFNiU5NyVBNSVFNiU5QyVBQyVFOCVBQSU5RSdcbiogZW5jb2RlUGF0aExpa2VVcmwoJy9wYXRoL2FscmVhZHklMjBlbmNvZGVkJykgLy8gJy9wYXRoL2FscmVhZHklMjBlbmNvZGVkJyAocHJlc2VydmVkKVxuKi9cbmZ1bmN0aW9uIGVuY29kZVBhdGhMaWtlVXJsKHBhdGgpIHtcblx0aWYgKCEvW1xcc1xcdTAwODAtXFx1RkZGRl0vLnRlc3QocGF0aCkpIHJldHVybiBwYXRoO1xuXHRyZXR1cm4gcGF0aC5yZXBsYWNlKC9cXHN8W15cXHUwMDAwLVxcdTAwN0ZdL2d1LCBlbmNvZGVVUklDb21wb25lbnQpO1xufVxuLyoqXG4qIEJ1aWxkcyB0aGUgZGV2LW1vZGUgQ1NTIHN0eWxlcyBVUkwgZm9yIHJvdXRlLXNjb3BlZCBDU1MgY29sbGVjdGlvbi5cbiogVXNlZCBieSBIZWFkQ29udGVudCBjb21wb25lbnRzIGluIGFsbCBmcmFtZXdvcmsgaW1wbGVtZW50YXRpb25zIHRvIGNvbnN0cnVjdFxuKiB0aGUgVVJMIGZvciB0aGUgYC9AdGFuc3RhY2stc3RhcnQvc3R5bGVzLmNzc2AgZW5kcG9pbnQuXG4qXG4qIEBwYXJhbSBiYXNlcGF0aCAtIFRoZSByb3V0ZXIncyBiYXNlcGF0aCAobWF5IG9yIG1heSBub3QgaGF2ZSBsZWFkaW5nIHNsYXNoKVxuKiBAcGFyYW0gcm91dGVJZHMgLSBBcnJheSBvZiBtYXRjaGVkIHJvdXRlIElEcyB0byBpbmNsdWRlIGluIHRoZSBDU1MgY29sbGVjdGlvblxuKiBAcmV0dXJucyBUaGUgZnVsbCBVUkwgcGF0aCBmb3IgdGhlIGRldiBzdHlsZXMgQ1NTIGVuZHBvaW50XG4qL1xuZnVuY3Rpb24gYnVpbGREZXZTdHlsZXNVcmwoYmFzZXBhdGgsIHJvdXRlSWRzKSB7XG5cdGNvbnN0IHRyaW1tZWRCYXNlcGF0aCA9IGJhc2VwYXRoLnJlcGxhY2UoL15cXC8rfFxcLyskL2csIFwiXCIpO1xuXHRyZXR1cm4gYCR7dHJpbW1lZEJhc2VwYXRoID09PSBcIlwiID8gXCJcIiA6IGAvJHt0cmltbWVkQmFzZXBhdGh9YH0vQHRhbnN0YWNrLXN0YXJ0L3N0eWxlcy5jc3M/cm91dGVzPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHJvdXRlSWRzLmpvaW4oXCIsXCIpKX1gO1xufVxuZnVuY3Rpb24gYXJyYXlzRXF1YWwoYSwgYikge1xuXHRpZiAoYSA9PT0gYikgcmV0dXJuIHRydWU7XG5cdGlmIChhLmxlbmd0aCAhPT0gYi5sZW5ndGgpIHJldHVybiBmYWxzZTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBhLmxlbmd0aDsgaSsrKSBpZiAoYVtpXSAhPT0gYltpXSkgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgREVGQVVMVF9QUk9UT0NPTF9BTExPV0xJU1QsIGFycmF5c0VxdWFsLCBidWlsZERldlN0eWxlc1VybCwgY3JlYXRlQ29udHJvbGxlZFByb21pc2UsIGNyZWF0ZU51bGwsIGRlY29kZVBhdGgsIGRlZXBFcXVhbCwgZW5jb2RlUGF0aExpa2VVcmwsIGVzY2FwZUh0bWwsIGZpbmRMYXN0LCBmdW5jdGlvbmFsVXBkYXRlLCBnZXRVcmxTY2hlbWUsIGhhc0tleXMsIGhhc093biwgaXNEYW5nZXJvdXNQcm90b2NvbCwgaXNNb2R1bGVOb3RGb3VuZEVycm9yLCBpc1BsYWluT2JqZWN0LCBpc1Byb21pc2UsIGxhc3QsIG51bGxSZXBsYWNlRXF1YWxEZWVwLCBwcm90b2NvbFJlbGF0aXZlUHJlZml4UmVnZXgsIHJlcGxhY2VFcXVhbERlZXAgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXRpbHMuanMubWFwIiwiaW1wb3J0IHsgbGFzdCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyNyZWdpb24gc3JjL3BhdGgudHNcbi8qKiBKb2luIHBhdGggc2VnbWVudHMsIGNsZWFuaW5nIGR1cGxpY2F0ZSBzbGFzaGVzIGJldHdlZW4gcGFydHMuICovXG5mdW5jdGlvbiBqb2luUGF0aHMocGF0aHMpIHtcblx0cmV0dXJuIGNsZWFuUGF0aChwYXRocy5maWx0ZXIoKHZhbCkgPT4ge1xuXHRcdHJldHVybiB2YWwgIT09IHZvaWQgMDtcblx0fSkuam9pbihcIi9cIikpO1xufVxuLyoqIFJlbW92ZSByZXBlYXRlZCBzbGFzaGVzIGZyb20gYSBwYXRoIHN0cmluZy4gKi9cbmZ1bmN0aW9uIGNsZWFuUGF0aChwYXRoKSB7XG5cdHJldHVybiBwYXRoLnJlcGxhY2UoL1xcL3syLH0vZywgXCIvXCIpO1xufVxuLyoqIFRyaW0gbGVhZGluZyBzbGFzaGVzIChleGNlcHQgcHJlc2VydmluZyByb290ICcvJykuICovXG5mdW5jdGlvbiB0cmltUGF0aExlZnQocGF0aCkge1xuXHRyZXR1cm4gcGF0aCA9PT0gXCIvXCIgPyBwYXRoIDogcGF0aC5yZXBsYWNlKC9eXFwvKy8sIFwiXCIpO1xufVxuLyoqIFRyaW0gdHJhaWxpbmcgc2xhc2hlcyAoZXhjZXB0IHByZXNlcnZpbmcgcm9vdCAnLycpLiAqL1xuZnVuY3Rpb24gdHJpbVBhdGhSaWdodChwYXRoKSB7XG5cdGNvbnN0IGxlbiA9IHBhdGgubGVuZ3RoO1xuXHRyZXR1cm4gbGVuID4gMSAmJiBwYXRoW2xlbiAtIDFdID09PSBcIi9cIiA/IHBhdGgucmVwbGFjZSgvXFwvKyQvLCBcIlwiKSA6IHBhdGg7XG59XG4vKiogVHJpbSBib3RoIGxlYWRpbmcgYW5kIHRyYWlsaW5nIHNsYXNoZXMuICovXG5mdW5jdGlvbiB0cmltUGF0aChwYXRoKSB7XG5cdHJldHVybiB0cmltUGF0aFJpZ2h0KHRyaW1QYXRoTGVmdChwYXRoKSk7XG59XG4vKiogUmVtb3ZlIGEgdHJhaWxpbmcgc2xhc2ggZnJvbSB2YWx1ZSB3aGVuIGFwcHJvcHJpYXRlIGZvciBjb21wYXJpc29ucy4gKi9cbmZ1bmN0aW9uIHJlbW92ZVRyYWlsaW5nU2xhc2godmFsdWUsIGJhc2VwYXRoKSB7XG5cdGlmICh2YWx1ZT8uZW5kc1dpdGgoXCIvXCIpICYmIHZhbHVlICE9PSBcIi9cIiAmJiB2YWx1ZSAhPT0gYCR7YmFzZXBhdGh9L2ApIHJldHVybiB2YWx1ZS5zbGljZSgwLCAtMSk7XG5cdHJldHVybiB2YWx1ZTtcbn1cbi8qKlxuKiBDb21wYXJlIHR3byBwYXRobmFtZXMgZm9yIGV4YWN0IGVxdWFsaXR5IGFmdGVyIG5vcm1hbGl6aW5nIHRyYWlsaW5nIHNsYXNoZXNcbiogcmVsYXRpdmUgdG8gdGhlIHByb3ZpZGVkIGBiYXNlcGF0aGAuXG4qL1xuZnVuY3Rpb24gZXhhY3RQYXRoVGVzdChwYXRoTmFtZTEsIHBhdGhOYW1lMiwgYmFzZXBhdGgpIHtcblx0cmV0dXJuIHJlbW92ZVRyYWlsaW5nU2xhc2gocGF0aE5hbWUxLCBiYXNlcGF0aCkgPT09IHJlbW92ZVRyYWlsaW5nU2xhc2gocGF0aE5hbWUyLCBiYXNlcGF0aCk7XG59XG4vKipcbiogUmVzb2x2ZSBhIGRlc3RpbmF0aW9uIHBhdGggYWdhaW5zdCBhIGJhc2UsIGhvbm9yaW5nIHRyYWlsaW5nLXNsYXNoIHBvbGljeVxuKiBhbmQgc3VwcG9ydGluZyByZWxhdGl2ZSBzZWdtZW50cyAoYC5gL2AuLmApIGFuZCBhYnNvbHV0ZSBgdG9gIHZhbHVlcy5cbipcbiogSW50ZXJuYWw6IHBhcmFtZXRlcnMgYXJlIHBvc2l0aW9uYWwgc28gdGhlIHJvdXRlcidzIGhvdCBjYWxsZXJzIHBhc3Mgbm9cbiogb3B0aW9ucyBvYmplY3QuXG4qL1xuZnVuY3Rpb24gcmVzb2x2ZVBhdGgoYmFzZSwgdG8sIHRyYWlsaW5nU2xhc2ggPSBcIm5ldmVyXCIsIGNhY2hlKSB7XG5cdGlmICh0by5pbmNsdWRlcyhcIi8vXCIpKSB0byA9IGNsZWFuUGF0aCh0byk7XG5cdGlmICh0by5zdGFydHNXaXRoKFwiL1wiKSkge1xuXHRcdGlmICh0by5sZW5ndGggPT09IDEgfHwgdHJhaWxpbmdTbGFzaCA9PT0gXCJwcmVzZXJ2ZVwiKSByZXR1cm4gdG87XG5cdFx0aWYgKHRyYWlsaW5nU2xhc2ggPT09IFwiYWx3YXlzXCIpIHJldHVybiB0by5lbmRzV2l0aChcIi9cIikgPyB0byA6IGAke3RvfS9gO1xuXHRcdHJldHVybiB0by5lbmRzV2l0aChcIi9cIikgPyB0by5zbGljZSgwLCAtMSkgOiB0bztcblx0fVxuXHRjb25zdCBpc0Jhc2UgPSB0byA9PT0gXCIuXCI7XG5cdGxldCBrZXk7XG5cdGlmIChjYWNoZSkge1xuXHRcdGtleSA9IGlzQmFzZSA/IGJhc2UgOiBiYXNlICsgXCJcXDBcIiArIHRvO1xuXHRcdGNvbnN0IGNhY2hlZCA9IGNhY2hlLmdldChrZXkpO1xuXHRcdGlmIChjYWNoZWQpIHJldHVybiBjYWNoZWQ7XG5cdH1cblx0bGV0IGJhc2VTZWdtZW50cztcblx0aWYgKGlzQmFzZSkgYmFzZVNlZ21lbnRzID0gYmFzZS5zcGxpdChcIi9cIik7XG5cdGVsc2Uge1xuXHRcdGlmIChiYXNlLmluY2x1ZGVzKFwiLy9cIikpIGJhc2UgPSBjbGVhblBhdGgoYmFzZSk7XG5cdFx0YmFzZVNlZ21lbnRzID0gYmFzZS5zcGxpdChcIi9cIik7XG5cdFx0d2hpbGUgKGJhc2VTZWdtZW50cy5sZW5ndGggPiAxICYmIGxhc3QoYmFzZVNlZ21lbnRzKSA9PT0gXCJcIikgYmFzZVNlZ21lbnRzLnBvcCgpO1xuXHRcdGNvbnN0IHRvU2VnbWVudHMgPSB0by5zcGxpdChcIi9cIik7XG5cdFx0Zm9yIChsZXQgaW5kZXggPSAwLCBsZW5ndGggPSB0b1NlZ21lbnRzLmxlbmd0aDsgaW5kZXggPCBsZW5ndGg7IGluZGV4KyspIHtcblx0XHRcdGNvbnN0IHZhbHVlID0gdG9TZWdtZW50c1tpbmRleF07XG5cdFx0XHRpZiAodmFsdWUgPT09IFwiXCIpIHtcblx0XHRcdFx0aWYgKCFpbmRleCkgYmFzZVNlZ21lbnRzID0gW3ZhbHVlXTtcblx0XHRcdFx0ZWxzZSBpZiAoaW5kZXggPT09IGxlbmd0aCAtIDEpIGJhc2VTZWdtZW50cy5wdXNoKHZhbHVlKTtcblx0XHRcdH0gZWxzZSBpZiAodmFsdWUgPT09IFwiLi5cIikge1xuXHRcdFx0XHRpZiAoYmFzZVNlZ21lbnRzLmxlbmd0aCA+IDEpIGJhc2VTZWdtZW50cy5wb3AoKTtcblx0XHRcdFx0ZWxzZSBiYXNlU2VnbWVudHMgPSBbXCJcIl07XG5cdFx0XHR9IGVsc2UgaWYgKHZhbHVlID09PSBcIi5cIikge30gZWxzZSBiYXNlU2VnbWVudHMucHVzaCh2YWx1ZSk7XG5cdFx0fVxuXHR9XG5cdGlmIChiYXNlU2VnbWVudHMubGVuZ3RoID4gMSkge1xuXHRcdGlmIChsYXN0KGJhc2VTZWdtZW50cykgPT09IFwiXCIpIHtcblx0XHRcdGlmICh0cmFpbGluZ1NsYXNoID09PSBcIm5ldmVyXCIpIGJhc2VTZWdtZW50cy5wb3AoKTtcblx0XHR9IGVsc2UgaWYgKHRyYWlsaW5nU2xhc2ggPT09IFwiYWx3YXlzXCIpIGJhc2VTZWdtZW50cy5wdXNoKFwiXCIpO1xuXHR9XG5cdGNvbnN0IGpvaW5lZCA9IGJhc2VTZWdtZW50cy5qb2luKFwiL1wiKTtcblx0Y29uc3QgcmVzdWx0ID0gKGlzQmFzZSA/IGNsZWFuUGF0aChqb2luZWQpIDogam9pbmVkKSB8fCBcIi9cIjtcblx0aWYgKGtleSAmJiBjYWNoZSkgY2FjaGUuc2V0KGtleSwgcmVzdWx0KTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbi8qKlxuKiBDcmVhdGUgYSBwcmUtY29tcGlsZWQgZGVjb2RlIGNvbmZpZyBmcm9tIGFsbG93ZWQgY2hhcmFjdGVycy5cbiogQ3JlYXRlZCBvbmNlIGZvciB0aGUgcm91dGVyJ3MgZml4ZWQgZW5jb2RpbmcgY29uZmlndXJhdGlvbi5cbiovXG5mdW5jdGlvbiBjb21waWxlRGVjb2RlQ2hhck1hcChwYXRoUGFyYW1zQWxsb3dlZENoYXJhY3RlcnMpIHtcblx0Y29uc3QgY2hhck1hcCA9IG5ldyBNYXAocGF0aFBhcmFtc0FsbG93ZWRDaGFyYWN0ZXJzLm1hcCgoY2hhcikgPT4gW2VuY29kZVVSSUNvbXBvbmVudChjaGFyKSwgY2hhcl0pKTtcblx0Y29uc3QgcmVnZXggPSBuZXcgUmVnRXhwKFsuLi5jaGFyTWFwLmtleXMoKV0uam9pbihcInxcIikucmVwbGFjZSgvWy4qKCldL2csIFwiXFxcXCQmXCIpLCBcImdcIik7XG5cdHJldHVybiAoZW5jb2RlZCkgPT4gZW5jb2RlZC5yZXBsYWNlKHJlZ2V4LCAobWF0Y2gpID0+IGNoYXJNYXAuZ2V0KG1hdGNoKSA/PyBtYXRjaCk7XG59XG5mdW5jdGlvbiBnZXRSb3V0ZVNlZ21lbnRzKHJvdXRlKSB7XG5cdHJldHVybiByb3V0ZS5faW50ZXJwb2xhdGlvbjtcbn1cbi8qKiBBIHNwbGF0IGlzIG1pc3Npbmcgd2hlbiBpdCBoYXMgbm8gdmFsdWU7IGAwYCBhbmQgYGZhbHNlYCBhcmUgc3RyaW5naWZpZWQgbGlrZSBhbnkgb3RoZXIgcGFyYW0uICovXG5mdW5jdGlvbiBpc01pc3NpbmdTcGxhdCh2YWx1ZSkge1xuXHRyZXR1cm4gdmFsdWUgPT0gbnVsbCB8fCB2YWx1ZSA9PT0gXCJcIjtcbn1cbi8qKiBEZXZ0b29scyBjaGVja3MgbmF2aWdhdGlvbiBhdmFpbGFiaWxpdHkgc2VwYXJhdGVseSBmcm9tIHRoZSBob3QgZm9ybWF0dGVyLiAqL1xuZnVuY3Rpb24gaGFzTWlzc2luZ1BhdGhQYXJhbXMoc2VnbWVudHMsIHBhcmFtcykge1xuXHRyZXR1cm4gc2VnbWVudHMuc29tZSgocGFydCkgPT4ge1xuXHRcdGlmICh0eXBlb2YgcGFydCA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIGZhbHNlO1xuXHRcdGNvbnN0IFtraW5kLCBrZXldID0gcGFydDtcblx0XHRyZXR1cm4ga2luZCA9PT0gMiA/IGlzTWlzc2luZ1NwbGF0KHBhcmFtc1trZXldKSA6IGtpbmQgPT09IDEgJiYgIShrZXkgaW4gcGFyYW1zKTtcblx0fSk7XG59XG5mdW5jdGlvbiBlbmNvZGVQYXJhbShrZXksIHZhbHVlLCBkZWNvZGVyKSB7XG5cdGlmICh0eXBlb2YgdmFsdWUgIT09IFwic3RyaW5nXCIpIHJldHVybiBcIlwiICsgKHZhbHVlID8/IHZvaWQgMCk7XG5cdGNvbnN0IHNwbGF0ID0ga2V5ID09PSBcIl9zcGxhdFwiO1xuXHRpZiAoc3BsYXQgJiYgKCF2YWx1ZSB8fCAvXlthLXpBLVowLTlcXC0uX34hL10qJC8udGVzdCh2YWx1ZSkpKSByZXR1cm4gdmFsdWU7XG5cdGxldCBlbmNvZGVkID0gZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcblx0aWYgKHNwbGF0KSBlbmNvZGVkID0gZW5jb2RlZC5yZXBsYWNlQWxsKFwiJTJGXCIsIFwiL1wiKTtcblx0cmV0dXJuIGRlY29kZXIgPyBkZWNvZGVyKGVuY29kZWQpIDogZW5jb2RlZDtcbn1cbi8qKiBTdWJzdGl0dXRlIGN1cnJlbnQgdmFsdWVzIGludG8gcGFyc2VkIHNlZ21lbnRzLCBvcHRpb25hbGx5IGNvbGxlY3RpbmcgcmF3IHBhcmFtcy4gKi9cbmZ1bmN0aW9uIGludGVycG9sYXRlUGF0aChwYXRoLCBzZWdtZW50cywgcGFyYW1zLCBkZWNvZGVyLCB1c2VkUGFyYW1zKSB7XG5cdGNvbnN0IHRyYWlsaW5nU2xhc2ggPSBwYXRoLmVuZHNXaXRoKFwiL1wiKSA/IFwiL1wiIDogXCJcIjtcblx0bGV0IGpvaW5lZCA9IFwiXCI7XG5cdGZvciAoY29uc3QgcGFydCBvZiBzZWdtZW50cykge1xuXHRcdGlmICh0eXBlb2YgcGFydCA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0am9pbmVkICs9IHBhcnQ7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0Y29uc3QgW2tpbmQsIGtleSwgcHJlZml4LCByYXdTdWZmaXhdID0gcGFydDtcblx0XHRjb25zdCBzcGxhdCA9IGtpbmQgPT09IDI7XG5cdFx0Y29uc3Qgc3VmZml4ID0gc3BsYXQgJiYgcmF3U3VmZml4ICE9PSB2b2lkIDAgPyByYXdTdWZmaXggKyB0cmFpbGluZ1NsYXNoIDogcmF3U3VmZml4O1xuXHRcdGxldCBwYXJhbVZhbHVlID0gcGFyYW1zW2tleV07XG5cdFx0aWYgKGtpbmQgPT09IDMgJiYgcGFyYW1WYWx1ZSA9PSBudWxsKSBjb250aW51ZTtcblx0XHRpZiAodXNlZFBhcmFtcykge1xuXHRcdFx0dXNlZFBhcmFtc1trZXldID0gcGFyYW1WYWx1ZTtcblx0XHRcdGlmIChzcGxhdCkgdXNlZFBhcmFtc1tcIipcIl0gPSBwYXJhbVZhbHVlO1xuXHRcdH1cblx0XHRpZiAoc3BsYXQgJiYgaXNNaXNzaW5nU3BsYXQocGFyYW1WYWx1ZSkpIHtcblx0XHRcdGlmIChwcmVmaXggPT09IFwiL1wiICYmICFzdWZmaXgpIGNvbnRpbnVlO1xuXHRcdFx0cGFyYW1WYWx1ZSA9IFwiXCI7XG5cdFx0fVxuXHRcdGpvaW5lZCArPSBwcmVmaXggKyBlbmNvZGVQYXJhbShrZXksIHBhcmFtVmFsdWUsIGRlY29kZXIpICsgKHN1ZmZpeCB8fCBcIlwiKTtcblx0fVxuXHRyZXR1cm4gam9pbmVkICsgdHJhaWxpbmdTbGFzaCB8fCBcIi9cIjtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgY2xlYW5QYXRoLCBjb21waWxlRGVjb2RlQ2hhck1hcCwgZXhhY3RQYXRoVGVzdCwgZ2V0Um91dGVTZWdtZW50cywgaGFzTWlzc2luZ1BhdGhQYXJhbXMsIGludGVycG9sYXRlUGF0aCwgam9pblBhdGhzLCByZW1vdmVUcmFpbGluZ1NsYXNoLCByZXNvbHZlUGF0aCwgdHJpbVBhdGgsIHRyaW1QYXRoTGVmdCwgdHJpbVBhdGhSaWdodCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1wYXRoLmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvc2lldmUtY2FjaGUudHNcbi8qKlxuKiBBIGZpeGVkLWNhcGFjaXR5IGNhY2hlIHVzaW5nIHRoZSBTSUVWRSBldmljdGlvbiBhbGdvcml0aG1cbiogKGh0dHBzOi8vY2FjaGVtb24uZ2l0aHViLmlvL1NJRVZFLXdlYnNpdGUvKS5cbipcbiogRW50cmllcyBsaXZlIGluIHRoZSBNYXAncyBGSUZPIGluc2VydGlvbiBvcmRlcjsgYSBoaXQgb25seSBmbGlwcyBhIGB2aXNpdGVkYFxuKiBiaXQgaW5zdGVhZCBvZiByZWxpbmtpbmcgdGhlIGVudHJ5LCB3aGljaCBtYWtlcyBgZ2V0YCAoYnkgZmFyIHRoZSBob3R0ZXN0XG4qIG9wZXJhdGlvbiBoZXJlKSBvbmUgYE1hcC5nZXRgIHBsdXMgYSBib29sZWFuIHN0b3JlLiBFdmljdGlvbiBzd2VlcHMgYSBgaGFuZGBcbiogZnJvbSB0aGUgb2xkZXN0IGVudHJ5IHRvd2FyZHMgdGhlIG5ld2VzdCwgY2xlYXJpbmcgYHZpc2l0ZWRgIGJpdHMgdW50aWwgaXRcbiogZmluZHMgYW4gdW52aXNpdGVkIGVudHJ5IHRvIGRyb3AsIHNvIGVudHJpZXMgdG91Y2hlZCBzaW5jZSB0aGUgbGFzdCBzd2VlcFxuKiBzdXJ2aXZlIG9uZSBtb3JlIHJvdW5kLiBUaGlzIGtlZXBzIExSVS1saWtlIGhpdCByYXRpb3Mgd2hpbGUgYmVpbmdcbiogc2Nhbi1yZXNpc3RhbnQuXG4qL1xuZnVuY3Rpb24gY3JlYXRlU2lldmVDYWNoZShtYXgpIHtcblx0Y29uc3QgY2FjaGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRsZXQgaGFuZDtcblx0bGV0IG5ld2VzdDtcblx0cmV0dXJuIHtcblx0XHRnZXQoa2V5KSB7XG5cdFx0XHRjb25zdCBlbnRyeSA9IGNhY2hlLmdldChrZXkpO1xuXHRcdFx0aWYgKCFlbnRyeSkgcmV0dXJuO1xuXHRcdFx0ZW50cnkudmlzaXRlZCA9IHRydWU7XG5cdFx0XHRyZXR1cm4gZW50cnkudmFsdWU7XG5cdFx0fSxcblx0XHRzZXQoa2V5LCB2YWx1ZSkge1xuXHRcdFx0Y29uc3QgZXhpc3RpbmcgPSBjYWNoZS5nZXQoa2V5KTtcblx0XHRcdGlmIChleGlzdGluZykge1xuXHRcdFx0XHRleGlzdGluZy52YWx1ZSA9IHZhbHVlO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRpZiAoY2FjaGUuc2l6ZSA+PSBtYXgpIHtcblx0XHRcdFx0bGV0IG5vZGUgPSBoYW5kPy5uZXh0KCkudmFsdWU7XG5cdFx0XHRcdHdoaWxlICghbm9kZSB8fCBub2RlLnZpc2l0ZWQpIHtcblx0XHRcdFx0XHRpZiAobm9kZSkgbm9kZS52aXNpdGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0ZWxzZSBoYW5kID0gY2FjaGUudmFsdWVzKCk7XG5cdFx0XHRcdFx0bm9kZSA9IGhhbmQubmV4dCgpLnZhbHVlO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChub2RlID09PSBuZXdlc3QpIGhhbmQgPSB2b2lkIDA7XG5cdFx0XHRcdGNhY2hlLmRlbGV0ZShub2RlLmtleSk7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBlbnRyeSA9IHtcblx0XHRcdFx0a2V5LFxuXHRcdFx0XHR2YWx1ZSxcblx0XHRcdFx0dmlzaXRlZDogZmFsc2Vcblx0XHRcdH07XG5cdFx0XHRuZXdlc3QgPSBlbnRyeTtcblx0XHRcdGNhY2hlLnNldChrZXksIGVudHJ5KTtcblx0XHR9LFxuXHRcdGNsZWFyKCkge1xuXHRcdFx0Y2FjaGUuY2xlYXIoKTtcblx0XHRcdGhhbmQgPSB2b2lkIDA7XG5cdFx0XHRuZXdlc3QgPSB2b2lkIDA7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjcmVhdGVTaWV2ZUNhY2hlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNpZXZlLWNhY2hlLmpzLm1hcCIsImltcG9ydCB7IGxhc3QgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgaW52YXJpYW50IH0gZnJvbSBcIi4vaW52YXJpYW50LmpzXCI7XG5pbXBvcnQgeyB0cmltUGF0aFJpZ2h0IH0gZnJvbSBcIi4vcGF0aC5qc1wiO1xuaW1wb3J0IHsgY3JlYXRlU2lldmVDYWNoZSB9IGZyb20gXCIuL3NpZXZlLWNhY2hlLmpzXCI7XG5jb25zdCBTRUdNRU5UX1RZUEVfSU5ERVggPSA0O1xuY29uc3QgU0VHTUVOVF9UWVBFX1BBVEhMRVNTID0gNTtcbmZ1bmN0aW9uIGdldFBhcmFtTmFtZXMoZGF0YSkge1xuXHRjb25zdCBjYWNoZWQgPSBkYXRhLm5hbWVzO1xuXHRpZiAoY2FjaGVkKSByZXR1cm4gY2FjaGVkO1xuXHRjb25zdCBrZXlzID0gW107XG5cdGZvciAoY29uc3Qgc2VnbWVudCBvZiBkYXRhKSBpZiAodHlwZW9mIHNlZ21lbnQgIT09IFwic3RyaW5nXCIpIGtleXMucHVzaChzZWdtZW50WzFdKTtcblx0cmV0dXJuIGRhdGEubmFtZXMgPSBrZXlzO1xufVxuLyoqIFBhcnNlIG9uZSBzZWdtZW50IGZvciBtYXRjaGluZyBhbmQgcmV0YWluIHRoZSBzYW1lIHJlY29yZCBmb3IgaW50ZXJwb2xhdGlvbi4gKi9cbmZ1bmN0aW9uIHBhcnNlU2VnbWVudChwYXRoLCBzdGFydCwgZW5kKSB7XG5cdGNvbnN0IHBhcnQgPSBwYXRoLnNsaWNlKHN0YXJ0LCBlbmQpO1xuXHRpZiAocGFydC5jaGFyQ29kZUF0KDApID09PSAzNikgcmV0dXJuIHBhcnQubGVuZ3RoID09PSAxID8gW1xuXHRcdDIsXG5cdFx0XCJfc3BsYXRcIixcblx0XHRcIlwiLFxuXHRcdHZvaWQgMFxuXHRdIDogW1xuXHRcdDEsXG5cdFx0cGFydC5zbGljZSgxKSxcblx0XHRcIlwiLFxuXHRcdFwiXCJcblx0XTtcblx0Y29uc3Qgb3BlbiA9IHBhcnQuaW5kZXhPZihcIntcIik7XG5cdGlmIChvcGVuID49IDApIHtcblx0XHRjb25zdCBjbG9zZSA9IHBhcnQuaW5kZXhPZihcIn1cIiwgb3Blbik7XG5cdFx0Y29uc3Qgb3B0aW9uYWwgPSBwYXJ0LmNoYXJDb2RlQXQob3BlbiArIDEpID09PSA0NTtcblx0XHRjb25zdCBuYW1lU3RhcnQgPSBvcGVuICsgKG9wdGlvbmFsID8gMyA6IDIpO1xuXHRcdGlmIChjbG9zZSA+PSAwICYmIHBhcnQuY2hhckNvZGVBdChuYW1lU3RhcnQgLSAxKSA9PT0gMzYgJiYgKCFvcHRpb25hbCB8fCBuYW1lU3RhcnQgPCBjbG9zZSkpIHtcblx0XHRcdGNvbnN0IGtleSA9IHBhcnQuc2xpY2UobmFtZVN0YXJ0LCBjbG9zZSk7XG5cdFx0XHRyZXR1cm4gW1xuXHRcdFx0XHRvcHRpb25hbCA/IDMgOiBrZXkgPyAxIDogMixcblx0XHRcdFx0a2V5IHx8IFwiX3NwbGF0XCIsXG5cdFx0XHRcdHBhcnQuc2xpY2UoMCwgb3BlbiksXG5cdFx0XHRcdHBhdGguc2xpY2Uoc3RhcnQgKyBjbG9zZSArIDEsIGtleSA/IGVuZCA6IHBhdGgubGVuZ3RoKVxuXHRcdFx0XTtcblx0XHR9XG5cdH1cblx0cmV0dXJuIHBhcnQ7XG59XG5mdW5jdGlvbiBwYXJzZVNlZ21lbnRzKGRlZmF1bHRDYXNlU2Vuc2l0aXZlLCByb3V0ZSwgc3RhcnQsIG5vZGUsIGR5bmFtaWNMaXN0c1RvU29ydCwgcGFyZW50SW50ZXJwb2xhdGlvbikge1xuXHRsZXQgY3Vyc29yID0gc3RhcnQ7XG5cdGNvbnN0IHBhdGggPSByb3V0ZS5mdWxsUGF0aCA/PyByb3V0ZS5mcm9tO1xuXHRjb25zdCBvcHRpb25zID0gcm91dGUub3B0aW9ucztcblx0Y29uc3QgbGVuZ3RoID0gcGF0aC5sZW5ndGg7XG5cdGNvbnN0IGxpdGVyYWxFbmQgPSBwYXRoLmVuZHNXaXRoKFwiL1wiKSA/IGxlbmd0aCAtIDEgOiBsZW5ndGg7XG5cdGNvbnN0IGNhc2VTZW5zaXRpdmUgPSBvcHRpb25zPy5jYXNlU2Vuc2l0aXZlID8/IGRlZmF1bHRDYXNlU2Vuc2l0aXZlO1xuXHRjb25zdCBwYXJzZVBhcmFtcyA9IG9wdGlvbnM/LnBhcmFtcz8ucGFyc2UgPz8gb3B0aW9ucz8ucGFyc2VQYXJhbXM7XG5cdGxldCBpbnRlcnBvbGF0aW9uO1xuXHRsZXQgbGl0ZXJhbFN0YXJ0ID0gcGFyZW50SW50ZXJwb2xhdGlvbiA/IHN0YXJ0IC0gMSA6IDA7XG5cdGlmICghbm9kZSB8fCBwYXRoLmluY2x1ZGVzKFwiJFwiKSkge1xuXHRcdGludGVycG9sYXRpb24gPSBwYXJlbnRJbnRlcnBvbGF0aW9uPy5zbGljZSgpID8/IFtdO1xuXHRcdGNvbnN0IHRhaWwgPSBsYXN0KGludGVycG9sYXRpb24pO1xuXHRcdGlmICh0YWlsICYmIHR5cGVvZiB0YWlsICE9PSBcInN0cmluZ1wiICYmIHRhaWxbMF0gPT09IDIpIHtcblx0XHRcdGludGVycG9sYXRpb25baW50ZXJwb2xhdGlvbi5sZW5ndGggLSAxXSA9IFtcblx0XHRcdFx0dGFpbFswXSxcblx0XHRcdFx0dGFpbFsxXSxcblx0XHRcdFx0dGFpbFsyXSxcblx0XHRcdFx0dGFpbFszXSA9PT0gdm9pZCAwID8gdm9pZCAwIDogdGFpbFszXSArIHBhdGguc3Vic3RyaW5nKHN0YXJ0IC0gKHBhdGhbc3RhcnQgLSAyXSA9PT0gXCIvXCIgPyAyIDogMSksIGxpdGVyYWxFbmQpXG5cdFx0XHRdO1xuXHRcdFx0bGl0ZXJhbFN0YXJ0ID0gbGVuZ3RoO1xuXHRcdH1cblx0fVxuXHR3aGlsZSAoY3Vyc29yIDwgbGVuZ3RoKSB7XG5cdFx0Y29uc3Qgc3RhcnQgPSBjdXJzb3I7XG5cdFx0Y29uc3QgbmV4dCA9IHBhdGguaW5kZXhPZihcIi9cIiwgc3RhcnQpO1xuXHRcdGxldCBlbmQgPSBuZXh0ID09PSAtMSA/IGxlbmd0aCA6IG5leHQ7XG5cdFx0Y29uc3Qgc2VnbWVudCA9IHBhcnNlU2VnbWVudChwYXRoLCBzdGFydCwgZW5kKTtcblx0XHRjdXJzb3IgPSBlbmQgKyAxO1xuXHRcdGxldCBuZXh0Tm9kZTtcblx0XHRpZiAodHlwZW9mIHNlZ21lbnQgPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdGlmICghbm9kZSkgY29udGludWU7XG5cdFx0XHRsZXQgbmFtZSA9IHNlZ21lbnQ7XG5cdFx0XHRsZXQgc3RhdGljQ2hpbGRyZW47XG5cdFx0XHRpZiAoY2FzZVNlbnNpdGl2ZSkgc3RhdGljQ2hpbGRyZW4gPSBub2RlLnN0YXRpYyA/Pz0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRuYW1lID0gc2VnbWVudC50b0xvd2VyQ2FzZSgpO1xuXHRcdFx0XHRzdGF0aWNDaGlsZHJlbiA9IG5vZGUuc3RhdGljSW5zZW5zaXRpdmUgPz89IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBleGlzdGluZ05vZGUgPSBzdGF0aWNDaGlsZHJlbi5nZXQobmFtZSk7XG5cdFx0XHRpZiAoZXhpc3RpbmdOb2RlKSBuZXh0Tm9kZSA9IGV4aXN0aW5nTm9kZTtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRjb25zdCBuZXh0ID0gY3JlYXRlU2VnbWVudE5vZGUobm9kZSk7XG5cdFx0XHRcdG5leHROb2RlID0gbmV4dDtcblx0XHRcdFx0c3RhdGljQ2hpbGRyZW4uc2V0KG5hbWUsIG5leHQpO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRjb25zdCBraW5kID0gc2VnbWVudFswXTtcblx0XHRcdGxldCBwcmVmaXggPSBzZWdtZW50WzJdO1xuXHRcdFx0bGV0IHN1ZmZpeCA9IHNlZ21lbnRbM10gPz8gXCJcIjtcblx0XHRcdGlmIChraW5kID09PSAyKSB7XG5cdFx0XHRcdGVuZCA9IGxlbmd0aDtcblx0XHRcdFx0Y3Vyc29yID0gZW5kICsgMTtcblx0XHRcdH1cblx0XHRcdGlmIChpbnRlcnBvbGF0aW9uICYmIGxpdGVyYWxTdGFydCA8IGVuZCkge1xuXHRcdFx0XHRpZiAobGl0ZXJhbFN0YXJ0IDwgc3RhcnQgLSAxKSBpbnRlcnBvbGF0aW9uLnB1c2gocGF0aC5zbGljZShsaXRlcmFsU3RhcnQsIHN0YXJ0IC0gMSkpO1xuXHRcdFx0XHRzZWdtZW50WzJdID0gXCIvXCIgKyBwcmVmaXg7XG5cdFx0XHRcdGlmIChraW5kID09PSAyICYmIHNlZ21lbnRbM10gIT09IHZvaWQgMCAmJiBsaXRlcmFsRW5kIDwgbGVuZ3RoKSBzZWdtZW50WzNdID0gc3VmZml4LnNsaWNlKDAsIC0xKTtcblx0XHRcdFx0aW50ZXJwb2xhdGlvbi5wdXNoKHNlZ21lbnQpO1xuXHRcdFx0XHRsaXRlcmFsU3RhcnQgPSBlbmQ7XG5cdFx0XHR9XG5cdFx0XHRpZiAoIW5vZGUpIGNvbnRpbnVlO1xuXHRcdFx0Y29uc3QgYWN0dWFsbHlDYXNlU2Vuc2l0aXZlID0gY2FzZVNlbnNpdGl2ZSAmJiAhIShwcmVmaXggfHwgc3VmZml4KTtcblx0XHRcdGlmICghY2FzZVNlbnNpdGl2ZSkge1xuXHRcdFx0XHRwcmVmaXggPSBwcmVmaXgudG9Mb3dlckNhc2UoKTtcblx0XHRcdFx0c3VmZml4ID0gc3VmZml4LnRvTG93ZXJDYXNlKCk7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBzaWJsaW5ncyA9IGtpbmQgPT09IDEgPyBub2RlLmR5bmFtaWMgPz89IFtdIDoga2luZCA9PT0gMyA/IG5vZGUub3B0aW9uYWwgPz89IFtdIDogbm9kZS53aWxkY2FyZCA/Pz0gW107XG5cdFx0XHRjb25zdCBleGlzdGluZ05vZGUgPSBraW5kICE9PSAyICYmICFwYXJzZVBhcmFtcyAmJiBzaWJsaW5ncy5maW5kKChzKSA9PiAhcy5wYXJzZSAmJiBzLmNhc2VTZW5zaXRpdmUgPT09IGFjdHVhbGx5Q2FzZVNlbnNpdGl2ZSAmJiBzLnByZWZpeCA9PT0gcHJlZml4ICYmIHMuc3VmZml4ID09PSBzdWZmaXgpO1xuXHRcdFx0aWYgKGV4aXN0aW5nTm9kZSkgbmV4dE5vZGUgPSBleGlzdGluZ05vZGU7XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0Y29uc3QgbmV4dCA9IGNyZWF0ZVNlZ21lbnROb2RlKG5vZGUsIGtpbmQsIGFjdHVhbGx5Q2FzZVNlbnNpdGl2ZSwgcHJlZml4LCBzdWZmaXgpO1xuXHRcdFx0XHRuZXh0Tm9kZSA9IG5leHQ7XG5cdFx0XHRcdHNpYmxpbmdzLnB1c2gobmV4dCk7XG5cdFx0XHRcdGlmIChzaWJsaW5ncy5sZW5ndGggPT09IDIpIGR5bmFtaWNMaXN0c1RvU29ydD8ucHVzaChzaWJsaW5ncyk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdG5vZGUgPSBuZXh0Tm9kZTtcblx0fVxuXHRpZiAoaW50ZXJwb2xhdGlvbiAmJiBsaXRlcmFsU3RhcnQgPCBsaXRlcmFsRW5kKSBpbnRlcnBvbGF0aW9uLnB1c2gocGF0aC5zbGljZShsaXRlcmFsU3RhcnQsIGxpdGVyYWxFbmQpKTtcblx0Y29uc3Qgc2VnbWVudERhdGEgPSBpbnRlcnBvbGF0aW9uPy5zbGljZSgpO1xuXHRpZiAoIW5vZGUpIHJldHVybiBzZWdtZW50RGF0YTtcblx0aWYgKHBhcnNlUGFyYW1zICYmIHJvdXRlLmNoaWxkcmVuICYmICFyb3V0ZS5pc1Jvb3QgJiYgcm91dGUuaWQgJiYgcm91dGUuaWQuY2hhckNvZGVBdChyb3V0ZS5pZC5sYXN0SW5kZXhPZihcIi9cIikgKyAxKSA9PT0gOTUpIHtcblx0XHRjb25zdCBwYXRobGVzc05vZGUgPSBjcmVhdGVTZWdtZW50Tm9kZShub2RlLCBTRUdNRU5UX1RZUEVfUEFUSExFU1MpO1xuXHRcdChub2RlLnBhdGhsZXNzID8/PSBbXSkucHVzaChwYXRobGVzc05vZGUpO1xuXHRcdG5vZGUgPSBwYXRobGVzc05vZGU7XG5cdH1cblx0Y29uc3QgaXNMZWFmID0gKHJvdXRlLnBhdGggfHwgIXJvdXRlLmNoaWxkcmVuKSAmJiAhcm91dGUuaXNSb290O1xuXHRpZiAoaXNMZWFmICYmIGxpdGVyYWxFbmQgPCBsZW5ndGgpIHtcblx0XHRjb25zdCBpbmRleE5vZGUgPSBjcmVhdGVTZWdtZW50Tm9kZShub2RlLCBTRUdNRU5UX1RZUEVfSU5ERVgpO1xuXHRcdG5vZGUuaW5kZXggPSBpbmRleE5vZGU7XG5cdFx0bm9kZSA9IGluZGV4Tm9kZTtcblx0fVxuXHRub2RlLnBhcnNlID0gcGFyc2VQYXJhbXMgPz8gbnVsbDtcblx0bm9kZS5wcmlvcml0eSA9IG9wdGlvbnM/LnBhcmFtcz8ucHJpb3JpdHkgPz8gMDtcblx0aWYgKCFub2RlLnJvdXRlKSB7XG5cdFx0bm9kZS5kYXRhID0gc2VnbWVudERhdGE7XG5cdFx0aWYgKGlzTGVhZikgbm9kZS5yb3V0ZSA9IHJvdXRlO1xuXHR9XG5cdHJldHVybiBbXG5cdFx0bm9kZSxcblx0XHRjdXJzb3IsXG5cdFx0c2VnbWVudERhdGFcblx0XTtcbn1cbmZ1bmN0aW9uIHNvcnREeW5hbWljKGEsIGIpIHtcblx0aWYgKGEucGFyc2UgJiYgIWIucGFyc2UpIHJldHVybiAtMTtcblx0aWYgKCFhLnBhcnNlICYmIGIucGFyc2UpIHJldHVybiAxO1xuXHRpZiAoYS5wYXJzZSAmJiBiLnBhcnNlICYmIChhLnByaW9yaXR5IHx8IGIucHJpb3JpdHkpKSByZXR1cm4gYi5wcmlvcml0eSAtIGEucHJpb3JpdHk7XG5cdGlmIChhLnByZWZpeCAmJiBiLnByZWZpeCAmJiBhLnByZWZpeCAhPT0gYi5wcmVmaXgpIHtcblx0XHRpZiAoYS5wcmVmaXguc3RhcnRzV2l0aChiLnByZWZpeCkpIHJldHVybiAtMTtcblx0XHRpZiAoYi5wcmVmaXguc3RhcnRzV2l0aChhLnByZWZpeCkpIHJldHVybiAxO1xuXHR9XG5cdGlmIChhLnN1ZmZpeCAmJiBiLnN1ZmZpeCAmJiBhLnN1ZmZpeCAhPT0gYi5zdWZmaXgpIHtcblx0XHRpZiAoYS5zdWZmaXguZW5kc1dpdGgoYi5zdWZmaXgpKSByZXR1cm4gLTE7XG5cdFx0aWYgKGIuc3VmZml4LmVuZHNXaXRoKGEuc3VmZml4KSkgcmV0dXJuIDE7XG5cdH1cblx0aWYgKGEucHJlZml4ICYmICFiLnByZWZpeCkgcmV0dXJuIC0xO1xuXHRpZiAoIWEucHJlZml4ICYmIGIucHJlZml4KSByZXR1cm4gMTtcblx0aWYgKGEuc3VmZml4ICYmICFiLnN1ZmZpeCkgcmV0dXJuIC0xO1xuXHRpZiAoIWEuc3VmZml4ICYmIGIuc3VmZml4KSByZXR1cm4gMTtcblx0aWYgKGEuY2FzZVNlbnNpdGl2ZSAmJiAhYi5jYXNlU2Vuc2l0aXZlKSByZXR1cm4gLTE7XG5cdGlmICghYS5jYXNlU2Vuc2l0aXZlICYmIGIuY2FzZVNlbnNpdGl2ZSkgcmV0dXJuIDE7XG5cdHJldHVybiAwO1xufVxuZnVuY3Rpb24gY3JlYXRlU2VnbWVudE5vZGUocGFyZW50LCBraW5kID0gMCwgY2FzZVNlbnNpdGl2ZSwgcHJlZml4LCBzdWZmaXgpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kLFxuXHRcdGRlcHRoOiBwYXJlbnQgPyBwYXJlbnQuZGVwdGggKyAxIDogMCxcblx0XHRwYXRobGVzczogbnVsbCxcblx0XHRpbmRleDogbnVsbCxcblx0XHRzdGF0aWM6IG51bGwsXG5cdFx0c3RhdGljSW5zZW5zaXRpdmU6IG51bGwsXG5cdFx0ZHluYW1pYzogbnVsbCxcblx0XHRvcHRpb25hbDogbnVsbCxcblx0XHR3aWxkY2FyZDogbnVsbCxcblx0XHRyb3V0ZTogbnVsbCxcblx0XHRkYXRhOiB2b2lkIDAsXG5cdFx0cGFyZW50LFxuXHRcdHBhcnNlOiBudWxsLFxuXHRcdHByaW9yaXR5OiAwLFxuXHRcdGNhc2VTZW5zaXRpdmUsXG5cdFx0cHJlZml4LFxuXHRcdHN1ZmZpeFxuXHR9O1xufVxuZnVuY3Rpb24gcHJvY2Vzc1JvdXRlTWFza3Mocm91dGVMaXN0LCBwcm9jZXNzZWRUcmVlKSB7XG5cdGNvbnN0IHNlZ21lbnRUcmVlID0gY3JlYXRlU2VnbWVudE5vZGUoKTtcblx0Y29uc3QgZHluYW1pY0xpc3RzVG9Tb3J0ID0gW107XG5cdGZ1bmN0aW9uIHZpc2l0KHJvdXRlLCBzdGFydCwgcGFyZW50Tm9kZSwgcGFyZW50SW50ZXJwb2xhdGlvbikge1xuXHRcdGNvbnN0IFtub2RlLCBjdXJzb3IsIHNlZ21lbnRzXSA9IHBhcnNlU2VnbWVudHMoZmFsc2UsIHJvdXRlLCBzdGFydCwgcGFyZW50Tm9kZSwgZHluYW1pY0xpc3RzVG9Tb3J0LCBwYXJlbnRJbnRlcnBvbGF0aW9uKTtcblx0XHRpZiAocm91dGUuY2hpbGRyZW4pIGZvciAoY29uc3QgY2hpbGQgb2Ygcm91dGUuY2hpbGRyZW4pIHZpc2l0KGNoaWxkLCBjdXJzb3IsIG5vZGUsIHNlZ21lbnRzKTtcblx0fVxuXHRmb3IgKGNvbnN0IHJvdXRlIG9mIHJvdXRlTGlzdCkgdmlzaXQocm91dGUsIDEsIHNlZ21lbnRUcmVlKTtcblx0Zm9yIChjb25zdCBub2RlcyBvZiBkeW5hbWljTGlzdHNUb1NvcnQpIG5vZGVzLnNvcnQoc29ydER5bmFtaWMpO1xuXHRwcm9jZXNzZWRUcmVlLm1hc2tzVHJlZSA9IHNlZ21lbnRUcmVlO1xuXHRwcm9jZXNzZWRUcmVlLmZsYXRDYWNoZSA9IGNyZWF0ZVNpZXZlQ2FjaGUoMWUzKTtcbn1cbi8qKlxuKiBUYWtlIGFuIGFyYml0cmFyeSBsaXN0IG9mIHJvdXRlcywgY3JlYXRlIGEgdHJlZSBmcm9tIHRoZW0gKGlmIGl0IGhhc24ndCBiZWVuIGNyZWF0ZWQgYWxyZWFkeSksIGFuZCBtYXRjaCBhIHBhdGggYWdhaW5zdCBpdC5cbiovXG5mdW5jdGlvbiBmaW5kRmxhdE1hdGNoKHBhdGgsIHByb2Nlc3NlZFRyZWUpIHtcblx0cGF0aCB8fD0gXCIvXCI7XG5cdGNvbnN0IGNhY2hlZCA9IHByb2Nlc3NlZFRyZWUuZmxhdENhY2hlLmdldChwYXRoKTtcblx0aWYgKGNhY2hlZCAhPT0gdm9pZCAwKSByZXR1cm4gY2FjaGVkO1xuXHRjb25zdCByZXN1bHQgPSBmaW5kTWF0Y2gocGF0aCwgcHJvY2Vzc2VkVHJlZS5tYXNrc1RyZWUpO1xuXHRwcm9jZXNzZWRUcmVlLmZsYXRDYWNoZS5zZXQocGF0aCwgcmVzdWx0KTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbi8qKlxuKiBAZGVwcmVjYXRlZCBrZWVwIHVudGlsIHYyIHNvIHRoYXQgYHJvdXRlci5tYXRjaFJvdXRlYCBjYW4ga2VlcCBub3QgY2FyaW5nIGFib3V0IHRoZSBhY3R1YWwgcm91dGUgdHJlZVxuKi9cbmZ1bmN0aW9uIGZpbmRTaW5nbGVNYXRjaChmcm9tLCBjYXNlU2Vuc2l0aXZlLCBmdXp6eSwgcGF0aCwgcHJvY2Vzc2VkVHJlZSkge1xuXHRmcm9tIHx8PSBcIi9cIjtcblx0cGF0aCB8fD0gXCIvXCI7XG5cdGNvbnN0IGtleSA9IGNhc2VTZW5zaXRpdmUgPyBgY2FzZVxcMCR7ZnJvbX1gIDogZnJvbTtcblx0bGV0IHRyZWUgPSBwcm9jZXNzZWRUcmVlLnNpbmdsZUNhY2hlLmdldChrZXkpO1xuXHRpZiAoIXRyZWUpIHtcblx0XHR0cmVlID0gY3JlYXRlU2VnbWVudE5vZGUoKTtcblx0XHRwYXJzZVNlZ21lbnRzKGNhc2VTZW5zaXRpdmUsIHsgZnJvbSB9LCAxLCB0cmVlKTtcblx0XHRwcm9jZXNzZWRUcmVlLnNpbmdsZUNhY2hlLnNldChrZXksIHRyZWUpO1xuXHR9XG5cdHJldHVybiBmaW5kTWF0Y2gocGF0aCwgdHJlZSwgZnV6enkpO1xufVxuZnVuY3Rpb24gZmluZFJvdXRlTWF0Y2gocGF0aCwgcHJvY2Vzc2VkVHJlZSwgZnV6enkgPSBmYWxzZSkge1xuXHRjb25zdCBrZXkgPSBmdXp6eSA/IHBhdGggOiBgbm9mdXp6XFwwJHtwYXRofWA7XG5cdGNvbnN0IGNhY2hlZCA9IHByb2Nlc3NlZFRyZWUubWF0Y2hDYWNoZS5nZXQoa2V5KTtcblx0aWYgKGNhY2hlZCAhPT0gdm9pZCAwKSByZXR1cm4gY2FjaGVkO1xuXHRwYXRoIHx8PSBcIi9cIjtcblx0bGV0IHJlc3VsdDtcblx0dHJ5IHtcblx0XHRyZXN1bHQgPSBmaW5kTWF0Y2gocGF0aCwgcHJvY2Vzc2VkVHJlZS5zZWdtZW50VHJlZSwgZnV6enkpO1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRpZiAoZXJyIGluc3RhbmNlb2YgVVJJRXJyb3IpIHJlc3VsdCA9IG51bGw7XG5cdFx0ZWxzZSB0aHJvdyBlcnI7XG5cdH1cblx0aWYgKHJlc3VsdCkgcmVzdWx0LmJyYW5jaCA9IGJ1aWxkUm91dGVCcmFuY2gocmVzdWx0LnJvdXRlKTtcblx0cHJvY2Vzc2VkVHJlZS5tYXRjaENhY2hlLnNldChrZXksIHJlc3VsdCk7XG5cdHJldHVybiByZXN1bHQ7XG59XG4vKipcbiogUHJvY2Vzc2VzIGEgcm91dGUgdHJlZSBpbnRvIGEgc2VnbWVudCB0cmllIGZvciBlZmZpY2llbnQgcGF0aCBtYXRjaGluZy5cbiogQWxzbyBidWlsZHMgbG9va3VwIG1hcHMgZm9yIHJvdXRlcyBieSBJRCBhbmQgYnkgdHJpbW1lZCBmdWxsIHBhdGguXG4qL1xuZnVuY3Rpb24gcHJvY2Vzc1JvdXRlVHJlZShyb3V0ZVRyZWUsIGNhc2VTZW5zaXRpdmUgPSBmYWxzZSkge1xuXHRjb25zdCBzZWdtZW50VHJlZSA9IGNyZWF0ZVNlZ21lbnROb2RlKCk7XG5cdGNvbnN0IGR5bmFtaWNMaXN0c1RvU29ydCA9IFtdO1xuXHRjb25zdCByb3V0ZXNCeUlkID0ge307XG5cdGNvbnN0IHJvdXRlc0J5UGF0aCA9IHt9O1xuXHRsZXQgaW5kZXggPSAwO1xuXHRmdW5jdGlvbiB2aXNpdChyb3V0ZSwgc3RhcnQsIHBhcmVudE5vZGUsIHBhcmVudEludGVycG9sYXRpb24pIHtcblx0XHRyb3V0ZS5pbml0KGluZGV4KTtcblx0XHRpZiAocm91dGUuaWQgaW4gcm91dGVzQnlJZCkge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgdGhyb3cgbmV3IEVycm9yKGBJbnZhcmlhbnQgZmFpbGVkOiBEdXBsaWNhdGUgcm91dGVzIGZvdW5kIHdpdGggaWQ6ICR7U3RyaW5nKHJvdXRlLmlkKX1gKTtcblx0XHRcdGludmFyaWFudCgpO1xuXHRcdH1cblx0XHRyb3V0ZXNCeUlkW3JvdXRlLmlkXSA9IHJvdXRlO1xuXHRcdGlmIChpbmRleCAhPT0gMCAmJiByb3V0ZS5wYXRoKSB7XG5cdFx0XHRjb25zdCB0cmltbWVkRnVsbFBhdGggPSB0cmltUGF0aFJpZ2h0KHJvdXRlLmZ1bGxQYXRoKTtcblx0XHRcdGlmICghcm91dGVzQnlQYXRoW3RyaW1tZWRGdWxsUGF0aF0gfHwgcm91dGUuZnVsbFBhdGguZW5kc1dpdGgoXCIvXCIpKSByb3V0ZXNCeVBhdGhbdHJpbW1lZEZ1bGxQYXRoXSA9IHJvdXRlO1xuXHRcdH1cblx0XHRpbmRleCsrO1xuXHRcdGNvbnN0IFtub2RlLCBjdXJzb3IsIHNlZ21lbnRzXSA9IHBhcnNlU2VnbWVudHMoY2FzZVNlbnNpdGl2ZSwgcm91dGUsIHN0YXJ0LCBwYXJlbnROb2RlLCBkeW5hbWljTGlzdHNUb1NvcnQsIHBhcmVudEludGVycG9sYXRpb24pO1xuXHRcdHJvdXRlLl9pbnRlcnBvbGF0aW9uID0gc2VnbWVudHM7XG5cdFx0aWYgKHJvdXRlLmNoaWxkcmVuKSBmb3IgKGNvbnN0IGNoaWxkIG9mIHJvdXRlLmNoaWxkcmVuKSB2aXNpdChjaGlsZCwgY3Vyc29yLCBub2RlLCBzZWdtZW50cyk7XG5cdH1cblx0dmlzaXQocm91dGVUcmVlLCAxLCBzZWdtZW50VHJlZSk7XG5cdGZvciAoY29uc3Qgbm9kZXMgb2YgZHluYW1pY0xpc3RzVG9Tb3J0KSBub2Rlcy5zb3J0KHNvcnREeW5hbWljKTtcblx0cmV0dXJuIHtcblx0XHRwcm9jZXNzZWRUcmVlOiB7XG5cdFx0XHRzZWdtZW50VHJlZSxcblx0XHRcdHNpbmdsZUNhY2hlOiBjcmVhdGVTaWV2ZUNhY2hlKDFlMyksXG5cdFx0XHRtYXRjaENhY2hlOiBjcmVhdGVTaWV2ZUNhY2hlKDFlMyksXG5cdFx0XHRmbGF0Q2FjaGU6IG51bGwsXG5cdFx0XHRtYXNrc1RyZWU6IG51bGxcblx0XHR9LFxuXHRcdHJvdXRlc0J5SWQsXG5cdFx0cm91dGVzQnlQYXRoXG5cdH07XG59XG5mdW5jdGlvbiBmaW5kTWF0Y2gocGF0aCwgc2VnbWVudFRyZWUsIGZ1enp5ID0gZmFsc2UpIHtcblx0Y29uc3QgcGFydHMgPSBwYXRoLnNwbGl0KFwiL1wiKTtcblx0Y29uc3QgbGVhZiA9IGdldE5vZGVNYXRjaChwYXRoLCBwYXJ0cywgc2VnbWVudFRyZWUsIGZ1enp5KTtcblx0aWYgKCFsZWFmKSByZXR1cm4gbnVsbDtcblx0Y29uc3QgW3Jhd1BhcmFtc10gPSBleHRyYWN0UGFyYW1zKHBhdGgsIHBhcnRzLCBsZWFmKTtcblx0cmV0dXJuIHtcblx0XHRyb3V0ZTogbGVhZi5ub2RlLnJvdXRlLFxuXHRcdHJhd1BhcmFtc1xuXHR9O1xufVxuLyoqXG4qIFRoaXMgZnVuY3Rpb24gaXMgXCJyZXN1bWFibGVcIjpcbiogLSB0aGUgYGxlYWZgIGlucHV0IGNhbiBjb250YWluIGBleHRyYWN0YCBhbmQgYHJhd1BhcmFtc2AgcHJvcGVydGllcyBmcm9tIGEgcHJldmlvdXMgYGV4dHJhY3RQYXJhbXNgIGNhbGxcbiogLSB0aGUgcmV0dXJuZWQgYHN0YXRlYCBjYW4gYmUgcGFzc2VkIGJhY2sgYXMgYGV4dHJhY3RgIGluIGEgZnV0dXJlIGNhbGwgdG8gY29udGludWUgZXh0cmFjdGluZyBwYXJhbXMgZnJvbSB3aGVyZSB3ZSBsZWZ0IG9mZlxuKlxuKiBJbnB1dHMgYXJlICpub3QqIG11dGF0ZWQuXG4qL1xuZnVuY3Rpb24gZXh0cmFjdFBhcmFtcyhwYXRoLCBwYXJ0cywgbGVhZikge1xuXHRjb25zdCBsaXN0ID0gYnVpbGRCcmFuY2gobGVhZi5ub2RlKTtcblx0Y29uc3QgbmFtZXMgPSBsZWFmLm5vZGUuZGF0YSAmJiBnZXRQYXJhbU5hbWVzKGxlYWYubm9kZS5kYXRhKTtcblx0Y29uc3QgcmF3UGFyYW1zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblx0LyoqIHdoaWNoIHNlZ21lbnQgb2YgdGhlIHBhdGggd2UncmUgY3VycmVudGx5IHByb2Nlc3NpbmcgKi9cblx0bGV0IHBhcnRJbmRleCA9IGxlYWYuZXh0cmFjdD8ucGFydCA/PyAwO1xuXHQvKiogd2hpY2ggbm9kZSBvZiB0aGUgcm91dGUgdHJlZSBicmFuY2ggd2UncmUgY3VycmVudGx5IHByb2Nlc3NpbmcgKi9cblx0bGV0IG5vZGVJbmRleCA9IGxlYWYuZXh0cmFjdD8ubm9kZSA/PyAwO1xuXHQvKiogaW5kZXggb2YgdGhlIDFzdCBjaGFyYWN0ZXIgb2YgdGhlIHNlZ21lbnQgd2UncmUgcHJvY2Vzc2luZyBpbiB0aGUgcGF0aCBzdHJpbmcgKi9cblx0bGV0IHBhdGhJbmRleCA9IGxlYWYuZXh0cmFjdD8ucGF0aCA/PyAwO1xuXHQvKiogTmV4dCBvcmlnaW5hbCBwYXJhbWV0ZXIgbmFtZSwgaW5kZXBlbmRlbnQgb2YgcGF0aGxlc3Mvc3RhdGljIG5vZGVzLiAqL1xuXHRsZXQgcGFyYW1JbmRleCA9IGxlYWYuZXh0cmFjdD8ucGFyYW0gPz8gMDtcblx0Zm9yICg7IG5vZGVJbmRleCA8IGxpc3QubGVuZ3RoOyBwYXJ0SW5kZXgrKywgbm9kZUluZGV4KyssIHBhdGhJbmRleCsrKSB7XG5cdFx0Y29uc3Qgbm9kZSA9IGxpc3Rbbm9kZUluZGV4XTtcblx0XHRpZiAobm9kZS5raW5kID09PSBTRUdNRU5UX1RZUEVfSU5ERVgpIGJyZWFrO1xuXHRcdGlmIChub2RlLmtpbmQgPT09IFNFR01FTlRfVFlQRV9QQVRITEVTUykge1xuXHRcdFx0cGFydEluZGV4LS07XG5cdFx0XHRwYXRoSW5kZXgtLTtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRjb25zdCBwYXJ0ID0gcGFydHNbcGFydEluZGV4XTtcblx0XHRjb25zdCBjdXJyZW50UGF0aEluZGV4ID0gcGF0aEluZGV4O1xuXHRcdGlmIChwYXJ0KSBwYXRoSW5kZXggKz0gcGFydC5sZW5ndGg7XG5cdFx0aWYgKG5vZGUua2luZCA9PT0gMSB8fCBub2RlLmtpbmQgPT09IDMpIHtcblx0XHRcdGNvbnN0IG5hbWUgPSBuYW1lc1twYXJhbUluZGV4KytdO1xuXHRcdFx0aWYgKG5vZGUua2luZCA9PT0gMyAmJiBsZWFmLnNraXBwZWQgJiAxIDw8IG5vZGVJbmRleCkge1xuXHRcdFx0XHRwYXJ0SW5kZXgtLTtcblx0XHRcdFx0cGF0aEluZGV4ID0gY3VycmVudFBhdGhJbmRleCAtIDE7XG5cdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgdmFsdWUgPSBub2RlLnN1ZmZpeCB8fCBub2RlLnByZWZpeCA/IHBhcnQuc3Vic3RyaW5nKG5vZGUucHJlZml4Lmxlbmd0aCwgcGFydC5sZW5ndGggLSBub2RlLnN1ZmZpeC5sZW5ndGgpIDogcGFydDtcblx0XHRcdGlmICh2YWx1ZSB8fCBub2RlLmtpbmQgPT09IDEpIHJhd1BhcmFtc1tuYW1lXSA9IGRlY29kZVVSSUNvbXBvbmVudCh2YWx1ZSk7XG5cdFx0fSBlbHNlIGlmIChub2RlLmtpbmQgPT09IDIpIHtcblx0XHRcdGNvbnN0IG4gPSBub2RlO1xuXHRcdFx0Y29uc3QgdmFsdWUgPSBwYXRoLnN1YnN0cmluZyhjdXJyZW50UGF0aEluZGV4ICsgbi5wcmVmaXgubGVuZ3RoLCBwYXRoLmxlbmd0aCAtIG4uc3VmZml4Lmxlbmd0aCk7XG5cdFx0XHRjb25zdCBzcGxhdCA9IGRlY29kZVVSSUNvbXBvbmVudCh2YWx1ZSk7XG5cdFx0XHRyYXdQYXJhbXNbXCIqXCJdID0gc3BsYXQ7XG5cdFx0XHRyYXdQYXJhbXMuX3NwbGF0ID0gc3BsYXQ7XG5cdFx0XHRicmVhaztcblx0XHR9XG5cdH1cblx0aWYgKGxlYWYucmF3UGFyYW1zKSBPYmplY3QuYXNzaWduKHJhd1BhcmFtcywgbGVhZi5yYXdQYXJhbXMpO1xuXHRyZXR1cm4gW3Jhd1BhcmFtcywge1xuXHRcdHBhcnQ6IHBhcnRJbmRleCxcblx0XHRub2RlOiBub2RlSW5kZXgsXG5cdFx0cGF0aDogcGF0aEluZGV4LFxuXHRcdHBhcmFtOiBwYXJhbUluZGV4XG5cdH1dO1xufVxuZnVuY3Rpb24gYnVpbGRSb3V0ZUJyYW5jaChyb3V0ZSkge1xuXHRjb25zdCBsaXN0ID0gW3JvdXRlXTtcblx0d2hpbGUgKHJvdXRlLnBhcmVudFJvdXRlKSB7XG5cdFx0cm91dGUgPSByb3V0ZS5wYXJlbnRSb3V0ZTtcblx0XHRsaXN0LnB1c2gocm91dGUpO1xuXHR9XG5cdGxpc3QucmV2ZXJzZSgpO1xuXHRyZXR1cm4gbGlzdDtcbn1cbmZ1bmN0aW9uIGJ1aWxkQnJhbmNoKG5vZGUpIHtcblx0Y29uc3QgbGlzdCA9IEFycmF5KG5vZGUuZGVwdGggKyAxKTtcblx0ZG8ge1xuXHRcdGxpc3Rbbm9kZS5kZXB0aF0gPSBub2RlO1xuXHRcdG5vZGUgPSBub2RlLnBhcmVudDtcblx0fSB3aGlsZSAobm9kZSk7XG5cdHJldHVybiBsaXN0O1xufVxuZnVuY3Rpb24gZ2V0Tm9kZU1hdGNoKHBhdGgsIHBhcnRzLCBzZWdtZW50VHJlZSwgZnV6enkpIHtcblx0aWYgKHBhdGggPT09IFwiL1wiICYmIHNlZ21lbnRUcmVlLmluZGV4KSByZXR1cm4ge1xuXHRcdG5vZGU6IHNlZ21lbnRUcmVlLmluZGV4LFxuXHRcdHNraXBwZWQ6IDBcblx0fTtcblx0Y29uc3QgdHJhaWxpbmdTbGFzaCA9ICFsYXN0KHBhcnRzKTtcblx0Y29uc3QgcGF0aElzSW5kZXggPSB0cmFpbGluZ1NsYXNoICYmIHBhdGggIT09IFwiL1wiO1xuXHRjb25zdCBwYXJ0c0xlbmd0aCA9IHBhcnRzLmxlbmd0aCAtICh0cmFpbGluZ1NsYXNoID8gMSA6IDApO1xuXHRjb25zdCBzdGFjayA9IFt7XG5cdFx0bm9kZTogc2VnbWVudFRyZWUsXG5cdFx0aW5kZXg6IDEsXG5cdFx0c2tpcHBlZDogMCxcblx0XHRzdGF0aWNzOiAwLFxuXHRcdGR5bmFtaWNzOiAwLFxuXHRcdG9wdGlvbmFsczogMFxuXHR9XTtcblx0bGV0IGJlc3RGdXp6eSA9IG51bGw7XG5cdGxldCBiZXN0TWF0Y2ggPSBudWxsO1xuXHR3aGlsZSAoc3RhY2subGVuZ3RoKSB7XG5cdFx0Y29uc3QgZnJhbWUgPSBzdGFjay5wb3AoKTtcblx0XHRjb25zdCB7IG5vZGUsIGluZGV4LCBza2lwcGVkLCBzdGF0aWNzLCBkeW5hbWljcywgb3B0aW9uYWxzIH0gPSBmcmFtZTtcblx0XHRsZXQgeyBleHRyYWN0LCByYXdQYXJhbXMgfSA9IGZyYW1lO1xuXHRcdGlmIChub2RlLmtpbmQgPT09IDIgJiYgbm9kZS5yb3V0ZSAmJiAhaXNGcmFtZU1vcmVTcGVjaWZpYyhiZXN0TWF0Y2gsIGZyYW1lKSkgY29udGludWU7XG5cdFx0aWYgKG5vZGUucGFyc2UpIHtcblx0XHRcdGlmICghdmFsaWRhdGVQYXJzZVBhcmFtcyhwYXRoLCBwYXJ0cywgZnJhbWUpKSBjb250aW51ZTtcblx0XHRcdHJhd1BhcmFtcyA9IGZyYW1lLnJhd1BhcmFtcztcblx0XHRcdGV4dHJhY3QgPSBmcmFtZS5leHRyYWN0O1xuXHRcdH1cblx0XHRpZiAoZnV6enkgJiYgbm9kZS5yb3V0ZSAmJiBub2RlLmtpbmQgIT09IFNFR01FTlRfVFlQRV9JTkRFWCAmJiBpc0ZyYW1lTW9yZVNwZWNpZmljKGJlc3RGdXp6eSwgZnJhbWUpKSBiZXN0RnV6enkgPSBmcmFtZTtcblx0XHRjb25zdCBpc0JleW9uZFBhdGggPSBpbmRleCA9PT0gcGFydHNMZW5ndGg7XG5cdFx0aWYgKGlzQmV5b25kUGF0aCkge1xuXHRcdFx0aWYgKG5vZGUucm91dGUgJiYgKCFwYXRoSXNJbmRleCB8fCBub2RlLmtpbmQgPT09IFNFR01FTlRfVFlQRV9JTkRFWCB8fCBub2RlLmtpbmQgPT09IDIpICYmIGlzRnJhbWVNb3JlU3BlY2lmaWMoYmVzdE1hdGNoLCBmcmFtZSkpIGJlc3RNYXRjaCA9IGZyYW1lO1xuXHRcdFx0aWYgKCFub2RlLm9wdGlvbmFsICYmICFub2RlLndpbGRjYXJkICYmICFub2RlLmluZGV4ICYmICFub2RlLnBhdGhsZXNzKSBjb250aW51ZTtcblx0XHR9XG5cdFx0Y29uc3QgcGFydCA9IGlzQmV5b25kUGF0aCA/IHZvaWQgMCA6IHBhcnRzW2luZGV4XTtcblx0XHRsZXQgbG93ZXJQYXJ0O1xuXHRcdGlmIChpc0JleW9uZFBhdGggJiYgbm9kZS5pbmRleCkge1xuXHRcdFx0Y29uc3QgaW5kZXhGcmFtZSA9IHtcblx0XHRcdFx0bm9kZTogbm9kZS5pbmRleCxcblx0XHRcdFx0aW5kZXgsXG5cdFx0XHRcdHNraXBwZWQsXG5cdFx0XHRcdHN0YXRpY3MsXG5cdFx0XHRcdGR5bmFtaWNzLFxuXHRcdFx0XHRvcHRpb25hbHMsXG5cdFx0XHRcdGV4dHJhY3QsXG5cdFx0XHRcdHJhd1BhcmFtc1xuXHRcdFx0fTtcblx0XHRcdGxldCBpbmRleFZhbGlkID0gdHJ1ZTtcblx0XHRcdGlmIChub2RlLmluZGV4LnBhcnNlKSB7XG5cdFx0XHRcdGlmICghdmFsaWRhdGVQYXJzZVBhcmFtcyhwYXRoLCBwYXJ0cywgaW5kZXhGcmFtZSkpIGluZGV4VmFsaWQgPSBmYWxzZTtcblx0XHRcdH1cblx0XHRcdGlmIChpbmRleFZhbGlkKSB7XG5cdFx0XHRcdGlmICghZHluYW1pY3MgJiYgIW9wdGlvbmFscyAmJiAhc2tpcHBlZCAmJiBpc1BlcmZlY3RTdGF0aWNNYXRjaChzdGF0aWNzLCBwYXJ0c0xlbmd0aCkpIHJldHVybiBpbmRleEZyYW1lO1xuXHRcdFx0XHRpZiAoaXNGcmFtZU1vcmVTcGVjaWZpYyhiZXN0TWF0Y2gsIGluZGV4RnJhbWUpKSBiZXN0TWF0Y2ggPSBpbmRleEZyYW1lO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZiAobm9kZS53aWxkY2FyZCkgZm9yIChsZXQgaSA9IG5vZGUud2lsZGNhcmQubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcblx0XHRcdGNvbnN0IHNlZ21lbnQgPSBub2RlLndpbGRjYXJkW2ldO1xuXHRcdFx0Y29uc3QgeyBwcmVmaXgsIHN1ZmZpeCB9ID0gc2VnbWVudDtcblx0XHRcdGlmIChwcmVmaXgpIHtcblx0XHRcdFx0aWYgKGlzQmV5b25kUGF0aCkgY29udGludWU7XG5cdFx0XHRcdGlmICghKHNlZ21lbnQuY2FzZVNlbnNpdGl2ZSA/IHBhcnQgOiBsb3dlclBhcnQgPz89IHBhcnQudG9Mb3dlckNhc2UoKSkuc3RhcnRzV2l0aChwcmVmaXgpKSBjb250aW51ZTtcblx0XHRcdH1cblx0XHRcdGlmIChzdWZmaXgpIHtcblx0XHRcdFx0aWYgKGlzQmV5b25kUGF0aCkgY29udGludWU7XG5cdFx0XHRcdGNvbnN0IGVuZCA9IHBhcnRzLnNsaWNlKGluZGV4KS5qb2luKFwiL1wiKTtcblx0XHRcdFx0Y29uc3Qgc3VmZml4UGFydCA9IGVuZC5zbGljZSgtc3VmZml4Lmxlbmd0aCk7XG5cdFx0XHRcdGlmICgoc2VnbWVudC5jYXNlU2Vuc2l0aXZlID8gc3VmZml4UGFydCA6IHN1ZmZpeFBhcnQudG9Mb3dlckNhc2UoKSkgIT09IHN1ZmZpeCB8fCBlbmQubGVuZ3RoIC0gc3VmZml4Lmxlbmd0aCA8IHByZWZpeC5sZW5ndGgpIGNvbnRpbnVlO1xuXHRcdFx0fVxuXHRcdFx0c3RhY2sucHVzaCh7XG5cdFx0XHRcdG5vZGU6IHNlZ21lbnQsXG5cdFx0XHRcdGluZGV4OiBwYXJ0c0xlbmd0aCxcblx0XHRcdFx0c2tpcHBlZCxcblx0XHRcdFx0c3RhdGljcyxcblx0XHRcdFx0ZHluYW1pY3MsXG5cdFx0XHRcdG9wdGlvbmFscyxcblx0XHRcdFx0ZXh0cmFjdCxcblx0XHRcdFx0cmF3UGFyYW1zXG5cdFx0XHR9KTtcblx0XHR9XG5cdFx0aWYgKG5vZGUub3B0aW9uYWwpIHtcblx0XHRcdGNvbnN0IG5leHRTa2lwcGVkID0gc2tpcHBlZCB8IDEgPDwgbm9kZS5kZXB0aCArIDE7XG5cdFx0XHRmb3IgKGxldCBpID0gbm9kZS5vcHRpb25hbC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0XHRjb25zdCBzZWdtZW50ID0gbm9kZS5vcHRpb25hbFtpXTtcblx0XHRcdFx0c3RhY2sucHVzaCh7XG5cdFx0XHRcdFx0bm9kZTogc2VnbWVudCxcblx0XHRcdFx0XHRpbmRleCxcblx0XHRcdFx0XHRza2lwcGVkOiBuZXh0U2tpcHBlZCxcblx0XHRcdFx0XHRzdGF0aWNzLFxuXHRcdFx0XHRcdGR5bmFtaWNzLFxuXHRcdFx0XHRcdG9wdGlvbmFscyxcblx0XHRcdFx0XHRleHRyYWN0LFxuXHRcdFx0XHRcdHJhd1BhcmFtc1xuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHRcdGlmICghaXNCZXlvbmRQYXRoKSBmb3IgKGxldCBpID0gbm9kZS5vcHRpb25hbC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0XHRjb25zdCBzZWdtZW50ID0gbm9kZS5vcHRpb25hbFtpXTtcblx0XHRcdFx0Y29uc3QgeyBwcmVmaXgsIHN1ZmZpeCB9ID0gc2VnbWVudDtcblx0XHRcdFx0aWYgKHByZWZpeCB8fCBzdWZmaXgpIHtcblx0XHRcdFx0XHRjb25zdCBjYXNlUGFydCA9IHNlZ21lbnQuY2FzZVNlbnNpdGl2ZSA/IHBhcnQgOiBsb3dlclBhcnQgPz89IHBhcnQudG9Mb3dlckNhc2UoKTtcblx0XHRcdFx0XHRpZiAocHJlZml4ICYmICFjYXNlUGFydC5zdGFydHNXaXRoKHByZWZpeCkpIGNvbnRpbnVlO1xuXHRcdFx0XHRcdGlmIChzdWZmaXggJiYgY2FzZVBhcnQuaW5kZXhPZihzdWZmaXgsIGNhc2VQYXJ0Lmxlbmd0aCAtIHN1ZmZpeC5sZW5ndGgpIDwgcHJlZml4Lmxlbmd0aCkgY29udGludWU7XG5cdFx0XHRcdH1cblx0XHRcdFx0c3RhY2sucHVzaCh7XG5cdFx0XHRcdFx0bm9kZTogc2VnbWVudCxcblx0XHRcdFx0XHRpbmRleDogaW5kZXggKyAxLFxuXHRcdFx0XHRcdHNraXBwZWQsXG5cdFx0XHRcdFx0c3RhdGljcyxcblx0XHRcdFx0XHRkeW5hbWljcyxcblx0XHRcdFx0XHRvcHRpb25hbHM6IG9wdGlvbmFscyArIHNlZ21lbnRTY29yZShwYXJ0c0xlbmd0aCwgaW5kZXgpLFxuXHRcdFx0XHRcdGV4dHJhY3QsXG5cdFx0XHRcdFx0cmF3UGFyYW1zXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZiAoIWlzQmV5b25kUGF0aCAmJiBub2RlLmR5bmFtaWMgJiYgcGFydCkgZm9yIChsZXQgaSA9IG5vZGUuZHluYW1pYy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0Y29uc3Qgc2VnbWVudCA9IG5vZGUuZHluYW1pY1tpXTtcblx0XHRcdGNvbnN0IHsgcHJlZml4LCBzdWZmaXggfSA9IHNlZ21lbnQ7XG5cdFx0XHRpZiAocHJlZml4IHx8IHN1ZmZpeCkge1xuXHRcdFx0XHRjb25zdCBjYXNlUGFydCA9IHNlZ21lbnQuY2FzZVNlbnNpdGl2ZSA/IHBhcnQgOiBsb3dlclBhcnQgPz89IHBhcnQudG9Mb3dlckNhc2UoKTtcblx0XHRcdFx0aWYgKHByZWZpeCAmJiAhY2FzZVBhcnQuc3RhcnRzV2l0aChwcmVmaXgpKSBjb250aW51ZTtcblx0XHRcdFx0aWYgKHN1ZmZpeCAmJiBjYXNlUGFydC5pbmRleE9mKHN1ZmZpeCwgY2FzZVBhcnQubGVuZ3RoIC0gc3VmZml4Lmxlbmd0aCkgPCBwcmVmaXgubGVuZ3RoKSBjb250aW51ZTtcblx0XHRcdH1cblx0XHRcdHN0YWNrLnB1c2goe1xuXHRcdFx0XHRub2RlOiBzZWdtZW50LFxuXHRcdFx0XHRpbmRleDogaW5kZXggKyAxLFxuXHRcdFx0XHRza2lwcGVkLFxuXHRcdFx0XHRzdGF0aWNzLFxuXHRcdFx0XHRkeW5hbWljczogZHluYW1pY3MgKyBzZWdtZW50U2NvcmUocGFydHNMZW5ndGgsIGluZGV4KSxcblx0XHRcdFx0b3B0aW9uYWxzLFxuXHRcdFx0XHRleHRyYWN0LFxuXHRcdFx0XHRyYXdQYXJhbXNcblx0XHRcdH0pO1xuXHRcdH1cblx0XHRpZiAoIWlzQmV5b25kUGF0aCAmJiBub2RlLnN0YXRpY0luc2Vuc2l0aXZlKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IG5vZGUuc3RhdGljSW5zZW5zaXRpdmUuZ2V0KGxvd2VyUGFydCA/Pz0gcGFydC50b0xvd2VyQ2FzZSgpKTtcblx0XHRcdGlmIChtYXRjaCkgc3RhY2sucHVzaCh7XG5cdFx0XHRcdG5vZGU6IG1hdGNoLFxuXHRcdFx0XHRpbmRleDogaW5kZXggKyAxLFxuXHRcdFx0XHRza2lwcGVkLFxuXHRcdFx0XHRzdGF0aWNzOiBzdGF0aWNzICsgc2VnbWVudFNjb3JlKHBhcnRzTGVuZ3RoLCBpbmRleCksXG5cdFx0XHRcdGR5bmFtaWNzLFxuXHRcdFx0XHRvcHRpb25hbHMsXG5cdFx0XHRcdGV4dHJhY3QsXG5cdFx0XHRcdHJhd1BhcmFtc1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdGlmICghaXNCZXlvbmRQYXRoICYmIG5vZGUuc3RhdGljKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IG5vZGUuc3RhdGljLmdldChwYXJ0KTtcblx0XHRcdGlmIChtYXRjaCkgc3RhY2sucHVzaCh7XG5cdFx0XHRcdG5vZGU6IG1hdGNoLFxuXHRcdFx0XHRpbmRleDogaW5kZXggKyAxLFxuXHRcdFx0XHRza2lwcGVkLFxuXHRcdFx0XHRzdGF0aWNzOiBzdGF0aWNzICsgc2VnbWVudFNjb3JlKHBhcnRzTGVuZ3RoLCBpbmRleCksXG5cdFx0XHRcdGR5bmFtaWNzLFxuXHRcdFx0XHRvcHRpb25hbHMsXG5cdFx0XHRcdGV4dHJhY3QsXG5cdFx0XHRcdHJhd1BhcmFtc1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdGlmIChub2RlLnBhdGhsZXNzKSBmb3IgKGxldCBpID0gbm9kZS5wYXRobGVzcy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0Y29uc3Qgc2VnbWVudCA9IG5vZGUucGF0aGxlc3NbaV07XG5cdFx0XHRzdGFjay5wdXNoKHtcblx0XHRcdFx0bm9kZTogc2VnbWVudCxcblx0XHRcdFx0aW5kZXgsXG5cdFx0XHRcdHNraXBwZWQsXG5cdFx0XHRcdHN0YXRpY3MsXG5cdFx0XHRcdGR5bmFtaWNzLFxuXHRcdFx0XHRvcHRpb25hbHMsXG5cdFx0XHRcdGV4dHJhY3QsXG5cdFx0XHRcdHJhd1BhcmFtc1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cdGlmIChiZXN0TWF0Y2gpIHJldHVybiBiZXN0TWF0Y2g7XG5cdGlmIChmdXp6eSAmJiBiZXN0RnV6enkpIHtcblx0XHRsZXQgc2xpY2VJbmRleCA9IGJlc3RGdXp6eS5pbmRleDtcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGJlc3RGdXp6eS5pbmRleDsgaSsrKSBzbGljZUluZGV4ICs9IHBhcnRzW2ldLmxlbmd0aDtcblx0XHRjb25zdCBzcGxhdCA9IHNsaWNlSW5kZXggPT09IHBhdGgubGVuZ3RoID8gXCIvXCIgOiBwYXRoLnNsaWNlKHNsaWNlSW5kZXgpO1xuXHRcdGJlc3RGdXp6eS5yYXdQYXJhbXMgPz89IE9iamVjdC5jcmVhdGUobnVsbCk7XG5cdFx0YmVzdEZ1enp5LnJhd1BhcmFtc1tcIioqXCJdID0gZGVjb2RlVVJJQ29tcG9uZW50KHNwbGF0KTtcblx0XHRyZXR1cm4gYmVzdEZ1enp5O1xuXHR9XG5cdHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gc2VnbWVudFNjb3JlKHBhcnRzTGVuZ3RoLCBpbmRleCkge1xuXHRyZXR1cm4gMiAqKiAocGFydHNMZW5ndGggLSBpbmRleCAtIDEpO1xufVxuZnVuY3Rpb24gaXNQZXJmZWN0U3RhdGljTWF0Y2goc3RhdGljcywgcGFydHNMZW5ndGgpIHtcblx0cmV0dXJuIHN0YXRpY3MgPT09IDIgKiogKHBhcnRzTGVuZ3RoIC0gMSkgLSAxO1xufVxuZnVuY3Rpb24gdmFsaWRhdGVQYXJzZVBhcmFtcyhwYXRoLCBwYXJ0cywgZnJhbWUpIHtcblx0bGV0IHJhd1BhcmFtcztcblx0bGV0IHN0YXRlO1xuXHR0cnkge1xuXHRcdFtyYXdQYXJhbXMsIHN0YXRlXSA9IGV4dHJhY3RQYXJhbXMocGF0aCwgcGFydHMsIGZyYW1lKTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cblx0ZnJhbWUucmF3UGFyYW1zID0gcmF3UGFyYW1zO1xuXHRmcmFtZS5leHRyYWN0ID0gc3RhdGU7XG5cdGlmICghZnJhbWUubm9kZS5wYXJzZSkgcmV0dXJuIHRydWU7XG5cdHRyeSB7XG5cdFx0aWYgKGZyYW1lLm5vZGUucGFyc2UocmF3UGFyYW1zKSA9PT0gZmFsc2UpIHJldHVybiBudWxsO1xuXHR9IGNhdGNoIHt9XG5cdHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gaXNGcmFtZU1vcmVTcGVjaWZpYyhwcmV2LCBuZXh0KSB7XG5cdGlmICghcHJldikgcmV0dXJuIHRydWU7XG5cdHJldHVybiBuZXh0LnN0YXRpY3MgPiBwcmV2LnN0YXRpY3MgfHwgbmV4dC5zdGF0aWNzID09PSBwcmV2LnN0YXRpY3MgJiYgKG5leHQuZHluYW1pY3MgPiBwcmV2LmR5bmFtaWNzIHx8IG5leHQuZHluYW1pY3MgPT09IHByZXYuZHluYW1pY3MgJiYgKG5leHQub3B0aW9uYWxzID4gcHJldi5vcHRpb25hbHMgfHwgbmV4dC5vcHRpb25hbHMgPT09IHByZXYub3B0aW9uYWxzICYmICgobmV4dC5ub2RlLmtpbmQgPT09IFNFR01FTlRfVFlQRV9JTkRFWCkgPiAocHJldi5ub2RlLmtpbmQgPT09IFNFR01FTlRfVFlQRV9JTkRFWCkgfHwgbmV4dC5ub2RlLmtpbmQgPT09IFNFR01FTlRfVFlQRV9JTkRFWCA9PT0gKHByZXYubm9kZS5raW5kID09PSBTRUdNRU5UX1RZUEVfSU5ERVgpICYmIG5leHQubm9kZS5kZXB0aCA+IHByZXYubm9kZS5kZXB0aCkpKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYnVpbGRSb3V0ZUJyYW5jaCwgZmluZEZsYXRNYXRjaCwgZmluZFJvdXRlTWF0Y2gsIGZpbmRTaW5nbGVNYXRjaCwgZ2V0UGFyYW1OYW1lcywgcGFyc2VTZWdtZW50LCBwYXJzZVNlZ21lbnRzLCBwcm9jZXNzUm91dGVNYXNrcywgcHJvY2Vzc1JvdXRlVHJlZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1uZXctcHJvY2Vzcy1yb3V0ZS10cmVlLmpzLm1hcCIsImltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuLy8jcmVnaW9uIHNyYy9zY3JvbGwtcmVzdG9yYXRpb24udHNcbmZ1bmN0aW9uIGdldFNhZmVTZXNzaW9uU3RvcmFnZSgpIHtcblx0dHJ5IHtcblx0XHRyZXR1cm4gc2Vzc2lvblN0b3JhZ2U7XG5cdH0gY2F0Y2gge1xuXHRcdHJldHVybjtcblx0fVxufVxuY29uc3Qgc3RvcmFnZUtleSA9IFwidHNyLXNjcm9sbC1yZXN0b3JhdGlvbi12MV8zXCI7XG5jb25zdCBzYWZlU2Vzc2lvblN0b3JhZ2UgPSBnZXRTYWZlU2Vzc2lvblN0b3JhZ2UoKTtcbmZ1bmN0aW9uIGNyZWF0ZVNjcm9sbFJlc3RvcmF0aW9uQ2FjaGUoKSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIEpTT04ucGFyc2Uoc2FmZVNlc3Npb25TdG9yYWdlPy5nZXRJdGVtKFwidHNyLXNjcm9sbC1yZXN0b3JhdGlvbi12MV8zXCIpIHx8IFwie31cIik7XG5cdH0gY2F0Y2gge1xuXHRcdHJldHVybiB7fTtcblx0fVxufVxuY29uc3Qgc2Nyb2xsUmVzdG9yYXRpb25DYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVTY3JvbGxSZXN0b3JhdGlvbkNhY2hlKCk7XG5jb25zdCBzY3JvbGxSZXN0b3JhdGlvbklkQXR0cmlidXRlID0gXCJkYXRhLXNjcm9sbC1yZXN0b3JhdGlvbi1pZFwiO1xuLyoqXG4qIFRoZSBkZWZhdWx0IGBnZXRLZXlgIGZ1bmN0aW9uIGZvciBgdXNlU2Nyb2xsUmVzdG9yYXRpb25gLlxuKiBJdCByZXR1cm5zIHRoZSBga2V5YCBmcm9tIHRoZSBsb2NhdGlvbiBzdGF0ZSBvciB0aGUgYGhyZWZgIG9mIHRoZSBsb2NhdGlvbi5cbipcbiogVGhlIGBsb2NhdGlvbi5ocmVmYCBpcyB1c2VkIGFzIGEgZmFsbGJhY2sgdG8gc3VwcG9ydCB0aGUgdXNlIGNhc2Ugd2hlcmUgdGhlIGxvY2F0aW9uIHN0YXRlIGlzIG5vdCBhdmFpbGFibGUgbGlrZSB0aGUgaW5pdGlhbCByZW5kZXIuXG4qL1xuY29uc3QgZGVmYXVsdEdldFNjcm9sbFJlc3RvcmF0aW9uS2V5ID0gKGxvY2F0aW9uKSA9PiB7XG5cdHJldHVybiBsb2NhdGlvbi5zdGF0ZS5fX1RTUl9rZXkgfHwgbG9jYXRpb24uaHJlZjtcbn07XG5mdW5jdGlvbiBnZXRTY3JvbGxSZXN0b3JhdGlvblNlbGVjdG9yKGVsZW1lbnQpIHtcblx0Y29uc3QgYXR0cklkID0gZWxlbWVudC5nZXRBdHRyaWJ1dGUoc2Nyb2xsUmVzdG9yYXRpb25JZEF0dHJpYnV0ZSk7XG5cdGlmIChhdHRySWQpIHJldHVybiBgWyR7c2Nyb2xsUmVzdG9yYXRpb25JZEF0dHJpYnV0ZX09XCIke2F0dHJJZH1cIl1gO1xuXHRsZXQgc2VsZWN0b3IgPSBcIlwiO1xuXHRsZXQgZWwgPSBlbGVtZW50O1xuXHRsZXQgcGFyZW50O1xuXHR3aGlsZSAocGFyZW50ID0gZWwucGFyZW50Tm9kZSkge1xuXHRcdGxldCBpbmRleCA9IDE7XG5cdFx0bGV0IHNpYmxpbmcgPSBlbDtcblx0XHR3aGlsZSAoc2libGluZyA9IHNpYmxpbmcucHJldmlvdXNFbGVtZW50U2libGluZykgaW5kZXgrKztcblx0XHRjb25zdCBwYXJ0ID0gYCR7ZWwubG9jYWxOYW1lfTpudGgtY2hpbGQoJHtpbmRleH0pYDtcblx0XHRzZWxlY3RvciA9IHNlbGVjdG9yID8gYCR7cGFydH0gPiAke3NlbGVjdG9yfWAgOiBwYXJ0O1xuXHRcdGVsID0gcGFyZW50O1xuXHR9XG5cdHJldHVybiBzZWxlY3Rvcjtcbn1cbmZ1bmN0aW9uIGdldEVsZW1lbnRTY3JvbGxSZXN0b3JhdGlvbkVudHJ5KHJvdXRlciwgb3B0aW9ucykge1xuXHRjb25zdCByZXN0b3JlS2V5ID0gKG9wdGlvbnMuZ2V0S2V5IHx8IGRlZmF1bHRHZXRTY3JvbGxSZXN0b3JhdGlvbktleSkocm91dGVyLmxhdGVzdExvY2F0aW9uKTtcblx0Y29uc3QgZW50cmllcyA9IHNjcm9sbFJlc3RvcmF0aW9uQ2FjaGVbcmVzdG9yZUtleV07XG5cdGlmICghZW50cmllcykgcmV0dXJuO1xuXHRpZiAob3B0aW9ucy5pZCkgcmV0dXJuIGVudHJpZXNbYFske3Njcm9sbFJlc3RvcmF0aW9uSWRBdHRyaWJ1dGV9PVwiJHtvcHRpb25zLmlkfVwiXWBdO1xuXHRjb25zdCBlbGVtZW50ID0gb3B0aW9ucy5nZXRFbGVtZW50Py4oKTtcblx0aWYgKCFlbGVtZW50KSByZXR1cm47XG5cdHJldHVybiBlbnRyaWVzW2VsZW1lbnQgPT09IHdpbmRvdyA/IHdpbmRvd1Njcm9sbFRhcmdldCA6IGdldFNjcm9sbFJlc3RvcmF0aW9uU2VsZWN0b3IoZWxlbWVudCldO1xufVxubGV0IGlnbm9yZVNjcm9sbCA9IGZhbHNlO1xuY29uc3Qgd2luZG93U2Nyb2xsVGFyZ2V0ID0gXCJ3aW5kb3dcIjtcbmZ1bmN0aW9uIGdldEVsZW1lbnQoc2VsZWN0b3IpIHtcblx0dHJ5IHtcblx0XHRyZXR1cm4gdHlwZW9mIHNlbGVjdG9yID09PSBcImZ1bmN0aW9uXCIgPyBzZWxlY3RvcigpIDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzZWxlY3Rvcik7XG5cdH0gY2F0Y2gge31cbn1cbmZ1bmN0aW9uIGdldFNjcm9sbFRvVG9wRWxlbWVudHMoc2Nyb2xsVG9Ub3BTZWxlY3RvcnMpIHtcblx0Y29uc3QgZWxlbWVudHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRmb3IgKGNvbnN0IHNlbGVjdG9yIG9mIHNjcm9sbFRvVG9wU2VsZWN0b3JzKSB7XG5cdFx0aWYgKHNlbGVjdG9yID09PSB3aW5kb3dTY3JvbGxUYXJnZXQpIGNvbnRpbnVlO1xuXHRcdGNvbnN0IGVsZW1lbnQgPSBnZXRFbGVtZW50KHNlbGVjdG9yKTtcblx0XHRpZiAoZWxlbWVudCkgZWxlbWVudHMuYWRkKGVsZW1lbnQpO1xuXHR9XG5cdHJldHVybiBlbGVtZW50cztcbn1cbmZ1bmN0aW9uIHNldHVwU2Nyb2xsUmVzdG9yYXRpb24ocm91dGVyLCBmb3JjZSkge1xuXHRjb25zdCBzaG91bGRTZXR1cFNjcm9sbFJlc3RvcmF0aW9uID0gZm9yY2UgPz8gcm91dGVyLm9wdGlvbnMuc2Nyb2xsUmVzdG9yYXRpb247XG5cdGNvbnN0IHNjcm9sbCA9IHJvdXRlci5fc2Nyb2xsO1xuXHRpZiAoc2hvdWxkU2V0dXBTY3JvbGxSZXN0b3JhdGlvbikgc2Nyb2xsLmUgPSB0cnVlO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSByZXR1cm47XG5cdGNvbnN0IGdldEtleSA9IHJvdXRlci5vcHRpb25zLmdldFNjcm9sbFJlc3RvcmF0aW9uS2V5IHx8IGRlZmF1bHRHZXRTY3JvbGxSZXN0b3JhdGlvbktleTtcblx0Y29uc3QgdHJhY2tlZFNjcm9sbFRhcmdldHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRjb25zdCBzbmFwc2hvdEN1cnJlbnRTY3JvbGxUYXJnZXRzID0gKHJlc3RvcmVLZXkpID0+IHtcblx0XHRjb25zdCBrZXlFbnRyeSA9IHNjcm9sbFJlc3RvcmF0aW9uQ2FjaGVbcmVzdG9yZUtleV0gfHw9IHt9O1xuXHRcdGZvciAoY29uc3QgdGFyZ2V0IG9mIHRyYWNrZWRTY3JvbGxUYXJnZXRzKSBpZiAodGFyZ2V0ID09PSBkb2N1bWVudCkga2V5RW50cnlbd2luZG93U2Nyb2xsVGFyZ2V0XSA9IHtcblx0XHRcdHNjcm9sbFgsXG5cdFx0XHRzY3JvbGxZXG5cdFx0fTtcblx0XHRlbHNlIGlmICh0YXJnZXQuaXNDb25uZWN0ZWQpIGtleUVudHJ5W2dldFNjcm9sbFJlc3RvcmF0aW9uU2VsZWN0b3IodGFyZ2V0KV0gPSB7XG5cdFx0XHRzY3JvbGxYOiB0YXJnZXQuc2Nyb2xsTGVmdCxcblx0XHRcdHNjcm9sbFk6IHRhcmdldC5zY3JvbGxUb3Bcblx0XHR9O1xuXHR9O1xuXHRpZiAoc2hvdWxkU2V0dXBTY3JvbGxSZXN0b3JhdGlvbiAmJiAhc2Nyb2xsLnMpIHtcblx0XHRzY3JvbGwucyA9IHRydWU7XG5cdFx0aWdub3JlU2Nyb2xsID0gZmFsc2U7XG5cdFx0aGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbiA9IFwibWFudWFsXCI7XG5cdFx0ZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCAoZXZlbnQpID0+IHtcblx0XHRcdGlmIChpZ25vcmVTY3JvbGwpIHJldHVybjtcblx0XHRcdHRyYWNrZWRTY3JvbGxUYXJnZXRzLmFkZChldmVudC50YXJnZXQpO1xuXHRcdH0sIHRydWUpO1xuXHRcdHJvdXRlci5zdWJzY3JpYmUoXCJvbkJlZm9yZUxvYWRcIiwgKGV2ZW50KSA9PiB7XG5cdFx0XHRpZiAoZXZlbnQuZnJvbUxvY2F0aW9uKSBzbmFwc2hvdEN1cnJlbnRTY3JvbGxUYXJnZXRzKGdldEtleShldmVudC5mcm9tTG9jYXRpb24pKTtcblx0XHRcdHRyYWNrZWRTY3JvbGxUYXJnZXRzLmNsZWFyKCk7XG5cdFx0fSk7XG5cdFx0YWRkRXZlbnRMaXN0ZW5lcihcInBhZ2VoaWRlXCIsICgpID0+IHtcblx0XHRcdGhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24gPSBcImF1dG9cIjtcblx0XHRcdHNuYXBzaG90Q3VycmVudFNjcm9sbFRhcmdldHMoZ2V0S2V5KHJvdXRlci5zdG9yZXMucmVzb2x2ZWRMb2NhdGlvbi5nZXQoKSA/PyByb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLmdldCgpKSk7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRzYWZlU2Vzc2lvblN0b3JhZ2U/LnNldEl0ZW0oc3RvcmFnZUtleSwgSlNPTi5zdHJpbmdpZnkoc2Nyb2xsUmVzdG9yYXRpb25DYWNoZSkpO1xuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNvbnNvbGUud2FybihcIlt0cy1yb3V0ZXJdIENvdWxkIG5vdCBwZXJzaXN0IHNjcm9sbCByZXN0b3JhdGlvbiBzdGF0ZSB0byBzZXNzaW9uU3RvcmFnZS5cIik7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0YWRkRXZlbnRMaXN0ZW5lcihcInBhZ2VzaG93XCIsIChldmVudCkgPT4ge1xuXHRcdFx0aWYgKGV2ZW50LnBlcnNpc3RlZCkgaGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbiA9IFwibWFudWFsXCI7XG5cdFx0fSk7XG5cdH1cblx0aWYgKHNjcm9sbC5yKSByZXR1cm47XG5cdHNjcm9sbC5yID0gdHJ1ZTtcblx0cm91dGVyLnN1YnNjcmliZShcIm9uUmVuZGVyZWRcIiwgKGV2ZW50KSA9PiB7XG5cdFx0Y29uc3QgYmVoYXZpb3IgPSByb3V0ZXIub3B0aW9ucy5zY3JvbGxSZXN0b3JhdGlvbkJlaGF2aW9yO1xuXHRcdGNvbnN0IHNjcm9sbFRvVG9wU2VsZWN0b3JzID0gcm91dGVyLm9wdGlvbnMuc2Nyb2xsVG9Ub3BTZWxlY3RvcnM7XG5cdFx0Y29uc3Qgc2hvdWxkUmVzZXRTY3JvbGwgPSBzY3JvbGwubjtcblx0XHRjb25zdCBoYXNoTmF2aWdhdGlvbiA9IHNjcm9sbC5oO1xuXHRcdGxldCBzY3JvbGxUb1RvcEVsZW1lbnRzO1xuXHRcdHRyYWNrZWRTY3JvbGxUYXJnZXRzLmNsZWFyKCk7XG5cdFx0c2Nyb2xsLm4gPSB0cnVlO1xuXHRcdHNjcm9sbC5oID0gZmFsc2U7XG5cdFx0aWYgKHR5cGVvZiByb3V0ZXIub3B0aW9ucy5zY3JvbGxSZXN0b3JhdGlvbiA9PT0gXCJmdW5jdGlvblwiICYmICFyb3V0ZXIub3B0aW9ucy5zY3JvbGxSZXN0b3JhdGlvbih7IGxvY2F0aW9uOiByb3V0ZXIubGF0ZXN0TG9jYXRpb24gfSkpIHJldHVybjtcblx0XHRjb25zdCBjYWNoZUtleSA9IGdldEtleShldmVudC50b0xvY2F0aW9uKTtcblx0XHRjb25zdCBmcm9tQ2FjaGVLZXkgPSBldmVudC5mcm9tTG9jYXRpb24gJiYgZ2V0S2V5KGV2ZW50LmZyb21Mb2NhdGlvbik7XG5cdFx0aWYgKHNjcm9sbC5lICYmIGZyb21DYWNoZUtleSAmJiBmcm9tQ2FjaGVLZXkgIT09IGNhY2hlS2V5KSB7XG5cdFx0XHRjb25zdCBmcm9tRWxlbWVudEVudHJpZXMgPSBzY3JvbGxSZXN0b3JhdGlvbkNhY2hlW2Zyb21DYWNoZUtleV07XG5cdFx0XHRpZiAoZnJvbUVsZW1lbnRFbnRyaWVzKSB7XG5cdFx0XHRcdGxldCB0b0VsZW1lbnRFbnRyaWVzID0gc2Nyb2xsUmVzdG9yYXRpb25DYWNoZVtjYWNoZUtleV07XG5cdFx0XHRcdGZvciAoY29uc3QgZWxlbWVudFNlbGVjdG9yIGluIGZyb21FbGVtZW50RW50cmllcykge1xuXHRcdFx0XHRcdGlmIChlbGVtZW50U2VsZWN0b3IgPT09IHdpbmRvd1Njcm9sbFRhcmdldCkge1xuXHRcdFx0XHRcdFx0aWYgKHNob3VsZFJlc2V0U2Nyb2xsKSBjb250aW51ZTtcblx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0Y29uc3QgZWxlbWVudCA9IGdldEVsZW1lbnQoZWxlbWVudFNlbGVjdG9yKTtcblx0XHRcdFx0XHRcdGlmICghZWxlbWVudCkgY29udGludWU7XG5cdFx0XHRcdFx0XHRpZiAoc2hvdWxkUmVzZXRTY3JvbGwgJiYgc2Nyb2xsVG9Ub3BTZWxlY3RvcnMpIHtcblx0XHRcdFx0XHRcdFx0c2Nyb2xsVG9Ub3BFbGVtZW50cyA/Pz0gZ2V0U2Nyb2xsVG9Ub3BFbGVtZW50cyhzY3JvbGxUb1RvcFNlbGVjdG9ycyk7XG5cdFx0XHRcdFx0XHRcdGlmIChzY3JvbGxUb1RvcEVsZW1lbnRzLmhhcyhlbGVtZW50KSkgY29udGludWU7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmICghdG9FbGVtZW50RW50cmllcykgdG9FbGVtZW50RW50cmllcyA9IHNjcm9sbFJlc3RvcmF0aW9uQ2FjaGVbY2FjaGVLZXldID0ge307XG5cdFx0XHRcdFx0dG9FbGVtZW50RW50cmllc1tlbGVtZW50U2VsZWN0b3JdID8/PSBmcm9tRWxlbWVudEVudHJpZXNbZWxlbWVudFNlbGVjdG9yXTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0XHRpZ25vcmVTY3JvbGwgPSB0cnVlO1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBoYXNoID0gZXZlbnQudG9Mb2NhdGlvbi5oYXNoO1xuXHRcdFx0Y29uc3QgaGFzaFNjcm9sbEludG9WaWV3T3B0aW9ucyA9IGV2ZW50LnRvTG9jYXRpb24uc3RhdGUuX19oYXNoU2Nyb2xsSW50b1ZpZXdPcHRpb25zID8/IHRydWU7XG5cdFx0XHRsZXQgd2luZG93UmVzdG9yZWQgPSBmYWxzZTtcblx0XHRcdGlmIChzaG91bGRSZXNldFNjcm9sbCkge1xuXHRcdFx0XHRpZiAoIWhhc2ggJiYgc2Nyb2xsVG9Ub3BTZWxlY3RvcnMpIHNjcm9sbFRvVG9wRWxlbWVudHMgPz89IGdldFNjcm9sbFRvVG9wRWxlbWVudHMoc2Nyb2xsVG9Ub3BTZWxlY3RvcnMpO1xuXHRcdFx0XHRjb25zdCBza2lwV2luZG93UmVzdG9yZSA9IGhhc2ggJiYgaGFzaFNjcm9sbEludG9WaWV3T3B0aW9ucyAmJiBoYXNoTmF2aWdhdGlvbjtcblx0XHRcdFx0Y29uc3QgZWxlbWVudEVudHJpZXMgPSBzY3JvbGwuZSA/IHNjcm9sbFJlc3RvcmF0aW9uQ2FjaGVbY2FjaGVLZXldIDogdm9pZCAwO1xuXHRcdFx0XHRpZiAoZWxlbWVudEVudHJpZXMpIGZvciAoY29uc3QgZWxlbWVudFNlbGVjdG9yIGluIGVsZW1lbnRFbnRyaWVzKSB7XG5cdFx0XHRcdFx0Y29uc3QgeyBzY3JvbGxYLCBzY3JvbGxZIH0gPSBlbGVtZW50RW50cmllc1tlbGVtZW50U2VsZWN0b3JdO1xuXHRcdFx0XHRcdGlmIChlbGVtZW50U2VsZWN0b3IgPT09IHdpbmRvd1Njcm9sbFRhcmdldCkge1xuXHRcdFx0XHRcdFx0aWYgKHNraXBXaW5kb3dSZXN0b3JlKSBjb250aW51ZTtcblx0XHRcdFx0XHRcdHNjcm9sbFRvKHtcblx0XHRcdFx0XHRcdFx0dG9wOiBzY3JvbGxZLFxuXHRcdFx0XHRcdFx0XHRsZWZ0OiBzY3JvbGxYLFxuXHRcdFx0XHRcdFx0XHRiZWhhdmlvclxuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0XHR3aW5kb3dSZXN0b3JlZCA9IHRydWU7XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdGNvbnN0IGVsZW1lbnQgPSBnZXRFbGVtZW50KGVsZW1lbnRTZWxlY3Rvcik7XG5cdFx0XHRcdFx0XHRpZiAoZWxlbWVudCkge1xuXHRcdFx0XHRcdFx0XHRlbGVtZW50LnNjcm9sbExlZnQgPSBzY3JvbGxYO1xuXHRcdFx0XHRcdFx0XHRlbGVtZW50LnNjcm9sbFRvcCA9IHNjcm9sbFk7XG5cdFx0XHRcdFx0XHRcdHNjcm9sbFRvVG9wRWxlbWVudHM/LmRlbGV0ZShlbGVtZW50KTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKCFoYXNoKSB7XG5cdFx0XHRcdFx0Y29uc3Qgc2Nyb2xsT3B0aW9ucyA9IHtcblx0XHRcdFx0XHRcdHRvcDogMCxcblx0XHRcdFx0XHRcdGxlZnQ6IDAsXG5cdFx0XHRcdFx0XHRiZWhhdmlvclxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0aWYgKCF3aW5kb3dSZXN0b3JlZCkgc2Nyb2xsVG8oc2Nyb2xsT3B0aW9ucyk7XG5cdFx0XHRcdFx0aWYgKHNjcm9sbFRvVG9wRWxlbWVudHMpIGZvciAoY29uc3QgZWxlbWVudCBvZiBzY3JvbGxUb1RvcEVsZW1lbnRzKSBlbGVtZW50LnNjcm9sbFRvKHNjcm9sbE9wdGlvbnMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoIXdpbmRvd1Jlc3RvcmVkICYmIGhhc2ggJiYgaGFzaFNjcm9sbEludG9WaWV3T3B0aW9ucykgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaGFzaCk/LnNjcm9sbEludG9WaWV3KGhhc2hTY3JvbGxJbnRvVmlld09wdGlvbnMpO1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHRpZ25vcmVTY3JvbGwgPSBmYWxzZTtcblx0XHR9XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBkZWZhdWx0R2V0U2Nyb2xsUmVzdG9yYXRpb25LZXksIGdldEVsZW1lbnRTY3JvbGxSZXN0b3JhdGlvbkVudHJ5LCBzZXR1cFNjcm9sbFJlc3RvcmF0aW9uLCBzdG9yYWdlS2V5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNjcm9sbC1yZXN0b3JhdGlvbi5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3Fzcy50c1xuLyoqXG4qIFByb2dyYW0gaXMgYSByZWltcGxlbWVudGF0aW9uIG9mIHRoZSBgcXNzYCBwYWNrYWdlOlxuKiBDb3B5cmlnaHQgKGMpIEx1a2UgRWR3YXJkcyBsdWtlLmVkd2FyZHMwNUBnbWFpbC5jb20sIE1JVCBMaWNlbnNlXG4qIGh0dHBzOi8vZ2l0aHViLmNvbS9sdWtlZWQvcXNzL2Jsb2IvbWFzdGVyL2xpY2Vuc2UubWRcbipcbiogVGhpcyByZWltcGxlbWVudGF0aW9uIHVzZXMgbW9kZXJuIGJyb3dzZXIgQVBJc1xuKiAobmFtZWx5IFVSTFNlYXJjaFBhcmFtcykgYW5kIFR5cGVTY3JpcHQgd2hpbGUgc3RpbGxcbiogbWFpbnRhaW5pbmcgdGhlIG9yaWdpbmFsIGZ1bmN0aW9uYWxpdHkgYW5kIGludGVyZmFjZS5cbipcbiogVXBkYXRlOiB0aGlzIGltcGxlbWVudGF0aW9uIGhhcyBhbHNvIGJlZW4gbWFuZ2xlZCB0b1xuKiBmaXQgZXhhY3RseSBvdXIgdXNlLWNhc2UgKHNpbmdsZSB2YWx1ZSBwZXIga2V5IGluIGVuY29kaW5nKS5cbiovXG4vKipcbiogRW5jb2RlcyBhbiBvYmplY3QgaW50byBhIHF1ZXJ5IHN0cmluZy5cbiogQHBhcmFtIG9iaiAtIFRoZSBvYmplY3QgdG8gZW5jb2RlIGludG8gYSBxdWVyeSBzdHJpbmcuXG4qIEBwYXJhbSBzdHJpbmdpZnkgLSBBbiBvcHRpb25hbCBjdXN0b20gc3RyaW5naWZ5IGZ1bmN0aW9uLlxuKiBAcmV0dXJucyBUaGUgZW5jb2RlZCBxdWVyeSBzdHJpbmcuXG4qIEBleGFtcGxlXG4qIGBgYFxuKiAvLyBFeGFtcGxlIGlucHV0OiBlbmNvZGUoeyB0b2tlbjogJ2ZvbycsIGtleTogJ3ZhbHVlJyB9KVxuKiAvLyBFeHBlY3RlZCBvdXRwdXQ6IFwidG9rZW49Zm9vJmtleT12YWx1ZVwiXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGVuY29kZShvYmosIHN0cmluZ2lmeSA9IFN0cmluZykge1xuXHRsZXQgcmVzdWx0O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcblx0XHRjb25zdCB2YWwgPSBvYmpba2V5XTtcblx0XHRpZiAodmFsICE9PSB2b2lkIDApIChyZXN1bHQgfHw9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKSkuc2V0KGtleSwgc3RyaW5naWZ5KHZhbCkpO1xuXHR9XG5cdHJldHVybiByZXN1bHQgPyByZXN1bHQudG9TdHJpbmcoKSA6IFwiXCI7XG59XG4vKipcbiogQ29udmVydHMgYSBzdHJpbmcgdmFsdWUgdG8gaXRzIGFwcHJvcHJpYXRlIHR5cGUgKHN0cmluZywgbnVtYmVyLCBib29sZWFuKS5cbiogQHBhcmFtIG1peCAtIFRoZSBzdHJpbmcgdmFsdWUgdG8gY29udmVydC5cbiogQHJldHVybnMgVGhlIGNvbnZlcnRlZCB2YWx1ZS5cbiogQGV4YW1wbGVcbiogLy8gRXhhbXBsZSBpbnB1dDogdG9WYWx1ZShcIjEyM1wiKVxuKiAvLyBFeHBlY3RlZCBvdXRwdXQ6IDEyM1xuKi9cbmZ1bmN0aW9uIHRvVmFsdWUoc3RyKSB7XG5cdGlmICghc3RyKSByZXR1cm4gXCJcIjtcblx0aWYgKHN0ciA9PT0gXCJmYWxzZVwiKSByZXR1cm4gZmFsc2U7XG5cdGlmIChzdHIgPT09IFwidHJ1ZVwiKSByZXR1cm4gdHJ1ZTtcblx0cmV0dXJuICtzdHIgKiAwID09PSAwICYmICtzdHIgKyBcIlwiID09PSBzdHIgPyArc3RyIDogc3RyO1xufVxuLyoqXG4qIERlY29kZXMgYSBxdWVyeSBzdHJpbmcgaW50byBhbiBvYmplY3QuXG4qIEBwYXJhbSBzdHIgLSBUaGUgcXVlcnkgc3RyaW5nIHRvIGRlY29kZS5cbiogQHJldHVybnMgVGhlIGRlY29kZWQga2V5LXZhbHVlIHBhaXJzIGluIGFuIG9iamVjdCBmb3JtYXQuXG4qIEBleGFtcGxlXG4qIC8vIEV4YW1wbGUgaW5wdXQ6IGRlY29kZShcInRva2VuPWZvbyZrZXk9dmFsdWVcIilcbiogLy8gRXhwZWN0ZWQgb3V0cHV0OiB7IFwidG9rZW5cIjogXCJmb29cIiwgXCJrZXlcIjogXCJ2YWx1ZVwiIH1cbiovXG5mdW5jdGlvbiBkZWNvZGUoc3RyKSB7XG5cdGNvbnN0IHNlYXJjaFBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoc3RyKTtcblx0Y29uc3QgcmVzdWx0ID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblx0Zm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2Ygc2VhcmNoUGFyYW1zLmVudHJpZXMoKSkge1xuXHRcdGNvbnN0IHByZXZpb3VzVmFsdWUgPSByZXN1bHRba2V5XTtcblx0XHRpZiAocHJldmlvdXNWYWx1ZSA9PSBudWxsKSByZXN1bHRba2V5XSA9IHRvVmFsdWUodmFsdWUpO1xuXHRcdGVsc2UgaWYgKEFycmF5LmlzQXJyYXkocHJldmlvdXNWYWx1ZSkpIHByZXZpb3VzVmFsdWUucHVzaCh0b1ZhbHVlKHZhbHVlKSk7XG5cdFx0ZWxzZSByZXN1bHRba2V5XSA9IFtwcmV2aW91c1ZhbHVlLCB0b1ZhbHVlKHZhbHVlKV07XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZGVjb2RlLCBlbmNvZGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXNzLmpzLm1hcCIsImltcG9ydCB7IGRlY29kZSwgZW5jb2RlIH0gZnJvbSBcIi4vcXNzLmpzXCI7XG4vLyNyZWdpb24gc3JjL3NlYXJjaFBhcmFtcy50c1xuY29uc3QganNvblN0YXJ0ID0gL14oPzpcXHN8W1wiW3tcXGQtXXxmYXxudXx0cikvO1xuLyoqIERlZmF1bHQgYHBhcnNlU2VhcmNoYCB0aGF0IHN0cmlwcyBsZWFkaW5nICc/JyBhbmQgSlNPTi1wYXJzZXMgdmFsdWVzLiAqL1xuY29uc3QgZGVmYXVsdFBhcnNlU2VhcmNoID0gcGFyc2VTZWFyY2hXaXRoKEpTT04ucGFyc2UpO1xuLyoqIERlZmF1bHQgYHN0cmluZ2lmeVNlYXJjaGAgdXNpbmcgSlNPTi5zdHJpbmdpZnkgZm9yIGNvbXBsZXggdmFsdWVzLiAqL1xuY29uc3QgZGVmYXVsdFN0cmluZ2lmeVNlYXJjaCA9IHN0cmluZ2lmeVNlYXJjaFdpdGgoSlNPTi5zdHJpbmdpZnksIEpTT04ucGFyc2UpO1xuLyoqXG4qIEJ1aWxkIGEgYHBhcnNlU2VhcmNoYCBmdW5jdGlvbiB1c2luZyBhIHByb3ZpZGVkIEpTT04tbGlrZSBwYXJzZXIuXG4qXG4qIFRoZSByZXR1cm5lZCBmdW5jdGlvbiBzdHJpcHMgYSBsZWFkaW5nIGA/YCwgZGVjb2RlcyB2YWx1ZXMsIGFuZCBhdHRlbXB0cyB0b1xuKiBKU09OLXBhcnNlIHN0cmluZyB2YWx1ZXMgdXNpbmcgdGhlIGdpdmVuIGBwYXJzZXJgLlxuKlxuKiBAcGFyYW0gcGFyc2VyIEZ1bmN0aW9uIHRvIHBhcnNlIGEgc3RyaW5nIHZhbHVlIChlLmcuIGBKU09OLnBhcnNlYCkuXG4qIEByZXR1cm5zIEEgYHBhcnNlU2VhcmNoYCBmdW5jdGlvbiBjb21wYXRpYmxlIHdpdGggYFJvdXRlcmAgb3B0aW9ucy5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9ndWlkZS9jdXN0b20tc2VhcmNoLXBhcmFtLXNlcmlhbGl6YXRpb25cbiovXG5mdW5jdGlvbiBwYXJzZVNlYXJjaFdpdGgocGFyc2VyKSB7XG5cdGNvbnN0IGlzSnNvblBhcnNlciA9IHBhcnNlciA9PT0gSlNPTi5wYXJzZTtcblx0cmV0dXJuIChzZWFyY2hTdHIpID0+IHtcblx0XHRpZiAoc2VhcmNoU3RyWzBdID09PSBcIj9cIikgc2VhcmNoU3RyID0gc2VhcmNoU3RyLnNsaWNlKDEpO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gZGVjb2RlKHNlYXJjaFN0cik7XG5cdFx0Zm9yIChjb25zdCBrZXkgaW4gcXVlcnkpIHtcblx0XHRcdGNvbnN0IHZhbHVlID0gcXVlcnlba2V5XTtcblx0XHRcdGlmICh0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdFx0aWYgKGlzSnNvblBhcnNlciAmJiAhanNvblN0YXJ0LnRlc3QodmFsdWUpKSBjb250aW51ZTtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRxdWVyeVtrZXldID0gcGFyc2VyKHZhbHVlKTtcblx0XHRcdFx0fSBjYXRjaCAoX2Vycikge31cblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIHF1ZXJ5O1xuXHR9O1xufVxuLyoqXG4qIEJ1aWxkIGEgYHN0cmluZ2lmeVNlYXJjaGAgZnVuY3Rpb24gdXNpbmcgYSBwcm92aWRlZCBzZXJpYWxpemVyLlxuKlxuKiBOb24tcHJpbWl0aXZlIHZhbHVlcyBhcmUgc2VyaWFsaXplZCB3aXRoIGBzdHJpbmdpZnlgLiBJZiBhIGBwYXJzZXJgIGlzXG4qIHN1cHBsaWVkLCBzdHJpbmcgdmFsdWVzIHRoYXQgYXJlIHBhcnNlYWJsZSBhcmUgcmUtc2VyaWFsaXplZCB0byBlbnN1cmVcbiogc3ltbWV0cnkgd2l0aCBgcGFyc2VTZWFyY2hgLlxuKlxuKiBAcGFyYW0gc3RyaW5naWZ5IEZ1bmN0aW9uIHRvIHNlcmlhbGl6ZSBhIHZhbHVlIChlLmcuIGBKU09OLnN0cmluZ2lmeWApLlxuKiBAcGFyYW0gcGFyc2VyIE9wdGlvbmFsIHBhcnNlciB0byBkZXRlY3QgcGFyc2VhYmxlIHN0cmluZ3MuXG4qIEByZXR1cm5zIEEgYHN0cmluZ2lmeVNlYXJjaGAgZnVuY3Rpb24gY29tcGF0aWJsZSB3aXRoIGBSb3V0ZXJgIG9wdGlvbnMuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvZ3VpZGUvY3VzdG9tLXNlYXJjaC1wYXJhbS1zZXJpYWxpemF0aW9uXG4qL1xuZnVuY3Rpb24gc3RyaW5naWZ5U2VhcmNoV2l0aChzdHJpbmdpZnksIHBhcnNlcikge1xuXHRjb25zdCBpc0pzb25QYXJzZXIgPSBwYXJzZXIgPT09IEpTT04ucGFyc2U7XG5cdGZ1bmN0aW9uIHN0cmluZ2lmeVZhbHVlKHZhbCkge1xuXHRcdGlmICh2YWwgJiYgdHlwZW9mIHZhbCA9PT0gXCJvYmplY3RcIikgdHJ5IHtcblx0XHRcdHJldHVybiBzdHJpbmdpZnkodmFsKTtcblx0XHR9IGNhdGNoIChfZXJyKSB7fVxuXHRcdGVsc2UgaWYgKHBhcnNlciAmJiB0eXBlb2YgdmFsID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRpZiAoaXNKc29uUGFyc2VyICYmICFqc29uU3RhcnQudGVzdCh2YWwpKSByZXR1cm4gdmFsO1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0cGFyc2VyKHZhbCk7XG5cdFx0XHRcdHJldHVybiBzdHJpbmdpZnkodmFsKTtcblx0XHRcdH0gY2F0Y2ggKF9lcnIpIHt9XG5cdFx0fVxuXHRcdHJldHVybiB2YWw7XG5cdH1cblx0cmV0dXJuIChzZWFyY2gpID0+IHtcblx0XHRjb25zdCBzZWFyY2hTdHIgPSBlbmNvZGUoc2VhcmNoLCBzdHJpbmdpZnlWYWx1ZSk7XG5cdFx0cmV0dXJuIHNlYXJjaFN0ciA/IGA/JHtzZWFyY2hTdHJ9YCA6IFwiXCI7XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGRlZmF1bHRQYXJzZVNlYXJjaCwgZGVmYXVsdFN0cmluZ2lmeVNlYXJjaCwgcGFyc2VTZWFyY2hXaXRoLCBzdHJpbmdpZnlTZWFyY2hXaXRoIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNlYXJjaFBhcmFtcy5qcy5tYXAiLCJpbXBvcnQgeyBjbGVhblBhdGgsIHRyaW1QYXRoIH0gZnJvbSBcIi4vcGF0aC5qc1wiO1xuLy8jcmVnaW9uIHNyYy9yZXdyaXRlLnRzXG4vKiogQ29tcG9zZSBtdWx0aXBsZSByZXdyaXRlIHBhaXJzIGludG8gYSBzaW5nbGUgaW4vb3V0IHJld3JpdGUuICovXG5mdW5jdGlvbiBjb21wb3NlUmV3cml0ZXMocmV3cml0ZXMpIHtcblx0cmV0dXJuIHtcblx0XHRpbnB1dDogKHsgdXJsIH0pID0+IHtcblx0XHRcdGZvciAoY29uc3QgcmV3cml0ZSBvZiByZXdyaXRlcykgdXJsID0gZXhlY3V0ZVJld3JpdGVJbnB1dChyZXdyaXRlLCB1cmwpO1xuXHRcdFx0cmV0dXJuIHVybDtcblx0XHR9LFxuXHRcdG91dHB1dDogKHsgdXJsIH0pID0+IHtcblx0XHRcdGZvciAobGV0IGkgPSByZXdyaXRlcy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgdXJsID0gZXhlY3V0ZVJld3JpdGVPdXRwdXQocmV3cml0ZXNbaV0sIHVybCk7XG5cdFx0XHRyZXR1cm4gdXJsO1xuXHRcdH1cblx0fTtcbn1cbi8qKiBDcmVhdGUgYSByZXdyaXRlIHBhaXIgdGhhdCBzdHJpcHMvYWRkcyBhIGJhc2VwYXRoIG9uIGlucHV0L291dHB1dC4gKi9cbmZ1bmN0aW9uIHJld3JpdGVCYXNlcGF0aChiYXNlcGF0aCwgY2FzZVNlbnNpdGl2ZSwgcmV3cml0ZSkge1xuXHRjb25zdCB0cmltbWVkQmFzZXBhdGggPSB0cmltUGF0aChiYXNlcGF0aCk7XG5cdGNvbnN0IG5vcm1hbGl6ZWRCYXNlcGF0aCA9IGAvJHt0cmltbWVkQmFzZXBhdGh9YDtcblx0Y29uc3QgY2hlY2tCYXNlcGF0aCA9IGNhc2VTZW5zaXRpdmUgPyBub3JtYWxpemVkQmFzZXBhdGggOiBub3JtYWxpemVkQmFzZXBhdGgudG9Mb3dlckNhc2UoKTtcblx0Y29uc3QgY2hlY2tCYXNlcGF0aFdpdGhTbGFzaCA9IGAke2NoZWNrQmFzZXBhdGh9L2A7XG5cdGNvbnN0IGJhc2VwYXRoUmV3cml0ZSA9IHtcblx0XHRpbnB1dDogKHsgdXJsIH0pID0+IHtcblx0XHRcdGNvbnN0IHBhdGhuYW1lID0gY2FzZVNlbnNpdGl2ZSA/IHVybC5wYXRobmFtZSA6IHVybC5wYXRobmFtZS50b0xvd2VyQ2FzZSgpO1xuXHRcdFx0aWYgKHBhdGhuYW1lID09PSBjaGVja0Jhc2VwYXRoKSB1cmwucGF0aG5hbWUgPSBcIi9cIjtcblx0XHRcdGVsc2UgaWYgKHBhdGhuYW1lLnN0YXJ0c1dpdGgoY2hlY2tCYXNlcGF0aFdpdGhTbGFzaCkpIHVybC5wYXRobmFtZSA9IHVybC5wYXRobmFtZS5zbGljZShub3JtYWxpemVkQmFzZXBhdGgubGVuZ3RoKTtcblx0XHRcdHJldHVybiB1cmw7XG5cdFx0fSxcblx0XHRvdXRwdXQ6ICh7IHVybCB9KSA9PiB7XG5cdFx0XHR1cmwucGF0aG5hbWUgPSBjbGVhblBhdGgoYC8ke3RyaW1tZWRCYXNlcGF0aH0ke3VybC5wYXRobmFtZX1gKTtcblx0XHRcdHJldHVybiB1cmw7XG5cdFx0fVxuXHR9O1xuXHRyZXR1cm4gcmV3cml0ZSA/IHtcblx0XHRpbnB1dDogKHsgdXJsIH0pID0+IGV4ZWN1dGVSZXdyaXRlSW5wdXQocmV3cml0ZSwgYmFzZXBhdGhSZXdyaXRlLmlucHV0KHsgdXJsIH0pKSxcblx0XHRvdXRwdXQ6ICh7IHVybCB9KSA9PiBiYXNlcGF0aFJld3JpdGUub3V0cHV0KHsgdXJsOiBleGVjdXRlUmV3cml0ZU91dHB1dChyZXdyaXRlLCB1cmwpIH0pXG5cdH0gOiBiYXNlcGF0aFJld3JpdGU7XG59XG4vKiogRXhlY3V0ZSBhIGxvY2F0aW9uIGlucHV0IHJld3JpdGUgaWYgcHJvdmlkZWQuICovXG5mdW5jdGlvbiBleGVjdXRlUmV3cml0ZUlucHV0KHJld3JpdGUsIHVybCkge1xuXHRjb25zdCByZXMgPSByZXdyaXRlPy5pbnB1dD8uKHsgdXJsIH0pO1xuXHRpZiAocmVzKSB7XG5cdFx0aWYgKHR5cGVvZiByZXMgPT09IFwic3RyaW5nXCIpIHJldHVybiBuZXcgVVJMKHJlcyk7XG5cdFx0ZWxzZSBpZiAocmVzIGluc3RhbmNlb2YgVVJMKSByZXR1cm4gcmVzO1xuXHR9XG5cdHJldHVybiB1cmw7XG59XG4vKiogRXhlY3V0ZSBhIGxvY2F0aW9uIG91dHB1dCByZXdyaXRlIGlmIHByb3ZpZGVkLiAqL1xuZnVuY3Rpb24gZXhlY3V0ZVJld3JpdGVPdXRwdXQocmV3cml0ZSwgdXJsKSB7XG5cdGNvbnN0IHJlcyA9IHJld3JpdGU/Lm91dHB1dD8uKHsgdXJsIH0pO1xuXHRpZiAocmVzKSB7XG5cdFx0aWYgKHR5cGVvZiByZXMgPT09IFwic3RyaW5nXCIpIHJldHVybiBuZXcgVVJMKHJlcyk7XG5cdFx0ZWxzZSBpZiAocmVzIGluc3RhbmNlb2YgVVJMKSByZXR1cm4gcmVzO1xuXHR9XG5cdHJldHVybiB1cmw7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNvbXBvc2VSZXdyaXRlcywgZXhlY3V0ZVJld3JpdGVJbnB1dCwgZXhlY3V0ZVJld3JpdGVPdXRwdXQsIHJld3JpdGVCYXNlcGF0aCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZXdyaXRlLmpzLm1hcCIsImltcG9ydCB7IGFycmF5c0VxdWFsLCBmdW5jdGlvbmFsVXBkYXRlIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vI3JlZ2lvbiBzcmMvc3RvcmVzLnRzXG4vKiogU1NSIG5vbi1yZWFjdGl2ZSBjcmVhdGVNdXRhYmxlU3RvcmUgKi9cbmZ1bmN0aW9uIGNyZWF0ZU5vblJlYWN0aXZlTXV0YWJsZVN0b3JlKGluaXRpYWxWYWx1ZSkge1xuXHRsZXQgdmFsdWUgPSBpbml0aWFsVmFsdWU7XG5cdHJldHVybiB7XG5cdFx0Z2V0KCkge1xuXHRcdFx0cmV0dXJuIHZhbHVlO1xuXHRcdH0sXG5cdFx0c2V0KG5leHRPclVwZGF0ZXIpIHtcblx0XHRcdHZhbHVlID0gZnVuY3Rpb25hbFVwZGF0ZShuZXh0T3JVcGRhdGVyLCB2YWx1ZSk7XG5cdFx0fVxuXHR9O1xufVxuLyoqIFNTUiBub24tcmVhY3RpdmUgY3JlYXRlUmVhZG9ubHlTdG9yZSAqL1xuZnVuY3Rpb24gY3JlYXRlTm9uUmVhY3RpdmVSZWFkb25seVN0b3JlKHJlYWQpIHtcblx0cmV0dXJuIHsgZ2V0KCkge1xuXHRcdHJldHVybiByZWFkKCk7XG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJvdXRlclN0b3Jlcyhpbml0aWFsTG9jYXRpb24sIGNvbmZpZykge1xuXHRjb25zdCB7IGNyZWF0ZU11dGFibGVTdG9yZSwgY3JlYXRlUmVhZG9ubHlTdG9yZSwgYmF0Y2ggfSA9IGNvbmZpZztcblx0Y29uc3QgYnlSb3V0ZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGNvbnN0IHN0YXR1cyA9IGNyZWF0ZU11dGFibGVTdG9yZShcImlkbGVcIik7XG5cdGNvbnN0IGxvY2F0aW9uID0gY3JlYXRlTXV0YWJsZVN0b3JlKGluaXRpYWxMb2NhdGlvbik7XG5cdGNvbnN0IHJlc29sdmVkTG9jYXRpb24gPSBjcmVhdGVNdXRhYmxlU3RvcmUodm9pZCAwKTtcblx0Y29uc3QgaWRzID0gY3JlYXRlTXV0YWJsZVN0b3JlKFtdKTtcblx0Y29uc3QgbWF0Y2hlcyA9IGNyZWF0ZVJlYWRvbmx5U3RvcmUoKCkgPT4gaWRzLmdldCgpLm1hcCgoaWQpID0+IGJ5Um91dGUuZ2V0KGlkKS5nZXQoKSkpO1xuXHRjb25zdCBfX3N0b3JlID0gY3JlYXRlUmVhZG9ubHlTdG9yZSgoKSA9PiAoe1xuXHRcdHN0YXR1czogc3RhdHVzLmdldCgpLFxuXHRcdGlzTG9hZGluZzogc3RhdHVzLmdldCgpID09PSBcInBlbmRpbmdcIixcblx0XHRtYXRjaGVzOiBtYXRjaGVzLmdldCgpLFxuXHRcdGxvY2F0aW9uOiBsb2NhdGlvbi5nZXQoKSxcblx0XHRyZXNvbHZlZExvY2F0aW9uOiByZXNvbHZlZExvY2F0aW9uLmdldCgpXG5cdH0pKTtcblx0ZnVuY3Rpb24gZ2V0TWF0Y2hTdG9yZShyb3V0ZUlkKSB7XG5cdFx0bGV0IG1hdGNoU3RvcmUgPSBieVJvdXRlLmdldChyb3V0ZUlkKTtcblx0XHRpZiAoIW1hdGNoU3RvcmUpIHtcblx0XHRcdG1hdGNoU3RvcmUgPSBjcmVhdGVNdXRhYmxlU3RvcmUodm9pZCAwKTtcblx0XHRcdGJ5Um91dGUuc2V0KHJvdXRlSWQsIG1hdGNoU3RvcmUpO1xuXHRcdH1cblx0XHRyZXR1cm4gbWF0Y2hTdG9yZTtcblx0fVxuXHRjb25zdCBzdG9yZSA9IHtcblx0XHRzdGF0dXMsXG5cdFx0bG9jYXRpb24sXG5cdFx0cmVzb2x2ZWRMb2NhdGlvbixcblx0XHRpZHMsXG5cdFx0bWF0Y2hlcyxcblx0XHRieVJvdXRlLFxuXHRcdF9fc3RvcmUsXG5cdFx0Z2V0TWF0Y2hTdG9yZSxcblx0XHRzZXRNYXRjaGVzXG5cdH07XG5cdGZ1bmN0aW9uIHNldE1hdGNoZXMobmV4dE1hdGNoZXMpIHtcblx0XHRjb25zdCBwcmV2aW91c0lkcyA9IGlkcy5nZXQoKTtcblx0XHRjb25zdCBuZXh0SWRzID0gbmV4dE1hdGNoZXMubWFwKChtYXRjaCkgPT4gbWF0Y2gucm91dGVJZCk7XG5cdFx0YmF0Y2goKCkgPT4ge1xuXHRcdFx0aWYgKCFhcnJheXNFcXVhbChwcmV2aW91c0lkcywgbmV4dElkcykpIGlkcy5zZXQobmV4dElkcyk7XG5cdFx0XHRmb3IgKGNvbnN0IGlkIG9mIHByZXZpb3VzSWRzKSBpZiAoIW5leHRJZHMuaW5jbHVkZXMoaWQpKSBieVJvdXRlLmdldChpZCkuc2V0KCgpID0+IHZvaWQgMCk7XG5cdFx0XHRmb3IgKGNvbnN0IG5leHRNYXRjaCBvZiBuZXh0TWF0Y2hlcykge1xuXHRcdFx0XHRjb25zdCBtYXRjaFN0b3JlID0gZ2V0TWF0Y2hTdG9yZShuZXh0TWF0Y2gucm91dGVJZCk7XG5cdFx0XHRcdGlmIChtYXRjaFN0b3JlLmdldCgpICE9PSBuZXh0TWF0Y2gpIG1hdGNoU3RvcmUuc2V0KG5leHRNYXRjaCk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIHN0b3JlO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjcmVhdGVOb25SZWFjdGl2ZU11dGFibGVTdG9yZSwgY3JlYXRlTm9uUmVhY3RpdmVSZWFkb25seVN0b3JlLCBjcmVhdGVSb3V0ZXJTdG9yZXMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c3RvcmVzLmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvaW5kZXgudHNcbnZhciBzdGF0ZUluZGV4S2V5ID0gXCJfX1RTUl9pbmRleFwiO1xudmFyIHBvcFN0YXRlRXZlbnQgPSBcInBvcHN0YXRlXCI7XG52YXIgYmVmb3JlVW5sb2FkRXZlbnQgPSBcImJlZm9yZXVubG9hZFwiO1xuLyoqXG4qIFR1cm4gcHJvdG9jb2wtcmVsYXRpdmUgaW5wdXRzIHN1Y2ggYXMgXCIvL2V2aWwuZXhhbXBsZVwiIGludG8gcGF0aHNcbiogc3VjaCBhcyBcIi9ldmlsLmV4YW1wbGVcIiwga2VlcGluZyBuYXZpZ2F0aW9uIG9uIHRoZSBjdXJyZW50IG9yaWdpbi5cbipcbiogRm9yIEhUVFAoUykgVVJMcywgV0hBVFdHIHBhcnNpbmcgaWdub3JlcyBsZWFkaW5nIEMwIGNvbnRyb2xzIGFuZCBzcGFjZXMsXG4qIHJlbW92ZXMgdGFicy9uZXdsaW5lcywgYW5kIHRyZWF0cyBiYWNrc2xhc2hlcyBhcyBzbGFzaGVzLCBzbyBpbnB1dHMgbGlrZVxuKiBcIi9cXGV2aWwuZXhhbXBsZVwiIGFsc28gbmVlZCBub3JtYWxpemF0aW9uLiBUaGlzIG9ubHkgYWxsb2NhdGVzIHdoZW4gdGhvc2VcbiogcnVsZXMgd291bGQgbWFrZSB0aGUgaW5wdXQgcHJvdG9jb2wtcmVsYXRpdmUuXG4qL1xudmFyIHByb3RvY29sUmVsYXRpdmVQcmVmaXggPSAvXltcXHgwMC1cXHgyMF0qKD86W1xcXFwvXVtcXHRcXG5cXHJdKil7Mix9LztcbmZ1bmN0aW9uIG5vcm1hbGl6ZVByb3RvY29sUmVsYXRpdmUodXJsKSB7XG5cdGNvbnN0IG1hdGNoID0gcHJvdG9jb2xSZWxhdGl2ZVByZWZpeC5leGVjKHVybCk7XG5cdHJldHVybiBtYXRjaCA/IFwiL1wiICsgdXJsLnNsaWNlKG1hdGNoWzBdLmxlbmd0aCkgOiB1cmw7XG59XG5mdW5jdGlvbiBub3JtYWxpemVIcmVmKGhyZWYpIHtcblx0aWYgKC9bXFx4MDAtXFx4MWZcXHg3Zl0vLnRlc3QoaHJlZikpIGhyZWYgPSBocmVmLnJlcGxhY2UoL1tcXHgwMC1cXHgxZlxceDdmXS9nLCAoY2hhcmFjdGVyKSA9PiBcIlx0XFxuXFxyXCIuaW5jbHVkZXMoY2hhcmFjdGVyKSA/IFwiXCIgOiBlbmNvZGVVUklDb21wb25lbnQoY2hhcmFjdGVyKSk7XG5cdHJldHVybiBub3JtYWxpemVQcm90b2NvbFJlbGF0aXZlKGhyZWYpO1xufVxuZnVuY3Rpb24gY3JlYXRlSGlzdG9yeShvcHRzKSB7XG5cdGxldCBsb2NhdGlvbiA9IG9wdHMuZ2V0TG9jYXRpb24oKTtcblx0Y29uc3Qgc3Vic2NyaWJlcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRjb25zdCBub3RpZnkgPSAoYWN0aW9uKSA9PiB7XG5cdFx0bG9jYXRpb24gPSBvcHRzLmdldExvY2F0aW9uKCk7XG5cdFx0c3Vic2NyaWJlcnMuZm9yRWFjaCgoc3Vic2NyaWJlcikgPT4gc3Vic2NyaWJlcih7XG5cdFx0XHRsb2NhdGlvbixcblx0XHRcdGFjdGlvblxuXHRcdH0pKTtcblx0fTtcblx0Y29uc3QgaGFuZGxlSW5kZXhDaGFuZ2UgPSAoYWN0aW9uKSA9PiB7XG5cdFx0aWYgKG9wdHMubm90aWZ5T25JbmRleENoYW5nZSA/PyB0cnVlKSBub3RpZnkoYWN0aW9uKTtcblx0XHRlbHNlIGxvY2F0aW9uID0gb3B0cy5nZXRMb2NhdGlvbigpO1xuXHR9O1xuXHRjb25zdCB0cnlOYXZpZ2F0aW9uID0gYXN5bmMgKGFyZ3MpID0+IHtcblx0XHRjb25zdCBibG9ja2VycyA9IGFyZ3MubmF2aWdhdGVPcHRzPy5pZ25vcmVCbG9ja2VyID8gdm9pZCAwIDogb3B0cy5nZXRCbG9ja2Vycz8uKCk7XG5cdFx0aWYgKHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIiAmJiBibG9ja2Vycz8ubGVuZ3RoICYmIChhcmdzLnR5cGUgPT09IFwiUFVTSFwiIHx8IGFyZ3MudHlwZSA9PT0gXCJSRVBMQUNFXCIpKSBmb3IgKGNvbnN0IGJsb2NrZXIgb2YgYmxvY2tlcnMpIHtcblx0XHRcdGNvbnN0IG5leHRMb2NhdGlvbiA9IHBhcnNlSHJlZihhcmdzLnBhdGgsIGFyZ3Muc3RhdGUpO1xuXHRcdFx0aWYgKGF3YWl0IGJsb2NrZXIuYmxvY2tlckZuKHtcblx0XHRcdFx0Y3VycmVudExvY2F0aW9uOiBsb2NhdGlvbixcblx0XHRcdFx0bmV4dExvY2F0aW9uLFxuXHRcdFx0XHRhY3Rpb246IGFyZ3MudHlwZVxuXHRcdFx0fSkpIHtcblx0XHRcdFx0b3B0cy5vbkJsb2NrZWQ/LigpO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGFyZ3MudGFzaygpO1xuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdGdldCBsb2NhdGlvbigpIHtcblx0XHRcdHJldHVybiBsb2NhdGlvbjtcblx0XHR9LFxuXHRcdGdldCBsZW5ndGgoKSB7XG5cdFx0XHRyZXR1cm4gb3B0cy5nZXRMZW5ndGgoKTtcblx0XHR9LFxuXHRcdHN1YnNjcmliZXJzLFxuXHRcdHN1YnNjcmliZTogKGNiKSA9PiB7XG5cdFx0XHRzdWJzY3JpYmVycy5hZGQoY2IpO1xuXHRcdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdFx0c3Vic2NyaWJlcnMuZGVsZXRlKGNiKTtcblx0XHRcdH07XG5cdFx0fSxcblx0XHRwdXNoOiAocGF0aCwgc3RhdGUsIG5hdmlnYXRlT3B0cykgPT4ge1xuXHRcdFx0Y29uc3QgY3VycmVudEluZGV4ID0gbG9jYXRpb24uc3RhdGVbc3RhdGVJbmRleEtleV07XG5cdFx0XHRzdGF0ZSA9IGFzc2lnbktleUFuZEluZGV4KGN1cnJlbnRJbmRleCArIDEsIHN0YXRlKTtcblx0XHRcdHRyeU5hdmlnYXRpb24oe1xuXHRcdFx0XHR0YXNrOiAoKSA9PiB7XG5cdFx0XHRcdFx0b3B0cy5wdXNoU3RhdGUocGF0aCwgc3RhdGUpO1xuXHRcdFx0XHRcdG5vdGlmeSh7IHR5cGU6IFwiUFVTSFwiIH0pO1xuXHRcdFx0XHR9LFxuXHRcdFx0XHRuYXZpZ2F0ZU9wdHMsXG5cdFx0XHRcdHR5cGU6IFwiUFVTSFwiLFxuXHRcdFx0XHRwYXRoLFxuXHRcdFx0XHRzdGF0ZVxuXHRcdFx0fSk7XG5cdFx0fSxcblx0XHRyZXBsYWNlOiAocGF0aCwgc3RhdGUsIG5hdmlnYXRlT3B0cykgPT4ge1xuXHRcdFx0Y29uc3QgY3VycmVudEluZGV4ID0gbG9jYXRpb24uc3RhdGVbc3RhdGVJbmRleEtleV07XG5cdFx0XHRzdGF0ZSA9IGFzc2lnbktleUFuZEluZGV4KGN1cnJlbnRJbmRleCwgc3RhdGUpO1xuXHRcdFx0dHJ5TmF2aWdhdGlvbih7XG5cdFx0XHRcdHRhc2s6ICgpID0+IHtcblx0XHRcdFx0XHRvcHRzLnJlcGxhY2VTdGF0ZShwYXRoLCBzdGF0ZSk7XG5cdFx0XHRcdFx0bm90aWZ5KHsgdHlwZTogXCJSRVBMQUNFXCIgfSk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdG5hdmlnYXRlT3B0cyxcblx0XHRcdFx0dHlwZTogXCJSRVBMQUNFXCIsXG5cdFx0XHRcdHBhdGgsXG5cdFx0XHRcdHN0YXRlXG5cdFx0XHR9KTtcblx0XHR9LFxuXHRcdGdvOiAoaW5kZXgsIG5hdmlnYXRlT3B0cykgPT4ge1xuXHRcdFx0dHJ5TmF2aWdhdGlvbih7XG5cdFx0XHRcdHRhc2s6ICgpID0+IHtcblx0XHRcdFx0XHRvcHRzLmdvKGluZGV4LCBuYXZpZ2F0ZU9wdHM/Lmlnbm9yZUJsb2NrZXIgPz8gZmFsc2UpO1xuXHRcdFx0XHRcdGhhbmRsZUluZGV4Q2hhbmdlKHtcblx0XHRcdFx0XHRcdHR5cGU6IFwiR09cIixcblx0XHRcdFx0XHRcdGluZGV4XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdG5hdmlnYXRlT3B0cyxcblx0XHRcdFx0dHlwZTogXCJHT1wiXG5cdFx0XHR9KTtcblx0XHR9LFxuXHRcdGJhY2s6IChuYXZpZ2F0ZU9wdHMpID0+IHtcblx0XHRcdHRyeU5hdmlnYXRpb24oe1xuXHRcdFx0XHR0YXNrOiAoKSA9PiB7XG5cdFx0XHRcdFx0b3B0cy5iYWNrKG5hdmlnYXRlT3B0cz8uaWdub3JlQmxvY2tlciA/PyBmYWxzZSk7XG5cdFx0XHRcdFx0aGFuZGxlSW5kZXhDaGFuZ2UoeyB0eXBlOiBcIkJBQ0tcIiB9KTtcblx0XHRcdFx0fSxcblx0XHRcdFx0bmF2aWdhdGVPcHRzLFxuXHRcdFx0XHR0eXBlOiBcIkJBQ0tcIlxuXHRcdFx0fSk7XG5cdFx0fSxcblx0XHRmb3J3YXJkOiAobmF2aWdhdGVPcHRzKSA9PiB7XG5cdFx0XHR0cnlOYXZpZ2F0aW9uKHtcblx0XHRcdFx0dGFzazogKCkgPT4ge1xuXHRcdFx0XHRcdG9wdHMuZm9yd2FyZChuYXZpZ2F0ZU9wdHM/Lmlnbm9yZUJsb2NrZXIgPz8gZmFsc2UpO1xuXHRcdFx0XHRcdGhhbmRsZUluZGV4Q2hhbmdlKHsgdHlwZTogXCJGT1JXQVJEXCIgfSk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdG5hdmlnYXRlT3B0cyxcblx0XHRcdFx0dHlwZTogXCJGT1JXQVJEXCJcblx0XHRcdH0pO1xuXHRcdH0sXG5cdFx0Y2FuR29CYWNrOiAoKSA9PiBsb2NhdGlvbi5zdGF0ZVtzdGF0ZUluZGV4S2V5XSAhPT0gMCxcblx0XHRjcmVhdGVIcmVmOiAoc3RyKSA9PiBvcHRzLmNyZWF0ZUhyZWYoc3RyKSxcblx0XHRibG9jazogKGJsb2NrZXIpID0+IHtcblx0XHRcdGlmICghb3B0cy5zZXRCbG9ja2VycykgcmV0dXJuICgpID0+IHt9O1xuXHRcdFx0Y29uc3QgYmxvY2tlcnMgPSBvcHRzLmdldEJsb2NrZXJzPy4oKSA/PyBbXTtcblx0XHRcdG9wdHMuc2V0QmxvY2tlcnMoWy4uLmJsb2NrZXJzLCBibG9ja2VyXSk7XG5cdFx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBibG9ja2VycyA9IG9wdHMuZ2V0QmxvY2tlcnM/LigpID8/IFtdO1xuXHRcdFx0XHRvcHRzLnNldEJsb2NrZXJzPy4oYmxvY2tlcnMuZmlsdGVyKChiKSA9PiBiICE9PSBibG9ja2VyKSk7XG5cdFx0XHR9O1xuXHRcdH0sXG5cdFx0Zmx1c2g6ICgpID0+IG9wdHMuZmx1c2g/LigpLFxuXHRcdGRlc3Ryb3k6ICgpID0+IG9wdHMuZGVzdHJveT8uKCksXG5cdFx0bm90aWZ5LFxuXHRcdF9nZXRCbG9ja2VyczogKCkgPT4gb3B0cy5nZXRCbG9ja2Vycz8uKCkgPz8gW11cblx0fTtcbn1cbmZ1bmN0aW9uIGFzc2lnbktleUFuZEluZGV4KGluZGV4LCBzdGF0ZSkge1xuXHRjb25zdCBrZXkgPSBjcmVhdGVSYW5kb21LZXkoKTtcblx0cmV0dXJuIHtcblx0XHQuLi5zdGF0ZSxcblx0XHRrZXksXG5cdFx0X19UU1Jfa2V5OiBrZXksXG5cdFx0W3N0YXRlSW5kZXhLZXldOiBpbmRleFxuXHR9O1xufVxuLyoqXG4qIENyZWF0ZXMgYSBoaXN0b3J5IG9iamVjdCB0aGF0IGNhbiBiZSB1c2VkIHRvIGludGVyYWN0IHdpdGggdGhlIGJyb3dzZXInc1xuKiBuYXZpZ2F0aW9uLiBUaGlzIGlzIGEgbGlnaHR3ZWlnaHQgQVBJIHdyYXBwaW5nIHRoZSBicm93c2VyJ3MgbmF0aXZlIG1ldGhvZHMuXG4qIEl0IGlzIGRlc2lnbmVkIHRvIHdvcmsgd2l0aCBUYW5TdGFjayBSb3V0ZXIsIGJ1dCBjb3VsZCBiZSB1c2VkIGFzIGEgc3RhbmRhbG9uZSBBUEkgYXMgd2VsbC5cbiogSU1QT1JUQU5UOiBUaGlzIEFQSSBpbXBsZW1lbnRzIGhpc3RvcnkgdGhyb3R0bGluZyB2aWEgYSBtaWNyb3Rhc2sgdG8gcHJldmVudFxuKiBleGNlc3NpdmUgY2FsbHMgdG8gdGhlIGhpc3RvcnkgQVBJLiBJbiBzb21lIGJyb3dzZXJzLCBjYWxsaW5nIGhpc3RvcnkucHVzaFN0YXRlIG9yXG4qIGhpc3RvcnkucmVwbGFjZVN0YXRlIGluIHF1aWNrIHN1Y2Nlc3Npb24gY2FuIGNhdXNlIHRoZSBicm93c2VyIHRvIGlnbm9yZSBzdWJzZXF1ZW50XG4qIGNhbGxzLiBUaGlzIEFQSSBzbW9vdGhzIG91dCB0aG9zZSBkaWZmZXJlbmNlcyBhbmQgZW5zdXJlcyB0aGF0IHlvdXIgYXBwbGljYXRpb25cbiogc3RhdGUgd2lsbCAqZXZlbnR1YWxseSogbWF0Y2ggdGhlIGJyb3dzZXIgc3RhdGUuIEluIG1vc3QgY2FzZXMsIHRoaXMgaXMgbm90IGEgcHJvYmxlbSxcbiogYnV0IGlmIHlvdSBuZWVkIHRvIGVuc3VyZSB0aGF0IHRoZSBicm93c2VyIHN0YXRlIGlzIHVwIHRvIGRhdGUsIHlvdSBjYW4gdXNlIHRoZVxuKiBgaGlzdG9yeS5mbHVzaGAgbWV0aG9kIHRvIGltbWVkaWF0ZWx5IGZsdXNoIGFsbCBwZW5kaW5nIHN0YXRlIGNoYW5nZXMgdG8gdGhlIGJyb3dzZXIgVVJMLlxuKiBAcGFyYW0gb3B0c1xuKiBAcGFyYW0gb3B0cy5nZXRIcmVmIEEgZnVuY3Rpb24gdGhhdCByZXR1cm5zIHRoZSBjdXJyZW50IGhyZWYgKHBhdGggKyBzZWFyY2ggKyBoYXNoKVxuKiBAcGFyYW0gb3B0cy5jcmVhdGVIcmVmIEEgZnVuY3Rpb24gdGhhdCB0YWtlcyBhIHBhdGggYW5kIHJldHVybnMgYSBocmVmIChwYXRoICsgc2VhcmNoICsgaGFzaClcbiogQHJldHVybnMgQSBoaXN0b3J5IGluc3RhbmNlXG4qL1xuZnVuY3Rpb24gY3JlYXRlQnJvd3Nlckhpc3Rvcnkob3B0cykge1xuXHRjb25zdCB3aW4gPSBvcHRzPy53aW5kb3cgPz8gKHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdyA6IHZvaWQgMCk7XG5cdGNvbnN0IG9yaWdpbmFsUHVzaFN0YXRlID0gd2luLmhpc3RvcnkucHVzaFN0YXRlO1xuXHRjb25zdCBvcmlnaW5hbFJlcGxhY2VTdGF0ZSA9IHdpbi5oaXN0b3J5LnJlcGxhY2VTdGF0ZTtcblx0bGV0IGJsb2NrZXJzID0gW107XG5cdGNvbnN0IF9nZXRCbG9ja2VycyA9ICgpID0+IGJsb2NrZXJzO1xuXHRjb25zdCBfc2V0QmxvY2tlcnMgPSAobmV3QmxvY2tlcnMpID0+IGJsb2NrZXJzID0gbmV3QmxvY2tlcnM7XG5cdGNvbnN0IGNyZWF0ZUhyZWYgPSAocGF0aCkgPT4gbm9ybWFsaXplSHJlZihvcHRzPy5jcmVhdGVIcmVmID8gb3B0cy5jcmVhdGVIcmVmKHBhdGgpIDogcGF0aCk7XG5cdGNvbnN0IHBhcnNlTG9jYXRpb24gPSBvcHRzPy5wYXJzZUxvY2F0aW9uID8/ICgoKSA9PiBwYXJzZUhyZWYoYCR7d2luLmxvY2F0aW9uLnBhdGhuYW1lfSR7d2luLmxvY2F0aW9uLnNlYXJjaH0ke3dpbi5sb2NhdGlvbi5oYXNofWAsIHdpbi5oaXN0b3J5LnN0YXRlKSk7XG5cdGlmICghd2luLmhpc3Rvcnkuc3RhdGU/Ll9fVFNSX2tleSAmJiAhd2luLmhpc3Rvcnkuc3RhdGU/LmtleSkge1xuXHRcdGNvbnN0IGFkZGVkS2V5ID0gY3JlYXRlUmFuZG9tS2V5KCk7XG5cdFx0d2luLmhpc3RvcnkucmVwbGFjZVN0YXRlKHtcblx0XHRcdFtzdGF0ZUluZGV4S2V5XTogMCxcblx0XHRcdGtleTogYWRkZWRLZXksXG5cdFx0XHRfX1RTUl9rZXk6IGFkZGVkS2V5XG5cdFx0fSwgXCJcIik7XG5cdH1cblx0bGV0IGN1cnJlbnRMb2NhdGlvbiA9IHBhcnNlTG9jYXRpb24oKTtcblx0bGV0IHJvbGxiYWNrTG9jYXRpb247XG5cdGxldCBuZXh0UG9wSXNHbyA9IGZhbHNlO1xuXHRsZXQgaWdub3JlTmV4dFBvcCA9IGZhbHNlO1xuXHRsZXQgc2tpcEJsb2NrZXJOZXh0UG9wID0gZmFsc2U7XG5cdGxldCBpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gZmFsc2U7XG5cdGNvbnN0IGdldExvY2F0aW9uID0gKCkgPT4gY3VycmVudExvY2F0aW9uO1xuXHRsZXQgbmV4dDtcblx0Y29uc3QgZmx1c2ggPSAoKSA9PiB7XG5cdFx0aWYgKCFuZXh0KSByZXR1cm47XG5cdFx0aGlzdG9yeS5faWdub3JlU3Vic2NyaWJlcnMgPSB0cnVlO1xuXHRcdChuZXh0WzJdID8gd2luLmhpc3RvcnkucHVzaFN0YXRlIDogd2luLmhpc3RvcnkucmVwbGFjZVN0YXRlKShuZXh0WzFdLCBcIlwiLCBuZXh0WzBdKTtcblx0XHRoaXN0b3J5Ll9pZ25vcmVTdWJzY3JpYmVycyA9IGZhbHNlO1xuXHRcdG5leHQgPSB2b2lkIDA7XG5cdFx0cm9sbGJhY2tMb2NhdGlvbiA9IHZvaWQgMDtcblx0fTtcblx0Y29uc3QgcXVldWVIaXN0b3J5QWN0aW9uID0gKGlzUHVzaCwgZGVzdEhyZWYsIHN0YXRlKSA9PiB7XG5cdFx0Y29uc3QgaHJlZiA9IG9wdHM/LmNyZWF0ZUhyZWYgPyBjcmVhdGVIcmVmKGRlc3RIcmVmKSA6IHZvaWQgMDtcblx0XHRjb25zdCBoYXNQZW5kaW5nQWN0aW9uID0gISFuZXh0O1xuXHRcdGlmICghaGFzUGVuZGluZ0FjdGlvbikgcm9sbGJhY2tMb2NhdGlvbiA9IGN1cnJlbnRMb2NhdGlvbjtcblx0XHRjdXJyZW50TG9jYXRpb24gPSBwYXJzZUhyZWYoZGVzdEhyZWYsIHN0YXRlKTtcblx0XHRuZXh0ID0gW1xuXHRcdFx0aHJlZiA/PyBjdXJyZW50TG9jYXRpb24uaHJlZixcblx0XHRcdHN0YXRlLFxuXHRcdFx0bmV4dD8uWzJdIHx8IGlzUHVzaFxuXHRcdF07XG5cdFx0aWYgKCFoYXNQZW5kaW5nQWN0aW9uKSBxdWV1ZU1pY3JvdGFzaygoKSA9PiBmbHVzaCgpKTtcblx0fTtcblx0Y29uc3Qgb25QdXNoUG9wID0gKHR5cGUpID0+IHtcblx0XHRjdXJyZW50TG9jYXRpb24gPSBwYXJzZUxvY2F0aW9uKCk7XG5cdFx0aGlzdG9yeS5ub3RpZnkoeyB0eXBlIH0pO1xuXHR9O1xuXHRjb25zdCBvblB1c2hQb3BFdmVudCA9IGFzeW5jICgpID0+IHtcblx0XHRpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gZmFsc2U7XG5cdFx0aWYgKGlnbm9yZU5leHRQb3ApIHtcblx0XHRcdGlnbm9yZU5leHRQb3AgPSBmYWxzZTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0Y29uc3QgbmV4dExvY2F0aW9uID0gcGFyc2VMb2NhdGlvbigpO1xuXHRcdGNvbnN0IGRlbHRhID0gbmV4dExvY2F0aW9uLnN0YXRlW3N0YXRlSW5kZXhLZXldIC0gY3VycmVudExvY2F0aW9uLnN0YXRlW3N0YXRlSW5kZXhLZXldO1xuXHRcdGNvbnN0IGlzRm9yd2FyZCA9IGRlbHRhID09PSAxO1xuXHRcdGNvbnN0IGlzQmFjayA9IGRlbHRhID09PSAtMTtcblx0XHRjb25zdCBpc0dvID0gIWlzRm9yd2FyZCAmJiAhaXNCYWNrIHx8IG5leHRQb3BJc0dvO1xuXHRcdG5leHRQb3BJc0dvID0gZmFsc2U7XG5cdFx0Y29uc3QgYWN0aW9uID0gaXNHbyA/IFwiR09cIiA6IGlzQmFjayA/IFwiQkFDS1wiIDogXCJGT1JXQVJEXCI7XG5cdFx0Y29uc3Qgbm90aWZ5ID0gaXNHbyA/IHtcblx0XHRcdHR5cGU6IFwiR09cIixcblx0XHRcdGluZGV4OiBkZWx0YVxuXHRcdH0gOiB7IHR5cGU6IGlzQmFjayA/IFwiQkFDS1wiIDogXCJGT1JXQVJEXCIgfTtcblx0XHRpZiAoc2tpcEJsb2NrZXJOZXh0UG9wKSBza2lwQmxvY2tlck5leHRQb3AgPSBmYWxzZTtcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGJsb2NrZXJzID0gX2dldEJsb2NrZXJzKCk7XG5cdFx0XHRpZiAodHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIGJsb2NrZXJzLmxlbmd0aCkge1xuXHRcdFx0XHRmb3IgKGNvbnN0IGJsb2NrZXIgb2YgYmxvY2tlcnMpIGlmIChhd2FpdCBibG9ja2VyLmJsb2NrZXJGbih7XG5cdFx0XHRcdFx0Y3VycmVudExvY2F0aW9uLFxuXHRcdFx0XHRcdG5leHRMb2NhdGlvbixcblx0XHRcdFx0XHRhY3Rpb25cblx0XHRcdFx0fSkpIHtcblx0XHRcdFx0XHRpZ25vcmVOZXh0UG9wID0gdHJ1ZTtcblx0XHRcdFx0XHR3aW4uaGlzdG9yeS5nbygtZGVsdGEpO1xuXHRcdFx0XHRcdGhpc3Rvcnkubm90aWZ5KG5vdGlmeSk7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGN1cnJlbnRMb2NhdGlvbiA9IHBhcnNlTG9jYXRpb24oKTtcblx0XHRoaXN0b3J5Lm5vdGlmeShub3RpZnkpO1xuXHR9O1xuXHRjb25zdCBvbkJlZm9yZVVubG9hZCA9IChlKSA9PiB7XG5cdFx0aWYgKGlnbm9yZU5leHRCZWZvcmVVbmxvYWQpIHtcblx0XHRcdGlnbm9yZU5leHRCZWZvcmVVbmxvYWQgPSBmYWxzZTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0bGV0IHNob3VsZEJsb2NrID0gZmFsc2U7XG5cdFx0Y29uc3QgYmxvY2tlcnMgPSBfZ2V0QmxvY2tlcnMoKTtcblx0XHRpZiAodHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIGJsb2NrZXJzLmxlbmd0aCkgZm9yIChjb25zdCBibG9ja2VyIG9mIGJsb2NrZXJzKSB7XG5cdFx0XHRjb25zdCBzaG91bGRIYXZlQmVmb3JlVW5sb2FkID0gYmxvY2tlci5lbmFibGVCZWZvcmVVbmxvYWQgPz8gdHJ1ZTtcblx0XHRcdGlmIChzaG91bGRIYXZlQmVmb3JlVW5sb2FkID09PSB0cnVlKSB7XG5cdFx0XHRcdHNob3VsZEJsb2NrID0gdHJ1ZTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cdFx0XHRpZiAodHlwZW9mIHNob3VsZEhhdmVCZWZvcmVVbmxvYWQgPT09IFwiZnVuY3Rpb25cIiAmJiBzaG91bGRIYXZlQmVmb3JlVW5sb2FkKCkgPT09IHRydWUpIHtcblx0XHRcdFx0c2hvdWxkQmxvY2sgPSB0cnVlO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYgKHNob3VsZEJsb2NrKSB7XG5cdFx0XHRlLnByZXZlbnREZWZhdWx0KCk7XG5cdFx0XHRyZXR1cm4gZS5yZXR1cm5WYWx1ZSA9IFwiXCI7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBoaXN0b3J5ID0gY3JlYXRlSGlzdG9yeSh7XG5cdFx0Z2V0TG9jYXRpb24sXG5cdFx0Z2V0TGVuZ3RoOiAoKSA9PiB3aW4uaGlzdG9yeS5sZW5ndGgsXG5cdFx0cHVzaFN0YXRlOiAoaHJlZiwgc3RhdGUpID0+IHF1ZXVlSGlzdG9yeUFjdGlvbih0cnVlLCBocmVmLCBzdGF0ZSksXG5cdFx0cmVwbGFjZVN0YXRlOiAoaHJlZiwgc3RhdGUpID0+IHF1ZXVlSGlzdG9yeUFjdGlvbihmYWxzZSwgaHJlZiwgc3RhdGUpLFxuXHRcdGJhY2s6IChpZ25vcmVCbG9ja2VyKSA9PiB7XG5cdFx0XHRpZiAoaWdub3JlQmxvY2tlcikge1xuXHRcdFx0XHRza2lwQmxvY2tlck5leHRQb3AgPSB0cnVlO1xuXHRcdFx0XHRpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gdHJ1ZTtcblx0XHRcdH1cblx0XHRcdHJldHVybiB3aW4uaGlzdG9yeS5iYWNrKCk7XG5cdFx0fSxcblx0XHRmb3J3YXJkOiAoaWdub3JlQmxvY2tlcikgPT4ge1xuXHRcdFx0aWYgKGlnbm9yZUJsb2NrZXIpIHtcblx0XHRcdFx0c2tpcEJsb2NrZXJOZXh0UG9wID0gdHJ1ZTtcblx0XHRcdFx0aWdub3JlTmV4dEJlZm9yZVVubG9hZCA9IHRydWU7XG5cdFx0XHR9XG5cdFx0XHR3aW4uaGlzdG9yeS5mb3J3YXJkKCk7XG5cdFx0fSxcblx0XHRnbzogKG4sIGlnbm9yZUJsb2NrZXIpID0+IHtcblx0XHRcdG5leHRQb3BJc0dvID0gdHJ1ZTtcblx0XHRcdGlmIChpZ25vcmVCbG9ja2VyKSB7XG5cdFx0XHRcdHNraXBCbG9ja2VyTmV4dFBvcCA9IHRydWU7XG5cdFx0XHRcdGlnbm9yZU5leHRCZWZvcmVVbmxvYWQgPSB0cnVlO1xuXHRcdFx0fVxuXHRcdFx0d2luLmhpc3RvcnkuZ28obik7XG5cdFx0fSxcblx0XHRjcmVhdGVIcmVmLFxuXHRcdGZsdXNoLFxuXHRcdGRlc3Ryb3k6ICgpID0+IHtcblx0XHRcdHdpbi5oaXN0b3J5LnB1c2hTdGF0ZSA9IG9yaWdpbmFsUHVzaFN0YXRlO1xuXHRcdFx0d2luLmhpc3RvcnkucmVwbGFjZVN0YXRlID0gb3JpZ2luYWxSZXBsYWNlU3RhdGU7XG5cdFx0XHR3aW4ucmVtb3ZlRXZlbnRMaXN0ZW5lcihiZWZvcmVVbmxvYWRFdmVudCwgb25CZWZvcmVVbmxvYWQsIHsgY2FwdHVyZTogdHJ1ZSB9KTtcblx0XHRcdHdpbi5yZW1vdmVFdmVudExpc3RlbmVyKHBvcFN0YXRlRXZlbnQsIG9uUHVzaFBvcEV2ZW50KTtcblx0XHR9LFxuXHRcdG9uQmxvY2tlZDogKCkgPT4ge1xuXHRcdFx0aWYgKHJvbGxiYWNrTG9jYXRpb24gJiYgY3VycmVudExvY2F0aW9uICE9PSByb2xsYmFja0xvY2F0aW9uKSBjdXJyZW50TG9jYXRpb24gPSByb2xsYmFja0xvY2F0aW9uO1xuXHRcdH0sXG5cdFx0Z2V0QmxvY2tlcnM6IF9nZXRCbG9ja2Vycyxcblx0XHRzZXRCbG9ja2VyczogX3NldEJsb2NrZXJzLFxuXHRcdG5vdGlmeU9uSW5kZXhDaGFuZ2U6IGZhbHNlXG5cdH0pO1xuXHRoaXN0b3J5Ll9pZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gKGhyZWYpID0+IHtcblx0XHRpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gZmFsc2U7XG5cdFx0dHJ5IHtcblx0XHRcdGhyZWYgPSBuZXcgVVJMKGhyZWYsIHdpbi5kb2N1bWVudC5iYXNlVVJJKS5ocmVmO1xuXHRcdFx0aWdub3JlTmV4dEJlZm9yZVVubG9hZCA9IC9eaHR0cHM/Oi8udGVzdChocmVmKSAmJiAoIWhyZWYuaW5jbHVkZXMoXCIjXCIpIHx8IGhyZWYuc3BsaXQoXCIjXCIpWzBdICE9PSB3aW4ubG9jYXRpb24uaHJlZi5zcGxpdChcIiNcIilbMF0pO1xuXHRcdH0gY2F0Y2gge31cblx0fTtcblx0d2luLmFkZEV2ZW50TGlzdGVuZXIoYmVmb3JlVW5sb2FkRXZlbnQsIG9uQmVmb3JlVW5sb2FkLCB7IGNhcHR1cmU6IHRydWUgfSk7XG5cdHdpbi5hZGRFdmVudExpc3RlbmVyKHBvcFN0YXRlRXZlbnQsIG9uUHVzaFBvcEV2ZW50KTtcblx0d2luLmhpc3RvcnkucHVzaFN0YXRlID0gZnVuY3Rpb24oLi4uYXJncykge1xuXHRcdGNvbnN0IHJlcyA9IG9yaWdpbmFsUHVzaFN0YXRlLmFwcGx5KHdpbi5oaXN0b3J5LCBhcmdzKTtcblx0XHRpZiAoIWhpc3RvcnkuX2lnbm9yZVN1YnNjcmliZXJzKSBvblB1c2hQb3AoXCJQVVNIXCIpO1xuXHRcdHJldHVybiByZXM7XG5cdH07XG5cdHdpbi5oaXN0b3J5LnJlcGxhY2VTdGF0ZSA9IGZ1bmN0aW9uKC4uLmFyZ3MpIHtcblx0XHRjb25zdCByZXMgPSBvcmlnaW5hbFJlcGxhY2VTdGF0ZS5hcHBseSh3aW4uaGlzdG9yeSwgYXJncyk7XG5cdFx0aWYgKCFoaXN0b3J5Ll9pZ25vcmVTdWJzY3JpYmVycykgb25QdXNoUG9wKFwiUkVQTEFDRVwiKTtcblx0XHRyZXR1cm4gcmVzO1xuXHR9O1xuXHRyZXR1cm4gaGlzdG9yeTtcbn1cbi8qKlxuKiBDcmVhdGUgYSBoYXNoLWJhc2VkIGhpc3RvcnkgaW1wbGVtZW50YXRpb24uXG4qIFVzZWZ1bCBmb3Igc3RhdGljIGhvc3RzIG9yIGVudmlyb25tZW50cyB3aXRob3V0IHNlcnZlciBVUkwgcmV3cml0aW5nLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2d1aWRlL2hpc3RvcnktdHlwZXNcbiovXG5mdW5jdGlvbiBjcmVhdGVIYXNoSGlzdG9yeShvcHRzKSB7XG5cdGNvbnN0IHdpbiA9IG9wdHM/LndpbmRvdyA/PyAodHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDogdm9pZCAwKTtcblx0cmV0dXJuIGNyZWF0ZUJyb3dzZXJIaXN0b3J5KHtcblx0XHR3aW5kb3c6IHdpbixcblx0XHRwYXJzZUxvY2F0aW9uOiAoKSA9PiB7XG5cdFx0XHRjb25zdCBoYXNoID0gd2luLmxvY2F0aW9uLmhhc2g7XG5cdFx0XHRsZXQgaGFzaEluZGV4ID0gaGFzaC5pbmRleE9mKFwiI1wiLCAxKTtcblx0XHRcdGlmIChoYXNoSW5kZXggPCAwKSBoYXNoSW5kZXggPSBoYXNoLmxlbmd0aDtcblx0XHRcdHJldHVybiBwYXJzZUhyZWYoYCR7aGFzaCA/IGhhc2guc2xpY2UoMSwgaGFzaEluZGV4KSA6IFwiL1wifSR7d2luLmxvY2F0aW9uLnNlYXJjaH0ke2hhc2guc2xpY2UoaGFzaEluZGV4KX1gLCB3aW4uaGlzdG9yeS5zdGF0ZSk7XG5cdFx0fSxcblx0XHRjcmVhdGVIcmVmOiAoaHJlZikgPT4gYCR7d2luLmxvY2F0aW9uLnBhdGhuYW1lfSR7d2luLmxvY2F0aW9uLnNlYXJjaH0jJHtocmVmfWBcblx0fSk7XG59XG4vKipcbiogQ3JlYXRlIGFuIGluLW1lbW9yeSBoaXN0b3J5IGltcGxlbWVudGF0aW9uLlxuKiBJZGVhbCBmb3Igc2VydmVyIHJlbmRlcmluZywgdGVzdHMsIGFuZCBub24tRE9NIGVudmlyb25tZW50cy5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9ndWlkZS9oaXN0b3J5LXR5cGVzXG4qL1xuZnVuY3Rpb24gY3JlYXRlTWVtb3J5SGlzdG9yeShvcHRzID0geyBpbml0aWFsRW50cmllczogW1wiL1wiXSB9KSB7XG5cdGNvbnN0IGVudHJpZXMgPSBvcHRzLmluaXRpYWxFbnRyaWVzO1xuXHRsZXQgaW5kZXggPSBvcHRzLmluaXRpYWxJbmRleCA/IE1hdGgubWluKE1hdGgubWF4KG9wdHMuaW5pdGlhbEluZGV4LCAwKSwgZW50cmllcy5sZW5ndGggLSAxKSA6IGVudHJpZXMubGVuZ3RoIC0gMTtcblx0Y29uc3Qgc3RhdGVzID0gZW50cmllcy5tYXAoKF9lbnRyeSwgaW5kZXgpID0+IGFzc2lnbktleUFuZEluZGV4KGluZGV4LCB2b2lkIDApKTtcblx0Y29uc3QgZ2V0TG9jYXRpb24gPSAoKSA9PiBwYXJzZUhyZWYoZW50cmllc1tpbmRleF0sIHN0YXRlc1tpbmRleF0pO1xuXHRsZXQgYmxvY2tlcnMgPSBbXTtcblx0Y29uc3QgX2dldEJsb2NrZXJzID0gKCkgPT4gYmxvY2tlcnM7XG5cdGNvbnN0IF9zZXRCbG9ja2VycyA9IChuZXdCbG9ja2VycykgPT4gYmxvY2tlcnMgPSBuZXdCbG9ja2Vycztcblx0cmV0dXJuIGNyZWF0ZUhpc3Rvcnkoe1xuXHRcdGdldExvY2F0aW9uLFxuXHRcdGdldExlbmd0aDogKCkgPT4gZW50cmllcy5sZW5ndGgsXG5cdFx0cHVzaFN0YXRlOiAocGF0aCwgc3RhdGUpID0+IHtcblx0XHRcdGluZGV4ID0gaW5kZXggPCBlbnRyaWVzLmxlbmd0aCAtIDEgPyBpbmRleCArIDEgOiBlbnRyaWVzLmxlbmd0aDtcblx0XHRcdHN0YXRlc1tpbmRleF0gPSBzdGF0ZTtcblx0XHRcdGVudHJpZXNbaW5kZXhdID0gcGF0aDtcblx0XHRcdGlmIChpbmRleCA8IGVudHJpZXMubGVuZ3RoIC0gMSkge1xuXHRcdFx0XHRlbnRyaWVzLmxlbmd0aCA9IGluZGV4ICsgMTtcblx0XHRcdFx0c3RhdGVzLmxlbmd0aCA9IGluZGV4ICsgMTtcblx0XHRcdH1cblx0XHR9LFxuXHRcdHJlcGxhY2VTdGF0ZTogKHBhdGgsIHN0YXRlKSA9PiB7XG5cdFx0XHRzdGF0ZXNbaW5kZXhdID0gc3RhdGU7XG5cdFx0XHRlbnRyaWVzW2luZGV4XSA9IHBhdGg7XG5cdFx0fSxcblx0XHRiYWNrOiAoKSA9PiB7XG5cdFx0XHRpbmRleCA9IE1hdGgubWF4KGluZGV4IC0gMSwgMCk7XG5cdFx0fSxcblx0XHRmb3J3YXJkOiAoKSA9PiB7XG5cdFx0XHRpbmRleCA9IE1hdGgubWluKGluZGV4ICsgMSwgZW50cmllcy5sZW5ndGggLSAxKTtcblx0XHR9LFxuXHRcdGdvOiAobikgPT4ge1xuXHRcdFx0aW5kZXggPSBNYXRoLm1pbihNYXRoLm1heChpbmRleCArIG4sIDApLCBlbnRyaWVzLmxlbmd0aCAtIDEpO1xuXHRcdH0sXG5cdFx0Y3JlYXRlSHJlZjogbm9ybWFsaXplSHJlZixcblx0XHRnZXRCbG9ja2VyczogX2dldEJsb2NrZXJzLFxuXHRcdHNldEJsb2NrZXJzOiBfc2V0QmxvY2tlcnNcblx0fSk7XG59XG52YXIgbm9vcCA9ICgpID0+IHt9O1xudmFyIFNlcnZlckhpc3RvcnkgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKGxvY2F0aW9uKSB7XG5cdFx0dGhpcy5sb2NhdGlvbiA9IGxvY2F0aW9uO1xuXHR9XG5cdGdldCBsZW5ndGgoKSB7XG5cdFx0cmV0dXJuIDE7XG5cdH1cblx0Z2V0IHN1YnNjcmliZXJzKCkge1xuXHRcdHJldHVybiB0aGlzLl9zdWJzY3JpYmVycyA/Pz0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0fVxuXHRzdWJzY3JpYmUoKSB7XG5cdFx0cmV0dXJuIG5vb3A7XG5cdH1cblx0cHVzaCgpIHt9XG5cdHJlcGxhY2UoKSB7fVxuXHRnbygpIHt9XG5cdGJhY2soKSB7fVxuXHRmb3J3YXJkKCkge31cblx0Y2FuR29CYWNrKCkge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXHRjcmVhdGVIcmVmKGhyZWYpIHtcblx0XHRyZXR1cm4gbm9ybWFsaXplSHJlZihocmVmKTtcblx0fVxuXHRibG9jaygpIHtcblx0XHRyZXR1cm4gbm9vcDtcblx0fVxuXHRmbHVzaCgpIHt9XG5cdGRlc3Ryb3koKSB7fVxuXHRub3RpZnkoKSB7fVxuXHRfZ2V0QmxvY2tlcnMoKSB7XG5cdFx0cmV0dXJuIFtdO1xuXHR9XG59O1xuLyoqIEEgZml4ZWQgcmVxdWVzdCBsb2NhdGlvbjsgc2VydmVyIG5hdmlnYXRpb24gaXMgYSBuby1vcC4gKi9cbmZ1bmN0aW9uIGNyZWF0ZVNlcnZlckhpc3RvcnkoaHJlZikge1xuXHRyZXR1cm4gbmV3IFNlcnZlckhpc3RvcnkocGFyc2VIcmVmKGhyZWYsIHZvaWQgMCkpO1xufVxuZnVuY3Rpb24gcGFyc2VIcmVmKGhyZWYsIHN0YXRlKSB7XG5cdGNvbnN0IHNhbml0aXplZEhyZWYgPSBub3JtYWxpemVIcmVmKGhyZWYpO1xuXHRjb25zdCBoYXNoSW5kZXggPSBzYW5pdGl6ZWRIcmVmLmluZGV4T2YoXCIjXCIpO1xuXHRjb25zdCBzZWFyY2hJbmRleCA9IHNhbml0aXplZEhyZWYuaW5kZXhPZihcIj9cIik7XG5cdGlmICghc3RhdGUpIHtcblx0XHRjb25zdCBrZXkgPSBjcmVhdGVSYW5kb21LZXkoKTtcblx0XHRzdGF0ZSA9IHtcblx0XHRcdFtzdGF0ZUluZGV4S2V5XTogMCxcblx0XHRcdGtleSxcblx0XHRcdF9fVFNSX2tleToga2V5XG5cdFx0fTtcblx0fVxuXHRyZXR1cm4ge1xuXHRcdGhyZWY6IHNhbml0aXplZEhyZWYsXG5cdFx0cGF0aG5hbWU6IHNhbml0aXplZEhyZWYuc2xpY2UoMCwgaGFzaEluZGV4ID4gLTEgPyBzZWFyY2hJbmRleCA+IC0xID8gTWF0aC5taW4oaGFzaEluZGV4LCBzZWFyY2hJbmRleCkgOiBoYXNoSW5kZXggOiBzZWFyY2hJbmRleCA+IC0xID8gc2VhcmNoSW5kZXggOiBzYW5pdGl6ZWRIcmVmLmxlbmd0aCksXG5cdFx0aGFzaDogaGFzaEluZGV4ID4gLTEgPyBzYW5pdGl6ZWRIcmVmLnNsaWNlKGhhc2hJbmRleCkgOiBcIlwiLFxuXHRcdHNlYXJjaDogc2VhcmNoSW5kZXggPiAtMSA/IHNhbml0aXplZEhyZWYuc2xpY2Uoc2VhcmNoSW5kZXgsIGhhc2hJbmRleCA9PT0gLTEgPyB2b2lkIDAgOiBoYXNoSW5kZXgpIDogXCJcIixcblx0XHRzdGF0ZVxuXHR9O1xufVxuZnVuY3Rpb24gY3JlYXRlUmFuZG9tS2V5KCkge1xuXHRyZXR1cm4gKE1hdGgucmFuZG9tKCkgKyAxKS50b1N0cmluZygzNikuc2xpY2UoNyk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNyZWF0ZUJyb3dzZXJIaXN0b3J5LCBjcmVhdGVIYXNoSGlzdG9yeSwgY3JlYXRlSGlzdG9yeSwgY3JlYXRlTWVtb3J5SGlzdG9yeSwgY3JlYXRlU2VydmVySGlzdG9yeSwgbm9ybWFsaXplUHJvdG9jb2xSZWxhdGl2ZSwgcGFyc2VIcmVmIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImltcG9ydCB7IERFRkFVTFRfUFJPVE9DT0xfQUxMT1dMSVNULCBjcmVhdGVOdWxsLCBkZWNvZGVQYXRoLCBkZWVwRXF1YWwsIGVuY29kZVBhdGhMaWtlVXJsLCBmaW5kTGFzdCwgZnVuY3Rpb25hbFVwZGF0ZSwgZ2V0VXJsU2NoZW1lLCBoYXNLZXlzLCBoYXNPd24sIGlzRGFuZ2Vyb3VzUHJvdG9jb2wsIGxhc3QsIG51bGxSZXBsYWNlRXF1YWxEZWVwLCBwcm90b2NvbFJlbGF0aXZlUHJlZml4UmVnZXgsIHJlcGxhY2VFcXVhbERlZXAgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgY29tcGlsZURlY29kZUNoYXJNYXAsIGludGVycG9sYXRlUGF0aCwgcmVzb2x2ZVBhdGgsIHRyaW1QYXRoLCB0cmltUGF0aFJpZ2h0IH0gZnJvbSBcIi4vcGF0aC5qc1wiO1xuaW1wb3J0IHsgY3JlYXRlU2lldmVDYWNoZSB9IGZyb20gXCIuL3NpZXZlLWNhY2hlLmpzXCI7XG5pbXBvcnQgeyBidWlsZFJvdXRlQnJhbmNoLCBmaW5kRmxhdE1hdGNoLCBmaW5kUm91dGVNYXRjaCwgZmluZFNpbmdsZU1hdGNoLCBwYXJzZVNlZ21lbnRzLCBwcm9jZXNzUm91dGVNYXNrcywgcHJvY2Vzc1JvdXRlVHJlZSB9IGZyb20gXCIuL25ldy1wcm9jZXNzLXJvdXRlLXRyZWUuanNcIjtcbmltcG9ydCB7IGlzTm90Rm91bmQgfSBmcm9tIFwiLi9ub3QtZm91bmQuanNcIjtcbmltcG9ydCB7IHNldHVwU2Nyb2xsUmVzdG9yYXRpb24gfSBmcm9tIFwiLi9zY3JvbGwtcmVzdG9yYXRpb24uanNcIjtcbmltcG9ydCB7IGRlZmF1bHRQYXJzZVNlYXJjaCwgZGVmYXVsdFN0cmluZ2lmeVNlYXJjaCB9IGZyb20gXCIuL3NlYXJjaFBhcmFtcy5qc1wiO1xuaW1wb3J0IHsgcm9vdFJvdXRlSWQgfSBmcm9tIFwiLi9yb290LmpzXCI7XG5pbXBvcnQgeyBpc1JlZGlyZWN0IH0gZnJvbSBcIi4vcmVkaXJlY3QuanNcIjtcbmltcG9ydCB7IGxvYWRDbGllbnRSb3V0ZSwgbG9hZFJvdXRlQ2h1bmssIHByZWxvYWRDbGllbnRSb3V0ZSwgcmVmcmVzaENsaWVudFJvdXRlLCByZXBsYWNlUm91dGVDaHVuayB9IGZyb20gXCIuL2xvYWQtY2xpZW50LmpzXCI7XG5pbXBvcnQgeyBleGVjdXRlUmV3cml0ZUlucHV0LCBleGVjdXRlUmV3cml0ZU91dHB1dCwgcmV3cml0ZUJhc2VwYXRoIH0gZnJvbSBcIi4vcmV3cml0ZS5qc1wiO1xuaW1wb3J0IHsgY3JlYXRlUm91dGVyU3RvcmVzIH0gZnJvbSBcIi4vc3RvcmVzLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVCcm93c2VySGlzdG9yeSwgbm9ybWFsaXplUHJvdG9jb2xSZWxhdGl2ZSwgcGFyc2VIcmVmIH0gZnJvbSBcIkB0YW5zdGFjay9oaXN0b3J5XCI7XG5pbXBvcnQgeyBpc1NlcnZlciwgbG9hZFNlcnZlclJvdXRlIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuLy8jcmVnaW9uIHNyYy9yb3V0ZXIudHNcbmZ1bmN0aW9uIGlzRXh0ZXJuYWxVcmwodXJsLCBvcmlnaW4pIHtcblx0cmV0dXJuIHVybC5wcm90b2NvbCAhPT0gXCJodHRwOlwiICYmIHVybC5wcm90b2NvbCAhPT0gXCJodHRwczpcIiB8fCB1cmwub3JpZ2luICE9PSBvcmlnaW4gfHwgISF1cmwudXNlcm5hbWUgfHwgISF1cmwucGFzc3dvcmQ7XG59XG5mdW5jdGlvbiBnZXRVcmxQYXRoKHVybCkge1xuXHRyZXR1cm4gdXJsLnBhdGhuYW1lICsgdXJsLnNlYXJjaCArIHVybC5oYXNoO1xufVxuZnVuY3Rpb24gcm91dGVOZWVkc0xvYWQocm91dGUpIHtcblx0cmV0dXJuIHJvdXRlLm9wdGlvbnMubG9hZGVyIHx8IHJvdXRlLm9wdGlvbnMuYmVmb3JlTG9hZCB8fCByb3V0ZS5sYXp5Rm4gfHwgcm91dGUub3B0aW9ucy5jb21wb25lbnQ/LnByZWxvYWQgfHwgcm91dGUub3B0aW9ucy5wZW5kaW5nQ29tcG9uZW50Py5wcmVsb2FkO1xufVxuLyoqXG4qIENvbnZlcnQgYW4gdW5rbm93biBlcnJvciBpbnRvIGEgbWluaW1hbCwgc2VyaWFsaXphYmxlIG9iamVjdC5cbiogSW5jbHVkZXMgbmFtZSBhbmQgbWVzc2FnZSAoYW5kIHN0YWNrIGluIGRldmVsb3BtZW50KS5cbiovXG5mdW5jdGlvbiBkZWZhdWx0U2VyaWFsaXplRXJyb3IoZXJyKSB7XG5cdGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuXHRcdGNvbnN0IG9iaiA9IHtcblx0XHRcdG5hbWU6IGVyci5uYW1lLFxuXHRcdFx0bWVzc2FnZTogZXJyLm1lc3NhZ2Vcblx0XHR9O1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJkZXZlbG9wbWVudFwiKSBvYmouc3RhY2sgPSBlcnIuc3RhY2s7XG5cdFx0cmV0dXJuIG9iajtcblx0fVxuXHRyZXR1cm4geyBkYXRhOiBlcnIgfTtcbn1cbi8qKiBPcHRpb25zIGZvciBjb25maWd1cmluZyB0cmFpbGluZy1zbGFzaCBiZWhhdmlvci4gKi9cbmNvbnN0IHRyYWlsaW5nU2xhc2hPcHRpb25zID0ge1xuXHRhbHdheXM6IFwiYWx3YXlzXCIsXG5cdG5ldmVyOiBcIm5ldmVyXCIsXG5cdHByZXNlcnZlOiBcInByZXNlcnZlXCJcbn07XG4vKipcbiogQ29tcHV0ZSB3aGV0aGVyIHBhdGgsIGhyZWYgb3IgaGFzaCBjaGFuZ2VkIGJldHdlZW4gcHJldmlvdXMgYW5kIGN1cnJlbnRcbiogcmVzb2x2ZWQgbG9jYXRpb25zLlxuKi9cbmZ1bmN0aW9uIGdldExvY2F0aW9uQ2hhbmdlSW5mbyhsb2NhdGlvbiwgcmVzb2x2ZWRMb2NhdGlvbikge1xuXHRyZXR1cm4ge1xuXHRcdGZyb21Mb2NhdGlvbjogcmVzb2x2ZWRMb2NhdGlvbixcblx0XHR0b0xvY2F0aW9uOiBsb2NhdGlvbixcblx0XHRwYXRoQ2hhbmdlZDogcmVzb2x2ZWRMb2NhdGlvbj8ucGF0aG5hbWUgIT09IGxvY2F0aW9uLnBhdGhuYW1lLFxuXHRcdGhyZWZDaGFuZ2VkOiByZXNvbHZlZExvY2F0aW9uPy5ocmVmICE9PSBsb2NhdGlvbi5ocmVmLFxuXHRcdGhhc2hDaGFuZ2VkOiByZXNvbHZlZExvY2F0aW9uPy5oYXNoICE9PSBsb2NhdGlvbi5oYXNoXG5cdH07XG59XG4vKipcbiogUmV0dXJuIG9ubHkgc3RhdGUgb3duZWQgYnkgdGhlIGFwcGxpY2F0aW9uLCBleGNsdWRpbmcgdm9sYXRpbGUgaGlzdG9yeVxuKiBib29ra2VlcGluZy4gTWFzayBwYXlsb2FkcyAoYF9fdGVtcExvY2F0aW9uYC9gX190ZW1wS2V5YCkgYXJlIGtlcHQ6IHRoZXlcbiogZGlzdGluZ3Vpc2ggb3RoZXJ3aXNlLWlkZW50aWNhbCBsb2NhdGlvbnMuXG4qL1xuZnVuY3Rpb24gX2dldFVzZXJIaXN0b3J5U3RhdGUoeyBrZXk6IF9rZXksIF9fVFNSX2tleTogX3RzcktleSwgX19UU1JfaW5kZXg6IF90c3JJbmRleCwgX19oYXNoU2Nyb2xsSW50b1ZpZXdPcHRpb25zOiBfaGFzaFNjcm9sbCwgLi4uc3RhdGUgfSkge1xuXHRyZXR1cm4gc3RhdGU7XG59XG5mdW5jdGlvbiBsaWZlY3ljbGVFbmQobWF0Y2hlcykge1xuXHRyZXR1cm4gbWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5zdGF0dXMgPT09IFwiZXJyb3JcIiB8fCBtYXRjaC5zdGF0dXMgPT09IFwibm90Rm91bmRcIiB8fCBtYXRjaC5fbm90Rm91bmQpICsgMTtcbn1cbi8qKiBSdW4gcm91dGUgbGlmZWN5Y2xlIGNhbGxiYWNrcyBpbiBsZWF2ZS9lbnRlci9zdGF5IHBoYXNlcy4gKi9cbmZ1bmN0aW9uIHJ1blJvdXRlTGlmZWN5Y2xlKHJvdXRlciwgcHJldmlvdXMsIG1hdGNoZXMsIHByZXZpb3VzRW5kLCBuZXh0RW5kLCBvd25lcikge1xuXHRpZiAocHJldmlvdXNFbmQpIHByZXZpb3VzID0gcHJldmlvdXMuc2xpY2UoMCwgcHJldmlvdXNFbmQpO1xuXHRpZiAobmV4dEVuZCkgbWF0Y2hlcyA9IG1hdGNoZXMuc2xpY2UoMCwgbmV4dEVuZCk7XG5cdGZvciAoY29uc3QgbWF0Y2ggb2YgcHJldmlvdXMpIHtcblx0XHRpZiAob3duZXIgJiYgcm91dGVyLl90eCAhPT0gb3duZXIpIHJldHVybjtcblx0XHRpZiAoIW1hdGNoZXMuc29tZSgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUucm91dGVJZCA9PT0gbWF0Y2gucm91dGVJZCkpIHJvdXRlci5yb3V0ZXNCeUlkW21hdGNoLnJvdXRlSWRdLm9wdGlvbnMub25MZWF2ZT8uKG1hdGNoKTtcblx0fVxuXHRmb3IgKGNvbnN0IG1hdGNoIG9mIG1hdGNoZXMpIHtcblx0XHRpZiAob3duZXIgJiYgcm91dGVyLl90eCAhPT0gb3duZXIpIHJldHVybjtcblx0XHRyb3V0ZXIucm91dGVzQnlJZFttYXRjaC5yb3V0ZUlkXS5vcHRpb25zW3ByZXZpb3VzLnNvbWUoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLnJvdXRlSWQgPT09IG1hdGNoLnJvdXRlSWQpID8gXCJvblN0YXlcIiA6IFwib25FbnRlclwiXT8uKG1hdGNoKTtcblx0fVxufVxuLyoqXG4qIENvcmUsIGZyYW1ld29yay1hZ25vc3RpYyByb3V0ZXIgZW5naW5lIHRoYXQgcG93ZXJzIFRhblN0YWNrIFJvdXRlci5cbipcbiogUHJvdmlkZXMgbmF2aWdhdGlvbiwgbWF0Y2hpbmcsIGxvYWRpbmcsIHByZWxvYWRpbmcsIGNhY2hpbmcgYW5kIGV2ZW50IEFQSXNcbiogdXNlZCBieSBmcmFtZXdvcmsgYWRhcHRlcnMgKFJlYWN0L1NvbGlkKS4gUHJlZmVyIGZyYW1ld29yayBoZWxwZXJzIGxpa2VcbiogYGNyZWF0ZVJvdXRlcmAgaW4gYXBwIGNvZGUuXG4qXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9Sb3V0ZXJUeXBlXG4qL1xudmFyIFJvdXRlckNvcmUgPSBjbGFzcyB7XG5cdC8qKlxuXHQqIEBkZXByZWNhdGVkIFVzZSB0aGUgYGNyZWF0ZVJvdXRlcmAgZnVuY3Rpb24gaW5zdGVhZFxuXHQqL1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zLCBnZXRTdG9yZUNvbmZpZykge1xuXHRcdHRoaXMudGVtcExvY2F0aW9uS2V5ID0gYCR7TWF0aC5yb3VuZChNYXRoLnJhbmRvbSgpICogMWU3KX1gO1xuXHRcdHRoaXMuX3Njcm9sbCA9IHsgbjogdHJ1ZSB9O1xuXHRcdHRoaXMuc3Vic2NyaWJlcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHRoaXMuX2NhY2hlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHR0aGlzLl9jb21taXR0ZWQgPSBbXTtcblx0XHR0aGlzLnN0YXJ0VHJhbnNpdGlvbiA9IGFzeW5jIChmbikgPT4ge1xuXHRcdFx0Zm4oKTtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9O1xuXHRcdHRoaXMudXBkYXRlID0gKG5ld09wdGlvbnMpID0+IHtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdFx0aWYgKG5ld09wdGlvbnMubm90Rm91bmRSb3V0ZSkgY29uc29sZS53YXJuKFwiVGhlIG5vdEZvdW5kUm91dGUgQVBJIGlzIGRlcHJlY2F0ZWQgYW5kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmV4dCBtYWpvciB2ZXJzaW9uLiBTZWUgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL3YxL2RvY3MvZnJhbWV3b3JrL3JlYWN0L2d1aWRlL25vdC1mb3VuZC1lcnJvcnMjbWlncmF0aW5nLWZyb20tbm90Zm91bmRyb3V0ZSBmb3IgbW9yZSBpbmZvLlwiKTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHByZXZPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuXHRcdFx0dGhpcy5vcHRpb25zID0ge1xuXHRcdFx0XHQuLi5wcmV2T3B0aW9ucyxcblx0XHRcdFx0Li4ubmV3T3B0aW9uc1xuXHRcdFx0fTtcblx0XHRcdHRoaXMuaXNTZXJ2ZXIgPSB0aGlzLm9wdGlvbnMuaXNTZXJ2ZXIgPz8gaXNTZXJ2ZXIgPz8gdHlwZW9mIGRvY3VtZW50ID09PSBcInVuZGVmaW5lZFwiO1xuXHRcdFx0aWYgKCEoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikpIHRoaXMuc3RhdGljTG9jYXRpb25zID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5cdFx0XHR0aGlzLnByb3RvY29sQWxsb3dsaXN0ID0gbmV3IFNldCh0aGlzLm9wdGlvbnMucHJvdG9jb2xBbGxvd2xpc3QpO1xuXHRcdFx0aWYgKCF0aGlzLmhpc3RvcnkgfHwgdGhpcy5vcHRpb25zLmhpc3RvcnkgJiYgdGhpcy5vcHRpb25zLmhpc3RvcnkgIT09IHRoaXMuaGlzdG9yeSkge1xuXHRcdFx0XHRpZiAoIXRoaXMub3B0aW9ucy5oaXN0b3J5KSB7XG5cdFx0XHRcdFx0aWYgKCEoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikpIHRoaXMuaGlzdG9yeSA9IGNyZWF0ZUJyb3dzZXJIaXN0b3J5KCk7XG5cdFx0XHRcdH0gZWxzZSB0aGlzLmhpc3RvcnkgPSB0aGlzLm9wdGlvbnMuaGlzdG9yeTtcblx0XHRcdH1cblx0XHRcdHRoaXMub3JpZ2luID0gdGhpcy5vcHRpb25zLm9yaWdpbjtcblx0XHRcdGlmICghdGhpcy5vcmlnaW4pIHtcblx0XHRcdFx0aWYgKCEoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikgJiYgd2luZG93Py5vcmlnaW4gJiYgd2luZG93Lm9yaWdpbiAhPT0gXCJudWxsXCIpIHRoaXMub3JpZ2luID0gd2luZG93Lm9yaWdpbjtcblx0XHRcdFx0ZWxzZSB0aGlzLm9yaWdpbiA9IFwiaHR0cDovL2xvY2FsaG9zdFwiO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgbmV4dEJhc2VwYXRoID0gdGhpcy5vcHRpb25zLmJhc2VwYXRoID8/IFwiL1wiO1xuXHRcdFx0Y29uc3QgbmV4dFJld3JpdGVPcHRpb24gPSB0aGlzLm9wdGlvbnMucmV3cml0ZTtcblx0XHRcdGNvbnN0IHJld3JpdGVDaGFuZ2VkID0gdGhpcy5iYXNlcGF0aCAhPT0gbmV4dEJhc2VwYXRoIHx8IHByZXZPcHRpb25zPy5yZXdyaXRlICE9PSBuZXh0UmV3cml0ZU9wdGlvbiB8fCBwcmV2T3B0aW9ucz8uY2FzZVNlbnNpdGl2ZSAhPT0gdGhpcy5vcHRpb25zLmNhc2VTZW5zaXRpdmU7XG5cdFx0XHRpZiAocmV3cml0ZUNoYW5nZWQpIHtcblx0XHRcdFx0dGhpcy5iYXNlcGF0aCA9IG5leHRCYXNlcGF0aDtcblx0XHRcdFx0dGhpcy5yZXdyaXRlID0gbmV4dEJhc2VwYXRoICE9PSBcIi9cIiAmJiB0cmltUGF0aChuZXh0QmFzZXBhdGgpID8gcmV3cml0ZUJhc2VwYXRoKG5leHRCYXNlcGF0aCwgdGhpcy5vcHRpb25zLmNhc2VTZW5zaXRpdmUsIG5leHRSZXdyaXRlT3B0aW9uKSA6IG5leHRSZXdyaXRlT3B0aW9uO1xuXHRcdFx0fVxuXHRcdFx0aWYgKHRoaXMuaGlzdG9yeSkgdGhpcy51cGRhdGVMYXRlc3RMb2NhdGlvbigpO1xuXHRcdFx0aWYgKHRoaXMub3B0aW9ucy5yb3V0ZVRyZWUgIT09IHRoaXMucm91dGVUcmVlIHx8IChpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSAmJiBwcmV2T3B0aW9ucz8uY2FzZVNlbnNpdGl2ZSAhPT0gdGhpcy5vcHRpb25zLmNhc2VTZW5zaXRpdmUpIHtcblx0XHRcdFx0dGhpcy5yb3V0ZVRyZWUgPSB0aGlzLm9wdGlvbnMucm91dGVUcmVlO1xuXHRcdFx0XHRsZXQgcHJvY2Vzc1JvdXRlVHJlZVJlc3VsdDtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcImRldmVsb3BtZW50XCIgJiYgKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpICYmIGdsb2JhbFRoaXMuX19UU1JfQ0FDSEVfXyAmJiBnbG9iYWxUaGlzLl9fVFNSX0NBQ0hFX18ucm91dGVUcmVlID09PSB0aGlzLnJvdXRlVHJlZSAmJiBnbG9iYWxUaGlzLl9fVFNSX0NBQ0hFX18uY2FzZVNlbnNpdGl2ZSA9PT0gdGhpcy5vcHRpb25zLmNhc2VTZW5zaXRpdmUpIHByb2Nlc3NSb3V0ZVRyZWVSZXN1bHQgPSBnbG9iYWxUaGlzLl9fVFNSX0NBQ0hFX18ucHJvY2Vzc1JvdXRlVHJlZVJlc3VsdDtcblx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0cHJvY2Vzc1JvdXRlVHJlZVJlc3VsdCA9IHRoaXMuYnVpbGRSb3V0ZVRyZWUoKTtcblx0XHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwiZGV2ZWxvcG1lbnRcIiAmJiAoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikgJiYgZ2xvYmFsVGhpcy5fX1RTUl9DQUNIRV9fID09PSB2b2lkIDApIGdsb2JhbFRoaXMuX19UU1JfQ0FDSEVfXyA9IHtcblx0XHRcdFx0XHRcdHJvdXRlVHJlZTogdGhpcy5yb3V0ZVRyZWUsXG5cdFx0XHRcdFx0XHRjYXNlU2Vuc2l0aXZlOiB0aGlzLm9wdGlvbnMuY2FzZVNlbnNpdGl2ZSxcblx0XHRcdFx0XHRcdHByb2Nlc3NSb3V0ZVRyZWVSZXN1bHRcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuc2V0Um91dGVzKHByb2Nlc3NSb3V0ZVRyZWVSZXN1bHQpO1xuXHRcdFx0fVxuXHRcdFx0aWYgKCF0aGlzLnN0b3Jlcykge1xuXHRcdFx0XHRpZiAodGhpcy5sYXRlc3RMb2NhdGlvbikge1xuXHRcdFx0XHRcdGNvbnN0IGNvbmZpZyA9IHRoaXMuZ2V0U3RvcmVDb25maWcodGhpcyk7XG5cdFx0XHRcdFx0dGhpcy5iYXRjaCA9IGNvbmZpZy5iYXRjaDtcblx0XHRcdFx0XHR0aGlzLnN0b3JlcyA9IGNyZWF0ZVJvdXRlclN0b3Jlcyh0aGlzLmxhdGVzdExvY2F0aW9uLCBjb25maWcpO1xuXHRcdFx0XHRcdGlmICghKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpKSBzZXR1cFNjcm9sbFJlc3RvcmF0aW9uKHRoaXMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgaWYgKHJld3JpdGVDaGFuZ2VkKSB0aGlzLnN0b3Jlcy5sb2NhdGlvbi5zZXQodGhpcy5sYXRlc3RMb2NhdGlvbik7XG5cdFx0fTtcblx0XHR0aGlzLnVwZGF0ZUxhdGVzdExvY2F0aW9uID0gKCkgPT4ge1xuXHRcdFx0dGhpcy5sYXRlc3RMb2NhdGlvbiA9IHRoaXMucGFyc2VMb2NhdGlvbih0aGlzLmhpc3RvcnkubG9jYXRpb24sIHRoaXMubGF0ZXN0TG9jYXRpb24pO1xuXHRcdH07XG5cdFx0dGhpcy5idWlsZFJvdXRlVHJlZSA9ICgpID0+IHtcblx0XHRcdGNvbnN0IHJlc3VsdCA9IHByb2Nlc3NSb3V0ZVRyZWUodGhpcy5yb3V0ZVRyZWUsIHRoaXMub3B0aW9ucy5jYXNlU2Vuc2l0aXZlKTtcblx0XHRcdGlmICh0aGlzLm9wdGlvbnMucm91dGVNYXNrcykgcHJvY2Vzc1JvdXRlTWFza3ModGhpcy5vcHRpb25zLnJvdXRlTWFza3MsIHJlc3VsdC5wcm9jZXNzZWRUcmVlKTtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdC4uLnJlc3VsdCxcblx0XHRcdFx0cmVzb2x2ZVBhdGhDYWNoZTogY3JlYXRlU2lldmVDYWNoZSgxZTMpXG5cdFx0XHR9O1xuXHRcdH07XG5cdFx0dGhpcy5zdWJzY3JpYmUgPSAoZXZlbnRUeXBlLCBmbikgPT4ge1xuXHRcdFx0Y29uc3QgbGlzdGVuZXIgPSB7XG5cdFx0XHRcdGV2ZW50VHlwZSxcblx0XHRcdFx0Zm5cblx0XHRcdH07XG5cdFx0XHR0aGlzLnN1YnNjcmliZXJzLmFkZChsaXN0ZW5lcik7XG5cdFx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0XHR0aGlzLnN1YnNjcmliZXJzLmRlbGV0ZShsaXN0ZW5lcik7XG5cdFx0XHR9O1xuXHRcdH07XG5cdFx0dGhpcy5lbWl0ID0gKHJvdXRlckV2ZW50KSA9PiB7XG5cdFx0XHRmb3IgKGNvbnN0IGxpc3RlbmVyIG9mIHRoaXMuc3Vic2NyaWJlcnMpIGlmIChsaXN0ZW5lci5ldmVudFR5cGUgPT09IHJvdXRlckV2ZW50LnR5cGUpIHRyeSB7XG5cdFx0XHRcdGxpc3RlbmVyLmZuKHJvdXRlckV2ZW50KTtcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0Y29uc29sZS5lcnJvcihlKTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdHRoaXMucGFyc2VMb2NhdGlvbiA9IChsb2NhdGlvblRvUGFyc2UsIHByZXZpb3VzTG9jYXRpb24pID0+IHtcblx0XHRcdGNvbnN0IHBhcnNlID0gKHsgcGF0aG5hbWUsIHNlYXJjaCwgaGFzaCwgaHJlZiB9LCBzdGF0ZSkgPT4ge1xuXHRcdFx0XHRpZiAoIXRoaXMucmV3cml0ZSAmJiAhL1sgXFx4MDAtXFx4MWZcXHg3ZlxcdTAwODAtXFx1ZmZmZl0vLnRlc3QocGF0aG5hbWUpKSB7XG5cdFx0XHRcdFx0Y29uc3QgcGFyc2VkU2VhcmNoID0gdGhpcy5vcHRpb25zLnBhcnNlU2VhcmNoKHNlYXJjaCk7XG5cdFx0XHRcdFx0Y29uc3Qgc2VhcmNoU3RyID0gdGhpcy5vcHRpb25zLnN0cmluZ2lmeVNlYXJjaChwYXJzZWRTZWFyY2gpO1xuXHRcdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0XHRocmVmOiBwYXRobmFtZSArIHNlYXJjaFN0ciArIGhhc2gsXG5cdFx0XHRcdFx0XHRwdWJsaWNIcmVmOiBwYXRobmFtZSArIHNlYXJjaFN0ciArIGhhc2gsXG5cdFx0XHRcdFx0XHRwYXRobmFtZTogZGVjb2RlUGF0aChwYXRobmFtZSksXG5cdFx0XHRcdFx0XHRleHRlcm5hbDogZmFsc2UsXG5cdFx0XHRcdFx0XHRzZWFyY2hTdHIsXG5cdFx0XHRcdFx0XHRzZWFyY2g6IG51bGxSZXBsYWNlRXF1YWxEZWVwKHByZXZpb3VzTG9jYXRpb24/LnNlYXJjaCwgcGFyc2VkU2VhcmNoKSxcblx0XHRcdFx0XHRcdGhhc2g6IGRlY29kZVBhdGgoaGFzaC5zbGljZSgxKSksXG5cdFx0XHRcdFx0XHRzdGF0ZTogcmVwbGFjZUVxdWFsRGVlcChwcmV2aW91c0xvY2F0aW9uPy5zdGF0ZSwgc3RhdGUpXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb25zdCB1cmwgPSBleGVjdXRlUmV3cml0ZUlucHV0KHRoaXMucmV3cml0ZSwgbmV3IFVSTChocmVmLCB0aGlzLm9yaWdpbikpO1xuXHRcdFx0XHRjb25zdCBwYXJzZWRTZWFyY2ggPSB0aGlzLm9wdGlvbnMucGFyc2VTZWFyY2godXJsLnNlYXJjaCk7XG5cdFx0XHRcdGNvbnN0IHNlYXJjaFN0ciA9IHRoaXMub3B0aW9ucy5zdHJpbmdpZnlTZWFyY2gocGFyc2VkU2VhcmNoKTtcblx0XHRcdFx0dXJsLnNlYXJjaCA9IHNlYXJjaFN0cjtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRocmVmOiB1cmwuaHJlZi5yZXBsYWNlKHVybC5vcmlnaW4sIFwiXCIpLFxuXHRcdFx0XHRcdHB1YmxpY0hyZWY6IGhyZWYsXG5cdFx0XHRcdFx0cGF0aG5hbWU6IGRlY29kZVBhdGgobm9ybWFsaXplUHJvdG9jb2xSZWxhdGl2ZSh1cmwucGF0aG5hbWUpKSxcblx0XHRcdFx0XHRleHRlcm5hbDogISF0aGlzLnJld3JpdGUgJiYgaXNFeHRlcm5hbFVybCh1cmwsIHRoaXMub3JpZ2luKSxcblx0XHRcdFx0XHRzZWFyY2hTdHIsXG5cdFx0XHRcdFx0c2VhcmNoOiBudWxsUmVwbGFjZUVxdWFsRGVlcChwcmV2aW91c0xvY2F0aW9uPy5zZWFyY2gsIHBhcnNlZFNlYXJjaCksXG5cdFx0XHRcdFx0aGFzaDogZGVjb2RlUGF0aCh1cmwuaGFzaC5zbGljZSgxKSksXG5cdFx0XHRcdFx0c3RhdGU6IHJlcGxhY2VFcXVhbERlZXAocHJldmlvdXNMb2NhdGlvbj8uc3RhdGUsIHN0YXRlKVxuXHRcdFx0XHR9O1xuXHRcdFx0fTtcblx0XHRcdGNvbnN0IGxvY2F0aW9uID0gcGFyc2UobG9jYXRpb25Ub1BhcnNlLCBsb2NhdGlvblRvUGFyc2Uuc3RhdGUpO1xuXHRcdFx0Y29uc3QgeyBfX3RlbXBMb2NhdGlvbiwgX190ZW1wS2V5IH0gPSBsb2NhdGlvbi5zdGF0ZTtcblx0XHRcdGlmIChfX3RlbXBMb2NhdGlvbiAmJiAoIV9fdGVtcEtleSB8fCBfX3RlbXBLZXkgPT09IHRoaXMudGVtcExvY2F0aW9uS2V5KSkge1xuXHRcdFx0XHRjb25zdCBwYXJzZWRUZW1wTG9jYXRpb24gPSBwYXJzZShfX3RlbXBMb2NhdGlvbiwge1xuXHRcdFx0XHRcdC4uLl9fdGVtcExvY2F0aW9uLnN0YXRlLFxuXHRcdFx0XHRcdF9fdGVtcExvY2F0aW9uOiB2b2lkIDAsXG5cdFx0XHRcdFx0a2V5OiBsb2NhdGlvbi5zdGF0ZS5rZXksXG5cdFx0XHRcdFx0X19UU1Jfa2V5OiBsb2NhdGlvbi5zdGF0ZS5fX1RTUl9rZXlcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHBhcnNlZFRlbXBMb2NhdGlvbi5tYXNrZWRMb2NhdGlvbiA9IGxvY2F0aW9uO1xuXHRcdFx0XHRyZXR1cm4gcGFyc2VkVGVtcExvY2F0aW9uO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGxvY2F0aW9uO1xuXHRcdH07XG5cdFx0dGhpcy5tYXRjaFJvdXRlcyA9IChwYXRobmFtZU9yTmV4dCwgbG9jYXRpb25TZWFyY2hPck9wdHMsIG9wdHMpID0+IHtcblx0XHRcdGlmICh0eXBlb2YgcGF0aG5hbWVPck5leHQgPT09IFwic3RyaW5nXCIpIHJldHVybiB0aGlzLm1hdGNoUm91dGVzSW50ZXJuYWwoe1xuXHRcdFx0XHRwYXRobmFtZTogcGF0aG5hbWVPck5leHQsXG5cdFx0XHRcdHNlYXJjaDogbG9jYXRpb25TZWFyY2hPck9wdHNcblx0XHRcdH0sIG9wdHMpO1xuXHRcdFx0cmV0dXJuIHRoaXMubWF0Y2hSb3V0ZXNJbnRlcm5hbChwYXRobmFtZU9yTmV4dCwgbG9jYXRpb25TZWFyY2hPck9wdHMpO1xuXHRcdH07XG5cdFx0dGhpcy5nZXRNYXRjaGVkUm91dGVzID0gKHBhdGhuYW1lKSA9PiB7XG5cdFx0XHRjb25zdCByYXdQYXJhbXMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXHRcdFx0Y29uc3QgbWF0Y2ggPSBmaW5kUm91dGVNYXRjaCh0cmltUGF0aFJpZ2h0KHBhdGhuYW1lKSwgdGhpcy5wcm9jZXNzZWRUcmVlLCB0cnVlKTtcblx0XHRcdGlmIChtYXRjaCkgT2JqZWN0LmFzc2lnbihyYXdQYXJhbXMsIG1hdGNoLnJhd1BhcmFtcyk7XG5cdFx0XHRyZXR1cm4gW1xuXHRcdFx0XHRtYXRjaD8uYnJhbmNoIHx8IFt0aGlzLnJvdXRlc0J5SWRbXCJfX3Jvb3RfX1wiXV0sXG5cdFx0XHRcdHJhd1BhcmFtcyxcblx0XHRcdFx0bWF0Y2g/LnJvdXRlXG5cdFx0XHRdO1xuXHRcdH07XG5cdFx0dGhpcy5idWlsZExvY2F0aW9uID0gKG9wdHMpID0+IHtcblx0XHRcdGlmICghKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpKSB7XG5cdFx0XHRcdGNvbnN0IGNhY2hlZCA9IHRoaXMuc3RhdGljTG9jYXRpb25zLmdldChvcHRzKTtcblx0XHRcdFx0aWYgKGNhY2hlZCkgcmV0dXJuIGNhY2hlZDtcblx0XHRcdH1cblx0XHRcdGxldCB1c2VkQ3VycmVudCA9IGZhbHNlO1xuXHRcdFx0Y29uc3QgYnVpbGQgPSAoZGVzdCA9IHt9KSA9PiB7XG5cdFx0XHRcdGlmIChkZXN0LmhyZWYpIHtcblx0XHRcdFx0XHRjb25zdCBwYXJzZWQgPSBwYXJzZUhyZWYoZGVzdC5ocmVmLCB7fSk7XG5cdFx0XHRcdFx0ZGVzdCA9IHtcblx0XHRcdFx0XHRcdC4uLmRlc3QsXG5cdFx0XHRcdFx0XHR0bzogZXhlY3V0ZVJld3JpdGVJbnB1dCh0aGlzLnJld3JpdGUsIG5ldyBVUkwocGFyc2VkLnBhdGhuYW1lLCB0aGlzLm9yaWdpbikpLnBhdGhuYW1lLFxuXHRcdFx0XHRcdFx0c2VhcmNoOiB0aGlzLm9wdGlvbnMucGFyc2VTZWFyY2gocGFyc2VkLnNlYXJjaCksXG5cdFx0XHRcdFx0XHRoYXNoOiBwYXJzZWQuaGFzaC5zbGljZSgxKVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdH1cblx0XHRcdFx0Y29uc3QgY3VycmVudExvY2F0aW9uID0gb3B0cy5fZnJvbUxvY2F0aW9uIHx8IHRoaXMuX3BlbmRpbmdMb2NhdGlvbiB8fCB0aGlzLmxhdGVzdExvY2F0aW9uO1xuXHRcdFx0XHRsZXQgbGlnaHR3ZWlnaHQ7XG5cdFx0XHRcdGNvbnN0IGN1cnJlbnQgPSAoKSA9PiB7XG5cdFx0XHRcdFx0dXNlZEN1cnJlbnQgPSB0cnVlO1xuXHRcdFx0XHRcdHJldHVybiBjdXJyZW50TG9jYXRpb247XG5cdFx0XHRcdH07XG5cdFx0XHRcdGNvbnN0IGN1cnJlbnRNYXRjaCA9ICgpID0+IGxpZ2h0d2VpZ2h0ID8/PSB0aGlzLm1hdGNoUm91dGVzTGlnaHR3ZWlnaHQoY3VycmVudCgpKTtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBkZXN0LmZyb20gJiYgZGVzdC5faXNOYXZpZ2F0ZSkge1xuXHRcdFx0XHRcdGNvbnN0IFthbGxGcm9tTWF0Y2hlc10gPSB0aGlzLmdldE1hdGNoZWRSb3V0ZXMoZGVzdC5mcm9tKTtcblx0XHRcdFx0XHRjb25zdCBbbWF0Y2hlZFJvdXRlcywgZnVsbFBhdGhdID0gY3VycmVudE1hdGNoKCk7XG5cdFx0XHRcdFx0Y29uc3QgbWF0Y2hlZEZyb20gPSBmaW5kTGFzdChtYXRjaGVkUm91dGVzLCAoZCkgPT4ge1xuXHRcdFx0XHRcdFx0cmV0dXJuIGNvbXBhcmVQYXRocyhkLmZ1bGxQYXRoLCBkZXN0LmZyb20pO1xuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdGNvbnN0IG1hdGNoZWRDdXJyZW50ID0gZmluZExhc3QoYWxsRnJvbU1hdGNoZXMsIChkKSA9PiB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gY29tcGFyZVBhdGhzKGQuZnVsbFBhdGgsIGZ1bGxQYXRoKTtcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRpZiAoIW1hdGNoZWRGcm9tICYmICFtYXRjaGVkQ3VycmVudCkgY29uc29sZS53YXJuKGBDb3VsZCBub3QgZmluZCBtYXRjaCBmb3IgZnJvbTogJHtkZXN0LmZyb219YCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0Y29uc3QgdG8gPSBkZXN0LnRvID8gYCR7ZGVzdC50b31gIDogXCIuXCI7XG5cdFx0XHRcdGNvbnN0IG5leHRUbyA9IHJlc29sdmVQYXRoKHRvWzBdID09PSBcIi9cIiA/IFwiXCIgOiBkZXN0LnVuc2FmZVJlbGF0aXZlID09PSBcInBhdGhcIiA/IGN1cnJlbnQoKS5wYXRobmFtZSA6IGRlc3QuZnJvbSA/PyBjdXJyZW50TWF0Y2goKVsxXSwgdG8sIHRoaXMub3B0aW9ucy50cmFpbGluZ1NsYXNoLCB0aGlzLnJlc29sdmVQYXRoQ2FjaGUpO1xuXHRcdFx0XHRjb25zdCBkZXN0Um91dGUgPSB0aGlzLnJvdXRlc0J5UGF0aFt0cmltUGF0aFJpZ2h0KG5leHRUbyldO1xuXHRcdFx0XHRjb25zdCBpc1RlbXBsYXRlID0gbmV4dFRvLmluY2x1ZGVzKFwiJFwiKTtcblx0XHRcdFx0bGV0IGRlc3RSb3V0ZXM7XG5cdFx0XHRcdGlmIChkZXN0Um91dGUpIGRlc3RSb3V0ZXMgPSBkZXN0Um91dGUuX2JyYW5jaCA/Pz0gYnVpbGRSb3V0ZUJyYW5jaChkZXN0Um91dGUpO1xuXHRcdFx0XHRlbHNlIGlmIChpc1RlbXBsYXRlKSBkZXN0Um91dGVzID0gW107XG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdGNvbnN0IFttYXRjaGVkUm91dGVzLCByYXdQYXJhbXMsIGZvdW5kUm91dGVdID0gdGhpcy5nZXRNYXRjaGVkUm91dGVzKG5leHRUbyk7XG5cdFx0XHRcdFx0ZGVzdFJvdXRlcyA9IG1hdGNoZWRSb3V0ZXM7XG5cdFx0XHRcdFx0aWYgKHRoaXMub3B0aW9ucy5ub3RGb3VuZFJvdXRlICYmICghZm91bmRSb3V0ZSB8fCBmb3VuZFJvdXRlLnBhdGggIT09IFwiL1wiICYmIHJhd1BhcmFtc1tcIioqXCJdKSkgZGVzdFJvdXRlcyA9IFsuLi5kZXN0Um91dGVzLCB0aGlzLm9wdGlvbnMubm90Rm91bmRSb3V0ZV07XG5cdFx0XHRcdH1cblx0XHRcdFx0Y29uc3QgaW50ZXJwb2xhdGlvbiA9IGlzVGVtcGxhdGUgPyBkZXN0Um91dGU/Ll9pbnRlcnBvbGF0aW9uID8/IHBhcnNlU2VnbWVudHMoZmFsc2UsIHsgZnVsbFBhdGg6IG5leHRUbyB9LCAwKSA6IHZvaWQgMDtcblx0XHRcdFx0bGV0IG5leHRQYXJhbXM7XG5cdFx0XHRcdGZvciAoY29uc3Qgcm91dGUgb2YgZGVzdFJvdXRlcykge1xuXHRcdFx0XHRcdGNvbnN0IGZuID0gcm91dGUub3B0aW9ucy5wYXJhbXM/LnN0cmluZ2lmeSA/PyByb3V0ZS5vcHRpb25zLnN0cmluZ2lmeVBhcmFtcztcblx0XHRcdFx0XHRpZiAoZm4pIHtcblx0XHRcdFx0XHRcdGNvbnN0IGZyb21QYXJhbXMgPSBjdXJyZW50TWF0Y2goKVszXTtcblx0XHRcdFx0XHRcdG5leHRQYXJhbXMgPz89IHJlc29sdmVOZXh0UGFyYW1zKGRlc3QucGFyYW1zLCBmcm9tUGFyYW1zKTtcblx0XHRcdFx0XHRcdGlmICghaGFzS2V5cyhuZXh0UGFyYW1zKSkgYnJlYWs7XG5cdFx0XHRcdFx0XHRpZiAobmV4dFBhcmFtcyA9PT0gZnJvbVBhcmFtcykgbmV4dFBhcmFtcyA9IE9iamVjdC5hc3NpZ24oY3JlYXRlTnVsbCgpLCBuZXh0UGFyYW1zKTtcblx0XHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRcdE9iamVjdC5hc3NpZ24obmV4dFBhcmFtcywgZm4obmV4dFBhcmFtcykpO1xuXHRcdFx0XHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRuZXh0UGFyYW1zID8/PSByZXNvbHZlTmV4dFBhcmFtcyhkZXN0LnBhcmFtcywgbmVlZHNJbmhlcml0ZWRQYXJhbXMoZGVzdC5wYXJhbXMsIGludGVycG9sYXRpb24pID8gY3VycmVudE1hdGNoKClbM10gOiBFTVBUWV9SRUNPUkQpO1xuXHRcdFx0XHRjb25zdCBuZXh0UGF0aG5hbWUgPSBvcHRzLmxlYXZlUGFyYW1zID8gbmV4dFRvIDogbm9ybWFsaXplUHJvdG9jb2xSZWxhdGl2ZShkZWNvZGVQYXRoKGludGVycG9sYXRpb24gPyBpbnRlcnBvbGF0ZVBhdGgobmV4dFRvLCBpbnRlcnBvbGF0aW9uLCBuZXh0UGFyYW1zLCB0aGlzLnBhdGhQYXJhbXNEZWNvZGVyKSA6IG5leHRUbykpO1xuXHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGRlc3RSb3V0ZSAmJiAhb3B0cy5sZWF2ZVBhcmFtcykgdHJ5IHtcblx0XHRcdFx0XHRjb25zdCBmb3VuZFJvdXRlID0gdGhpcy5nZXRNYXRjaGVkUm91dGVzKG5leHRQYXRobmFtZSlbMl07XG5cdFx0XHRcdFx0aWYgKGZvdW5kUm91dGU/LmlkICE9PSBkZXN0Um91dGUuaWQpIGNvbnNvbGUud2FybihgR2VuZXJhdGVkIHBhdGggXCIke25leHRQYXRobmFtZX1cIiBmb3Igcm91dGUgXCIke2Rlc3RSb3V0ZS5pZH1cIiBtYXRjaGVkIHJvdXRlIFwiJHtmb3VuZFJvdXRlPy5pZH1cIiBpbnN0ZWFkLiBUaGlzIGNhbiBoYXBwZW4gd2hlbiBtdWx0aXBsZSByb3V0ZSB0ZW1wbGF0ZXMgcmVzb2x2ZSB0byB0aGUgc2FtZSBVUkwuIFVzZSB0aGUgcm91dGUgdGVtcGxhdGUgdGhhdCBtYXRjaGVzIHRoZSBpbnRlbmRlZCByb3V0ZSwgb3IgYWRqdXN0IHBhcmFtcy5zdHJpbmdpZnkgaWYgaXQgY2hhbmdlZCB0aGUgdGFyZ2V0IHBhdGguYCk7XG5cdFx0XHRcdH0gY2F0Y2gge31cblx0XHRcdFx0Y29uc3QgbWlkZGxld2FyZXMgPSBnZXRTZWFyY2hNaWRkbGV3YXJlcyhkZXN0Um91dGVzLCBvcHRzLl9pbmNsdWRlVmFsaWRhdGVTZWFyY2gpO1xuXHRcdFx0XHRjb25zdCBmcm9tU2VhcmNoID0gKCkgPT4ge1xuXHRcdFx0XHRcdGxldCBzZWFyY2ggPSBjdXJyZW50TWF0Y2goKVsyXTtcblx0XHRcdFx0XHRpZiAob3B0cy5faW5jbHVkZVZhbGlkYXRlU2VhcmNoICYmIHRoaXMub3B0aW9ucy5zZWFyY2g/LnN0cmljdCkge1xuXHRcdFx0XHRcdFx0Y29uc3QgdmFsaWRhdGVkU2VhcmNoID0ge307XG5cdFx0XHRcdFx0XHRkZXN0Um91dGVzLmZvckVhY2goKHJvdXRlKSA9PiB7XG5cdFx0XHRcdFx0XHRcdGlmIChyb3V0ZS5vcHRpb25zLnZhbGlkYXRlU2VhcmNoKSB0cnkge1xuXHRcdFx0XHRcdFx0XHRcdE9iamVjdC5hc3NpZ24odmFsaWRhdGVkU2VhcmNoLCB2YWxpZGF0ZVNlYXJjaChyb3V0ZS5vcHRpb25zLnZhbGlkYXRlU2VhcmNoLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHQuLi52YWxpZGF0ZWRTZWFyY2gsXG5cdFx0XHRcdFx0XHRcdFx0XHQuLi5zZWFyY2hcblx0XHRcdFx0XHRcdFx0XHR9KSk7XG5cdFx0XHRcdFx0XHRcdH0gY2F0Y2gge31cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0c2VhcmNoID0gdmFsaWRhdGVkU2VhcmNoO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRyZXR1cm4gc2VhcmNoO1xuXHRcdFx0XHR9O1xuXHRcdFx0XHRjb25zdCBuZXh0U2VhcmNoID0gbWlkZGxld2FyZXMubGVuZ3RoID8gYXBwbHlTZWFyY2hNaWRkbGV3YXJlKG1pZGRsZXdhcmVzLCBmcm9tU2VhcmNoKCksIGRlc3QpIDogZGVzdC5zZWFyY2ggPT09IHRydWUgPyBmcm9tU2VhcmNoKCkgOiB0eXBlb2YgZGVzdC5zZWFyY2ggPT09IFwiZnVuY3Rpb25cIiA/IGRlc3Quc2VhcmNoKGZyb21TZWFyY2goKSkgOiBkZXN0LnNlYXJjaCB8fCBFTVBUWV9SRUNPUkQ7XG5cdFx0XHRcdGNvbnN0IHNlYXJjaFN0ciA9IHRoaXMub3B0aW9ucy5zdHJpbmdpZnlTZWFyY2gobmV4dFNlYXJjaCk7XG5cdFx0XHRcdGNvbnN0IGhhc2ggPSBkZXN0Lmhhc2ggPT09IHRydWUgPyBjdXJyZW50KCkuaGFzaCA6IHR5cGVvZiBkZXN0Lmhhc2ggPT09IFwiZnVuY3Rpb25cIiA/IGRlc3QuaGFzaChjdXJyZW50KCkuaGFzaCkgOiBkZXN0Lmhhc2ggfHwgdm9pZCAwO1xuXHRcdFx0XHRjb25zdCBoYXNoU3RyID0gaGFzaCA/IGAjJHtoYXNofWAgOiBcIlwiO1xuXHRcdFx0XHRjb25zdCBuZXh0U3RhdGUgPSAhZGVzdC5zdGF0ZSA/IEVNUFRZX1JFQ09SRCA6IGRlc3Quc3RhdGUgPT09IHRydWUgPyBjdXJyZW50KCkuc3RhdGUgOiB0eXBlb2YgZGVzdC5zdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gZGVzdC5zdGF0ZShjdXJyZW50KCkuc3RhdGUpIDogZGVzdC5zdGF0ZTtcblx0XHRcdFx0Y29uc3QgZnVsbFBhdGggPSBgJHtuZXh0UGF0aG5hbWV9JHtzZWFyY2hTdHJ9JHtoYXNoU3RyfWA7XG5cdFx0XHRcdGxldCBocmVmO1xuXHRcdFx0XHRsZXQgcHVibGljSHJlZjtcblx0XHRcdFx0bGV0IGV4dGVybmFsID0gZmFsc2U7XG5cdFx0XHRcdGlmICh0aGlzLnJld3JpdGUpIHtcblx0XHRcdFx0XHRjb25zdCB1cmwgPSBuZXcgVVJMKGZ1bGxQYXRoLCB0aGlzLm9yaWdpbik7XG5cdFx0XHRcdFx0Y29uc3Qgb3JpZ2luID0gdXJsLm9yaWdpbjtcblx0XHRcdFx0XHRjb25zdCByZXdyaXR0ZW5VcmwgPSBleGVjdXRlUmV3cml0ZU91dHB1dCh0aGlzLnJld3JpdGUsIHVybCk7XG5cdFx0XHRcdFx0aHJlZiA9IGdldFVybFBhdGgodXJsKTtcblx0XHRcdFx0XHRpZiAoaXNFeHRlcm5hbFVybChyZXdyaXR0ZW5VcmwsIG9yaWdpbikpIHtcblx0XHRcdFx0XHRcdHB1YmxpY0hyZWYgPSByZXdyaXR0ZW5VcmwuaHJlZjtcblx0XHRcdFx0XHRcdGV4dGVybmFsID0gdHJ1ZTtcblx0XHRcdFx0XHR9IGVsc2UgcHVibGljSHJlZiA9IG5vcm1hbGl6ZVByb3RvY29sUmVsYXRpdmUoZ2V0VXJsUGF0aChyZXdyaXR0ZW5VcmwpKTtcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRocmVmID0gZW5jb2RlUGF0aExpa2VVcmwoZnVsbFBhdGgpO1xuXHRcdFx0XHRcdHB1YmxpY0hyZWYgPSBocmVmO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0cHVibGljSHJlZixcblx0XHRcdFx0XHRocmVmLFxuXHRcdFx0XHRcdHBhdGhuYW1lOiBuZXh0UGF0aG5hbWUsXG5cdFx0XHRcdFx0c2VhcmNoOiBuZXh0U2VhcmNoLFxuXHRcdFx0XHRcdHNlYXJjaFN0cixcblx0XHRcdFx0XHRzdGF0ZTogbmV4dFN0YXRlLFxuXHRcdFx0XHRcdGhhc2g6IGhhc2ggPz8gXCJcIixcblx0XHRcdFx0XHRleHRlcm5hbCxcblx0XHRcdFx0XHR1bm1hc2tPblJlbG9hZDogZGVzdC51bm1hc2tPblJlbG9hZFxuXHRcdFx0XHR9O1xuXHRcdFx0fTtcblx0XHRcdGNvbnN0IG5leHQgPSBidWlsZChvcHRzKTtcblx0XHRcdGlmIChvcHRzLm1hc2spIG5leHQubWFza2VkTG9jYXRpb24gPSBidWlsZCh7XG5cdFx0XHRcdGZyb206IG9wdHMuZnJvbSxcblx0XHRcdFx0Li4ub3B0cy5tYXNrXG5cdFx0XHR9KTtcblx0XHRcdGVsc2UgaWYgKHRoaXMub3B0aW9ucy5yb3V0ZU1hc2tzKSB7XG5cdFx0XHRcdGNvbnN0IG1hdGNoID0gZmluZEZsYXRNYXRjaChuZXh0LnBhdGhuYW1lLCB0aGlzLnByb2Nlc3NlZFRyZWUpO1xuXHRcdFx0XHRpZiAobWF0Y2gpIHtcblx0XHRcdFx0XHRjb25zdCBwYXJhbXMgPSBPYmplY3QuYXNzaWduKGNyZWF0ZU51bGwoKSwgbWF0Y2gucmF3UGFyYW1zKTtcblx0XHRcdFx0XHRjb25zdCB7IGZyb206IF9mcm9tLCBwYXJhbXM6IG1hc2tQYXJhbXMsIC4uLm1hc2tQcm9wcyB9ID0gbWF0Y2gucm91dGU7XG5cdFx0XHRcdFx0Y29uc3QgbmV4dFBhcmFtcyA9IHJlc29sdmVOZXh0UGFyYW1zKG1hc2tQYXJhbXMsIHBhcmFtcyk7XG5cdFx0XHRcdFx0bmV4dC5tYXNrZWRMb2NhdGlvbiA9IGJ1aWxkKHtcblx0XHRcdFx0XHRcdGZyb206IG9wdHMuZnJvbSxcblx0XHRcdFx0XHRcdC4uLm1hc2tQcm9wcyxcblx0XHRcdFx0XHRcdHBhcmFtczogbmV4dFBhcmFtc1xuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoIShpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSAmJiAhdXNlZEN1cnJlbnQgJiYgb3B0cy5fZnJvbUxvY2F0aW9uKSB0aGlzLnN0YXRpY0xvY2F0aW9ucy5zZXQob3B0cywgbmV4dCk7XG5cdFx0XHRyZXR1cm4gbmV4dDtcblx0XHR9O1xuXHRcdHRoaXMuY29tbWl0TG9jYXRpb24gPSBhc3luYyAoeyB2aWV3VHJhbnNpdGlvbiwgaWdub3JlQmxvY2tlciwgLi4ubmV4dCB9KSA9PiB7XG5cdFx0XHRpZiAoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikgcmV0dXJuO1xuXHRcdFx0Y29uc3QgbmV4dExvY2F0aW9uID0gbmV4dC5tYXNrZWRMb2NhdGlvbiA/PyBuZXh0O1xuXHRcdFx0aWYgKG5leHRMb2NhdGlvbi5leHRlcm5hbCAmJiAhKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpKSByZXR1cm4gZG9jdW1lbnROYXZpZ2F0aW9uKHRoaXMsIG5leHRMb2NhdGlvbi5wdWJsaWNIcmVmLCB7XG5cdFx0XHRcdHJlcGxhY2U6IG5leHQucmVwbGFjZSxcblx0XHRcdFx0aWdub3JlQmxvY2tlclxuXHRcdFx0fSk7XG5cdFx0XHRsZXQgaGlzdG9yeUFjdGlvbjtcblx0XHRcdGNvbnN0IGlzU2FtZUxvY2F0aW9uID0gdHJpbVBhdGhSaWdodCh0aGlzLmxhdGVzdExvY2F0aW9uLmhyZWYpID09PSB0cmltUGF0aFJpZ2h0KG5leHQuaHJlZikgJiYgZGVlcEVxdWFsKF9nZXRVc2VySGlzdG9yeVN0YXRlKG5leHQuc3RhdGUpLCBfZ2V0VXNlckhpc3RvcnlTdGF0ZSh0aGlzLmxhdGVzdExvY2F0aW9uLnN0YXRlKSk7XG5cdFx0XHRjb25zdCBwcmV2aW91c0NvbW1pdFByb21pc2UgPSB0aGlzLl9jb21taXRQcm9taXNlO1xuXHRcdFx0bGV0IHJlc29sdmU7XG5cdFx0XHRjb25zdCBjb21taXRQcm9taXNlID0gbmV3IFByb21pc2UoKGRvbmUpID0+IHtcblx0XHRcdFx0cmVzb2x2ZSA9IGRvbmU7XG5cdFx0XHR9KTtcblx0XHRcdGNvbW1pdFByb21pc2UucmVzb2x2ZSA9ICgpID0+IHtcblx0XHRcdFx0cmVzb2x2ZSgpO1xuXHRcdFx0XHRwcmV2aW91c0NvbW1pdFByb21pc2U/LnJlc29sdmUoKTtcblx0XHRcdH07XG5cdFx0XHR0aGlzLl9jb21taXRQcm9taXNlID0gY29tbWl0UHJvbWlzZTtcblx0XHRcdGlmIChpc1NhbWVMb2NhdGlvbikgdGhpcy5sb2FkKCk7XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0bGV0IHsgbWFza2VkTG9jYXRpb24sIGhhc2hTY3JvbGxJbnRvVmlldywgLi4ubmV4dEhpc3RvcnkgfSA9IG5leHQ7XG5cdFx0XHRcdGlmIChtYXNrZWRMb2NhdGlvbikge1xuXHRcdFx0XHRcdG5leHRIaXN0b3J5ID0ge1xuXHRcdFx0XHRcdFx0Li4ubWFza2VkTG9jYXRpb24sXG5cdFx0XHRcdFx0XHRzdGF0ZToge1xuXHRcdFx0XHRcdFx0XHQuLi5tYXNrZWRMb2NhdGlvbi5zdGF0ZSxcblx0XHRcdFx0XHRcdFx0X190ZW1wS2V5OiB2b2lkIDAsXG5cdFx0XHRcdFx0XHRcdF9fdGVtcExvY2F0aW9uOiB7XG5cdFx0XHRcdFx0XHRcdFx0Li4ubmV4dEhpc3RvcnksXG5cdFx0XHRcdFx0XHRcdFx0c2VhcmNoOiBuZXh0SGlzdG9yeS5zZWFyY2hTdHIsXG5cdFx0XHRcdFx0XHRcdFx0c3RhdGU6IHtcblx0XHRcdFx0XHRcdFx0XHRcdC4uLm5leHRIaXN0b3J5LnN0YXRlLFxuXHRcdFx0XHRcdFx0XHRcdFx0X190ZW1wS2V5OiB2b2lkIDAsXG5cdFx0XHRcdFx0XHRcdFx0XHRfX3RlbXBMb2NhdGlvbjogdm9pZCAwLFxuXHRcdFx0XHRcdFx0XHRcdFx0X19UU1Jfa2V5OiB2b2lkIDAsXG5cdFx0XHRcdFx0XHRcdFx0XHRrZXk6IHZvaWQgMFxuXHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0aWYgKG5leHRIaXN0b3J5LnVubWFza09uUmVsb2FkID8/IHRoaXMub3B0aW9ucy51bm1hc2tPblJlbG9hZCA/PyBmYWxzZSkgbmV4dEhpc3Rvcnkuc3RhdGUuX190ZW1wS2V5ID0gdGhpcy50ZW1wTG9jYXRpb25LZXk7XG5cdFx0XHRcdH1cblx0XHRcdFx0bmV4dEhpc3Rvcnkuc3RhdGUgPSB7XG5cdFx0XHRcdFx0Li4ubmV4dEhpc3Rvcnkuc3RhdGUsXG5cdFx0XHRcdFx0X19oYXNoU2Nyb2xsSW50b1ZpZXdPcHRpb25zOiBoYXNoU2Nyb2xsSW50b1ZpZXcgPz8gdGhpcy5vcHRpb25zLmRlZmF1bHRIYXNoU2Nyb2xsSW50b1ZpZXcgPz8gdHJ1ZVxuXHRcdFx0XHR9O1xuXHRcdFx0XHR0aGlzLnNob3VsZFZpZXdUcmFuc2l0aW9uID0gdmlld1RyYW5zaXRpb247XG5cdFx0XHRcdGhpc3RvcnlBY3Rpb24gPSBuZXh0LnJlcGxhY2UgPyBcIlJFUExBQ0VcIiA6IFwiUFVTSFwiO1xuXHRcdFx0XHR0aGlzLmhpc3RvcnlbaGlzdG9yeUFjdGlvbiA9PT0gXCJSRVBMQUNFXCIgPyBcInJlcGxhY2VcIiA6IFwicHVzaFwiXShuZXh0SGlzdG9yeS5wdWJsaWNIcmVmLCBuZXh0SGlzdG9yeS5zdGF0ZSwgeyBpZ25vcmVCbG9ja2VyIH0pO1xuXHRcdFx0XHRpZiAoIXRoaXMuaGlzdG9yeS5zdWJzY3JpYmVycy5zaXplKSB0aGlzLmxvYWQoeyBhY3Rpb246IHsgdHlwZTogaGlzdG9yeUFjdGlvbiB9IH0pO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy5fc2Nyb2xsLm4gPSBuZXh0LnJlc2V0U2Nyb2xsID8/IHRydWU7XG5cdFx0XHRyZXR1cm4gdGhpcy5fY29tbWl0UHJvbWlzZTtcblx0XHR9O1xuXHRcdHRoaXMuYnVpbGRBbmRDb21taXRMb2NhdGlvbiA9ICh7IHJlcGxhY2UsIHJlc2V0U2Nyb2xsLCBoYXNoU2Nyb2xsSW50b1ZpZXcsIHZpZXdUcmFuc2l0aW9uLCBpZ25vcmVCbG9ja2VyLCAuLi5yZXN0IH0gPSB7fSkgPT4ge1xuXHRcdFx0aWYgKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcblx0XHRcdGNvbnN0IGxvY2F0aW9uID0gdGhpcy5idWlsZExvY2F0aW9uKHtcblx0XHRcdFx0Li4ucmVzdCxcblx0XHRcdFx0X2luY2x1ZGVWYWxpZGF0ZVNlYXJjaDogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0XHR0aGlzLl9wZW5kaW5nTG9jYXRpb24gPSBsb2NhdGlvbjtcblx0XHRcdGNvbnN0IGNvbW1pdFByb21pc2UgPSB0aGlzLmNvbW1pdExvY2F0aW9uKHtcblx0XHRcdFx0Li4ubG9jYXRpb24sXG5cdFx0XHRcdHZpZXdUcmFuc2l0aW9uLFxuXHRcdFx0XHRyZXBsYWNlLFxuXHRcdFx0XHRyZXNldFNjcm9sbCxcblx0XHRcdFx0aGFzaFNjcm9sbEludG9WaWV3LFxuXHRcdFx0XHRpZ25vcmVCbG9ja2VyXG5cdFx0XHR9KTtcblx0XHRcdHF1ZXVlTWljcm90YXNrKCgpID0+IHtcblx0XHRcdFx0aWYgKHRoaXMuX3BlbmRpbmdMb2NhdGlvbiA9PT0gbG9jYXRpb24pIHRoaXMuX3BlbmRpbmdMb2NhdGlvbiA9IHZvaWQgMDtcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIGNvbW1pdFByb21pc2U7XG5cdFx0fTtcblx0XHR0aGlzLm5hdmlnYXRlID0gYXN5bmMgKHsgdG8sIHJlbG9hZERvY3VtZW50LCBocmVmLCBwdWJsaWNIcmVmLCAuLi5yZXN0IH0pID0+IHtcblx0XHRcdGlmIChpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSByZXR1cm47XG5cdFx0XHRjb25zdCBocmVmU2NoZW1lID0gaHJlZiA/IGdldFVybFNjaGVtZShocmVmKSA6IHZvaWQgMDtcblx0XHRcdGlmIChocmVmU2NoZW1lIHx8IHJlbG9hZERvY3VtZW50KSB7XG5cdFx0XHRcdGlmICh0byAhPT0gdm9pZCAwIHx8ICFocmVmKSB7XG5cdFx0XHRcdFx0Y29uc3QgbG9jYXRpb24gPSB0aGlzLmJ1aWxkTG9jYXRpb24oe1xuXHRcdFx0XHRcdFx0dG8sXG5cdFx0XHRcdFx0XHQuLi5yZXN0XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0Y29uc3QgcHVibGljTG9jYXRpb24gPSBsb2NhdGlvbi5tYXNrZWRMb2NhdGlvbiA/PyBsb2NhdGlvbjtcblx0XHRcdFx0XHRocmVmID8/PSBwdWJsaWNMb2NhdGlvbi5wdWJsaWNIcmVmO1xuXHRcdFx0XHRcdHB1YmxpY0hyZWYgPz89IHB1YmxpY0xvY2F0aW9uLnB1YmxpY0hyZWY7XG5cdFx0XHRcdH1cblx0XHRcdFx0Y29uc3QgcmVsb2FkSHJlZiA9ICFocmVmU2NoZW1lICYmIHB1YmxpY0hyZWYgPyBwdWJsaWNIcmVmIDogaHJlZjtcblx0XHRcdFx0cmV0dXJuIGRvY3VtZW50TmF2aWdhdGlvbih0aGlzLCByZWxvYWRIcmVmLCByZXN0KTtcblx0XHRcdH1cblx0XHRcdHJldHVybiB0aGlzLmJ1aWxkQW5kQ29tbWl0TG9jYXRpb24oe1xuXHRcdFx0XHQuLi5yZXN0LFxuXHRcdFx0XHRocmVmLFxuXHRcdFx0XHR0byxcblx0XHRcdFx0X2lzTmF2aWdhdGU6IHRydWVcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy5sb2FkID0gYXN5bmMgKG9wdHMpID0+IHtcblx0XHRcdGlmIChpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSByZXR1cm4gbG9hZFNlcnZlclJvdXRlKHRoaXMsIG9wdHMpO1xuXHRcdFx0dGhpcy51cGRhdGVMYXRlc3RMb2NhdGlvbigpO1xuXHRcdFx0aWYgKG9wdHM/LmFjdGlvbikgdGhpcy5fc2Nyb2xsLmggPSBvcHRzLmFjdGlvbi50eXBlID09PSBcIlBVU0hcIiB8fCBvcHRzLmFjdGlvbi50eXBlID09PSBcIlJFUExBQ0VcIjtcblx0XHRcdGF3YWl0IGxvYWRDbGllbnRSb3V0ZSh0aGlzLCBvcHRzKTtcblx0XHR9O1xuXHRcdHRoaXMuc3RhcnRWaWV3VHJhbnNpdGlvbiA9IChmbikgPT4ge1xuXHRcdFx0Y29uc3Qgc2hvdWxkVmlld1RyYW5zaXRpb24gPSB0aGlzLnNob3VsZFZpZXdUcmFuc2l0aW9uID8/IHRoaXMub3B0aW9ucy5kZWZhdWx0Vmlld1RyYW5zaXRpb247XG5cdFx0XHR0aGlzLnNob3VsZFZpZXdUcmFuc2l0aW9uID0gdm9pZCAwO1xuXHRcdFx0aWYgKHNob3VsZFZpZXdUcmFuc2l0aW9uICYmICEoaXNTZXJ2ZXIgPz8gdHlwZW9mIGRvY3VtZW50ID09PSBcInVuZGVmaW5lZFwiKSAmJiB0eXBlb2YgZG9jdW1lbnQuc3RhcnRWaWV3VHJhbnNpdGlvbiA9PT0gXCJmdW5jdGlvblwiKSB7XG5cdFx0XHRcdGxldCBzdGFydFZpZXdUcmFuc2l0aW9uUGFyYW1zO1xuXHRcdFx0XHRpZiAodHlwZW9mIHNob3VsZFZpZXdUcmFuc2l0aW9uID09PSBcIm9iamVjdFwiICYmIHdpbmRvdy5DU1M/LnN1cHBvcnRzPy4oXCJzZWxlY3Rvcig6YWN0aXZlLXZpZXctdHJhbnNpdGlvbi10eXBlKGEpKVwiKSkge1xuXHRcdFx0XHRcdGNvbnN0IG5leHQgPSB0aGlzLmxhdGVzdExvY2F0aW9uO1xuXHRcdFx0XHRcdGNvbnN0IHByZXZMb2NhdGlvbiA9IHRoaXMuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uZ2V0KCk7XG5cdFx0XHRcdFx0Y29uc3QgcmVzb2x2ZWRWaWV3VHJhbnNpdGlvblR5cGVzID0gdHlwZW9mIHNob3VsZFZpZXdUcmFuc2l0aW9uLnR5cGVzID09PSBcImZ1bmN0aW9uXCIgPyBzaG91bGRWaWV3VHJhbnNpdGlvbi50eXBlcyhnZXRMb2NhdGlvbkNoYW5nZUluZm8obmV4dCwgcHJldkxvY2F0aW9uKSkgOiBzaG91bGRWaWV3VHJhbnNpdGlvbi50eXBlcztcblx0XHRcdFx0XHRpZiAocmVzb2x2ZWRWaWV3VHJhbnNpdGlvblR5cGVzID09PSBmYWxzZSkgcmV0dXJuIGZuKCk7XG5cdFx0XHRcdFx0c3RhcnRWaWV3VHJhbnNpdGlvblBhcmFtcyA9IHtcblx0XHRcdFx0XHRcdHVwZGF0ZTogZm4sXG5cdFx0XHRcdFx0XHR0eXBlczogcmVzb2x2ZWRWaWV3VHJhbnNpdGlvblR5cGVzXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0fSBlbHNlIHN0YXJ0Vmlld1RyYW5zaXRpb25QYXJhbXMgPSBmbjtcblx0XHRcdFx0cmV0dXJuIGRvY3VtZW50LnN0YXJ0Vmlld1RyYW5zaXRpb24oc3RhcnRWaWV3VHJhbnNpdGlvblBhcmFtcykudXBkYXRlQ2FsbGJhY2tEb25lO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGZuKCk7XG5cdFx0fTtcblx0XHR0aGlzLmludmFsaWRhdGUgPSAob3B0cykgPT4ge1xuXHRcdFx0Y29uc3QgY29tbWl0dGVkTWF0Y2hlcyA9IHRoaXMuX2NvbW1pdHRlZDtcblx0XHRcdGNvbnN0IGZpbHRlciA9IG9wdHM/LmZpbHRlcjtcblx0XHRcdGNvbnN0IHByZWxvYWRzID0gdGhpcy5fcHJlbG9hZHM7XG5cdFx0XHRjb25zdCBpbnZhbGlkSWRzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHRcdGNvbnN0IGNvbnNpZGVyID0gKG1hdGNoKSA9PiB7XG5cdFx0XHRcdGlmICghZmlsdGVyIHx8IGZpbHRlcihtYXRjaCkpIGludmFsaWRJZHMuYWRkKG1hdGNoLmlkKTtcblx0XHRcdH07XG5cdFx0XHRjb21taXR0ZWRNYXRjaGVzLmZvckVhY2goY29uc2lkZXIpO1xuXHRcdFx0dGhpcy5fY2FjaGUuZm9yRWFjaChjb25zaWRlcik7XG5cdFx0XHRwcmVsb2Fkcz8uZm9yRWFjaCgobWF0Y2hlcykgPT4gbWF0Y2hlcy5mb3JFYWNoKGNvbnNpZGVyKSk7XG5cdFx0XHR0aGlzLl90eD8uWzNdLmZvckVhY2goY29uc2lkZXIpO1xuXHRcdFx0Y29uc3QgYWJvcnQgPSBbXTtcblx0XHRcdGZvciAoY29uc3QgW2NvbnRyb2xsZXIsIG1hdGNoZXNdIG9mIHByZWxvYWRzID8/IFtdKSBpZiAobWF0Y2hlcy5zb21lKChtYXRjaCkgPT4gaW52YWxpZElkcy5oYXMobWF0Y2guaWQpKSkge1xuXHRcdFx0XHRwcmVsb2Fkcy5kZWxldGUoY29udHJvbGxlcik7XG5cdFx0XHRcdGFib3J0LnB1c2goY29udHJvbGxlcik7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBpbnZhbGlkYXRlID0gKGQpID0+IHtcblx0XHRcdFx0aWYgKGludmFsaWRJZHMuaGFzKGQuaWQpKSB7XG5cdFx0XHRcdFx0Y29uc3Qgcm91dGUgPSB0aGlzLnJvdXRlc0J5SWRbZC5yb3V0ZUlkXTtcblx0XHRcdFx0XHRjb25zdCBuZXh0ID0ge1xuXHRcdFx0XHRcdFx0Li4uZCxcblx0XHRcdFx0XHRcdGludmFsaWQ6IHRydWUsXG5cdFx0XHRcdFx0XHQuLi4ob3B0cz8uZm9yY2VQZW5kaW5nIHx8IGQuc3RhdHVzID09PSBcImVycm9yXCIgfHwgZC5zdGF0dXMgPT09IFwibm90Rm91bmRcIikgJiYgcm91dGVOZWVkc0xvYWQocm91dGUpID8ge1xuXHRcdFx0XHRcdFx0XHRzdGF0dXM6IFwicGVuZGluZ1wiLFxuXHRcdFx0XHRcdFx0XHRlcnJvcjogdm9pZCAwXG5cdFx0XHRcdFx0XHR9IDogdm9pZCAwXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRkLl9mbGlnaHQgPSB2b2lkIDA7XG5cdFx0XHRcdFx0cmV0dXJuIG5leHQ7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIGQ7XG5cdFx0XHR9O1xuXHRcdFx0dGhpcy5fY29tbWl0dGVkID0gY29tbWl0dGVkTWF0Y2hlcy5tYXAoaW52YWxpZGF0ZSk7XG5cdFx0XHRmb3IgKGNvbnN0IFtpZCwgbWF0Y2hdIG9mIHRoaXMuX2NhY2hlKSBpZiAoaW52YWxpZElkcy5oYXMoaWQpKSB7XG5cdFx0XHRcdG1hdGNoLmludmFsaWQgPSB0cnVlO1xuXHRcdFx0XHRpZiAob3B0cz8uZm9yY2VQZW5kaW5nKSBtYXRjaC5zdGF0dXMgPSBcInBlbmRpbmdcIjtcblx0XHRcdH1cblx0XHRcdGZvciAoY29uc3QgaWQgb2YgaW52YWxpZElkcykge1xuXHRcdFx0XHRjb25zdCBmbGlnaHQgPSB0aGlzLl9mbGlnaHRzPy5nZXQoaWQpO1xuXHRcdFx0XHR0aGlzLl9mbGlnaHRzPy5kZWxldGUoaWQpO1xuXHRcdFx0XHRpZiAoZmxpZ2h0ICYmICFmbGlnaHRbMl0pIGFib3J0LnB1c2goZmxpZ2h0WzFdKTtcblx0XHRcdH1cblx0XHRcdGZvciAoY29uc3QgY29udHJvbGxlciBvZiBhYm9ydCkgY29udHJvbGxlci5hYm9ydCgpO1xuXHRcdFx0dGhpcy5zaG91bGRWaWV3VHJhbnNpdGlvbiA9IGZhbHNlO1xuXHRcdFx0cmV0dXJuIHRoaXMubG9hZCh7IHN5bmM6IG9wdHM/LnN5bmMgfSk7XG5cdFx0fTtcblx0XHR0aGlzLnJlc29sdmVSZWRpcmVjdCA9IChyZWRpcmVjdCkgPT4ge1xuXHRcdFx0Y29uc3Qgb3B0aW9ucyA9IHJlZGlyZWN0Lm9wdGlvbnM7XG5cdFx0XHRsZXQgaHJlZiA9IHJlZGlyZWN0LmhlYWRlcnMuZ2V0KFwiTG9jYXRpb25cIikgfHwgb3B0aW9ucy5ocmVmO1xuXHRcdFx0aWYgKCFocmVmKSB7XG5cdFx0XHRcdGNvbnN0IGxvY2F0aW9uID0gdGhpcy5idWlsZExvY2F0aW9uKG9wdGlvbnMpO1xuXHRcdFx0XHRocmVmID0gKGxvY2F0aW9uLm1hc2tlZExvY2F0aW9uID8/IGxvY2F0aW9uKS5wdWJsaWNIcmVmIHx8IFwiL1wiO1xuXHRcdFx0fVxuXHRcdFx0bGV0IHNjaGVtZTtcblx0XHRcdGlmIChwcm90b2NvbFJlbGF0aXZlUHJlZml4UmVnZXgudGVzdChocmVmKSB8fCAoc2NoZW1lID0gZ2V0VXJsU2NoZW1lKGhyZWYpKSAmJiAhdGhpcy5wcm90b2NvbEFsbG93bGlzdC5oYXMoc2NoZW1lKSkgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IGBSZWRpcmVjdCBibG9ja2VkOiB1bnNhZmUgcHJvdG9jb2wgaW4gaHJlZiBcIiR7aHJlZn1cIi4gQWxsb3dlZCBwcm90b2NvbHM6ICR7QXJyYXkuZnJvbSh0aGlzLnByb3RvY29sQWxsb3dsaXN0KS5qb2luKFwiLCBcIil9LmAgOiBcIlJlZGlyZWN0IGJsb2NrZWQ6IHVuc2FmZSBwcm90b2NvbFwiKTtcblx0XHRcdGlmIChzY2hlbWUgPT09IFwiaHR0cDpcIiB8fCBzY2hlbWUgPT09IFwiaHR0cHM6XCIpIHtcblx0XHRcdFx0Y29uc3QgdXJsID0gbmV3IFVSTChocmVmKTtcblx0XHRcdFx0aWYgKHVybC5wYXRobmFtZS5zdGFydHNXaXRoKFwiLy9cIikpIGhyZWYgPSB1cmwuaHJlZjtcblx0XHRcdFx0ZWxzZSBpZiAoIWlzRXh0ZXJuYWxVcmwodXJsLCB0aGlzLm9yaWdpbikpIHtcblx0XHRcdFx0XHRocmVmID0gZ2V0VXJsUGF0aCh1cmwpO1xuXHRcdFx0XHRcdHNjaGVtZSA9IHZvaWQgMDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKHNjaGVtZSkgb3B0aW9ucy5yZWxvYWREb2N1bWVudCA9IHRydWU7XG5cdFx0XHRvcHRpb25zLmhyZWYgPSBocmVmO1xuXHRcdFx0cmVkaXJlY3QuaGVhZGVycy5zZXQoXCJMb2NhdGlvblwiLCBocmVmKTtcblx0XHRcdHJldHVybiByZWRpcmVjdDtcblx0XHR9O1xuXHRcdHRoaXMuY2xlYXJDYWNoZSA9IChvcHRzKSA9PiB7XG5cdFx0XHRjb25zdCBjYWNoZWQgPSB0aGlzLl9jYWNoZTtcblx0XHRcdGNvbnN0IHByZWxvYWRzID0gdGhpcy5fcHJlbG9hZHM7XG5cdFx0XHRjb25zdCBmaWx0ZXIgPSBvcHRzPy5maWx0ZXI7XG5cdFx0XHRjb25zdCBkaXNjYXJkZWQgPSBbXTtcblx0XHRcdGNvbnN0IGRpc2NhcmRlZElkcyA9IFtdO1xuXHRcdFx0Zm9yIChjb25zdCBbaWQsIG1hdGNoXSBvZiBjYWNoZWQpIGlmICghZmlsdGVyIHx8IGZpbHRlcihtYXRjaCkpIHtcblx0XHRcdFx0ZGlzY2FyZGVkSWRzLnB1c2goaWQpO1xuXHRcdFx0XHRkaXNjYXJkZWQucHVzaChtYXRjaCk7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBhYm9ydCA9IFtdO1xuXHRcdFx0Zm9yIChjb25zdCBbY29udHJvbGxlciwgbWF0Y2hlc10gb2YgcHJlbG9hZHMgPz8gW10pIGlmICghZmlsdGVyIHx8IG1hdGNoZXMuc29tZShmaWx0ZXIpKSB7XG5cdFx0XHRcdGFib3J0LnB1c2goY29udHJvbGxlcik7XG5cdFx0XHRcdGRpc2NhcmRlZC5wdXNoKC4uLm1hdGNoZXMpO1xuXHRcdFx0fVxuXHRcdFx0Zm9yIChjb25zdCBpZCBvZiBkaXNjYXJkZWRJZHMpIGNhY2hlZC5kZWxldGUoaWQpO1xuXHRcdFx0Zm9yIChjb25zdCBjb250cm9sbGVyIG9mIGFib3J0KSBwcmVsb2Fkcy5kZWxldGUoY29udHJvbGxlcik7XG5cdFx0XHRmb3IgKGNvbnN0IG1hdGNoIG9mIGRpc2NhcmRlZCkge1xuXHRcdFx0XHRjb25zdCBmbGlnaHQgPSBtYXRjaC5fZmxpZ2h0O1xuXHRcdFx0XHRtYXRjaC5fZmxpZ2h0ID0gdm9pZCAwO1xuXHRcdFx0XHRpZiAoZmxpZ2h0ICYmICEtLWZsaWdodFsyXSkge1xuXHRcdFx0XHRcdGlmICh0aGlzLl9mbGlnaHRzPy5nZXQobWF0Y2guaWQpID09PSBmbGlnaHQpIHRoaXMuX2ZsaWdodHMuZGVsZXRlKG1hdGNoLmlkKTtcblx0XHRcdFx0XHRhYm9ydC5wdXNoKGZsaWdodFsxXSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGZvciAoY29uc3QgY29udHJvbGxlciBvZiBhYm9ydCkgY29udHJvbGxlci5hYm9ydCgpO1xuXHRcdH07XG5cdFx0dGhpcy5sb2FkUm91dGVDaHVuayA9IGxvYWRSb3V0ZUNodW5rO1xuXHRcdHRoaXMucHJlbG9hZFJvdXRlID0gKG9wdHMpID0+IHByZWxvYWRDbGllbnRSb3V0ZSh0aGlzLCBvcHRzKTtcblx0XHR0aGlzLm1hdGNoUm91dGUgPSAobG9jYXRpb24sIG9wdHMpID0+IHtcblx0XHRcdGNvbnN0IG1hdGNoTG9jYXRpb24gPSB7XG5cdFx0XHRcdC4uLmxvY2F0aW9uLFxuXHRcdFx0XHR0bzogbG9jYXRpb24udG8gPyByZXNvbHZlUGF0aChsb2NhdGlvbi5mcm9tIHx8IFwiXCIsIGxvY2F0aW9uLnRvLCB0aGlzLm9wdGlvbnMudHJhaWxpbmdTbGFzaCwgdGhpcy5yZXNvbHZlUGF0aENhY2hlKSA6IHZvaWQgMCxcblx0XHRcdFx0cGFyYW1zOiBsb2NhdGlvbi5wYXJhbXMgfHwge30sXG5cdFx0XHRcdGxlYXZlUGFyYW1zOiB0cnVlXG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgbmV4dCA9IHRoaXMuYnVpbGRMb2NhdGlvbihtYXRjaExvY2F0aW9uKTtcblx0XHRcdGNvbnN0IGlzUGVuZGluZyA9IHRoaXMuc3RvcmVzLnN0YXR1cy5nZXQoKSA9PT0gXCJwZW5kaW5nXCI7XG5cdFx0XHRpZiAob3B0cz8ucGVuZGluZyAmJiAhaXNQZW5kaW5nKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRjb25zdCBiYXNlTG9jYXRpb24gPSBvcHRzPy5wZW5kaW5nID8/ICFpc1BlbmRpbmcgPyB0aGlzLmxhdGVzdExvY2F0aW9uIDogdGhpcy5zdG9yZXMucmVzb2x2ZWRMb2NhdGlvbi5nZXQoKSB8fCB0aGlzLnN0b3Jlcy5sb2NhdGlvbi5nZXQoKTtcblx0XHRcdGNvbnN0IG1hdGNoID0gZmluZFNpbmdsZU1hdGNoKG5leHQucGF0aG5hbWUsIG9wdHM/LmNhc2VTZW5zaXRpdmUgPz8gZmFsc2UsIG9wdHM/LmZ1enp5ID8/IGZhbHNlLCBiYXNlTG9jYXRpb24ucGF0aG5hbWUsIHRoaXMucHJvY2Vzc2VkVHJlZSk7XG5cdFx0XHRpZiAoIW1hdGNoKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRpZiAobG9jYXRpb24ucGFyYW1zKSB7XG5cdFx0XHRcdGlmICghZGVlcEVxdWFsKG1hdGNoLnJhd1BhcmFtcywgbG9jYXRpb24ucGFyYW1zLCB0cnVlKSkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0fVxuXHRcdFx0aWYgKG9wdHM/LmluY2x1ZGVTZWFyY2ggPz8gdHJ1ZSkgcmV0dXJuIGRlZXBFcXVhbChiYXNlTG9jYXRpb24uc2VhcmNoLCBuZXh0LnNlYXJjaCwgdHJ1ZSkgPyBtYXRjaC5yYXdQYXJhbXMgOiBmYWxzZTtcblx0XHRcdHJldHVybiBtYXRjaC5yYXdQYXJhbXM7XG5cdFx0fTtcblx0XHR0aGlzLmdldFN0b3JlQ29uZmlnID0gZ2V0U3RvcmVDb25maWc7XG5cdFx0aWYgKG9wdGlvbnMucGF0aFBhcmFtc0FsbG93ZWRDaGFyYWN0ZXJzPy5sZW5ndGgpIHRoaXMucGF0aFBhcmFtc0RlY29kZXIgPSBjb21waWxlRGVjb2RlQ2hhck1hcChvcHRpb25zLnBhdGhQYXJhbXNBbGxvd2VkQ2hhcmFjdGVycyk7XG5cdFx0dGhpcy51cGRhdGUoe1xuXHRcdFx0ZGVmYXVsdFByZWxvYWREZWxheTogNTAsXG5cdFx0XHRkZWZhdWx0UGVuZGluZ01zOiAxZTMsXG5cdFx0XHRkZWZhdWx0UGVuZGluZ01pbk1zOiA1MDAsXG5cdFx0XHRjb250ZXh0OiB2b2lkIDAsXG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0Y2FzZVNlbnNpdGl2ZTogb3B0aW9ucy5jYXNlU2Vuc2l0aXZlID8/IGZhbHNlLFxuXHRcdFx0bm90Rm91bmRNb2RlOiBvcHRpb25zLm5vdEZvdW5kTW9kZSA/PyBcImZ1enp5XCIsXG5cdFx0XHRzdHJpbmdpZnlTZWFyY2g6IG9wdGlvbnMuc3RyaW5naWZ5U2VhcmNoID8/IGRlZmF1bHRTdHJpbmdpZnlTZWFyY2gsXG5cdFx0XHRwYXJzZVNlYXJjaDogb3B0aW9ucy5wYXJzZVNlYXJjaCA/PyBkZWZhdWx0UGFyc2VTZWFyY2gsXG5cdFx0XHRwcm90b2NvbEFsbG93bGlzdDogb3B0aW9ucy5wcm90b2NvbEFsbG93bGlzdCA/PyBERUZBVUxUX1BST1RPQ09MX0FMTE9XTElTVFxuXHRcdH0pO1xuXHRcdGlmICghKGlzU2VydmVyID8/IHR5cGVvZiBkb2N1bWVudCA9PT0gXCJ1bmRlZmluZWRcIikpIHNlbGYuX19UU1JfUk9VVEVSX18gPSB0aGlzO1xuXHR9XG5cdGlzU2hlbGwoKSB7XG5cdFx0cmV0dXJuICEhdGhpcy5vcHRpb25zLmlzU2hlbGw7XG5cdH1cblx0Z2V0IHN0YXRlKCkge1xuXHRcdHJldHVybiB0aGlzLnN0b3Jlcy5fX3N0b3JlLmdldCgpO1xuXHR9XG5cdHNldFJvdXRlcyhjYWNoZXMpIHtcblx0XHRPYmplY3QuYXNzaWduKHRoaXMsIGNhY2hlcyk7XG5cdFx0dGhpcy5saWdodHdlaWdodENhY2hlID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5cdFx0aWYgKCEoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikpIHRoaXMuc3RhdGljTG9jYXRpb25zID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5cdFx0Y29uc3Qgbm90Rm91bmRSb3V0ZSA9IHRoaXMub3B0aW9ucy5ub3RGb3VuZFJvdXRlO1xuXHRcdGlmIChub3RGb3VuZFJvdXRlKSB7XG5cdFx0XHRub3RGb3VuZFJvdXRlLmluaXQoOTk5OTk5OTk5OTkpO1xuXHRcdFx0aWYgKHRoaXMucm91dGVzQnlJZFtub3RGb3VuZFJvdXRlLmlkXSAhPT0gbm90Rm91bmRSb3V0ZSkgbm90Rm91bmRSb3V0ZS5faW50ZXJwb2xhdGlvbiA9IHBhcnNlU2VnbWVudHMoZmFsc2UsIG5vdEZvdW5kUm91dGUsIDApO1xuXHRcdFx0dGhpcy5yb3V0ZXNCeUlkW25vdEZvdW5kUm91dGUuaWRdID0gbm90Rm91bmRSb3V0ZTtcblx0XHR9XG5cdH1cblx0bWF0Y2hSb3V0ZXNJbnRlcm5hbChuZXh0LCBvcHRzKSB7XG5cdFx0Y29uc3QgW2luaXRpYWxNYXRjaGVkUm91dGVzLCByYXdQYXJhbXMsIGZvdW5kUm91dGVdID0gdGhpcy5nZXRNYXRjaGVkUm91dGVzKG5leHQucGF0aG5hbWUpO1xuXHRcdGxldCBtYXRjaGVkUm91dGVzID0gaW5pdGlhbE1hdGNoZWRSb3V0ZXM7XG5cdFx0bGV0IGlzR2xvYmFsTm90Rm91bmQgPSBmYWxzZTtcblx0XHRpZiAoZm91bmRSb3V0ZSA/IGZvdW5kUm91dGUucGF0aCAhPT0gXCIvXCIgJiYgcmF3UGFyYW1zW1wiKipcIl0gOiB0cmltUGF0aFJpZ2h0KG5leHQucGF0aG5hbWUpKSB7XG5cdFx0XHRpZiAodGhpcy5vcHRpb25zLm5vdEZvdW5kUm91dGUpIG1hdGNoZWRSb3V0ZXMgPSBbLi4ubWF0Y2hlZFJvdXRlcywgdGhpcy5vcHRpb25zLm5vdEZvdW5kUm91dGVdO1xuXHRcdFx0ZWxzZSBpc0dsb2JhbE5vdEZvdW5kID0gdHJ1ZTtcblx0XHR9XG5cdFx0Y29uc3QgX25vdEZvdW5kUm91dGVJZCA9IGlzR2xvYmFsTm90Rm91bmQgPyBmaW5kR2xvYmFsTm90Rm91bmRSb3V0ZUlkKHRoaXMub3B0aW9ucy5ub3RGb3VuZE1vZGUsIG1hdGNoZWRSb3V0ZXMpIDogdm9pZCAwO1xuXHRcdGNvbnN0IG1hdGNoZXMgPSBuZXcgQXJyYXkobWF0Y2hlZFJvdXRlcy5sZW5ndGgpO1xuXHRcdGNvbnN0IGNvbW1pdHRlZCA9IHRoaXMuX2NvbW1pdHRlZDtcblx0XHRjb25zdCBwcmV2aW91c0F0ID0gKHJvdXRlLCBpbmRleCkgPT4ge1xuXHRcdFx0Y29uc3QgbWF0Y2ggPSBjb21taXR0ZWRbaW5kZXhdO1xuXHRcdFx0cmV0dXJuIG1hdGNoPy5yb3V0ZUlkID09PSByb3V0ZS5pZCA/IG1hdGNoIDogcm91dGUgPT09IHRoaXMub3B0aW9ucy5ub3RGb3VuZFJvdXRlID8gY29tbWl0dGVkLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLnJvdXRlSWQgPT09IHJvdXRlLmlkKSA6IHZvaWQgMDtcblx0XHR9O1xuXHRcdGxldCBzdHJpY3RQYXJhbXM7XG5cdFx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IG1hdGNoZWRSb3V0ZXMubGVuZ3RoOyBpbmRleCsrKSB7XG5cdFx0XHRjb25zdCByb3V0ZSA9IG1hdGNoZWRSb3V0ZXNbaW5kZXhdO1xuXHRcdFx0Y29uc3QgcGFyZW50TWF0Y2ggPSBtYXRjaGVzW2luZGV4IC0gMV07XG5cdFx0XHRsZXQgcHJlTWF0Y2hTZWFyY2g7XG5cdFx0XHRsZXQgc3RyaWN0TWF0Y2hTZWFyY2g7XG5cdFx0XHRsZXQgc2VhcmNoRXJyb3I7XG5cdFx0XHR7XG5cdFx0XHRcdGNvbnN0IHBhcmVudFNlYXJjaCA9IHBhcmVudE1hdGNoPy5zZWFyY2ggPz8gbmV4dC5zZWFyY2g7XG5cdFx0XHRcdGNvbnN0IHBhcmVudFN0cmljdFNlYXJjaCA9IHBhcmVudE1hdGNoPy5fc3RyaWN0U2VhcmNoID8/IHZvaWQgMDtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRjb25zdCBzdHJpY3RTZWFyY2ggPSB2YWxpZGF0ZVNlYXJjaChyb3V0ZS5vcHRpb25zLnZhbGlkYXRlU2VhcmNoLCB7IC4uLnBhcmVudFNlYXJjaCB9KSA/PyB2b2lkIDA7XG5cdFx0XHRcdFx0cHJlTWF0Y2hTZWFyY2ggPSB7XG5cdFx0XHRcdFx0XHQuLi5wYXJlbnRTZWFyY2gsXG5cdFx0XHRcdFx0XHQuLi5zdHJpY3RTZWFyY2hcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdHN0cmljdE1hdGNoU2VhcmNoID0ge1xuXHRcdFx0XHRcdFx0Li4ucGFyZW50U3RyaWN0U2VhcmNoLFxuXHRcdFx0XHRcdFx0Li4uc3RyaWN0U2VhcmNoXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdFx0bGV0IHNlYXJjaFBhcmFtRXJyb3IgPSBlcnI7XG5cdFx0XHRcdFx0aWYgKCEoZXJyIGluc3RhbmNlb2YgU2VhcmNoUGFyYW1FcnJvcikpIHNlYXJjaFBhcmFtRXJyb3IgPSBuZXcgU2VhcmNoUGFyYW1FcnJvcihlcnIubWVzc2FnZSwgeyBjYXVzZTogZXJyIH0pO1xuXHRcdFx0XHRcdGlmIChvcHRzPy50aHJvd09uRXJyb3IpIHRocm93IHNlYXJjaFBhcmFtRXJyb3I7XG5cdFx0XHRcdFx0cHJlTWF0Y2hTZWFyY2ggPSBwYXJlbnRTZWFyY2g7XG5cdFx0XHRcdFx0c3RyaWN0TWF0Y2hTZWFyY2ggPSB7fTtcblx0XHRcdFx0XHRzZWFyY2hFcnJvciA9IHNlYXJjaFBhcmFtRXJyb3I7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGxldCBsb2FkZXJEZXBzID0gXCJcIjtcblx0XHRcdGxldCBsb2FkZXJEZXBzSGFzaCA9IFwiXCI7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRsb2FkZXJEZXBzID0gcm91dGUub3B0aW9ucy5sb2FkZXJEZXBzPy4oeyBzZWFyY2g6IHByZU1hdGNoU2VhcmNoIH0pID8/IFwiXCI7XG5cdFx0XHRcdGxvYWRlckRlcHNIYXNoID0gbG9hZGVyRGVwcyA/IEpTT04uc3RyaW5naWZ5KGxvYWRlckRlcHMpIHx8IFwiXCIgOiBcIlwiO1xuXHRcdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdFx0aWYgKG9wdHM/LnRocm93T25FcnJvcikgdGhyb3cgY2F1c2U7XG5cdFx0XHRcdHNlYXJjaEVycm9yID8/PSBjYXVzZTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHVzZWRQYXJhbXMgPSBjcmVhdGVOdWxsKCk7XG5cdFx0XHRjb25zdCBpbnRlcnBvbGF0ZWRQYXRoID0gcm91dGUuX2ludGVycG9sYXRpb24gPyBpbnRlcnBvbGF0ZVBhdGgocm91dGUuZnVsbFBhdGgsIHJvdXRlLl9pbnRlcnBvbGF0aW9uLCByYXdQYXJhbXMsIHRoaXMucGF0aFBhcmFtc0RlY29kZXIsIHVzZWRQYXJhbXMpIDogcm91dGUuZnVsbFBhdGg7XG5cdFx0XHRjb25zdCBtYXRjaElkID0gcm91dGUuaWQgKyBpbnRlcnBvbGF0ZWRQYXRoICsgbG9hZGVyRGVwc0hhc2g7XG5cdFx0XHRjb25zdCBwcmV2aW91c01hdGNoID0gcHJldmlvdXNBdChyb3V0ZSwgaW5kZXgpO1xuXHRcdFx0Y29uc3QgZXhpc3RpbmdNYXRjaCA9IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBvcHRzPy5fcmVtYXRlcmlhbGl6ZSA/IHZvaWQgMCA6IHRoaXMuX2NhY2hlLmdldChtYXRjaElkKSA/PyAocHJldmlvdXNNYXRjaD8uaWQgPT09IG1hdGNoSWQgPyBwcmV2aW91c01hdGNoIDogdm9pZCAwKTtcblx0XHRcdHN0cmljdFBhcmFtcyA9IGV4aXN0aW5nTWF0Y2g/Ll9zdHJpY3RQYXJhbXMgPz8gT2JqZWN0LmFzc2lnbih1c2VkUGFyYW1zLCBzdHJpY3RQYXJhbXMpO1xuXHRcdFx0bGV0IHBhcmFtc0Vycm9yO1xuXHRcdFx0aWYgKCFleGlzdGluZ01hdGNoKSB0cnkge1xuXHRcdFx0XHRleHRyYWN0U3RyaWN0UGFyYW1zKHJvdXRlLCBzdHJpY3RQYXJhbXMpO1xuXHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdGlmIChpc05vdEZvdW5kKGVycikgfHwgaXNSZWRpcmVjdChlcnIpKSBwYXJhbXNFcnJvciA9IGVycjtcblx0XHRcdFx0ZWxzZSBwYXJhbXNFcnJvciA9IG5ldyBQYXRoUGFyYW1FcnJvcihlcnIubWVzc2FnZSwgeyBjYXVzZTogZXJyIH0pO1xuXHRcdFx0XHRpZiAob3B0cz8udGhyb3dPbkVycm9yKSB0aHJvdyBwYXJhbXNFcnJvcjtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGNhdXNlID0gcHJldmlvdXNNYXRjaCA/IFwic3RheVwiIDogXCJlbnRlclwiO1xuXHRcdFx0bGV0IG1hdGNoO1xuXHRcdFx0aWYgKGV4aXN0aW5nTWF0Y2gpIG1hdGNoID0ge1xuXHRcdFx0XHQuLi5leGlzdGluZ01hdGNoLFxuXHRcdFx0XHRjYXVzZSxcblx0XHRcdFx0c2VhcmNoOiBwcmV2aW91c01hdGNoID8gbnVsbFJlcGxhY2VFcXVhbERlZXAocHJldmlvdXNNYXRjaC5zZWFyY2gsIHByZU1hdGNoU2VhcmNoKSA6IG51bGxSZXBsYWNlRXF1YWxEZWVwKGV4aXN0aW5nTWF0Y2guc2VhcmNoLCBwcmVNYXRjaFNlYXJjaCksXG5cdFx0XHRcdF9zdHJpY3RTZWFyY2g6IHN0cmljdE1hdGNoU2VhcmNoLFxuXHRcdFx0XHRzZWFyY2hFcnJvclxuXHRcdFx0fTtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRjb25zdCBzdGF0dXMgPSByb3V0ZU5lZWRzTG9hZChyb3V0ZSkgPyBcInBlbmRpbmdcIiA6IFwic3VjY2Vzc1wiO1xuXHRcdFx0XHRtYXRjaCA9IHtcblx0XHRcdFx0XHRpZDogbWF0Y2hJZCxcblx0XHRcdFx0XHRzc3I6IGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIgPyB2b2lkIDAgOiByb3V0ZS5vcHRpb25zLnNzcixcblx0XHRcdFx0XHRpbmRleCxcblx0XHRcdFx0XHRyb3V0ZUlkOiByb3V0ZS5pZCxcblx0XHRcdFx0XHRwYXJhbXM6IHByZXZpb3VzTWF0Y2g/LnBhcmFtcyA/PyBzdHJpY3RQYXJhbXMsXG5cdFx0XHRcdFx0X3N0cmljdFBhcmFtczogc3RyaWN0UGFyYW1zLFxuXHRcdFx0XHRcdHBhdGhuYW1lOiBpbnRlcnBvbGF0ZWRQYXRoLFxuXHRcdFx0XHRcdHVwZGF0ZWRBdDogRGF0ZS5ub3coKSxcblx0XHRcdFx0XHRzZWFyY2g6IHByZXZpb3VzTWF0Y2ggPyBudWxsUmVwbGFjZUVxdWFsRGVlcChwcmV2aW91c01hdGNoLnNlYXJjaCwgcHJlTWF0Y2hTZWFyY2gpIDogcHJlTWF0Y2hTZWFyY2gsXG5cdFx0XHRcdFx0X3N0cmljdFNlYXJjaDogc3RyaWN0TWF0Y2hTZWFyY2gsXG5cdFx0XHRcdFx0c2VhcmNoRXJyb3IsXG5cdFx0XHRcdFx0c3RhdHVzLFxuXHRcdFx0XHRcdGlzRmV0Y2hpbmc6IGZhbHNlLFxuXHRcdFx0XHRcdGVycm9yOiB2b2lkIDAsXG5cdFx0XHRcdFx0cGFyYW1zRXJyb3IsXG5cdFx0XHRcdFx0Y29udGV4dDoge30sXG5cdFx0XHRcdFx0YWJvcnRDb250cm9sbGVyOiBvcHRzPy5fY29udHJvbGxlciA/PyBuZXcgQWJvcnRDb250cm9sbGVyKCksXG5cdFx0XHRcdFx0Y2F1c2UsXG5cdFx0XHRcdFx0bG9hZGVyRGVwczogcHJldmlvdXNNYXRjaCA/IHJlcGxhY2VFcXVhbERlZXAocHJldmlvdXNNYXRjaC5sb2FkZXJEZXBzLCBsb2FkZXJEZXBzKSA6IGxvYWRlckRlcHMsXG5cdFx0XHRcdFx0aW52YWxpZDogZmFsc2UsXG5cdFx0XHRcdFx0cHJlbG9hZDogZmFsc2UsXG5cdFx0XHRcdFx0c3RhdGljRGF0YTogcm91dGUub3B0aW9ucy5zdGF0aWNEYXRhIHx8IHt9LFxuXHRcdFx0XHRcdGZ1bGxQYXRoOiByb3V0ZS5mdWxsUGF0aFxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgX25vdEZvdW5kID0gX25vdEZvdW5kUm91dGVJZCA9PT0gcm91dGUuaWQ7XG5cdFx0XHRpZiAobWF0Y2guX25vdEZvdW5kICYmICFfbm90Rm91bmQpIG1hdGNoLmVycm9yID0gdm9pZCAwO1xuXHRcdFx0bWF0Y2guX25vdEZvdW5kID0gX25vdEZvdW5kO1xuXHRcdFx0bWF0Y2hlc1tpbmRleF0gPSBtYXRjaDtcblx0XHR9XG5cdFx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IG1hdGNoZXMubGVuZ3RoOyBpbmRleCsrKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IG1hdGNoZXNbaW5kZXhdO1xuXHRcdFx0bWF0Y2gucGFyYW1zID0gbWF0Y2guY2F1c2UgPT09IFwic3RheVwiID8gbnVsbFJlcGxhY2VFcXVhbERlZXAobWF0Y2gucGFyYW1zLCBzdHJpY3RQYXJhbXMpIDogc3RyaWN0UGFyYW1zO1xuXHRcdFx0aWYgKG9wdHM/Ll9jb250cm9sbGVyKSBtYXRjaC5jb250ZXh0ID0ge307XG5cdFx0fVxuXHRcdHJldHVybiBtYXRjaGVzO1xuXHR9XG5cdC8qKlxuXHQqIExpZ2h0d2VpZ2h0IHJvdXRlIG1hdGNoaW5nIGZvciBidWlsZExvY2F0aW9uLlxuXHQqIE9ubHkgY29tcHV0ZXMgZnVsbFBhdGgsIGFjY3VtdWxhdGVkIHNlYXJjaCwgYW5kIHBhcmFtcyAtIHNraXBwaW5nIGV4cGVuc2l2ZVxuXHQqIG9wZXJhdGlvbnMgbGlrZSBBYm9ydENvbnRyb2xsZXIsIGxvYWRlckRlcHMsIGFuZCBmdWxsIG1hdGNoIG9iamVjdHMuXG5cdCovXG5cdG1hdGNoUm91dGVzTGlnaHR3ZWlnaHQobG9jYXRpb24pIHtcblx0XHRjb25zdCBsYXN0Um91dGVJZCA9IGxhc3QodGhpcy5zdG9yZXMuaWRzLmdldCgpKTtcblx0XHRjb25zdCBsYXN0U3RhdGVNYXRjaCA9IGxhc3RSb3V0ZUlkID8gdGhpcy5zdG9yZXMuYnlSb3V0ZS5nZXQobGFzdFJvdXRlSWQpLmdldCgpIDogdm9pZCAwO1xuXHRcdGNvbnN0IGxhc3RTdGF0ZU1hdGNoSWQgPSBsYXN0U3RhdGVNYXRjaD8uaWQ7XG5cdFx0Y29uc3QgY2FjaGVkID0gdGhpcy5saWdodHdlaWdodENhY2hlLmdldChsb2NhdGlvbik7XG5cdFx0aWYgKGNhY2hlZCAmJiBjYWNoZWRbMF0gPT09IGxhc3RTdGF0ZU1hdGNoSWQpIHJldHVybiBjYWNoZWRbMV07XG5cdFx0Y29uc3QgW21hdGNoZWRSb3V0ZXMsIHJhd1BhcmFtc10gPSB0aGlzLmdldE1hdGNoZWRSb3V0ZXMobG9jYXRpb24ucGF0aG5hbWUpO1xuXHRcdGNvbnN0IGxhc3RSb3V0ZSA9IGxhc3QobWF0Y2hlZFJvdXRlcyk7XG5cdFx0Y29uc3QgYWNjdW11bGF0ZWRTZWFyY2ggPSB7IC4uLmxvY2F0aW9uLnNlYXJjaCB9O1xuXHRcdGZvciAoY29uc3Qgcm91dGUgb2YgbWF0Y2hlZFJvdXRlcykgdHJ5IHtcblx0XHRcdE9iamVjdC5hc3NpZ24oYWNjdW11bGF0ZWRTZWFyY2gsIHZhbGlkYXRlU2VhcmNoKHJvdXRlLm9wdGlvbnMudmFsaWRhdGVTZWFyY2gsIGFjY3VtdWxhdGVkU2VhcmNoKSk7XG5cdFx0fSBjYXRjaCB7fVxuXHRcdGNvbnN0IGNhblJldXNlUGFyYW1zID0gbGFzdFN0YXRlTWF0Y2ggJiYgbGFzdFN0YXRlTWF0Y2gucm91dGVJZCA9PT0gbGFzdFJvdXRlLmlkICYmIGxhc3RTdGF0ZU1hdGNoLnBhdGhuYW1lID09PSBsb2NhdGlvbi5wYXRobmFtZTtcblx0XHRsZXQgcGFyYW1zO1xuXHRcdGlmIChjYW5SZXVzZVBhcmFtcykgcGFyYW1zID0gbGFzdFN0YXRlTWF0Y2gucGFyYW1zO1xuXHRcdGVsc2Uge1xuXHRcdFx0Y29uc3Qgc3RyaWN0UGFyYW1zID0gcmF3UGFyYW1zO1xuXHRcdFx0Zm9yIChjb25zdCByb3V0ZSBvZiBtYXRjaGVkUm91dGVzKSB0cnkge1xuXHRcdFx0XHRleHRyYWN0U3RyaWN0UGFyYW1zKHJvdXRlLCBzdHJpY3RQYXJhbXMpO1xuXHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0cGFyYW1zID0gc3RyaWN0UGFyYW1zO1xuXHRcdH1cblx0XHRjb25zdCByZXN1bHQgPSBbXG5cdFx0XHRtYXRjaGVkUm91dGVzLFxuXHRcdFx0bGFzdFJvdXRlLmZ1bGxQYXRoLFxuXHRcdFx0YWNjdW11bGF0ZWRTZWFyY2gsXG5cdFx0XHRwYXJhbXNcblx0XHRdO1xuXHRcdHRoaXMubGlnaHR3ZWlnaHRDYWNoZS5zZXQobG9jYXRpb24sIFtsYXN0U3RhdGVNYXRjaElkLCByZXN1bHRdKTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG59O1xuYXN5bmMgZnVuY3Rpb24gZG9jdW1lbnROYXZpZ2F0aW9uKHJvdXRlciwgaHJlZiwgeyByZXBsYWNlLCBpZ25vcmVCbG9ja2VyIH0pIHtcblx0aWYgKGlzRGFuZ2Vyb3VzUHJvdG9jb2woaHJlZiwgcm91dGVyLnByb3RvY29sQWxsb3dsaXN0KSkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNvbnNvbGUud2FybihgQmxvY2tlZCBuYXZpZ2F0aW9uIHRvIGRhbmdlcm91cyBwcm90b2NvbDogJHtocmVmfWApO1xuXHRcdHJldHVybjtcblx0fVxuXHRpZiAoIWlnbm9yZUJsb2NrZXIpIHtcblx0XHRjb25zdCBibG9ja2VycyA9IHJvdXRlci5oaXN0b3J5Ll9nZXRCbG9ja2VycygpO1xuXHRcdGZvciAoY29uc3QgYmxvY2tlciBvZiBibG9ja2VycykgaWYgKGJsb2NrZXI/LmJsb2NrZXJGbikge1xuXHRcdFx0aWYgKGF3YWl0IGJsb2NrZXIuYmxvY2tlckZuKHtcblx0XHRcdFx0Y3VycmVudExvY2F0aW9uOiByb3V0ZXIuaGlzdG9yeS5sb2NhdGlvbixcblx0XHRcdFx0bmV4dExvY2F0aW9uOiByb3V0ZXIuaGlzdG9yeS5sb2NhdGlvbixcblx0XHRcdFx0YWN0aW9uOiByZXBsYWNlID8gXCJSRVBMQUNFXCIgOiBcIlBVU0hcIlxuXHRcdFx0fSkpIHJldHVybjtcblx0XHR9XG5cdH1cblx0cm91dGVyLmhpc3RvcnkuX2lnbm9yZU5leHRCZWZvcmVVbmxvYWQ/LihocmVmKTtcblx0aWYgKHJlcGxhY2UpIHdpbmRvdy5sb2NhdGlvbi5yZXBsYWNlKGhyZWYpO1xuXHRlbHNlIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gaHJlZjtcbn1cbi8qKlxuKiBJbiBub24tcHJvZHVjdGlvbiBlbnZpcm9ubWVudHMsXG4qIGF1Z21lbnQgdGhlIFJvdXRlckNvcmUgY2xhc3Mgd2l0aCBhIGBfcmVmcmVzaFJvdXRlYCBtZXRob2RcbiogZGVkaWNhdGVkIHRvIEhNUi5cbiovXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFJvdXRlckNvcmUucHJvdG90eXBlLl9yZXBsYWNlUm91dGVDaHVuayA9IHJlcGxhY2VSb3V0ZUNodW5rO1xuXHRSb3V0ZXJDb3JlLnByb3RvdHlwZS5fcmVmcmVzaFJvdXRlID0gYXN5bmMgZnVuY3Rpb24oKSB7XG5cdFx0dGhpcy5fc2VydmVyUmVzdWx0ID0gdm9pZCAwO1xuXHRcdHRoaXMudXBkYXRlTGF0ZXN0TG9jYXRpb24oKTtcblx0XHRhd2FpdCByZWZyZXNoQ2xpZW50Um91dGUodGhpcyk7XG5cdH07XG59XG4vKiogRXJyb3IgdGhyb3duIHdoZW4gc2VhcmNoIHBhcmFtZXRlciB2YWxpZGF0aW9uIGZhaWxzLiAqL1xudmFyIFNlYXJjaFBhcmFtRXJyb3IgPSBjbGFzcyBleHRlbmRzIEVycm9yIHt9O1xuLyoqIEVycm9yIHRocm93biB3aGVuIHBhdGggcGFyYW1ldGVyIHBhcnNpbmcvdmFsaWRhdGlvbiBmYWlscy4gKi9cbnZhciBQYXRoUGFyYW1FcnJvciA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige307XG5jb25zdCBub3JtYWxpemUgPSAoc3RyKSA9PiBzdHIuZW5kc1dpdGgoXCIvXCIpICYmIHN0ci5sZW5ndGggPiAxID8gc3RyLnNsaWNlKDAsIC0xKSA6IHN0cjtcbmZ1bmN0aW9uIGNvbXBhcmVQYXRocyhhLCBiKSB7XG5cdHJldHVybiBub3JtYWxpemUoYSkgPT09IG5vcm1hbGl6ZShiKTtcbn1cbi8qKlxuKiBMYXppbHkgaW1wb3J0IGEgbW9kdWxlIGZ1bmN0aW9uIGFuZCBmb3J3YXJkIGFyZ3VtZW50cyB0byBpdCwgcmV0YWluaW5nXG4qIHBhcmFtZXRlciBhbmQgcmV0dXJuIHR5cGVzIGZvciB0aGUgc2VsZWN0ZWQgZXhwb3J0IGtleS5cbiovXG5mdW5jdGlvbiBsYXp5Rm4oZm4sIGtleSkge1xuXHRyZXR1cm4gYXN5bmMgKC4uLmFyZ3MpID0+IHtcblx0XHRyZXR1cm4gKGF3YWl0IGZuKCkpW2tleSB8fCBcImRlZmF1bHRcIl0oLi4uYXJncyk7XG5cdH07XG59XG4vKiogQ3JlYXRlIGFuIGluaXRpYWwgUm91dGVyU3RhdGUgZnJvbSBhIHBhcnNlZCBsb2NhdGlvbi4gKi9cbmZ1bmN0aW9uIGdldEluaXRpYWxSb3V0ZXJTdGF0ZShsb2NhdGlvbikge1xuXHRyZXR1cm4ge1xuXHRcdGlzTG9hZGluZzogZmFsc2UsXG5cdFx0c3RhdHVzOiBcImlkbGVcIixcblx0XHRyZXNvbHZlZExvY2F0aW9uOiB2b2lkIDAsXG5cdFx0bG9jYXRpb24sXG5cdFx0bWF0Y2hlczogW11cblx0fTtcbn1cbmZ1bmN0aW9uIHZhbGlkYXRlU2VhcmNoKHZhbGlkYXRlU2VhcmNoLCBpbnB1dCkge1xuXHRpZiAodmFsaWRhdGVTZWFyY2ggPT0gbnVsbCkgcmV0dXJuIHt9O1xuXHRpZiAoXCJ+c3RhbmRhcmRcIiBpbiB2YWxpZGF0ZVNlYXJjaCkge1xuXHRcdGNvbnN0IHJlc3VsdCA9IHZhbGlkYXRlU2VhcmNoW1wifnN0YW5kYXJkXCJdLnZhbGlkYXRlKGlucHV0KTtcblx0XHRpZiAocmVzdWx0IGluc3RhbmNlb2YgUHJvbWlzZSkgdGhyb3cgbmV3IFNlYXJjaFBhcmFtRXJyb3IoXCJBc3luYyB2YWxpZGF0aW9uIG5vdCBzdXBwb3J0ZWRcIik7XG5cdFx0aWYgKHJlc3VsdC5pc3N1ZXMpIHRocm93IG5ldyBTZWFyY2hQYXJhbUVycm9yKEpTT04uc3RyaW5naWZ5KHJlc3VsdC5pc3N1ZXMsIHZvaWQgMCwgMiksIHsgY2F1c2U6IHJlc3VsdCB9KTtcblx0XHRyZXR1cm4gcmVzdWx0LnZhbHVlO1xuXHR9XG5cdGlmIChcInBhcnNlXCIgaW4gdmFsaWRhdGVTZWFyY2gpIHJldHVybiB2YWxpZGF0ZVNlYXJjaC5wYXJzZShpbnB1dCk7XG5cdGlmICh0eXBlb2YgdmFsaWRhdGVTZWFyY2ggPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIHZhbGlkYXRlU2VhcmNoKGlucHV0KTtcblx0cmV0dXJuIHt9O1xufVxuZnVuY3Rpb24gcmVzb2x2ZU5leHRQYXJhbXMoc3BlYywgYmFzZSkge1xuXHRpZiAoc3BlYyA9PT0gdm9pZCAwIHx8IHNwZWMgPT09IHRydWUpIHJldHVybiBiYXNlO1xuXHRjb25zdCBuZXh0ID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblx0aWYgKHNwZWMgPT09IGZhbHNlIHx8IHNwZWMgPT09IG51bGwpIHJldHVybiBuZXh0O1xuXHRpZiAodHlwZW9mIHNwZWMgPT09IFwiZnVuY3Rpb25cIikge1xuXHRcdE9iamVjdC5hc3NpZ24obmV4dCwgYmFzZSk7XG5cdFx0cmV0dXJuIE9iamVjdC5hc3NpZ24obmV4dCwgc3BlYyhuZXh0KSk7XG5cdH1cblx0cmV0dXJuIE9iamVjdC5hc3NpZ24obmV4dCwgYmFzZSwgc3BlYyk7XG59XG5mdW5jdGlvbiBuZWVkc0luaGVyaXRlZFBhcmFtcyhzcGVjLCBpbnRlcnBvbGF0aW9uKSB7XG5cdGlmICh0eXBlb2Ygc3BlYyA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gdHJ1ZTtcblx0aWYgKCFpbnRlcnBvbGF0aW9uIHx8IHNwZWMgPT09IGZhbHNlIHx8IHNwZWMgPT09IG51bGwpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIHNwZWMgPT09IHZvaWQgMCB8fCBzcGVjID09PSB0cnVlIHx8IGludGVycG9sYXRpb24uc29tZSgocGFydCkgPT4gdHlwZW9mIHBhcnQgIT09IFwic3RyaW5nXCIgJiYgIWhhc093bi5jYWxsKHNwZWMsIHBhcnRbMV0pKTtcbn1cbmNvbnN0IEVNUFRZX1JFQ09SRCA9IE9iamVjdC5mcmVlemUoe30pO1xuZnVuY3Rpb24gZ2V0U2VhcmNoTWlkZGxld2FyZXMoZGVzdFJvdXRlcywgaW5jbHVkZVZhbGlkYXRlU2VhcmNoKSB7XG5cdGNvbnN0IG1pZGRsZXdhcmVzID0gW107XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgZGVzdFJvdXRlcy5sZW5ndGg7IGkrKykge1xuXHRcdGNvbnN0IHJvdXRlT3B0aW9ucyA9IGRlc3RSb3V0ZXNbaV0ub3B0aW9ucztcblx0XHRpZiAoXCJzZWFyY2hcIiBpbiByb3V0ZU9wdGlvbnMpIHtcblx0XHRcdGlmIChyb3V0ZU9wdGlvbnMuc2VhcmNoPy5taWRkbGV3YXJlcykgbWlkZGxld2FyZXMucHVzaCguLi5yb3V0ZU9wdGlvbnMuc2VhcmNoLm1pZGRsZXdhcmVzKTtcblx0XHR9IGVsc2UgaWYgKHJvdXRlT3B0aW9ucy5wcmVTZWFyY2hGaWx0ZXJzIHx8IHJvdXRlT3B0aW9ucy5wb3N0U2VhcmNoRmlsdGVycykge1xuXHRcdFx0Y29uc3QgbGVnYWN5TWlkZGxld2FyZSA9ICh7IHNlYXJjaCwgbmV4dCB9KSA9PiB7XG5cdFx0XHRcdGNvbnN0IHJlc3VsdCA9IG5leHQocm91dGVPcHRpb25zLnByZVNlYXJjaEZpbHRlcnMgPyByb3V0ZU9wdGlvbnMucHJlU2VhcmNoRmlsdGVycy5yZWR1Y2UoKHByZXYsIG5leHQpID0+IG5leHQocHJldiksIHNlYXJjaCkgOiBzZWFyY2gpO1xuXHRcdFx0XHRyZXR1cm4gcm91dGVPcHRpb25zLnBvc3RTZWFyY2hGaWx0ZXJzID8gcm91dGVPcHRpb25zLnBvc3RTZWFyY2hGaWx0ZXJzLnJlZHVjZSgocHJldiwgbmV4dCkgPT4gbmV4dChwcmV2KSwgcmVzdWx0KSA6IHJlc3VsdDtcblx0XHRcdH07XG5cdFx0XHRtaWRkbGV3YXJlcy5wdXNoKGxlZ2FjeU1pZGRsZXdhcmUpO1xuXHRcdH1cblx0XHRjb25zdCByb3V0ZVZhbGlkYXRlU2VhcmNoID0gcm91dGVPcHRpb25zLnZhbGlkYXRlU2VhcmNoO1xuXHRcdGlmIChpbmNsdWRlVmFsaWRhdGVTZWFyY2ggJiYgcm91dGVWYWxpZGF0ZVNlYXJjaCkge1xuXHRcdFx0Y29uc3QgdmFsaWRhdGUgPSAoeyBzZWFyY2gsIG5leHQsIG1ldGEgfSkgPT4ge1xuXHRcdFx0XHRjb25zdCByZXN1bHQgPSBuZXh0KHNlYXJjaCk7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0Y29uc3QgdmFsaWRhdGVkID0gdmFsaWRhdGVTZWFyY2gocm91dGVWYWxpZGF0ZVNlYXJjaCwgcmVzdWx0KTtcblx0XHRcdFx0XHRpZiAobWV0YSAmJiB2YWxpZGF0ZWQpIHtcblx0XHRcdFx0XHRcdGZvciAoY29uc3Qga2V5IGluIHZhbGlkYXRlZCkgaWYgKCEoa2V5IGluIHJlc3VsdCkpIChtZXRhLmRlZmF1bHRlZCB8fD0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSkuc2V0KGtleSwgdmFsaWRhdGVkW2tleV0pO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdFx0Li4ucmVzdWx0LFxuXHRcdFx0XHRcdFx0Li4udmFsaWRhdGVkXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdFx0fTtcblx0XHRcdG1pZGRsZXdhcmVzLnB1c2godmFsaWRhdGUpO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gbWlkZGxld2FyZXM7XG59XG5mdW5jdGlvbiBhcHBseVNlYXJjaE1pZGRsZXdhcmUobWlkZGxld2FyZXMsIHNlYXJjaCwgZGVzdCkge1xuXHRjb25zdCBhcHBseU5leHQgPSAoaW5kZXgsIGN1cnJlbnRTZWFyY2gsIG1ldGEpID0+IHtcblx0XHRpZiAoaW5kZXggPj0gbWlkZGxld2FyZXMubGVuZ3RoKSB7XG5cdFx0XHRpZiAoIWRlc3Quc2VhcmNoKSByZXR1cm4ge307XG5cdFx0XHRpZiAoZGVzdC5zZWFyY2ggPT09IHRydWUpIHJldHVybiBjdXJyZW50U2VhcmNoO1xuXHRcdFx0Y29uc3QgcmVzdWx0ID0gZnVuY3Rpb25hbFVwZGF0ZShkZXN0LnNlYXJjaCwgY3VycmVudFNlYXJjaCk7XG5cdFx0XHRpZiAobWV0YSkgbWV0YS5leHBsaWNpdCA9IHJlc3VsdDtcblx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fVxuXHRcdGNvbnN0IG5leHQgPSAobmV3U2VhcmNoLCBjb2xsZWN0TWV0YSkgPT4ge1xuXHRcdFx0aWYgKGNvbGxlY3RNZXRhKSB7XG5cdFx0XHRcdGNvbnN0IG5leHRNZXRhID0gbWV0YSB8fCB7fTtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRzZWFyY2g6IGFwcGx5TmV4dChpbmRleCArIDEsIG5ld1NlYXJjaCwgbmV4dE1ldGEpLFxuXHRcdFx0XHRcdG1ldGE6IG5leHRNZXRhXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gYXBwbHlOZXh0KGluZGV4ICsgMSwgbmV3U2VhcmNoLCBtZXRhKTtcblx0XHR9O1xuXHRcdHJldHVybiBtaWRkbGV3YXJlc1tpbmRleF0oe1xuXHRcdFx0c2VhcmNoOiBjdXJyZW50U2VhcmNoLFxuXHRcdFx0bmV4dCxcblx0XHRcdG1ldGFcblx0XHR9KTtcblx0fTtcblx0cmV0dXJuIGFwcGx5TmV4dCgwLCBzZWFyY2gpO1xufVxuZnVuY3Rpb24gZmluZEdsb2JhbE5vdEZvdW5kUm91dGVJZChub3RGb3VuZE1vZGUsIHJvdXRlcykge1xuXHRpZiAobm90Rm91bmRNb2RlICE9PSBcInJvb3RcIikge1xuXHRcdGxldCBmYWxsYmFjaztcblx0XHRmb3IgKGxldCBpID0gcm91dGVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRjb25zdCByb3V0ZSA9IHJvdXRlc1tpXTtcblx0XHRcdGlmIChyb3V0ZS5vcHRpb25zLm5vdEZvdW5kQ29tcG9uZW50KSByZXR1cm4gcm91dGUuaWQ7XG5cdFx0XHRmYWxsYmFjayB8fD0gcm91dGUuY2hpbGRyZW4gJiYgcm91dGUuaWQ7XG5cdFx0fVxuXHRcdGlmIChmYWxsYmFjaykgcmV0dXJuIGZhbGxiYWNrO1xuXHR9XG5cdHJldHVybiByb290Um91dGVJZDtcbn1cbmZ1bmN0aW9uIGV4dHJhY3RTdHJpY3RQYXJhbXMocm91dGUsIGFjY3VtdWxhdGVkUGFyYW1zKSB7XG5cdGNvbnN0IHBhcnNlUGFyYW1zID0gcm91dGUub3B0aW9ucy5wYXJhbXM/LnBhcnNlID8/IHJvdXRlLm9wdGlvbnMucGFyc2VQYXJhbXM7XG5cdGlmIChwYXJzZVBhcmFtcykgT2JqZWN0LmFzc2lnbihhY2N1bXVsYXRlZFBhcmFtcywgcGFyc2VQYXJhbXMoYWNjdW11bGF0ZWRQYXJhbXMpKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUGF0aFBhcmFtRXJyb3IsIFJvdXRlckNvcmUsIFNlYXJjaFBhcmFtRXJyb3IsIF9nZXRVc2VySGlzdG9yeVN0YXRlLCBkZWZhdWx0U2VyaWFsaXplRXJyb3IsIGdldEluaXRpYWxSb3V0ZXJTdGF0ZSwgZ2V0TG9jYXRpb25DaGFuZ2VJbmZvLCBsYXp5Rm4sIGxpZmVjeWNsZUVuZCwgcnVuUm91dGVMaWZlY3ljbGUsIHRyYWlsaW5nU2xhc2hPcHRpb25zIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdXRlci5qcy5tYXAiLCJpbXBvcnQgeyBpc05vdEZvdW5kIH0gZnJvbSBcIi4vbm90LWZvdW5kLmpzXCI7XG5pbXBvcnQgeyBpc1JlZGlyZWN0IH0gZnJvbSBcIi4vcmVkaXJlY3QuanNcIjtcbmltcG9ydCB7IGRlaHlkcmF0ZVNzck1hdGNoSWQgfSBmcm9tIFwiLi9zc3Ivc3NyLW1hdGNoLWlkLmpzXCI7XG5pbXBvcnQgeyBnZXRMb2NhdGlvbkNoYW5nZUluZm8sIGxpZmVjeWNsZUVuZCwgcnVuUm91dGVMaWZlY3ljbGUgfSBmcm9tIFwiLi9yb3V0ZXIuanNcIjtcbi8vI3JlZ2lvbiBzcmMvbG9hZC1jbGllbnQudHNcbmZ1bmN0aW9uIHJlcGxhY2VSb3V0ZUNodW5rKHJvdXRlLCBsYXp5Rm4pIHtcblx0cm91dGUubGF6eUZuID0gbGF6eUZuID8/IHJvdXRlLmxhenlGbjtcblx0cm91dGUuX2xhenkgPSB2b2lkIDA7XG59XG5mdW5jdGlvbiBwcmVsb2FkQ29tcG9uZW50KHJvdXRlLCB0eXBlKSB7XG5cdHJldHVybiByb3V0ZS5vcHRpb25zW3R5cGVdPy5wcmVsb2FkPy4oKTtcbn1cbmZ1bmN0aW9uIGxvYWRDb21wb25lbnRzKHJvdXRlLCBvblBlbmRpbmdSZWFkeSkge1xuXHRjb25zdCBjb21wb25lbnQgPSBwcmVsb2FkQ29tcG9uZW50KHJvdXRlLCBcImNvbXBvbmVudFwiKTtcblx0bGV0IHBlbmRpbmcgPSBwcmVsb2FkQ29tcG9uZW50KHJvdXRlLCBcInBlbmRpbmdDb21wb25lbnRcIik7XG5cdGlmIChvblBlbmRpbmdSZWFkeSkge1xuXHRcdGlmIChwZW5kaW5nKSBwZW5kaW5nID0gcGVuZGluZy50aGVuKG9uUGVuZGluZ1JlYWR5KTtcblx0XHRlbHNlIG9uUGVuZGluZ1JlYWR5KCk7XG5cdH1cblx0aWYgKGNvbXBvbmVudCAmJiBwZW5kaW5nKSByZXR1cm4gUHJvbWlzZS5hbGwoW2NvbXBvbmVudCwgcGVuZGluZ10pLnRoZW4oKCkgPT4ge30pO1xuXHRyZXR1cm4gY29tcG9uZW50ID8/IHBlbmRpbmc7XG59XG5mdW5jdGlvbiBsb2FkUm91dGVDaHVuayhyb3V0ZSwgY29tcG9uZW50VHlwZSwgb25QZW5kaW5nUmVhZHkpIHtcblx0Y29uc3QgYWZ0ZXJMYXp5ID0gKCkgPT4gY29tcG9uZW50VHlwZSA9PT0gZmFsc2UgPyB2b2lkIDAgOiBjb21wb25lbnRUeXBlID8gcHJlbG9hZENvbXBvbmVudChyb3V0ZSwgY29tcG9uZW50VHlwZSkgOiBsb2FkQ29tcG9uZW50cyhyb3V0ZSwgb25QZW5kaW5nUmVhZHkpO1xuXHRjb25zdCBjdXJyZW50ID0gcm91dGUuX2xhenk7XG5cdGlmIChjdXJyZW50KSByZXR1cm4gY3VycmVudCA9PT0gdHJ1ZSA/IGFmdGVyTGF6eSgpIDogY3VycmVudC50aGVuKGFmdGVyTGF6eSk7XG5cdGlmICghcm91dGUubGF6eUZuKSByZXR1cm4gYWZ0ZXJMYXp5KCk7XG5cdGNvbnN0IHByb21pc2UgPSByb3V0ZS5sYXp5Rm4oKS50aGVuKChsYXp5Um91dGUpID0+IHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiIHx8IHJvdXRlLl9sYXp5ID09PSBwcm9taXNlKSB7XG5cdFx0XHRjb25zdCB7IGlkOiBfaWQsIC4uLm9wdGlvbnMgfSA9IGxhenlSb3V0ZS5vcHRpb25zO1xuXHRcdFx0T2JqZWN0LmFzc2lnbihyb3V0ZS5vcHRpb25zLCBvcHRpb25zKTtcblx0XHRcdHJvdXRlLl9sYXp5ID0gdHJ1ZTtcblx0XHR9XG5cdH0sIChlcnJvcikgPT4ge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgfHwgcm91dGUuX2xhenkgPT09IHByb21pc2UpIHJvdXRlLl9sYXp5ID0gdm9pZCAwO1xuXHRcdHRocm93IGVycm9yO1xuXHR9KTtcblx0cm91dGUuX2xhenkgPSBwcm9taXNlO1xuXHRyZXR1cm4gcHJvbWlzZS50aGVuKGFmdGVyTGF6eSk7XG59XG4vKiogUmV0dXJuIHRoZSBzdHJ1Y3R1cmFsIGxhbmUgdGhyb3VnaCB0aGUgZmlyc3QgdGVybWluYWwgcmVuZGVyIGJvdW5kYXJ5LiAqL1xuZnVuY3Rpb24gX2dldFJlbmRlcmVkTWF0Y2hlcyhtYXRjaGVzKSB7XG5cdGNvbnN0IGVuZCA9IG1hdGNoZXMuZmluZEluZGV4KChtYXRjaCkgPT4gbWF0Y2guc3RhdHVzICE9PSBcInN1Y2Nlc3NcIiB8fCBtYXRjaC5fbm90Rm91bmQpICsgMTtcblx0cmV0dXJuIGVuZCAmJiBlbmQgPCBtYXRjaGVzLmxlbmd0aCA/IG1hdGNoZXMuc2xpY2UoMCwgZW5kKSA6IG1hdGNoZXM7XG59XG4vKipcbiogVHJ1dGh5IHdoZW4gdGhlIHRyYW5zYWN0aW9uIHB1Ymxpc2hpbmcgYGxvY2F0aW9uYCBsZWF2ZXMgYHJvdXRlSWRgIG91dCBvZiBpdHNcbiogbWF0Y2hlcywgc28gc3Vic2NyaWJlcnMgc2NvcGVkIHRvIHRoYXQgcm91dGUgY2FuIHNraXAgdGhlIHB1YmxpY2F0aW9uOiB0aGVcbiogcm91dGUgdW5tb3VudHMgd2hlbiB0aGUgdHJhbnNhY3Rpb24gY29tbWl0cywgYW5kIGEgdHJhbnNhY3Rpb24gdGhhdCBlbmRzXG4qIG90aGVyd2lzZSBpcyBzdXBlcnNlZGVkIG9yIHJlZGlyZWN0ZWQgYnkgYSBuZXdlciBwdWJsaWNhdGlvbi4gT25seSB2YWxpZFxuKiBzeW5jaHJvbm91c2x5IGluc2lkZSB0aGUgcHVibGljYXRpb246IHRoZSB0cmFuc2FjdGlvbidzIG1hdGNoZXMgYXJlIGVtcHRpZWRcbiogYXQgY29tbWl0IGFuZCBiZWZvcmUgZm9sbG93aW5nIGEgcmVkaXJlY3QuIFB1YmxpY2F0aW9ucyB3aXRob3V0IGEgbWF0Y2hpbmdcbiogdHJhbnNhY3Rpb24gKGh5ZHJhdGlvbikgYW5kIHNjb3BlcyB3aXRob3V0IGEgcm91dGUgbmV2ZXIgZGVwYXJ0LlxuKi9cbmZ1bmN0aW9uIF9pc1JvdXRlRGVwYXJ0aW5nKHJvdXRlciwgcm91dGVJZCwgbG9jYXRpb24pIHtcblx0Y29uc3QgdHggPSByb3V0ZXIuX3R4O1xuXHRyZXR1cm4gcm91dGVJZCAmJiB0eD8uWzJdID09PSBsb2NhdGlvbiAmJiAhdHhbM10uc29tZSgobWF0Y2gpID0+IG1hdGNoLnJvdXRlSWQgPT09IHJvdXRlSWQpO1xufVxuLyoqIFJldHVybiB0aGUgbGFuZSB3aG9zZSBkb2N1bWVudCBhc3NldHMgYmVsb25nIHRvIHRoZSBjdXJyZW50IHByZXNlbnRhdGlvbi4gKi9cbmZ1bmN0aW9uIF9nZXRBc3NldE1hdGNoZXMobWF0Y2hlcykge1xuXHRsZXQgZW5kID0gbWF0Y2hlcy5sZW5ndGg7XG5cdGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBlbmQ7IGluZGV4KyspIHtcblx0XHRjb25zdCBtYXRjaCA9IG1hdGNoZXNbaW5kZXhdO1xuXHRcdGlmIChtYXRjaC5fYXNzZXRFbmQgIT09IHZvaWQgMCkge1xuXHRcdFx0ZW5kID0gTWF0aC5taW4oZW5kLCBNYXRoLm1heChpbmRleCArIDEsIG1hdGNoLl9hc3NldEVuZCkpO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGlmIChtYXRjaC5zdGF0dXMgIT09IFwic3VjY2Vzc1wiIHx8IG1hdGNoLl9ub3RGb3VuZCkge1xuXHRcdFx0ZW5kID0gaW5kZXggKyAxO1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHR9XG5cdHJldHVybiBlbmQgPCBtYXRjaGVzLmxlbmd0aCA/IG1hdGNoZXMuc2xpY2UoMCwgZW5kKSA6IG1hdGNoZXM7XG59XG5jb25zdCBTVUNDRVNTID0gMDtcbmNvbnN0IEVSUk9SID0gMTtcbmNvbnN0IE5PVF9GT1VORCA9IDI7XG5jb25zdCBSRURJUkVDVEVEID0gMztcbmNvbnN0IENBTkNFTEVEX09VVENPTUUgPSBbNF07XG5mdW5jdGlvbiBpc0NvbnRyb2wocmVzdWx0KSB7XG5cdHJldHVybiB0eXBlb2YgcmVzdWx0WzBdID09PSBcIm51bWJlclwiO1xufVxuZnVuY3Rpb24gd2FpdEZvcih2YWx1ZSwgc2lnbmFsKSB7XG5cdGlmIChzaWduYWwuYWJvcnRlZCkgcmV0dXJuIFByb21pc2UucmFjZShbUHJvbWlzZS5yZWplY3Qoc2lnbmFsKSwgdmFsdWVdKTtcblx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCBhYm9ydCA9ICgpID0+IHJlamVjdChzaWduYWwpO1xuXHRcdHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgYWJvcnQsIHsgb25jZTogdHJ1ZSB9KTtcblx0XHRQcm9taXNlLnJlc29sdmUodmFsdWUpLnRoZW4ocmVzb2x2ZSwgcmVqZWN0KS50aGVuKCgpID0+IHNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgYWJvcnQpKTtcblx0fSk7XG59XG5mdW5jdGlvbiBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKSB7XG5cdHJldHVybiByb3V0ZXIucm91dGVzQnlJZFttYXRjaC5yb3V0ZUlkXTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZSh2YWx1ZSwgcmVqZWN0ZWQsIHJvdXRlSWQpIHtcblx0aWYgKGlzUmVkaXJlY3QodmFsdWUpKSByZXR1cm4gW1JFRElSRUNURUQsIHZhbHVlXTtcblx0aWYgKGlzTm90Rm91bmQodmFsdWUpKSB7XG5cdFx0dmFsdWUucm91dGVJZCB8fD0gcm91dGVJZDtcblx0XHRyZXR1cm4gW05PVF9GT1VORCwgdmFsdWVdO1xuXHR9XG5cdGlmICghcmVqZWN0ZWQpIHJldHVybiBbU1VDQ0VTUywgdmFsdWVdO1xuXHRpZiAodHlwZW9mIHZhbHVlPy50aGVuID09PSBcImZ1bmN0aW9uXCIpIHZhbHVlID0gbmV3IEVycm9yKFwiQSBQcm9taXNlIHdhcyB0aHJvd25cIiwgeyBjYXVzZTogdmFsdWUgfSk7XG5cdHJldHVybiBbRVJST1IsIHZhbHVlXTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZUVycm9yKHJvdXRlLCBjYXVzZSkge1xuXHRsZXQgb3V0Y29tZSA9IG5vcm1hbGl6ZShjYXVzZSwgdHJ1ZSwgcm91dGUuaWQpO1xuXHRpZiAob3V0Y29tZVswXSAhPT0gRVJST1IpIHJldHVybiBvdXRjb21lO1xuXHR0cnkge1xuXHRcdHJvdXRlLm9wdGlvbnMub25FcnJvcj8uKG91dGNvbWVbMV0pO1xuXHR9IGNhdGNoIChvbkVycm9yQ2F1c2UpIHtcblx0XHRvdXRjb21lID0gbm9ybWFsaXplKG9uRXJyb3JDYXVzZSwgdHJ1ZSwgcm91dGUuaWQpO1xuXHR9XG5cdHJldHVybiBvdXRjb21lO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplTGFuZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIGNhdXNlLCBvcHRpb25zKSB7XG5cdGlmIChvcHRpb25zWzBdLnNpZ25hbC5hYm9ydGVkKSByZXR1cm4gQ0FOQ0VMRURfT1VUQ09NRTtcblx0cmV0dXJuIG1hdGVyaWFsaXplUmVkaXJlY3Qocm91dGVyLCBsYW5lLCByb3V0ZSwgbm9ybWFsaXplRXJyb3Iocm91dGUsIGNhdXNlKSwgb3B0aW9ucyk7XG59XG5hc3luYyBmdW5jdGlvbiBjb250ZXh0dWFsaXplKHJvdXRlciwgbGFuZSwgb3B0aW9ucywgZW5kLCBwbGFuU3VjY2Vzc2Z1bExhbmUsIHJldGFpbmVkRW5kKSB7XG5cdGNvbnN0IFtsb2NhdGlvbiwgbWF0Y2hlc10gPSBsYW5lO1xuXHRjb25zdCBzaWduYWwgPSBvcHRpb25zWzBdLnNpZ25hbDtcblx0Y29uc3QgcHJlbG9hZCA9ICEhb3B0aW9uc1szXTtcblx0Zm9yIChsZXQgaW5kZXggPSBvcHRpb25zWzZdID8/IDA7IGluZGV4IDwgZW5kOyBpbmRleCsrKSB7XG5cdFx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzW2luZGV4XTtcblx0XHRjb25zdCByb3V0ZSA9IGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpO1xuXHRcdG1hdGNoLmFib3J0Q29udHJvbGxlciA9IG9wdGlvbnNbMF07XG5cdFx0Y29uc3QgcGFyZW50Q29udGV4dCA9IG1hdGNoZXNbaW5kZXggLSAxXT8uY29udGV4dCA/PyByb3V0ZXIub3B0aW9ucy5jb250ZXh0ID8/IHt9O1xuXHRcdGNvbnN0IGNvbW1vbiA9IHtcblx0XHRcdHBhcmFtczogbWF0Y2gucGFyYW1zLFxuXHRcdFx0bG9jYXRpb24sXG5cdFx0XHRuYXZpZ2F0ZTogKG9wdHMpID0+IHJvdXRlci5uYXZpZ2F0ZSh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdF9mcm9tTG9jYXRpb246IGxvY2F0aW9uXG5cdFx0XHR9KSxcblx0XHRcdGJ1aWxkTG9jYXRpb246IHJvdXRlci5idWlsZExvY2F0aW9uLFxuXHRcdFx0Y2F1c2U6IHByZWxvYWQgPyBcInByZWxvYWRcIiA6IG1hdGNoLmNhdXNlLFxuXHRcdFx0YWJvcnRDb250cm9sbGVyOiBvcHRpb25zWzBdLFxuXHRcdFx0cHJlbG9hZCxcblx0XHRcdG1hdGNoZXMsXG5cdFx0XHRyb3V0ZUlkOiByb3V0ZS5pZFxuXHRcdH07XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IHJvdXRlQ29udGV4dCA9IG1hdGNoLl9jdHggfHw9IHJvdXRlLm9wdGlvbnMuY29udGV4dCA/IHJvdXRlLm9wdGlvbnMuY29udGV4dCh7XG5cdFx0XHRcdC4uLmNvbW1vbixcblx0XHRcdFx0ZGVwczogbWF0Y2gubG9hZGVyRGVwcyxcblx0XHRcdFx0Y29udGV4dDogcGFyZW50Q29udGV4dFxuXHRcdFx0fSkgfHwge30gOiB2b2lkIDA7XG5cdFx0XHRtYXRjaC5jb250ZXh0ID0ge1xuXHRcdFx0XHQuLi5wYXJlbnRDb250ZXh0LFxuXHRcdFx0XHQuLi5yb3V0ZUNvbnRleHRcblx0XHRcdH07XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaCk7XG5cdFx0XHRyZXR1cm4gW2luZGV4LCBub3JtYWxpemVMYW5lRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIG9wdGlvbnMpXTtcblx0XHR9XG5cdFx0aWYgKHNpZ25hbC5hYm9ydGVkKSByZXR1cm4gW2luZGV4LCBDQU5DRUxFRF9PVVRDT01FXTtcblx0XHRjb25zdCB2YWxpZGF0aW9uRXJyb3IgPSBtYXRjaC5wYXJhbXNFcnJvciA/PyBtYXRjaC5zZWFyY2hFcnJvcjtcblx0XHRpZiAodmFsaWRhdGlvbkVycm9yICE9PSB2b2lkIDApIHtcblx0XHRcdHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaCk7XG5cdFx0XHRyZXR1cm4gW2luZGV4LCBub3JtYWxpemVMYW5lRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgdmFsaWRhdGlvbkVycm9yLCBvcHRpb25zKV07XG5cdFx0fVxuXHRcdGNvbnN0IGJlZm9yZUxvYWQgPSByb3V0ZS5vcHRpb25zLmJlZm9yZUxvYWQ7XG5cdFx0aWYgKCFiZWZvcmVMb2FkKSBjb250aW51ZTtcblx0XHRjb25zdCBwcmV2aW91c1N0YXR1cyA9IG1hdGNoLnN0YXR1cztcblx0XHRpZiAoaW5kZXggPj0gcmV0YWluZWRFbmQpIHtcblx0XHRcdG1hdGNoLnN0YXR1cyA9IFwicGVuZGluZ1wiO1xuXHRcdFx0b3B0aW9uc1s3XT8uKCk7XG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHRzZXRGZXRjaGluZyhyb3V0ZXIsIG1hdGNoLCBcImJlZm9yZUxvYWRcIiwgb3B0aW9uc1swXSk7XG5cdFx0XHRjb25zdCB2YWx1ZSA9IGJlZm9yZUxvYWQoe1xuXHRcdFx0XHQuLi5jb21tb24sXG5cdFx0XHRcdHNlYXJjaDogbWF0Y2guc2VhcmNoLFxuXHRcdFx0XHRjb250ZXh0OiBtYXRjaC5jb250ZXh0LFxuXHRcdFx0XHQuLi5yb3V0ZXIub3B0aW9ucy5hZGRpdGlvbmFsQ29udGV4dFxuXHRcdFx0fSk7XG5cdFx0XHRjb25zdCByZXN1bHQgPSBhd2FpdCAodHlwZW9mIHZhbHVlPy50aGVuID09PSBcImZ1bmN0aW9uXCIgPyB3YWl0Rm9yKHZhbHVlLCBzaWduYWwpIDogdmFsdWUpO1xuXHRcdFx0aWYgKHNpZ25hbC5hYm9ydGVkKSByZXR1cm4gW2luZGV4LCBDQU5DRUxFRF9PVVRDT01FXTtcblx0XHRcdGNvbnN0IG91dGNvbWUgPSBtYXRlcmlhbGl6ZVJlZGlyZWN0KHJvdXRlciwgbGFuZSwgcm91dGUsIG5vcm1hbGl6ZShyZXN1bHQsIGZhbHNlLCByb3V0ZS5pZCksIG9wdGlvbnMpO1xuXHRcdFx0aWYgKG91dGNvbWVbMF0gIT09IFNVQ0NFU1MpIHtcblx0XHRcdFx0cmVsZWFzZUZsaWdodChyb3V0ZXIsIG1hdGNoKTtcblx0XHRcdFx0cmV0dXJuIFtpbmRleCwgb3V0Y29tZV07XG5cdFx0XHR9XG5cdFx0XHRtYXRjaC5jb250ZXh0ID0ge1xuXHRcdFx0XHQuLi5tYXRjaC5jb250ZXh0LFxuXHRcdFx0XHQuLi5yZXN1bHRcblx0XHRcdH07XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaCk7XG5cdFx0XHRyZXR1cm4gW2luZGV4LCBub3JtYWxpemVMYW5lRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIG9wdGlvbnMpXTtcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0bWF0Y2guc3RhdHVzID0gcHJldmlvdXNTdGF0dXM7XG5cdFx0XHRzZXRGZXRjaGluZyhyb3V0ZXIsIG1hdGNoLCBmYWxzZSwgb3B0aW9uc1swXSk7XG5cdFx0fVxuXHR9XG5cdHBsYW5TdWNjZXNzZnVsTGFuZSgpO1xufVxuZnVuY3Rpb24gcmVsZWFzZU93bmVkRmxpZ2h0KHJvdXRlciwgbWF0Y2gsIGZsaWdodCkge1xuXHRpZiAoIWZsaWdodCB8fCAtLWZsaWdodFsyXSkgcmV0dXJuO1xuXHRpZiAocm91dGVyLl9mbGlnaHRzPy5nZXQobWF0Y2guaWQpID09PSBmbGlnaHQpIHtcblx0XHRjb25zdCBjdXJyZW50ID0gcm91dGVyLl90eDtcblx0XHRpZiAoY3VycmVudCAmJiAhY3VycmVudFswXS5zaWduYWwuYWJvcnRlZCAmJiAhY3VycmVudFszXS5pbmNsdWRlcyhtYXRjaCkgJiYgY3VycmVudFszXS5zb21lKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5pZCA9PT0gbWF0Y2guaWQpICYmIGN1cnJlbnRbM10uc29tZSgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaXNGZXRjaGluZyA9PT0gXCJiZWZvcmVMb2FkXCIpKSByZXR1cm47XG5cdFx0cm91dGVyLl9mbGlnaHRzLmRlbGV0ZShtYXRjaC5pZCk7XG5cdH1cblx0cmV0dXJuIGZsaWdodFsxXTtcbn1cbmZ1bmN0aW9uIHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaCkge1xuXHRjb25zdCBmbGlnaHQgPSBtYXRjaC5fZmxpZ2h0O1xuXHRtYXRjaC5fZmxpZ2h0ID0gdm9pZCAwO1xuXHRyZWxlYXNlT3duZWRGbGlnaHQocm91dGVyLCBtYXRjaCwgZmxpZ2h0KT8uYWJvcnQoKTtcbn1cbi8qKlxuKiBOb3QgcGFzc2luZyBpbiBhIGBuZXh0YCBvd25lcnNoaXAgcmVjaXBpZW50XG4qIGlzIGVxdWl2YWxlbnQgdG8gZGlzY2FyZGluZyB0aGUgbWF0Y2ggcmVzb3VyY2VzXG4qL1xuZnVuY3Rpb24gdHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIHByZXZpb3VzLCBuZXh0LCBkZWZlclNhbWVJZEZsaWdodCkge1xuXHRjb25zdCBhYm9ydCA9IFtdO1xuXHRmb3IgKGNvbnN0IG1hdGNoIG9mIHByZXZpb3VzKSBpZiAoIW5leHQ/LmluY2x1ZGVzKG1hdGNoKSkge1xuXHRcdGNvbnN0IGZsaWdodCA9IG1hdGNoLl9mbGlnaHQ7XG5cdFx0bWF0Y2guX2ZsaWdodCA9IHZvaWQgMDtcblx0XHRpZiAoZGVmZXJTYW1lSWRGbGlnaHQgJiYgZmxpZ2h0Py5bMl0gPT09IDEgJiYgcm91dGVyLl9mbGlnaHRzPy5nZXQobWF0Y2guaWQpID09PSBmbGlnaHQgJiYgbmV4dD8uc29tZSgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgPT09IG1hdGNoLmlkKSkgZmxpZ2h0WzJdID0gMDtcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGNvbnRyb2xsZXIgPSByZWxlYXNlT3duZWRGbGlnaHQocm91dGVyLCBtYXRjaCwgZmxpZ2h0KTtcblx0XHRcdGlmIChjb250cm9sbGVyKSBhYm9ydC5wdXNoKGNvbnRyb2xsZXIpO1xuXHRcdH1cblx0fVxuXHRmb3IgKGNvbnN0IGNvbnRyb2xsZXIgb2YgYWJvcnQpIGNvbnRyb2xsZXIuYWJvcnQoKTtcbn1cbmZ1bmN0aW9uIGFjcXVpcmVNYXRjaFJlc291cmNlcyhtYXRjaGVzKSB7XG5cdGZvciAoY29uc3QgbWF0Y2ggb2YgbWF0Y2hlcykge1xuXHRcdGNvbnN0IGZsaWdodCA9IG1hdGNoLl9mbGlnaHQ7XG5cdFx0aWYgKGZsaWdodCkgZmxpZ2h0WzJdKys7XG5cdH1cbn1cbmZ1bmN0aW9uIHNldEZldGNoaW5nKHJvdXRlciwgbWF0Y2gsIHZhbHVlLCBvd25lcikge1xuXHRtYXRjaC5pc0ZldGNoaW5nID0gdmFsdWU7XG5cdGlmIChvd25lciAmJiByb3V0ZXIuX3R4Py5bMF0gIT09IG93bmVyKSByZXR1cm47XG5cdGNvbnN0IHN0b3JlID0gcm91dGVyLnN0b3Jlcy5ieVJvdXRlLmdldChtYXRjaC5yb3V0ZUlkKTtcblx0Y29uc3QgcHJlc2VudGVkID0gc3RvcmU/LmdldCgpO1xuXHRpZiAocHJlc2VudGVkPy5pZCA9PT0gbWF0Y2guaWQpIHN0b3JlLnNldCh7XG5cdFx0Li4ucHJlc2VudGVkLFxuXHRcdGlzRmV0Y2hpbmc6IHZhbHVlXG5cdH0pO1xufVxuZnVuY3Rpb24gZ2V0TG9hZGVyQ29udGV4dChyb3V0ZXIsIGxhbmUsIG1hdGNoLCByb3V0ZSwgY29udHJvbGxlciwgcGFyZW50TWF0Y2hQcm9taXNlLCBwcmVsb2FkKSB7XG5cdGNvbnN0IGxvY2F0aW9uID0gbGFuZVswXTtcblx0cmV0dXJuIHtcblx0XHRwYXJhbXM6IG1hdGNoLnBhcmFtcyxcblx0XHRsb2NhdGlvbixcblx0XHRuYXZpZ2F0ZTogKG9wdHMpID0+IHJvdXRlci5uYXZpZ2F0ZSh7XG5cdFx0XHQuLi5vcHRzLFxuXHRcdFx0X2Zyb21Mb2NhdGlvbjogbG9jYXRpb25cblx0XHR9KSxcblx0XHRjYXVzZTogcHJlbG9hZCA/IFwicHJlbG9hZFwiIDogbWF0Y2guY2F1c2UsXG5cdFx0YWJvcnRDb250cm9sbGVyOiBjb250cm9sbGVyLFxuXHRcdHByZWxvYWQsXG5cdFx0ZGVwczogbWF0Y2gubG9hZGVyRGVwcyxcblx0XHRwYXJlbnRNYXRjaFByb21pc2UsXG5cdFx0Y29udGV4dDogbWF0Y2guY29udGV4dCxcblx0XHRyb3V0ZSxcblx0XHQuLi5yb3V0ZXIub3B0aW9ucy5hZGRpdGlvbmFsQ29udGV4dFxuXHR9O1xufVxuYXN5bmMgZnVuY3Rpb24gbG9hZFJlc291cmNlKHJvdXRlciwgbGFuZSwgbWF0Y2gsIHJvdXRlLCBsb2FkZXIsIHBhcmVudE1hdGNoUHJvbWlzZSwgb3B0aW9ucykge1xuXHRjb25zdCBvd25lciA9IG9wdGlvbnNbMF07XG5cdGNvbnN0IHNpZ25hbCA9IG93bmVyLnNpZ25hbDtcblx0aWYgKHNpZ25hbC5hYm9ydGVkKSByZXR1cm4gQ0FOQ0VMRURfT1VUQ09NRTtcblx0aWYgKCFsb2FkZXIpIHJldHVybiBbU1VDQ0VTUywgdm9pZCAwXTtcblx0bGV0IGZsaWdodCA9IG1hdGNoLl9mbGlnaHQ7XG5cdHNldEZldGNoaW5nKHJvdXRlciwgbWF0Y2gsIFwibG9hZGVyXCIsIG93bmVyKTtcblx0dHJ5IHtcblx0XHRpZiAoIWZsaWdodCkge1xuXHRcdFx0Y29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRcdGZsaWdodCA9IFtcblx0XHRcdFx0UHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiBsb2FkZXIoZ2V0TG9hZGVyQ29udGV4dChyb3V0ZXIsIGxhbmUsIG1hdGNoLCByb3V0ZSwgY29udHJvbGxlciwgcGFyZW50TWF0Y2hQcm9taXNlLCAhIW9wdGlvbnNbM10pKSkudGhlbigodmFsdWUpID0+IG5vcm1hbGl6ZSh2YWx1ZSwgZmFsc2UsIHJvdXRlLmlkKSwgKGNhdXNlKSA9PiBub3JtYWxpemUoY2F1c2UsIHRydWUsIHJvdXRlLmlkKSkudGhlbigocmVzdWx0KSA9PiB7XG5cdFx0XHRcdFx0aWYgKHJlc3VsdFswXSAhPT0gU1VDQ0VTUyAmJiByb3V0ZXIuX2ZsaWdodHM/LmdldChtYXRjaC5pZCkgPT09IGZsaWdodCkge1xuXHRcdFx0XHRcdFx0cm91dGVyLl9mbGlnaHRzLmRlbGV0ZShtYXRjaC5pZCk7XG5cdFx0XHRcdFx0XHRpZiAoIWZsaWdodFsyXSkgY29udHJvbGxlci5hYm9ydCgpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRyZXR1cm4gcmVzdWx0WzBdID09PSBFUlJPUiAmJiBmbGlnaHRbMl0gPyBub3JtYWxpemVFcnJvcihyb3V0ZSwgcmVzdWx0WzFdKSA6IHJlc3VsdDtcblx0XHRcdFx0fSksXG5cdFx0XHRcdGNvbnRyb2xsZXIsXG5cdFx0XHRcdDFcblx0XHRcdF07XG5cdFx0XHQocm91dGVyLl9mbGlnaHRzID8/PSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKS5zZXQobWF0Y2guaWQsIGZsaWdodCk7XG5cdFx0fVxuXHRcdG1hdGNoLl9mbGlnaHQgPSBmbGlnaHQ7XG5cdFx0bWF0Y2guYWJvcnRDb250cm9sbGVyID0gZmxpZ2h0WzFdO1xuXHRcdHJldHVybiBtYXRlcmlhbGl6ZVJlZGlyZWN0KHJvdXRlciwgbGFuZSwgcm91dGUsIGF3YWl0IHdhaXRGb3IoZmxpZ2h0WzBdLCBzaWduYWwpLCBvcHRpb25zKTtcblx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRpZiAoY2F1c2UgIT09IHNpZ25hbCB8fCAhc2lnbmFsLmFib3J0ZWQpIHRocm93IGNhdXNlO1xuXHRcdHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaCk7XG5cdFx0cmV0dXJuIENBTkNFTEVEX09VVENPTUU7XG5cdH0gZmluYWxseSB7XG5cdFx0c2V0RmV0Y2hpbmcocm91dGVyLCBtYXRjaCwgZmFsc2UsIG93bmVyKTtcblx0fVxufVxuZnVuY3Rpb24gc2V0dGxlSW50byhtYXRjaCwgcmVzdWx0LCBwcmVsb2FkKSB7XG5cdGlmIChyZXN1bHRbMF0gPT09IFJFRElSRUNURUQpIHJldHVybjtcblx0bWF0Y2guc3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdG1hdGNoLmVycm9yID0gdm9pZCAwO1xuXHRpZiAocmVzdWx0WzBdID09PSBTVUNDRVNTKSB7XG5cdFx0bWF0Y2gubG9hZGVyRGF0YSA9IHJlc3VsdFsxXTtcblx0XHRtYXRjaC5pbnZhbGlkID0gZmFsc2U7XG5cdFx0bWF0Y2gudXBkYXRlZEF0ID0gRGF0ZS5ub3coKTtcblx0XHRtYXRjaC5wcmVsb2FkID0gcHJlbG9hZDtcblx0fSBlbHNlIG1hdGNoLmludmFsaWQgPSB0cnVlO1xufVxuZnVuY3Rpb24gY2FjaGVMb2FkZXJNYXRjaChyb3V0ZXIsIG1hdGNoLCBwbGFubmVkKSB7XG5cdGNvbnN0IGN1cnJlbnQgPSByb3V0ZXIuX2NhY2hlLmdldChtYXRjaC5pZCk7XG5cdGlmIChjdXJyZW50ICE9PSBwbGFubmVkIHx8IHJvdXRlci5fY29tbWl0dGVkLnNvbWUoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSBtYXRjaC5pZCAmJiBjYW5kaWRhdGUuX2ZsaWdodCA9PT0gbWF0Y2guX2ZsaWdodCkpIHJldHVybjtcblx0Y29uc3QgY2FjaGVkID0ge1xuXHRcdC4uLm1hdGNoLFxuXHRcdF9ub3RGb3VuZDogdm9pZCAwLFxuXHRcdGNvbnRleHQ6IHt9XG5cdH07XG5cdGlmIChjYWNoZWQuX2ZsaWdodCkgY2FjaGVkLl9mbGlnaHRbMl0rKztcblx0cm91dGVyLl9jYWNoZS5zZXQobWF0Y2guaWQsIGNhY2hlZCk7XG5cdGlmIChjdXJyZW50KSByZWxlYXNlRmxpZ2h0KHJvdXRlciwgY3VycmVudCk7XG59XG5mdW5jdGlvbiBnZXRQYXJlbnRTbmFwc2hvdChtYXRjaCwgb3V0Y29tZSkge1xuXHRpZiAob3V0Y29tZVswXSA9PT0gRVJST1IgfHwgb3V0Y29tZVswXSA9PT0gTk9UX0ZPVU5EKSByZXR1cm4ge1xuXHRcdC4uLm1hdGNoLFxuXHRcdHN0YXR1czogb3V0Y29tZVswXSA9PT0gRVJST1IgPyBcImVycm9yXCIgOiBcIm5vdEZvdW5kXCIsXG5cdFx0ZXJyb3I6IG91dGNvbWVbMV0sXG5cdFx0X2ZsaWdodDogdm9pZCAwXG5cdH07XG5cdHJldHVybiBtYXRjaDtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUxvYWRlclRhc2socm91dGVyLCBsYW5lLCBpbmRleCwgdGFza3MsIHNlbWFudGljUGFyZW50LCBvcHRpb25zLCByZXRhaW5lZEVuZCkge1xuXHRjb25zdCBtYXRjaCA9IGxhbmVbMV1baW5kZXhdO1xuXHRjb25zdCByb3V0ZSA9IGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpO1xuXHRjb25zdCBwcmVsb2FkID0gISFvcHRpb25zWzNdO1xuXHRjb25zdCBwbGFubmVkQ2FjaGVNYXRjaCA9IHJvdXRlci5fY2FjaGUuZ2V0KG1hdGNoLmlkKTtcblx0bGV0IGNvbmZpZ3VyZWQ7XG5cdGxldCByZWxvYWQgPSBmYWxzZTtcblx0bGV0IHJlbG9hZEZhaWx1cmU7XG5cdHRyeSB7XG5cdFx0aWYgKG1hdGNoLnN0YXR1cyA9PT0gXCJzdWNjZXNzXCIpIHtcblx0XHRcdGNvbmZpZ3VyZWQgPSByb3V0ZS5vcHRpb25zLnNob3VsZFJlbG9hZDtcblx0XHRcdGlmICh0eXBlb2YgY29uZmlndXJlZCA9PT0gXCJmdW5jdGlvblwiKSBjb25maWd1cmVkID0gY29uZmlndXJlZChnZXRMb2FkZXJDb250ZXh0KHJvdXRlciwgbGFuZSwgbWF0Y2gsIHJvdXRlLCBvcHRpb25zWzBdLCBzZW1hbnRpY1BhcmVudCwgcHJlbG9hZCkpO1xuXHRcdFx0aWYgKG9wdGlvbnNbMF0uc2lnbmFsLmFib3J0ZWQpIHJlbG9hZEZhaWx1cmUgPSBDQU5DRUxFRF9PVVRDT01FO1xuXHRcdH1cblx0XHRpZiAoIXJlbG9hZEZhaWx1cmUpIHtcblx0XHRcdGlmIChtYXRjaC5zdGF0dXMgIT09IFwic3VjY2Vzc1wiKSByZWxvYWQgPSB0cnVlO1xuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdGNvbnN0IHN0YWxlQWdlID0gcHJlbG9hZCB8fCBtYXRjaC5wcmVsb2FkID8gcm91dGUub3B0aW9ucy5wcmVsb2FkU3RhbGVUaW1lID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRQcmVsb2FkU3RhbGVUaW1lID8/IDNlNCA6IHJvdXRlLm9wdGlvbnMuc3RhbGVUaW1lID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRTdGFsZVRpbWUgPz8gMDtcblx0XHRcdFx0cmVsb2FkID0gISEobWF0Y2guaW52YWxpZCB8fCBjb25maWd1cmVkIHx8IGNvbmZpZ3VyZWQgPT09IHZvaWQgMCAmJiBEYXRlLm5vdygpIC0gbWF0Y2gudXBkYXRlZEF0ID49IHN0YWxlQWdlICYmIChvcHRpb25zWzVdIHx8IG1hdGNoLmNhdXNlID09PSBcImVudGVyXCIgfHwgb3B0aW9uc1syXS5zb21lKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5yb3V0ZUlkID09PSBtYXRjaC5yb3V0ZUlkICYmIGNhbmRpZGF0ZS5pZCAhPT0gbWF0Y2guaWQpKSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdG1hdGNoLmludmFsaWQgPSB0cnVlO1xuXHRcdHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaCk7XG5cdFx0cmVsb2FkRmFpbHVyZSA9IG5vcm1hbGl6ZUxhbmVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCBjYXVzZSwgb3B0aW9ucyk7XG5cdH1cblx0Y29uc3Qgcm91dGVMb2FkZXIgPSByb3V0ZS5vcHRpb25zLmxvYWRlcjtcblx0Y29uc3QgaXNMb2FkZXJGbiA9IHR5cGVvZiByb3V0ZUxvYWRlciA9PT0gXCJmdW5jdGlvblwiO1xuXHRjb25zdCBsb2FkZXIgPSBpc0xvYWRlckZuID8gcm91dGVMb2FkZXIgOiByb3V0ZUxvYWRlcj8uaGFuZGxlcjtcblx0Y29uc3QgcHJlbG9hZGFibGUgPSAhcHJlbG9hZCB8fCByb3V0ZS5vcHRpb25zLnByZWxvYWQgIT09IGZhbHNlO1xuXHRsZXQgZG9ub3IgPSBwcmVsb2FkYWJsZSAmJiByb3V0ZUxvYWRlciAmJiAhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiByb3V0ZXIuX3R4Py5bNl0pID8gcm91dGVyLl9mbGlnaHRzPy5nZXQobWF0Y2guaWQpIDogdm9pZCAwO1xuXHRpZiAoZG9ub3IgPT09IG1hdGNoLl9mbGlnaHQgfHwgcmVsb2FkRmFpbHVyZSkgZG9ub3IgPSB2b2lkIDA7XG5cdGVsc2UgaWYgKGRvbm9yICYmICFyZWxvYWQgJiYgIXByZWxvYWQgJiYgY29uZmlndXJlZCA9PT0gdm9pZCAwKSByZWxvYWQgPSB0cnVlO1xuXHRlbHNlIGlmICghcmVsb2FkKSBkb25vciA9IHZvaWQgMDtcblx0Y29uc3QgYmFja2dyb3VuZCA9ICEhKHJvdXRlTG9hZGVyICYmIHJlbG9hZCAmJiBtYXRjaC5zdGF0dXMgPT09IFwic3VjY2Vzc1wiICYmICFwcmVsb2FkICYmICFvcHRpb25zWzRdICYmICgoaXNMb2FkZXJGbiA/IHZvaWQgMCA6IHJvdXRlTG9hZGVyLnN0YWxlUmVsb2FkTW9kZSkgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFN0YWxlUmVsb2FkTW9kZSkgIT09IFwiYmxvY2tpbmdcIik7XG5cdGNvbnN0IGxvYWRlZCA9IHJlbG9hZCAmJiBwcmVsb2FkYWJsZTtcblx0Y29uc3QgYmxvY2tpbmcgPSBsb2FkZWQgJiYgIWJhY2tncm91bmQgJiYgKG1hdGNoLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgfHwgISFyb3V0ZUxvYWRlcik7XG5cdGNvbnN0IG9uUmVhZHkgPSBpbmRleCA+PSByZXRhaW5lZEVuZCA/IG9wdGlvbnNbN10gOiB2b2lkIDA7XG5cdGNvbnN0IG9uTGF6eVJlYWR5ID0gcm91dGUubGF6eUZuICYmIHJvdXRlLl9sYXp5ICE9PSB0cnVlID8gb25SZWFkeSA6IHZvaWQgMDtcblx0aWYgKGxvYWRlZCAmJiAhcm91dGVMb2FkZXIpIHtcblx0XHRtYXRjaC5pbnZhbGlkID0gZmFsc2U7XG5cdFx0bWF0Y2gudXBkYXRlZEF0ID0gRGF0ZS5ub3coKTtcblx0fVxuXHRpZiAoZG9ub3IpIGRvbm9yWzJdKys7XG5cdGlmIChibG9ja2luZykge1xuXHRcdGNvbnN0IGFjY2VwdGVkRmxpZ2h0ID0gbWF0Y2guX2ZsaWdodDtcblx0XHRtYXRjaC5fZmxpZ2h0ID0gZG9ub3I7XG5cdFx0cmVsZWFzZU93bmVkRmxpZ2h0KHJvdXRlciwgbWF0Y2gsIGFjY2VwdGVkRmxpZ2h0KT8uYWJvcnQoKTtcblx0XHRpZiAoaW5kZXggPj0gcmV0YWluZWRFbmQpIG1hdGNoLnN0YXR1cyA9IFwicGVuZGluZ1wiO1xuXHRcdG9uUmVhZHk/LigpO1xuXHR9XG5cdGlmICghbG9hZGVkKSBtYXRjaC5pc0ZldGNoaW5nID0gZmFsc2U7XG5cdGNvbnN0IG91dGNvbWUgPSAhcmVsb2FkRmFpbHVyZSAmJiBibG9ja2luZyA/IGxvYWRSZXNvdXJjZShyb3V0ZXIsIGxhbmUsIG1hdGNoLCByb3V0ZSwgbG9hZGVyLCBzZW1hbnRpY1BhcmVudCwgb3B0aW9ucykudGhlbigocmVzdWx0KSA9PiB7XG5cdFx0c2V0dGxlSW50byhtYXRjaCwgcmVzdWx0LCBwcmVsb2FkKTtcblx0XHRpZiAocmVzdWx0WzBdID09PSBTVUNDRVNTKSB7XG5cdFx0XHRpZiAocm91dGVMb2FkZXIgJiYgIW9wdGlvbnNbMF0uc2lnbmFsLmFib3J0ZWQpIGNhY2hlTG9hZGVyTWF0Y2gocm91dGVyLCBtYXRjaCwgcGxhbm5lZENhY2hlTWF0Y2gpO1xuXHRcdFx0aWYgKGluZGV4ID49IHJldGFpbmVkRW5kKSBtYXRjaC5zdGF0dXMgPSBcInBlbmRpbmdcIjtcblx0XHR9XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fSkgOiBQcm9taXNlLnJlc29sdmUocmVsb2FkRmFpbHVyZSA/PyBbU1VDQ0VTUywgbWF0Y2gubG9hZGVyRGF0YV0pO1xuXHRjb25zdCBjaHVua0ZhaWx1cmUgPSAoYXN5bmMgKCkgPT4ge1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBjaHVuayA9IGxvYWRSb3V0ZUNodW5rKHJvdXRlLCB2b2lkIDAsIG9uTGF6eVJlYWR5KTtcblx0XHRcdGlmIChjaHVuaykgYXdhaXQgd2FpdEZvcihjaHVuaywgb3B0aW9uc1swXS5zaWduYWwpO1xuXHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRpZiAoIWxhbmVbMV0uc29tZSgoY2FuZGlkYXRlLCBjYW5kaWRhdGVJbmRleCkgPT4gY2FuZGlkYXRlSW5kZXggPD0gaW5kZXggJiYgKGNhbmRpZGF0ZS5zdGF0dXMgPT09IFwiZXJyb3JcIiB8fCBjYW5kaWRhdGUuc3RhdHVzID09PSBcIm5vdEZvdW5kXCIgfHwgY2FuZGlkYXRlLl9ub3RGb3VuZCkpKSByZXR1cm4gW2luZGV4LCBub3JtYWxpemVMYW5lRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIG9wdGlvbnMpXTtcblx0XHR9XG5cdFx0Y29uc3QgcmVzdWx0ID0gYXdhaXQgb3V0Y29tZTtcblx0XHRpZiAoYmxvY2tpbmcgJiYgcmVzdWx0WzBdID09PSBTVUNDRVNTICYmIG1hdGNoLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgJiYgIW9wdGlvbnNbMF0uc2lnbmFsLmFib3J0ZWQpIHtcblx0XHRcdG1hdGNoLnN0YXR1cyA9IFwic3VjY2Vzc1wiO1xuXHRcdFx0b25SZWFkeT8uKCk7XG5cdFx0fVxuXHR9KSgpO1xuXHR0YXNrcy5wdXNoKFtcblx0XHRpbmRleCxcblx0XHRvdXRjb21lLFxuXHRcdGNodW5rRmFpbHVyZVxuXHRdKTtcblx0aWYgKCFiYWNrZ3JvdW5kKSByZXR1cm4gb3V0Y29tZS50aGVuKChyZXN1bHQpID0+IGdldFBhcmVudFNuYXBzaG90KG1hdGNoLCByZXN1bHQpKTtcblx0Y29uc3QgY2FuZGlkYXRlID0ge1xuXHRcdC4uLm1hdGNoLFxuXHRcdHN0YXR1czogXCJwZW5kaW5nXCIsXG5cdFx0cHJlbG9hZDogZmFsc2UsXG5cdFx0X2ZsaWdodDogZG9ub3Jcblx0fTtcblx0bWF0Y2guaW52YWxpZCA9IGZhbHNlO1xuXHRtYXRjaC5pc0ZldGNoaW5nID0gXCJsb2FkZXJcIjtcblx0Y29uc3QgYmFja2dyb3VuZE91dGNvbWUgPSBsb2FkUmVzb3VyY2Uocm91dGVyLCBsYW5lLCBjYW5kaWRhdGUsIHJvdXRlLCBsb2FkZXIsIHNlbWFudGljUGFyZW50LCBvcHRpb25zKS50aGVuKChyZXN1bHQpID0+IHtcblx0XHRtYXRjaC5pc0ZldGNoaW5nID0gZmFsc2U7XG5cdFx0c2V0dGxlSW50byhjYW5kaWRhdGUsIHJlc3VsdCwgZmFsc2UpO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH0pO1xuXHQobGFuZVsyXSA/Pz0gW10pLnB1c2goW1xuXHRcdGluZGV4LFxuXHRcdGJhY2tncm91bmRPdXRjb21lLFxuXHRcdGNodW5rRmFpbHVyZSxcblx0XHRjYW5kaWRhdGVcblx0XSk7XG5cdHJldHVybiBiYWNrZ3JvdW5kT3V0Y29tZS50aGVuKChyZXN1bHQpID0+IGdldFBhcmVudFNuYXBzaG90KGNhbmRpZGF0ZSwgcmVzdWx0KSk7XG59XG5hc3luYyBmdW5jdGlvbiBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbWF0Y2hlcywgaW5kZXhlZCwgc2lnbmFsLCBmYWxsYmFjayA9IDApIHtcblx0Y29uc3QgY2F1c2UgPSBpbmRleGVkPy5bMV1bMV07XG5cdGxldCBpbmRleCA9IGNhdXNlPy5yb3V0ZUlkID8gbWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5yb3V0ZUlkID09PSBjYXVzZS5yb3V0ZUlkKSA6IGluZGV4ZWQ/LlswXSA/PyBtYXRjaGVzLmxlbmd0aCAtIDE7XG5cdGlmIChpbmRleCA8IDApIGluZGV4ID0gMDtcblx0Zm9yIChsZXQgaSA9IGluZGV4OyBpID49IDA7IGktLSkge1xuXHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaGVzW2ldKTtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3QgbG9hZGluZyA9IGxvYWRSb3V0ZUNodW5rKHJvdXRlLCBmYWxzZSk7XG5cdFx0XHRpZiAobG9hZGluZykgYXdhaXQgd2FpdEZvcihsb2FkaW5nLCBzaWduYWwpO1xuXHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRpZiAoY2F1c2UgPT09IHNpZ25hbCAmJiBzaWduYWwuYWJvcnRlZCkgdGhyb3cgY2F1c2U7XG5cdFx0fVxuXHRcdGlmIChyb3V0ZS5vcHRpb25zLm5vdEZvdW5kQ29tcG9uZW50KSByZXR1cm4gaTtcblx0fVxuXHRyZXR1cm4gY2F1c2U/LnJvdXRlSWQgPyBpbmRleCA6IGZhbGxiYWNrO1xufVxuZnVuY3Rpb24gZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCBsYW5lKSB7XG5cdGlmIChsYW5lWzJdKSB7XG5cdFx0dHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIGxhbmVbMl0ubWFwKCh0YXNrKSA9PiB0YXNrWzNdKSk7XG5cdFx0bGFuZVsyXSA9IHZvaWQgMDtcblx0fVxufVxuYXN5bmMgZnVuY3Rpb24gc2V0dGxlVGFza3ModGFza3MsIHNlcmlhbEZhaWx1cmUsIHJlZGlyZWN0VGFza3MsIGdhdGUpIHtcblx0bGV0IGxvYWRlckZhaWx1cmU7XG5cdHRyeSB7XG5cdFx0YXdhaXQgUHJvbWlzZS5hbGwodGFza3MubWFwKCh0YXNrKSA9PiB0YXNrWzFdLnRoZW4oYXN5bmMgKG91dGNvbWUpID0+IHtcblx0XHRcdGNvbnN0IHRhc2tJbmRleCA9IHRhc2tbMF07XG5cdFx0XHRpZiAoZ2F0ZSAmJiB0YXNrSW5kZXggPj0gYXdhaXQgZ2F0ZSkgcmV0dXJuO1xuXHRcdFx0aWYgKG91dGNvbWVbMF0gPj0gUkVESVJFQ1RFRCkgdGhyb3cgW3Rhc2tJbmRleCwgb3V0Y29tZV07XG5cdFx0XHRpZiAoIWxvYWRlckZhaWx1cmUgJiYgb3V0Y29tZVswXSAhPT0gU1VDQ0VTUykge1xuXHRcdFx0XHRsb2FkZXJGYWlsdXJlID0gW3Rhc2tJbmRleCwgb3V0Y29tZV07XG5cdFx0XHRcdGF3YWl0IFByb21pc2UuYWxsKChyZWRpcmVjdFRhc2tzID8/IFtdKS5tYXAoKG5leHRUYXNrKSA9PiB7XG5cdFx0XHRcdFx0aWYgKG5leHRUYXNrWzBdIDw9IHRhc2tJbmRleCkgcmV0dXJuO1xuXHRcdFx0XHRcdHJldHVybiBuZXh0VGFza1sxXS50aGVuKChuZXh0T3V0Y29tZSkgPT4ge1xuXHRcdFx0XHRcdFx0aWYgKG5leHRPdXRjb21lWzBdID09PSBSRURJUkVDVEVEKSB0aHJvdyBbbmV4dFRhc2tbMF0sIG5leHRPdXRjb21lXTtcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0fSkpO1xuXHRcdFx0fVxuXHRcdH0pKSk7XG5cdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0cmV0dXJuIGNhdXNlO1xuXHR9XG5cdHJldHVybiBzZXJpYWxGYWlsdXJlID8/IGxvYWRlckZhaWx1cmU7XG59XG5mdW5jdGlvbiBtYXRlcmlhbGl6ZVJlZGlyZWN0KHJvdXRlciwgbGFuZSwgcm91dGUsIG91dGNvbWUsIG9wdGlvbnMsIGZhaWxlZCkge1xuXHR3aGlsZSAob3V0Y29tZVswXSA9PT0gUkVESVJFQ1RFRCkge1xuXHRcdGNvbnN0IHJlZGlyZWN0ID0gb3V0Y29tZVsxXTtcblx0XHRjb25zdCByZWRpcmVjdE9wdGlvbnMgPSByZWRpcmVjdC5vcHRpb25zO1xuXHRcdHRyeSB7XG5cdFx0XHRpZiAocmVkaXJlY3RPcHRpb25zLmhyZWYgfHwgcmVkaXJlY3QuaGVhZGVycy5oYXMoXCJMb2NhdGlvblwiKSkge1xuXHRcdFx0XHRyb3V0ZXIucmVzb2x2ZVJlZGlyZWN0KHJlZGlyZWN0KTtcblx0XHRcdFx0aWYgKHJlZGlyZWN0T3B0aW9ucy5yZWxvYWREb2N1bWVudCkgcmV0dXJuIG91dGNvbWU7XG5cdFx0XHR9XG5cdFx0XHRpZiAocmVkaXJlY3RPcHRpb25zLnJlbG9hZERvY3VtZW50ID8gb3B0aW9uc1szXSA6IG9wdGlvbnNbMV0gPj0gMjApIHJldHVybiBvdXRjb21lO1xuXHRcdFx0Y29uc3QgbG9jYXRpb24gPSByb3V0ZXIuYnVpbGRMb2NhdGlvbih7XG5cdFx0XHRcdC4uLnJlZGlyZWN0T3B0aW9ucyxcblx0XHRcdFx0X2Zyb21Mb2NhdGlvbjogbGFuZVswXSxcblx0XHRcdFx0X2luY2x1ZGVWYWxpZGF0ZVNlYXJjaDogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0XHRjb25zdCBwdWJsaWNMb2NhdGlvbiA9IGxvY2F0aW9uLm1hc2tlZExvY2F0aW9uID8/IGxvY2F0aW9uO1xuXHRcdFx0aWYgKHB1YmxpY0xvY2F0aW9uLmV4dGVybmFsKSB7XG5cdFx0XHRcdGNvbnN0IHJlc29sdmVkID0gcmVkaXJlY3QuY2xvbmUoKTtcblx0XHRcdFx0cmVzb2x2ZWQub3B0aW9ucyA9IHsgLi4ucmVkaXJlY3RPcHRpb25zIH07XG5cdFx0XHRcdHJlc29sdmVkLmhlYWRlcnMuc2V0KFwiTG9jYXRpb25cIiwgcHVibGljTG9jYXRpb24ucHVibGljSHJlZik7XG5cdFx0XHRcdHJvdXRlci5yZXNvbHZlUmVkaXJlY3QocmVzb2x2ZWQpO1xuXHRcdFx0XHRyZXR1cm4gb3B0aW9uc1szXSA/IFtSRURJUkVDVEVELCByZXNvbHZlZF0gOiBbXG5cdFx0XHRcdFx0UkVESVJFQ1RFRCxcblx0XHRcdFx0XHRyZXNvbHZlZCxcblx0XHRcdFx0XHRwdWJsaWNMb2NhdGlvblxuXHRcdFx0XHRdO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIFtcblx0XHRcdFx0UkVESVJFQ1RFRCxcblx0XHRcdFx0cmVkaXJlY3QsXG5cdFx0XHRcdGxvY2F0aW9uXG5cdFx0XHRdO1xuXHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRvdXRjb21lID0gZmFpbGVkID8gW0VSUk9SLCBjYXVzZV0gOiBub3JtYWxpemVFcnJvcihyb3V0ZSwgY2F1c2UpO1xuXHRcdFx0ZmFpbGVkID0gdHJ1ZTtcblx0XHR9XG5cdH1cblx0cmV0dXJuIG91dGNvbWU7XG59XG5hc3luYyBmdW5jdGlvbiByZWR1Y2VMYW5lKHJvdXRlciwgbGFuZSwgdGFza3MsIGNvbnRyb2xsZXIsIHNldHRsZW1lbnQsIG9uUmVhZHkpIHtcblx0Y29uc3QgbWF0Y2hlcyA9IGxhbmVbMV07XG5cdGxldCBmYWlsdXJlID0gYXdhaXQgc2V0dGxlbWVudDtcblx0bGV0IHJlZGlyZWN0TGltaXRFeGNlZWRlZCA9IGZhbHNlO1xuXHRjb25zdCBwbGFubmVkQm91bmRhcnkgPSBtYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLl9ub3RGb3VuZCk7XG5cdGNvbnN0IGJvdW5kYXJ5T2YgPSAoZm91bmQpID0+IGZvdW5kWzFdWzBdID09PSBOT1RfRk9VTkQgPyBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbWF0Y2hlcywgZm91bmQsIGNvbnRyb2xsZXIuc2lnbmFsKSA6IGZvdW5kWzBdO1xuXHRsZXQgcmVhZGluZXNzRW5kID0gcGxhbm5lZEJvdW5kYXJ5IDwgMCA/IG1hdGNoZXMubGVuZ3RoIDogcGxhbm5lZEJvdW5kYXJ5O1xuXHRpZiAoKGZhaWx1cmU/LlsxXVswXSA/PyAwKSA+PSBSRURJUkVDVEVEKSByZWFkaW5lc3NFbmQgPSAwO1xuXHRlbHNlIGlmIChmYWlsdXJlKSB7XG5cdFx0cmVhZGluZXNzRW5kID0gZmFpbHVyZVsyXSA/Pz0gYXdhaXQgYm91bmRhcnlPZihmYWlsdXJlKTtcblx0XHRmb3IgKGNvbnN0IHRhc2sgb2YgdGFza3MpIHtcblx0XHRcdGlmICh0YXNrWzBdID49IHJlYWRpbmVzc0VuZCkgYnJlYWs7XG5cdFx0XHRjb25zdCBvdXRjb21lID0gYXdhaXQgdGFza1sxXTtcblx0XHRcdGlmIChvdXRjb21lWzBdICE9PSBTVUNDRVNTICYmIG91dGNvbWVbMF0gPCBSRURJUkVDVEVEICYmICEoXCJsb2FkZXJEYXRhXCIgaW4gbWF0Y2hlc1t0YXNrWzBdXSkpIHtcblx0XHRcdFx0ZmFpbHVyZSA9IFt0YXNrWzBdLCBvdXRjb21lXTtcblx0XHRcdFx0cmVhZGluZXNzRW5kID0gZmFpbHVyZVsyXSA9IGF3YWl0IGJvdW5kYXJ5T2YoZmFpbHVyZSk7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRmb3IgKGNvbnN0IHRhc2sgb2YgdGFza3MpIHtcblx0XHRpZiAodGFza1swXSA+PSByZWFkaW5lc3NFbmQpIGJyZWFrO1xuXHRcdGNvbnN0IGNodW5rRmFpbHVyZSA9IGF3YWl0IHRhc2tbMl07XG5cdFx0aWYgKCFjaHVua0ZhaWx1cmUpIGNvbnRpbnVlO1xuXHRcdGZhaWx1cmUgPSBjaHVua0ZhaWx1cmU7XG5cdFx0YnJlYWs7XG5cdH1cblx0aWYgKChmYWlsdXJlPy5bMV1bMF0gPz8gMCkgPj0gUkVESVJFQ1RFRCkge1xuXHRcdGNvbnN0IG91dGNvbWUgPSBmYWlsdXJlWzFdO1xuXHRcdGlmIChvdXRjb21lWzBdICE9PSBSRURJUkVDVEVEIHx8IG91dGNvbWVbMV0ub3B0aW9ucy5yZWxvYWREb2N1bWVudCB8fCBvdXRjb21lWzJdKSB7XG5cdFx0XHRkaXNjYXJkQmFja2dyb3VuZChyb3V0ZXIsIGxhbmUpO1xuXHRcdFx0cmV0dXJuIG91dGNvbWU7XG5cdFx0fVxuXHRcdHJlZGlyZWN0TGltaXRFeGNlZWRlZCA9IHRydWU7XG5cdFx0ZmFpbHVyZSA9IFswLCBbRVJST1IsIC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJUb28gbWFueSByZWRpcmVjdHNcIildXTtcblx0fVxuXHRjb25zdCBib3VuZGFyeSA9IGZhaWx1cmUgPyBmYWlsdXJlWzJdID8/IGF3YWl0IGJvdW5kYXJ5T2YoZmFpbHVyZSkgOiBwbGFubmVkQm91bmRhcnk7XG5cdGlmIChib3VuZGFyeSA+PSAwKSB7XG5cdFx0Y29uc3Qgb3V0Y29tZSA9IGZhaWx1cmU/LlsxXTtcblx0XHRjb25zdCBraW5kID0gb3V0Y29tZT8uWzBdO1xuXHRcdGNvbnN0IG1hdGNoID0gbWF0Y2hlc1tib3VuZGFyeV07XG5cdFx0Y29uc3QgY2F1c2UgPSBvdXRjb21lPy5bMV07XG5cdFx0Y29uc3QgaW5zdGFsbCA9ICgpID0+IHtcblx0XHRcdGlmIChvdXRjb21lKSB7XG5cdFx0XHRcdG1hdGNoLl9ub3RGb3VuZCA9IHZvaWQgMDtcblx0XHRcdFx0aWYgKGtpbmQgPT09IEVSUk9SKSBtYXRjaC5zdGF0dXMgPSBcImVycm9yXCI7XG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdGNhdXNlLnJvdXRlSWQgPSBtYXRjaC5yb3V0ZUlkO1xuXHRcdFx0XHRcdGlmIChtYXRjaC5yb3V0ZUlkID09PSByb3V0ZXIucm91dGVUcmVlLmlkKSB7XG5cdFx0XHRcdFx0XHRtYXRjaC5zdGF0dXMgPSBcInN1Y2Nlc3NcIjtcblx0XHRcdFx0XHRcdG1hdGNoLl9ub3RGb3VuZCA9IHRydWU7XG5cdFx0XHRcdFx0fSBlbHNlIG1hdGNoLnN0YXR1cyA9IFwibm90Rm91bmRcIjtcblx0XHRcdFx0fVxuXHRcdFx0XHRtYXRjaC5lcnJvciA9IGNhdXNlO1xuXHRcdFx0XHRtYXRjaC5pc0ZldGNoaW5nID0gZmFsc2U7XG5cdFx0XHR9XG5cdFx0fTtcblx0XHRpbnN0YWxsKCk7XG5cdFx0aWYgKCFvdXRjb21lKSBvblJlYWR5Py4oKTtcblx0XHRjb25zdCByb3V0ZSA9IGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpO1xuXHRcdHRyeSB7XG5cdFx0XHRhd2FpdCB3YWl0Rm9yKG91dGNvbWUgPyBQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IGxvYWRSb3V0ZUNodW5rKHJvdXRlLCBraW5kID09PSBFUlJPUiA/IFwiZXJyb3JDb21wb25lbnRcIiA6IFwibm90Rm91bmRDb21wb25lbnRcIikpIDogUHJvbWlzZS5hbGwoW2xvYWRSb3V0ZUNodW5rKHJvdXRlKSwgbG9hZFJvdXRlQ2h1bmsocm91dGUsIFwibm90Rm91bmRDb21wb25lbnRcIildKSwgY29udHJvbGxlci5zaWduYWwpO1xuXHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRpZiAoY2F1c2UgPT09IGNvbnRyb2xsZXIuc2lnbmFsICYmIGNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcblx0XHRcdFx0ZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCBsYW5lKTtcblx0XHRcdFx0cmV0dXJuIENBTkNFTEVEX09VVENPTUU7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmICghb3V0Y29tZSkgbWF0Y2guc3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdFx0ZWxzZSBpZiAocmVkaXJlY3RMaW1pdEV4Y2VlZGVkKSB7XG5cdFx0XHRjb250cm9sbGVyLmFib3J0KCk7XG5cdFx0XHRhd2FpdCBQcm9taXNlLmFsbChbXG5cdFx0XHRcdC4uLnRhc2tzLm1hcCgodGFzaykgPT4gdGFza1sxXSksXG5cdFx0XHRcdC4uLnRhc2tzLm1hcCgodGFzaykgPT4gdGFza1syXSksXG5cdFx0XHRcdC4uLihsYW5lWzJdID8/IFtdKS5tYXAoKHRhc2spID0+IHRhc2tbMV0pXG5cdFx0XHRdKTtcblx0XHRcdGRpc2NhcmRCYWNrZ3JvdW5kKHJvdXRlciwgbGFuZSk7XG5cdFx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbWF0Y2hlcyk7XG5cdFx0XHRpbnN0YWxsKCk7XG5cdFx0fVxuXHR9XG5cdHJldHVybiBsYW5lO1xufVxuYXN5bmMgZnVuY3Rpb24gcHJvamVjdExhbmUocm91dGVyLCBsYW5lLCBzaWduYWwsIHN0YXJ0ID0gMCwgZW5kID0gbGFuZVsxXS5sZW5ndGgpIHtcblx0Y29uc3QgbWF0Y2hlcyA9IGxhbmVbMV07XG5cdGZvciAobGV0IGluZGV4ID0gc3RhcnQ7IGluZGV4IDwgZW5kOyBpbmRleCsrKSB7XG5cdFx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzW2luZGV4XTtcblx0XHRjb25zdCByb3V0ZU9wdGlvbnMgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKS5vcHRpb25zO1xuXHRcdGlmIChyb3V0ZU9wdGlvbnMuaGVhZCB8fCByb3V0ZU9wdGlvbnMuc2NyaXB0cykgdHJ5IHtcblx0XHRcdGNvbnN0IGNvbnRleHQgPSB7XG5cdFx0XHRcdHNzcjogcm91dGVyLm9wdGlvbnMuc3NyLFxuXHRcdFx0XHRtYXRjaGVzLFxuXHRcdFx0XHRtYXRjaCxcblx0XHRcdFx0cGFyYW1zOiBtYXRjaC5wYXJhbXMsXG5cdFx0XHRcdGxvYWRlckRhdGE6IG1hdGNoLmxvYWRlckRhdGFcblx0XHRcdH07XG5cdFx0XHRjb25zdCBbaGVhZCwgc2NyaXB0c10gPSBhd2FpdCB3YWl0Rm9yKFByb21pc2UuYWxsKFtyb3V0ZU9wdGlvbnMuaGVhZD8uKGNvbnRleHQpLCByb3V0ZU9wdGlvbnMuc2NyaXB0cz8uKGNvbnRleHQpXSksIHNpZ25hbCk7XG5cdFx0XHRtYXRjaC5tZXRhID0gaGVhZD8ubWV0YTtcblx0XHRcdG1hdGNoLmxpbmtzID0gaGVhZD8ubGlua3M7XG5cdFx0XHRtYXRjaC5oZWFkU2NyaXB0cyA9IGhlYWQ/LnNjcmlwdHM7XG5cdFx0XHRtYXRjaC5zdHlsZXMgPSBoZWFkPy5zdHlsZXM7XG5cdFx0XHRtYXRjaC5zY3JpcHRzID0gc2NyaXB0cztcblx0XHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdFx0aWYgKGNhdXNlID09PSBzaWduYWwgJiYgc2lnbmFsLmFib3J0ZWQpIGJyZWFrO1xuXHRcdFx0Y29uc29sZS5lcnJvcihjYXVzZSk7XG5cdFx0fVxuXHRcdGlmIChtYXRjaC5zdGF0dXMgIT09IFwic3VjY2Vzc1wiIHx8IG1hdGNoLl9ub3RGb3VuZCkgYnJlYWs7XG5cdH1cblx0cmV0dXJuIGxhbmU7XG59XG5hc3luYyBmdW5jdGlvbiBleGVjdXRlQ2xpZW50TGFuZShyb3V0ZXIsIGxvY2F0aW9uLCBtYXRjaGVzLCBvcHRpb25zKSB7XG5cdGNvbnN0IG1hdGNoZWQgPSBbbG9jYXRpb24sIG1hdGNoZXNdO1xuXHRjb25zdCBzaWduYWwgPSBvcHRpb25zWzBdLnNpZ25hbDtcblx0bGV0IHJlZHVjZWQ7XG5cdHRyeSB7XG5cdFx0Y29uc3QgcHJlc2VudGVkID0gcm91dGVyLnN0b3Jlcy5tYXRjaGVzLmdldCgpO1xuXHRcdGxldCBwbGFubmVkQm91bmRhcnkgPSBtYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLl9ub3RGb3VuZCk7XG5cdFx0aWYgKHJvdXRlci5vcHRpb25zLm5vdEZvdW5kTW9kZSAhPT0gXCJyb290XCIgJiYgcGxhbm5lZEJvdW5kYXJ5ID49IDApIHtcblx0XHRcdGNvbnN0IGJvdW5kYXJ5ID0gYXdhaXQgZ2V0Tm90Rm91bmRCb3VuZGFyeShyb3V0ZXIsIG1hdGNoZXMsIHZvaWQgMCwgc2lnbmFsLCBwbGFubmVkQm91bmRhcnkpO1xuXHRcdFx0bWF0Y2hlc1twbGFubmVkQm91bmRhcnldLl9ub3RGb3VuZCA9IHZvaWQgMDtcblx0XHRcdG1hdGNoZXNbYm91bmRhcnldLl9ub3RGb3VuZCA9IHRydWU7XG5cdFx0XHRwbGFubmVkQm91bmRhcnkgPSBib3VuZGFyeTtcblx0XHR9XG5cdFx0bGV0IGVuZCA9IHBsYW5uZWRCb3VuZGFyeSA8IDAgPyBtYXRjaGVzLmxlbmd0aCA6IHBsYW5uZWRCb3VuZGFyeSArIDE7XG5cdFx0bGV0IHJldGFpbmVkRW5kID0gMDtcblx0XHR3aGlsZSAocmV0YWluZWRFbmQgPCBlbmQgJiYgcmV0YWluZWRFbmQgIT09IHBsYW5uZWRCb3VuZGFyeSkge1xuXHRcdFx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzW3JldGFpbmVkRW5kXTtcblx0XHRcdGNvbnN0IGNvbW1pdHRlZCA9IG9wdGlvbnNbMl1bcmV0YWluZWRFbmRdO1xuXHRcdFx0Y29uc3QgdmlzaWJsZSA9IHByZXNlbnRlZFtyZXRhaW5lZEVuZF07XG5cdFx0XHRpZiAoY29tbWl0dGVkPy5pZCAhPT0gbWF0Y2guaWQgfHwgY29tbWl0dGVkLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgfHwgbWF0Y2gucHJlbG9hZCB8fCB2aXNpYmxlPy5pZCAhPT0gbWF0Y2guaWQgfHwgdmlzaWJsZS5zdGF0dXMgIT09IFwic3VjY2Vzc1wiKSBicmVhaztcblx0XHRcdHJldGFpbmVkRW5kKys7XG5cdFx0XHRpZiAoY29tbWl0dGVkLl9ub3RGb3VuZCB8fCB2aXNpYmxlLl9ub3RGb3VuZCkgYnJlYWs7XG5cdFx0fVxuXHRcdGNvbnN0IHRhc2tzID0gW107XG5cdFx0Y29uc3Qgc3RhcnQgPSBvcHRpb25zWzZdID8/IDA7XG5cdFx0bGV0IHNlbWFudGljUGFyZW50ID0gc3RhcnQgPyBQcm9taXNlLnJlc29sdmUobWF0Y2hlc1tzdGFydCAtIDFdKSA6IHZvaWQgMDtcblx0XHRjb25zdCBwbGFuU3VjY2Vzc2Z1bExhbmUgPSAoKSA9PiB7XG5cdFx0XHRmb3IgKGxldCBpbmRleCA9IHN0YXJ0OyBpbmRleCA8IGVuZDsgaW5kZXgrKykge1xuXHRcdFx0XHRpZiAoc2lnbmFsLmFib3J0ZWQpIGJyZWFrO1xuXHRcdFx0XHRzZW1hbnRpY1BhcmVudCA9IGNyZWF0ZUxvYWRlclRhc2socm91dGVyLCBtYXRjaGVkLCBpbmRleCwgdGFza3MsIHNlbWFudGljUGFyZW50LCBvcHRpb25zLCByZXRhaW5lZEVuZCk7XG5cdFx0XHR9XG5cdFx0fTtcblx0XHRjb25zdCBmYWlsdXJlID0gYXdhaXQgY29udGV4dHVhbGl6ZShyb3V0ZXIsIG1hdGNoZWQsIG9wdGlvbnMsIGVuZCwgcGxhblN1Y2Nlc3NmdWxMYW5lLCByZXRhaW5lZEVuZCk7XG5cdFx0aWYgKGZhaWx1cmUpIHtcblx0XHRcdG9wdGlvbnNbNF0gPSB0cnVlO1xuXHRcdFx0ZW5kID0gZmFpbHVyZVswXTtcblx0XHRcdGlmIChmYWlsdXJlWzFdWzBdID09PSBOT1RfRk9VTkQpIHtcblx0XHRcdFx0Y29uc3QgYm91bmRhcnkgPSBhd2FpdCBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbWF0Y2hlcywgZmFpbHVyZSwgc2lnbmFsKTtcblx0XHRcdFx0ZmFpbHVyZVsyXSA9IGJvdW5kYXJ5O1xuXHRcdFx0XHRlbmQgPSBNYXRoLm1pbihlbmQsIGJvdW5kYXJ5ICsgMSk7XG5cdFx0XHR9IGVsc2UgaWYgKGZhaWx1cmVbMV1bMF0gPj0gUkVESVJFQ1RFRCkgZW5kID0gMDtcblx0XHRcdHBsYW5TdWNjZXNzZnVsTGFuZSgpO1xuXHRcdH1cblx0XHRpZiAoIXNpZ25hbC5hYm9ydGVkICYmICFvcHRpb25zWzNdKSB7XG5cdFx0XHRjb25zdCBhYm9ydCA9IFtdO1xuXHRcdFx0Zm9yIChjb25zdCBbaWQsIGZsaWdodF0gb2Ygcm91dGVyLl9mbGlnaHRzID8/IFtdKSBpZiAoIWZsaWdodFsyXSkge1xuXHRcdFx0XHRyb3V0ZXIuX2ZsaWdodHMuZGVsZXRlKGlkKTtcblx0XHRcdFx0YWJvcnQucHVzaChmbGlnaHRbMV0pO1xuXHRcdFx0fVxuXHRcdFx0Zm9yIChjb25zdCBjb250cm9sbGVyIG9mIGFib3J0KSBjb250cm9sbGVyLmFib3J0KCk7XG5cdFx0fVxuXHRcdGNvbnN0IHJlZHVjdGlvbiA9IHJlZHVjZUxhbmUocm91dGVyLCBtYXRjaGVkLCB0YXNrcywgb3B0aW9uc1swXSwgc2V0dGxlVGFza3ModGFza3MsIGZhaWx1cmUsIG1hdGNoZWRbMl0pLCBvcHRpb25zWzddKTtcblx0XHRpZiAobWF0Y2hlZFsyXT8ubGVuZ3RoKSBtYXRjaGVkWzNdID0gc2V0dGxlVGFza3MobWF0Y2hlZFsyXSwgdm9pZCAwLCB2b2lkIDAsIHJlZHVjdGlvbi50aGVuKChmb3JlZ3JvdW5kKSA9PiBpc0NvbnRyb2woZm9yZWdyb3VuZCkgPyAwIDogX2dldFJlbmRlcmVkTWF0Y2hlcyhtYXRjaGVzKS5sZW5ndGgsICgpID0+IDApKTtcblx0XHRyZWR1Y2VkID0gYXdhaXQgcmVkdWN0aW9uO1xuXHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdGRpc2NhcmRCYWNrZ3JvdW5kKHJvdXRlciwgbWF0Y2hlZCk7XG5cdFx0aWYgKGNhdXNlID09PSBzaWduYWwgJiYgc2lnbmFsLmFib3J0ZWQpIHJldHVybiBDQU5DRUxFRF9PVVRDT01FO1xuXHRcdHRocm93IGNhdXNlO1xuXHR9XG5cdGlmIChpc0NvbnRyb2wocmVkdWNlZCkpIHJldHVybiByZWR1Y2VkO1xuXHRyZXR1cm4gcHJvamVjdExhbmUocm91dGVyLCByZWR1Y2VkLCBzaWduYWwsIG9wdGlvbnNbNl0gPT09IG1hdGNoZXMubGVuZ3RoID8gb3B0aW9uc1s2XSA6IDApO1xufVxuLyoqXG4qIFdhaXRzIGZvciBgcGVuZGluZ01zYCwgdGhlbiBwcmVzZW50cyB0aGUgY29tcGxldGUgbGFuZS4gUmVuZGVyaW5nIGFwcGxpZXMgdGhlXG4qIHNlbGVjdGVkIGJvdW5kYXJ5IGN1dG9mZiB3aGlsZSByZXRhaW5pbmcgZXZlcnkgbWF0Y2gncyBzdHJ1Y3R1cmFsIHN0YXRlLlxuKiBBIHJlcGxhY2VtZW50IGxvYWQgZm9yIHRoZSBzYW1lIG1hdGNoIGtlZXBzIHRoZSB0aW1lcjsgY2hvb3NpbmcgYSBkaWZmZXJlbnRcbiogbWF0Y2ggcmVzZXRzIGl0LiBgcGVuZGluZ01pbk1zYCBzdGFydHMgYWZ0ZXIgdGhlIGZhbGxiYWNrIHJlbmRlcnMuXG4qL1xuZnVuY3Rpb24gb2ZmZXJQZW5kaW5nKHJvdXRlciwgdHgpIHtcblx0aWYgKHJvdXRlci5fdHggIT09IHR4KSByZXR1cm47XG5cdGNvbnN0IG1hdGNoZXMgPSB0eFszXTtcblx0Y29uc3QgcHJlc2VudGVkID0gcm91dGVyLnN0b3Jlcy5tYXRjaGVzLmdldCgpO1xuXHRsZXQgc2Vzc2lvbiA9IHJvdXRlci5fcGVuZGluZztcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IG1hdGNoZXMubGVuZ3RoOyBpbmRleCsrKSB7XG5cdFx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzW2luZGV4XTtcblx0XHRjb25zdCBzdWNjZXNzID0gbWF0Y2guc3RhdHVzID09PSBcInN1Y2Nlc3NcIiAmJiAhbWF0Y2guX25vdEZvdW5kO1xuXHRcdGNvbnN0IHByZXNlbnRlZFBlbmRpbmcgPSBwcmVzZW50ZWRbaW5kZXhdPy5pZCA9PT0gbWF0Y2guaWQgJiYgcHJlc2VudGVkW2luZGV4XT8uc3RhdHVzID09PSBcInBlbmRpbmdcIjtcblx0XHRpZiAoc3VjY2VzcyAmJiAhcHJlc2VudGVkUGVuZGluZykgY29udGludWU7XG5cdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0XHRjb25zdCBkZWxheSA9IHN1Y2Nlc3MgfHwgbWF0Y2guaW52YWxpZCA/IDAgOiByb3V0ZS5vcHRpb25zLnBlbmRpbmdNcyA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0UGVuZGluZ01zO1xuXHRcdGNvbnN0IGNvbXBvbmVudCA9IHJvdXRlLm9wdGlvbnMucGVuZGluZ0NvbXBvbmVudCA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0UGVuZGluZ0NvbXBvbmVudDtcblx0XHRpZiAoIWNvbXBvbmVudCB8fCB0eXBlb2YgZGVsYXkgIT09IFwibnVtYmVyXCIgfHwgZGVsYXkgPT09IEluZmluaXR5KSB7XG5cdFx0XHRpZiAoc2Vzc2lvbikge1xuXHRcdFx0XHRzZXNzaW9uWzBdID0gdHg7XG5cdFx0XHRcdHNlc3Npb25bMl0gPSAwO1xuXHRcdFx0XHRzZXNzaW9uWzRdID0gdHJ1ZTtcblx0XHRcdH1cblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0Y29uc3QgbWluID0gcm91dGUub3B0aW9ucy5wZW5kaW5nTWluTXMgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFBlbmRpbmdNaW5NcyA/PyAwO1xuXHRcdGxldCB0b29rT3ZlciA9IGZhbHNlO1xuXHRcdGlmIChzZXNzaW9uPy5bMV0gPT09IG1hdGNoLmlkKSB7XG5cdFx0XHR0b29rT3ZlciA9IHNlc3Npb25bMF0gIT09IHR4O1xuXHRcdFx0c2Vzc2lvblswXSA9IHR4O1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRjbGVhclRpbWVvdXQoc2Vzc2lvbj8uWzNdKTtcblx0XHRcdHJvdXRlci5fcGVuZGluZyA9IHNlc3Npb24gPSB2b2lkIDA7XG5cdFx0fVxuXHRcdGlmICghc2Vzc2lvbikgcm91dGVyLl9wZW5kaW5nID0gc2Vzc2lvbiA9IFtcblx0XHRcdHR4LFxuXHRcdFx0bWF0Y2guaWQsXG5cdFx0XHRwcmVzZW50ZWRQZW5kaW5nID8gRGF0ZS5ub3coKSArIG1pbiA6IHR4WzRdICsgZGVsYXksXG5cdFx0XHR2b2lkIDAsXG5cdFx0XHRwcmVzZW50ZWRQZW5kaW5nIHx8IHZvaWQgMCxcblx0XHRcdGNvbXBvbmVudFxuXHRcdF07XG5cdFx0aWYgKHNlc3Npb25bNF0gJiYgIXRvb2tPdmVyICYmIHNlc3Npb25bNV0gPT09IGNvbXBvbmVudCkgcmV0dXJuO1xuXHRcdHNlc3Npb25bNV0gPSBjb21wb25lbnQ7XG5cdFx0aWYgKCFzZXNzaW9uWzRdKSB7XG5cdFx0XHRjbGVhclRpbWVvdXQoc2Vzc2lvblszXSk7XG5cdFx0XHRjb25zdCByZW1haW5pbmcgPSBzZXNzaW9uWzJdIC0gRGF0ZS5ub3coKTtcblx0XHRcdGlmIChyZW1haW5pbmcgPiAwKSB7XG5cdFx0XHRcdHNlc3Npb25bM10gPSBzZXRUaW1lb3V0KCgpID0+IG9mZmVyUGVuZGluZyhyb3V0ZXIsIHR4KSwgcmVtYWluaW5nKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0c2Vzc2lvblsyXSA9IDA7XG5cdFx0fVxuXHRcdGNvbnN0IG9mZmVyZWQgPSBtYXRjaGVzLm1hcCgobWF0Y2gpID0+ICh7XG5cdFx0XHQuLi5tYXRjaCxcblx0XHRcdF9mbGlnaHQ6IHZvaWQgMFxuXHRcdH0pKTtcblx0XHRvZmZlcmVkW2luZGV4XS5zdGF0dXMgPSBcInBlbmRpbmdcIjtcblx0XHRjb25zdCBhY2sgPSBzZXNzaW9uWzRdID0gcm91dGVyLnN0YXJ0VHJhbnNpdGlvbigoKSA9PiByb3V0ZXIuc3RvcmVzLnNldE1hdGNoZXMob2ZmZXJlZCksIG9mZmVyZWQpLnRoZW4oKHJlbmRlcmVkKSA9PiB7XG5cdFx0XHRpZiAocmVuZGVyZWQgJiYgcm91dGVyLl9wZW5kaW5nID09PSBzZXNzaW9uICYmIHNlc3Npb25bNF0gPT09IGFjayAmJiAhc2Vzc2lvblsyXSkgc2Vzc2lvblsyXSA9IERhdGUubm93KCkgKyBtaW47XG5cdFx0XHRyZXR1cm4gcmVuZGVyZWQ7XG5cdFx0fSk7XG5cdFx0cmV0dXJuO1xuXHR9XG59XG4vKipcbiogQ2FuY2VscyBwZW5kaW5nIFVJIHRpbWluZyB1bmxlc3MgdGhlIGN1cnJlbnQgc3VjY2Vzc29yIGNhbiB0YWtlIG92ZXIgdGhlXG4qIHNhbWUgYm91bmRhcnkgdGhhdCByZW1haW5zIHBhaW50ZWQuXG4qL1xuZnVuY3Rpb24gZmluaXNoUGVuZGluZyhyb3V0ZXIsIHR4KSB7XG5cdGNvbnN0IHNlc3Npb24gPSByb3V0ZXIuX3BlbmRpbmc7XG5cdGlmIChyb3V0ZXIuX3R4ID09PSB0eCB8fCAhcm91dGVyLl90eD8uWzNdLnNvbWUoKG1hdGNoKSA9PiBtYXRjaC5pZCA9PT0gc2Vzc2lvbj8uWzFdKSkge1xuXHRcdGNsZWFyVGltZW91dChzZXNzaW9uPy5bM10pO1xuXHRcdHJvdXRlci5fcGVuZGluZyA9IHZvaWQgMDtcblx0fVxufVxuYXN5bmMgZnVuY3Rpb24gYXdhaXRQZW5kaW5nTWluaW11bShyb3V0ZXIsIHR4KSB7XG5cdGNvbnN0IHNlc3Npb24gPSByb3V0ZXIuX3BlbmRpbmc7XG5cdGlmICghc2Vzc2lvbikgcmV0dXJuO1xuXHRjbGVhclRpbWVvdXQoc2Vzc2lvblszXSk7XG5cdGNvbnN0IHJlbWFpbmluZyA9IHNlc3Npb25bMl0gLSBEYXRlLm5vdygpO1xuXHRpZiAoIXNlc3Npb25bNF0gfHwgcmVtYWluaW5nIDw9IDAgfHwgIV9nZXRSZW5kZXJlZE1hdGNoZXModHhbM10pLnNvbWUoKG1hdGNoKSA9PiBtYXRjaC5pZCA9PT0gc2Vzc2lvblsxXSkpIHJldHVybjtcblx0bGV0IHRpbWVyO1xuXHR0cnkge1xuXHRcdGF3YWl0IHdhaXRGb3IobmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdHRpbWVyID0gc2V0VGltZW91dChyZXNvbHZlLCByZW1haW5pbmcpO1xuXHRcdH0pLCB0eFswXS5zaWduYWwpO1xuXHR9IGNhdGNoIHt9XG5cdGNsZWFyVGltZW91dCh0aW1lcik7XG59XG5mdW5jdGlvbiBwdWJsaXNoTWF0Y2hlcyhyb3V0ZXIsIG1hdGNoZXMpIHtcblx0cm91dGVyLl9jb21taXR0ZWQgPSBtYXRjaGVzO1xuXHRyb3V0ZXIuc3RvcmVzLnNldE1hdGNoZXMobWF0Y2hlcyk7XG59XG5mdW5jdGlvbiBjb21taXRNYXRjaGVzKHJvdXRlciwgdHgsIG1hdGNoZXMsIHJlc29sdmVkUHJlZml4KSB7XG5cdGNvbnN0IHByZXZpb3VzID0gcm91dGVyLl9jb21taXR0ZWQ7XG5cdGNvbnN0IHByZXZpb3VzRW5kID0gcm91dGVyLl9saWZlY3ljbGVFbmQ7XG5cdGNvbnN0IHByZXZpb3VzQ2FjaGVkID0gcm91dGVyLl9jYWNoZTtcblx0Zm9yIChjb25zdCBtYXRjaCBvZiBtYXRjaGVzKSB7XG5cdFx0bWF0Y2gucHJlbG9hZCA9IGZhbHNlO1xuXHRcdGlmIChyZXNvbHZlZFByZWZpeCkgbWF0Y2guX2Fzc2V0RW5kID0gdm9pZCAwO1xuXHR9XG5cdGNvbnN0IGN1dCA9IF9nZXRSZW5kZXJlZE1hdGNoZXMobWF0Y2hlcykubGVuZ3RoO1xuXHRjb25zdCBjYWNoZWQgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiIHx8ICF0eFs2XSkge1xuXHRcdGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG5cdFx0Y29uc3Qgc3VwZXJzZWRlZCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IG1hdGNoZXMubGVuZ3RoOyBpbmRleCsrKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IG1hdGNoZXNbaW5kZXhdO1xuXHRcdFx0aWYgKGluZGV4IDwgY3V0IHx8IG1hdGNoLnN0YXR1cyA9PT0gXCJzdWNjZXNzXCIpIHN1cGVyc2VkZWQuYWRkKG1hdGNoLmlkKTtcblx0XHR9XG5cdFx0Zm9yIChjb25zdCBtYXRjaCBvZiBbLi4ucHJldmlvdXMsIC4uLnByZXZpb3VzQ2FjaGVkLnZhbHVlcygpXSkge1xuXHRcdFx0aWYgKG1hdGNoLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgfHwgc3VwZXJzZWRlZC5oYXMobWF0Y2guaWQpKSBjb250aW51ZTtcblx0XHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdFx0XHRpZiAoIXJvdXRlLm9wdGlvbnMubG9hZGVyIHx8IG5vdyAtIG1hdGNoLnVwZGF0ZWRBdCA+PSAobWF0Y2gucHJlbG9hZCA/IHJvdXRlLm9wdGlvbnMucHJlbG9hZEdjVGltZSA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0UHJlbG9hZEdjVGltZSA/PyAzZTUgOiByb3V0ZS5vcHRpb25zLmdjVGltZSA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0R2NUaW1lID8/IDNlNSkpIGNvbnRpbnVlO1xuXHRcdFx0Y2FjaGVkLnNldChtYXRjaC5pZCwgcHJldmlvdXNDYWNoZWQuZ2V0KG1hdGNoLmlkKSA9PT0gbWF0Y2ggPyBtYXRjaCA6IHtcblx0XHRcdFx0Li4ubWF0Y2gsXG5cdFx0XHRcdF9mbGlnaHQ6IHZvaWQgMCxcblx0XHRcdFx0aXNGZXRjaGluZzogZmFsc2UsXG5cdFx0XHRcdGNvbnRleHQ6IHt9XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0dHhbM10gPSBbXTtcblx0cm91dGVyLl9jYWNoZSA9IGNhY2hlZDtcblx0Y29uc3QgbmV4dEVuZCA9IHJvdXRlci5fbGlmZWN5Y2xlRW5kID0gbGlmZWN5Y2xlRW5kKG1hdGNoZXMpO1xuXHRwdWJsaXNoTWF0Y2hlcyhyb3V0ZXIsIG1hdGNoZXMpO1xuXHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgWy4uLnByZXZpb3VzQ2FjaGVkLnZhbHVlcygpLCAuLi5wcmV2aW91c10uZmlsdGVyKChtYXRjaCkgPT4gbWF0Y2guX2ZsaWdodCAmJiBjYWNoZWQuZ2V0KG1hdGNoLmlkKSAhPT0gbWF0Y2gpLCBtYXRjaGVzKTtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdGNvbnN0IGhhbmRvZmYgPSB0eFs2XT8uWzBdO1xuXHRcdGlmIChoYW5kb2ZmICYmIHJvdXRlci5faGFuZG9mZiA9PT0gaGFuZG9mZikgaGFuZG9mZlsxXSgpO1xuXHR9XG5cdHJ1blJvdXRlTGlmZWN5Y2xlKHJvdXRlciwgcHJldmlvdXMsIG1hdGNoZXMsIHByZXZpb3VzRW5kLCBuZXh0RW5kLCB0eCk7XG59XG4vKipcbiogUmVzb2x2ZSBvbmNlIHRoZSByb3V0ZXIgaGFzIHNldHRsZWQgb24gYSB0cmFuc2FjdGlvbiBvdGhlciB0aGFuIGBvd25lcmAuXG4qIEVhY2ggdHJhbnNhY3Rpb24ncyBjb21wbGV0aW9uIGZvbGxvd3MgaXRzIGN1cnJlbnQgc3VjY2Vzc29yLCBzbyBhbGwgd2FpdGVyc1xuKiBzaGFyZSB0aGUgc2FtZSBjaGFpbiBpbnN0ZWFkIG9mIHBvbGxpbmcgZXZlcnkgc3VjY2Vzc29yIGluZGVwZW5kZW50bHkuXG4qL1xuYXN5bmMgZnVuY3Rpb24gYXdhaXRDdXJyZW50KHJvdXRlciwgb3duZXIpIHtcblx0bGV0IGN1cnJlbnQgPSByb3V0ZXIuX3R4O1xuXHR3aGlsZSAoY3VycmVudCAmJiBjdXJyZW50ICE9PSBvd25lcikge1xuXHRcdG93bmVyID0gY3VycmVudDtcblx0XHRhd2FpdCBjdXJyZW50WzVdO1xuXHRcdGN1cnJlbnQgPSByb3V0ZXIuX3R4O1xuXHR9XG59XG5mdW5jdGlvbiBmb2xsb3dSZWRpcmVjdChyb3V0ZXIsIHR4LCBvdXRjb21lKSB7XG5cdGNvbnN0IG9wdGlvbnMgPSBvdXRjb21lWzFdLm9wdGlvbnM7XG5cdGNvbnN0IGxvY2F0aW9uID0gb3V0Y29tZVsyXTtcblx0aWYgKCFsb2NhdGlvbikgcmV0dXJuIHJvdXRlci5uYXZpZ2F0ZSh7XG5cdFx0Li4ub3B0aW9ucyxcblx0XHRyZXBsYWNlOiB0cnVlLFxuXHRcdGlnbm9yZUJsb2NrZXI6IHRydWVcblx0fSk7XG5cdGlmIChvcHRpb25zLnJlbG9hZERvY3VtZW50KSByZXR1cm4gcm91dGVyLm5hdmlnYXRlKHtcblx0XHRocmVmOiAobG9jYXRpb24ubWFza2VkTG9jYXRpb24gPz8gbG9jYXRpb24pLnB1YmxpY0hyZWYsXG5cdFx0cmVsb2FkRG9jdW1lbnQ6IHRydWUsXG5cdFx0cmVwbGFjZTogdHJ1ZSxcblx0XHRpZ25vcmVCbG9ja2VyOiB0cnVlXG5cdH0pO1xuXHRsb2NhdGlvbi5fcmVkaXJlY3RzID0gdHhbMV0gKyAxO1xuXHRyb3V0ZXIuX3BlbmRpbmdMb2NhdGlvbiA9IGxvY2F0aW9uO1xuXHRjb25zdCBjb21taXR0ZWQgPSByb3V0ZXIuY29tbWl0TG9jYXRpb24oe1xuXHRcdC4uLmxvY2F0aW9uLFxuXHRcdHZpZXdUcmFuc2l0aW9uOiBvcHRpb25zLnZpZXdUcmFuc2l0aW9uLFxuXHRcdHJlcGxhY2U6IHRydWUsXG5cdFx0cmVzZXRTY3JvbGw6IG9wdGlvbnMucmVzZXRTY3JvbGwsXG5cdFx0aGFzaFNjcm9sbEludG9WaWV3OiBvcHRpb25zLmhhc2hTY3JvbGxJbnRvVmlldyxcblx0XHRpZ25vcmVCbG9ja2VyOiB0cnVlXG5cdH0pO1xuXHRxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG5cdFx0aWYgKHJvdXRlci5fcGVuZGluZ0xvY2F0aW9uID09PSBsb2NhdGlvbikgcm91dGVyLl9wZW5kaW5nTG9jYXRpb24gPSB2b2lkIDA7XG5cdH0pO1xuXHRyZXR1cm4gY29tbWl0dGVkO1xufVxuYXN5bmMgZnVuY3Rpb24gcnVuQmFja2dyb3VuZChyb3V0ZXIsIHR4LCBiYXNlLCB0YXNrcywgc2V0dGxlbWVudCkge1xuXHRjb25zdCBuZXh0ID0gYmFzZS5tYXAoKG1hdGNoKSA9PiAoeyAuLi5tYXRjaCB9KSk7XG5cdGFjcXVpcmVNYXRjaFJlc291cmNlcyhuZXh0KTtcblx0Zm9yIChjb25zdCB0YXNrIG9mIHRhc2tzKSB7XG5cdFx0cmVsZWFzZUZsaWdodChyb3V0ZXIsIG5leHRbdGFza1swXV0pO1xuXHRcdG5leHRbdGFza1swXV0gPSB0YXNrWzNdO1xuXHR9XG5cdGNvbnN0IGxhbmUgPSBbdHhbMl0sIG5leHRdO1xuXHRsZXQgcmVkdWNlZDtcblx0dHJ5IHtcblx0XHRyZWR1Y2VkID0gYXdhaXQgcmVkdWNlTGFuZShyb3V0ZXIsIGxhbmUsIHRhc2tzLCB0eFswXSwgc2V0dGxlbWVudCk7XG5cdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0dHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIG5leHQpO1xuXHRcdHRocm93IGNhdXNlO1xuXHR9XG5cdGlmIChpc0NvbnRyb2wocmVkdWNlZCkpIHtcblx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbmV4dCk7XG5cdFx0aWYgKHJlZHVjZWRbMF0gPT09IFJFRElSRUNURUQgJiYgcm91dGVyLl90eCA9PT0gdHggJiYgcm91dGVyLl9jb21taXR0ZWQgPT09IGJhc2UpIGF3YWl0IGZvbGxvd1JlZGlyZWN0KHJvdXRlciwgdHgsIHJlZHVjZWQpO1xuXHRcdHJldHVybjtcblx0fVxuXHRhd2FpdCBwcm9qZWN0TGFuZShyb3V0ZXIsIHJlZHVjZWQsIHR4WzBdLnNpZ25hbCk7XG5cdGlmIChyb3V0ZXIuX3R4ICE9PSB0eCB8fCByb3V0ZXIuX2NvbW1pdHRlZCAhPT0gYmFzZSkge1xuXHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBuZXh0KTtcblx0XHRyZXR1cm47XG5cdH1cblx0Zm9yIChjb25zdCBtYXRjaCBvZiBuZXh0KSB7XG5cdFx0Y29uc3QgY2FjaGVkID0gcm91dGVyLl9jYWNoZS5nZXQobWF0Y2guaWQpO1xuXHRcdGlmIChjYWNoZWQ/Ll9mbGlnaHQgJiYgY2FjaGVkLl9mbGlnaHQgPT09IG1hdGNoLl9mbGlnaHQpIHtcblx0XHRcdHJvdXRlci5fY2FjaGUuZGVsZXRlKG1hdGNoLmlkKTtcblx0XHRcdHJlbGVhc2VGbGlnaHQocm91dGVyLCBjYWNoZWQpO1xuXHRcdH1cblx0fVxuXHRwdWJsaXNoTWF0Y2hlcyhyb3V0ZXIsIG5leHQpO1xuXHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgYmFzZSwgbmV4dCk7XG59XG5hc3luYyBmdW5jdGlvbiBydW5DbGllbnRUcmFuc2FjdGlvbihyb3V0ZXIsIHR4LCBmb3JjZVN0YWxlUmVsb2FkLCBvblJlYWR5LCBzeW5jLCByZXNvbHZlZFByZWZpeCkge1xuXHRjb25zdCByZXN1bHQgPSBhd2FpdCBleGVjdXRlQ2xpZW50TGFuZShyb3V0ZXIsIHR4WzJdLCB0eFszXSwgW1xuXHRcdHR4WzBdLFxuXHRcdHR4WzFdLFxuXHRcdHJvdXRlci5fY29tbWl0dGVkLFxuXHRcdHZvaWQgMCxcblx0XHRzeW5jLFxuXHRcdGZvcmNlU3RhbGVSZWxvYWQsXG5cdFx0cmVzb2x2ZWRQcmVmaXgsXG5cdFx0b25SZWFkeVxuXHRdKTtcblx0aWYgKGlzQ29udHJvbChyZXN1bHQpKSB7XG5cdFx0Y29uc3QgZm9sbG93ID0gcmVzdWx0WzBdID09PSBSRURJUkVDVEVEICYmIHJvdXRlci5fdHggPT09IHR4O1xuXHRcdGlmICghZm9sbG93IHx8IHJlc3VsdFsxXS5vcHRpb25zLnJlbG9hZERvY3VtZW50KSBmaW5pc2hQZW5kaW5nKHJvdXRlciwgdHgpO1xuXHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCB0eFszXSk7XG5cdFx0dHhbM10gPSBbXTtcblx0XHRpZiAoIWZvbGxvdykgcmV0dXJuO1xuXHRcdGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkge1xuXHRcdFx0ZmluaXNoUGVuZGluZyhyb3V0ZXIsIHR4KTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiB0eFs2XSkgcm91dGVyLl9yZWZyZXNoTmV4dExvYWQgPSB0cnVlO1xuXHRcdGF3YWl0IGZvbGxvd1JlZGlyZWN0KHJvdXRlciwgdHgsIHJlc3VsdCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGNvbnN0IG1hdGNoZXMgPSByZXN1bHRbMV07XG5cdGlmIChyb3V0ZXIuX3R4ID09PSB0eCkgYXdhaXQgYXdhaXRQZW5kaW5nTWluaW11bShyb3V0ZXIsIHR4KTtcblx0aWYgKHJvdXRlci5fdHggIT09IHR4KSB7XG5cdFx0ZmluaXNoUGVuZGluZyhyb3V0ZXIsIHR4KTtcblx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbWF0Y2hlcyk7XG5cdFx0ZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCByZXN1bHQpO1xuXHRcdHJldHVybjtcblx0fVxuXHRjb25zdCB0b0xvY2F0aW9uID0gdHhbMl07XG5cdGNvbnN0IGNoYW5nZUluZm8gPSBnZXRMb2NhdGlvbkNoYW5nZUluZm8odG9Mb2NhdGlvbiwgcm91dGVyLnN0b3Jlcy5yZXNvbHZlZExvY2F0aW9uLmdldCgpKTtcblx0Y29uc3QgYmFja2dyb3VuZCA9IHJlc3VsdFsyXTtcblx0YXdhaXQgcm91dGVyLnN0YXJ0Vmlld1RyYW5zaXRpb24oYXN5bmMgKCkgPT4ge1xuXHRcdGlmIChyb3V0ZXIuX3R4ID09PSB0eCkgYXdhaXQgYXdhaXRQZW5kaW5nTWluaW11bShyb3V0ZXIsIHR4KTtcblx0XHRpZiAocm91dGVyLl90eCAhPT0gdHgpIHtcblx0XHRcdGZpbmlzaFBlbmRpbmcocm91dGVyLCB0eCk7XG5cdFx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbWF0Y2hlcyk7XG5cdFx0XHRkaXNjYXJkQmFja2dyb3VuZChyb3V0ZXIsIHJlc3VsdCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGNvbnN0IGNvbW1pdCA9ICgpID0+IHtcblx0XHRcdGZpbmlzaFBlbmRpbmcocm91dGVyLCB0eCk7XG5cdFx0XHRjb21taXRNYXRjaGVzKHJvdXRlciwgdHgsIG1hdGNoZXMsIHJlc29sdmVkUHJlZml4KTtcblx0XHRcdGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkgcmV0dXJuO1xuXHRcdFx0cm91dGVyLmVtaXQoe1xuXHRcdFx0XHR0eXBlOiBcIm9uTG9hZFwiLFxuXHRcdFx0XHQuLi5jaGFuZ2VJbmZvXG5cdFx0XHR9KTtcblx0XHRcdGlmIChyb3V0ZXIuX3R4ID09PSB0eCkgcm91dGVyLmVtaXQoe1xuXHRcdFx0XHR0eXBlOiBcIm9uQmVmb3JlUm91dGVNb3VudFwiLFxuXHRcdFx0XHQuLi5jaGFuZ2VJbmZvXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdGNvbnN0IHJlbmRlcmVkID0gYXdhaXQgcm91dGVyLnN0YXJ0VHJhbnNpdGlvbihjb21taXQsIG1hdGNoZXMpO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgdHhbNl0pIHR4WzZdID0gdm9pZCAwO1xuXHRcdGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkge1xuXHRcdFx0ZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCByZXN1bHQpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRpZiAoYmFja2dyb3VuZD8ubGVuZ3RoKSBydW5CYWNrZ3JvdW5kKHJvdXRlciwgdHgsIG1hdGNoZXMsIGJhY2tncm91bmQsIHJlc3VsdFszXSkuY2F0Y2goY29uc29sZS5lcnJvcik7XG5cdFx0cm91dGVyLmJhdGNoKCgpID0+IHtcblx0XHRcdHJvdXRlci5zdG9yZXMucmVzb2x2ZWRMb2NhdGlvbi5zZXQodG9Mb2NhdGlvbik7XG5cdFx0XHRyb3V0ZXIuc3RvcmVzLnN0YXR1cy5zZXQoXCJpZGxlXCIpO1xuXHRcdFx0aWYgKHJvdXRlci5fdHggPT09IHR4KSByb3V0ZXIuZW1pdCh7XG5cdFx0XHRcdHR5cGU6IFwib25SZXNvbHZlZFwiLFxuXHRcdFx0XHQuLi5jaGFuZ2VJbmZvXG5cdFx0XHR9KTtcblx0XHRcdGlmIChyZW5kZXJlZCAmJiByb3V0ZXIuX3R4ID09PSB0eCkgcm91dGVyLmVtaXQoe1xuXHRcdFx0XHR0eXBlOiBcIm9uUmVuZGVyZWRcIixcblx0XHRcdFx0Li4uY2hhbmdlSW5mb1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdFx0aWYgKHJvdXRlci5fdHggIT09IHR4KSByZXR1cm47XG5cdFx0cm91dGVyLl9jb21taXRQcm9taXNlPy5yZXNvbHZlKCk7XG5cdFx0cm91dGVyLl9jb21taXRQcm9taXNlID0gdm9pZCAwO1xuXHR9KTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGxvYWRDbGllbnRSb3V0ZShyb3V0ZXIsIG9wdHMpIHtcblx0bGV0IHJlbWF0ZXJpYWxpemUgPSBmYWxzZTtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgcmVtYXRlcmlhbGl6ZSA9ICEhcm91dGVyLl9yZWZyZXNoTmV4dExvYWQgfHwgISFyb3V0ZXIuX3R4Py5bNl07XG5cdGNvbnN0IHByZXZpb3VzT3duZXIgPSByb3V0ZXIuX3R4O1xuXHRjb25zdCByZXNvbHZlZExvY2F0aW9uID0gcm91dGVyLnN0b3Jlcy5yZXNvbHZlZExvY2F0aW9uLmdldCgpO1xuXHRjb25zdCBwcmV2aW91c0xvY2F0aW9uID0gcmVzb2x2ZWRMb2NhdGlvbiA/PyByb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLmdldCgpO1xuXHRjb25zdCBsb2NhdGlvbiA9IHJvdXRlci5sYXRlc3RMb2NhdGlvbjtcblx0Y29uc3QgcGVuZGluZ0xvY2F0aW9uID0gcm91dGVyLl9wZW5kaW5nTG9jYXRpb247XG5cdGNvbnN0IHJlZGlyZWN0cyA9IHBlbmRpbmdMb2NhdGlvbj8uaHJlZiA9PT0gbG9jYXRpb24uaHJlZiA/IHBlbmRpbmdMb2NhdGlvbi5fcmVkaXJlY3RzID8/IDAgOiAwO1xuXHRjb25zdCBoYW5kb2ZmID0gcm91dGVyLl9oYW5kb2ZmO1xuXHRjb25zdCBoeWRyYXRpb25Db250cm9sbGVyID0gcmVtYXRlcmlhbGl6ZSA/IHZvaWQgMCA6IGhhbmRvZmY/LlswXSgpO1xuXHRjb25zdCBwcmVmbGlnaHQgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cdGNvbnN0IHByZXZpb3VzUHJlZmxpZ2h0ID0gcm91dGVyLl9wcmVmbGlnaHQ7XG5cdHJvdXRlci5fcHJlZmxpZ2h0ID0gcHJlZmxpZ2h0O1xuXHRpZiAoIXJlbWF0ZXJpYWxpemUgJiYgIWh5ZHJhdGlvbkNvbnRyb2xsZXIpIGhhbmRvZmY/LlsxXSgpO1xuXHRwcmV2aW91c1ByZWZsaWdodD8uYWJvcnQoKTtcblx0aWYgKCFwcmVmbGlnaHQuc2lnbmFsLmFib3J0ZWQpIHtcblx0XHRjb25zdCBjaGFuZ2VJbmZvID0gZ2V0TG9jYXRpb25DaGFuZ2VJbmZvKGxvY2F0aW9uLCByZXNvbHZlZExvY2F0aW9uKTtcblx0XHRyb3V0ZXIuZW1pdCh7XG5cdFx0XHR0eXBlOiBcIm9uQmVmb3JlTmF2aWdhdGVcIixcblx0XHRcdC4uLmNoYW5nZUluZm9cblx0XHR9KTtcblx0XHRpZiAoIXByZWZsaWdodC5zaWduYWwuYWJvcnRlZCkgcm91dGVyLmVtaXQoe1xuXHRcdFx0dHlwZTogXCJvbkJlZm9yZUxvYWRcIixcblx0XHRcdC4uLmNoYW5nZUluZm9cblx0XHR9KTtcblx0fVxuXHRpZiAocHJlZmxpZ2h0LnNpZ25hbC5hYm9ydGVkKSB7XG5cdFx0YXdhaXQgYXdhaXRDdXJyZW50KHJvdXRlciwgcHJldmlvdXNPd25lcik7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGNvbnN0IHNhbWVIcmVmID0gcHJldmlvdXNMb2NhdGlvbi5ocmVmID09PSBsb2NhdGlvbi5ocmVmO1xuXHRsZXQgY29udHJvbGxlciA9IHByZWZsaWdodDtcblx0Y29uc3QgbWF0Y2hlcyA9IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiByZW1hdGVyaWFsaXplID8gcm91dGVyLm1hdGNoUm91dGVzKGxvY2F0aW9uLCB7XG5cdFx0X2NvbnRyb2xsZXI6IHByZWZsaWdodCxcblx0XHRfcmVtYXRlcmlhbGl6ZTogdHJ1ZVxuXHR9KSA6IHJvdXRlci5tYXRjaFJvdXRlcyhsb2NhdGlvbiwgeyBfY29udHJvbGxlcjogcHJlZmxpZ2h0IH0pO1xuXHRhY3F1aXJlTWF0Y2hSZXNvdXJjZXMobWF0Y2hlcyk7XG5cdGNvbnN0IHJlc29sdmVkUHJlZml4ID0gaHlkcmF0aW9uQ29udHJvbGxlciA/IGhhbmRvZmZbMV0obWF0Y2hlcykgOiB2b2lkIDA7XG5cdGlmIChyZXNvbHZlZFByZWZpeCkgY29udHJvbGxlciA9IGh5ZHJhdGlvbkNvbnRyb2xsZXI7XG5cdGVsc2UgaHlkcmF0aW9uQ29udHJvbGxlcj8uYWJvcnQoKTtcblx0aWYgKHByZWZsaWdodC5zaWduYWwuYWJvcnRlZCkge1xuXHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBtYXRjaGVzKTtcblx0XHRhd2FpdCBhd2FpdEN1cnJlbnQocm91dGVyLCBwcmV2aW91c093bmVyKTtcblx0XHRyZXR1cm47XG5cdH1cblx0cm91dGVyLl9wcmVmbGlnaHQgPSB2b2lkIDA7XG5cdGxldCBzZXR0bGU7XG5cdGNvbnN0IHJ1biA9ICgpID0+IHJ1bkNsaWVudFRyYW5zYWN0aW9uKHJvdXRlciwgdHgsIHNhbWVIcmVmLCAoKSA9PiBvZmZlclBlbmRpbmcocm91dGVyLCB0eCksIG9wdHM/LnN5bmMsIHJlc29sdmVkUHJlZml4KTtcblx0Y29uc3QgZG9uZSA9IG9wdHM/LnN5bmMgPyBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gc2V0dGxlID0gcmVzb2x2ZSkgOiBQcm9taXNlLnJlc29sdmUoKS50aGVuKHJ1bik7XG5cdGNvbnN0IHR4ID0gW1xuXHRcdGNvbnRyb2xsZXIsXG5cdFx0cmVkaXJlY3RzLFxuXHRcdGxvY2F0aW9uLFxuXHRcdG1hdGNoZXMsXG5cdFx0RGF0ZS5ub3coKSxcblx0XHRkb25lLnRoZW4oKCkgPT4gYXdhaXRDdXJyZW50KHJvdXRlciwgdHgpKVxuXHRdO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHJlbWF0ZXJpYWxpemUpIHtcblx0XHR0eFs2XSA9IFtoYW5kb2ZmXTtcblx0XHRyb3V0ZXIuX3JlZnJlc2hOZXh0TG9hZCA9IHZvaWQgMDtcblx0fVxuXHRyb3V0ZXIuX3R4ID0gdHg7XG5cdGlmIChwcmV2aW91c093bmVyKSB7XG5cdFx0Zm9yIChjb25zdCBtYXRjaCBvZiByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCkpIHtcblx0XHRcdGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkgYnJlYWs7XG5cdFx0XHRpZiAobWF0Y2guaXNGZXRjaGluZykgc2V0RmV0Y2hpbmcocm91dGVyLCBtYXRjaCwgZmFsc2UpO1xuXHRcdH1cblx0XHRwcmV2aW91c093bmVyWzBdLmFib3J0KCk7XG5cdFx0dHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIHByZXZpb3VzT3duZXJbM10sIHR4WzNdLCB0cnVlKTtcblx0fVxuXHRpZiAocm91dGVyLl90eCAhPT0gdHgpIHtcblx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgdHhbM10pO1xuXHRcdHR4WzNdID0gW107XG5cdFx0c2V0dGxlPy4oKTtcblx0XHRhd2FpdCBhd2FpdEN1cnJlbnQocm91dGVyLCB0eCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHJvdXRlci5iYXRjaCgoKSA9PiB7XG5cdFx0cm91dGVyLnN0b3Jlcy5zdGF0dXMuc2V0KFwicGVuZGluZ1wiKTtcblx0XHRyb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLnNldChsb2NhdGlvbik7XG5cdH0pO1xuXHRpZiAocmVzb2x2ZWRQcmVmaXggfHwgIXJvdXRlci5fY29tbWl0dGVkLmxlbmd0aCAmJiBtYXRjaGVzWzBdPy5zdGF0dXMgIT09IFwic3VjY2Vzc1wiICYmICFtYXRjaGVzLnNvbWUoKG1hdGNoKSA9PiBtYXRjaC5fbm90Rm91bmQpKSBvZmZlclBlbmRpbmcocm91dGVyLCB0eCk7XG5cdHNldHRsZT8uKHJ1bigpKTtcblx0YXdhaXQgdHhbNV07XG59XG5hc3luYyBmdW5jdGlvbiByZWZyZXNoQ2xpZW50Um91dGUocm91dGVyKSB7XG5cdGNvbnN0IHBlbmRpbmcgPSByb3V0ZXIuX3R4O1xuXHRpZiAocGVuZGluZyAmJiAhcGVuZGluZ1s2XSAmJiByb3V0ZXIuc3RvcmVzLnN0YXR1cy5nZXQoKSA9PT0gXCJwZW5kaW5nXCIpIHtcblx0XHRhd2FpdCBwZW5kaW5nWzVdO1xuXHRcdGlmIChyb3V0ZXIuX3R4ICE9PSBwZW5kaW5nKSBhd2FpdCBhd2FpdEN1cnJlbnQocm91dGVyLCBwZW5kaW5nKTtcblx0fVxuXHRyb3V0ZXIuX2ZsaWdodHM/LmNsZWFyKCk7XG5cdHJvdXRlci5jbGVhckNhY2hlKCk7XG5cdHJvdXRlci5fcmVmcmVzaE5leHRMb2FkID0gdHJ1ZTtcblx0YXdhaXQgbG9hZENsaWVudFJvdXRlKHJvdXRlciwgeyBzeW5jOiB0cnVlIH0pO1xufVxuYXN5bmMgZnVuY3Rpb24gcHJlbG9hZENsaWVudFJvdXRlKHJvdXRlciwgb3B0cykge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIChyb3V0ZXIuX3JlZnJlc2hOZXh0TG9hZCB8fCByb3V0ZXIuX3R4Py5bNl0pKSByZXR1cm47XG5cdGxldCBsb2NhdGlvbiA9IHJvdXRlci5idWlsZExvY2F0aW9uKG9wdHMpO1xuXHRmb3IgKGxldCByZWRpcmVjdHMgPSAwOzsgcmVkaXJlY3RzKyspIHtcblx0XHRjb25zdCBiYXNlID0gcm91dGVyLl9jb21taXR0ZWQ7XG5cdFx0Y29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRsZXQgbWF0Y2hlcztcblx0XHRsZXQgYWN0aXZlO1xuXHRcdGxldCByZXN1bHQ7XG5cdFx0dHJ5IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdG1hdGNoZXMgPSByb3V0ZXIubWF0Y2hSb3V0ZXMobG9jYXRpb24sIHsgX2NvbnRyb2xsZXI6IGNvbnRyb2xsZXIgfSk7XG5cdFx0XHRcdGFjcXVpcmVNYXRjaFJlc291cmNlcyhtYXRjaGVzKTtcblx0XHRcdFx0YWN0aXZlID0gKHJvdXRlci5fcHJlbG9hZHMgPz89IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpLnNldChjb250cm9sbGVyLCBtYXRjaGVzKTtcblx0XHRcdFx0cmVzdWx0ID0gYXdhaXQgZXhlY3V0ZUNsaWVudExhbmUocm91dGVyLCBsb2NhdGlvbiwgbWF0Y2hlcywgW1xuXHRcdFx0XHRcdGNvbnRyb2xsZXIsXG5cdFx0XHRcdFx0cmVkaXJlY3RzLFxuXHRcdFx0XHRcdGJhc2UsXG5cdFx0XHRcdFx0dHJ1ZVxuXHRcdFx0XHRdKTtcblx0XHRcdH0gZmluYWxseSB7XG5cdFx0XHRcdGlmIChhY3RpdmUpIHtcblx0XHRcdFx0XHRhY3RpdmUgPSBhY3RpdmUuZGVsZXRlKGNvbnRyb2xsZXIpO1xuXHRcdFx0XHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBtYXRjaGVzKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb250cm9sbGVyLmFib3J0KCk7XG5cdFx0XHR9XG5cdFx0XHRpZiAoIWlzQ29udHJvbChyZXN1bHQpKSByZXR1cm4gcmVzdWx0WzFdO1xuXHRcdFx0aWYgKCFhY3RpdmUgfHwgcmVzdWx0Lmxlbmd0aCA8IDMgfHwgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIChyb3V0ZXIuX3JlZnJlc2hOZXh0TG9hZCB8fCByb3V0ZXIuX3R4Py5bNl0pKSByZXR1cm47XG5cdFx0XHRsb2NhdGlvbiA9IHJlc3VsdFsyXTtcblx0XHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdFx0aWYgKCFpc05vdEZvdW5kKGNhdXNlKSkgY29uc29sZS5lcnJvcihjYXVzZSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHR9XG59XG5hc3luYyBmdW5jdGlvbiBoeWRyYXRlKHJvdXRlcikge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICF3aW5kb3cuJF9UU1IpIHRocm93IG5ldyBFcnJvcihcIkludmFyaWFudCBmYWlsZWQ6IEV4cGVjdGVkIHRvIGZpbmQgYm9vdHN0cmFwIGRhdGEgb24gd2luZG93LiRfVFNSLCBidXQgd2UgZGlkIG5vdC4gUGxlYXNlIGZpbGUgYW4gaXNzdWUhXCIpO1xuXHRjb25zdCB0c3IgPSB3aW5kb3cuJF9UU1I7XG5cdGNvbnN0IGFkYXB0ZXJzID0gcm91dGVyLm9wdGlvbnMuc2VyaWFsaXphdGlvbkFkYXB0ZXJzO1xuXHRpZiAoYWRhcHRlcnM/Lmxlbmd0aCkge1xuXHRcdHRzci50ID0gbmV3IE1hcChhZGFwdGVycy5tYXAoKGFkYXB0ZXIpID0+IFthZGFwdGVyLmtleSwgYWRhcHRlci5mcm9tU2VyaWFsaXphYmxlXSkpO1xuXHRcdHRzci5idWZmZXIuZm9yRWFjaCgoc2NyaXB0KSA9PiBzY3JpcHQoKSk7XG5cdH1cblx0dHNyLmluaXRpYWxpemVkID0gdHJ1ZTtcblx0Y29uc3QgZGVoeWRyYXRlZFJvdXRlciA9IHRzci5yb3V0ZXI7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIWRlaHlkcmF0ZWRSb3V0ZXIpIHRocm93IG5ldyBFcnJvcihcIkludmFyaWFudCBmYWlsZWQ6IEV4cGVjdGVkIHRvIGZpbmQgYSBkZWh5ZHJhdGVkIGRhdGEgb24gd2luZG93LiRfVFNSLnJvdXRlciwgYnV0IHdlIGRpZCBub3QuIFBsZWFzZSBmaWxlIGFuIGlzc3VlIVwiKTtcblx0cm91dGVyLnNzciA9IHsgbWFuaWZlc3Q6IGRlaHlkcmF0ZWRSb3V0ZXIubWFuaWZlc3QgfTtcblx0cm91dGVyLm9wdGlvbnMuc3NyID0geyBub25jZTogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIm1ldGFbcHJvcGVydHk9XFxcImNzcC1ub25jZVxcXCJdXCIpPy5jb250ZW50IH07XG5cdGNvbnN0IGRlaHlkcmF0ZWRNYXRjaGVzID0gZGVoeWRyYXRlZFJvdXRlci5tYXRjaGVzO1xuXHRjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuXHRjb25zdCBwcmV2aW91c1ByZWZsaWdodCA9IHJvdXRlci5fcHJlZmxpZ2h0O1xuXHRyb3V0ZXIuX3ByZWZsaWdodCA9IGNvbnRyb2xsZXI7XG5cdHByZXZpb3VzUHJlZmxpZ2h0Py5hYm9ydCgpO1xuXHRjb25zdCBpc0N1cnJlbnQgPSAoKSA9PiByb3V0ZXIuX3ByZWZsaWdodCA9PT0gY29udHJvbGxlcjtcblx0bGV0IGxvY2F0aW9uO1xuXHRsZXQgY2FuZGlkYXRlcztcblx0bGV0IGhhbmRvZmZIaXN0b3J5SHJlZjtcblx0bGV0IGhhbmRvZmZIaXN0b3J5U3RhdGU7XG5cdHRyeSB7XG5cdFx0YXdhaXQgd2FpdEZvcihyb3V0ZXIub3B0aW9ucy5oeWRyYXRlPy4oZGVoeWRyYXRlZFJvdXRlci5kZWh5ZHJhdGVkRGF0YSksIGNvbnRyb2xsZXIuc2lnbmFsKTtcblx0XHRpZiAoIWlzQ3VycmVudCgpKSByZXR1cm47XG5cdFx0Y29uc3QgaGlzdG9yeUxvY2F0aW9uID0gcm91dGVyLmhpc3RvcnkubG9jYXRpb247XG5cdFx0aGFuZG9mZkhpc3RvcnlIcmVmID0gaGlzdG9yeUxvY2F0aW9uLmhyZWY7XG5cdFx0aGFuZG9mZkhpc3RvcnlTdGF0ZSA9IGhpc3RvcnlMb2NhdGlvbi5zdGF0ZTtcblx0XHRyb3V0ZXIudXBkYXRlTGF0ZXN0TG9jYXRpb24oKTtcblx0XHRsb2NhdGlvbiA9IHJvdXRlci5sYXRlc3RMb2NhdGlvbjtcblx0XHRyb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLnNldChsb2NhdGlvbik7XG5cdFx0Y2FuZGlkYXRlcyA9IHJvdXRlci5tYXRjaFJvdXRlcyhsb2NhdGlvbiwgeyBfY29udHJvbGxlcjogY29udHJvbGxlciB9KTtcblx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRpZiAoaXNDdXJyZW50KCkpIHJvdXRlci5fcHJlZmxpZ2h0ID0gdm9pZCAwO1xuXHRcdGNvbnRyb2xsZXIuYWJvcnQoY2F1c2UpO1xuXHRcdGlmIChjYXVzZSAhPT0gY29udHJvbGxlci5zaWduYWwpIHRocm93IGNhdXNlO1xuXHR9XG5cdGlmICghaXNDdXJyZW50KCkpIHJldHVybjtcblx0Y29uc3QgY29tbWl0dGVkID0gW107XG5cdGxldCBwZW5kaW5nQm91bmRhcnk7XG5cdGxldCB2ZXJpZmllZEFzc2V0RW5kID0gMDtcblx0Y29uc3QgcmV0cnlGcm9tID0gKGluZGV4KSA9PiB7XG5cdFx0dmVyaWZpZWRBc3NldEVuZCA9IE1hdGgubWluKHZlcmlmaWVkQXNzZXRFbmQsIGluZGV4ICsgMSk7XG5cdFx0Y29uc3QgcmVtb3ZlZCA9IGNvbW1pdHRlZC5zcGxpY2UoaW5kZXgpO1xuXHRcdGZvciAoY29uc3QgbWF0Y2ggb2YgcmVtb3ZlZCkgaWYgKGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpLm9wdGlvbnMubG9hZGVyICYmIChtYXRjaC5zdGF0dXMgPT09IFwic3VjY2Vzc1wiIHx8ICFtYXRjaC5pbnZhbGlkICYmIFwibG9hZGVyRGF0YVwiIGluIG1hdGNoKSkgY2FjaGVMb2FkZXJNYXRjaChyb3V0ZXIsIHtcblx0XHRcdC4uLm1hdGNoLFxuXHRcdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIixcblx0XHRcdGVycm9yOiB2b2lkIDAsXG5cdFx0XHRwcmVsb2FkOiB0cnVlXG5cdFx0fSwgcm91dGVyLl9jYWNoZS5nZXQobWF0Y2guaWQpKTtcblx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgcmVtb3ZlZCk7XG5cdH07XG5cdGNvbnN0IHNoYXJlZCA9IGRlaHlkcmF0ZWRNYXRjaGVzLmxlbmd0aCA+IGNhbmRpZGF0ZXMubGVuZ3RoID8gY2FuZGlkYXRlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5fbm90Rm91bmQpICsgMSA6IGRlaHlkcmF0ZWRNYXRjaGVzLmxlbmd0aDtcblx0bGV0IGlzVGVybWluYWwgPSBmYWxzZTtcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IHNoYXJlZDsgaW5kZXgrKykge1xuXHRcdGNvbnN0IGNhbmRpZGF0ZSA9IGNhbmRpZGF0ZXNbaW5kZXhdO1xuXHRcdGNvbnN0IGRlaHlkcmF0ZWQgPSBkZWh5ZHJhdGVkTWF0Y2hlc1tpbmRleF07XG5cdFx0aWYgKGRlaHlkcmF0ZWQuaSAhPT0gZGVoeWRyYXRlU3NyTWF0Y2hJZChjYW5kaWRhdGUuaWQpKSB7XG5cdFx0XHRwZW5kaW5nQm91bmRhcnkgPz89IGluZGV4O1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHRcdHZlcmlmaWVkQXNzZXRFbmQgPSBpbmRleCArIDE7XG5cdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIGNhbmRpZGF0ZSk7XG5cdFx0aWYgKFwibFwiIGluIGRlaHlkcmF0ZWQgfHwgZGVoeWRyYXRlZC5zID09PSBcInN1Y2Nlc3NcIiAmJiBkZWh5ZHJhdGVkLmUgPT09IHZvaWQgMCAmJiByb3V0ZS5vcHRpb25zLmxvYWRlcikgY2FuZGlkYXRlLmxvYWRlckRhdGEgPSBkZWh5ZHJhdGVkLmw7XG5cdFx0Y2FuZGlkYXRlLnN0YXR1cyA9IGRlaHlkcmF0ZWQucztcblx0XHRjYW5kaWRhdGUuc3NyID0gZGVoeWRyYXRlZC5zc3I7XG5cdFx0cm91dGUub3B0aW9ucy5zc3IgPSBjYW5kaWRhdGUuc3NyO1xuXHRcdGNhbmRpZGF0ZS51cGRhdGVkQXQgPSBkZWh5ZHJhdGVkLnU7XG5cdFx0Y2FuZGlkYXRlLmVycm9yID0gZGVoeWRyYXRlZC5lO1xuXHRcdGNhbmRpZGF0ZS5fbm90Rm91bmQgfHw9IGRlaHlkcmF0ZWQuZztcblx0XHRpZiAoY2FuZGlkYXRlLnN0YXR1cyA9PT0gXCJlcnJvclwiIHx8IGNhbmRpZGF0ZS5zdGF0dXMgPT09IFwibm90Rm91bmRcIiB8fCBjYW5kaWRhdGUuX25vdEZvdW5kKSB7XG5cdFx0XHRpc1Rlcm1pbmFsID0gdHJ1ZTtcblx0XHRcdGNvbW1pdHRlZC5wdXNoKGNhbmRpZGF0ZSk7XG5cdFx0XHRpZiAoY2FuZGlkYXRlLnNzciA9PT0gZmFsc2UgfHwgY2FuZGlkYXRlLnNzciA9PT0gXCJkYXRhLW9ubHlcIikgcGVuZGluZ0JvdW5kYXJ5ID8/PSBpbmRleDtcblx0XHRcdGJyZWFrO1xuXHRcdH1cblx0XHRpZiAoY2FuZGlkYXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHtcblx0XHRcdHBlbmRpbmdCb3VuZGFyeSA/Pz0gaW5kZXg7XG5cdFx0XHRicmVhaztcblx0XHR9XG5cdFx0Y29tbWl0dGVkLnB1c2goY2FuZGlkYXRlKTtcblx0XHRpZiAoY2FuZGlkYXRlLnNzciA9PT0gXCJkYXRhLW9ubHlcIikgcGVuZGluZ0JvdW5kYXJ5ID8/PSBpbmRleDtcblx0fVxuXHRpZiAoIWlzVGVybWluYWwgJiYgY29tbWl0dGVkLmxlbmd0aCA9PT0gc2hhcmVkICYmIHNoYXJlZCA8IGNhbmRpZGF0ZXMubGVuZ3RoKSBwZW5kaW5nQm91bmRhcnkgPSBzaGFyZWQ7XG5cdGNvbnN0IGNodW5rcyA9IGNvbW1pdHRlZC5tYXAoYXN5bmMgKG1hdGNoKSA9PiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdFx0XHRhd2FpdCAobWF0Y2guX25vdEZvdW5kID8gUHJvbWlzZS5hbGwoW2xvYWRSb3V0ZUNodW5rKHJvdXRlKSwgbG9hZFJvdXRlQ2h1bmsocm91dGUsIFwibm90Rm91bmRDb21wb25lbnRcIildKSA6IGxvYWRSb3V0ZUNodW5rKHJvdXRlLCBtYXRjaC5zdGF0dXMgPT09IFwiZXJyb3JcIiA/IFwiZXJyb3JDb21wb25lbnRcIiA6IG1hdGNoLnN0YXR1cyA9PT0gXCJub3RGb3VuZFwiID8gXCJub3RGb3VuZENvbXBvbmVudFwiIDogdm9pZCAwKSk7XG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9IGNhdGNoIHtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9XG5cdH0pO1xuXHRsZXQgY2h1bmtGYWlsdXJlID0gMDtcblx0dHJ5IHtcblx0XHR3aGlsZSAoY2h1bmtGYWlsdXJlIDwgY2h1bmtzLmxlbmd0aCAmJiBhd2FpdCB3YWl0Rm9yKGNodW5rc1tjaHVua0ZhaWx1cmVdLCBjb250cm9sbGVyLnNpZ25hbCkpIGNodW5rRmFpbHVyZSsrO1xuXHR9IGNhdGNoIHtcblx0XHRyZXR1cm47XG5cdH1cblx0aWYgKCFpc0N1cnJlbnQoKSkgcmV0dXJuO1xuXHRpZiAoY2h1bmtGYWlsdXJlIDwgY29tbWl0dGVkLmxlbmd0aCkgcmV0cnlGcm9tKGNodW5rRmFpbHVyZSk7XG5cdGNvbnN0IGNvbnRleHRFbmQgPSBNYXRoLm1heChwZW5kaW5nQm91bmRhcnkgPT09IGNvbW1pdHRlZC5sZW5ndGggPyBjb21taXR0ZWQubGVuZ3RoICsgMSA6IGNvbW1pdHRlZC5sZW5ndGgsIGNodW5rRmFpbHVyZSA8IGNodW5rcy5sZW5ndGggPyBjaHVua0ZhaWx1cmUgOiB2ZXJpZmllZEFzc2V0RW5kKTtcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGNvbnRleHRFbmQ7IGluZGV4KyspIHtcblx0XHRjb25zdCBtYXRjaCA9IGNhbmRpZGF0ZXNbaW5kZXhdO1xuXHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdFx0Y29uc3QgcGFyZW50Q29udGV4dCA9IGNhbmRpZGF0ZXNbaW5kZXggLSAxXT8uY29udGV4dCA/PyByb3V0ZXIub3B0aW9ucy5jb250ZXh0ID8/IHt9O1xuXHRcdGxldCByb3V0ZUNvbnRleHQ7XG5cdFx0aWYgKHJvdXRlLm9wdGlvbnMuY29udGV4dCkge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0cm91dGVDb250ZXh0ID0gbWF0Y2guX2N0eCA9IHJvdXRlLm9wdGlvbnMuY29udGV4dCh7XG5cdFx0XHRcdFx0ZGVwczogbWF0Y2gubG9hZGVyRGVwcyxcblx0XHRcdFx0XHRwYXJhbXM6IG1hdGNoLnBhcmFtcyxcblx0XHRcdFx0XHRjb250ZXh0OiBwYXJlbnRDb250ZXh0LFxuXHRcdFx0XHRcdGxvY2F0aW9uLFxuXHRcdFx0XHRcdG5hdmlnYXRlOiAob3B0cykgPT4gcm91dGVyLm5hdmlnYXRlKHtcblx0XHRcdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdFx0XHRfZnJvbUxvY2F0aW9uOiBsb2NhdGlvblxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdGJ1aWxkTG9jYXRpb246IHJvdXRlci5idWlsZExvY2F0aW9uLFxuXHRcdFx0XHRcdGNhdXNlOiBtYXRjaC5jYXVzZSxcblx0XHRcdFx0XHRhYm9ydENvbnRyb2xsZXI6IGNvbnRyb2xsZXIsXG5cdFx0XHRcdFx0cHJlbG9hZDogZmFsc2UsXG5cdFx0XHRcdFx0bWF0Y2hlczogY2FuZGlkYXRlcyxcblx0XHRcdFx0XHRyb3V0ZUlkOiByb3V0ZS5pZFxuXHRcdFx0XHR9KSB8fCB7fTtcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRpZiAoIWlzQ3VycmVudCgpKSByZXR1cm47XG5cdFx0XHRcdGlmIChtYXRjaC5zdGF0dXMgIT09IFwiZXJyb3JcIiAmJiBtYXRjaC5zdGF0dXMgIT09IFwibm90Rm91bmRcIiAmJiAhbWF0Y2guX25vdEZvdW5kKSB7XG5cdFx0XHRcdFx0cGVuZGluZ0JvdW5kYXJ5ID0gTWF0aC5taW4ocGVuZGluZ0JvdW5kYXJ5ID8/IGluZGV4LCBpbmRleCk7XG5cdFx0XHRcdFx0cmV0cnlGcm9tKGluZGV4KTtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKCFpc0N1cnJlbnQoKSkgcmV0dXJuO1xuXHRcdH1cblx0XHRtYXRjaC5jb250ZXh0ID0ge1xuXHRcdFx0Li4ucGFyZW50Q29udGV4dCxcblx0XHRcdC4uLnJvdXRlQ29udGV4dCxcblx0XHRcdC4uLmNvbW1pdHRlZFtpbmRleF0gJiYgZGVoeWRyYXRlZE1hdGNoZXNbaW5kZXhdLmJcblx0XHR9O1xuXHR9XG5cdGF3YWl0IHByb2plY3RMYW5lKHJvdXRlciwgW2xvY2F0aW9uLCBjYW5kaWRhdGVzXSwgY29udHJvbGxlci5zaWduYWwsIDAsIHZlcmlmaWVkQXNzZXRFbmQpO1xuXHRpZiAoIWlzQ3VycmVudCgpKSByZXR1cm47XG5cdGNvbnN0IG5lZWRzQ2xpZW50TG9hZCA9IHBlbmRpbmdCb3VuZGFyeSAhPT0gdm9pZCAwIHx8IGNvbW1pdHRlZC5sZW5ndGggPCBzaGFyZWQ7XG5cdGNvbnN0IGNvbW1pdHRlZE1hdGNoZXMgPSBpc1Rlcm1pbmFsICYmIGNvbW1pdHRlZC5sZW5ndGggPT09IHNoYXJlZCA/IGNhbmRpZGF0ZXMgOiBjb21taXR0ZWQ7XG5cdGxldCBwcmVzZW50ZWQgPSBuZWVkc0NsaWVudExvYWQgPyBjYW5kaWRhdGVzIDogY29tbWl0dGVkTWF0Y2hlcztcblx0bGV0IGRhdGFPbmx5QXNzZXRFbmQ7XG5cdGlmIChuZWVkc0NsaWVudExvYWQgJiYgcGVuZGluZ0JvdW5kYXJ5ICE9PSB2b2lkIDApIHtcblx0XHRjb25zdCBib3VuZGFyeSA9IHByZXNlbnRlZFtwZW5kaW5nQm91bmRhcnldO1xuXHRcdGRhdGFPbmx5QXNzZXRFbmQgPSBib3VuZGFyeS5zc3IgPT09IFwiZGF0YS1vbmx5XCIgJiYgdmVyaWZpZWRBc3NldEVuZCA+IHBlbmRpbmdCb3VuZGFyeSArIDEgPyB2ZXJpZmllZEFzc2V0RW5kIDogdm9pZCAwO1xuXHRcdHByZXNlbnRlZCA9IHByZXNlbnRlZC5zbGljZSgpO1xuXHRcdHByZXNlbnRlZFtwZW5kaW5nQm91bmRhcnldID0ge1xuXHRcdFx0Li4uYm91bmRhcnksXG5cdFx0XHRzdGF0dXM6IFwicGVuZGluZ1wiLFxuXHRcdFx0c3NyOiBib3VuZGFyeS5zc3IgPT09IFwiZGF0YS1vbmx5XCIgPyBcImRhdGEtb25seVwiIDogZmFsc2UsXG5cdFx0XHRfYXNzZXRFbmQ6IGRhdGFPbmx5QXNzZXRFbmRcblx0XHR9O1xuXHR9XG5cdGNvbnN0IGNsYWltID0gKCkgPT4ge1xuXHRcdGNvbnN0IGhpc3RvcnlMb2NhdGlvbiA9IHJvdXRlci5oaXN0b3J5LmxvY2F0aW9uO1xuXHRcdHJldHVybiBuZWVkc0NsaWVudExvYWQgJiYgIXJvdXRlci5fdHggJiYgaGlzdG9yeUxvY2F0aW9uLmhyZWYgPT09IGhhbmRvZmZIaXN0b3J5SHJlZiAmJiBoaXN0b3J5TG9jYXRpb24uc3RhdGUgPT09IGhhbmRvZmZIaXN0b3J5U3RhdGUgJiYgcm91dGVyLl9jb21taXR0ZWQgPT09IGNvbW1pdHRlZE1hdGNoZXMgJiYgY29tbWl0dGVkTWF0Y2hlcy5sZW5ndGggJiYgIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQgPyBjb250cm9sbGVyIDogdm9pZCAwO1xuXHR9O1xuXHRjb25zdCBoYW5kb2ZmID0gW2NsYWltLCAobWF0Y2hlcykgPT4ge1xuXHRcdGlmIChyb3V0ZXIuX2hhbmRvZmYgIT09IGhhbmRvZmYpIHJldHVybjtcblx0XHRyb3V0ZXIuX2hhbmRvZmYgPSB2b2lkIDA7XG5cdFx0Y29uc3QgcHJlZml4ID0gY29tbWl0dGVkTWF0Y2hlcy5sZW5ndGg7XG5cdFx0aWYgKCFtYXRjaGVzIHx8ICFjbGFpbSgpIHx8IGNvbW1pdHRlZE1hdGNoZXMuc29tZSgobWF0Y2gsIGluZGV4KSA9PiBtYXRjaC5pZCAhPT0gbWF0Y2hlc1tpbmRleF0/LmlkKSkge1xuXHRcdFx0Y29udHJvbGxlci5hYm9ydCgpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRsZXQgaGFuZG9mZkFzc2V0RW5kID0gZGF0YU9ubHlBc3NldEVuZDtcblx0XHRpZiAoaGFuZG9mZkFzc2V0RW5kICE9PSB2b2lkIDApIHtcblx0XHRcdGZvciAobGV0IGluZGV4ID0gcHJlZml4OyBpbmRleCA8IGhhbmRvZmZBc3NldEVuZDsgaW5kZXgrKykgaWYgKGNhbmRpZGF0ZXNbaW5kZXhdPy5pZCAhPT0gbWF0Y2hlc1tpbmRleF0/LmlkKSB7XG5cdFx0XHRcdGhhbmRvZmZBc3NldEVuZCA9IGluZGV4ID4gcGVuZGluZ0JvdW5kYXJ5ICsgMSA/IGluZGV4IDogdm9pZCAwO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdH1cblx0XHR9XG5cdFx0Y29uc3QgY2xvbmVzID0gY29tbWl0dGVkTWF0Y2hlcy5tYXAoKG1hdGNoKSA9PiAoeyAuLi5tYXRjaCB9KSk7XG5cdFx0aWYgKGhhbmRvZmZBc3NldEVuZCAhPT0gdm9pZCAwKSBjbG9uZXNbcGVuZGluZ0JvdW5kYXJ5XS5fYXNzZXRFbmQgPSBoYW5kb2ZmQXNzZXRFbmQ7XG5cdFx0dHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIG1hdGNoZXMuc3BsaWNlKDAsIHByZWZpeCwgLi4uY2xvbmVzKSk7XG5cdFx0Zm9yIChsZXQgaW5kZXggPSBwcmVmaXg7IGluZGV4IDwgbWF0Y2hlcy5sZW5ndGg7IGluZGV4KyspIHtcblx0XHRcdGNvbnN0IG1hdGNoID0gbWF0Y2hlc1tpbmRleF07XG5cdFx0XHRjb25zdCBoeWRyYXRlZCA9IGNhbmRpZGF0ZXNbaW5kZXhdO1xuXHRcdFx0aWYgKGh5ZHJhdGVkPy5pZCA9PT0gbWF0Y2guaWQgJiYgaHlkcmF0ZWQuX2N0eCkgbWF0Y2guX2N0eCA9IGh5ZHJhdGVkLl9jdHg7XG5cdFx0XHRtYXRjaC5hYm9ydENvbnRyb2xsZXIgPSBjb250cm9sbGVyO1xuXHRcdH1cblx0XHRyZXR1cm4gcHJlZml4O1xuXHR9XTtcblx0cm91dGVyLl9jb21taXR0ZWQgPSBjb21taXR0ZWRNYXRjaGVzO1xuXHRyb3V0ZXIuX2xpZmVjeWNsZUVuZCA9IGxpZmVjeWNsZUVuZChjb21taXR0ZWRNYXRjaGVzKTtcblx0cm91dGVyLl9oYW5kb2ZmID0gaGFuZG9mZjtcblx0cm91dGVyLl9wcmVmbGlnaHQgPSB2b2lkIDA7XG5cdHJvdXRlci5iYXRjaCgoKSA9PiB7XG5cdFx0cm91dGVyLnN0b3Jlcy5zZXRNYXRjaGVzKHByZXNlbnRlZCk7XG5cdFx0cm91dGVyLnN0b3Jlcy5zdGF0dXMuc2V0KFwiaWRsZVwiKTtcblx0XHRpZiAoIW5lZWRzQ2xpZW50TG9hZCkgcm91dGVyLnN0b3Jlcy5yZXNvbHZlZExvY2F0aW9uLnNldChyb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLmdldCgpKTtcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IF9nZXRBc3NldE1hdGNoZXMsIF9nZXRSZW5kZXJlZE1hdGNoZXMsIF9pc1JvdXRlRGVwYXJ0aW5nLCBjYWNoZUxvYWRlck1hdGNoLCBjb21taXRNYXRjaGVzLCBnZXRSb3V0ZSwgaHlkcmF0ZSwgbG9hZENsaWVudFJvdXRlLCBsb2FkUm91dGVDaHVuaywgcHJlbG9hZENsaWVudFJvdXRlLCBwcm9qZWN0TGFuZSwgcmVmcmVzaENsaWVudFJvdXRlLCByZXBsYWNlUm91dGVDaHVuaywgd2FpdEZvciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1sb2FkLWNsaWVudC5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL2F3YWl0LXNpZ25hbC50c1xuZnVuY3Rpb24gb2JzZXJ2ZUxhdGUoY2FsbGJhY2ssIHZhbHVlKSB7XG5cdGlmICghY2FsbGJhY2spIHJldHVybjtcblx0dHJ5IHtcblx0XHRjb25zdCByZXN1bHQgPSBjYWxsYmFjayh2YWx1ZSk7XG5cdFx0aWYgKHJlc3VsdCAhPT0gdm9pZCAwKSBQcm9taXNlLnJlc29sdmUocmVzdWx0KS5jYXRjaCgoKSA9PiB7fSk7XG5cdH0gY2F0Y2gge31cbn1cbi8qKlxuKiBBd2FpdCBgdmFsdWVgIHVubGVzcyBgc2lnbmFsYCBhYm9ydHMgZmlyc3QuIEEgcmVzdWx0IHRoYXQgc2V0dGxlcyBhZnRlciB0aGVcbiogYWJvcnQgaXMgcGFzc2VkIHRvIGBvbkxhdGVgIC8gYG9uTGF0ZUVycm9yYCBpbnN0ZWFkLlxuKlxuKiBPbmUgYWJvcnQgbGlzdGVuZXIgcGVyIHdhaXQ6IFNTUiByZXF1ZXN0cyBuZXN0IGF0IG1vc3QgYSBmZXcgd2FpdHMgb24gb25lXG4qIHNpZ25hbCwgc28gcG9vbGluZyB0aGVtIHdhcyBtZWFzdXJhYmx5IHNsb3dlciB0aGFuIHRoaXMuXG4qL1xuZnVuY3Rpb24gd2FpdEZvclJlYXNvbih2YWx1ZSwgc2lnbmFsLCBvbkxhdGUsIG9uTGF0ZUVycm9yKSB7XG5cdGNvbnN0IHByb21pc2UgPSBQcm9taXNlLnJlc29sdmUodmFsdWUpO1xuXHRpZiAoc2lnbmFsLmFib3J0ZWQpIHtcblx0XHRwcm9taXNlLnRoZW4oKHJlc3VsdCkgPT4gb2JzZXJ2ZUxhdGUob25MYXRlLCByZXN1bHQpLCAoZXJyb3IpID0+IG9ic2VydmVMYXRlKG9uTGF0ZUVycm9yLCBlcnJvcikpO1xuXHRcdHJldHVybiBQcm9taXNlLnJlamVjdChzaWduYWwucmVhc29uKTtcblx0fVxuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IGFib3J0ID0gKCkgPT4gcmVqZWN0KHNpZ25hbC5yZWFzb24pO1xuXHRcdHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgYWJvcnQsIHsgb25jZTogdHJ1ZSB9KTtcblx0XHRwcm9taXNlLnRoZW4oKHJlc3VsdCkgPT4ge1xuXHRcdFx0c2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydCk7XG5cdFx0XHRpZiAoc2lnbmFsLmFib3J0ZWQpIG9ic2VydmVMYXRlKG9uTGF0ZSwgcmVzdWx0KTtcblx0XHRcdGVsc2UgcmVzb2x2ZShyZXN1bHQpO1xuXHRcdH0sIChlcnJvcikgPT4ge1xuXHRcdFx0c2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydCk7XG5cdFx0XHRpZiAoc2lnbmFsLmFib3J0ZWQpIG9ic2VydmVMYXRlKG9uTGF0ZUVycm9yLCBlcnJvcik7XG5cdFx0XHRlbHNlIHJlamVjdChlcnJvcik7XG5cdFx0fSk7XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB3YWl0Rm9yUmVhc29uIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWF3YWl0LXNpZ25hbC5qcy5tYXAiLCJpbXBvcnQgeyBpc05vdEZvdW5kIH0gZnJvbSBcIi4vbm90LWZvdW5kLmpzXCI7XG5pbXBvcnQgeyByb290Um91dGVJZCB9IGZyb20gXCIuL3Jvb3QuanNcIjtcbmltcG9ydCB7IGlzUmVkaXJlY3QsIHJlZGlyZWN0IH0gZnJvbSBcIi4vcmVkaXJlY3QuanNcIjtcbmltcG9ydCB7IGxvYWRSb3V0ZUNodW5rIH0gZnJvbSBcIi4vbG9hZC1jbGllbnQuanNcIjtcbmltcG9ydCB7IGdldExvY2F0aW9uQ2hhbmdlSW5mbywgbGlmZWN5Y2xlRW5kLCBydW5Sb3V0ZUxpZmVjeWNsZSB9IGZyb20gXCIuL3JvdXRlci5qc1wiO1xuaW1wb3J0IHsgd2FpdEZvclJlYXNvbiB9IGZyb20gXCIuL2F3YWl0LXNpZ25hbC5qc1wiO1xuLy8jcmVnaW9uIHNyYy9sb2FkLXNlcnZlci50c1xuY29uc3QgU1VDQ0VTUyA9IDA7XG5jb25zdCBFUlJPUiA9IDE7XG5jb25zdCBOT1RfRk9VTkQgPSAyO1xuY29uc3QgUkVESVJFQ1RFRCA9IDM7XG5jb25zdCBTS0lQUEVEID0gNDtcbmNvbnN0IE1BVENIX1NFVFRMRURfQUJPUlRfUkVBU09OID0gT2JqZWN0LmZyZWV6ZSh7XG5cdG5hbWU6IFwiQWJvcnRFcnJvclwiLFxuXHRtZXNzYWdlOiBcIlRhblN0YWNrIFJvdXRlciBhYm9ydGVkIHRoaXMgc2VydmVyIG1hdGNoIGJlY2F1c2UgaXQgc2V0dGxlZC5cIlxufSk7XG5jb25zdCBSRURJUkVDVF9BQk9SVF9SRUFTT04gPSBPYmplY3QuZnJlZXplKHtcblx0bmFtZTogXCJBYm9ydEVycm9yXCIsXG5cdG1lc3NhZ2U6IFwiVGFuU3RhY2sgUm91dGVyIGFib3J0ZWQgdGhpcyBzZXJ2ZXIgbWF0Y2ggYmVjYXVzZSBvZiBhIHJlZGlyZWN0LlwiXG59KTtcbmZ1bmN0aW9uIGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpIHtcblx0cmV0dXJuIHJvdXRlci5yb3V0ZXNCeUlkW21hdGNoLnJvdXRlSWRdO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplKHZhbHVlLCByZWplY3RlZCkge1xuXHRpZiAoaXNSZWRpcmVjdCh2YWx1ZSkpIHJldHVybiBbUkVESVJFQ1RFRCwgdmFsdWVdO1xuXHRpZiAoaXNOb3RGb3VuZCh2YWx1ZSkpIHJldHVybiBbTk9UX0ZPVU5ELCB2YWx1ZV07XG5cdGlmIChyZWplY3RlZCAmJiB0eXBlb2YgdmFsdWU/LnRoZW4gPT09IFwiZnVuY3Rpb25cIikgdmFsdWUgPSBuZXcgRXJyb3IoXCJBIFByb21pc2Ugd2FzIHRocm93blwiLCB7IGNhdXNlOiB2YWx1ZSB9KTtcblx0cmV0dXJuIHJlamVjdGVkID8gW0VSUk9SLCB2YWx1ZV0gOiBbU1VDQ0VTUywgdmFsdWVdO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIHNpZ25hbCwgbm90aWZ5ID0gdHJ1ZSkge1xuXHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdGxldCBvdXRjb21lID0gbm9ybWFsaXplKGNhdXNlLCB0cnVlKTtcblx0aWYgKG91dGNvbWVbMF0gIT09IEVSUk9SKSByZXR1cm4gbWF0ZXJpYWxpemVSZWRpcmVjdChyb3V0ZXIsIGxhbmUsIHJvdXRlLCBvdXRjb21lLCBzaWduYWwsIG5vdGlmeSk7XG5cdHRyeSB7XG5cdFx0cm91dGUub3B0aW9ucy5vbkVycm9yPy4ob3V0Y29tZVsxXSk7XG5cdH0gY2F0Y2ggKG9uRXJyb3JDYXVzZSkge1xuXHRcdG91dGNvbWUgPSBub3JtYWxpemUob25FcnJvckNhdXNlLCB0cnVlKTtcblx0fVxuXHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdHJldHVybiBtYXRlcmlhbGl6ZVJlZGlyZWN0KHJvdXRlciwgbGFuZSwgcm91dGUsIG91dGNvbWUsIHNpZ25hbCwgbm90aWZ5KTtcbn1cbmZ1bmN0aW9uIG1hdGVyaWFsaXplUmVkaXJlY3Qocm91dGVyLCBsYW5lLCByb3V0ZSwgb3V0Y29tZSwgc2lnbmFsLCBub3RpZnkgPSB0cnVlKSB7XG5cdGlmIChvdXRjb21lWzBdICE9PSBSRURJUkVDVEVEKSByZXR1cm4gb3V0Y29tZTtcblx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHR0cnkge1xuXHRcdG91dGNvbWVbMV0ub3B0aW9ucy5fZnJvbUxvY2F0aW9uID0gbGFuZS5sb2NhdGlvbjtcblx0XHRyb3V0ZXIucmVzb2x2ZVJlZGlyZWN0KG91dGNvbWVbMV0pO1xuXHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRyZXR1cm4gb3V0Y29tZTtcblx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0cmV0dXJuIG5vdGlmeSA/IG5vcm1hbGl6ZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIGNhdXNlLCBzaWduYWwsIGZhbHNlKSA6IFtFUlJPUiwgY2F1c2VdO1xuXHR9XG59XG5mdW5jdGlvbiBtYXliZSh2YWx1ZSwgY2F1c2UpIHtcblx0aWYgKGNhdXNlICE9PSB2b2lkIDApIHJldHVybiB7XG5cdFx0c3RhdHVzOiBcImVycm9yXCIsXG5cdFx0ZXJyb3I6IGNhdXNlXG5cdH07XG5cdHJldHVybiB7XG5cdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIixcblx0XHR2YWx1ZVxuXHR9O1xufVxuZnVuY3Rpb24gbmF2aWdhdGVGcm9tKHJvdXRlciwgbG9jYXRpb24pIHtcblx0cmV0dXJuIChvcHRpb25zKSA9PiByb3V0ZXIubmF2aWdhdGUoe1xuXHRcdC4uLm9wdGlvbnMsXG5cdFx0X2Zyb21Mb2NhdGlvbjogbG9jYXRpb25cblx0fSk7XG59XG5mdW5jdGlvbiB3YWl0Rm9yKHZhbHVlLCBzaWduYWwpIHtcblx0cmV0dXJuIHNpZ25hbCA/IHdhaXRGb3JSZWFzb24odmFsdWUsIHNpZ25hbCkgOiB2YWx1ZTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVTc3Iocm91dGVyLCBsYW5lLCBpbmRleCkge1xuXHRjb25zdCBtYXRjaCA9IGxhbmUubWF0Y2hlc1tpbmRleF07XG5cdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdGNvbnN0IHBhcmVudFNzciA9IGxhbmUubWF0Y2hlc1tpbmRleCAtIDFdPy5zc3I7XG5cdGlmIChyb3V0ZXIuaXNTaGVsbCgpKSByZXR1cm4gcm91dGUuaWQgPT09IHJvb3RSb3V0ZUlkO1xuXHRpZiAocGFyZW50U3NyID09PSBmYWxzZSkgcmV0dXJuIGZhbHNlO1xuXHRjb25zdCBpbmhlcml0ID0gKHZhbHVlKSA9PiB7XG5cdFx0cmV0dXJuIHZhbHVlID09PSB0cnVlICYmIHBhcmVudFNzciA9PT0gXCJkYXRhLW9ubHlcIiA/IFwiZGF0YS1vbmx5XCIgOiB2YWx1ZTtcblx0fTtcblx0Y29uc3QgZGVmYXVsdFNzciA9IHJvdXRlci5vcHRpb25zLmRlZmF1bHRTc3IgPz8gdHJ1ZTtcblx0Y29uc3QgaW5oZXJpdGVkRGVmYXVsdCA9IGluaGVyaXQoZGVmYXVsdFNzcik7XG5cdG1hdGNoLnNzciA9IGluaGVyaXRlZERlZmF1bHQ7XG5cdGNvbnN0IG9wdGlvbiA9IHJvdXRlLm9wdGlvbnMuc3NyO1xuXHRpZiAob3B0aW9uID09PSB2b2lkIDApIHJldHVybiBpbmhlcml0ZWREZWZhdWx0O1xuXHRpZiAodHlwZW9mIG9wdGlvbiAhPT0gXCJmdW5jdGlvblwiKSByZXR1cm4gaW5oZXJpdChvcHRpb24pO1xuXHRjb25zdCBjb250ZXh0ID0ge1xuXHRcdHNlYXJjaDogbWF5YmUobWF0Y2guc2VhcmNoLCBtYXRjaC5zZWFyY2hFcnJvciksXG5cdFx0cGFyYW1zOiBtYXliZShtYXRjaC5wYXJhbXMsIG1hdGNoLnBhcmFtc0Vycm9yKSxcblx0XHRsb2NhdGlvbjogbGFuZS5sb2NhdGlvbixcblx0XHRtYXRjaGVzOiBsYW5lLm1hdGNoZXMubWFwKChjYW5kaWRhdGUpID0+ICh7XG5cdFx0XHRpbmRleDogY2FuZGlkYXRlLmluZGV4LFxuXHRcdFx0cGF0aG5hbWU6IGNhbmRpZGF0ZS5wYXRobmFtZSxcblx0XHRcdGZ1bGxQYXRoOiBjYW5kaWRhdGUuZnVsbFBhdGgsXG5cdFx0XHRzdGF0aWNEYXRhOiBjYW5kaWRhdGUuc3RhdGljRGF0YSxcblx0XHRcdGlkOiBjYW5kaWRhdGUuaWQsXG5cdFx0XHRyb3V0ZUlkOiBjYW5kaWRhdGUucm91dGVJZCxcblx0XHRcdHNlYXJjaDogbWF5YmUoY2FuZGlkYXRlLnNlYXJjaCwgY2FuZGlkYXRlLnNlYXJjaEVycm9yKSxcblx0XHRcdHBhcmFtczogbWF5YmUoY2FuZGlkYXRlLnBhcmFtcywgY2FuZGlkYXRlLnBhcmFtc0Vycm9yKSxcblx0XHRcdHNzcjogY2FuZGlkYXRlLnNzclxuXHRcdH0pKVxuXHR9O1xuXHR0cnkge1xuXHRcdHJldHVybiBQcm9taXNlLnJlc29sdmUob3B0aW9uKGNvbnRleHQpKS50aGVuKCh2YWx1ZSkgPT4gaW5oZXJpdCh2YWx1ZSA/PyBkZWZhdWx0U3NyKSk7XG5cdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KGNhdXNlKTtcblx0fVxufVxuZnVuY3Rpb24gc3RhbXBOb3RGb3VuZChtYXRjaCwgb3V0Y29tZSkge1xuXHRpZiAob3V0Y29tZVswXSA9PT0gTk9UX0ZPVU5EICYmICFvdXRjb21lWzFdLnJvdXRlSWQpIG91dGNvbWVbMV0ucm91dGVJZCA9IG1hdGNoLnJvdXRlSWQ7XG5cdHJldHVybiBvdXRjb21lO1xufVxuYXN5bmMgZnVuY3Rpb24gY29udGV4dHVhbGl6ZShyb3V0ZXIsIGxhbmUsIHNpZ25hbCkge1xuXHRjb25zdCBnbG9iYWxCb3VuZGFyeSA9IGxhbmUubWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5fbm90Rm91bmQpO1xuXHRsZXQgZW5kID0gZ2xvYmFsQm91bmRhcnkgPCAwID8gbGFuZS5tYXRjaGVzLmxlbmd0aCA6IGdsb2JhbEJvdW5kYXJ5ICsgMTtcblx0bGV0IGZhaWx1cmU7XG5cdGxldCBwYXJlbnRDb250ZXh0ID0geyAuLi5yb3V0ZXIub3B0aW9ucy5jb250ZXh0ID8/IHt9IH07XG5cdGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBlbmQ7IGluZGV4KyspIHtcblx0XHRjb25zdCBtYXRjaCA9IGxhbmUubWF0Y2hlc1tpbmRleF07XG5cdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3Qgc3NyID0gcmVzb2x2ZVNzcihyb3V0ZXIsIGxhbmUsIGluZGV4KTtcblx0XHRcdG1hdGNoLnNzciA9IHNzciBpbnN0YW5jZW9mIFByb21pc2UgPyBhd2FpdCBzc3IgOiBzc3I7XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdGZhaWx1cmUgPSBbaW5kZXgsIHN0YW1wTm90Rm91bmQobWF0Y2gsIG5vcm1hbGl6ZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIGNhdXNlLCBzaWduYWwpKV07XG5cdFx0XHRlbmQgPSBpbmRleDtcblx0XHR9XG5cdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGlmIChmYWlsdXJlPy5bMV1bMF0gPT09IFJFRElSRUNURUQpIGJyZWFrO1xuXHRcdG1hdGNoLl9fYmVmb3JlTG9hZENvbnRleHQgPSB2b2lkIDA7XG5cdFx0bGV0IGNvbnRleHQgPSBwYXJlbnRDb250ZXh0O1xuXHRcdHRyeSB7XG5cdFx0XHRsZXQgcm91dGVDb250ZXh0O1xuXHRcdFx0aWYgKHJvdXRlLm9wdGlvbnMuY29udGV4dCkge1xuXHRcdFx0XHRjb25zdCByb3V0ZUNvbnRleHRPcHRpb25zID0ge1xuXHRcdFx0XHRcdGRlcHM6IG1hdGNoLmxvYWRlckRlcHMsXG5cdFx0XHRcdFx0cGFyYW1zOiBtYXRjaC5wYXJhbXMsXG5cdFx0XHRcdFx0Y29udGV4dDogcGFyZW50Q29udGV4dCxcblx0XHRcdFx0XHRsb2NhdGlvbjogbGFuZS5sb2NhdGlvbixcblx0XHRcdFx0XHRuYXZpZ2F0ZTogbmF2aWdhdGVGcm9tKHJvdXRlciwgbGFuZS5sb2NhdGlvbiksXG5cdFx0XHRcdFx0YnVpbGRMb2NhdGlvbjogcm91dGVyLmJ1aWxkTG9jYXRpb24sXG5cdFx0XHRcdFx0Y2F1c2U6IG1hdGNoLmNhdXNlLFxuXHRcdFx0XHRcdGFib3J0Q29udHJvbGxlcjogbWF0Y2guYWJvcnRDb250cm9sbGVyLFxuXHRcdFx0XHRcdHByZWxvYWQ6IGZhbHNlLFxuXHRcdFx0XHRcdG1hdGNoZXM6IGxhbmUubWF0Y2hlcyxcblx0XHRcdFx0XHRyb3V0ZUlkOiByb3V0ZS5pZFxuXHRcdFx0XHR9O1xuXHRcdFx0XHRyb3V0ZUNvbnRleHQgPSByb3V0ZS5vcHRpb25zLmNvbnRleHQocm91dGVDb250ZXh0T3B0aW9ucykgPz8gdm9pZCAwO1xuXHRcdFx0fVxuXHRcdFx0Y29udGV4dCA9IHtcblx0XHRcdFx0Li4ucGFyZW50Q29udGV4dCxcblx0XHRcdFx0Li4ucm91dGVDb250ZXh0XG5cdFx0XHR9O1xuXHRcdFx0bWF0Y2guY29udGV4dCA9IGNvbnRleHQ7XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdGlmICghZmFpbHVyZSkgZmFpbHVyZSA9IFtpbmRleCwgc3RhbXBOb3RGb3VuZChtYXRjaCwgbm9ybWFsaXplRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIHNpZ25hbCkpXTtcblx0XHRcdGVuZCA9IGluZGV4O1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRpZiAoZmFpbHVyZSkgYnJlYWs7XG5cdFx0Y29uc3QgdmFsaWRhdGlvbkVycm9yID0gbWF0Y2gucGFyYW1zRXJyb3IgPz8gbWF0Y2guc2VhcmNoRXJyb3I7XG5cdFx0aWYgKHZhbGlkYXRpb25FcnJvciAhPT0gdm9pZCAwKSB7XG5cdFx0XHRmYWlsdXJlID0gW2luZGV4LCBzdGFtcE5vdEZvdW5kKG1hdGNoLCBub3JtYWxpemVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCB2YWxpZGF0aW9uRXJyb3IsIHNpZ25hbCkpXTtcblx0XHRcdGVuZCA9IGluZGV4O1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRpZiAobWF0Y2guc3NyID09PSBmYWxzZSB8fCAhcm91dGUub3B0aW9ucy5iZWZvcmVMb2FkKSB7XG5cdFx0XHRwYXJlbnRDb250ZXh0ID0gY29udGV4dDtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBtYXRjaC5hYm9ydENvbnRyb2xsZXI7XG5cdFx0Y29uc3Qgb3B0aW9ucyA9IHtcblx0XHRcdHNlYXJjaDogbWF0Y2guc2VhcmNoLFxuXHRcdFx0YWJvcnRDb250cm9sbGVyLFxuXHRcdFx0cGFyYW1zOiBtYXRjaC5wYXJhbXMsXG5cdFx0XHRwcmVsb2FkOiBmYWxzZSxcblx0XHRcdGNvbnRleHQsXG5cdFx0XHRsb2NhdGlvbjogbGFuZS5sb2NhdGlvbixcblx0XHRcdG5hdmlnYXRlOiBuYXZpZ2F0ZUZyb20ocm91dGVyLCBsYW5lLmxvY2F0aW9uKSxcblx0XHRcdGJ1aWxkTG9jYXRpb246IHJvdXRlci5idWlsZExvY2F0aW9uLFxuXHRcdFx0Y2F1c2U6IG1hdGNoLmNhdXNlLFxuXHRcdFx0bWF0Y2hlczogbGFuZS5tYXRjaGVzLFxuXHRcdFx0cm91dGVJZDogcm91dGUuaWQsXG5cdFx0XHQuLi5yb3V0ZXIub3B0aW9ucy5hZGRpdGlvbmFsQ29udGV4dFxuXHRcdH07XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGJlZm9yZUxvYWRDb250ZXh0ID0gYXdhaXQgcm91dGUub3B0aW9ucy5iZWZvcmVMb2FkKG9wdGlvbnMpO1xuXHRcdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdFx0Y29uc3Qgb3V0Y29tZSA9IHN0YW1wTm90Rm91bmQobWF0Y2gsIG1hdGVyaWFsaXplUmVkaXJlY3Qocm91dGVyLCBsYW5lLCByb3V0ZSwgbm9ybWFsaXplKGJlZm9yZUxvYWRDb250ZXh0LCBmYWxzZSksIHNpZ25hbCkpO1xuXHRcdFx0aWYgKG91dGNvbWVbMF0gIT09IFNVQ0NFU1MpIHtcblx0XHRcdFx0ZmFpbHVyZSA9IFtpbmRleCwgb3V0Y29tZV07XG5cdFx0XHRcdGVuZCA9IGluZGV4O1xuXHRcdFx0XHRicmVhaztcblx0XHRcdH1cblx0XHRcdG1hdGNoLl9fYmVmb3JlTG9hZENvbnRleHQgPSBiZWZvcmVMb2FkQ29udGV4dDtcblx0XHRcdG1hdGNoLmNvbnRleHQgPSB7XG5cdFx0XHRcdC4uLmNvbnRleHQsXG5cdFx0XHRcdC4uLmJlZm9yZUxvYWRDb250ZXh0XG5cdFx0XHR9O1xuXHRcdFx0cGFyZW50Q29udGV4dCA9IG1hdGNoLmNvbnRleHQ7XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdGZhaWx1cmUgPSBbaW5kZXgsIHN0YW1wTm90Rm91bmQobWF0Y2gsIG5vcm1hbGl6ZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIGNhdXNlLCBzaWduYWwpKV07XG5cdFx0XHRlbmQgPSBpbmRleDtcblx0XHRcdGJyZWFrO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4ge1xuXHRcdGxvY2F0aW9uOiBsYW5lLmxvY2F0aW9uLFxuXHRcdG1hdGNoZXM6IGxhbmUubWF0Y2hlcyxcblx0XHRlbmQsXG5cdFx0ZmFpbHVyZVxuXHR9O1xufVxuZnVuY3Rpb24gZ2V0TG9hZGVyQ29udGV4dChyb3V0ZXIsIGxhbmUsIG1hdGNoLCByb3V0ZSwgaW5kZXgsIHRhc2tzKSB7XG5cdHJldHVybiB7XG5cdFx0cGFyYW1zOiBtYXRjaC5wYXJhbXMsXG5cdFx0ZGVwczogbWF0Y2gubG9hZGVyRGVwcyxcblx0XHRwcmVsb2FkOiBmYWxzZSxcblx0XHRwYXJlbnRNYXRjaFByb21pc2U6IHRhc2tzW2luZGV4IC0gMV0/Lm1hdGNoLFxuXHRcdGFib3J0Q29udHJvbGxlcjogbWF0Y2guYWJvcnRDb250cm9sbGVyLFxuXHRcdGNvbnRleHQ6IG1hdGNoLmNvbnRleHQsXG5cdFx0bG9jYXRpb246IGxhbmUubG9jYXRpb24sXG5cdFx0bmF2aWdhdGU6IG5hdmlnYXRlRnJvbShyb3V0ZXIsIGxhbmUubG9jYXRpb24pLFxuXHRcdGNhdXNlOiBtYXRjaC5jYXVzZSxcblx0XHRyb3V0ZSxcblx0XHQuLi5yb3V0ZXIub3B0aW9ucy5hZGRpdGlvbmFsQ29udGV4dFxuXHR9O1xufVxuZnVuY3Rpb24gY3JlYXRlTG9hZGVyVGFzayhyb3V0ZXIsIGxhbmUsIGluZGV4LCB0YXNrcywgc2lnbmFsKSB7XG5cdGNvbnN0IG1hdGNoID0gbGFuZS5tYXRjaGVzW2luZGV4XTtcblx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0bGV0IG91dGNvbWU7XG5cdGlmIChtYXRjaC5zc3IgPT09IGZhbHNlKSBvdXRjb21lID0gUHJvbWlzZS5yZXNvbHZlKFtTS0lQUEVEXSk7XG5cdGVsc2Uge1xuXHRcdGNvbnN0IHJvdXRlTG9hZGVyID0gcm91dGUub3B0aW9ucy5sb2FkZXI7XG5cdFx0Y29uc3QgbG9hZGVyID0gdHlwZW9mIHJvdXRlTG9hZGVyID09PSBcImZ1bmN0aW9uXCIgPyByb3V0ZUxvYWRlciA6IHJvdXRlTG9hZGVyPy5oYW5kbGVyO1xuXHRcdGlmICghbG9hZGVyKSBvdXRjb21lID0gUHJvbWlzZS5yZXNvbHZlKFtTVUNDRVNTLCB2b2lkIDBdKTtcblx0XHRlbHNlIG91dGNvbWUgPSBQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IGxvYWRlcihnZXRMb2FkZXJDb250ZXh0KHJvdXRlciwgbGFuZSwgbWF0Y2gsIHJvdXRlLCBpbmRleCwgdGFza3MpKSkudGhlbigocmVzdWx0KSA9PiBub3JtYWxpemUocmVzdWx0LCBmYWxzZSksIChjYXVzZSkgPT4gbm9ybWFsaXplKGNhdXNlLCB0cnVlKSkudGhlbigocmVzdWx0KSA9PiB7XG5cdFx0XHRpZiAoc2lnbmFsPy5hYm9ydGVkIHx8IG1hdGNoLmFib3J0Q29udHJvbGxlci5zaWduYWwucmVhc29uID09PSBSRURJUkVDVF9BQk9SVF9SRUFTT04pIHJldHVybiBbU0tJUFBFRF07XG5cdFx0XHRpZiAocmVzdWx0WzBdID09PSBFUlJPUikgcmVzdWx0ID0gbm9ybWFsaXplRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgcmVzdWx0WzFdLCBzaWduYWwpO1xuXHRcdFx0ZWxzZSByZXN1bHQgPSBtYXRlcmlhbGl6ZVJlZGlyZWN0KHJvdXRlciwgbGFuZSwgcm91dGUsIHJlc3VsdCwgc2lnbmFsKTtcblx0XHRcdHJldHVybiBzdGFtcE5vdEZvdW5kKG1hdGNoLCByZXN1bHQpO1xuXHRcdH0pO1xuXHR9XG5cdGNvbnN0IHBhcmVudE1hdGNoID0gb3V0Y29tZS50aGVuKChyZXN1bHQpID0+IHtcblx0XHRjb25zdCBzbmFwc2hvdCA9IHsgLi4ubWF0Y2ggfTtcblx0XHRpZiAocmVzdWx0WzBdID09PSBTVUNDRVNTKSB7XG5cdFx0XHRzbmFwc2hvdC5sb2FkZXJEYXRhID0gcmVzdWx0WzFdO1xuXHRcdFx0c25hcHNob3Quc3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdFx0XHRzbmFwc2hvdC5lcnJvciA9IHZvaWQgMDtcblx0XHRcdHNuYXBzaG90LmludmFsaWQgPSBmYWxzZTtcblx0XHRcdHNuYXBzaG90LmlzRmV0Y2hpbmcgPSBmYWxzZTtcblx0XHR9IGVsc2UgaWYgKHJlc3VsdFswXSA9PT0gRVJST1IpIHtcblx0XHRcdHNuYXBzaG90LnN0YXR1cyA9IFwiZXJyb3JcIjtcblx0XHRcdHNuYXBzaG90LmVycm9yID0gcmVzdWx0WzFdO1xuXHRcdH0gZWxzZSBpZiAocmVzdWx0WzBdID09PSBOT1RfRk9VTkQpIHtcblx0XHRcdHNuYXBzaG90LnN0YXR1cyA9IFwibm90Rm91bmRcIjtcblx0XHRcdHNuYXBzaG90LmVycm9yID0gcmVzdWx0WzFdO1xuXHRcdH1cblx0XHRyZXR1cm4gc25hcHNob3Q7XG5cdH0pO1xuXHRyZXR1cm4ge1xuXHRcdGluZGV4LFxuXHRcdG91dGNvbWUsXG5cdFx0bWF0Y2g6IHBhcmVudE1hdGNoXG5cdH07XG59XG5hc3luYyBmdW5jdGlvbiBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbWF0Y2hlcywgaW5kZXhlZCwgc2lnbmFsLCBmYWxsYmFjayA9IDApIHtcblx0Y29uc3QgY2F1c2UgPSBpbmRleGVkPy5bMV1bMV07XG5cdGxldCBpbmRleCA9IGNhdXNlPy5yb3V0ZUlkID8gbWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5yb3V0ZUlkID09PSBjYXVzZS5yb3V0ZUlkKSA6IGluZGV4ZWQ/LlswXSA/PyBtYXRjaGVzLmxlbmd0aCAtIDE7XG5cdGlmIChpbmRleCA8IDApIGluZGV4ID0gMDtcblx0Zm9yIChsZXQgY2FuZGlkYXRlID0gaW5kZXg7IGNhbmRpZGF0ZSA+PSAwOyBjYW5kaWRhdGUtLSkge1xuXHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaGVzW2NhbmRpZGF0ZV0pO1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBsb2FkaW5nID0gbG9hZFJvdXRlQ2h1bmsocm91dGUsIGZhbHNlKTtcblx0XHRcdGlmIChsb2FkaW5nKSBhd2FpdCBsb2FkaW5nO1xuXHRcdH0gY2F0Y2gge1xuXHRcdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdH1cblx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0aWYgKHJvdXRlLm9wdGlvbnMubm90Rm91bmRDb21wb25lbnQpIHJldHVybiBjYW5kaWRhdGU7XG5cdH1cblx0cmV0dXJuIGNhdXNlPy5yb3V0ZUlkID8gaW5kZXggOiBmYWxsYmFjaztcbn1cbmZ1bmN0aW9uIGFib3J0TWF0Y2hlcyhtYXRjaGVzLCBzdGFydCA9IDAsIHJlYXNvbiA9IE1BVENIX1NFVFRMRURfQUJPUlRfUkVBU09OKSB7XG5cdGZvciAobGV0IGluZGV4ID0gc3RhcnQ7IGluZGV4IDwgbWF0Y2hlcy5sZW5ndGg7IGluZGV4KyspIG1hdGNoZXNbaW5kZXhdLmFib3J0Q29udHJvbGxlci5hYm9ydChyZWFzb24pO1xufVxuYXN5bmMgZnVuY3Rpb24gYXBwbHlGYWlsdXJlKHJvdXRlciwgbGFuZSwgaW5kZXhlZCwgc2lnbmFsKSB7XG5cdGlmICghaW5kZXhlZCkge1xuXHRcdGNvbnN0IGJvdW5kYXJ5ID0gbGFuZS5tYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLl9ub3RGb3VuZCk7XG5cdFx0aWYgKGJvdW5kYXJ5ID49IDApIHtcblx0XHRcdGFib3J0TWF0Y2hlcyhsYW5lLm1hdGNoZXMsIGJvdW5kYXJ5ICsgMSk7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRzdGF0dXM6IDQwNCxcblx0XHRcdFx0Ym91bmRhcnksXG5cdFx0XHRcdGtpbmQ6IE5PVF9GT1VORFxuXHRcdFx0fTtcblx0XHR9XG5cdFx0cmV0dXJuIHsgc3RhdHVzOiAyMDAgfTtcblx0fVxuXHRjb25zdCBbaW5kZXgsIG91dGNvbWVdID0gaW5kZXhlZDtcblx0aWYgKG91dGNvbWVbMF0gPT09IEVSUk9SKSB7XG5cdFx0Y29uc3QgbWF0Y2ggPSBsYW5lLm1hdGNoZXNbaW5kZXhdO1xuXHRcdG1hdGNoLl9ub3RGb3VuZCA9IHZvaWQgMDtcblx0XHRtYXRjaC5zdGF0dXMgPSBcImVycm9yXCI7XG5cdFx0bWF0Y2guZXJyb3IgPSBvdXRjb21lWzFdO1xuXHRcdG1hdGNoLmlzRmV0Y2hpbmcgPSBmYWxzZTtcblx0XHRhYm9ydE1hdGNoZXMobGFuZS5tYXRjaGVzLCBpbmRleCArIDEpO1xuXHRcdHJldHVybiB7XG5cdFx0XHRzdGF0dXM6IDUwMCxcblx0XHRcdGJvdW5kYXJ5OiBpbmRleCxcblx0XHRcdGtpbmQ6IEVSUk9SXG5cdFx0fTtcblx0fVxuXHRjb25zdCBib3VuZGFyeSA9IGluZGV4ZWRbMl0gPz8gYXdhaXQgZ2V0Tm90Rm91bmRCb3VuZGFyeShyb3V0ZXIsIGxhbmUubWF0Y2hlcywgaW5kZXhlZCwgc2lnbmFsKTtcblx0Y29uc3QgbWF0Y2ggPSBsYW5lLm1hdGNoZXNbYm91bmRhcnldO1xuXHRjb25zdCBjYXVzZSA9IG91dGNvbWVbMV07XG5cdGNhdXNlLnJvdXRlSWQgPSBtYXRjaC5yb3V0ZUlkO1xuXHRtYXRjaC5fbm90Rm91bmQgPSB2b2lkIDA7XG5cdGlmIChtYXRjaC5yb3V0ZUlkID09PSByb3V0ZXIucm91dGVUcmVlLmlkKSB7XG5cdFx0bWF0Y2guc3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdFx0bWF0Y2guX25vdEZvdW5kID0gdHJ1ZTtcblx0XHRtYXRjaC5lcnJvciA9IGNhdXNlO1xuXHR9IGVsc2Uge1xuXHRcdG1hdGNoLnN0YXR1cyA9IFwibm90Rm91bmRcIjtcblx0XHRtYXRjaC5lcnJvciA9IGNhdXNlO1xuXHR9XG5cdG1hdGNoLmlzRmV0Y2hpbmcgPSBmYWxzZTtcblx0YWJvcnRNYXRjaGVzKGxhbmUubWF0Y2hlcywgYm91bmRhcnkgKyAxKTtcblx0cmV0dXJuIHtcblx0XHRzdGF0dXM6IDQwNCxcblx0XHRib3VuZGFyeSxcblx0XHRraW5kOiBOT1RfRk9VTkRcblx0fTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGxvYWROb3JtYWxDaHVua3Mocm91dGVyLCBsYW5lLCBlbmQsIHNpZ25hbCkge1xuXHRjb25zdCBjaHVua3MgPSBbXTtcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGxhbmUubWF0Y2hlcy5sZW5ndGg7IGluZGV4KyspIHtcblx0XHRjb25zdCBtYXRjaCA9IGxhbmUubWF0Y2hlc1tpbmRleF07XG5cdFx0aWYgKGluZGV4ID49IGVuZCB8fCBtYXRjaC5zc3IgIT09IHRydWUgfHwgbWF0Y2guc3RhdHVzICE9PSBcInN1Y2Nlc3NcIikgY29udGludWU7XG5cdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3QgbG9hZGluZyA9IGxvYWRSb3V0ZUNodW5rKHJvdXRlKTtcblx0XHRcdGlmIChsb2FkaW5nKSB7XG5cdFx0XHRcdGNvbnN0IGNodW5rID0gbG9hZGluZy50aGVuKCgpID0+IHtcblx0XHRcdFx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0XHRcdH0sIChjYXVzZSkgPT4ge1xuXHRcdFx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdFx0XHRyZXR1cm4gW2luZGV4LCBzdGFtcE5vdEZvdW5kKG1hdGNoLCBub3JtYWxpemVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCBjYXVzZSwgc2lnbmFsKSldO1xuXHRcdFx0XHR9KTtcblx0XHRcdFx0Y2h1bmsuY2F0Y2goKCkgPT4ge30pO1xuXHRcdFx0XHRjaHVua3MucHVzaChjaHVuayk7XG5cdFx0XHR9XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdGNodW5rcy5wdXNoKFtpbmRleCwgc3RhbXBOb3RGb3VuZChtYXRjaCwgbm9ybWFsaXplRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIHNpZ25hbCkpXSk7XG5cdFx0fVxuXHR9XG5cdGZvciAoY29uc3QgY2h1bmsgb2YgY2h1bmtzKSB7XG5cdFx0Y29uc3QgaW5kZXhlZCA9IEFycmF5LmlzQXJyYXkoY2h1bmspID8gY2h1bmsgOiBhd2FpdCBjaHVuaztcblx0XHRpZiAoaW5kZXhlZCkgcmV0dXJuIGluZGV4ZWQ7XG5cdH1cbn1cbmFzeW5jIGZ1bmN0aW9uIHByb2plY3RMYW5lKHJvdXRlciwgbGFuZSwgc2lnbmFsKSB7XG5cdGZvciAoY29uc3QgbWF0Y2ggb2YgbGFuZS5tYXRjaGVzKSB7XG5cdFx0Y29uc3Qgcm91dGVPcHRpb25zID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCkub3B0aW9ucztcblx0XHRpZiAocm91dGVPcHRpb25zLmhlYWQgfHwgcm91dGVPcHRpb25zLnNjcmlwdHMgfHwgcm91dGVPcHRpb25zLmhlYWRlcnMpIHtcblx0XHRcdGNvbnN0IGNvbnRleHQgPSB7XG5cdFx0XHRcdHNzcjogcm91dGVyLm9wdGlvbnMuc3NyLFxuXHRcdFx0XHRtYXRjaGVzOiBsYW5lLm1hdGNoZXMsXG5cdFx0XHRcdG1hdGNoLFxuXHRcdFx0XHRwYXJhbXM6IG1hdGNoLnBhcmFtcyxcblx0XHRcdFx0bG9hZGVyRGF0YTogbWF0Y2gubG9hZGVyRGF0YVxuXHRcdFx0fTtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IFtoZWFkLCBzY3JpcHRzLCBoZWFkZXJzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcblx0XHRcdFx0XHRyb3V0ZU9wdGlvbnMuaGVhZD8uKGNvbnRleHQpLFxuXHRcdFx0XHRcdHJvdXRlT3B0aW9ucy5zY3JpcHRzPy4oY29udGV4dCksXG5cdFx0XHRcdFx0cm91dGVPcHRpb25zLmhlYWRlcnM/Lihjb250ZXh0KVxuXHRcdFx0XHRdKTtcblx0XHRcdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdFx0XHRtYXRjaC5tZXRhID0gaGVhZD8ubWV0YTtcblx0XHRcdFx0bWF0Y2gubGlua3MgPSBoZWFkPy5saW5rcztcblx0XHRcdFx0bWF0Y2guaGVhZFNjcmlwdHMgPSBoZWFkPy5zY3JpcHRzO1xuXHRcdFx0XHRtYXRjaC5zdHlsZXMgPSBoZWFkPy5zdHlsZXM7XG5cdFx0XHRcdG1hdGNoLnNjcmlwdHMgPSBzY3JpcHRzO1xuXHRcdFx0XHRtYXRjaC5oZWFkZXJzID0gaGVhZGVycztcblx0XHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdFx0Y29uc29sZS5lcnJvcihjYXVzZSk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmIChtYXRjaC5zc3IgPT09IGZhbHNlIHx8IG1hdGNoLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgfHwgbWF0Y2guX25vdEZvdW5kKSBicmVhaztcblx0fVxufVxuYXN5bmMgZnVuY3Rpb24gZXhlY3V0ZVNlcnZlckxhbmUocm91dGVyLCBsb2NhdGlvbiwgbWF0Y2hlZE1hdGNoZXMsIHNpZ25hbCkge1xuXHRjb25zdCBtYXRjaGVkID0ge1xuXHRcdGxvY2F0aW9uLFxuXHRcdG1hdGNoZXM6IG1hdGNoZWRNYXRjaGVzLm1hcCgobWF0Y2gpID0+ICh7XG5cdFx0XHQuLi5tYXRjaCxcblx0XHRcdF9fYmVmb3JlTG9hZENvbnRleHQ6IHZvaWQgMCxcblx0XHRcdGNvbnRleHQ6IHt9LFxuXHRcdFx0aXNGZXRjaGluZzogZmFsc2UsXG5cdFx0XHRhYm9ydENvbnRyb2xsZXI6IG5ldyBBYm9ydENvbnRyb2xsZXIoKVxuXHRcdH0pKVxuXHR9O1xuXHRjb25zdCBhYm9ydExhbmUgPSAoKSA9PiBhYm9ydE1hdGNoZXMobWF0Y2hlZC5tYXRjaGVzLCAwLCBzaWduYWw/LnJlYXNvbiA/PyBNQVRDSF9TRVRUTEVEX0FCT1JUX1JFQVNPTik7XG5cdGlmIChzaWduYWw/LmFib3J0ZWQpIHtcblx0XHRhYm9ydExhbmUoKTtcblx0XHRzaWduYWwudGhyb3dJZkFib3J0ZWQoKTtcblx0fVxuXHRzaWduYWw/LmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydExhbmUsIHsgb25jZTogdHJ1ZSB9KTtcblx0dHJ5IHtcblx0XHRjb25zdCBwbGFubmVkR2xvYmFsQm91bmRhcnkgPSBtYXRjaGVkLm1hdGNoZXMuZmluZEluZGV4KChtYXRjaCkgPT4gbWF0Y2guX25vdEZvdW5kKTtcblx0XHRpZiAocm91dGVyLm9wdGlvbnMubm90Rm91bmRNb2RlICE9PSBcInJvb3RcIiAmJiBwbGFubmVkR2xvYmFsQm91bmRhcnkgPj0gMCkge1xuXHRcdFx0Y29uc3QgYm91bmRhcnkgPSBhd2FpdCBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbWF0Y2hlZC5tYXRjaGVzLCB2b2lkIDAsIHNpZ25hbCwgcGxhbm5lZEdsb2JhbEJvdW5kYXJ5KTtcblx0XHRcdGlmIChib3VuZGFyeSAhPT0gcGxhbm5lZEdsb2JhbEJvdW5kYXJ5KSB7XG5cdFx0XHRcdG1hdGNoZWQubWF0Y2hlc1twbGFubmVkR2xvYmFsQm91bmRhcnldLl9ub3RGb3VuZCA9IHZvaWQgMDtcblx0XHRcdFx0bWF0Y2hlZC5tYXRjaGVzW2JvdW5kYXJ5XS5fbm90Rm91bmQgPSB0cnVlO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRjb25zdCBsYW5lID0gYXdhaXQgY29udGV4dHVhbGl6ZShyb3V0ZXIsIG1hdGNoZWQsIHNpZ25hbCk7XG5cdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGxldCBsb2FkZXJFbmQgPSBsYW5lLmVuZDtcblx0XHRpZiAobGFuZS5mYWlsdXJlPy5bMV1bMF0gPT09IFJFRElSRUNURUQpIGxvYWRlckVuZCA9IDA7XG5cdFx0ZWxzZSBpZiAobGFuZS5mYWlsdXJlPy5bMV1bMF0gPT09IE5PVF9GT1VORCkge1xuXHRcdFx0bGFuZS5mYWlsdXJlWzJdID0gYXdhaXQgZ2V0Tm90Rm91bmRCb3VuZGFyeShyb3V0ZXIsIGxhbmUubWF0Y2hlcywgbGFuZS5mYWlsdXJlLCBzaWduYWwpO1xuXHRcdFx0bG9hZGVyRW5kID0gTWF0aC5taW4obG9hZGVyRW5kLCBsYW5lLmZhaWx1cmVbMl0gKyAxKTtcblx0XHR9XG5cdFx0Y29uc3QgdGFza3MgPSBbXTtcblx0XHRmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgbG9hZGVyRW5kOyBpbmRleCsrKSB7XG5cdFx0XHRjb25zdCB0YXNrID0gY3JlYXRlTG9hZGVyVGFzayhyb3V0ZXIsIGxhbmUsIGluZGV4LCB0YXNrcywgc2lnbmFsKTtcblx0XHRcdHRhc2tzLnB1c2godGFzayk7XG5cdFx0fVxuXHRcdGxldCBsb2FkZXJGYWlsdXJlO1xuXHRcdGxldCBjb250cm9sID0gbGFuZS5mYWlsdXJlPy5bMV1bMF0gPT09IFJFRElSRUNURUQgPyBsYW5lLmZhaWx1cmUgOiB2b2lkIDA7XG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IFByb21pc2UuYWxsKHRhc2tzLm1hcCgodGFzaykgPT4gdGFzay5vdXRjb21lLnRoZW4oKGxvYWRlZE91dGNvbWUpID0+IHtcblx0XHRcdFx0Y29uc3QgbWF0Y2ggPSBsYW5lLm1hdGNoZXNbdGFzay5pbmRleF07XG5cdFx0XHRcdGNvbnN0IG91dGNvbWUgPSBsb2FkZWRPdXRjb21lO1xuXHRcdFx0XHRpZiAob3V0Y29tZVswXSA9PT0gU1VDQ0VTUykge1xuXHRcdFx0XHRcdG1hdGNoLmxvYWRlckRhdGEgPSBvdXRjb21lWzFdO1xuXHRcdFx0XHRcdG1hdGNoLnN0YXR1cyA9IFwic3VjY2Vzc1wiO1xuXHRcdFx0XHRcdG1hdGNoLmVycm9yID0gdm9pZCAwO1xuXHRcdFx0XHRcdG1hdGNoLmludmFsaWQgPSBmYWxzZTtcblx0XHRcdFx0XHRtYXRjaC5pc0ZldGNoaW5nID0gZmFsc2U7XG5cdFx0XHRcdFx0bWF0Y2gudXBkYXRlZEF0ID0gRGF0ZS5ub3coKTtcblx0XHRcdFx0fSBlbHNlIGlmIChvdXRjb21lWzBdID09PSBSRURJUkVDVEVEKSB7XG5cdFx0XHRcdFx0Y29udHJvbCA9IFt0YXNrLmluZGV4LCBvdXRjb21lXTtcblx0XHRcdFx0XHR0aHJvdyBjb250cm9sO1xuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdGlmIChtYXRjaC5zc3IgIT09IGZhbHNlKSB7XG5cdFx0XHRcdFx0XHRtYXRjaC5zdGF0dXMgPSBcInN1Y2Nlc3NcIjtcblx0XHRcdFx0XHRcdG1hdGNoLmVycm9yID0gdm9pZCAwO1xuXHRcdFx0XHRcdFx0bWF0Y2guaW52YWxpZCA9IHRydWU7XG5cdFx0XHRcdFx0XHRtYXRjaC5pc0ZldGNoaW5nID0gZmFsc2U7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmICghbG9hZGVyRmFpbHVyZSAmJiBvdXRjb21lWzBdICE9PSBTS0lQUEVEKSBsb2FkZXJGYWlsdXJlID0gW3Rhc2suaW5kZXgsIG91dGNvbWVdO1xuXHRcdFx0XHR9XG5cdFx0XHR9KSkpO1xuXHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY2F1c2UpKSB0aHJvdyBjYXVzZTtcblx0XHRcdGNvbnRyb2wgPSBjYXVzZTtcblx0XHR9XG5cdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGlmIChjb250cm9sPy5bMV1bMF0gPT09IFJFRElSRUNURUQpIHtcblx0XHRcdGFib3J0TWF0Y2hlcyhsYW5lLm1hdGNoZXMsIDAsIFJFRElSRUNUX0FCT1JUX1JFQVNPTik7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHR0eXBlOiBcInJlZGlyZWN0XCIsXG5cdFx0XHRcdHJlZGlyZWN0OiBjb250cm9sWzFdWzFdXG5cdFx0XHR9O1xuXHRcdH1cblx0XHRsZXQgZmFpbHVyZSA9IGxhbmUuZmFpbHVyZSA/PyBsb2FkZXJGYWlsdXJlO1xuXHRcdGNvbnN0IHBsYW5uZWRCb3VuZGFyeSA9IGxhbmUubWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5fbm90Rm91bmQpO1xuXHRcdGxldCByZWFkaW5lc3NFbmQ7XG5cdFx0aWYgKGZhaWx1cmUpIHtcblx0XHRcdGNvbnN0IG91dGNvbWVFbmQgPSBmYWlsdXJlWzJdID8/PSBmYWlsdXJlWzFdWzBdID09PSBOT1RfRk9VTkQgPyBhd2FpdCBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbGFuZS5tYXRjaGVzLCBmYWlsdXJlLCBzaWduYWwpIDogZmFpbHVyZVswXTtcblx0XHRcdGZvciAoY29uc3QgdGFzayBvZiB0YXNrcykge1xuXHRcdFx0XHRpZiAodGFzay5pbmRleCA+PSBvdXRjb21lRW5kKSBicmVhaztcblx0XHRcdFx0Y29uc3Qgb3V0Y29tZSA9IGF3YWl0IHRhc2sub3V0Y29tZTtcblx0XHRcdFx0aWYgKG91dGNvbWVbMF0gIT09IFNVQ0NFU1MgJiYgb3V0Y29tZVswXSA8IFJFRElSRUNURUQgJiYgIShcImxvYWRlckRhdGFcIiBpbiBsYW5lLm1hdGNoZXNbdGFzay5pbmRleF0pKSB7XG5cdFx0XHRcdFx0ZmFpbHVyZSA9IFt0YXNrLmluZGV4LCBvdXRjb21lXTtcblx0XHRcdFx0XHRmYWlsdXJlWzJdID0gb3V0Y29tZVswXSA9PT0gTk9UX0ZPVU5EID8gYXdhaXQgZ2V0Tm90Rm91bmRCb3VuZGFyeShyb3V0ZXIsIGxhbmUubWF0Y2hlcywgZmFpbHVyZSwgc2lnbmFsKSA6IHRhc2suaW5kZXg7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJlYWRpbmVzc0VuZCA9IGZhaWx1cmVbMl07XG5cdFx0fSBlbHNlIHJlYWRpbmVzc0VuZCA9IHBsYW5uZWRCb3VuZGFyeSA8IDAgPyBsYW5lLm1hdGNoZXMubGVuZ3RoIDogcGxhbm5lZEJvdW5kYXJ5O1xuXHRcdGNvbnN0IHJlcXVpcmVkRmFpbHVyZSA9IGF3YWl0IGxvYWROb3JtYWxDaHVua3Mocm91dGVyLCBsYW5lLCByZWFkaW5lc3NFbmQsIHNpZ25hbCk7XG5cdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGlmIChyZXF1aXJlZEZhaWx1cmUpIHtcblx0XHRcdGlmIChyZXF1aXJlZEZhaWx1cmVbMV1bMF0gPT09IFJFRElSRUNURUQpIHtcblx0XHRcdFx0YWJvcnRNYXRjaGVzKGxhbmUubWF0Y2hlcywgMCwgUkVESVJFQ1RfQUJPUlRfUkVBU09OKTtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHR0eXBlOiBcInJlZGlyZWN0XCIsXG5cdFx0XHRcdFx0cmVkaXJlY3Q6IHJlcXVpcmVkRmFpbHVyZVsxXVsxXVxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdFx0ZmFpbHVyZSA9IHJlcXVpcmVkRmFpbHVyZTtcblx0XHR9XG5cdFx0Y29uc3QgdGVybWluYWwgPSBhd2FpdCBhcHBseUZhaWx1cmUocm91dGVyLCBsYW5lLCBmYWlsdXJlLCBzaWduYWwpO1xuXHRcdGlmICh0ZXJtaW5hbC5ib3VuZGFyeSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IGxhbmUubWF0Y2hlc1t0ZXJtaW5hbC5ib3VuZGFyeV07XG5cdFx0XHRpZiAobWF0Y2guc3NyID09PSB0cnVlKSB7XG5cdFx0XHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0aWYgKHRlcm1pbmFsLmtpbmQgPT09IEVSUk9SKSBhd2FpdCBsb2FkUm91dGVDaHVuayhyb3V0ZSwgXCJlcnJvckNvbXBvbmVudFwiKTtcblx0XHRcdFx0XHRlbHNlIGlmIChtYXRjaC5fbm90Rm91bmQpIGF3YWl0IFByb21pc2UuYWxsKFtsb2FkUm91dGVDaHVuayhyb3V0ZSksIGxvYWRSb3V0ZUNodW5rKHJvdXRlLCBcIm5vdEZvdW5kQ29tcG9uZW50XCIpXSk7XG5cdFx0XHRcdFx0ZWxzZSBhd2FpdCBsb2FkUm91dGVDaHVuayhyb3V0ZSwgXCJub3RGb3VuZENvbXBvbmVudFwiKTtcblx0XHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRhd2FpdCBwcm9qZWN0TGFuZShyb3V0ZXIsIHtcblx0XHRcdGxvY2F0aW9uOiBsYW5lLmxvY2F0aW9uLFxuXHRcdFx0bWF0Y2hlczogbGFuZS5tYXRjaGVzXG5cdFx0fSwgc2lnbmFsKTtcblx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0cm91dGVyLnNlcnZlclNzcj8ub25DbGVhbnVwKChzZXR0bGVkKSA9PiB7XG5cdFx0XHRpZiAoIXNldHRsZWQpIGFib3J0TGFuZSgpO1xuXHRcdH0pO1xuXHRcdHJldHVybiB7XG5cdFx0XHR0eXBlOiBcInJlbmRlclwiLFxuXHRcdFx0c3RhdHVzOiB0ZXJtaW5hbC5zdGF0dXMsXG5cdFx0XHRtYXRjaGVzOiBsYW5lLm1hdGNoZXNcblx0XHR9O1xuXHR9IGZpbmFsbHkge1xuXHRcdHNpZ25hbD8ucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIGFib3J0TGFuZSk7XG5cdH1cbn1cbmFzeW5jIGZ1bmN0aW9uIGxvYWRTZXJ2ZXJSb3V0ZShyb3V0ZXIsIG9wdHMpIHtcblx0aWYgKCFvcHRzPy5fc2tpcExvY2F0aW9uVXBkYXRlKSByb3V0ZXIudXBkYXRlTGF0ZXN0TG9jYXRpb24oKTtcblx0Y29uc3QgbmV4dCA9IHJvdXRlci5sYXRlc3RMb2NhdGlvbjtcblx0Y29uc3QgcHJldmlvdXMgPSByb3V0ZXIuX2NvbW1pdHRlZDtcblx0Y29uc3QgcHJldmlvdXNFbmQgPSByb3V0ZXIuX2xpZmVjeWNsZUVuZDtcblx0bGV0IHJlc3VsdDtcblx0dHJ5IHtcblx0XHRjb25zdCBjYW5vbmljYWwgPSByb3V0ZXIuYnVpbGRMb2NhdGlvbih7XG5cdFx0XHR0bzogbmV4dC5wYXRobmFtZSxcblx0XHRcdHNlYXJjaDogdHJ1ZSxcblx0XHRcdHBhcmFtczogdHJ1ZSxcblx0XHRcdGhhc2g6IHRydWUsXG5cdFx0XHRzdGF0ZTogdHJ1ZSxcblx0XHRcdF9pbmNsdWRlVmFsaWRhdGVTZWFyY2g6IHRydWVcblx0XHR9KTtcblx0XHRpZiAobmV4dC5wdWJsaWNIcmVmICE9PSBjYW5vbmljYWwucHVibGljSHJlZikge1xuXHRcdFx0Y29uc3QgaHJlZiA9IGNhbm9uaWNhbC5wdWJsaWNIcmVmIHx8IFwiL1wiO1xuXHRcdFx0dGhyb3cgcmVkaXJlY3QoeyBocmVmIH0pO1xuXHRcdH1cblx0XHRjb25zdCBmcm9tTG9jYXRpb24gPSByb3V0ZXIuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uZ2V0KCk7XG5cdFx0Y29uc3QgY2hhbmdlSW5mbyA9IGdldExvY2F0aW9uQ2hhbmdlSW5mbyhuZXh0LCBmcm9tTG9jYXRpb24pO1xuXHRcdHJvdXRlci5lbWl0KHtcblx0XHRcdHR5cGU6IFwib25CZWZvcmVOYXZpZ2F0ZVwiLFxuXHRcdFx0Li4uY2hhbmdlSW5mb1xuXHRcdH0pO1xuXHRcdHJvdXRlci5lbWl0KHtcblx0XHRcdHR5cGU6IFwib25CZWZvcmVMb2FkXCIsXG5cdFx0XHQuLi5jaGFuZ2VJbmZvXG5cdFx0fSk7XG5cdFx0b3B0cz8uX3NpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRyZXN1bHQgPSBhd2FpdCB3YWl0Rm9yKGV4ZWN1dGVTZXJ2ZXJMYW5lKHJvdXRlciwgbmV4dCwgcm91dGVyLm1hdGNoUm91dGVzKG5leHQpLCBvcHRzPy5fc2lnbmFsKSwgb3B0cz8uX3NpZ25hbCk7XG5cdFx0b3B0cz8uX3NpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRvcHRzPy5fc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGlmICghaXNSZWRpcmVjdChjYXVzZSkpIHRocm93IGNhdXNlO1xuXHRcdGNhdXNlLm9wdGlvbnMuX2Zyb21Mb2NhdGlvbiA9IG5leHQ7XG5cdFx0cmVzdWx0ID0ge1xuXHRcdFx0dHlwZTogXCJyZWRpcmVjdFwiLFxuXHRcdFx0cmVkaXJlY3Q6IHJvdXRlci5yZXNvbHZlUmVkaXJlY3QoY2F1c2UpXG5cdFx0fTtcblx0fVxuXHRyb3V0ZXIuX3NlcnZlclJlc3VsdCA9IHJlc3VsdDtcblx0bGV0IG5leHRFbmQgPSAwO1xuXHRyb3V0ZXIuYmF0Y2goKCkgPT4ge1xuXHRcdHJvdXRlci5zdG9yZXMubG9jYXRpb24uc2V0KG5leHQpO1xuXHRcdHJvdXRlci5zdG9yZXMuc3RhdHVzLnNldChcImlkbGVcIik7XG5cdFx0aWYgKHJlc3VsdC50eXBlID09PSBcInJlbmRlclwiKSB7XG5cdFx0XHRyb3V0ZXIuX2NvbW1pdHRlZCA9IHJlc3VsdC5tYXRjaGVzO1xuXHRcdFx0bmV4dEVuZCA9IHJvdXRlci5fbGlmZWN5Y2xlRW5kID0gbGlmZWN5Y2xlRW5kKHJlc3VsdC5tYXRjaGVzKTtcblx0XHRcdHJvdXRlci5zdG9yZXMuc2V0TWF0Y2hlcyhyZXN1bHQubWF0Y2hlcyk7XG5cdFx0XHRyb3V0ZXIuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uc2V0KG5leHQpO1xuXHRcdH1cblx0fSk7XG5cdGlmIChyZXN1bHQudHlwZSA9PT0gXCJyZW5kZXJcIikgcnVuUm91dGVMaWZlY3ljbGUocm91dGVyLCBwcmV2aW91cywgcmVzdWx0Lm1hdGNoZXMsIHByZXZpb3VzRW5kLCBuZXh0RW5kKTtcblx0cm91dGVyLl9jb21taXRQcm9taXNlPy5yZXNvbHZlKCk7XG5cdHJvdXRlci5fY29tbWl0UHJvbWlzZSA9IHZvaWQgMDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgbG9hZFNlcnZlclJvdXRlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWxvYWQtc2VydmVyLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuLyoqXG4qIFJlYWN0LnVzZSBpZiBhdmFpbGFibGUgKFJlYWN0IDE5KyksIHVuZGVmaW5lZCBvdGhlcndpc2UuXG4qIFVzZSBkeW5hbWljIGxvb2t1cCB0byBhdm9pZCBXZWJwYWNrIGNvbXBpbGF0aW9uIGVycm9ycyB3aXRoIFJlYWN0IDE4LlxuKi9cbnZhciByZWFjdFVzZSA9IFJlYWN0JDFbXCJ1c2VcIl07XG52YXIgdXNlTGF5b3V0RWZmZWN0ID0gaXNTZXJ2ZXIgPz8gdHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIiA/IFJlYWN0JDEudXNlRWZmZWN0IDogUmVhY3QkMS51c2VMYXlvdXRFZmZlY3Q7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHJlYWN0VXNlLCB1c2VMYXlvdXRFZmZlY3QgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXRpbHMuanMubWFwIiwiaW1wb3J0IHsgZGVmYXVsdFNlcmlhbGl6ZUVycm9yIH0gZnJvbSBcIi4vcm91dGVyLmpzXCI7XG4vLyNyZWdpb24gc3JjL2RlZmVyLnRzXG4vKipcbiogV2VsbC1rbm93biBzeW1ib2wgdXNlZCBieSB7QGxpbmsgZGVmZXJ9IHRvIHRhZyBhIHByb21pc2Ugd2l0aFxuKiBpdHMgZGVmZXJyZWQgc3RhdGUuIENvbnN1bWVycyBjYW4gcmVhZCBgcHJvbWlzZVtUU1JfREVGRVJSRURfUFJPTUlTRV1gXG4qIHRvIGFjY2VzcyBgc3RhdHVzYCwgYGRhdGFgLCBvciBgZXJyb3JgLlxuKi9cbmNvbnN0IFRTUl9ERUZFUlJFRF9QUk9NSVNFID0gU3ltYm9sLmZvcihcIlRTUl9ERUZFUlJFRF9QUk9NSVNFXCIpO1xuLyoqXG4qIFdyYXAgYSBwcm9taXNlIHdpdGggYSBkZWZlcnJlZCBzdGF0ZSBmb3IgdXNlIHdpdGggYDxBd2FpdD5gIGFuZCBgdXNlQXdhaXRlZGAuXG4qXG4qIFRoZSByZXR1cm5lZCBwcm9taXNlIGlzIGF1Z21lbnRlZCB3aXRoIGludGVybmFsIHN0YXRlIChzdGF0dXMvZGF0YS9lcnJvcilcbiogc28gVUkgY2FuIHJlYWQgcHJvZ3Jlc3Mgb3Igc3VzcGVuZCB1bnRpbCBpdCBzZXR0bGVzLlxuKlxuKiBAcGFyYW0gX3Byb21pc2UgVGhlIHByb21pc2UgdG8gd3JhcC5cbiogQHBhcmFtIG9wdGlvbnMgT3B0aW9uYWwgY29uZmlnLiBQcm92aWRlIGBzZXJpYWxpemVFcnJvcmAgdG8gY3VzdG9taXplIGhvd1xuKiBlcnJvcnMgYXJlIHNlcmlhbGl6ZWQgZm9yIHRyYW5zZmVyLlxuKiBAcmV0dXJucyBUaGUgc2FtZSBwcm9taXNlIHdpdGggYXR0YWNoZWQgZGVmZXJyZWQgbWV0YWRhdGEuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9kZWZlckZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gZGVmZXIoX3Byb21pc2UsIG9wdGlvbnMpIHtcblx0Y29uc3QgcHJvbWlzZSA9IF9wcm9taXNlO1xuXHRpZiAocHJvbWlzZVtUU1JfREVGRVJSRURfUFJPTUlTRV0pIHJldHVybiBwcm9taXNlO1xuXHRwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXSA9IHsgc3RhdHVzOiBcInBlbmRpbmdcIiB9O1xuXHRwcm9taXNlLnRoZW4oKGRhdGEpID0+IHtcblx0XHRwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXS5zdGF0dXMgPSBcInN1Y2Nlc3NcIjtcblx0XHRwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXS5kYXRhID0gZGF0YTtcblx0fSkuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0cHJvbWlzZVtUU1JfREVGRVJSRURfUFJPTUlTRV0uc3RhdHVzID0gXCJlcnJvclwiO1xuXHRcdHByb21pc2VbVFNSX0RFRkVSUkVEX1BST01JU0VdLmVycm9yID0ge1xuXHRcdFx0ZGF0YTogKG9wdGlvbnM/LnNlcmlhbGl6ZUVycm9yID8/IGRlZmF1bHRTZXJpYWxpemVFcnJvcikoZXJyb3IpLFxuXHRcdFx0X19pc1NlcnZlckVycm9yOiB0cnVlXG5cdFx0fTtcblx0fSk7XG5cdHJldHVybiBwcm9taXNlO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBUU1JfREVGRVJSRURfUFJPTUlTRSwgZGVmZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZGVmZXIuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9saW5rLnRzXG5jb25zdCBwcmVsb2FkV2FybmluZyA9IFwiRXJyb3IgcHJlbG9hZGluZyByb3V0ZSEg4pid77iPXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHByZWxvYWRXYXJuaW5nIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWxpbmsuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9tYW5pZmVzdC50c1xuY29uc3QgREVWX1NUWUxFU19BVFRSID0gXCJkYXRhLXRhbnN0YWNrLXJvdXRlci1kZXYtc3R5bGVzXCI7XG5mdW5jdGlvbiBnZXRBc3NldENyb3NzT3JpZ2luKGFzc2V0Q3Jvc3NPcmlnaW4sIGtpbmQpIHtcblx0aWYgKCFhc3NldENyb3NzT3JpZ2luKSByZXR1cm47XG5cdGlmICh0eXBlb2YgYXNzZXRDcm9zc09yaWdpbiA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIGFzc2V0Q3Jvc3NPcmlnaW47XG5cdHJldHVybiBhc3NldENyb3NzT3JpZ2luW2tpbmRdO1xufVxuZnVuY3Rpb24gZ2V0TWFuaWZlc3RTY3JpcHRGb3JtYXQobWFuaWZlc3QpIHtcblx0cmV0dXJuIG1hbmlmZXN0Py5zY3JpcHRGb3JtYXQgPz8gXCJtb2R1bGVcIjtcbn1cbmZ1bmN0aW9uIGdldFNjcmlwdFByZWxvYWRBdHRycyhtYW5pZmVzdCwgbGluaywgYXNzZXRDcm9zc09yaWdpbikge1xuXHRjb25zdCBwcmVsb2FkTGluayA9IHJlc29sdmVNYW5pZmVzdEFzc2V0TGluayhsaW5rKTtcblx0Y29uc3QgY3Jvc3NPcmlnaW4gPSBnZXRBc3NldENyb3NzT3JpZ2luKGFzc2V0Q3Jvc3NPcmlnaW4sIFwic2NyaXB0XCIpID8/IHByZWxvYWRMaW5rLmNyb3NzT3JpZ2luO1xuXHRyZXR1cm4ge1xuXHRcdC4uLmdldE1hbmlmZXN0U2NyaXB0Rm9ybWF0KG1hbmlmZXN0KSA9PT0gXCJpaWZlXCIgPyB7XG5cdFx0XHRyZWw6IFwicHJlbG9hZFwiLFxuXHRcdFx0YXM6IFwic2NyaXB0XCJcblx0XHR9IDogeyByZWw6IFwibW9kdWxlcHJlbG9hZFwiIH0sXG5cdFx0aHJlZjogcHJlbG9hZExpbmsuaHJlZixcblx0XHRmZXRjaFByaW9yaXR5OiBcImxvd1wiLFxuXHRcdC4uLmNyb3NzT3JpZ2luID8geyBjcm9zc09yaWdpbiB9IDoge31cblx0fTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVNYW5pZmVzdEFzc2V0TGluayhsaW5rKSB7XG5cdGlmICh0eXBlb2YgbGluayA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIHtcblx0XHRocmVmOiBsaW5rLFxuXHRcdGNyb3NzT3JpZ2luOiB2b2lkIDBcblx0fTtcblx0cmV0dXJuIGxpbms7XG59XG5mdW5jdGlvbiBhcHBlbmRVbmlxdWVVc2VyVGFncyh0YXJnZXQsIHRhZ3MpIHtcblx0aWYgKHRhZ3MubGVuZ3RoID09PSAwKSByZXR1cm47XG5cdGlmICh0YWdzLmxlbmd0aCA9PT0gMSkge1xuXHRcdHRhcmdldC5wdXNoKHRhZ3NbMF0pO1xuXHRcdHJldHVybjtcblx0fVxuXHRjb25zdCBzZWVuID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0Zm9yIChjb25zdCB0YWcgb2YgdGFncykge1xuXHRcdGNvbnN0IGtleSA9IEpTT04uc3RyaW5naWZ5KHRhZyk7XG5cdFx0aWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlO1xuXHRcdHNlZW4uYWRkKGtleSk7XG5cdFx0dGFyZ2V0LnB1c2godGFnKTtcblx0fVxufVxuZnVuY3Rpb24gZ2V0U3R5bGVzaGVldEhyZWYoYXNzZXQpIHtcblx0cmV0dXJuIHJlc29sdmVNYW5pZmVzdENzc0xpbmsoYXNzZXQpLmhyZWY7XG59XG5mdW5jdGlvbiByZXNvbHZlTWFuaWZlc3RDc3NMaW5rKGxpbmspIHtcblx0aWYgKHR5cGVvZiBsaW5rID09PSBcInN0cmluZ1wiKSByZXR1cm4ge1xuXHRcdGhyZWY6IGxpbmssXG5cdFx0Y3Jvc3NPcmlnaW46IHZvaWQgMFxuXHR9O1xuXHRyZXR1cm4gbGluaztcbn1cbmZ1bmN0aW9uIGNyZWF0ZUlubGluZUNzc1N0eWxlQXNzZXQoY3NzKSB7XG5cdHJldHVybiB7XG5cdFx0YXR0cnM6IHsgc3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlIH0sXG5cdFx0Y2hpbGRyZW46IGNzc1xuXHR9O1xufVxuZnVuY3Rpb24gY3JlYXRlSW5saW5lQ3NzUGxhY2Vob2xkZXJBc3NldCgpIHtcblx0cmV0dXJuIHsgYXR0cnM6IHsgc3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlIH0gfTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgREVWX1NUWUxFU19BVFRSLCBhcHBlbmRVbmlxdWVVc2VyVGFncywgY3JlYXRlSW5saW5lQ3NzUGxhY2Vob2xkZXJBc3NldCwgY3JlYXRlSW5saW5lQ3NzU3R5bGVBc3NldCwgZ2V0QXNzZXRDcm9zc09yaWdpbiwgZ2V0TWFuaWZlc3RTY3JpcHRGb3JtYXQsIGdldFNjcmlwdFByZWxvYWRBdHRycywgZ2V0U3R5bGVzaGVldEhyZWYsIHJlc29sdmVNYW5pZmVzdEFzc2V0TGluaywgcmVzb2x2ZU1hbmlmZXN0Q3NzTGluayB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1tYW5pZmVzdC5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL01hdGNoZXMudHNcbi8qKlxuKiBOYXJyb3dzIG1hdGNoZXMgYmFzZWQgb24gYSBwYXRoXG4qIEBleHBlcmltZW50YWxcbiovXG5jb25zdCBpc01hdGNoID0gKG1hdGNoLCBwYXRoKSA9PiB7XG5cdGNvbnN0IHBhcnRzID0gcGF0aC5zcGxpdChcIi5cIik7XG5cdGxldCBwYXJ0O1xuXHRsZXQgaSA9IDA7XG5cdGxldCB2YWx1ZSA9IG1hdGNoO1xuXHR3aGlsZSAoKHBhcnQgPSBwYXJ0c1tpKytdKSAhPSBudWxsICYmIHZhbHVlICE9IG51bGwpIHZhbHVlID0gdmFsdWVbcGFydF07XG5cdHJldHVybiB2YWx1ZSAhPSBudWxsO1xufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaXNNYXRjaCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1NYXRjaGVzLmpzLm1hcCIsImltcG9ydCB7IF9nZXRBc3NldE1hdGNoZXMgfSBmcm9tIFwiLi4vbG9hZC1jbGllbnQuanNcIjtcbi8vI3JlZ2lvbiBzcmMvc3NyL2JvZHlTY3JpcHRzLnRzXG5mdW5jdGlvbiBnZXRTc3JCb2R5U2NyaXB0UGFydHMobWF0Y2hlcywgbWFuaWZlc3QsIG5vbmNlLCByb3V0ZVNjcmlwdEF0dHJzKSB7XG5cdGNvbnN0IGFzc2V0TWF0Y2hlcyA9IF9nZXRBc3NldE1hdGNoZXMobWF0Y2hlcyk7XG5cdGNvbnN0IHJvdXRlU2NyaXB0cyA9IFtdO1xuXHRjb25zdCBtYW5pZmVzdFNjcmlwdHMgPSBbXTtcblx0Zm9yIChjb25zdCBtYXRjaCBvZiBhc3NldE1hdGNoZXMpIGZvciAoY29uc3Qgc2NyaXB0IG9mIEFycmF5LmlzQXJyYXkobWF0Y2guc2NyaXB0cykgPyBtYXRjaC5zY3JpcHRzIDogW10pIHtcblx0XHRpZiAoIXNjcmlwdCkgY29udGludWU7XG5cdFx0Y29uc3QgeyBjaGlsZHJlbiwgLi4uYXR0cnMgfSA9IHNjcmlwdDtcblx0XHRyb3V0ZVNjcmlwdHMucHVzaCh7XG5cdFx0XHR0YWc6IFwic2NyaXB0XCIsXG5cdFx0XHRhdHRyczoge1xuXHRcdFx0XHQuLi5hdHRycyxcblx0XHRcdFx0Li4ucm91dGVTY3JpcHRBdHRycyxcblx0XHRcdFx0bm9uY2Vcblx0XHRcdH0sXG5cdFx0XHRjaGlsZHJlblxuXHRcdH0pO1xuXHR9XG5cdGlmIChtYW5pZmVzdCkgZm9yIChjb25zdCBtYXRjaCBvZiBhc3NldE1hdGNoZXMpIGZvciAoY29uc3QgYXNzZXQgb2YgbWFuaWZlc3Qucm91dGVzW21hdGNoLnJvdXRlSWRdPy5zY3JpcHRzID8/IFtdKSBtYW5pZmVzdFNjcmlwdHMucHVzaCh7XG5cdFx0dGFnOiBcInNjcmlwdFwiLFxuXHRcdGF0dHJzOiB7XG5cdFx0XHQuLi5hc3NldC5hdHRycyxcblx0XHRcdG5vbmNlXG5cdFx0fSxcblx0XHRjaGlsZHJlbjogYXNzZXQuY2hpbGRyZW5cblx0fSk7XG5cdHJldHVybiBbcm91dGVTY3JpcHRzLCBtYW5pZmVzdFNjcmlwdHNdO1xufVxuZnVuY3Rpb24gY29tcG9zZVNzckJvZHlTY3JpcHRzKFtyb3V0ZVNjcmlwdHMsIG1hbmlmZXN0U2NyaXB0c10sIGluaXRpYWxIeWRyYXRpb25TY3JpcHRzKSB7XG5cdGlmICghaW5pdGlhbEh5ZHJhdGlvblNjcmlwdHMpIHJldHVybiBbLi4ucm91dGVTY3JpcHRzLCAuLi5tYW5pZmVzdFNjcmlwdHNdO1xuXHRyZXR1cm4gW1xuXHRcdC4uLmluaXRpYWxIeWRyYXRpb25TY3JpcHRzLmJlZm9yZSxcblx0XHQuLi5yb3V0ZVNjcmlwdHMsXG5cdFx0Li4ubWFuaWZlc3RTY3JpcHRzLFxuXHRcdGluaXRpYWxIeWRyYXRpb25TY3JpcHRzLmJvdW5kYXJ5XG5cdF07XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNvbXBvc2VTc3JCb2R5U2NyaXB0cywgZ2V0U3NyQm9keVNjcmlwdFBhcnRzIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJvZHlTY3JpcHRzLmpzLm1hcCIsImltcG9ydCB7IGludmFyaWFudCB9IGZyb20gXCIuL2ludmFyaWFudC5qc1wiO1xuaW1wb3J0IHsgY2xlYW5QYXRoLCB0cmltUGF0aExlZnQsIHRyaW1QYXRoUmlnaHQgfSBmcm9tIFwiLi9wYXRoLmpzXCI7XG5pbXBvcnQgeyBub3RGb3VuZCB9IGZyb20gXCIuL25vdC1mb3VuZC5qc1wiO1xuaW1wb3J0IHsgcm9vdFJvdXRlSWQgfSBmcm9tIFwiLi9yb290LmpzXCI7XG5pbXBvcnQgeyByZWRpcmVjdCB9IGZyb20gXCIuL3JlZGlyZWN0LmpzXCI7XG4vLyNyZWdpb24gc3JjL3JvdXRlLnRzXG52YXIgQmFzZVJvdXRlID0gY2xhc3Mge1xuXHRnZXQgdG8oKSB7XG5cdFx0cmV0dXJuIHRoaXMuX3RvO1xuXHR9XG5cdGdldCBpZCgpIHtcblx0XHRyZXR1cm4gdGhpcy5faWQ7XG5cdH1cblx0Z2V0IHBhdGgoKSB7XG5cdFx0cmV0dXJuIHRoaXMuX3BhdGg7XG5cdH1cblx0Z2V0IGZ1bGxQYXRoKCkge1xuXHRcdHJldHVybiB0aGlzLl9mdWxsUGF0aDtcblx0fVxuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0dGhpcy5pbml0ID0gKG9yaWdpbmFsSW5kZXgpID0+IHtcblx0XHRcdHRoaXMub3JpZ2luYWxJbmRleCA9IG9yaWdpbmFsSW5kZXg7XG5cdFx0XHR0aGlzLl9icmFuY2ggPSB2b2lkIDA7XG5cdFx0XHRjb25zdCBvcHRpb25zID0gdGhpcy5vcHRpb25zO1xuXHRcdFx0Y29uc3QgaXNSb290ID0gIW9wdGlvbnM/LnBhdGggJiYgIW9wdGlvbnM/LmlkO1xuXHRcdFx0dGhpcy5wYXJlbnRSb3V0ZSA9IHRoaXMub3B0aW9ucy5nZXRQYXJlbnRSb3V0ZT8uKCk7XG5cdFx0XHRpZiAoaXNSb290KSB0aGlzLl9wYXRoID0gcm9vdFJvdXRlSWQ7XG5cdFx0XHRlbHNlIGlmICghdGhpcy5wYXJlbnRSb3V0ZSkge1xuXHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0aHJvdyBuZXcgRXJyb3IoYEludmFyaWFudCBmYWlsZWQ6IENoaWxkIFJvdXRlIGluc3RhbmNlcyBtdXN0IHBhc3MgYSAnZ2V0UGFyZW50Um91dGU6ICgpID0+IFBhcmVudFJvdXRlJyBvcHRpb24gdGhhdCByZXR1cm5zIGEgUm91dGUgaW5zdGFuY2UuYCk7XG5cdFx0XHRcdGludmFyaWFudCgpO1xuXHRcdFx0fVxuXHRcdFx0bGV0IHBhdGggPSBpc1Jvb3QgPyByb290Um91dGVJZCA6IG9wdGlvbnM/LnBhdGg7XG5cdFx0XHRpZiAocGF0aCAmJiBwYXRoICE9PSBcIi9cIikgcGF0aCA9IHRyaW1QYXRoTGVmdChwYXRoKTtcblx0XHRcdGNvbnN0IGN1c3RvbUlkID0gb3B0aW9ucz8uaWQgfHwgcGF0aDtcblx0XHRcdGNvbnN0IGlkID0gaXNSb290ID8gcm9vdFJvdXRlSWQgOiBjbGVhblBhdGgoKHRoaXMucGFyZW50Um91dGUuaWQgPT09IFwiX19yb290X19cIiA/IFwiXCIgOiB0aGlzLnBhcmVudFJvdXRlLmlkKSArIFwiL1wiICsgKGN1c3RvbUlkID8/IFwiXCIpKTtcblx0XHRcdGlmIChwYXRoID09PSBcIl9fcm9vdF9fXCIpIHBhdGggPSBcIi9cIjtcblx0XHRcdGNvbnN0IGZ1bGxQYXRoID0gaWQgPT09IFwiX19yb290X19cIiA/IFwiL1wiIDogcGF0aCA9PT0gdm9pZCAwID8gdGhpcy5wYXJlbnRSb3V0ZS5mdWxsUGF0aCA6IGNsZWFuUGF0aCh0aGlzLnBhcmVudFJvdXRlLmZ1bGxQYXRoICsgXCIvXCIgKyBwYXRoKTtcblx0XHRcdHRoaXMuX3BhdGggPSBwYXRoO1xuXHRcdFx0dGhpcy5faWQgPSBpZDtcblx0XHRcdHRoaXMuX2Z1bGxQYXRoID0gZnVsbFBhdGg7XG5cdFx0XHR0aGlzLl90byA9IHRyaW1QYXRoUmlnaHQoZnVsbFBhdGgpO1xuXHRcdH07XG5cdFx0dGhpcy5hZGRDaGlsZHJlbiA9IChjaGlsZHJlbikgPT4ge1xuXHRcdFx0cmV0dXJuIHRoaXMuX2FkZEZpbGVDaGlsZHJlbihjaGlsZHJlbik7XG5cdFx0fTtcblx0XHR0aGlzLl9hZGRGaWxlQ2hpbGRyZW4gPSAoY2hpbGRyZW4pID0+IHtcblx0XHRcdGlmIChBcnJheS5pc0FycmF5KGNoaWxkcmVuKSkgdGhpcy5jaGlsZHJlbiA9IGNoaWxkcmVuO1xuXHRcdFx0aWYgKHR5cGVvZiBjaGlsZHJlbiA9PT0gXCJvYmplY3RcIiAmJiBjaGlsZHJlbiAhPT0gbnVsbCkgdGhpcy5jaGlsZHJlbiA9IE9iamVjdC52YWx1ZXMoY2hpbGRyZW4pO1xuXHRcdFx0cmV0dXJuIHRoaXM7XG5cdFx0fTtcblx0XHR0aGlzLl9hZGRGaWxlVHlwZXMgPSAoKSA9PiB7XG5cdFx0XHRyZXR1cm4gdGhpcztcblx0XHR9O1xuXHRcdHRoaXMudXBkYXRlTG9hZGVyID0gKG9wdGlvbnMpID0+IHtcblx0XHRcdE9iamVjdC5hc3NpZ24odGhpcy5vcHRpb25zLCBvcHRpb25zKTtcblx0XHRcdHJldHVybiB0aGlzO1xuXHRcdH07XG5cdFx0dGhpcy51cGRhdGUgPSAob3B0aW9ucykgPT4ge1xuXHRcdFx0T2JqZWN0LmFzc2lnbih0aGlzLm9wdGlvbnMsIG9wdGlvbnMpO1xuXHRcdFx0cmV0dXJuIHRoaXM7XG5cdFx0fTtcblx0XHR0aGlzLmxhenkgPSAobGF6eUZuKSA9PiB7XG5cdFx0XHR0aGlzLmxhenlGbiA9IGxhenlGbjtcblx0XHRcdHJldHVybiB0aGlzO1xuXHRcdH07XG5cdFx0dGhpcy5yZWRpcmVjdCA9IChvcHRzKSA9PiByZWRpcmVjdCh7XG5cdFx0XHRmcm9tOiB0aGlzLmZ1bGxQYXRoLFxuXHRcdFx0Li4ub3B0c1xuXHRcdH0pO1xuXHRcdHRoaXMub3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG5cdFx0dGhpcy5pc1Jvb3QgPSAhb3B0aW9ucz8uZ2V0UGFyZW50Um91dGU7XG5cdFx0aWYgKG9wdGlvbnM/LmlkICYmIG9wdGlvbnM/LnBhdGgpIHRocm93IG5ldyBFcnJvcihgUm91dGUgY2Fubm90IGhhdmUgYm90aCBhbiAnaWQnIGFuZCBhICdwYXRoJyBvcHRpb24uYCk7XG5cdH1cbn07XG52YXIgQmFzZVJvdXRlQXBpID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3Rvcih7IGlkIH0pIHtcblx0XHR0aGlzLm5vdEZvdW5kID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiBub3RGb3VuZCh7XG5cdFx0XHRcdHJvdXRlSWQ6IHRoaXMuaWQsXG5cdFx0XHRcdC4uLm9wdHNcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy5yZWRpcmVjdCA9IChvcHRzKSA9PiByZWRpcmVjdCh7XG5cdFx0XHRmcm9tOiB0aGlzLmlkLFxuXHRcdFx0Li4ub3B0c1xuXHRcdH0pO1xuXHRcdHRoaXMuaWQgPSBpZDtcblx0fVxufTtcbnZhciBCYXNlUm9vdFJvdXRlID0gY2xhc3MgZXh0ZW5kcyBCYXNlUm91dGUge1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIob3B0aW9ucyk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEJhc2VSb290Um91dGUsIEJhc2VSb3V0ZSwgQmFzZVJvdXRlQXBpIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdXRlLmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvY29uZmlnLnRzXG5jb25zdCBjcmVhdGVSb3V0ZXJDb25maWcgPSAob3B0aW9ucykgPT4ge1xuXHRyZXR1cm4ge1xuXHRcdHNlcmlhbGl6YXRpb25BZGFwdGVyczogb3B0aW9ucy5zZXJpYWxpemF0aW9uQWRhcHRlcnMsXG5cdFx0ZGVmYXVsdFNzcjogb3B0aW9ucy5kZWZhdWx0U3NyXG5cdH07XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjcmVhdGVSb3V0ZXJDb25maWcgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29uZmlnLmpzLm1hcCIsImltcG9ydCB7IGRlZXBFcXVhbCwgaGFzT3duIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vI3JlZ2lvbiBzcmMvc2VhcmNoTWlkZGxld2FyZS50c1xuLyoqXG4qIFJldGFpbiBzcGVjaWZpZWQgc2VhcmNoIHBhcmFtcyBhY3Jvc3MgbmF2aWdhdGlvbnMuXG4qXG4qIElmIGBrZXlzYCBpcyBgdHJ1ZWAsIHJldGFpbiBhbGwgY3VycmVudCBwYXJhbXMuIE90aGVyd2lzZSwgY29weSBvbmx5IHRoZVxuKiBsaXN0ZWQga2V5cyBmcm9tIHRoZSBjdXJyZW50IHNlYXJjaCBpbnRvIHRoZSBuZXh0IHNlYXJjaC5cbipcbiogQHBhcmFtIGtleXMgYHRydWVgIHRvIHJldGFpbiBhbGwsIG9yIGEgbGlzdCBvZiBrZXlzIHRvIHJldGFpbi5cbiogQHJldHVybnMgQSBzZWFyY2ggbWlkZGxld2FyZSBzdWl0YWJsZSBmb3Igcm91dGUgYHNlYXJjaC5taWRkbGV3YXJlc2AuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9yZXRhaW5TZWFyY2hQYXJhbXNGdW5jdGlvblxuKi9cbmZ1bmN0aW9uIHJldGFpblNlYXJjaFBhcmFtcyhrZXlzKSB7XG5cdHJldHVybiAoeyBzZWFyY2gsIG5leHQgfSkgPT4ge1xuXHRcdGNvbnN0IHsgc2VhcmNoOiByZXN1bHRTZWFyY2gsIG1ldGEgfSA9IG5leHQoc2VhcmNoLCB0cnVlKTtcblx0XHRpZiAoa2V5cyA9PT0gdHJ1ZSkge1xuXHRcdFx0Y29uc3QgY29weSA9IHtcblx0XHRcdFx0Li4uc2VhcmNoLFxuXHRcdFx0XHQuLi5yZXN1bHRTZWFyY2hcblx0XHRcdH07XG5cdFx0XHRjb25zdCByZW1vdmVkID0gbWV0YS5yZW1vdmVkO1xuXHRcdFx0Y29uc3QgZXhwbGljaXQgPSBtZXRhLmV4cGxpY2l0O1xuXHRcdFx0Zm9yIChjb25zdCBrZXkgb2YgcmVtb3ZlZD8ua2V5cygpIHx8IFtdKSBpZiAoZXhwbGljaXQgJiYgaGFzT3duLmNhbGwoZXhwbGljaXQsIGtleSkgfHwgZGVlcEVxdWFsKHNlYXJjaFtrZXldLCByZW1vdmVkLmdldChrZXkpKSkgZGVsZXRlIGNvcHlba2V5XTtcblx0XHRcdGZvciAoY29uc3Qga2V5IG9mIG1ldGEucmVtb3ZlZEFueSB8fCBbXSkgZGVsZXRlIGNvcHlba2V5XTtcblx0XHRcdGZvciAoY29uc3Qga2V5IG9mIG1ldGEuZGVmYXVsdGVkPy5rZXlzKCkgfHwgW10pIGlmIChrZXkgaW4gc2VhcmNoICYmICFtZXRhLnJlbW92ZWRBbnk/LmhhcyhrZXkpICYmICEobWV0YS5yZW1vdmVkPy5oYXMoa2V5KSAmJiAoZXhwbGljaXQgJiYgaGFzT3duLmNhbGwoZXhwbGljaXQsIGtleSkgfHwgZGVlcEVxdWFsKHNlYXJjaFtrZXldLCBtZXRhLnJlbW92ZWQuZ2V0KGtleSkpKSkpIGNvcHlba2V5XSA9IHNlYXJjaFtrZXldO1xuXHRcdFx0cmV0dXJuIGNvcHk7XG5cdFx0fVxuXHRcdGNvbnN0IGNvcHkgPSB7IC4uLnJlc3VsdFNlYXJjaCB9O1xuXHRcdGNvbnN0IGV4cGxpY2l0ID0gbWV0YS5leHBsaWNpdDtcblx0XHRmb3IgKGNvbnN0IGtleSBvZiBrZXlzKSB7XG5cdFx0XHRjb25zdCBzdHJpbmdLZXkgPSBrZXk7XG5cdFx0XHRpZiAoIShtZXRhLnJlbW92ZWRBbnk/LmhhcyhzdHJpbmdLZXkpIHx8IG1ldGEucmVtb3ZlZD8uaGFzKHN0cmluZ0tleSkgJiYgKGV4cGxpY2l0ICYmIGhhc093bi5jYWxsKGV4cGxpY2l0LCBzdHJpbmdLZXkpIHx8IGRlZXBFcXVhbChzZWFyY2hba2V5XSwgbWV0YS5yZW1vdmVkLmdldChzdHJpbmdLZXkpKSkpICYmICghKGtleSBpbiBjb3B5KSB8fCBrZXkgaW4gc2VhcmNoICYmIG1ldGEuZGVmYXVsdGVkPy5oYXMoc3RyaW5nS2V5KSAmJiBkZWVwRXF1YWwoY29weVtrZXldLCBtZXRhLmRlZmF1bHRlZC5nZXQoc3RyaW5nS2V5KSkpKSBjb3B5W2tleV0gPSBzZWFyY2hba2V5XTtcblx0XHR9XG5cdFx0cmV0dXJuIGNvcHk7XG5cdH07XG59XG4vKipcbiogUmVtb3ZlIG9wdGlvbmFsIG9yIGRlZmF1bHQtdmFsdWVkIHNlYXJjaCBwYXJhbXMgZnJvbSBuYXZpZ2F0aW9ucy5cbipcbiogLSBQYXNzIGB0cnVlYCAob25seSBpZiB0aGVyZSBhcmUgbm8gcmVxdWlyZWQgc2VhcmNoIHBhcmFtcykgdG8gc3RyaXAgYWxsLlxuKiAtIFBhc3MgYW4gYXJyYXkgdG8gYWx3YXlzIHJlbW92ZSB0aG9zZSBvcHRpb25hbCBrZXlzLlxuKiAtIFBhc3MgYW4gb2JqZWN0IG9mIGRlZmF1bHQgdmFsdWVzOyBrZXlzIGVxdWFsIChkZWVwbHkpIHRvIHRoZSBkZWZhdWx0cyBhcmUgcmVtb3ZlZC5cbipcbiogQHJldHVybnMgQSBzZWFyY2ggbWlkZGxld2FyZSBzdWl0YWJsZSBmb3Igcm91dGUgYHNlYXJjaC5taWRkbGV3YXJlc2AuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9zdHJpcFNlYXJjaFBhcmFtc0Z1bmN0aW9uXG4qL1xuZnVuY3Rpb24gc3RyaXBTZWFyY2hQYXJhbXMoaW5wdXQpIHtcblx0cmV0dXJuICgoeyBzZWFyY2gsIG5leHQsIG1ldGEgfSkgPT4ge1xuXHRcdGlmIChpbnB1dCA9PT0gdHJ1ZSkge1xuXHRcdFx0T2JqZWN0LmtleXMoc2VhcmNoKS5mb3JFYWNoKChrZXkpID0+IHtcblx0XHRcdFx0aWYgKG1ldGEpIChtZXRhLnJlbW92ZWRBbnkgfHw9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCkpLmFkZChrZXkpO1xuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4ge307XG5cdFx0fVxuXHRcdGNvbnN0IHJlc3VsdCA9IHsgLi4ubmV4dChzZWFyY2gpIH07XG5cdFx0aWYgKEFycmF5LmlzQXJyYXkoaW5wdXQpKSBpbnB1dC5mb3JFYWNoKChrZXkpID0+IHtcblx0XHRcdGRlbGV0ZSByZXN1bHRba2V5XTtcblx0XHRcdGlmIChtZXRhKSAobWV0YS5yZW1vdmVkQW55IHx8PSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpKS5hZGQoa2V5KTtcblx0XHR9KTtcblx0XHRlbHNlIE9iamVjdC5lbnRyaWVzKGlucHV0KS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcblx0XHRcdGlmIChkZWVwRXF1YWwocmVzdWx0W2tleV0sIHZhbHVlKSkge1xuXHRcdFx0XHRkZWxldGUgcmVzdWx0W2tleV07XG5cdFx0XHRcdGlmIChtZXRhKSAobWV0YS5yZW1vdmVkIHx8PSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKS5zZXQoa2V5LCB2YWx1ZSk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHJldGFpblNlYXJjaFBhcmFtcywgc3RyaXBTZWFyY2hQYXJhbXMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2VhcmNoTWlkZGxld2FyZS5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3Nzci9zZXJpYWxpemVyL3RyYW5zZm9ybWVyLnRzXG4vKipcbiogQ3JlYXRlIGEgc3Ryb25nbHktdHlwZWQgc2VyaWFsaXphdGlvbiBhZGFwdGVyIGZvciBTU1IgaHlkcmF0aW9uLlxuKiBVc2UgdG8gcmVnaXN0ZXIgY3VzdG9tIHR5cGVzIHdpdGggdGhlIHJvdXRlciBzZXJpYWxpemVyLlxuKi9cbmZ1bmN0aW9uIGNyZWF0ZVNlcmlhbGl6YXRpb25BZGFwdGVyKG9wdHMpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdGlmICghb3B0cy5rZXkgfHwgL1tcXDBcIlxcXFw8XFxiXFx0XFxmXFxyXFxuXFx1MjAyOFxcdTIwMjlcXHVEODAwLVxcdURGRkZdLy50ZXN0KG9wdHMua2V5KSkgdGhyb3cgbmV3IEVycm9yKGBjcmVhdGVTZXJpYWxpemF0aW9uQWRhcHRlcjoga2V5ICR7SlNPTi5zdHJpbmdpZnkob3B0cy5rZXkpfSBpcyBpbnZhbGlkLiBTZXJpYWxpemF0aW9uIGFkYXB0ZXIga2V5cyBtdXN0IGJlIG5vbi1lbXB0eSBhbmQgbm90IGNvbnRhaW4gTlVMLCBcIiwgXFxcXCwgPCwgYmFja3NwYWNlLCB0YWIsIGZvcm0gZmVlZCwgbGluZSB0ZXJtaW5hdG9ycywgb3IgVVRGLTE2IHN1cnJvZ2F0ZSBjb2RlIHVuaXRzLmApO1xuXHR9XG5cdHJldHVybiBvcHRzO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjcmVhdGVTZXJpYWxpemF0aW9uQWRhcHRlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD10cmFuc2Zvcm1lci5qcy5tYXAiLCJpbXBvcnQgeyByZWFjdFVzZSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBUU1JfREVGRVJSRURfUFJPTUlTRSwgZGVmZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL2F3YWl0ZWQudHN4XG4vKiogU3VzcGVuZCB1bnRpbCBhIGRlZmVycmVkIHByb21pc2UgcmVzb2x2ZXMgb3IgcmVqZWN0cyBhbmQgcmV0dXJuIGl0cyBkYXRhLiAqL1xuZnVuY3Rpb24gdXNlQXdhaXRlZCh7IHByb21pc2U6IF9wcm9taXNlIH0pIHtcblx0aWYgKHJlYWN0VXNlKSByZXR1cm4gcmVhY3RVc2UoX3Byb21pc2UpO1xuXHRjb25zdCBwcm9taXNlID0gZGVmZXIoX3Byb21pc2UpO1xuXHRpZiAocHJvbWlzZVtUU1JfREVGRVJSRURfUFJPTUlTRV0uc3RhdHVzID09PSBcInBlbmRpbmdcIikgdGhyb3cgcHJvbWlzZTtcblx0aWYgKHByb21pc2VbVFNSX0RFRkVSUkVEX1BST01JU0VdLnN0YXR1cyA9PT0gXCJlcnJvclwiKSB0aHJvdyBwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXS5lcnJvcjtcblx0cmV0dXJuIHByb21pc2VbVFNSX0RFRkVSUkVEX1BST01JU0VdLmRhdGE7XG59XG4vKipcbiogQ29tcG9uZW50IHRoYXQgc3VzcGVuZHMgb24gYSBkZWZlcnJlZCBwcm9taXNlIGFuZCByZW5kZXJzIGl0cyBjaGlsZCB3aXRoXG4qIHRoZSByZXNvbHZlZCB2YWx1ZS4gT3B0aW9uYWxseSBwcm92aWRlcyBhIFN1c3BlbnNlIGZhbGxiYWNrLlxuKi9cbmZ1bmN0aW9uIEF3YWl0KHByb3BzKSB7XG5cdGNvbnN0IGlubmVyID0gLyogQF9fUFVSRV9fICovIGpzeChBd2FpdElubmVyLCB7IC4uLnByb3BzIH0pO1xuXHRpZiAocHJvcHMuZmFsbGJhY2spIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFJlYWN0JDEuU3VzcGVuc2UsIHtcblx0XHRmYWxsYmFjazogcHJvcHMuZmFsbGJhY2ssXG5cdFx0Y2hpbGRyZW46IGlubmVyXG5cdH0pO1xuXHRyZXR1cm4gaW5uZXI7XG59XG5mdW5jdGlvbiBBd2FpdElubmVyKHByb3BzKSB7XG5cdGNvbnN0IGRhdGEgPSB1c2VBd2FpdGVkKHByb3BzKTtcblx0cmV0dXJuIHByb3BzLmNoaWxkcmVuKGRhdGEpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBBd2FpdCwgdXNlQXdhaXRlZCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hd2FpdGVkLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9ub25Sb3V0ZUNvbXBvbmVudENvbnRleHQudHN4XG52YXIgbm9uUm91dGVDb21wb25lbnRDb250ZXh0ID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gUmVhY3QkMS5jcmVhdGVDb250ZXh0KHZvaWQgMCkgOiB2b2lkIDA7XG5mdW5jdGlvbiB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQoZWxlbWVudCwgY29tcG9uZW50KSB7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KG5vblJvdXRlQ29tcG9uZW50Q29udGV4dC5Qcm92aWRlciwge1xuXHRcdHZhbHVlOiBjb21wb25lbnQsXG5cdFx0Y2hpbGRyZW46IGVsZW1lbnRcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IG5vblJvdXRlQ29tcG9uZW50Q29udGV4dCwgd3JhcEluTm9uUm91dGVDb21wb25lbnRDb250ZXh0IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vblJvdXRlQ29tcG9uZW50Q29udGV4dC5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHdyYXBJbk5vblJvdXRlQ29tcG9uZW50Q29udGV4dCB9IGZyb20gXCIuL25vblJvdXRlQ29tcG9uZW50Q29udGV4dC5qc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCwganN4cyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9DYXRjaEJvdW5kYXJ5LnRzeFxudmFyIENhdGNoQm91bmRhcnkgPSBjbGFzcyBleHRlbmRzIFJlYWN0JDEuQ29tcG9uZW50IHtcblx0Y29uc3RydWN0b3IoLi4uX2FyZ3MpIHtcblx0XHRzdXBlciguLi5fYXJncyk7XG5cdFx0dGhpcy5zdGF0ZSA9IHsgZXJyb3I6IDAgfTtcblx0XHR0aGlzLnJlc2V0ID0gKCkgPT4ge1xuXHRcdFx0dGhpcy5zZXRTdGF0ZSh7IGVycm9yOiAwIH0pO1xuXHRcdH07XG5cdH1cblx0c3RhdGljIGdldERlcml2ZWRTdGF0ZUZyb21Qcm9wcyhwcm9wcywgc3RhdGUpIHtcblx0XHRjb25zdCByZXNldEtleSA9IHByb3BzLmdldFJlc2V0S2V5KCk7XG5cdFx0aWYgKHN0YXRlLmVycm9yICYmIHN0YXRlLnJlc2V0S2V5ICE9PSByZXNldEtleSkgcmV0dXJuIHtcblx0XHRcdHJlc2V0S2V5LFxuXHRcdFx0ZXJyb3I6IDBcblx0XHR9O1xuXHRcdHJldHVybiB7IHJlc2V0S2V5IH07XG5cdH1cblx0c3RhdGljIGdldERlcml2ZWRTdGF0ZUZyb21FcnJvcihlcnJvcikge1xuXHRcdHJldHVybiB7IGVycm9yOiBbZXJyb3JdIH07XG5cdH1cblx0Y29tcG9uZW50RGlkQ2F0Y2goZXJyb3IsIGVycm9ySW5mbykge1xuXHRcdHRoaXMucHJvcHMub25DYXRjaD8uKGVycm9yLCBlcnJvckluZm8pO1xuXHR9XG5cdHJlbmRlcigpIHtcblx0XHRjb25zdCBlcnJvciA9IHRoaXMuc3RhdGUuZXJyb3I7XG5cdFx0aWYgKGVycm9yKSB7XG5cdFx0XHRjb25zdCBlbGVtZW50ID0gUmVhY3QkMS5jcmVhdGVFbGVtZW50KHRoaXMucHJvcHMuZXJyb3JDb21wb25lbnQgPz8gRXJyb3JDb21wb25lbnQsIHtcblx0XHRcdFx0ZXJyb3I6IGVycm9yWzBdLFxuXHRcdFx0XHRyZXNldDogdGhpcy5yZXNldFxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gd3JhcEluTm9uUm91dGVDb21wb25lbnRDb250ZXh0KGVsZW1lbnQsIFwiZXJyb3JDb21wb25lbnRcIikgOiBlbGVtZW50O1xuXHRcdH1cblx0XHRyZXR1cm4gdGhpcy5wcm9wcy5jaGlsZHJlbjtcblx0fVxufTtcbmZ1bmN0aW9uIEVycm9yQ29tcG9uZW50KHsgZXJyb3IgfSkge1xuXHRjb25zdCBbc2hvdywgc2V0U2hvd10gPSBSZWFjdCQxLnVzZVN0YXRlKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIik7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4cyhcImRpdlwiLCB7XG5cdFx0c3R5bGU6IHtcblx0XHRcdHBhZGRpbmc6IFwiLjVyZW1cIixcblx0XHRcdG1heFdpZHRoOiBcIjEwMCVcIlxuXHRcdH0sXG5cdFx0Y2hpbGRyZW46IFtcblx0XHRcdC8qIEBfX1BVUkVfXyAqLyBqc3hzKFwiZGl2XCIsIHtcblx0XHRcdFx0c3R5bGU6IHtcblx0XHRcdFx0XHRkaXNwbGF5OiBcImZsZXhcIixcblx0XHRcdFx0XHRhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuXHRcdFx0XHRcdGdhcDogXCIuNXJlbVwiXG5cdFx0XHRcdH0sXG5cdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIGpzeChcInN0cm9uZ1wiLCB7XG5cdFx0XHRcdFx0c3R5bGU6IHsgZm9udFNpemU6IFwiMXJlbVwiIH0sXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCJcblx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJidXR0b25cIiwge1xuXHRcdFx0XHRcdHN0eWxlOiB7XG5cdFx0XHRcdFx0XHRhcHBlYXJhbmNlOiBcIm5vbmVcIixcblx0XHRcdFx0XHRcdGZvbnRTaXplOiBcIi42ZW1cIixcblx0XHRcdFx0XHRcdGJvcmRlcjogXCIxcHggc29saWQgY3VycmVudENvbG9yXCIsXG5cdFx0XHRcdFx0XHRwYWRkaW5nOiBcIi4xcmVtIC4ycmVtXCIsXG5cdFx0XHRcdFx0XHRmb250V2VpZ2h0OiBcImJvbGRcIixcblx0XHRcdFx0XHRcdGJvcmRlclJhZGl1czogXCIuMjVyZW1cIlxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0b25DbGljazogKCkgPT4gc2V0U2hvdygoZCkgPT4gIWQpLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBzaG93ID8gXCJIaWRlIEVycm9yXCIgOiBcIlNob3cgRXJyb3JcIlxuXHRcdFx0XHR9KV1cblx0XHRcdH0pLFxuXHRcdFx0LyogQF9fUFVSRV9fICovIGpzeChcImRpdlwiLCB7IHN0eWxlOiB7IGhlaWdodDogXCIuMjVyZW1cIiB9IH0pLFxuXHRcdFx0c2hvdyA/IC8qIEBfX1BVUkVfXyAqLyBqc3goXCJkaXZcIiwgeyBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChcInByZVwiLCB7XG5cdFx0XHRcdHN0eWxlOiB7XG5cdFx0XHRcdFx0Zm9udFNpemU6IFwiLjdlbVwiLFxuXHRcdFx0XHRcdGJvcmRlcjogXCIxcHggc29saWQgcmVkXCIsXG5cdFx0XHRcdFx0Ym9yZGVyUmFkaXVzOiBcIi4yNXJlbVwiLFxuXHRcdFx0XHRcdHBhZGRpbmc6IFwiLjNyZW1cIixcblx0XHRcdFx0XHRjb2xvcjogXCJyZWRcIixcblx0XHRcdFx0XHRvdmVyZmxvdzogXCJhdXRvXCJcblx0XHRcdFx0fSxcblx0XHRcdFx0Y2hpbGRyZW46IGVycm9yPy5tZXNzYWdlID8gLyogQF9fUFVSRV9fICovIGpzeChcImNvZGVcIiwgeyBjaGlsZHJlbjogZXJyb3IubWVzc2FnZSB9KSA6IG51bGxcblx0XHRcdH0pIH0pIDogbnVsbFxuXHRcdF1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IENhdGNoQm91bmRhcnksIEVycm9yQ29tcG9uZW50IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUNhdGNoQm91bmRhcnkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvQ2xpZW50T25seS50c3hcbnZhciBnZXRTbmFwc2hvdCA9ICgpID0+IHRydWU7XG52YXIgZ2V0U2VydmVyU25hcHNob3QgPSAoKSA9PiBmYWxzZTtcbi8qKlxuKiBSZW5kZXIgdGhlIGNoaWxkcmVuIG9ubHkgYWZ0ZXIgdGhlIEpTIGhhcyBsb2FkZWQgY2xpZW50LXNpZGUuIFVzZSBhbiBvcHRpb25hbFxuKiBmYWxsYmFjayBjb21wb25lbnQgaWYgdGhlIEpTIGlzIG5vdCB5ZXQgbG9hZGVkLlxuKlxuKiBAZXhhbXBsZVxuKiBSZW5kZXIgYSBDaGFydCBjb21wb25lbnQgaWYgSlMgbG9hZHMsIHJlbmRlcnMgYSBzaW1wbGUgRmFrZUNoYXJ0XG4qIGNvbXBvbmVudCBzZXJ2ZXItc2lkZSBvciBpZiB0aGVyZSBpcyBubyBKUy4gVGhlIEZha2VDaGFydCBjYW4gaGF2ZSBvbmx5IHRoZVxuKiBVSSB3aXRob3V0IHRoZSBiZWhhdmlvciBvciBiZSBhIGxvYWRpbmcgc3Bpbm5lciBvciBza2VsZXRvbi5cbipcbiogYGBgdHN4XG4qIHJldHVybiAoXG4qICAgPENsaWVudE9ubHkgZmFsbGJhY2s9ezxGYWtlQ2hhcnQgLz59PlxuKiAgICAgPENoYXJ0IC8+XG4qICAgPC9DbGllbnRPbmx5PlxuKiApXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIENsaWVudE9ubHkoeyBjaGlsZHJlbiwgZmFsbGJhY2sgPSBudWxsIH0pIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUmVhY3QuRnJhZ21lbnQsIHsgY2hpbGRyZW46IHVzZUh5ZHJhdGVkKCkgPyBjaGlsZHJlbiA6IGZhbGxiYWNrIH0pO1xufVxuLyoqIEBpbnRlcm5hbCAqL1xuZnVuY3Rpb24gdXNlSHlkcmF0ZWQoZW5hYmxlZCA9IHRydWUpIHtcblx0cmV0dXJuIFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKHN1YnNjcmliZSwgZ2V0U25hcHNob3QsIGVuYWJsZWQgPyBnZXRTZXJ2ZXJTbmFwc2hvdCA6IGdldFNuYXBzaG90KTtcbn1cbmZ1bmN0aW9uIHN1YnNjcmliZSgpIHtcblx0cmV0dXJuICgpID0+IHt9O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBDbGllbnRPbmx5LCB1c2VIeWRyYXRlZCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1DbGllbnRPbmx5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbi8vI3JlZ2lvbiBzcmMvcm91dGVyQ29udGV4dC50c3hcbnZhciByb3V0ZXJDb250ZXh0ID0gUmVhY3QkMS5jcmVhdGVDb250ZXh0KG51bGwpO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyByb3V0ZXJDb250ZXh0IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdXRlckNvbnRleHQuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyByb3V0ZXJDb250ZXh0IH0gZnJvbSBcIi4vcm91dGVyQ29udGV4dC5qc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlUm91dGVyLnRzeFxuLyoqXG4qIEFjY2VzcyB0aGUgY3VycmVudCBUYW5TdGFjayBSb3V0ZXIgaW5zdGFuY2UgZnJvbSBSZWFjdCBjb250ZXh0LlxuKiBNdXN0IGJlIHVzZWQgd2l0aGluIGEgYFJvdXRlclByb3ZpZGVyYC5cbipcbiogT3B0aW9uczpcbiogLSBgd2FybmA6IExvZyBhIHdhcm5pbmcgaWYgbm8gcm91dGVyIGNvbnRleHQgaXMgZm91bmQgKGRlZmF1bHQ6IHRydWUpLlxuKlxuKiBAcmV0dXJucyBUaGUgcmVnaXN0ZXJlZCByb3V0ZXIgaW5zdGFuY2UuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci91c2VSb3V0ZXJIb29rXG4qL1xuZnVuY3Rpb24gdXNlUm91dGVyKG9wdHMpIHtcblx0Y29uc3QgdmFsdWUgPSBSZWFjdCQxLnVzZUNvbnRleHQocm91dGVyQ29udGV4dCk7XG5cdGlmICghdmFsdWUpIHdhcm5NaXNzaW5nUm91dGVyKG9wdHMpO1xuXHRyZXR1cm4gdmFsdWU7XG59XG5mdW5jdGlvbiB3YXJuTWlzc2luZ1JvdXRlcihvcHRzKSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgKG9wdHM/Lndhcm4gPz8gdHJ1ZSkpIGNvbnNvbGUud2FybihcIldhcm5pbmc6IHVzZVJvdXRlciBtdXN0IGJlIHVzZWQgaW5zaWRlIGEgPFJvdXRlclByb3ZpZGVyPiBjb21wb25lbnQhXCIpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VSb3V0ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlUm91dGVyLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgX2lzUm91dGVEZXBhcnRpbmcgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuLy8jcmVnaW9uIHNyYy9tYXRjaENvbnRleHQudHN4XG5mdW5jdGlvbiBjcmVhdGVMaW5rU2NvcGUocm91dGVyLCByb3V0ZUlkKSB7XG5cdGNvbnN0IHN0b3JlID0gcm91dGVyLnN0b3Jlcy5sb2NhdGlvbjtcblx0Y29uc3QgbGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0bGV0IHNvdXJjZTtcblx0bGV0IHVuc3Vic2NyaWJlO1xuXHRjb25zdCB1cGRhdGUgPSAobG9jYXRpb24pID0+IHtcblx0XHRpZiAoIV9pc1JvdXRlRGVwYXJ0aW5nKHJvdXRlciwgcm91dGVJZCwgbG9jYXRpb24pKSB7XG5cdFx0XHRzb3VyY2UgPSBsb2NhdGlvbjtcblx0XHRcdGxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4gbGlzdGVuZXIoKSk7XG5cdFx0fVxuXHR9O1xuXHRyZXR1cm4gWygpID0+IHNvdXJjZSA/PyBzdG9yZS5nZXQoKSwgKGxpc3RlbmVyKSA9PiB7XG5cdFx0aWYgKCFsaXN0ZW5lcnMuc2l6ZSkge1xuXHRcdFx0c291cmNlID0gc3RvcmUuZ2V0KCk7XG5cdFx0XHR1bnN1YnNjcmliZSA9IHN0b3JlLnN1YnNjcmliZSh1cGRhdGUpLnVuc3Vic2NyaWJlO1xuXHRcdH1cblx0XHRsaXN0ZW5lcnMuYWRkKGxpc3RlbmVyKTtcblx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0bGlzdGVuZXJzLmRlbGV0ZShsaXN0ZW5lcik7XG5cdFx0XHRpZiAoIWxpc3RlbmVycy5zaXplKSB7XG5cdFx0XHRcdHVuc3Vic2NyaWJlKCk7XG5cdFx0XHRcdHNvdXJjZSA9IHZvaWQgMDtcblx0XHRcdH1cblx0XHR9O1xuXHR9XTtcbn1cbnZhciBtYXRjaENvbnRleHQgPSBSZWFjdCQxLmNyZWF0ZUNvbnRleHQodm9pZCAwKTtcbnZhciBkdW1teU1hdGNoQ29udGV4dCA9IFJlYWN0JDEuY3JlYXRlQ29udGV4dCh2b2lkIDApO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjcmVhdGVMaW5rU2NvcGUsIGR1bW15TWF0Y2hDb250ZXh0LCBtYXRjaENvbnRleHQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bWF0Y2hDb250ZXh0LmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvYWxpZW4udHNcbmNvbnN0IE5PTkUgPSAwO1xuY29uc3QgTVVUQUJMRSA9IDE7XG5jb25zdCBXQVRDSElORyA9IDI7XG5jb25zdCBSRUNVUlNFRF9DSEVDSyA9IDQ7XG5jb25zdCBSRUNVUlNFRCA9IDg7XG5jb25zdCBESVJUWSA9IDE2O1xuY29uc3QgUEVORElORyA9IDMyO1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGNyZWF0ZVJlYWN0aXZlU3lzdGVtKHsgdXBkYXRlLCBub3RpZnksIHVud2F0Y2hlZCB9KSB7XG5cdHJldHVybiB7XG5cdFx0bGluayxcblx0XHR1bmxpbmssXG5cdFx0cHJvcGFnYXRlLFxuXHRcdGNoZWNrRGlydHksXG5cdFx0c2hhbGxvd1Byb3BhZ2F0ZVxuXHR9O1xuXHRmdW5jdGlvbiBsaW5rKGRlcCwgc3ViLCB2ZXJzaW9uKSB7XG5cdFx0Y29uc3QgcHJldkRlcCA9IHN1Yi5kZXBzVGFpbDtcblx0XHRpZiAocHJldkRlcCAhPT0gdm9pZCAwICYmIHByZXZEZXAuZGVwID09PSBkZXApIHJldHVybjtcblx0XHRjb25zdCBuZXh0RGVwID0gcHJldkRlcCAhPT0gdm9pZCAwID8gcHJldkRlcC5uZXh0RGVwIDogc3ViLmRlcHM7XG5cdFx0aWYgKG5leHREZXAgIT09IHZvaWQgMCAmJiBuZXh0RGVwLmRlcCA9PT0gZGVwKSB7XG5cdFx0XHRuZXh0RGVwLnZlcnNpb24gPSB2ZXJzaW9uO1xuXHRcdFx0c3ViLmRlcHNUYWlsID0gbmV4dERlcDtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0Y29uc3QgcHJldlN1YiA9IGRlcC5zdWJzVGFpbDtcblx0XHRpZiAocHJldlN1YiAhPT0gdm9pZCAwICYmIHByZXZTdWIudmVyc2lvbiA9PT0gdmVyc2lvbiAmJiBwcmV2U3ViLnN1YiA9PT0gc3ViKSByZXR1cm47XG5cdFx0Y29uc3QgbmV3TGluayA9IHN1Yi5kZXBzVGFpbCA9IGRlcC5zdWJzVGFpbCA9IHtcblx0XHRcdHZlcnNpb24sXG5cdFx0XHRkZXAsXG5cdFx0XHRzdWIsXG5cdFx0XHRwcmV2RGVwLFxuXHRcdFx0bmV4dERlcCxcblx0XHRcdHByZXZTdWIsXG5cdFx0XHRuZXh0U3ViOiB2b2lkIDBcblx0XHR9O1xuXHRcdGlmIChuZXh0RGVwICE9PSB2b2lkIDApIG5leHREZXAucHJldkRlcCA9IG5ld0xpbms7XG5cdFx0aWYgKHByZXZEZXAgIT09IHZvaWQgMCkgcHJldkRlcC5uZXh0RGVwID0gbmV3TGluaztcblx0XHRlbHNlIHN1Yi5kZXBzID0gbmV3TGluaztcblx0XHRpZiAocHJldlN1YiAhPT0gdm9pZCAwKSBwcmV2U3ViLm5leHRTdWIgPSBuZXdMaW5rO1xuXHRcdGVsc2UgZGVwLnN1YnMgPSBuZXdMaW5rO1xuXHR9XG5cdGZ1bmN0aW9uIHVubGluayhsaW5rLCBzdWIgPSBsaW5rLnN1Yikge1xuXHRcdGNvbnN0IGRlcCA9IGxpbmsuZGVwO1xuXHRcdGNvbnN0IHByZXZEZXAgPSBsaW5rLnByZXZEZXA7XG5cdFx0Y29uc3QgbmV4dERlcCA9IGxpbmsubmV4dERlcDtcblx0XHRjb25zdCBuZXh0U3ViID0gbGluay5uZXh0U3ViO1xuXHRcdGNvbnN0IHByZXZTdWIgPSBsaW5rLnByZXZTdWI7XG5cdFx0aWYgKG5leHREZXAgIT09IHZvaWQgMCkgbmV4dERlcC5wcmV2RGVwID0gcHJldkRlcDtcblx0XHRlbHNlIHN1Yi5kZXBzVGFpbCA9IHByZXZEZXA7XG5cdFx0aWYgKHByZXZEZXAgIT09IHZvaWQgMCkgcHJldkRlcC5uZXh0RGVwID0gbmV4dERlcDtcblx0XHRlbHNlIHN1Yi5kZXBzID0gbmV4dERlcDtcblx0XHRpZiAobmV4dFN1YiAhPT0gdm9pZCAwKSBuZXh0U3ViLnByZXZTdWIgPSBwcmV2U3ViO1xuXHRcdGVsc2UgZGVwLnN1YnNUYWlsID0gcHJldlN1Yjtcblx0XHRpZiAocHJldlN1YiAhPT0gdm9pZCAwKSBwcmV2U3ViLm5leHRTdWIgPSBuZXh0U3ViO1xuXHRcdGVsc2UgaWYgKChkZXAuc3VicyA9IG5leHRTdWIpID09PSB2b2lkIDApIHVud2F0Y2hlZChkZXApO1xuXHRcdHJldHVybiBuZXh0RGVwO1xuXHR9XG5cdGZ1bmN0aW9uIHByb3BhZ2F0ZShsaW5rKSB7XG5cdFx0bGV0IG5leHQgPSBsaW5rLm5leHRTdWI7XG5cdFx0bGV0IHN0YWNrO1xuXHRcdHRvcDogZG8ge1xuXHRcdFx0Y29uc3Qgc3ViID0gbGluay5zdWI7XG5cdFx0XHRsZXQgZmxhZ3MgPSBzdWIuZmxhZ3M7XG5cdFx0XHRpZiAoIShmbGFncyAmIDYwKSkgc3ViLmZsYWdzID0gZmxhZ3MgfCAzMjtcblx0XHRcdGVsc2UgaWYgKCEoZmxhZ3MgJiAoNCB8IDgpKSkgZmxhZ3MgPSAwO1xuXHRcdFx0ZWxzZSBpZiAoIShmbGFncyAmIDQpKSBzdWIuZmxhZ3MgPSBmbGFncyAmIH44IHwgMzI7XG5cdFx0XHRlbHNlIGlmICghKGZsYWdzICYgKDE2IHwgMzIpKSAmJiBpc1ZhbGlkTGluayhsaW5rLCBzdWIpKSB7XG5cdFx0XHRcdHN1Yi5mbGFncyA9IGZsYWdzIHwgKDggfCAzMik7XG5cdFx0XHRcdGZsYWdzICY9IDE7XG5cdFx0XHR9IGVsc2UgZmxhZ3MgPSAwO1xuXHRcdFx0aWYgKGZsYWdzICYgMikgbm90aWZ5KHN1Yik7XG5cdFx0XHRpZiAoZmxhZ3MgJiAxKSB7XG5cdFx0XHRcdGNvbnN0IHN1YlN1YnMgPSBzdWIuc3Vicztcblx0XHRcdFx0aWYgKHN1YlN1YnMgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdGNvbnN0IG5leHRTdWIgPSAobGluayA9IHN1YlN1YnMpLm5leHRTdWI7XG5cdFx0XHRcdFx0aWYgKG5leHRTdWIgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdFx0c3RhY2sgPSB7XG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBuZXh0LFxuXHRcdFx0XHRcdFx0XHRwcmV2OiBzdGFja1xuXHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRcdG5leHQgPSBuZXh0U3ViO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRjb250aW51ZTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKChsaW5rID0gbmV4dCkgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRuZXh0ID0gbGluay5uZXh0U3ViO1xuXHRcdFx0XHRjb250aW51ZTtcblx0XHRcdH1cblx0XHRcdHdoaWxlIChzdGFjayAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdGxpbmsgPSBzdGFjay52YWx1ZTtcblx0XHRcdFx0c3RhY2sgPSBzdGFjay5wcmV2O1xuXHRcdFx0XHRpZiAobGluayAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0bmV4dCA9IGxpbmsubmV4dFN1Yjtcblx0XHRcdFx0XHRjb250aW51ZSB0b3A7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGJyZWFrO1xuXHRcdH0gd2hpbGUgKHRydWUpO1xuXHR9XG5cdGZ1bmN0aW9uIGNoZWNrRGlydHkobGluaywgc3ViKSB7XG5cdFx0bGV0IHN0YWNrO1xuXHRcdGxldCBjaGVja0RlcHRoID0gMDtcblx0XHRsZXQgZGlydHkgPSBmYWxzZTtcblx0XHR0b3A6IGRvIHtcblx0XHRcdGNvbnN0IGRlcCA9IGxpbmsuZGVwO1xuXHRcdFx0Y29uc3QgZmxhZ3MgPSBkZXAuZmxhZ3M7XG5cdFx0XHRpZiAoc3ViLmZsYWdzICYgMTYpIGRpcnR5ID0gdHJ1ZTtcblx0XHRcdGVsc2UgaWYgKChmbGFncyAmICgxIHwgMTYpKSA9PT0gKDEgfCAxNikpIHtcblx0XHRcdFx0aWYgKHVwZGF0ZShkZXApKSB7XG5cdFx0XHRcdFx0Y29uc3Qgc3VicyA9IGRlcC5zdWJzO1xuXHRcdFx0XHRcdGlmIChzdWJzLm5leHRTdWIgIT09IHZvaWQgMCkgc2hhbGxvd1Byb3BhZ2F0ZShzdWJzKTtcblx0XHRcdFx0XHRkaXJ0eSA9IHRydWU7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBpZiAoKGZsYWdzICYgKDEgfCAzMikpID09PSAoMSB8IDMyKSkge1xuXHRcdFx0XHRpZiAobGluay5uZXh0U3ViICE9PSB2b2lkIDAgfHwgbGluay5wcmV2U3ViICE9PSB2b2lkIDApIHN0YWNrID0ge1xuXHRcdFx0XHRcdHZhbHVlOiBsaW5rLFxuXHRcdFx0XHRcdHByZXY6IHN0YWNrXG5cdFx0XHRcdH07XG5cdFx0XHRcdGxpbmsgPSBkZXAuZGVwcztcblx0XHRcdFx0c3ViID0gZGVwO1xuXHRcdFx0XHQrK2NoZWNrRGVwdGg7XG5cdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0fVxuXHRcdFx0aWYgKCFkaXJ0eSkge1xuXHRcdFx0XHRjb25zdCBuZXh0RGVwID0gbGluay5uZXh0RGVwO1xuXHRcdFx0XHRpZiAobmV4dERlcCAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0bGluayA9IG5leHREZXA7XG5cdFx0XHRcdFx0Y29udGludWU7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHdoaWxlIChjaGVja0RlcHRoLS0pIHtcblx0XHRcdFx0Y29uc3QgZmlyc3RTdWIgPSBzdWIuc3Vicztcblx0XHRcdFx0Y29uc3QgaGFzTXVsdGlwbGVTdWJzID0gZmlyc3RTdWIubmV4dFN1YiAhPT0gdm9pZCAwO1xuXHRcdFx0XHRpZiAoaGFzTXVsdGlwbGVTdWJzKSB7XG5cdFx0XHRcdFx0bGluayA9IHN0YWNrLnZhbHVlO1xuXHRcdFx0XHRcdHN0YWNrID0gc3RhY2sucHJldjtcblx0XHRcdFx0fSBlbHNlIGxpbmsgPSBmaXJzdFN1Yjtcblx0XHRcdFx0aWYgKGRpcnR5KSB7XG5cdFx0XHRcdFx0aWYgKHVwZGF0ZShzdWIpKSB7XG5cdFx0XHRcdFx0XHRpZiAoaGFzTXVsdGlwbGVTdWJzKSBzaGFsbG93UHJvcGFnYXRlKGZpcnN0U3ViKTtcblx0XHRcdFx0XHRcdHN1YiA9IGxpbmsuc3ViO1xuXHRcdFx0XHRcdFx0Y29udGludWU7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGRpcnR5ID0gZmFsc2U7XG5cdFx0XHRcdH0gZWxzZSBzdWIuZmxhZ3MgJj0gfjMyO1xuXHRcdFx0XHRzdWIgPSBsaW5rLnN1Yjtcblx0XHRcdFx0Y29uc3QgbmV4dERlcCA9IGxpbmsubmV4dERlcDtcblx0XHRcdFx0aWYgKG5leHREZXAgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdGxpbmsgPSBuZXh0RGVwO1xuXHRcdFx0XHRcdGNvbnRpbnVlIHRvcDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGRpcnR5O1xuXHRcdH0gd2hpbGUgKHRydWUpO1xuXHR9XG5cdGZ1bmN0aW9uIHNoYWxsb3dQcm9wYWdhdGUobGluaykge1xuXHRcdGRvIHtcblx0XHRcdGNvbnN0IHN1YiA9IGxpbmsuc3ViO1xuXHRcdFx0Y29uc3QgZmxhZ3MgPSBzdWIuZmxhZ3M7XG5cdFx0XHRpZiAoKGZsYWdzICYgKDMyIHwgMTYpKSA9PT0gMzIpIHtcblx0XHRcdFx0c3ViLmZsYWdzID0gZmxhZ3MgfCAxNjtcblx0XHRcdFx0aWYgKChmbGFncyAmICgyIHwgNCkpID09PSAyKSBub3RpZnkoc3ViKTtcblx0XHRcdH1cblx0XHR9IHdoaWxlICgobGluayA9IGxpbmsubmV4dFN1YikgIT09IHZvaWQgMCk7XG5cdH1cblx0ZnVuY3Rpb24gaXNWYWxpZExpbmsoY2hlY2tMaW5rLCBzdWIpIHtcblx0XHRsZXQgbGluayA9IHN1Yi5kZXBzVGFpbDtcblx0XHR3aGlsZSAobGluayAhPT0gdm9pZCAwKSB7XG5cdFx0XHRpZiAobGluayA9PT0gY2hlY2tMaW5rKSByZXR1cm4gdHJ1ZTtcblx0XHRcdGxpbmsgPSBsaW5rLnByZXZEZXA7XG5cdFx0fVxuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufVxuXG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNyZWF0ZVJlYWN0aXZlU3lzdGVtIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1hbGllbi5qcy5tYXAiLCJpbXBvcnQgeyBjcmVhdGVSZWFjdGl2ZVN5c3RlbSB9IGZyb20gXCIuL2FsaWVuLmpzXCI7XG5cbi8vI3JlZ2lvbiBzcmMvYXRvbS50c1xuZnVuY3Rpb24gdG9PYnNlcnZlcihuZXh0SGFuZGxlciwgZXJyb3JIYW5kbGVyLCBjb21wbGV0aW9uSGFuZGxlcikge1xuXHRjb25zdCBpc09ic2VydmVyID0gdHlwZW9mIG5leHRIYW5kbGVyID09PSBcIm9iamVjdFwiO1xuXHRjb25zdCBzZWxmID0gaXNPYnNlcnZlciA/IG5leHRIYW5kbGVyIDogdm9pZCAwO1xuXHRyZXR1cm4ge1xuXHRcdG5leHQ6IChpc09ic2VydmVyID8gbmV4dEhhbmRsZXIubmV4dCA6IG5leHRIYW5kbGVyKT8uYmluZChzZWxmKSxcblx0XHRlcnJvcjogKGlzT2JzZXJ2ZXIgPyBuZXh0SGFuZGxlci5lcnJvciA6IGVycm9ySGFuZGxlcik/LmJpbmQoc2VsZiksXG5cdFx0Y29tcGxldGU6IChpc09ic2VydmVyID8gbmV4dEhhbmRsZXIuY29tcGxldGUgOiBjb21wbGV0aW9uSGFuZGxlcik/LmJpbmQoc2VsZilcblx0fTtcbn1cbmNvbnN0IHF1ZXVlZEVmZmVjdHMgPSBbXTtcbmxldCBjeWNsZSA9IDA7XG5jb25zdCB7IGxpbmssIHVubGluaywgcHJvcGFnYXRlLCBjaGVja0RpcnR5LCBzaGFsbG93UHJvcGFnYXRlIH0gPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlUmVhY3RpdmVTeXN0ZW0oe1xuXHR1cGRhdGUoYXRvbSkge1xuXHRcdHJldHVybiBhdG9tLl91cGRhdGUoKTtcblx0fSxcblx0bm90aWZ5KGVmZmVjdCkge1xuXHRcdHF1ZXVlZEVmZmVjdHNbcXVldWVkRWZmZWN0c0xlbmd0aCsrXSA9IGVmZmVjdDtcblx0XHRlZmZlY3QuZmxhZ3MgJj0gfjI7XG5cdH0sXG5cdHVud2F0Y2hlZChhdG9tKSB7XG5cdFx0aWYgKGF0b20uZGVwc1RhaWwgIT09IHZvaWQgMCkge1xuXHRcdFx0YXRvbS5kZXBzVGFpbCA9IHZvaWQgMDtcblx0XHRcdGF0b20uZmxhZ3MgPSAxIHwgMTY7XG5cdFx0XHRwdXJnZURlcHMoYXRvbSk7XG5cdFx0fVxuXHR9XG59KTtcbmxldCBub3RpZnlJbmRleCA9IDA7XG5sZXQgcXVldWVkRWZmZWN0c0xlbmd0aCA9IDA7XG5sZXQgYWN0aXZlU3ViO1xubGV0IGJhdGNoRGVwdGggPSAwO1xuZnVuY3Rpb24gYmF0Y2goZm4pIHtcblx0dHJ5IHtcblx0XHQrK2JhdGNoRGVwdGg7XG5cdFx0Zm4oKTtcblx0fSBmaW5hbGx5IHtcblx0XHRpZiAoIS0tYmF0Y2hEZXB0aCkgZmx1c2goKTtcblx0fVxufVxuZnVuY3Rpb24gcHVyZ2VEZXBzKHN1Yikge1xuXHRjb25zdCBkZXBzVGFpbCA9IHN1Yi5kZXBzVGFpbDtcblx0bGV0IGRlcCA9IGRlcHNUYWlsICE9PSB2b2lkIDAgPyBkZXBzVGFpbC5uZXh0RGVwIDogc3ViLmRlcHM7XG5cdHdoaWxlIChkZXAgIT09IHZvaWQgMCkgZGVwID0gdW5saW5rKGRlcCwgc3ViKTtcbn1cbmZ1bmN0aW9uIGZsdXNoKCkge1xuXHRpZiAoYmF0Y2hEZXB0aCA+IDApIHJldHVybjtcblx0d2hpbGUgKG5vdGlmeUluZGV4IDwgcXVldWVkRWZmZWN0c0xlbmd0aCkge1xuXHRcdGNvbnN0IGVmZmVjdCA9IHF1ZXVlZEVmZmVjdHNbbm90aWZ5SW5kZXhdO1xuXHRcdHF1ZXVlZEVmZmVjdHNbbm90aWZ5SW5kZXgrK10gPSB2b2lkIDA7XG5cdFx0ZWZmZWN0Lm5vdGlmeSgpO1xuXHR9XG5cdG5vdGlmeUluZGV4ID0gMDtcblx0cXVldWVkRWZmZWN0c0xlbmd0aCA9IDA7XG59XG5mdW5jdGlvbiBjcmVhdGVBc3luY0F0b20oZ2V0VmFsdWUsIG9wdGlvbnMpIHtcblx0Y29uc3QgcmVmID0ge307XG5cdGNvbnN0IGF0b20gPSBjcmVhdGVBdG9tKCgpID0+IHtcblx0XHRnZXRWYWx1ZSgpLnRoZW4oKGRhdGEpID0+IHtcblx0XHRcdGNvbnN0IGludGVybmFsQXRvbSA9IHJlZi5jdXJyZW50O1xuXHRcdFx0aWYgKGludGVybmFsQXRvbS5fdXBkYXRlKHtcblx0XHRcdFx0c3RhdHVzOiBcImRvbmVcIixcblx0XHRcdFx0ZGF0YVxuXHRcdFx0fSkpIHtcblx0XHRcdFx0Y29uc3Qgc3VicyA9IGludGVybmFsQXRvbS5zdWJzO1xuXHRcdFx0XHRpZiAoc3VicyAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0cHJvcGFnYXRlKHN1YnMpO1xuXHRcdFx0XHRcdHNoYWxsb3dQcm9wYWdhdGUoc3Vicyk7XG5cdFx0XHRcdFx0Zmx1c2goKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0sIChlcnJvcikgPT4ge1xuXHRcdFx0Y29uc3QgaW50ZXJuYWxBdG9tID0gcmVmLmN1cnJlbnQ7XG5cdFx0XHRpZiAoaW50ZXJuYWxBdG9tLl91cGRhdGUoe1xuXHRcdFx0XHRzdGF0dXM6IFwiZXJyb3JcIixcblx0XHRcdFx0ZXJyb3Jcblx0XHRcdH0pKSB7XG5cdFx0XHRcdGNvbnN0IHN1YnMgPSBpbnRlcm5hbEF0b20uc3Vicztcblx0XHRcdFx0aWYgKHN1YnMgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdHByb3BhZ2F0ZShzdWJzKTtcblx0XHRcdFx0XHRzaGFsbG93UHJvcGFnYXRlKHN1YnMpO1xuXHRcdFx0XHRcdGZsdXNoKCk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KTtcblx0XHRyZXR1cm4geyBzdGF0dXM6IFwicGVuZGluZ1wiIH07XG5cdH0sIG9wdGlvbnMpO1xuXHRyZWYuY3VycmVudCA9IGF0b207XG5cdHJldHVybiBhdG9tO1xufVxuZnVuY3Rpb24gY3JlYXRlQXRvbSh2YWx1ZU9yRm4sIG9wdGlvbnMpIHtcblx0Y29uc3QgaXNDb21wdXRlZCA9IHR5cGVvZiB2YWx1ZU9yRm4gPT09IFwiZnVuY3Rpb25cIjtcblx0Y29uc3QgZ2V0dGVyID0gdmFsdWVPckZuO1xuXHRjb25zdCBhdG9tID0ge1xuXHRcdF9zbmFwc2hvdDogaXNDb21wdXRlZCA/IHZvaWQgMCA6IHZhbHVlT3JGbixcblx0XHRzdWJzOiB2b2lkIDAsXG5cdFx0c3Vic1RhaWw6IHZvaWQgMCxcblx0XHRkZXBzOiB2b2lkIDAsXG5cdFx0ZGVwc1RhaWw6IHZvaWQgMCxcblx0XHRmbGFnczogaXNDb21wdXRlZCA/IDAgOiAxLFxuXHRcdGdldCgpIHtcblx0XHRcdGlmIChhY3RpdmVTdWIgIT09IHZvaWQgMCkgbGluayhhdG9tLCBhY3RpdmVTdWIsIGN5Y2xlKTtcblx0XHRcdHJldHVybiBhdG9tLl9zbmFwc2hvdDtcblx0XHR9LFxuXHRcdHN1YnNjcmliZShvYnNlcnZlck9yRm4pIHtcblx0XHRcdGNvbnN0IG9icyA9IHRvT2JzZXJ2ZXIob2JzZXJ2ZXJPckZuKTtcblx0XHRcdGNvbnN0IG9ic2VydmVkID0geyBjdXJyZW50OiBmYWxzZSB9O1xuXHRcdFx0Y29uc3QgZSA9IGVmZmVjdCgoKSA9PiB7XG5cdFx0XHRcdGF0b20uZ2V0KCk7XG5cdFx0XHRcdGlmICghb2JzZXJ2ZWQuY3VycmVudCkgb2JzZXJ2ZWQuY3VycmVudCA9IHRydWU7XG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdGFjdGl2ZVN1YiA9IHZvaWQgMDtcblx0XHRcdFx0XHRvYnMubmV4dD8uKGF0b20uX3NuYXBzaG90KTtcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4geyB1bnN1YnNjcmliZTogKCkgPT4ge1xuXHRcdFx0XHRlLnN0b3AoKTtcblx0XHRcdH0gfTtcblx0XHR9LFxuXHRcdF91cGRhdGUoZ2V0VmFsdWUpIHtcblx0XHRcdGNvbnN0IHByZXZTdWIgPSBhY3RpdmVTdWI7XG5cdFx0XHRjb25zdCBjb21wYXJlID0gb3B0aW9ucz8uY29tcGFyZSA/PyBPYmplY3QuaXM7XG5cdFx0XHRpZiAoaXNDb21wdXRlZCkge1xuXHRcdFx0XHRhY3RpdmVTdWIgPSBhdG9tO1xuXHRcdFx0XHQrK2N5Y2xlO1xuXHRcdFx0XHRhdG9tLmRlcHNUYWlsID0gdm9pZCAwO1xuXHRcdFx0fSBlbHNlIGlmIChnZXRWYWx1ZSA9PT0gdm9pZCAwKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRpZiAoaXNDb21wdXRlZCkgYXRvbS5mbGFncyA9IDEgfCA0O1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3Qgb2xkVmFsdWUgPSBhdG9tLl9zbmFwc2hvdDtcblx0XHRcdFx0Y29uc3QgbmV3VmFsdWUgPSB0eXBlb2YgZ2V0VmFsdWUgPT09IFwiZnVuY3Rpb25cIiA/IGdldFZhbHVlKG9sZFZhbHVlKSA6IGdldFZhbHVlID09PSB2b2lkIDAgJiYgaXNDb21wdXRlZCA/IGdldHRlcihvbGRWYWx1ZSkgOiBnZXRWYWx1ZTtcblx0XHRcdFx0aWYgKG9sZFZhbHVlID09PSB2b2lkIDAgfHwgIWNvbXBhcmUob2xkVmFsdWUsIG5ld1ZhbHVlKSkge1xuXHRcdFx0XHRcdGF0b20uX3NuYXBzaG90ID0gbmV3VmFsdWU7XG5cdFx0XHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdFx0fSBmaW5hbGx5IHtcblx0XHRcdFx0YWN0aXZlU3ViID0gcHJldlN1Yjtcblx0XHRcdFx0aWYgKGlzQ29tcHV0ZWQpIGF0b20uZmxhZ3MgJj0gfjQ7XG5cdFx0XHRcdHB1cmdlRGVwcyhhdG9tKTtcblx0XHRcdH1cblx0XHR9XG5cdH07XG5cdGlmIChpc0NvbXB1dGVkKSB7XG5cdFx0YXRvbS5mbGFncyA9IDEgfCAxNjtcblx0XHRhdG9tLmdldCA9IGZ1bmN0aW9uKCkge1xuXHRcdFx0Y29uc3QgZmxhZ3MgPSBhdG9tLmZsYWdzO1xuXHRcdFx0aWYgKGZsYWdzICYgMTYgfHwgZmxhZ3MgJiAzMiAmJiBjaGVja0RpcnR5KGF0b20uZGVwcywgYXRvbSkpIHtcblx0XHRcdFx0aWYgKGF0b20uX3VwZGF0ZSgpKSB7XG5cdFx0XHRcdFx0Y29uc3Qgc3VicyA9IGF0b20uc3Vicztcblx0XHRcdFx0XHRpZiAoc3VicyAhPT0gdm9pZCAwKSBzaGFsbG93UHJvcGFnYXRlKHN1YnMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgaWYgKGZsYWdzICYgMzIpIGF0b20uZmxhZ3MgPSBmbGFncyAmIH4zMjtcblx0XHRcdGlmIChhY3RpdmVTdWIgIT09IHZvaWQgMCkgbGluayhhdG9tLCBhY3RpdmVTdWIsIGN5Y2xlKTtcblx0XHRcdHJldHVybiBhdG9tLl9zbmFwc2hvdDtcblx0XHR9O1xuXHR9IGVsc2UgYXRvbS5zZXQgPSBmdW5jdGlvbih2YWx1ZU9yRm4pIHtcblx0XHRpZiAoYXRvbS5fdXBkYXRlKHZhbHVlT3JGbikpIHtcblx0XHRcdGNvbnN0IHN1YnMgPSBhdG9tLnN1YnM7XG5cdFx0XHRpZiAoc3VicyAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdHByb3BhZ2F0ZShzdWJzKTtcblx0XHRcdFx0c2hhbGxvd1Byb3BhZ2F0ZShzdWJzKTtcblx0XHRcdFx0Zmx1c2goKTtcblx0XHRcdH1cblx0XHR9XG5cdH07XG5cdHJldHVybiBhdG9tO1xufVxuZnVuY3Rpb24gZWZmZWN0KGZuKSB7XG5cdGNvbnN0IHJ1biA9ICgpID0+IHtcblx0XHRjb25zdCBwcmV2U3ViID0gYWN0aXZlU3ViO1xuXHRcdGFjdGl2ZVN1YiA9IGVmZmVjdE9iajtcblx0XHQrK2N5Y2xlO1xuXHRcdGVmZmVjdE9iai5kZXBzVGFpbCA9IHZvaWQgMDtcblx0XHRlZmZlY3RPYmouZmxhZ3MgPSAyIHwgNDtcblx0XHR0cnkge1xuXHRcdFx0cmV0dXJuIGZuKCk7XG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdGFjdGl2ZVN1YiA9IHByZXZTdWI7XG5cdFx0XHRlZmZlY3RPYmouZmxhZ3MgJj0gfjQ7XG5cdFx0XHRwdXJnZURlcHMoZWZmZWN0T2JqKTtcblx0XHR9XG5cdH07XG5cdGNvbnN0IGVmZmVjdE9iaiA9IHtcblx0XHRkZXBzOiB2b2lkIDAsXG5cdFx0ZGVwc1RhaWw6IHZvaWQgMCxcblx0XHRzdWJzOiB2b2lkIDAsXG5cdFx0c3Vic1RhaWw6IHZvaWQgMCxcblx0XHRmbGFnczogMiB8IDQsXG5cdFx0bm90aWZ5KCkge1xuXHRcdFx0Y29uc3QgZmxhZ3MgPSB0aGlzLmZsYWdzO1xuXHRcdFx0aWYgKGZsYWdzICYgMTYgfHwgZmxhZ3MgJiAzMiAmJiBjaGVja0RpcnR5KHRoaXMuZGVwcywgdGhpcykpIHJ1bigpO1xuXHRcdFx0ZWxzZSB0aGlzLmZsYWdzID0gMjtcblx0XHR9LFxuXHRcdHN0b3AoKSB7XG5cdFx0XHR0aGlzLmZsYWdzID0gMDtcblx0XHRcdHRoaXMuZGVwc1RhaWwgPSB2b2lkIDA7XG5cdFx0XHRwdXJnZURlcHModGhpcyk7XG5cdFx0fVxuXHR9O1xuXHRydW4oKTtcblx0cmV0dXJuIGVmZmVjdE9iajtcbn1cblxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBiYXRjaCwgY3JlYXRlQXN5bmNBdG9tLCBjcmVhdGVBdG9tLCBmbHVzaCwgdG9PYnNlcnZlciB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YXRvbS5qcy5tYXAiLCIvKipcbiAqIEBsaWNlbnNlIFJlYWN0XG4gKiB1c2Utc3luYy1leHRlcm5hbC1zdG9yZS1zaGltLmRldmVsb3BtZW50LmpzXG4gKlxuICogQ29weXJpZ2h0IChjKSBNZXRhIFBsYXRmb3JtcywgSW5jLiBhbmQgYWZmaWxpYXRlcy5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuXG5cInVzZSBzdHJpY3RcIjtcblwicHJvZHVjdGlvblwiICE9PSBwcm9jZXNzLmVudi5OT0RFX0VOViAmJlxuICAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIGlzKHgsIHkpIHtcbiAgICAgIHJldHVybiAoeCA9PT0geSAmJiAoMCAhPT0geCB8fCAxIC8geCA9PT0gMSAvIHkpKSB8fCAoeCAhPT0geCAmJiB5ICE9PSB5KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gdXNlU3luY0V4dGVybmFsU3RvcmUkMihzdWJzY3JpYmUsIGdldFNuYXBzaG90KSB7XG4gICAgICBkaWRXYXJuT2xkMThBbHBoYSB8fFxuICAgICAgICB2b2lkIDAgPT09IFJlYWN0LnN0YXJ0VHJhbnNpdGlvbiB8fFxuICAgICAgICAoKGRpZFdhcm5PbGQxOEFscGhhID0gITApLFxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiWW91IGFyZSB1c2luZyBhbiBvdXRkYXRlZCwgcHJlLXJlbGVhc2UgYWxwaGEgb2YgUmVhY3QgMTggdGhhdCBkb2VzIG5vdCBzdXBwb3J0IHVzZVN5bmNFeHRlcm5hbFN0b3JlLiBUaGUgdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUgc2hpbSB3aWxsIG5vdCB3b3JrIGNvcnJlY3RseS4gVXBncmFkZSB0byBhIG5ld2VyIHByZS1yZWxlYXNlLlwiXG4gICAgICAgICkpO1xuICAgICAgdmFyIHZhbHVlID0gZ2V0U25hcHNob3QoKTtcbiAgICAgIGlmICghZGlkV2FyblVuY2FjaGVkR2V0U25hcHNob3QpIHtcbiAgICAgICAgdmFyIGNhY2hlZFZhbHVlID0gZ2V0U25hcHNob3QoKTtcbiAgICAgICAgb2JqZWN0SXModmFsdWUsIGNhY2hlZFZhbHVlKSB8fFxuICAgICAgICAgIChjb25zb2xlLmVycm9yKFxuICAgICAgICAgICAgXCJUaGUgcmVzdWx0IG9mIGdldFNuYXBzaG90IHNob3VsZCBiZSBjYWNoZWQgdG8gYXZvaWQgYW4gaW5maW5pdGUgbG9vcFwiXG4gICAgICAgICAgKSxcbiAgICAgICAgICAoZGlkV2FyblVuY2FjaGVkR2V0U25hcHNob3QgPSAhMCkpO1xuICAgICAgfVxuICAgICAgY2FjaGVkVmFsdWUgPSB1c2VTdGF0ZSh7XG4gICAgICAgIGluc3Q6IHsgdmFsdWU6IHZhbHVlLCBnZXRTbmFwc2hvdDogZ2V0U25hcHNob3QgfVxuICAgICAgfSk7XG4gICAgICB2YXIgaW5zdCA9IGNhY2hlZFZhbHVlWzBdLmluc3QsXG4gICAgICAgIGZvcmNlVXBkYXRlID0gY2FjaGVkVmFsdWVbMV07XG4gICAgICB1c2VMYXlvdXRFZmZlY3QoXG4gICAgICAgIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpbnN0LnZhbHVlID0gdmFsdWU7XG4gICAgICAgICAgaW5zdC5nZXRTbmFwc2hvdCA9IGdldFNuYXBzaG90O1xuICAgICAgICAgIGNoZWNrSWZTbmFwc2hvdENoYW5nZWQoaW5zdCkgJiYgZm9yY2VVcGRhdGUoeyBpbnN0OiBpbnN0IH0pO1xuICAgICAgICB9LFxuICAgICAgICBbc3Vic2NyaWJlLCB2YWx1ZSwgZ2V0U25hcHNob3RdXG4gICAgICApO1xuICAgICAgdXNlRWZmZWN0KFxuICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgY2hlY2tJZlNuYXBzaG90Q2hhbmdlZChpbnN0KSAmJiBmb3JjZVVwZGF0ZSh7IGluc3Q6IGluc3QgfSk7XG4gICAgICAgICAgcmV0dXJuIHN1YnNjcmliZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjaGVja0lmU25hcHNob3RDaGFuZ2VkKGluc3QpICYmIGZvcmNlVXBkYXRlKHsgaW5zdDogaW5zdCB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSxcbiAgICAgICAgW3N1YnNjcmliZV1cbiAgICAgICk7XG4gICAgICB1c2VEZWJ1Z1ZhbHVlKHZhbHVlKTtcbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gY2hlY2tJZlNuYXBzaG90Q2hhbmdlZChpbnN0KSB7XG4gICAgICB2YXIgbGF0ZXN0R2V0U25hcHNob3QgPSBpbnN0LmdldFNuYXBzaG90O1xuICAgICAgaW5zdCA9IGluc3QudmFsdWU7XG4gICAgICB0cnkge1xuICAgICAgICB2YXIgbmV4dFZhbHVlID0gbGF0ZXN0R2V0U25hcHNob3QoKTtcbiAgICAgICAgcmV0dXJuICFvYmplY3RJcyhpbnN0LCBuZXh0VmFsdWUpO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuICEwO1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiB1c2VTeW5jRXh0ZXJuYWxTdG9yZSQxKHN1YnNjcmliZSwgZ2V0U25hcHNob3QpIHtcbiAgICAgIHJldHVybiBnZXRTbmFwc2hvdCgpO1xuICAgIH1cbiAgICBcInVuZGVmaW5lZFwiICE9PSB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fICYmXG4gICAgICBcImZ1bmN0aW9uXCIgPT09XG4gICAgICAgIHR5cGVvZiBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0YXJ0ICYmXG4gICAgICBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0YXJ0KEVycm9yKCkpO1xuICAgIHZhciBSZWFjdCA9IHJlcXVpcmUoXCJyZWFjdFwiKSxcbiAgICAgIG9iamVjdElzID0gXCJmdW5jdGlvblwiID09PSB0eXBlb2YgT2JqZWN0LmlzID8gT2JqZWN0LmlzIDogaXMsXG4gICAgICB1c2VTdGF0ZSA9IFJlYWN0LnVzZVN0YXRlLFxuICAgICAgdXNlRWZmZWN0ID0gUmVhY3QudXNlRWZmZWN0LFxuICAgICAgdXNlTGF5b3V0RWZmZWN0ID0gUmVhY3QudXNlTGF5b3V0RWZmZWN0LFxuICAgICAgdXNlRGVidWdWYWx1ZSA9IFJlYWN0LnVzZURlYnVnVmFsdWUsXG4gICAgICBkaWRXYXJuT2xkMThBbHBoYSA9ICExLFxuICAgICAgZGlkV2FyblVuY2FjaGVkR2V0U25hcHNob3QgPSAhMSxcbiAgICAgIHNoaW0gPVxuICAgICAgICBcInVuZGVmaW5lZFwiID09PSB0eXBlb2Ygd2luZG93IHx8XG4gICAgICAgIFwidW5kZWZpbmVkXCIgPT09IHR5cGVvZiB3aW5kb3cuZG9jdW1lbnQgfHxcbiAgICAgICAgXCJ1bmRlZmluZWRcIiA9PT0gdHlwZW9mIHdpbmRvdy5kb2N1bWVudC5jcmVhdGVFbGVtZW50XG4gICAgICAgICAgPyB1c2VTeW5jRXh0ZXJuYWxTdG9yZSQxXG4gICAgICAgICAgOiB1c2VTeW5jRXh0ZXJuYWxTdG9yZSQyO1xuICAgIGV4cG9ydHMudXNlU3luY0V4dGVybmFsU3RvcmUgPVxuICAgICAgdm9pZCAwICE9PSBSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZSA/IFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlIDogc2hpbTtcbiAgICBcInVuZGVmaW5lZFwiICE9PSB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fICYmXG4gICAgICBcImZ1bmN0aW9uXCIgPT09XG4gICAgICAgIHR5cGVvZiBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0b3AgJiZcbiAgICAgIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXy5yZWdpc3RlckludGVybmFsTW9kdWxlU3RvcChFcnJvcigpKTtcbiAgfSkoKTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAncHJvZHVjdGlvbicpIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuLi9janMvdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUtc2hpbS5wcm9kdWN0aW9uLmpzJyk7XG59IGVsc2Uge1xuICBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4uL2Nqcy91c2Utc3luYy1leHRlcm5hbC1zdG9yZS1zaGltLmRldmVsb3BtZW50LmpzJyk7XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlIFJlYWN0XG4gKiB1c2Utc3luYy1leHRlcm5hbC1zdG9yZS1zaGltL3dpdGgtc2VsZWN0b3IuZGV2ZWxvcG1lbnQuanNcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIE1ldGEgUGxhdGZvcm1zLCBJbmMuIGFuZCBhZmZpbGlhdGVzLlxuICpcbiAqIFRoaXMgc291cmNlIGNvZGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlIGZvdW5kIGluIHRoZVxuICogTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuICovXG5cblwidXNlIHN0cmljdFwiO1xuXCJwcm9kdWN0aW9uXCIgIT09IHByb2Nlc3MuZW52Lk5PREVfRU5WICYmXG4gIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gaXMoeCwgeSkge1xuICAgICAgcmV0dXJuICh4ID09PSB5ICYmICgwICE9PSB4IHx8IDEgLyB4ID09PSAxIC8geSkpIHx8ICh4ICE9PSB4ICYmIHkgIT09IHkpO1xuICAgIH1cbiAgICBcInVuZGVmaW5lZFwiICE9PSB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fICYmXG4gICAgICBcImZ1bmN0aW9uXCIgPT09XG4gICAgICAgIHR5cGVvZiBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0YXJ0ICYmXG4gICAgICBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0YXJ0KEVycm9yKCkpO1xuICAgIHZhciBSZWFjdCA9IHJlcXVpcmUoXCJyZWFjdFwiKSxcbiAgICAgIHNoaW0gPSByZXF1aXJlKFwidXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUvc2hpbVwiKSxcbiAgICAgIG9iamVjdElzID0gXCJmdW5jdGlvblwiID09PSB0eXBlb2YgT2JqZWN0LmlzID8gT2JqZWN0LmlzIDogaXMsXG4gICAgICB1c2VTeW5jRXh0ZXJuYWxTdG9yZSA9IHNoaW0udXNlU3luY0V4dGVybmFsU3RvcmUsXG4gICAgICB1c2VSZWYgPSBSZWFjdC51c2VSZWYsXG4gICAgICB1c2VFZmZlY3QgPSBSZWFjdC51c2VFZmZlY3QsXG4gICAgICB1c2VNZW1vID0gUmVhY3QudXNlTWVtbyxcbiAgICAgIHVzZURlYnVnVmFsdWUgPSBSZWFjdC51c2VEZWJ1Z1ZhbHVlO1xuICAgIGV4cG9ydHMudXNlU3luY0V4dGVybmFsU3RvcmVXaXRoU2VsZWN0b3IgPSBmdW5jdGlvbiAoXG4gICAgICBzdWJzY3JpYmUsXG4gICAgICBnZXRTbmFwc2hvdCxcbiAgICAgIGdldFNlcnZlclNuYXBzaG90LFxuICAgICAgc2VsZWN0b3IsXG4gICAgICBpc0VxdWFsXG4gICAgKSB7XG4gICAgICB2YXIgaW5zdFJlZiA9IHVzZVJlZihudWxsKTtcbiAgICAgIGlmIChudWxsID09PSBpbnN0UmVmLmN1cnJlbnQpIHtcbiAgICAgICAgdmFyIGluc3QgPSB7IGhhc1ZhbHVlOiAhMSwgdmFsdWU6IG51bGwgfTtcbiAgICAgICAgaW5zdFJlZi5jdXJyZW50ID0gaW5zdDtcbiAgICAgIH0gZWxzZSBpbnN0ID0gaW5zdFJlZi5jdXJyZW50O1xuICAgICAgaW5zdFJlZiA9IHVzZU1lbW8oXG4gICAgICAgIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBmdW5jdGlvbiBtZW1vaXplZFNlbGVjdG9yKG5leHRTbmFwc2hvdCkge1xuICAgICAgICAgICAgaWYgKCFoYXNNZW1vKSB7XG4gICAgICAgICAgICAgIGhhc01lbW8gPSAhMDtcbiAgICAgICAgICAgICAgbWVtb2l6ZWRTbmFwc2hvdCA9IG5leHRTbmFwc2hvdDtcbiAgICAgICAgICAgICAgbmV4dFNuYXBzaG90ID0gc2VsZWN0b3IobmV4dFNuYXBzaG90KTtcbiAgICAgICAgICAgICAgaWYgKHZvaWQgMCAhPT0gaXNFcXVhbCAmJiBpbnN0Lmhhc1ZhbHVlKSB7XG4gICAgICAgICAgICAgICAgdmFyIGN1cnJlbnRTZWxlY3Rpb24gPSBpbnN0LnZhbHVlO1xuICAgICAgICAgICAgICAgIGlmIChpc0VxdWFsKGN1cnJlbnRTZWxlY3Rpb24sIG5leHRTbmFwc2hvdCkpXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKG1lbW9pemVkU2VsZWN0aW9uID0gY3VycmVudFNlbGVjdGlvbik7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIChtZW1vaXplZFNlbGVjdGlvbiA9IG5leHRTbmFwc2hvdCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjdXJyZW50U2VsZWN0aW9uID0gbWVtb2l6ZWRTZWxlY3Rpb247XG4gICAgICAgICAgICBpZiAob2JqZWN0SXMobWVtb2l6ZWRTbmFwc2hvdCwgbmV4dFNuYXBzaG90KSlcbiAgICAgICAgICAgICAgcmV0dXJuIGN1cnJlbnRTZWxlY3Rpb247XG4gICAgICAgICAgICB2YXIgbmV4dFNlbGVjdGlvbiA9IHNlbGVjdG9yKG5leHRTbmFwc2hvdCk7XG4gICAgICAgICAgICBpZiAodm9pZCAwICE9PSBpc0VxdWFsICYmIGlzRXF1YWwoY3VycmVudFNlbGVjdGlvbiwgbmV4dFNlbGVjdGlvbikpXG4gICAgICAgICAgICAgIHJldHVybiAobWVtb2l6ZWRTbmFwc2hvdCA9IG5leHRTbmFwc2hvdCksIGN1cnJlbnRTZWxlY3Rpb247XG4gICAgICAgICAgICBtZW1vaXplZFNuYXBzaG90ID0gbmV4dFNuYXBzaG90O1xuICAgICAgICAgICAgcmV0dXJuIChtZW1vaXplZFNlbGVjdGlvbiA9IG5leHRTZWxlY3Rpb24pO1xuICAgICAgICAgIH1cbiAgICAgICAgICB2YXIgaGFzTWVtbyA9ICExLFxuICAgICAgICAgICAgbWVtb2l6ZWRTbmFwc2hvdCxcbiAgICAgICAgICAgIG1lbW9pemVkU2VsZWN0aW9uLFxuICAgICAgICAgICAgbWF5YmVHZXRTZXJ2ZXJTbmFwc2hvdCA9XG4gICAgICAgICAgICAgIHZvaWQgMCA9PT0gZ2V0U2VydmVyU25hcHNob3QgPyBudWxsIDogZ2V0U2VydmVyU25hcHNob3Q7XG4gICAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIG1lbW9pemVkU2VsZWN0b3IoZ2V0U25hcHNob3QoKSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbnVsbCA9PT0gbWF5YmVHZXRTZXJ2ZXJTbmFwc2hvdFxuICAgICAgICAgICAgICA/IHZvaWQgMFxuICAgICAgICAgICAgICA6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBtZW1vaXplZFNlbGVjdG9yKG1heWJlR2V0U2VydmVyU25hcHNob3QoKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgIF07XG4gICAgICAgIH0sXG4gICAgICAgIFtnZXRTbmFwc2hvdCwgZ2V0U2VydmVyU25hcHNob3QsIHNlbGVjdG9yLCBpc0VxdWFsXVxuICAgICAgKTtcbiAgICAgIHZhciB2YWx1ZSA9IHVzZVN5bmNFeHRlcm5hbFN0b3JlKHN1YnNjcmliZSwgaW5zdFJlZlswXSwgaW5zdFJlZlsxXSk7XG4gICAgICB1c2VFZmZlY3QoXG4gICAgICAgIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpbnN0Lmhhc1ZhbHVlID0gITA7XG4gICAgICAgICAgaW5zdC52YWx1ZSA9IHZhbHVlO1xuICAgICAgICB9LFxuICAgICAgICBbdmFsdWVdXG4gICAgICApO1xuICAgICAgdXNlRGVidWdWYWx1ZSh2YWx1ZSk7XG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfTtcbiAgICBcInVuZGVmaW5lZFwiICE9PSB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fICYmXG4gICAgICBcImZ1bmN0aW9uXCIgPT09XG4gICAgICAgIHR5cGVvZiBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0b3AgJiZcbiAgICAgIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXy5yZWdpc3RlckludGVybmFsTW9kdWxlU3RvcChFcnJvcigpKTtcbiAgfSkoKTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAncHJvZHVjdGlvbicpIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuLi9janMvdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUtc2hpbS93aXRoLXNlbGVjdG9yLnByb2R1Y3Rpb24uanMnKTtcbn0gZWxzZSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi4vY2pzL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlLXNoaW0vd2l0aC1zZWxlY3Rvci5kZXZlbG9wbWVudC5qcycpO1xufVxuIiwiaW1wb3J0IHsgdXNlQ2FsbGJhY2sgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVN5bmNFeHRlcm5hbFN0b3JlV2l0aFNlbGVjdG9yIH0gZnJvbSBcInVzZS1zeW5jLWV4dGVybmFsLXN0b3JlL3NoaW0vd2l0aC1zZWxlY3RvclwiO1xuXG4vLyNyZWdpb24gc3JjL3VzZVNlbGVjdG9yLnRzXG5mdW5jdGlvbiBkZWZhdWx0Q29tcGFyZShhLCBiKSB7XG5cdHJldHVybiBhID09PSBiO1xufVxuLyoqXG4qIFNlbGVjdHMgYSBzbGljZSBvZiBzdGF0ZSBmcm9tIGFuIGF0b20gb3Igc3RvcmUgYW5kIHN1YnNjcmliZXMgdGhlIGNvbXBvbmVudFxuKiB0byB0aGF0IHNlbGVjdGlvbi5cbipcbiogVGhpcyBpcyB0aGUgcHJpbWFyeSBSZWFjdCByZWFkIGhvb2sgZm9yIFRhblN0YWNrIFN0b3JlLiBJdCB3b3JrcyB3aXRoIGFueVxuKiBzb3VyY2UgdGhhdCBleHBvc2VzIGBnZXQoKWAgYW5kIGBzdWJzY3JpYmUoKWAsIGluY2x1ZGluZyBhdG9tcywgcmVhZG9ubHlcbiogYXRvbXMsIHN0b3JlcywgYW5kIHJlYWRvbmx5IHN0b3Jlcy5cbipcbiogT21pdCB0aGUgc2VsZWN0b3IgdG8gc3Vic2NyaWJlIHRvIHRoZSB3aG9sZSB2YWx1ZS5cbipcbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGNvbnN0IGNvdW50ID0gdXNlU2VsZWN0b3IoY291bnRlclN0b3JlLCAoc3RhdGUpID0+IHN0YXRlLmNvdW50KVxuKiBgYGBcbipcbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGNvbnN0IHZhbHVlID0gdXNlU2VsZWN0b3IoY291bnRBdG9tKVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VTZWxlY3Rvcihzb3VyY2UsIHNlbGVjdG9yID0gKHMpID0+IHMsIG9wdGlvbnMpIHtcblx0Y29uc3QgY29tcGFyZSA9IG9wdGlvbnM/LmNvbXBhcmUgPz8gZGVmYXVsdENvbXBhcmU7XG5cdGNvbnN0IHN1YnNjcmliZSA9IHVzZUNhbGxiYWNrKChoYW5kbGVTdG9yZUNoYW5nZSkgPT4ge1xuXHRcdGNvbnN0IHsgdW5zdWJzY3JpYmUgfSA9IHNvdXJjZS5zdWJzY3JpYmUoaGFuZGxlU3RvcmVDaGFuZ2UpO1xuXHRcdHJldHVybiB1bnN1YnNjcmliZTtcblx0fSwgW3NvdXJjZV0pO1xuXHRjb25zdCBnZXRTbmFwc2hvdCA9IHVzZUNhbGxiYWNrKCgpID0+IHNvdXJjZS5nZXQoKSwgW3NvdXJjZV0pO1xuXHRyZXR1cm4gdXNlU3luY0V4dGVybmFsU3RvcmVXaXRoU2VsZWN0b3Ioc3Vic2NyaWJlLCBnZXRTbmFwc2hvdCwgZ2V0U25hcHNob3QsIHNlbGVjdG9yLCBjb21wYXJlKTtcbn1cblxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VTZWxlY3RvciB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlU2VsZWN0b3IuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyBkdW1teU1hdGNoQ29udGV4dCwgbWF0Y2hDb250ZXh0IH0gZnJvbSBcIi4vbWF0Y2hDb250ZXh0LmpzXCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IGludmFyaWFudCwgcmVwbGFjZUVxdWFsRGVlcCB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbmltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1zdG9yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VNYXRjaC50c3hcbnZhciBkdW1teU1hdGNoID0ge307XG5mdW5jdGlvbiB1c2VTdHJ1Y3R1cmFsU2hhcmluZyhvcHRzLCByb3V0ZXIpIHtcblx0Y29uc3QgcHJldmlvdXNSZXN1bHQgPSBSZWFjdCQxLnVzZVJlZigpO1xuXHRyZXR1cm4gKHNsaWNlKSA9PiB7XG5cdFx0Y29uc3Qgc2VsZWN0ZWQgPSBvcHRzPy5zZWxlY3QgPyBvcHRzLnNlbGVjdChzbGljZSkgOiBzbGljZTtcblx0XHRpZiAob3B0cz8uc3RydWN0dXJhbFNoYXJpbmcgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFN0cnVjdHVyYWxTaGFyaW5nKSByZXR1cm4gcHJldmlvdXNSZXN1bHQuY3VycmVudCA9IHJlcGxhY2VFcXVhbERlZXAocHJldmlvdXNSZXN1bHQuY3VycmVudCwgc2VsZWN0ZWQpO1xuXHRcdHJldHVybiBzZWxlY3RlZDtcblx0fTtcbn1cbi8qKlxuKiBSZWFkIGFuZCBzZWxlY3QgdGhlIG5lYXJlc3Qgb3IgdGFyZ2V0ZWQgcm91dGUgbWF0Y2guXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci91c2VNYXRjaEhvb2tcbiovXG5mdW5jdGlvbiB1c2VNYXRjaChvcHRzKSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCBuZWFyZXN0Um91dGVJZCA9IFJlYWN0JDEudXNlQ29udGV4dChvcHRzLmZyb20gPyBkdW1teU1hdGNoQ29udGV4dCA6IG1hdGNoQ29udGV4dCk7XG5cdGNvbnN0IHJvdXRlSWQgPSBvcHRzLmZyb20gPz8gbmVhcmVzdFJvdXRlSWQ7XG5cdGNvbnN0IG1hdGNoU3RvcmUgPSByb3V0ZXIuc3RvcmVzLmdldE1hdGNoU3RvcmUocm91dGVJZCk7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHtcblx0XHRjb25zdCBtYXRjaCA9IG1hdGNoU3RvcmUuZ2V0KCk7XG5cdFx0aWYgKCFtYXRjaCkge1xuXHRcdFx0aWYgKG9wdHMuc2hvdWxkVGhyb3cgPz8gdHJ1ZSkge1xuXHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0aHJvdyBuZXcgRXJyb3IoYEludmFyaWFudCBmYWlsZWQ6IENvdWxkIG5vdCBmaW5kICR7b3B0cy5mcm9tID8gYGFuIGFjdGl2ZSBtYXRjaCBmcm9tIFwiJHtvcHRzLmZyb219XCJgIDogXCJhIG5lYXJlc3QgbWF0Y2ghXCJ9YCk7XG5cdFx0XHRcdGludmFyaWFudCgpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRyZXR1cm4gb3B0cy5zZWxlY3QgPyBvcHRzLnNlbGVjdChtYXRjaCkgOiBtYXRjaDtcblx0fVxuXHRjb25zdCBzZWxlY3RvciA9IHVzZVN0cnVjdHVyYWxTaGFyaW5nKG9wdHMsIHJvdXRlcik7XG5cdGNvbnN0IG1hdGNoU2VsZWN0aW9uID0gdXNlU2VsZWN0b3IobWF0Y2hTdG9yZSwgKG1hdGNoKSA9PiBtYXRjaCA/IHNlbGVjdG9yKG1hdGNoKSA6IGR1bW15TWF0Y2gpO1xuXHRpZiAobWF0Y2hTZWxlY3Rpb24gIT09IGR1bW15TWF0Y2gpIHJldHVybiBtYXRjaFNlbGVjdGlvbjtcblx0aWYgKG9wdHMuc2hvdWxkVGhyb3cgPz8gdHJ1ZSkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHRocm93IG5ldyBFcnJvcihgSW52YXJpYW50IGZhaWxlZDogQ291bGQgbm90IGZpbmQgJHtvcHRzLmZyb20gPyBgYW4gYWN0aXZlIG1hdGNoIGZyb20gXCIke29wdHMuZnJvbX1cImAgOiBcImEgbmVhcmVzdCBtYXRjaCFcIn1gKTtcblx0XHRpbnZhcmlhbnQoKTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VNYXRjaCwgdXNlU3RydWN0dXJhbFNoYXJpbmcgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlTWF0Y2guanMubWFwIiwiaW1wb3J0IHsgdXNlTWF0Y2ggfSBmcm9tIFwiLi91c2VNYXRjaC5qc1wiO1xuLy8jcmVnaW9uIHNyYy91c2VMb2FkZXJEYXRhLnRzeFxuLyoqXG4qIFJlYWQgYW5kIHNlbGVjdCB0aGUgY3VycmVudCByb3V0ZSdzIGxvYWRlciBkYXRhIHdpdGggdHlwZeKAkXNhZmV0eS5cbipcbiogT3B0aW9uczpcbiogLSBgZnJvbWAvYHN0cmljdGA6IENob29zZSB3aGljaCByb3V0ZSdzIGRhdGEgdG8gcmVhZCBhbmQgc3RyaWN0bmVzc1xuKiAtIGBzZWxlY3RgOiBNYXAgdGhlIGxvYWRlciBkYXRhIHRvIGEgZGVyaXZlZCB2YWx1ZVxuKiAtIGBzdHJ1Y3R1cmFsU2hhcmluZ2A6IEVuYWJsZSBzdHJ1Y3R1cmFsIHNoYXJpbmcgZm9yIHN0YWJsZSByZWZlcmVuY2VzXG4qXG4qIEByZXR1cm5zIFRoZSBsb2FkZXIgZGF0YSAob3Igc2VsZWN0ZWQgdmFsdWUpIGZvciB0aGUgbWF0Y2hlZCByb3V0ZS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3VzZUxvYWRlckRhdGFIb29rXG4qL1xuZnVuY3Rpb24gdXNlTG9hZGVyRGF0YShvcHRzKSB7XG5cdHJldHVybiB1c2VNYXRjaCh7XG5cdFx0ZnJvbTogb3B0cy5mcm9tLFxuXHRcdHN0cmljdDogb3B0cy5zdHJpY3QsXG5cdFx0c3RydWN0dXJhbFNoYXJpbmc6IG9wdHMuc3RydWN0dXJhbFNoYXJpbmcsXG5cdFx0c2VsZWN0OiAobWF0Y2gpID0+IHtcblx0XHRcdHJldHVybiBvcHRzLnNlbGVjdCA/IG9wdHMuc2VsZWN0KG1hdGNoLmxvYWRlckRhdGEpIDogbWF0Y2gubG9hZGVyRGF0YTtcblx0XHR9XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VMb2FkZXJEYXRhIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUxvYWRlckRhdGEuanMubWFwIiwiaW1wb3J0IHsgdXNlTWF0Y2ggfSBmcm9tIFwiLi91c2VNYXRjaC5qc1wiO1xuLy8jcmVnaW9uIHNyYy91c2VMb2FkZXJEZXBzLnRzeFxuLyoqXG4qIFJlYWQgYW5kIHNlbGVjdCB0aGUgY3VycmVudCByb3V0ZSdzIGxvYWRlciBkZXBlbmRlbmNpZXMgb2JqZWN0LlxuKlxuKiBPcHRpb25zOlxuKiAtIGBmcm9tYDogQ2hvb3NlIHdoaWNoIHJvdXRlJ3MgbG9hZGVyIGRlcHMgdG8gcmVhZFxuKiAtIGBzZWxlY3RgOiBNYXAgdGhlIGRlcHMgdG8gYSBkZXJpdmVkIHZhbHVlXG4qIC0gYHN0cnVjdHVyYWxTaGFyaW5nYDogRW5hYmxlIHN0cnVjdHVyYWwgc2hhcmluZyBmb3Igc3RhYmxlIHJlZmVyZW5jZXNcbipcbiogQHJldHVybnMgVGhlIGxvYWRlciBkZXBzIChvciBzZWxlY3RlZCB2YWx1ZSkgZm9yIHRoZSBtYXRjaGVkIHJvdXRlLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvdXNlTG9hZGVyRGVwc0hvb2tcbiovXG5mdW5jdGlvbiB1c2VMb2FkZXJEZXBzKG9wdHMpIHtcblx0Y29uc3QgeyBzZWxlY3QsIC4uLnJlc3QgfSA9IG9wdHM7XG5cdHJldHVybiB1c2VNYXRjaCh7XG5cdFx0Li4ucmVzdCxcblx0XHRzZWxlY3Q6IChtYXRjaCkgPT4ge1xuXHRcdFx0cmV0dXJuIHNlbGVjdCA/IHNlbGVjdChtYXRjaC5sb2FkZXJEZXBzKSA6IG1hdGNoLmxvYWRlckRlcHM7XG5cdFx0fVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlTG9hZGVyRGVwcyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VMb2FkZXJEZXBzLmpzLm1hcCIsImltcG9ydCB7IHVzZU1hdGNoIH0gZnJvbSBcIi4vdXNlTWF0Y2guanNcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlUGFyYW1zLnRzeFxuLyoqXG4qIEFjY2VzcyB0aGUgY3VycmVudCByb3V0ZSdzIHBhdGggcGFyYW1ldGVycyB3aXRoIHR5cGUtc2FmZXR5LlxuKlxuKiBPcHRpb25zOlxuKiAtIGBmcm9tYC9gc3RyaWN0YDogU3BlY2lmeSB0aGUgbWF0Y2hlZCByb3V0ZSBhbmQgd2hldGhlciB0byBlbmZvcmNlIHN0cmljdCB0eXBpbmdcbiogLSBgc2VsZWN0YDogUHJvamVjdCB0aGUgcGFyYW1zIG9iamVjdCB0byBhIGRlcml2ZWQgdmFsdWUgZm9yIG1lbW9pemVkIHJlbmRlcnNcbiogLSBgc3RydWN0dXJhbFNoYXJpbmdgOiBFbmFibGUgc3RydWN0dXJhbCBzaGFyaW5nIGZvciBzdGFibGUgcmVmZXJlbmNlc1xuKiAtIGBzaG91bGRUaHJvd2A6IFRocm93IGlmIHRoZSByb3V0ZSBpcyBub3QgZm91bmQgaW4gc3RyaWN0IGNvbnRleHRzXG4qXG4qIEByZXR1cm5zIFRoZSBwYXJhbXMgb2JqZWN0IChvciBzZWxlY3RlZCB2YWx1ZSkgZm9yIHRoZSBtYXRjaGVkIHJvdXRlLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvdXNlUGFyYW1zSG9va1xuKi9cbmZ1bmN0aW9uIHVzZVBhcmFtcyhvcHRzKSB7XG5cdHJldHVybiB1c2VNYXRjaCh7XG5cdFx0ZnJvbTogb3B0cy5mcm9tLFxuXHRcdHNob3VsZFRocm93OiBvcHRzLnNob3VsZFRocm93LFxuXHRcdHN0cnVjdHVyYWxTaGFyaW5nOiBvcHRzLnN0cnVjdHVyYWxTaGFyaW5nLFxuXHRcdHN0cmljdDogb3B0cy5zdHJpY3QsXG5cdFx0c2VsZWN0OiAobWF0Y2gpID0+IHtcblx0XHRcdGNvbnN0IHBhcmFtcyA9IG9wdHMuc3RyaWN0ID09PSBmYWxzZSA/IG1hdGNoLnBhcmFtcyA6IG1hdGNoLl9zdHJpY3RQYXJhbXM7XG5cdFx0XHRyZXR1cm4gb3B0cy5zZWxlY3QgPyBvcHRzLnNlbGVjdChwYXJhbXMpIDogcGFyYW1zO1xuXHRcdH1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZVBhcmFtcyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VQYXJhbXMuanMubWFwIiwiaW1wb3J0IHsgdXNlTWF0Y2ggfSBmcm9tIFwiLi91c2VNYXRjaC5qc1wiO1xuLy8jcmVnaW9uIHNyYy91c2VTZWFyY2gudHN4XG4vKipcbiogUmVhZCBhbmQgc2VsZWN0IHRoZSBjdXJyZW50IHJvdXRlJ3Mgc2VhcmNoIHBhcmFtZXRlcnMgd2l0aCB0eXBlLXNhZmV0eS5cbipcbiogT3B0aW9uczpcbiogLSBgZnJvbWAvYHN0cmljdGA6IENvbnRyb2wgd2hpY2ggcm91dGUncyBzZWFyY2ggaXMgcmVhZCBhbmQgaG93IHN0cmljdGx5IGl0J3MgdHlwZWRcbiogLSBgc2VsZWN0YDogTWFwIHRoZSBzZWFyY2ggb2JqZWN0IHRvIGEgZGVyaXZlZCB2YWx1ZSBmb3IgcmVuZGVyIG9wdGltaXphdGlvblxuKiAtIGBzdHJ1Y3R1cmFsU2hhcmluZ2A6IEVuYWJsZSBzdHJ1Y3R1cmFsIHNoYXJpbmcgZm9yIHN0YWJsZSByZWZlcmVuY2VzXG4qIC0gYHNob3VsZFRocm93YDogVGhyb3cgd2hlbiB0aGUgcm91dGUgaXMgbm90IGZvdW5kIChzdHJpY3QgY29udGV4dHMpXG4qXG4qIEByZXR1cm5zIFRoZSBzZWFyY2ggb2JqZWN0IChvciBzZWxlY3RlZCB2YWx1ZSkgZm9yIHRoZSBtYXRjaGVkIHJvdXRlLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvdXNlU2VhcmNoSG9va1xuKi9cbmZ1bmN0aW9uIHVzZVNlYXJjaChvcHRzKSB7XG5cdHJldHVybiB1c2VNYXRjaCh7XG5cdFx0ZnJvbTogb3B0cy5mcm9tLFxuXHRcdHN0cmljdDogb3B0cy5zdHJpY3QsXG5cdFx0c2hvdWxkVGhyb3c6IG9wdHMuc2hvdWxkVGhyb3csXG5cdFx0c3RydWN0dXJhbFNoYXJpbmc6IG9wdHMuc3RydWN0dXJhbFNoYXJpbmcsXG5cdFx0c2VsZWN0OiAobWF0Y2gpID0+IHtcblx0XHRcdHJldHVybiBvcHRzLnNlbGVjdCA/IG9wdHMuc2VsZWN0KG1hdGNoLnNlYXJjaCkgOiBtYXRjaC5zZWFyY2g7XG5cdFx0fVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlU2VhcmNoIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVNlYXJjaC5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUxheW91dEVmZmVjdCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG4vLyNyZWdpb24gc3JjL3VzZU5hdmlnYXRlLnRzeFxuLyoqXG4qIEltcGVyYXRpdmUgbmF2aWdhdGlvbiBob29rLlxuKlxuKiBSZXR1cm5zIGEgc3RhYmxlIGBuYXZpZ2F0ZShvcHRpb25zKWAgZnVuY3Rpb24gdG8gY2hhbmdlIHRoZSBjdXJyZW50IGxvY2F0aW9uXG4qIHByb2dyYW1tYXRpY2FsbHkuIFByZWZlciB0aGUgYExpbmtgIGNvbXBvbmVudCBmb3IgdXNlci1pbml0aWF0ZWQgbmF2aWdhdGlvbixcbiogYW5kIHVzZSB0aGlzIGhvb2sgZnJvbSBlZmZlY3RzLCBjYWxsYmFja3MsIG9yIGhhbmRsZXJzIHdoZXJlIGltcGVyYXRpdmVcbiogbmF2aWdhdGlvbiBpcyByZXF1aXJlZC5cbipcbiogT3B0aW9uczpcbiogLSBgZnJvbWA6IE9wdGlvbmFsIHJvdXRlIGJhc2UgdXNlZCB0byByZXNvbHZlIHJlbGF0aXZlIGB0b2AgcGF0aHMuXG4qXG4qIEByZXR1cm5zIEEgZnVuY3Rpb24gdGhhdCBhY2NlcHRzIGBOYXZpZ2F0ZU9wdGlvbnNgLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvdXNlTmF2aWdhdGVIb29rXG4qL1xuZnVuY3Rpb24gdXNlTmF2aWdhdGUoX2RlZmF1bHRPcHRzKSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRyZXR1cm4gUmVhY3QkMS51c2VDYWxsYmFjaygob3B0aW9ucykgPT4ge1xuXHRcdHJldHVybiByb3V0ZXIubmF2aWdhdGUoe1xuXHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdGZyb206IG9wdGlvbnMuZnJvbSA/PyBfZGVmYXVsdE9wdHM/LmZyb21cblx0XHR9KTtcblx0fSwgW19kZWZhdWx0T3B0cz8uZnJvbSwgcm91dGVyXSk7XG59XG4vKipcbiogQ29tcG9uZW50IHRoYXQgdHJpZ2dlcnMgYSBuYXZpZ2F0aW9uIHdoZW4gcmVuZGVyZWQuIE5hdmlnYXRpb24gZXhlY3V0ZXNcbiogaW4gYW4gZWZmZWN0IGFmdGVyIG1vdW50L3VwZGF0ZS5cbipcbiogUHJvcHMgYXJlIHRoZSBzYW1lIGFzIGBOYXZpZ2F0ZU9wdGlvbnNgIHVzZWQgYnkgYG5hdmlnYXRlKClgLlxuKlxuKiBAcmV0dXJucyBudWxsXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9uYXZpZ2F0ZUNvbXBvbmVudFxuKi9cbmZ1bmN0aW9uIE5hdmlnYXRlKHByb3BzKSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cdGNvbnN0IHByZXZpb3VzUHJvcHNSZWYgPSBSZWFjdCQxLnVzZVJlZihudWxsKTtcblx0dXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcblx0XHRpZiAocHJldmlvdXNQcm9wc1JlZi5jdXJyZW50ICE9PSBwcm9wcykge1xuXHRcdFx0bmF2aWdhdGUocHJvcHMpO1xuXHRcdFx0cHJldmlvdXNQcm9wc1JlZi5jdXJyZW50ID0gcHJvcHM7XG5cdFx0fVxuXHR9LCBbXG5cdFx0cm91dGVyLFxuXHRcdHByb3BzLFxuXHRcdG5hdmlnYXRlXG5cdF0pO1xuXHRyZXR1cm4gbnVsbDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgTmF2aWdhdGUsIHVzZU5hdmlnYXRlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZU5hdmlnYXRlLmpzLm1hcCIsImltcG9ydCB7IHVzZU1hdGNoIH0gZnJvbSBcIi4vdXNlTWF0Y2guanNcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlUm91dGVDb250ZXh0LnRzXG5mdW5jdGlvbiB1c2VSb3V0ZUNvbnRleHQob3B0cykge1xuXHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdC4uLm9wdHMsXG5cdFx0c2VsZWN0OiAobWF0Y2gpID0+IG9wdHMuc2VsZWN0ID8gb3B0cy5zZWxlY3QobWF0Y2guY29udGV4dCkgOiBtYXRjaC5jb250ZXh0XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VSb3V0ZUNvbnRleHQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlUm91dGVDb250ZXh0LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgY3JlYXRlTGlua1Njb3BlLCBtYXRjaENvbnRleHQgfSBmcm9tIFwiLi9tYXRjaENvbnRleHQuanNcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgZGVlcEVxdWFsLCBmdW5jdGlvbmFsVXBkYXRlLCBnZXRVcmxTY2hlbWUsIGlzRGFuZ2Vyb3VzUHJvdG9jb2wsIHByZWxvYWRXYXJuaW5nLCByZW1vdmVUcmFpbGluZ1NsYXNoIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL2xpbmsudHN4XG5mdW5jdGlvbiB1c2VTdGFibGVWYWx1ZXMoLi4udmFsdWVzKSB7XG5cdGNvbnN0IHJlZiA9IFJlYWN0JDEudXNlUmVmKHZhbHVlcyk7XG5cdGNvbnN0IHN0YWJsZSA9IHJlZi5jdXJyZW50O1xuXHR2YWx1ZXMuZm9yRWFjaCgodmFsdWUsIGluZGV4KSA9PiB7XG5cdFx0aWYgKCFkZWVwRXF1YWwoc3RhYmxlW2luZGV4XSwgdmFsdWUsIGZhbHNlLCB0cnVlKSkgc3RhYmxlW2luZGV4XSA9IHZhbHVlO1xuXHR9KTtcblx0cmV0dXJuIHJlZi5jdXJyZW50O1xufVxuZnVuY3Rpb24gcHJlbG9hZExpbmsocm91dGVyLCBvcHRpb25zKSB7XG5cdHJvdXRlci5wcmVsb2FkUm91dGUob3B0aW9ucykuY2F0Y2goKGVycikgPT4ge1xuXHRcdGNvbnNvbGUud2FybihlcnIpO1xuXHRcdGNvbnNvbGUud2FybihwcmVsb2FkV2FybmluZyk7XG5cdH0pO1xufVxuZnVuY3Rpb24gcmVzb2x2ZUV4dGVybmFsTGluayh0bywgcHJvdG9jb2xBbGxvd2xpc3QpIHtcblx0Y29uc3Qgc2NoZW1lID0gdHlwZW9mIHRvID09PSBcInN0cmluZ1wiICYmIGdldFVybFNjaGVtZSh0byk7XG5cdGlmICghc2NoZW1lKSByZXR1cm47XG5cdGlmICghcHJvdG9jb2xBbGxvd2xpc3QuaGFzKHNjaGVtZSkpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBjb25zb2xlLndhcm4oYEJsb2NrZWQgTGluayB3aXRoIGRhbmdlcm91cyBwcm90b2NvbDogJHt0b31gKTtcblx0XHRyZXR1cm4gbnVsbDtcblx0fVxuXHRyZXR1cm4gdG87XG59XG5mdW5jdGlvbiByZXNvbHZlSXNBY3RpdmUobG9jYXRpb24sIG5leHQsIGFjdGl2ZU9wdGlvbnMsIGJhc2VwYXRoKSB7XG5cdGNvbnN0IGN1cnJlbnRQYXRoID0gcmVtb3ZlVHJhaWxpbmdTbGFzaChsb2NhdGlvbi5wYXRobmFtZSwgYmFzZXBhdGgpO1xuXHRjb25zdCBuZXh0UGF0aCA9IHJlbW92ZVRyYWlsaW5nU2xhc2gobmV4dC5wYXRobmFtZSwgYmFzZXBhdGgpO1xuXHRpZiAoYWN0aXZlT3B0aW9ucz8uZXhhY3QgPyBjdXJyZW50UGF0aCAhPT0gbmV4dFBhdGggOiAhKGN1cnJlbnRQYXRoLnN0YXJ0c1dpdGgobmV4dFBhdGgpICYmIChjdXJyZW50UGF0aC5sZW5ndGggPT09IG5leHRQYXRoLmxlbmd0aCB8fCBjdXJyZW50UGF0aFtuZXh0UGF0aC5sZW5ndGhdID09PSBcIi9cIikpKSByZXR1cm4gZmFsc2U7XG5cdGlmIChhY3RpdmVPcHRpb25zPy5pbmNsdWRlU2VhcmNoID8/IHRydWUpIHtcblx0XHRpZiAoIWRlZXBFcXVhbChsb2NhdGlvbi5zZWFyY2gsIG5leHQuc2VhcmNoLCAhYWN0aXZlT3B0aW9ucz8uZXhhY3QsIGFjdGl2ZU9wdGlvbnM/LmV4cGxpY2l0VW5kZWZpbmVkKSkgcmV0dXJuIGZhbHNlO1xuXHR9XG5cdHJldHVybiAhYWN0aXZlT3B0aW9ucz8uaW5jbHVkZUhhc2ggfHwgbG9jYXRpb24uaGFzaCA9PT0gbmV4dC5oYXNoO1xufVxuZnVuY3Rpb24gdXNlTGlua1Byb3BzKG9wdGlvbnMsIGZvcndhcmRlZFJlZiwgaG9zdCkge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikgcmV0dXJuIGdldFNlcnZlckxpbmtQcm9wcyhyb3V0ZXIsIG9wdGlvbnMsIGZvcndhcmRlZFJlZiwgaG9zdCk7XG5cdGNvbnN0IGlubmVyUmVmID0gUmVhY3QkMS51c2VSZWYobnVsbCk7XG5cdGNvbnN0IG1lcmdlZFJlZiA9IFJlYWN0JDEudXNlQ2FsbGJhY2soKGVsZW1lbnQpID0+IHtcblx0XHRpbm5lclJlZi5jdXJyZW50ID0gZWxlbWVudDtcblx0XHRpZiAodHlwZW9mIGZvcndhcmRlZFJlZiA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gZm9yd2FyZGVkUmVmKGVsZW1lbnQpO1xuXHRcdGlmIChmb3J3YXJkZWRSZWYpIGZvcndhcmRlZFJlZi5jdXJyZW50ID0gZWxlbWVudDtcblx0fSwgW2ZvcndhcmRlZFJlZl0pO1xuXHRjb25zdCB7IGFjdGl2ZU9wdGlvbnMsIHRvLCBwcmVsb2FkOiB1c2VyUHJlbG9hZCwgcHJlbG9hZERlbGF5OiB1c2VyUHJlbG9hZERlbGF5LCBkaXNhYmxlZCwgdGFyZ2V0LCBvbkNsaWNrLCBvbkJsdXIsIG9uRm9jdXMsIG9uTW91c2VFbnRlciwgb25Nb3VzZUxlYXZlLCBvblRvdWNoU3RhcnQgfSA9IG9wdGlvbnM7XG5cdGNvbnN0IFtzdGFibGVTZWFyY2gsIHN0YWJsZVBhcmFtcywgc3RhYmxlQWN0aXZlT3B0aW9uc10gPSB1c2VTdGFibGVWYWx1ZXMob3B0aW9ucy5zZWFyY2gsIG9wdGlvbnMucGFyYW1zLCBhY3RpdmVPcHRpb25zKTtcblx0Y29uc3Qgcm91dGVJZCA9IFJlYWN0JDEudXNlQ29udGV4dChtYXRjaENvbnRleHQpO1xuXHRjb25zdCBzY29wZSA9IChyb3V0ZXIuc3RvcmVzLl9saW5rU2NvcGVzID8/PSB7fSlbcm91dGVJZF0gPz89IGNyZWF0ZUxpbmtTY29wZShyb3V0ZXIsIHJvdXRlSWQpO1xuXHRjb25zdCBbZGVzdCwgZ2V0TGlua1N0YXRlLCBnZXRIeWRyYXRpb25TdGF0ZV0gPSBSZWFjdCQxLnVzZU1lbW8oKCkgPT4ge1xuXHRcdGNvbnN0IGRpcmVjdEV4dGVybmFsTGluayA9IHJlc29sdmVFeHRlcm5hbExpbmsodG8sIHJvdXRlci5wcm90b2NvbEFsbG93bGlzdCk7XG5cdFx0aWYgKGRpcmVjdEV4dGVybmFsTGluayAhPT0gdm9pZCAwKSB7XG5cdFx0XHRjb25zdCBzdGF0ZSA9IFtkaXJlY3RFeHRlcm5hbExpbmsgPz8gdm9pZCAwXTtcblx0XHRcdHJldHVybiBbb3B0aW9ucywgKCkgPT4gc3RhdGVdO1xuXHRcdH1cblx0XHRjb25zdCBkZXN0ID0geyAuLi5vcHRpb25zIH07XG5cdFx0bGV0IHNvdXJjZTtcblx0XHRsZXQgc3RhdGU7XG5cdFx0bGV0IGh5ZHJhdGlvblN0YXRlO1xuXHRcdGNvbnN0IGdldExpbmtTdGF0ZSA9ICgpID0+IHtcblx0XHRcdGNvbnN0IGxvY2F0aW9uID0gc2NvcGVbMF0oKTtcblx0XHRcdGlmIChsb2NhdGlvbiAhPT0gc291cmNlKSB7XG5cdFx0XHRcdGRlc3QuX2Zyb21Mb2NhdGlvbiA9IGxvY2F0aW9uO1xuXHRcdFx0XHRjb25zdCBuZXh0ID0gcm91dGVyLmJ1aWxkTG9jYXRpb24oZGVzdCk7XG5cdFx0XHRcdGNvbnN0IGhyZWYgPSBnZXRIcmVmT3B0aW9uKG5leHQsIHJvdXRlciwgZGlzYWJsZWQpO1xuXHRcdFx0XHRjb25zdCBpc0FjdGl2ZSA9IGRpc2FibGVkIHx8IGhyZWYgJiYgIWdldFVybFNjaGVtZShocmVmKSA/IHJlc29sdmVJc0FjdGl2ZShsb2NhdGlvbiwgbmV4dCwgc3RhYmxlQWN0aXZlT3B0aW9ucywgcm91dGVyLmJhc2VwYXRoKSA6IHZvaWQgMDtcblx0XHRcdFx0aWYgKCFzdGF0ZSB8fCBzdGF0ZVswXSAhPT0gaHJlZiB8fCBzdGF0ZVsxXSAhPT0gaXNBY3RpdmUpIHN0YXRlID0gW2hyZWYsIGlzQWN0aXZlXTtcblx0XHRcdFx0c291cmNlID0gbG9jYXRpb247XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gc3RhdGU7XG5cdFx0fTtcblx0XHRyZXR1cm4gW1xuXHRcdFx0ZGVzdCxcblx0XHRcdGdldExpbmtTdGF0ZSxcblx0XHRcdHN0YWJsZUFjdGl2ZU9wdGlvbnM/LmluY2x1ZGVIYXNoICYmICgoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHN0YXRlID0gZ2V0TGlua1N0YXRlKCk7XG5cdFx0XHRcdHJldHVybiBzdGF0ZVsxXSA/IGh5ZHJhdGlvblN0YXRlID8/PSBbc3RhdGVbMF0sIGZhbHNlXSA6IHN0YXRlO1xuXHRcdFx0fSlcblx0XHRdO1xuXHR9LCBbXG5cdFx0cm91dGVyLFxuXHRcdHNjb3BlLFxuXHRcdG9wdGlvbnMuZnJvbSxcblx0XHRvcHRpb25zLmhhc2gsXG5cdFx0b3B0aW9ucy5ocmVmLFxuXHRcdHRvLFxuXHRcdHN0YWJsZVNlYXJjaCxcblx0XHRzdGFibGVQYXJhbXMsXG5cdFx0b3B0aW9ucy5zdGF0ZSxcblx0XHRvcHRpb25zLm1hc2ssXG5cdFx0b3B0aW9ucy51bnNhZmVSZWxhdGl2ZSxcblx0XHRzdGFibGVBY3RpdmVPcHRpb25zLFxuXHRcdGRpc2FibGVkXG5cdF0pO1xuXHRjb25zdCBbaHJlZiwgaXNBY3RpdmVdID0gUmVhY3QkMS51c2VTeW5jRXh0ZXJuYWxTdG9yZShzY29wZVsxXSwgZ2V0TGlua1N0YXRlLCBnZXRIeWRyYXRpb25TdGF0ZSB8fCBnZXRMaW5rU3RhdGUpO1xuXHRjb25zdCBleHRlcm5hbExpbmsgPSBpc0FjdGl2ZSA9PT0gdm9pZCAwICYmIGhyZWY7XG5cdGNvbnN0IGxpbmtEaXNhYmxlZCA9IGRpc2FibGVkIHx8IGhyZWYgPT09IHZvaWQgMDtcblx0Y29uc3QgaGFzUmVuZGVyRmV0Y2hlZCA9IFJlYWN0JDEudXNlUmVmKGZhbHNlKTtcblx0Y29uc3QgcHJlbG9hZCA9IG9wdGlvbnMucmVsb2FkRG9jdW1lbnQgfHwgZXh0ZXJuYWxMaW5rIHx8IGxpbmtEaXNhYmxlZCA/IGZhbHNlIDogdXNlclByZWxvYWQgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFByZWxvYWQ7XG5cdGNvbnN0IHByZWxvYWREZWxheSA9IHVzZXJQcmVsb2FkRGVsYXkgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFByZWxvYWREZWxheSA/PyAwO1xuXHRjb25zdCBlbnF1ZXVlUHJlbG9hZCA9IFJlYWN0JDEudXNlQ2FsbGJhY2soKGUpID0+IHtcblx0XHRjb25zdCBpc0ludGVyc2VjdGluZyA9IGU/LmlzSW50ZXJzZWN0aW5nO1xuXHRcdGlmICghKGlzSW50ZXJzZWN0aW5nID8/IHByZWxvYWQgPT09IFwiaW50ZW50XCIpKSB7XG5cdFx0XHRpZiAoaXNJbnRlcnNlY3RpbmcgPT09IGZhbHNlKSBjYW5jZWxQcmVsb2FkKGlubmVyUmVmKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0aWYgKCFwcmVsb2FkRGVsYXkpIHtcblx0XHRcdHByZWxvYWRMaW5rKHJvdXRlciwgZGVzdCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlubmVyUmVmLnQgPz89IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0aW5uZXJSZWYudCA9IHZvaWQgMDtcblx0XHRcdHByZWxvYWRMaW5rKHJvdXRlciwgZGVzdCk7XG5cdFx0fSwgcHJlbG9hZERlbGF5KTtcblx0fSwgW1xuXHRcdHJvdXRlcixcblx0XHRkZXN0LFxuXHRcdGlubmVyUmVmLFxuXHRcdHByZWxvYWQsXG5cdFx0cHJlbG9hZERlbGF5XG5cdF0pO1xuXHRSZWFjdCQxLnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0aWYgKCFwcmVsb2FkKSByZXR1cm47XG5cdFx0aWYgKHByZWxvYWQgPT09IFwicmVuZGVyXCIgJiYgIWhhc1JlbmRlckZldGNoZWQuY3VycmVudCkge1xuXHRcdFx0aGFzUmVuZGVyRmV0Y2hlZC5jdXJyZW50ID0gdHJ1ZTtcblx0XHRcdHByZWxvYWRMaW5rKHJvdXRlciwgZGVzdCk7XG5cdFx0fVxuXHRcdGxldCBhY3RpdmUgPSB0cnVlO1xuXHRcdGxldCBvYnNlcnZlcjtcblx0XHRpZiAocHJlbG9hZCA9PT0gXCJ2aWV3cG9ydFwiICYmIGlubmVyUmVmLmN1cnJlbnQgJiYgdHlwZW9mIEludGVyc2VjdGlvbk9ic2VydmVyID09PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRcdG9ic2VydmVyID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKChlbnRyaWVzKSA9PiB7XG5cdFx0XHRcdGlmIChhY3RpdmUpIGVucXVldWVQcmVsb2FkKGVudHJpZXMucG9wKCkpO1xuXHRcdFx0fSwgeyByb290TWFyZ2luOiBcIjEwMHB4XCIgfSk7XG5cdFx0XHRvYnNlcnZlci5vYnNlcnZlKGlubmVyUmVmLmN1cnJlbnQpO1xuXHRcdH1cblx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0YWN0aXZlID0gZmFsc2U7XG5cdFx0XHRvYnNlcnZlcj8uZGlzY29ubmVjdCgpO1xuXHRcdFx0Y2FuY2VsUHJlbG9hZChpbm5lclJlZik7XG5cdFx0fTtcblx0fSwgW1xuXHRcdHJvdXRlcixcblx0XHRkZXN0LFxuXHRcdHByZWxvYWQsXG5cdFx0ZW5xdWV1ZVByZWxvYWQsXG5cdFx0aW5uZXJSZWZcblx0XSk7XG5cdGNvbnN0IHByb3BzID0gY29sbGVjdEVsZW1lbnRQcm9wcyhvcHRpb25zLCBob3N0KTtcblx0cHJvcHMucmVmID0gZm9yd2FyZGVkUmVmID8gbWVyZ2VkUmVmIDogaW5uZXJSZWY7XG5cdGlmIChleHRlcm5hbExpbmspIHtcblx0XHRwcm9wcy5ocmVmID0gZXh0ZXJuYWxMaW5rO1xuXHRcdHJldHVybiBwcm9wcztcblx0fVxuXHRjb25zdCBoYW5kbGVDbGljayA9IChlKSA9PiB7XG5cdFx0Y29uc3QgZWZmZWN0aXZlVGFyZ2V0ID0gdGFyZ2V0ID8/IGUuY3VycmVudFRhcmdldC5nZXRBdHRyaWJ1dGUoXCJ0YXJnZXRcIik7XG5cdFx0aWYgKCFsaW5rRGlzYWJsZWQgJiYgIShlLm1ldGFLZXkgfHwgZS5hbHRLZXkgfHwgZS5jdHJsS2V5IHx8IGUuc2hpZnRLZXkpICYmICFlLmRlZmF1bHRQcmV2ZW50ZWQgJiYgKCFlZmZlY3RpdmVUYXJnZXQgfHwgZWZmZWN0aXZlVGFyZ2V0ID09PSBcIl9zZWxmXCIpICYmIGUuYnV0dG9uID09PSAwKSB7XG5cdFx0XHRlLnByZXZlbnREZWZhdWx0KCk7XG5cdFx0XHRjYW5jZWxQcmVsb2FkKGlubmVyUmVmKTtcblx0XHRcdHJvdXRlci5uYXZpZ2F0ZSh7XG5cdFx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRcdF9mcm9tTG9jYXRpb246IGRlc3QuX2Zyb21Mb2NhdGlvblxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBoYW5kbGVUb3VjaFN0YXJ0ID0gKCkgPT4ge1xuXHRcdGlmIChwcmVsb2FkID09PSBcImludGVudFwiKSBwcmVsb2FkTGluayhyb3V0ZXIsIGRlc3QpO1xuXHR9O1xuXHRjb25zdCBoYW5kbGVMZWF2ZSA9ICgpID0+IHtcblx0XHRpZiAocHJlbG9hZCA9PT0gXCJpbnRlbnRcIikgY2FuY2VsUHJlbG9hZChpbm5lclJlZik7XG5cdH07XG5cdHByb3BzLm9uQ2xpY2sgPSBjb21wb3NlSGFuZGxlcnMob25DbGljaywgaGFuZGxlQ2xpY2spO1xuXHRwcm9wcy5vbkJsdXIgPSBjb21wb3NlSGFuZGxlcnMob25CbHVyLCBoYW5kbGVMZWF2ZSk7XG5cdHByb3BzLm9uRm9jdXMgPSBjb21wb3NlSGFuZGxlcnMob25Gb2N1cywgZW5xdWV1ZVByZWxvYWQpO1xuXHRwcm9wcy5vbk1vdXNlRW50ZXIgPSBjb21wb3NlSGFuZGxlcnMob25Nb3VzZUVudGVyLCBlbnF1ZXVlUHJlbG9hZCk7XG5cdHByb3BzLm9uTW91c2VMZWF2ZSA9IGNvbXBvc2VIYW5kbGVycyhvbk1vdXNlTGVhdmUsIGhhbmRsZUxlYXZlKTtcblx0cHJvcHMub25Ub3VjaFN0YXJ0ID0gY29tcG9zZUhhbmRsZXJzKG9uVG91Y2hTdGFydCwgaGFuZGxlVG91Y2hTdGFydCk7XG5cdHJldHVybiBhcHBseUxpbmtTdGF0ZShwcm9wcywgb3B0aW9ucywgaXNBY3RpdmUsIGhyZWYsIGxpbmtEaXNhYmxlZCwgaG9zdCk7XG59XG52YXIgU1RBVElDX0VNUFRZX09CSkVDVCA9IHt9O1xudmFyIFNUQVRJQ19BQ1RJVkVfT0JKRUNUID0geyBjbGFzc05hbWU6IFwiYWN0aXZlXCIgfTtcbnZhciBST1VURVJfT1BUSU9OX0tFWVMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldChbXG5cdFwidG9cIixcblx0XCJwYXJhbXNcIixcblx0XCJzZWFyY2hcIixcblx0XCJoYXNoXCIsXG5cdFwic3RhdGVcIixcblx0XCJtYXNrXCIsXG5cdFwiZnJvbVwiLFxuXHRcInVuc2FmZVJlbGF0aXZlXCIsXG5cdFwicmVsb2FkRG9jdW1lbnRcIixcblx0XCJwcmVsb2FkXCIsXG5cdFwicHJlbG9hZERlbGF5XCIsXG5cdFwicHJlbG9hZEludGVudFByb3hpbWl0eVwiLFxuXHRcImhhc2hTY3JvbGxJbnRvVmlld1wiLFxuXHRcInJlcGxhY2VcIixcblx0XCJzdGFydFRyYW5zaXRpb25cIixcblx0XCJyZXNldFNjcm9sbFwiLFxuXHRcInZpZXdUcmFuc2l0aW9uXCIsXG5cdFwiaWdub3JlQmxvY2tlclwiLFxuXHRcImFjdGl2ZVByb3BzXCIsXG5cdFwiaW5hY3RpdmVQcm9wc1wiLFxuXHRcImFjdGl2ZU9wdGlvbnNcIixcblx0XCJfYXNDaGlsZFwiXG5dKTtcbmZ1bmN0aW9uIGNvbGxlY3RFbGVtZW50UHJvcHMob3B0aW9ucywgaG9zdCkge1xuXHRjb25zdCBwcm9wcyA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBvcHRpb25zKSB7XG5cdFx0aWYgKFJPVVRFUl9PUFRJT05fS0VZUy5oYXMoa2V5KSB8fCBrZXkgPT09IFwidHlwZVwiICYmIGhvc3QgIT09IHZvaWQgMCB8fCBrZXkgPT09IFwiZGlzYWJsZWRcIiAmJiBob3N0ID09PSBcImFcIikgY29udGludWU7XG5cdFx0cHJvcHNba2V5XSA9IG9wdGlvbnNba2V5XTtcblx0fVxuXHRyZXR1cm4gcHJvcHM7XG59XG5mdW5jdGlvbiBhcHBseUxpbmtTdGF0ZShwcm9wcywgb3B0aW9ucywgaXNBY3RpdmUsIGhyZWYsIGxpbmtEaXNhYmxlZCwgaG9zdCkge1xuXHRjb25zdCB7IGFjdGl2ZVByb3BzLCBpbmFjdGl2ZVByb3BzLCBjbGFzc05hbWUsIHN0eWxlLCB0YXJnZXQgfSA9IG9wdGlvbnM7XG5cdGNvbnN0IHN0YXRlUHJvcHMgPSBmdW5jdGlvbmFsVXBkYXRlKGlzQWN0aXZlID8gYWN0aXZlUHJvcHMgOiBpbmFjdGl2ZVByb3BzLCB7fSkgPz8gKGlzQWN0aXZlID8gU1RBVElDX0FDVElWRV9PQkpFQ1QgOiBTVEFUSUNfRU1QVFlfT0JKRUNUKTtcblx0T2JqZWN0LmFzc2lnbihwcm9wcywgc3RhdGVQcm9wcyk7XG5cdHByb3BzLmhyZWYgPSBocmVmO1xuXHRpZiAoaG9zdCAhPT0gXCJhXCIpIHByb3BzLmRpc2FibGVkID0gbGlua0Rpc2FibGVkO1xuXHRwcm9wcy50YXJnZXQgPSB0YXJnZXQ7XG5cdGNvbnN0IHN0YXRlU3R5bGUgPSBzdGF0ZVByb3BzLnN0eWxlO1xuXHRpZiAoc3R5bGUgfHwgc3RhdGVTdHlsZSkgcHJvcHMuc3R5bGUgPSBzdHlsZSAmJiBzdGF0ZVN0eWxlID8ge1xuXHRcdC4uLnN0eWxlLFxuXHRcdC4uLnN0YXRlU3R5bGVcblx0fSA6IHN0eWxlIHx8IHN0YXRlU3R5bGU7XG5cdGNvbnN0IHN0YXRlQ2xhc3NOYW1lID0gc3RhdGVQcm9wcy5jbGFzc05hbWU7XG5cdGlmIChjbGFzc05hbWUgfHwgc3RhdGVDbGFzc05hbWUpIHByb3BzLmNsYXNzTmFtZSA9IGNsYXNzTmFtZSA/IHN0YXRlQ2xhc3NOYW1lID8gYCR7Y2xhc3NOYW1lfSAke3N0YXRlQ2xhc3NOYW1lfWAgOiBjbGFzc05hbWUgOiBzdGF0ZUNsYXNzTmFtZTtcblx0aWYgKGxpbmtEaXNhYmxlZCkge1xuXHRcdHByb3BzLnJvbGUgPSBcImxpbmtcIjtcblx0XHRwcm9wc1tcImFyaWEtZGlzYWJsZWRcIl0gPSB0cnVlO1xuXHR9XG5cdGlmIChpc0FjdGl2ZSkge1xuXHRcdHByb3BzW1wiZGF0YS1zdGF0dXNcIl0gPSBcImFjdGl2ZVwiO1xuXHRcdHByb3BzW1wiYXJpYS1jdXJyZW50XCJdID0gXCJwYWdlXCI7XG5cdH1cblx0cmV0dXJuIHByb3BzO1xufVxuZnVuY3Rpb24gZ2V0U2VydmVyTGlua1Byb3BzKHJvdXRlciwgb3B0aW9ucywgZm9yd2FyZGVkUmVmLCBob3N0KSB7XG5cdGNvbnN0IHsgdG8sIGRpc2FibGVkLCBhY3RpdmVPcHRpb25zIH0gPSBvcHRpb25zO1xuXHRjb25zdCBkaXJlY3RFeHRlcm5hbExpbmsgPSByZXNvbHZlRXh0ZXJuYWxMaW5rKHRvLCByb3V0ZXIucHJvdG9jb2xBbGxvd2xpc3QpO1xuXHRjb25zdCBuZXh0ID0gZGlyZWN0RXh0ZXJuYWxMaW5rID09PSB2b2lkIDAgPyByb3V0ZXIuYnVpbGRMb2NhdGlvbihvcHRpb25zKSA6IHZvaWQgMDtcblx0Y29uc3QgaHJlZk9wdGlvbiA9IG5leHQgPyBnZXRIcmVmT3B0aW9uKG5leHQsIHJvdXRlciwgZGlzYWJsZWQpIDogZGlyZWN0RXh0ZXJuYWxMaW5rID8/IHZvaWQgMDtcblx0Y29uc3QgbGlua0Rpc2FibGVkID0gZGlzYWJsZWQgfHwgIWhyZWZPcHRpb247XG5cdGNvbnN0IGV4dGVybmFsTGluayA9IGRpcmVjdEV4dGVybmFsTGluayA/PyAoaHJlZk9wdGlvbiAmJiBnZXRVcmxTY2hlbWUoaHJlZk9wdGlvbikgPyBocmVmT3B0aW9uIDogdm9pZCAwKTtcblx0Y29uc3QgcHJvcHMgPSBjb2xsZWN0RWxlbWVudFByb3BzKG9wdGlvbnMsIGhvc3QpO1xuXHRwcm9wcy5yZWYgPSBmb3J3YXJkZWRSZWY7XG5cdGlmIChleHRlcm5hbExpbmspIHtcblx0XHRwcm9wcy5ocmVmID0gZXh0ZXJuYWxMaW5rO1xuXHRcdHJldHVybiBwcm9wcztcblx0fVxuXHRyZXR1cm4gYXBwbHlMaW5rU3RhdGUocHJvcHMsIG9wdGlvbnMsICEhbmV4dCAmJiAhKCFkaXNhYmxlZCAmJiAhaHJlZk9wdGlvbikgJiYgIWFjdGl2ZU9wdGlvbnM/LmluY2x1ZGVIYXNoICYmIHJlc29sdmVJc0FjdGl2ZShyb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLmdldCgpLCBuZXh0LCBhY3RpdmVPcHRpb25zLCByb3V0ZXIuYmFzZXBhdGgpLCBocmVmT3B0aW9uLCBsaW5rRGlzYWJsZWQsIGhvc3QpO1xufVxudmFyIGNhbmNlbFByZWxvYWQgPSAocmVmKSA9PiB7XG5cdGNsZWFyVGltZW91dChyZWYudCk7XG5cdHJlZi50ID0gdm9pZCAwO1xufTtcbnZhciBjb21wb3NlSGFuZGxlcnMgPSAoZmlyc3QsIHNlY29uZCkgPT4ge1xuXHRpZiAoIWZpcnN0KSByZXR1cm4gc2Vjb25kO1xuXHRyZXR1cm4gKGV2ZW50KSA9PiBldmVudC5kZWZhdWx0UHJldmVudGVkIHx8IChmaXJzdChldmVudCksIGV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQgfHwgc2Vjb25kKGV2ZW50KSk7XG59O1xuZnVuY3Rpb24gZ2V0SHJlZk9wdGlvbihuZXh0LCByb3V0ZXIsIGRpc2FibGVkKSB7XG5cdGlmIChkaXNhYmxlZCkgcmV0dXJuO1xuXHRjb25zdCBsb2NhdGlvbiA9IG5leHQubWFza2VkTG9jYXRpb24gPz8gbmV4dDtcblx0Y29uc3QgaHJlZiA9IGxvY2F0aW9uLmV4dGVybmFsID8gbG9jYXRpb24ucHVibGljSHJlZiA6IHJvdXRlci5oaXN0b3J5LmNyZWF0ZUhyZWYobG9jYXRpb24ucHVibGljSHJlZikgfHwgXCIvXCI7XG5cdGlmICgobG9jYXRpb24uZXh0ZXJuYWwgfHwgaHJlZiAhPT0gbG9jYXRpb24ucHVibGljSHJlZikgJiYgaXNEYW5nZXJvdXNQcm90b2NvbChocmVmLCByb3V0ZXIucHJvdG9jb2xBbGxvd2xpc3QpKSB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY29uc29sZS53YXJuKGBCbG9ja2VkIExpbmsgd2l0aCBkYW5nZXJvdXMgcHJvdG9jb2w6ICR7aHJlZn1gKTtcblx0XHRyZXR1cm47XG5cdH1cblx0cmV0dXJuIGhyZWY7XG59XG4vKipcbiogQ3JlYXRlcyBhIHR5cGVkIExpbmstbGlrZSBjb21wb25lbnQgdGhhdCBwcmVzZXJ2ZXMgVGFuU3RhY2sgUm91dGVyJ3NcbiogbmF2aWdhdGlvbiBzZW1hbnRpY3MgYW5kIHR5cGUtc2FmZXR5IHdoaWxlIGRlbGVnYXRpbmcgcmVuZGVyaW5nIHRvIHRoZVxuKiBwcm92aWRlZCBob3N0IGNvbXBvbmVudC5cbipcbiogVXNlZnVsIGZvciBpbnRlZ3JhdGluZyBkZXNpZ24gc3lzdGVtIGFuY2hvcnMvYnV0dG9ucyB3aGlsZSBrZWVwaW5nXG4qIHJvdXRlci1hd2FyZSBwcm9wcyAoZWcuIGB0b2AsIGBwYXJhbXNgLCBgc2VhcmNoYCwgYHByZWxvYWRgKS5cbipcbiogQHBhcmFtIENvbXAgVGhlIGhvc3QgY29tcG9uZW50IHRvIHJlbmRlciAoZWcuIGEgZGVzaWduLXN5c3RlbSBMaW5rL0J1dHRvbilcbiogQHJldHVybnMgQSByb3V0ZXItYXdhcmUgY29tcG9uZW50IHdpdGggdGhlIHNhbWUgQVBJIGFzIGBMaW5rYC5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9ndWlkZS9jdXN0b20tbGlua1xuKi9cbmZ1bmN0aW9uIGNyZWF0ZUxpbmsoQ29tcCkge1xuXHRyZXR1cm4gUmVhY3QkMS5mb3J3YXJkUmVmKGZ1bmN0aW9uIENyZWF0ZWRMaW5rKHByb3BzLCByZWYpIHtcblx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChMaW5rLCB7XG5cdFx0XHQuLi5wcm9wcyxcblx0XHRcdF9hc0NoaWxkOiBDb21wLFxuXHRcdFx0cmVmXG5cdFx0fSk7XG5cdH0pO1xufVxuLyoqXG4qIEEgc3Ryb25nbHktdHlwZWQgYW5jaG9yIGNvbXBvbmVudCBmb3IgZGVjbGFyYXRpdmUgbmF2aWdhdGlvbi5cbiogSGFuZGxlcyBwYXRoLCBzZWFyY2gsIGhhc2ggYW5kIHN0YXRlIHVwZGF0ZXMgd2l0aCBvcHRpb25hbCByb3V0ZSBwcmVsb2FkaW5nXG4qIGFuZCBhY3RpdmUtc3RhdGUgc3R5bGluZy5cbipcbiogUHJvcHM6XG4qIC0gYHByZWxvYWRgOiBDb250cm9scyByb3V0ZSBwcmVsb2FkaW5nIChlZy4gJ2ludGVudCcsICdyZW5kZXInLCAndmlld3BvcnQnLCB0cnVlL2ZhbHNlKVxuKiAtIGBwcmVsb2FkRGVsYXlgOiBEZWxheSBpbiBtcyBiZWZvcmUgcHJlbG9hZGluZyBvbiBmb2N1cywgaG92ZXIsIG9yIHZpZXdwb3J0IGVudHJ5XG4qIC0gYGFjdGl2ZVByb3BzYC9gaW5hY3RpdmVQcm9wc2A6IEFkZGl0aW9uYWwgcHJvcHMgbWVyZ2VkIHdoZW4gbGluayBpcyBhY3RpdmUvaW5hY3RpdmVcbiogLSBgcmVzZXRTY3JvbGxgL2BoYXNoU2Nyb2xsSW50b1ZpZXdgOiBDb250cm9sIHNjcm9sbCBiZWhhdmlvciBvbiBuYXZpZ2F0aW9uXG4qIC0gYHZpZXdUcmFuc2l0aW9uYC9gc3RhcnRUcmFuc2l0aW9uYDogVXNlIFZpZXcgVHJhbnNpdGlvbnMvUmVhY3QgdHJhbnNpdGlvbnMgZm9yIG5hdmlnYXRpb25cbiogLSBgaWdub3JlQmxvY2tlcmA6IEJ5cGFzcyByZWdpc3RlcmVkIGJsb2NrZXJzXG4qXG4qIEByZXR1cm5zIEFuIGFuY2hvci1saWtlIGVsZW1lbnQgdGhhdCBuYXZpZ2F0ZXMgd2l0aG91dCBmdWxsIHBhZ2UgcmVsb2Fkcy5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2xpbmtDb21wb25lbnRcbiovXG52YXIgTGluayA9IFJlYWN0JDEubWVtbyhSZWFjdCQxLmZvcndhcmRSZWYoKHByb3BzLCByZWYpID0+IHtcblx0Y29uc3QgaG9zdCA9IHByb3BzLl9hc0NoaWxkIHx8IFwiYVwiO1xuXHRjb25zdCBsaW5rUHJvcHMgPSB1c2VMaW5rUHJvcHMocHJvcHMsIHJlZiwgaG9zdCk7XG5cdGNvbnN0IGNoaWxkcmVuID0gdHlwZW9mIHByb3BzLmNoaWxkcmVuID09PSBcImZ1bmN0aW9uXCIgPyBwcm9wcy5jaGlsZHJlbih7IGlzQWN0aXZlOiBsaW5rUHJvcHNbXCJkYXRhLXN0YXR1c1wiXSA9PT0gXCJhY3RpdmVcIiB9KSA6IHByb3BzLmNoaWxkcmVuO1xuXHRyZXR1cm4gUmVhY3QkMS5jcmVhdGVFbGVtZW50KGhvc3QsIGxpbmtQcm9wcywgY2hpbGRyZW4pO1xufSksIGFyZUxpbmtQcm9wc0VxdWFsKTtcbmZ1bmN0aW9uIGFyZUxpbmtQcm9wc0VxdWFsKHByZXYsIG5leHQpIHtcblx0bGV0IGV4dHJhS2V5cyA9IDA7XG5cdGZvciAoY29uc3Qga2V5IGluIG5leHQpIHtcblx0XHRleHRyYUtleXMrKztcblx0XHRpZiAocHJldltrZXldID09PSBuZXh0W2tleV0pIGNvbnRpbnVlO1xuXHRcdGlmICghUk9VVEVSX09QVElPTl9LRVlTLmhhcyhrZXkpIHx8ICFkZWVwRXF1YWwocHJldltrZXldLCBuZXh0W2tleV0sIGZhbHNlLCB0cnVlKSkgcmV0dXJuIGZhbHNlO1xuXHR9XG5cdGZvciAoY29uc3QgX2tleSBpbiBwcmV2KSBleHRyYUtleXMtLTtcblx0cmV0dXJuIGV4dHJhS2V5cyA9PT0gMDtcbn1cbi8qKlxuKiBWYWxpZGF0ZSBhbmQgcmV1c2UgbmF2aWdhdGlvbiBvcHRpb25zIGZvciBgTGlua2AsIGBuYXZpZ2F0ZWAgb3IgYHJlZGlyZWN0YC5cbiogQWNjZXB0cyBhIGxpdGVyYWwgb3B0aW9ucyBvYmplY3QgYW5kIHJldHVybnMgaXQgdHlwZWQgZm9yIGxhdGVyIHNwcmVhZGluZy5cbiogQGV4YW1wbGVcbiogY29uc3Qgb3B0cyA9IGxpbmtPcHRpb25zKHsgdG86ICcvZGFzaGJvYXJkJywgc2VhcmNoOiB7IHRhYjogJ2hvbWUnIH0gfSlcbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2xpbmtPcHRpb25zXG4qL1xudmFyIGxpbmtPcHRpb25zID0gKG9wdGlvbnMpID0+IHtcblx0cmV0dXJuIG9wdGlvbnM7XG59O1xuLyoqXG4qIFR5cGUtY2hlY2sgYSBsaXRlcmFsIG9iamVjdCBmb3IgdXNlIHdpdGggYExpbmtgLCBgbmF2aWdhdGVgIG9yIGByZWRpcmVjdGAuXG4qIFVzZSB0byB2YWxpZGF0ZSBhbmQgcmV1c2UgbmF2aWdhdGlvbiBvcHRpb25zIGFjcm9zcyB5b3VyIGFwcC5cbiogQGV4YW1wbGVcbiogY29uc3Qgb3B0cyA9IGxpbmtPcHRpb25zKHsgdG86ICcvZGFzaGJvYXJkJywgc2VhcmNoOiB7IHRhYjogJ2hvbWUnIH0gfSlcbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2xpbmtPcHRpb25zXG4qL1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBMaW5rLCBjb21wb3NlSGFuZGxlcnMsIGNyZWF0ZUxpbmssIGxpbmtPcHRpb25zLCB1c2VMaW5rUHJvcHMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bGluay5qcy5tYXAiLCJpbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IHVzZU1hdGNoIH0gZnJvbSBcIi4vdXNlTWF0Y2guanNcIjtcbmltcG9ydCB7IHVzZUxvYWRlckRhdGEgfSBmcm9tIFwiLi91c2VMb2FkZXJEYXRhLmpzXCI7XG5pbXBvcnQgeyB1c2VMb2FkZXJEZXBzIH0gZnJvbSBcIi4vdXNlTG9hZGVyRGVwcy5qc1wiO1xuaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSBcIi4vdXNlUGFyYW1zLmpzXCI7XG5pbXBvcnQgeyB1c2VTZWFyY2ggfSBmcm9tIFwiLi91c2VTZWFyY2guanNcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcIi4vdXNlTmF2aWdhdGUuanNcIjtcbmltcG9ydCB7IHVzZVJvdXRlQ29udGV4dCB9IGZyb20gXCIuL3VzZVJvdXRlQ29udGV4dC5qc1wiO1xuaW1wb3J0IHsgTGluayB9IGZyb20gXCIuL2xpbmsuanNcIjtcbmltcG9ydCB7IEJhc2VSb290Um91dGUsIEJhc2VSb3V0ZSwgQmFzZVJvdXRlQXBpLCBub3RGb3VuZCB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9yb3V0ZS50c3hcbi8qKlxuKiBSZXR1cm5zIGEgcm91dGUtc3BlY2lmaWMgQVBJIHRoYXQgZXhwb3NlcyB0eXBlLXNhZmUgaG9va3MgcHJlLWJvdW5kXG4qIHRvIGEgc2luZ2xlIHJvdXRlIElELiBVc2VmdWwgZm9yIGNvbnN1bWluZyBhIHJvdXRlJ3MgQVBJcyBmcm9tIGZpbGVzXG4qIHdoZXJlIHRoZSByb3V0ZSBvYmplY3QgaXNuJ3QgZGlyZWN0bHkgaW1wb3J0ZWQgKGUuZy4gY29kZS1zcGxpdCBmaWxlcykuXG4qXG4qIEBwYXJhbSBpZCBSb3V0ZSBJRCBzdHJpbmcgbGl0ZXJhbCBmb3IgdGhlIHRhcmdldCByb3V0ZS5cbiogQHJldHVybnMgQSBgUm91dGVBcGlgIGluc3RhbmNlIGJvdW5kIHRvIHRoZSBnaXZlbiByb3V0ZSBJRC5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2dldFJvdXRlQXBpRnVuY3Rpb25cbiovXG5mdW5jdGlvbiBnZXRSb3V0ZUFwaShpZCkge1xuXHRyZXR1cm4gbmV3IFJvdXRlQXBpKHsgaWQgfSk7XG59XG52YXIgUm91dGVBcGkgPSBjbGFzcyBleHRlbmRzIEJhc2VSb3V0ZUFwaSB7XG5cdC8qKlxuXHQqIEBkZXByZWNhdGVkIFVzZSB0aGUgYGdldFJvdXRlQXBpYCBmdW5jdGlvbiBpbnN0ZWFkLlxuXHQqL1xuXHRjb25zdHJ1Y3Rvcih7IGlkIH0pIHtcblx0XHRzdXBlcih7IGlkIH0pO1xuXHRcdHRoaXMudXNlTWF0Y2ggPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZU1hdGNoKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZVJvdXRlQ29udGV4dCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlUm91dGVDb250ZXh0KHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZVNlYXJjaCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlU2VhcmNoKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZVBhcmFtcyA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlUGFyYW1zKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZUxvYWRlckRlcHMgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZUxvYWRlckRlcHMoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkLFxuXHRcdFx0XHRzdHJpY3Q6IGZhbHNlXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlTG9hZGVyRGF0YSA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTG9hZGVyRGF0YSh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWQsXG5cdFx0XHRcdHN0cmljdDogZmFsc2Vcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VOYXZpZ2F0ZSA9ICgpID0+IHtcblx0XHRcdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRcdFx0cmV0dXJuIHVzZU5hdmlnYXRlKHsgZnJvbTogcm91dGVyLnJvdXRlc0J5SWRbdGhpcy5pZF0uZnVsbFBhdGggfSk7XG5cdFx0fTtcblx0XHR0aGlzLm5vdEZvdW5kID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiBub3RGb3VuZCh7XG5cdFx0XHRcdHJvdXRlSWQ6IHRoaXMuaWQsXG5cdFx0XHRcdC4uLm9wdHNcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy5MaW5rID0gUmVhY3QuZm9yd2FyZFJlZigocHJvcHMsIHJlZikgPT4ge1xuXHRcdFx0Y29uc3QgZnVsbFBhdGggPSB1c2VSb3V0ZXIoKS5yb3V0ZXNCeUlkW3RoaXMuaWRdLmZ1bGxQYXRoO1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goTGluaywge1xuXHRcdFx0XHRyZWYsXG5cdFx0XHRcdGZyb206IGZ1bGxQYXRoLFxuXHRcdFx0XHQuLi5wcm9wc1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cbn07XG52YXIgUm91dGUgPSBjbGFzcyBleHRlbmRzIEJhc2VSb3V0ZSB7XG5cdC8qKlxuXHQqIEBkZXByZWNhdGVkIFVzZSB0aGUgYGNyZWF0ZVJvdXRlYCBmdW5jdGlvbiBpbnN0ZWFkLlxuXHQqL1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIob3B0aW9ucyk7XG5cdFx0dGhpcy51c2VNYXRjaCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlUm91dGVDb250ZXh0ID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VSb3V0ZUNvbnRleHQoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlU2VhcmNoID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VTZWFyY2goe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlUGFyYW1zID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VQYXJhbXMoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlTG9hZGVyRGVwcyA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTG9hZGVyRGVwcyh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VMb2FkZXJEYXRhID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VMb2FkZXJEYXRhKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZU5hdmlnYXRlID0gKCkgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZU5hdmlnYXRlKHsgZnJvbTogdGhpcy5mdWxsUGF0aCB9KTtcblx0XHR9O1xuXHRcdHRoaXMuTGluayA9IFJlYWN0LmZvcndhcmRSZWYoKHByb3BzLCByZWYpID0+IHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KExpbmssIHtcblx0XHRcdFx0cmVmLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmZ1bGxQYXRoLFxuXHRcdFx0XHQuLi5wcm9wc1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cbn07XG4vKipcbiogQ3JlYXRlcyBhIG5vbi1yb290IFJvdXRlIGluc3RhbmNlIGZvciBjb2RlLWJhc2VkIHJvdXRpbmcuXG4qXG4qIFVzZSB0aGlzIHRvIGRlZmluZSBhIHJvdXRlIHRoYXQgd2lsbCBiZSBjb21wb3NlZCBpbnRvIGEgcm91dGUgdHJlZVxuKiAodHlwaWNhbGx5IHZpYSBhIHBhcmVudCByb3V0ZSdzIGBhZGRDaGlsZHJlbmApLiBJZiB5b3UncmUgdXNpbmcgZmlsZS1iYXNlZFxuKiByb3V0aW5nLCBwcmVmZXIgYGNyZWF0ZUZpbGVSb3V0ZWAuXG4qXG4qIEBwYXJhbSBvcHRpb25zIFJvdXRlIG9wdGlvbnMgKHBhdGgsIGNvbXBvbmVudCwgbG9hZGVyLCBjb250ZXh0LCBldGMuKS5cbiogQHJldHVybnMgQSBSb3V0ZSBpbnN0YW5jZSB0byBiZSBhdHRhY2hlZCB0byB0aGUgcm91dGUgdHJlZS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2NyZWF0ZVJvdXRlRnVuY3Rpb25cbiovXG5mdW5jdGlvbiBjcmVhdGVSb3V0ZShvcHRpb25zKSB7XG5cdHJldHVybiBuZXcgUm91dGUob3B0aW9ucyk7XG59XG4vKipcbiogQ3JlYXRlcyBhIHJvb3Qgcm91dGUgZmFjdG9yeSB0aGF0IHJlcXVpcmVzIGEgcm91dGVyIGNvbnRleHQgdHlwZS5cbipcbiogVXNlIHdoZW4geW91ciByb290IHJvdXRlIGV4cGVjdHMgYGNvbnRleHRgIHRvIGJlIHByb3ZpZGVkIHRvIGBjcmVhdGVSb3V0ZXJgLlxuKiBUaGUgcmV0dXJuZWQgZnVuY3Rpb24gYmVoYXZlcyBsaWtlIGBjcmVhdGVSb290Um91dGVgIGJ1dCBlbmZvcmNlcyBhIGNvbnRleHQgdHlwZS5cbipcbiogQHJldHVybnMgQSBmYWN0b3J5IGZ1bmN0aW9uIHRvIGNvbmZpZ3VyZSBhbmQgcmV0dXJuIGEgcm9vdCByb3V0ZS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2NyZWF0ZVJvb3RSb3V0ZVdpdGhDb250ZXh0RnVuY3Rpb25cbiovXG5mdW5jdGlvbiBjcmVhdGVSb290Um91dGVXaXRoQ29udGV4dCgpIHtcblx0cmV0dXJuIChvcHRpb25zKSA9PiB7XG5cdFx0cmV0dXJuIGNyZWF0ZVJvb3RSb3V0ZShvcHRpb25zKTtcblx0fTtcbn1cbi8qKlxuKiBAZGVwcmVjYXRlZCBVc2UgdGhlIGBjcmVhdGVSb290Um91dGVXaXRoQ29udGV4dGAgZnVuY3Rpb24gaW5zdGVhZC5cbiovXG52YXIgcm9vdFJvdXRlV2l0aENvbnRleHQgPSBjcmVhdGVSb290Um91dGVXaXRoQ29udGV4dDtcbnZhciBSb290Um91dGUgPSBjbGFzcyBleHRlbmRzIEJhc2VSb290Um91dGUge1xuXHQvKipcblx0KiBAZGVwcmVjYXRlZCBgUm9vdFJvdXRlYCBpcyBub3cgYW4gaW50ZXJuYWwgaW1wbGVtZW50YXRpb24gZGV0YWlsLiBVc2UgYGNyZWF0ZVJvb3RSb3V0ZSgpYCBpbnN0ZWFkLlxuXHQqL1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIob3B0aW9ucyk7XG5cdFx0dGhpcy51c2VNYXRjaCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlUm91dGVDb250ZXh0ID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VSb3V0ZUNvbnRleHQoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlU2VhcmNoID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VTZWFyY2goe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlUGFyYW1zID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VQYXJhbXMoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlTG9hZGVyRGVwcyA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTG9hZGVyRGVwcyh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VMb2FkZXJEYXRhID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VMb2FkZXJEYXRhKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZU5hdmlnYXRlID0gKCkgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZU5hdmlnYXRlKHsgZnJvbTogdGhpcy5mdWxsUGF0aCB9KTtcblx0XHR9O1xuXHRcdHRoaXMuTGluayA9IFJlYWN0LmZvcndhcmRSZWYoKHByb3BzLCByZWYpID0+IHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KExpbmssIHtcblx0XHRcdFx0cmVmLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmZ1bGxQYXRoLFxuXHRcdFx0XHQuLi5wcm9wc1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cbn07XG4vKipcbiogQ3JlYXRlcyBhIHJvb3QgUm91dGUgaW5zdGFuY2UgdXNlZCB0byBidWlsZCB5b3VyIHJvdXRlIHRyZWUuXG4qXG4qIFR5cGljYWxseSBwYWlyZWQgd2l0aCBgY3JlYXRlUm91dGVyKHsgcm91dGVUcmVlIH0pYC4gSWYgeW91IG5lZWQgdG8gcmVxdWlyZVxuKiBhIHR5cGVkIHJvdXRlciBjb250ZXh0LCB1c2UgYGNyZWF0ZVJvb3RSb3V0ZVdpdGhDb250ZXh0YCBpbnN0ZWFkLlxuKlxuKiBAcGFyYW0gb3B0aW9ucyBSb290IHJvdXRlIG9wdGlvbnMgKGNvbXBvbmVudCwgZXJyb3IsIHBlbmRpbmcsIGV0Yy4pLlxuKiBAcmV0dXJucyBBIHJvb3Qgcm91dGUgaW5zdGFuY2UuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9jcmVhdGVSb290Um91dGVGdW5jdGlvblxuKi9cbmZ1bmN0aW9uIGNyZWF0ZVJvb3RSb3V0ZShvcHRpb25zKSB7XG5cdHJldHVybiBuZXcgUm9vdFJvdXRlKG9wdGlvbnMpO1xufVxuZnVuY3Rpb24gY3JlYXRlUm91dGVNYXNrKG9wdHMpIHtcblx0cmV0dXJuIG9wdHM7XG59XG52YXIgTm90Rm91bmRSb3V0ZSA9IGNsYXNzIGV4dGVuZHMgUm91dGUge1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIoe1xuXHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdGlkOiBcIjQwNFwiXG5cdFx0fSk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IE5vdEZvdW5kUm91dGUsIFJvb3RSb3V0ZSwgUm91dGUsIFJvdXRlQXBpLCBjcmVhdGVSb290Um91dGUsIGNyZWF0ZVJvb3RSb3V0ZVdpdGhDb250ZXh0LCBjcmVhdGVSb3V0ZSwgY3JlYXRlUm91dGVNYXNrLCBnZXRSb3V0ZUFwaSwgcm9vdFJvdXRlV2l0aENvbnRleHQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGUuanMubWFwIiwiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VNYXRjaCB9IGZyb20gXCIuL3VzZU1hdGNoLmpzXCI7XG5pbXBvcnQgeyB1c2VMb2FkZXJEYXRhIH0gZnJvbSBcIi4vdXNlTG9hZGVyRGF0YS5qc1wiO1xuaW1wb3J0IHsgdXNlTG9hZGVyRGVwcyB9IGZyb20gXCIuL3VzZUxvYWRlckRlcHMuanNcIjtcbmltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gXCIuL3VzZVBhcmFtcy5qc1wiO1xuaW1wb3J0IHsgdXNlU2VhcmNoIH0gZnJvbSBcIi4vdXNlU2VhcmNoLmpzXCI7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCIuL3VzZU5hdmlnYXRlLmpzXCI7XG5pbXBvcnQgeyB1c2VSb3V0ZUNvbnRleHQgfSBmcm9tIFwiLi91c2VSb3V0ZUNvbnRleHQuanNcIjtcbmltcG9ydCB7IGNyZWF0ZVJvdXRlIH0gZnJvbSBcIi4vcm91dGUuanNcIjtcbi8vI3JlZ2lvbiBzcmMvZmlsZVJvdXRlLnRzXG4vKipcbiogQ3JlYXRlcyBhIGZpbGUtYmFzZWQgUm91dGUgZmFjdG9yeSBmb3IgYSBnaXZlbiBwYXRoLlxuKlxuKiBVc2VkIGJ5IFRhblN0YWNrIFJvdXRlcidzIGZpbGUtYmFzZWQgcm91dGluZyB0byBhc3NvY2lhdGUgYSBmaWxlIHdpdGggYVxuKiByb3V0ZS4gVGhlIHJldHVybmVkIGZ1bmN0aW9uIGFjY2VwdHMgc3RhbmRhcmQgcm91dGUgb3B0aW9ucy4gSW4gbm9ybWFsIHVzYWdlXG4qIHRoZSBgcGF0aGAgc3RyaW5nIGlzIGluc2VydGVkIGFuZCBtYWludGFpbmVkIGJ5IHRoZSBgdHNyYCBnZW5lcmF0b3IuXG4qXG4qIEBwYXJhbSBwYXRoIEZpbGUgcGF0aCBsaXRlcmFsIGZvciB0aGUgcm91dGUgKHVzdWFsbHkgYXV0by1nZW5lcmF0ZWQpLlxuKiBAcmV0dXJucyBBIGZ1bmN0aW9uIHRoYXQgYWNjZXB0cyBSb3V0ZSBvcHRpb25zIGFuZCByZXR1cm5zIGEgUm91dGUgaW5zdGFuY2UuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9jcmVhdGVGaWxlUm91dGVGdW5jdGlvblxuKi9cbmZ1bmN0aW9uIGNyZWF0ZUZpbGVSb3V0ZShwYXRoKSB7XG5cdHJldHVybiAob3B0aW9ucykgPT4ge1xuXHRcdGNvbnN0IHJvdXRlID0gY3JlYXRlUm91dGUob3B0aW9ucyk7XG5cdFx0cm91dGUuaXNSb290ID0gZmFsc2U7XG5cdFx0cmV0dXJuIHJvdXRlO1xuXHR9O1xufVxuLyoqIFxuQGRlcHJlY2F0ZWQgSXQncyBubyBsb25nZXIgcmVjb21tZW5kZWQgdG8gdXNlIHRoZSBgRmlsZVJvdXRlYCBjbGFzcyBkaXJlY3RseS5cbkluc3RlYWQsIHVzZSBgY3JlYXRlRmlsZVJvdXRlKCcvcGF0aC90by9maWxlJykob3B0aW9ucylgIHRvIGNyZWF0ZSBhIGZpbGUgcm91dGUuXG4qL1xudmFyIEZpbGVSb3V0ZSA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3IocGF0aCwgX29wdHMpIHtcblx0XHR0aGlzLnBhdGggPSBwYXRoO1xuXHRcdHRoaXMuY3JlYXRlUm91dGUgPSAob3B0aW9ucykgPT4ge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0XHRpZiAoIXRoaXMuc2lsZW50KSBjb25zb2xlLndhcm4oXCJXYXJuaW5nOiBGaWxlUm91dGUgaXMgZGVwcmVjYXRlZCBhbmQgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uIFVzZSB0aGUgY3JlYXRlRmlsZVJvdXRlKHBhdGgpKG9wdGlvbnMpIGZ1bmN0aW9uIGluc3RlYWQuXCIpO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3Qgcm91dGUgPSBjcmVhdGVSb3V0ZShvcHRpb25zKTtcblx0XHRcdHJvdXRlLmlzUm9vdCA9IGZhbHNlO1xuXHRcdFx0cmV0dXJuIHJvdXRlO1xuXHRcdH07XG5cdFx0dGhpcy5zaWxlbnQgPSBfb3B0cz8uc2lsZW50O1xuXHR9XG59O1xuLyoqXG5AZGVwcmVjYXRlZCBJdCdzIHJlY29tbWVuZGVkIG5vdCB0byBzcGxpdCBsb2FkZXJzIGludG8gc2VwYXJhdGUgZmlsZXMuXG5JbnN0ZWFkLCBwbGFjZSB0aGUgbG9hZGVyIGZ1bmN0aW9uIGluIHRoZSBtYWluIHJvdXRlIGZpbGUgdmlhIGBjcmVhdGVGaWxlUm91dGVgLlxuKi9cbmZ1bmN0aW9uIEZpbGVSb3V0ZUxvYWRlcihfcGF0aCkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBjb25zb2xlLndhcm4oYFdhcm5pbmc6IEZpbGVSb3V0ZUxvYWRlciBpcyBkZXByZWNhdGVkIGFuZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi4gUGxlYXNlIHBsYWNlIHRoZSBsb2FkZXIgZnVuY3Rpb24gaW4gdGhlIG1haW4gcm91dGUgZmlsZSwgaW5zaWRlIHRoZSBcXGBjcmVhdGVGaWxlUm91dGUoJy9wYXRoL3RvL2ZpbGUnKShvcHRpb25zKVxcYCBvcHRpb25zYCk7XG5cdHJldHVybiAobG9hZGVyRm4pID0+IGxvYWRlckZuO1xufVxudmFyIExhenlSb3V0ZSA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3Iob3B0cykge1xuXHRcdHRoaXMudXNlTWF0Y2ggPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZU1hdGNoKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5vcHRpb25zLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlUm91dGVDb250ZXh0ID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VSb3V0ZUNvbnRleHQoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLm9wdGlvbnMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VTZWFyY2ggPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZVNlYXJjaCh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMub3B0aW9ucy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZVBhcmFtcyA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlUGFyYW1zKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5vcHRpb25zLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlTG9hZGVyRGVwcyA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTG9hZGVyRGVwcyh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMub3B0aW9ucy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZUxvYWRlckRhdGEgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZUxvYWRlckRhdGEoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLm9wdGlvbnMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VOYXZpZ2F0ZSA9ICgpID0+IHtcblx0XHRcdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRcdFx0cmV0dXJuIHVzZU5hdmlnYXRlKHsgZnJvbTogcm91dGVyLnJvdXRlc0J5SWRbdGhpcy5vcHRpb25zLmlkXS5mdWxsUGF0aCB9KTtcblx0XHR9O1xuXHRcdHRoaXMub3B0aW9ucyA9IG9wdHM7XG5cdH1cbn07XG4vKipcbiogQ3JlYXRlcyBhIGxhemlseS1jb25maWd1cmFibGUgY29kZS1iYXNlZCByb3V0ZSBzdHViIGJ5IElELlxuKlxuKiBVc2UgdGhpcyBmb3IgY29kZS1zcGxpdHRpbmcgd2l0aCBjb2RlLWJhc2VkIHJvdXRlcy4gVGhlIHJldHVybmVkIGZ1bmN0aW9uXG4qIGFjY2VwdHMgb25seSBub24tY3JpdGljYWwgcm91dGUgb3B0aW9ucyBsaWtlIGBjb21wb25lbnRgLCBgcGVuZGluZ0NvbXBvbmVudGAsXG4qIGBlcnJvckNvbXBvbmVudGAsIGFuZCBgbm90Rm91bmRDb21wb25lbnRgIHdoaWNoIGFyZSBhcHBsaWVkIHdoZW4gdGhlIHJvdXRlXG4qIGlzIG1hdGNoZWQuXG4qXG4qIEBwYXJhbSBpZCBSb3V0ZSBJRCBzdHJpbmcgbGl0ZXJhbCB0byBhc3NvY2lhdGUgd2l0aCB0aGUgbGF6eSByb3V0ZS5cbiogQHJldHVybnMgQSBmdW5jdGlvbiB0aGF0IGFjY2VwdHMgbGF6eSByb3V0ZSBvcHRpb25zIGFuZCByZXR1cm5zIGEgYExhenlSb3V0ZWAuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9jcmVhdGVMYXp5Um91dGVGdW5jdGlvblxuKi9cbmZ1bmN0aW9uIGNyZWF0ZUxhenlSb3V0ZShpZCkge1xuXHRyZXR1cm4gKG9wdHMpID0+IHtcblx0XHRyZXR1cm4gbmV3IExhenlSb3V0ZSh7XG5cdFx0XHRpZCxcblx0XHRcdC4uLm9wdHNcblx0XHR9KTtcblx0fTtcbn1cbi8qKlxuKiBDcmVhdGVzIGEgbGF6aWx5LWNvbmZpZ3VyYWJsZSBmaWxlLWJhc2VkIHJvdXRlIHN0dWIgYnkgZmlsZSBwYXRoLlxuKlxuKiBVc2UgdGhpcyBmb3IgY29kZS1zcGxpdHRpbmcgd2l0aCBmaWxlLWJhc2VkIHJvdXRlcyAoZWcuIGAubGF6eS50c3hgIGZpbGVzKS5cbiogVGhlIHJldHVybmVkIGZ1bmN0aW9uIGFjY2VwdHMgb25seSBub24tY3JpdGljYWwgcm91dGUgb3B0aW9ucyBsaWtlXG4qIGBjb21wb25lbnRgLCBgcGVuZGluZ0NvbXBvbmVudGAsIGBlcnJvckNvbXBvbmVudGAsIGFuZCBgbm90Rm91bmRDb21wb25lbnRgLlxuKlxuKiBAcGFyYW0gaWQgRmlsZSBwYXRoIGxpdGVyYWwgZm9yIHRoZSByb3V0ZSBmaWxlLlxuKiBAcmV0dXJucyBBIGZ1bmN0aW9uIHRoYXQgYWNjZXB0cyBsYXp5IHJvdXRlIG9wdGlvbnMgYW5kIHJldHVybnMgYSBgTGF6eVJvdXRlYC5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2NyZWF0ZUxhenlGaWxlUm91dGVGdW5jdGlvblxuKi9cbmZ1bmN0aW9uIGNyZWF0ZUxhenlGaWxlUm91dGUoaWQpIHtcblx0aWYgKHR5cGVvZiBpZCA9PT0gXCJvYmplY3RcIikgcmV0dXJuIG5ldyBMYXp5Um91dGUoaWQpO1xuXHRyZXR1cm4gKG9wdHMpID0+IG5ldyBMYXp5Um91dGUoe1xuXHRcdGlkLFxuXHRcdC4uLm9wdHNcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEZpbGVSb3V0ZSwgRmlsZVJvdXRlTG9hZGVyLCBMYXp5Um91dGUsIGNyZWF0ZUZpbGVSb3V0ZSwgY3JlYXRlTGF6eUZpbGVSb3V0ZSwgY3JlYXRlTGF6eVJvdXRlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWZpbGVSb3V0ZS5qcy5tYXAiLCJpbXBvcnQgeyByZWFjdFVzZSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBpc01vZHVsZU5vdEZvdW5kRXJyb3IgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG4vLyNyZWdpb24gc3JjL2xhenlSb3V0ZUNvbXBvbmVudC50c3hcbi8qKlxuKiBXcmFwIGEgZHluYW1pYyBpbXBvcnQgdG8gY3JlYXRlIGEgcm91dGUgY29tcG9uZW50IHRoYXQgc3VwcG9ydHNcbiogYC5wcmVsb2FkKClgIGFuZCBmcmllbmRseSByZWxvYWQtb24tbW9kdWxlLW1pc3NpbmcgYmVoYXZpb3IuXG4qXG4qIEBwYXJhbSBpbXBvcnRlciBGdW5jdGlvbiByZXR1cm5pbmcgYSBtb2R1bGUgcHJvbWlzZVxuKiBAcGFyYW0gZXhwb3J0TmFtZSBOYW1lZCBleHBvcnQgdG8gdXNlIChkZWZhdWx0OiBgZGVmYXVsdGApXG4qIEByZXR1cm5zIEEgbGF6eSByb3V0ZSBjb21wb25lbnQgY29tcGF0aWJsZSB3aXRoIFRhblN0YWNrIFJvdXRlclxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvbGF6eVJvdXRlQ29tcG9uZW50RnVuY3Rpb25cbiovXG5mdW5jdGlvbiBsYXp5Um91dGVDb21wb25lbnQoaW1wb3J0ZXIsIGV4cG9ydE5hbWUpIHtcblx0bGV0IGxvYWRQcm9taXNlO1xuXHRsZXQgY29tcDtcblx0bGV0IGVycm9yO1xuXHRjb25zdCBsb2FkID0gKCkgPT4ge1xuXHRcdGlmICghbG9hZFByb21pc2UpIHtcblx0XHRcdGVycm9yID0gdm9pZCAwO1xuXHRcdFx0bG9hZFByb21pc2UgPSBpbXBvcnRlcigpLnRoZW4oKHJlcykgPT4ge1xuXHRcdFx0XHRpZiAoIShpc1NlcnZlciA/PyB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSkge1xuXHRcdFx0XHRcdGxvYWRQcm9taXNlID0gdm9pZCAwO1xuXHRcdFx0XHRcdGxhenlDb21wLnByZWxvYWQgPSB2b2lkIDA7XG5cdFx0XHRcdH1cblx0XHRcdFx0Y29tcCA9IHJlc1tleHBvcnROYW1lID8/IFwiZGVmYXVsdFwiXTtcblx0XHRcdH0pLmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0bG9hZFByb21pc2UgPSB2b2lkIDA7XG5cdFx0XHRcdGVycm9yID0gZXJyO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdHJldHVybiBsb2FkUHJvbWlzZTtcblx0fTtcblx0Y29uc3QgbGF6eUNvbXAgPSBmdW5jdGlvbiBMYXp5KHByb3BzKSB7XG5cdFx0aWYgKGVycm9yKSB7XG5cdFx0XHRpZiAoaXNNb2R1bGVOb3RGb3VuZEVycm9yKGVycm9yKSAmJiAhKGlzU2VydmVyID8/IHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpICYmIHR5cGVvZiBzZXNzaW9uU3RvcmFnZSAhPT0gXCJ1bmRlZmluZWRcIikge1xuXHRcdFx0XHRjb25zdCBzdG9yYWdlS2V5ID0gYHRhbnN0YWNrX3JvdXRlcl9yZWxvYWQ6JHtlcnJvci5tZXNzYWdlfWA7XG5cdFx0XHRcdGlmICghc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShzdG9yYWdlS2V5KSkge1xuXHRcdFx0XHRcdHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oc3RvcmFnZUtleSwgXCIxXCIpO1xuXHRcdFx0XHRcdHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcblx0XHRcdFx0XHR0aHJvdyBuZXcgUHJvbWlzZSgoKSA9PiB7fSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHRocm93IGVycm9yO1xuXHRcdH1cblx0XHRpZiAoIWNvbXApIHtcblx0XHRcdGlmIChyZWFjdFVzZSkgcmVhY3RVc2UobG9hZCgpKTtcblx0XHRcdGVsc2UgdGhyb3cgbG9hZCgpO1xuXHRcdH1cblx0XHRyZXR1cm4gUmVhY3QkMS5jcmVhdGVFbGVtZW50KGNvbXAsIHByb3BzKTtcblx0fTtcblx0bGF6eUNvbXAucHJlbG9hZCA9IGxvYWQ7XG5cdHJldHVybiBsYXp5Q29tcDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgbGF6eVJvdXRlQ29tcG9uZW50IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWxhenlSb3V0ZUNvbXBvbmVudC5qcy5tYXAiLCJpbXBvcnQgeyBDYXRjaEJvdW5kYXJ5IH0gZnJvbSBcIi4vQ2F0Y2hCb3VuZGFyeS5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBpc05vdEZvdW5kIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0IFwicmVhY3RcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvbm90LWZvdW5kLnRzeFxuZnVuY3Rpb24gQ2F0Y2hOb3RGb3VuZChwcm9wcykge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikge1xuXHRcdGNvbnN0IHJlc2V0S2V5ID0gYG5vdC1mb3VuZC0ke3JvdXRlci5zdG9yZXMubG9jYXRpb24uZ2V0KCkucGF0aG5hbWV9LSR7cm91dGVyLnN0b3Jlcy5zdGF0dXMuZ2V0KCl9YDtcblx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChDYXRjaEJvdW5kYXJ5LCB7XG5cdFx0XHRnZXRSZXNldEtleTogKCkgPT4gcmVzZXRLZXksXG5cdFx0XHRvbkNhdGNoOiAoZXJyb3IsIGVycm9ySW5mbykgPT4ge1xuXHRcdFx0XHRpZiAoaXNOb3RGb3VuZChlcnJvcikpIHByb3BzLm9uQ2F0Y2g/LihlcnJvciwgZXJyb3JJbmZvKTtcblx0XHRcdFx0ZWxzZSB0aHJvdyBlcnJvcjtcblx0XHRcdH0sXG5cdFx0XHRlcnJvckNvbXBvbmVudDogKHsgZXJyb3IgfSkgPT4ge1xuXHRcdFx0XHRpZiAoaXNOb3RGb3VuZChlcnJvcikpIHJldHVybiBwcm9wcy5mYWxsYmFjaz8uKGVycm9yKTtcblx0XHRcdFx0ZWxzZSB0aHJvdyBlcnJvcjtcblx0XHRcdH0sXG5cdFx0XHRjaGlsZHJlbjogcHJvcHMuY2hpbGRyZW5cblx0XHR9KTtcblx0fVxuXHRjb25zdCByZXNldEtleSA9IGBub3QtZm91bmQtJHt1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLCAobG9jYXRpb24pID0+IGxvY2F0aW9uLnBhdGhuYW1lKX0tJHt1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLnN0YXR1cyl9YDtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goQ2F0Y2hCb3VuZGFyeSwge1xuXHRcdGdldFJlc2V0S2V5OiAoKSA9PiByZXNldEtleSxcblx0XHRvbkNhdGNoOiAoZXJyb3IsIGVycm9ySW5mbykgPT4ge1xuXHRcdFx0aWYgKGlzTm90Rm91bmQoZXJyb3IpKSBwcm9wcy5vbkNhdGNoPy4oZXJyb3IsIGVycm9ySW5mbyk7XG5cdFx0XHRlbHNlIHRocm93IGVycm9yO1xuXHRcdH0sXG5cdFx0ZXJyb3JDb21wb25lbnQ6ICh7IGVycm9yIH0pID0+IHtcblx0XHRcdGlmIChpc05vdEZvdW5kKGVycm9yKSkgcmV0dXJuIHByb3BzLmZhbGxiYWNrPy4oZXJyb3IpO1xuXHRcdFx0ZWxzZSB0aHJvdyBlcnJvcjtcblx0XHR9LFxuXHRcdGNoaWxkcmVuOiBwcm9wcy5jaGlsZHJlblxuXHR9KTtcbn1cbmZ1bmN0aW9uIERlZmF1bHRHbG9iYWxOb3RGb3VuZCgpIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJwXCIsIHsgY2hpbGRyZW46IFwiTm90IEZvdW5kXCIgfSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IENhdGNoTm90Rm91bmQsIERlZmF1bHRHbG9iYWxOb3RGb3VuZCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1ub3QtZm91bmQuanMubWFwIiwiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9TY3JpcHRPbmNlLnRzeFxuLyoqXG4qIFNlcnZlci1vbmx5IGhlbHBlciB0byBlbWl0IGEgc2NyaXB0IHRhZyBleGFjdGx5IG9uY2UgZHVyaW5nIFNTUi5cbiovXG5mdW5jdGlvbiBTY3JpcHRPbmNlKHsgY2hpbGRyZW4gfSkge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0aWYgKCEoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSkgcmV0dXJuIG51bGw7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwic2NyaXB0XCIsIHtcblx0XHRub25jZTogcm91dGVyLm9wdGlvbnMuc3NyPy5ub25jZSxcblx0XHRkYW5nZXJvdXNseVNldElubmVySFRNTDogeyBfX2h0bWw6IGNoaWxkcmVuICsgXCI7ZG9jdW1lbnQuY3VycmVudFNjcmlwdC5yZW1vdmUoKVwiIH1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFNjcmlwdE9uY2UgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9U2NyaXB0T25jZS5qcy5tYXAiLCJpbXBvcnQgeyB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQgfSBmcm9tIFwiLi9ub25Sb3V0ZUNvbXBvbmVudENvbnRleHQuanNcIjtcbmltcG9ydCB7IERlZmF1bHRHbG9iYWxOb3RGb3VuZCB9IGZyb20gXCIuL25vdC1mb3VuZC5qc1wiO1xuaW1wb3J0IFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9yZW5kZXJSb3V0ZU5vdEZvdW5kLnRzeFxuLyoqXG4qIFJlbmRlcnMgYSBub3QgZm91bmQgY29tcG9uZW50IGZvciBhIHJvdXRlIHdoZW4gbm8gbWF0Y2hpbmcgcm91dGUgaXMgZm91bmQuXG4qXG4qIEBwYXJhbSByb3V0ZXIgLSBUaGUgcm91dGVyIGluc3RhbmNlIGNvbnRhaW5pbmcgdGhlIHJvdXRlIGNvbmZpZ3VyYXRpb25cbiogQHBhcmFtIHJvdXRlIC0gVGhlIHJvdXRlIHRoYXQgdHJpZ2dlcmVkIHRoZSBub3QgZm91bmQgc3RhdGVcbiogQHBhcmFtIGRhdGEgLSBBZGRpdGlvbmFsIGRhdGEgdG8gcGFzcyB0byB0aGUgbm90IGZvdW5kIGNvbXBvbmVudFxuKiBAcmV0dXJucyBUaGUgcmVuZGVyZWQgbm90IGZvdW5kIGNvbXBvbmVudCBvciBhIGRlZmF1bHQgZmFsbGJhY2sgY29tcG9uZW50XG4qL1xuZnVuY3Rpb24gcmVuZGVyUm91dGVOb3RGb3VuZChyb3V0ZXIsIHJvdXRlLCBkYXRhKSB7XG5cdGlmICghcm91dGUub3B0aW9ucy5ub3RGb3VuZENvbXBvbmVudCkge1xuXHRcdGlmIChyb3V0ZXIub3B0aW9ucy5kZWZhdWx0Tm90Rm91bmRDb21wb25lbnQpIHtcblx0XHRcdGNvbnN0IG5vdEZvdW5kRWxlbWVudCA9IC8qIEBfX1BVUkVfXyAqLyBqc3gocm91dGVyLm9wdGlvbnMuZGVmYXVsdE5vdEZvdW5kQ29tcG9uZW50LCB7IC4uLmRhdGEgfSk7XG5cdFx0XHRyZXR1cm4gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gd3JhcEluTm9uUm91dGVDb21wb25lbnRDb250ZXh0KG5vdEZvdW5kRWxlbWVudCwgXCJub3RGb3VuZENvbXBvbmVudFwiKSA6IG5vdEZvdW5kRWxlbWVudDtcblx0XHR9XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0aWYgKCFyb3V0ZS5vcHRpb25zLm5vdEZvdW5kQ29tcG9uZW50KSBjb25zb2xlLndhcm4oYFdhcm5pbmc6IEEgbm90Rm91bmRFcnJvciB3YXMgZW5jb3VudGVyZWQgb24gdGhlIHJvdXRlIHdpdGggSUQgXCIke3JvdXRlLmlkfVwiLCBidXQgYSBub3RGb3VuZENvbXBvbmVudCBvcHRpb24gd2FzIG5vdCBjb25maWd1cmVkLCBub3Igd2FzIGEgcm91dGVyIGxldmVsIGRlZmF1bHROb3RGb3VuZENvbXBvbmVudCBjb25maWd1cmVkLiBDb25zaWRlciBjb25maWd1cmluZyBhdCBsZWFzdCBvbmUgb2YgdGhlc2UgdG8gYXZvaWQgVGFuU3RhY2sgUm91dGVyJ3Mgb3Zlcmx5IGdlbmVyaWMgZGVmYXVsdE5vdEZvdW5kQ29tcG9uZW50ICg8cD5Ob3QgRm91bmQ8L3A+KWApO1xuXHRcdH1cblx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChEZWZhdWx0R2xvYmFsTm90Rm91bmQsIHt9KTtcblx0fVxuXHRjb25zdCBub3RGb3VuZEVsZW1lbnQgPSAvKiBAX19QVVJFX18gKi8ganN4KHJvdXRlLm9wdGlvbnMubm90Rm91bmRDb21wb25lbnQsIHsgLi4uZGF0YSB9KTtcblx0cmV0dXJuIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IHdyYXBJbk5vblJvdXRlQ29tcG9uZW50Q29udGV4dChub3RGb3VuZEVsZW1lbnQsIFwibm90Rm91bmRDb21wb25lbnRcIikgOiBub3RGb3VuZEVsZW1lbnQ7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHJlbmRlclJvdXRlTm90Rm91bmQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVuZGVyUm91dGVOb3RGb3VuZC5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3Njcm9sbC1yZXN0b3JhdGlvbi1zY3JpcHQvY2xpZW50LnRzXG5mdW5jdGlvbiBnZXRTY3JvbGxSZXN0b3JhdGlvblNjcmlwdEZvclJvdXRlcihfcm91dGVyKSB7XG5cdHJldHVybiBudWxsO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBnZXRTY3JvbGxSZXN0b3JhdGlvblNjcmlwdEZvclJvdXRlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1jbGllbnQuanMubWFwIiwiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBTY3JpcHRPbmNlIH0gZnJvbSBcIi4vU2NyaXB0T25jZS5qc1wiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5pbXBvcnQgeyBnZXRTY3JvbGxSZXN0b3JhdGlvblNjcmlwdEZvclJvdXRlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvc2Nyb2xsLXJlc3RvcmF0aW9uLXNjcmlwdFwiO1xuLy8jcmVnaW9uIHNyYy9zY3JvbGwtcmVzdG9yYXRpb24udHN4XG5mdW5jdGlvbiBTY3JvbGxSZXN0b3JhdGlvbigpIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGNvbnN0IHNjcmlwdCA9IGdldFNjcm9sbFJlc3RvcmF0aW9uU2NyaXB0Rm9yUm91dGVyKHJvdXRlcik7XG5cdGlmICghc2NyaXB0KSByZXR1cm4gbnVsbDtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goU2NyaXB0T25jZSwgeyBjaGlsZHJlbjogc2NyaXB0IH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBTY3JvbGxSZXN0b3JhdGlvbiB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zY3JvbGwtcmVzdG9yYXRpb24uanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyBub25Sb3V0ZUNvbXBvbmVudENvbnRleHQsIHdyYXBJbk5vblJvdXRlQ29tcG9uZW50Q29udGV4dCB9IGZyb20gXCIuL25vblJvdXRlQ29tcG9uZW50Q29udGV4dC5qc1wiO1xuaW1wb3J0IHsgQ2F0Y2hCb3VuZGFyeSwgRXJyb3JDb21wb25lbnQgfSBmcm9tIFwiLi9DYXRjaEJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyBDbGllbnRPbmx5IH0gZnJvbSBcIi4vQ2xpZW50T25seS5qc1wiO1xuaW1wb3J0IHsgbWF0Y2hDb250ZXh0IH0gZnJvbSBcIi4vbWF0Y2hDb250ZXh0LmpzXCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IENhdGNoTm90Rm91bmQgfSBmcm9tIFwiLi9ub3QtZm91bmQuanNcIjtcbmltcG9ydCB7IHJlbmRlclJvdXRlTm90Rm91bmQgfSBmcm9tIFwiLi9yZW5kZXJSb3V0ZU5vdEZvdW5kLmpzXCI7XG5pbXBvcnQgeyBTY3JvbGxSZXN0b3JhdGlvbiB9IGZyb20gXCIuL3Njcm9sbC1yZXN0b3JhdGlvbi5qc1wiO1xuaW1wb3J0IHsgaXNOb3RGb3VuZCwgcm9vdFJvdXRlSWQgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyBqc3gsIGpzeHMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1zdG9yZVwiO1xuLy8jcmVnaW9uIHNyYy9NYXRjaC50c3hcbmZ1bmN0aW9uIHJlbmRlclBlbmRpbmcocm91dGVyLCByb3V0ZSkge1xuXHRjb25zdCBQZW5kaW5nQ29tcG9uZW50ID0gcm91dGU/Lm9wdGlvbnMucGVuZGluZ0NvbXBvbmVudCA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0UGVuZGluZ0NvbXBvbmVudDtcblx0aWYgKCFQZW5kaW5nQ29tcG9uZW50KSByZXR1cm4gbnVsbDtcblx0Y29uc3QgcGVuZGluZ0VsZW1lbnQgPSAvKiBAX19QVVJFX18gKi8ganN4KFBlbmRpbmdDb21wb25lbnQsIHt9KTtcblx0cmV0dXJuIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IHdyYXBJbk5vblJvdXRlQ29tcG9uZW50Q29udGV4dChwZW5kaW5nRWxlbWVudCwgXCJwZW5kaW5nQ29tcG9uZW50XCIpIDogcGVuZGluZ0VsZW1lbnQ7XG59XG52YXIgb3V0bGV0TWF0Y2hTZWxlY3Rpb25FcXVhbCA9IChhLCBiKSA9PiBhWzBdID09PSBiWzBdICYmIGFbMV0gPT09IGJbMV07XG52YXIgY2FuV3JhcEluU3VzcGVuc2UgPSAocm91dGVyLCByb3V0ZSwgc3NyKSA9PiAhcm91dGUuaXNSb290IHx8IHJvdXRlLm9wdGlvbnMuc2hlbGxDb21wb25lbnQgfHwgcm91dGUub3B0aW9ucy53cmFwSW5TdXNwZW5zZSB8fCBzc3IgPT09IGZhbHNlIHx8IHNzciA9PT0gXCJkYXRhLW9ubHlcIiB8fCAhKChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHx8IHJvdXRlci5zc3IpO1xudmFyIE1hdGNoID0gUmVhY3QkMS5tZW1vKGZ1bmN0aW9uIE1hdGNoSW1wbCh7IHJvdXRlSWQgfSkge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikgcmV0dXJuIG1hdGNoVmlldyhyb3V0ZXIsIHJvdXRlci5zdG9yZXMuYnlSb3V0ZS5nZXQocm91dGVJZCkuZ2V0KCkpO1xuXHRjb25zdCBtYXRjaFN0b3JlID0gcm91dGVyLnN0b3Jlcy5nZXRNYXRjaFN0b3JlKHJvdXRlSWQpO1xuXHRyZXR1cm4gbWF0Y2hWaWV3KHJvdXRlciwgdXNlU2VsZWN0b3IobWF0Y2hTdG9yZSkpO1xufSk7XG5mdW5jdGlvbiBtYXRjaFZpZXcocm91dGVyLCBtYXRjaCkge1xuXHRjb25zdCByb3V0ZSA9IHJvdXRlci5yb3V0ZXNCeUlkW21hdGNoLnJvdXRlSWRdO1xuXHRjb25zdCBwZW5kaW5nRWxlbWVudCA9IHJlbmRlclBlbmRpbmcocm91dGVyLCByb3V0ZSk7XG5cdGNvbnN0IHJvdXRlRXJyb3JDb21wb25lbnQgPSByb3V0ZS5vcHRpb25zLmVycm9yQ29tcG9uZW50ID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRFcnJvckNvbXBvbmVudDtcblx0Y29uc3Qgcm91dGVPbkNhdGNoID0gcm91dGUub3B0aW9ucy5vbkNhdGNoID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRPbkNhdGNoO1xuXHRjb25zdCByb3V0ZU5vdEZvdW5kQ29tcG9uZW50ID0gcm91dGUuaXNSb290ID8gcm91dGUub3B0aW9ucy5ub3RGb3VuZENvbXBvbmVudCA/PyByb3V0ZXIub3B0aW9ucy5ub3RGb3VuZFJvdXRlPy5vcHRpb25zLmNvbXBvbmVudCA6IHJvdXRlLm9wdGlvbnMubm90Rm91bmRDb21wb25lbnQ7XG5cdGNvbnN0IHJlc29sdmVkTm9Tc3IgPSBtYXRjaC5zc3IgPT09IGZhbHNlIHx8IG1hdGNoLnNzciA9PT0gXCJkYXRhLW9ubHlcIjtcblx0Y29uc3Qgd3JhcEluU3VzcGVuc2UgPSBjYW5XcmFwSW5TdXNwZW5zZShyb3V0ZXIsIHJvdXRlLCBtYXRjaC5zc3IpICYmIChyb3V0ZS5vcHRpb25zLndyYXBJblN1c3BlbnNlID8/IHBlbmRpbmdFbGVtZW50ID8/IChyb3V0ZS5vcHRpb25zLmVycm9yQ29tcG9uZW50Py5wcmVsb2FkIHx8IHJlc29sdmVkTm9Tc3IpKTtcblx0bGV0IGNvbnRlbnQgPSAvKiBAX19QVVJFX18gKi8ganN4KE1hdGNoSW5uZXIsIHsgbWF0Y2ggfSk7XG5cdGlmIChyZXNvbHZlZE5vU3NyKSBjb250ZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChDbGllbnRPbmx5LCB7XG5cdFx0ZmFsbGJhY2s6IHBlbmRpbmdFbGVtZW50LFxuXHRcdGNoaWxkcmVuOiBjb250ZW50XG5cdH0pO1xuXHRpZiAocm91dGVOb3RGb3VuZENvbXBvbmVudCkgY29udGVudCA9IC8qIEBfX1BVUkVfXyAqLyBqc3goQ2F0Y2hOb3RGb3VuZCwge1xuXHRcdGZhbGxiYWNrOiAoZXJyb3IpID0+IHtcblx0XHRcdGVycm9yLnJvdXRlSWQgPz89IG1hdGNoLnJvdXRlSWQ7XG5cdFx0XHRpZiAoZXJyb3Iucm91dGVJZCAhPT0gbWF0Y2gucm91dGVJZCkgdGhyb3cgZXJyb3I7XG5cdFx0XHRjb25zdCBub3RGb3VuZEVsZW1lbnQgPSBSZWFjdCQxLmNyZWF0ZUVsZW1lbnQocm91dGVOb3RGb3VuZENvbXBvbmVudCwgZXJyb3IpO1xuXHRcdFx0cmV0dXJuIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IHdyYXBJbk5vblJvdXRlQ29tcG9uZW50Q29udGV4dChub3RGb3VuZEVsZW1lbnQsIFwibm90Rm91bmRDb21wb25lbnRcIikgOiBub3RGb3VuZEVsZW1lbnQ7XG5cdFx0fSxcblx0XHRjaGlsZHJlbjogY29udGVudFxuXHR9KTtcblx0aWYgKHJvdXRlRXJyb3JDb21wb25lbnQpIGNvbnRlbnQgPSAvKiBAX19QVVJFX18gKi8ganN4KENhdGNoQm91bmRhcnksIHtcblx0XHRnZXRSZXNldEtleTogKCkgPT4gbWF0Y2gsXG5cdFx0ZXJyb3JDb21wb25lbnQ6IHJvdXRlRXJyb3JDb21wb25lbnQsXG5cdFx0b25DYXRjaDogKGVycm9yLCBlcnJvckluZm8pID0+IHtcblx0XHRcdGlmIChpc05vdEZvdW5kKGVycm9yKSkge1xuXHRcdFx0XHRlcnJvci5yb3V0ZUlkID8/PSBtYXRjaC5yb3V0ZUlkO1xuXHRcdFx0XHR0aHJvdyBlcnJvcjtcblx0XHRcdH1cblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNvbnNvbGUud2FybihgV2FybmluZzogRXJyb3IgaW4gcm91dGUgbWF0Y2g6ICR7bWF0Y2guaWR9YCk7XG5cdFx0XHRyb3V0ZU9uQ2F0Y2g/LihlcnJvciwgZXJyb3JJbmZvKTtcblx0XHR9LFxuXHRcdGNoaWxkcmVuOiBjb250ZW50XG5cdH0pO1xuXHRpZiAod3JhcEluU3VzcGVuc2UpIGNvbnRlbnQgPSAvKiBAX19QVVJFX18gKi8ganN4KFJlYWN0JDEuU3VzcGVuc2UsIHtcblx0XHRmYWxsYmFjazogcGVuZGluZ0VsZW1lbnQsXG5cdFx0Y2hpbGRyZW46IGNvbnRlbnRcblx0fSk7XG5cdGNvbnN0IHNjcm9sbFJlc3RvcmF0aW9uID0gKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikgJiYgcm91dGUucGFyZW50Um91dGU/LmlkID09PSByb290Um91dGVJZCAmJiByb3V0ZXIub3B0aW9ucy5zY3JvbGxSZXN0b3JhdGlvbiA/IC8qIEBfX1BVUkVfXyAqLyBqc3goU2Nyb2xsUmVzdG9yYXRpb24sIHt9KSA6IG51bGw7XG5cdGNvbnN0IFNoZWxsQ29tcG9uZW50ID0gcm91dGUuaXNSb290ICYmIHJvdXRlLm9wdGlvbnMuc2hlbGxDb21wb25lbnQ7XG5cdHJldHVybiBTaGVsbENvbXBvbmVudCA/IC8qIEBfX1BVUkVfXyAqLyBqc3gobWF0Y2hDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0dmFsdWU6IG1hdGNoLnJvdXRlSWQsXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3hzKFNoZWxsQ29tcG9uZW50LCB7IGNoaWxkcmVuOiBbY29udGVudCwgc2Nyb2xsUmVzdG9yYXRpb25dIH0pXG5cdH0pIDogLyogQF9fUFVSRV9fICovIGpzeHMobWF0Y2hDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0dmFsdWU6IG1hdGNoLnJvdXRlSWQsXG5cdFx0Y2hpbGRyZW46IFtjb250ZW50LCBzY3JvbGxSZXN0b3JhdGlvbl1cblx0fSk7XG59XG52YXIgTWF0Y2hJbm5lciA9IFJlYWN0JDEubWVtbyhmdW5jdGlvbiBNYXRjaElubmVySW1wbCh7IG1hdGNoIH0pIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGNvbnN0IHJvdXRlSWQgPSBtYXRjaC5yb3V0ZUlkO1xuXHRjb25zdCByb3V0ZSA9IHJvdXRlci5yb3V0ZXNCeUlkW3JvdXRlSWRdO1xuXHRjb25zdCBrZXkgPSBSZWFjdCQxLnVzZU1lbW8oKCkgPT4ge1xuXHRcdGNvbnN0IHJlbW91bnREZXBzID0gKHJvdXRlLm9wdGlvbnMucmVtb3VudERlcHMgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFJlbW91bnREZXBzKT8uKHtcblx0XHRcdHJvdXRlSWQsXG5cdFx0XHRsb2FkZXJEZXBzOiBtYXRjaC5sb2FkZXJEZXBzLFxuXHRcdFx0cGFyYW1zOiBtYXRjaC5fc3RyaWN0UGFyYW1zLFxuXHRcdFx0c2VhcmNoOiBtYXRjaC5fc3RyaWN0U2VhcmNoXG5cdFx0fSk7XG5cdFx0cmV0dXJuIHJlbW91bnREZXBzID8gSlNPTi5zdHJpbmdpZnkocmVtb3VudERlcHMpIDogdm9pZCAwO1xuXHR9LCBbXG5cdFx0cm91dGVJZCxcblx0XHRtYXRjaC5sb2FkZXJEZXBzLFxuXHRcdG1hdGNoLl9zdHJpY3RQYXJhbXMsXG5cdFx0bWF0Y2guX3N0cmljdFNlYXJjaCxcblx0XHRyb3V0ZS5vcHRpb25zLnJlbW91bnREZXBzLFxuXHRcdHJvdXRlci5vcHRpb25zLmRlZmF1bHRSZW1vdW50RGVwc1xuXHRdKTtcblx0Y29uc3Qgb3V0ID0gUmVhY3QkMS51c2VNZW1vKCgpID0+IHtcblx0XHRjb25zdCBDb21wID0gcm91dGUub3B0aW9ucy5jb21wb25lbnQgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdENvbXBvbmVudDtcblx0XHRyZXR1cm4gQ29tcCA/IC8qIEBfX1BVUkVfXyAqLyBqc3goQ29tcCwge30sIGtleSkgOiAvKiBAX19QVVJFX18gKi8ganN4KE91dGxldCwge30pO1xuXHR9LCBbXG5cdFx0a2V5LFxuXHRcdHJvdXRlLm9wdGlvbnMuY29tcG9uZW50LFxuXHRcdHJvdXRlci5vcHRpb25zLmRlZmF1bHRDb21wb25lbnRcblx0XSk7XG5cdGlmIChtYXRjaC5zdGF0dXMgPT09IFwicGVuZGluZ1wiKSB7XG5cdFx0aWYgKHJvdXRlci5zc3IgJiYgIWNhbldyYXBJblN1c3BlbnNlKHJvdXRlciwgcm91dGUsIG1hdGNoLnNzcikpIHJldHVybiBvdXQ7XG5cdFx0aWYgKHJvdXRlci5fdHgpIHRocm93IHJvdXRlci5fdHhbNV07XG5cdFx0cmV0dXJuIHJlbmRlclBlbmRpbmcocm91dGVyLCByb3V0ZSk7XG5cdH1cblx0aWYgKG1hdGNoLnN0YXR1cyA9PT0gXCJub3RGb3VuZFwiKSByZXR1cm4gcmVuZGVyUm91dGVOb3RGb3VuZChyb3V0ZXIsIHJvdXRlLCBtYXRjaC5lcnJvcik7XG5cdGlmIChtYXRjaC5zdGF0dXMgPT09IFwiZXJyb3JcIikge1xuXHRcdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHtcblx0XHRcdGNvbnN0IFJvdXRlRXJyb3JDb21wb25lbnQgPSAocm91dGUub3B0aW9ucy5lcnJvckNvbXBvbmVudCA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0RXJyb3JDb21wb25lbnQpIHx8IEVycm9yQ29tcG9uZW50O1xuXHRcdFx0Y29uc3QgZXJyb3JFbGVtZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChSb3V0ZUVycm9yQ29tcG9uZW50LCB7XG5cdFx0XHRcdGVycm9yOiBtYXRjaC5lcnJvcixcblx0XHRcdFx0cmVzZXQ6IHZvaWQgMCxcblx0XHRcdFx0aW5mbzogeyBjb21wb25lbnRTdGFjazogXCJcIiB9XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQoZXJyb3JFbGVtZW50LCBcImVycm9yQ29tcG9uZW50XCIpIDogZXJyb3JFbGVtZW50O1xuXHRcdH1cblx0XHR0aHJvdyBtYXRjaC5lcnJvcjtcblx0fVxuXHRyZXR1cm4gb3V0O1xufSk7XG4vKipcbiogUmVuZGVyIHRoZSBuZXh0IGNoaWxkIG1hdGNoIGluIHRoZSByb3V0ZSB0cmVlLiBUeXBpY2FsbHkgdXNlZCBpbnNpZGVcbiogYSByb3V0ZSBjb21wb25lbnQgdG8gcmVuZGVyIG5lc3RlZCByb3V0ZXMuXG4qXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9vdXRsZXRDb21wb25lbnRcbiovXG52YXIgT3V0bGV0ID0gUmVhY3QkMS5tZW1vKGZ1bmN0aW9uIE91dGxldEltcGwoKSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRjb25zdCBub25Sb3V0ZUNvbXBvbmVudCA9IFJlYWN0JDEudXNlQ29udGV4dChub25Sb3V0ZUNvbXBvbmVudENvbnRleHQpO1xuXHRcdGlmIChub25Sb3V0ZUNvbXBvbmVudCkgY29uc29sZS53YXJuKGBXYXJuaW5nOiBBbiA8T3V0bGV0IC8+IHdhcyByZW5kZXJlZCBpbnNpZGUgYSAke25vblJvdXRlQ29tcG9uZW50fS4gPE91dGxldCAvPiBzaG91bGQgb25seSBiZSByZW5kZXJlZCBpbnNpZGUgYSByb3V0ZSBjb21wb25lbnQuYCk7XG5cdH1cblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGNvbnN0IHJvdXRlSWQgPSBSZWFjdCQxLnVzZUNvbnRleHQobWF0Y2hDb250ZXh0KTtcblx0bGV0IHBhcmVudEdsb2JhbE5vdEZvdW5kO1xuXHRsZXQgcGFyZW50Tm90Rm91bmRFcnJvcjtcblx0bGV0IGNoaWxkUm91dGVJZDtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikge1xuXHRcdGNvbnN0IG1hdGNoZXMgPSByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCk7XG5cdFx0Y29uc3QgcGFyZW50SW5kZXggPSBtYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLnJvdXRlSWQgPT09IHJvdXRlSWQpO1xuXHRcdGNvbnN0IHBhcmVudE1hdGNoID0gbWF0Y2hlc1twYXJlbnRJbmRleF07XG5cdFx0cGFyZW50R2xvYmFsTm90Rm91bmQgPSAhIXBhcmVudE1hdGNoLl9ub3RGb3VuZDtcblx0XHRwYXJlbnROb3RGb3VuZEVycm9yID0gcGFyZW50TWF0Y2guZXJyb3I7XG5cdFx0Y2hpbGRSb3V0ZUlkID0gbWF0Y2hlc1twYXJlbnRJbmRleCArIDFdPy5yb3V0ZUlkO1xuXHR9IGVsc2Uge1xuXHRcdGNvbnN0IHBhcmVudE1hdGNoU3RvcmUgPSByb3V0ZXIuc3RvcmVzLmdldE1hdGNoU3RvcmUocm91dGVJZCk7XG5cdFx0W3BhcmVudEdsb2JhbE5vdEZvdW5kLCBwYXJlbnROb3RGb3VuZEVycm9yXSA9IHVzZVNlbGVjdG9yKHBhcmVudE1hdGNoU3RvcmUsIChtYXRjaCkgPT4gWyEhbWF0Y2guX25vdEZvdW5kLCBtYXRjaC5lcnJvcl0sIHsgY29tcGFyZTogb3V0bGV0TWF0Y2hTZWxlY3Rpb25FcXVhbCB9KTtcblx0XHRjaGlsZFJvdXRlSWQgPSB1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLmlkcywgKGlkcykgPT4ge1xuXHRcdFx0cmV0dXJuIGlkc1tpZHMuaW5kZXhPZihyb3V0ZUlkKSArIDFdO1xuXHRcdH0pO1xuXHR9XG5cdGlmIChwYXJlbnRHbG9iYWxOb3RGb3VuZCkgcmV0dXJuIHJlbmRlclJvdXRlTm90Rm91bmQocm91dGVyLCByb3V0ZXIucm91dGVzQnlJZFtyb3V0ZUlkXSwgcGFyZW50Tm90Rm91bmRFcnJvcik7XG5cdGlmICghY2hpbGRSb3V0ZUlkKSByZXR1cm4gbnVsbDtcblx0Y29uc3QgbmV4dE1hdGNoID0gLyogQF9fUFVSRV9fICovIGpzeChNYXRjaCwgeyByb3V0ZUlkOiBjaGlsZFJvdXRlSWQgfSk7XG5cdGlmIChyb3V0ZUlkID09PSByb290Um91dGVJZCkgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUmVhY3QkMS5TdXNwZW5zZSwge1xuXHRcdGZhbGxiYWNrOiByZW5kZXJQZW5kaW5nKHJvdXRlciksXG5cdFx0Y2hpbGRyZW46IG5leHRNYXRjaFxuXHR9KTtcblx0cmV0dXJuIG5leHRNYXRjaDtcbn0pO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBNYXRjaCwgTWF0Y2hJbm5lciwgT3V0bGV0LCByZW5kZXJQZW5kaW5nIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPU1hdGNoLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlTGF5b3V0RWZmZWN0IH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgZ2V0TG9jYXRpb25DaGFuZ2VJbmZvLCB0cmltUGF0aFJpZ2h0IH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbi8vI3JlZ2lvbiBzcmMvVHJhbnNpdGlvbmVyLnRzeFxuZnVuY3Rpb24gc2V0dGxlT3duZXIob3duZXIsIHJlbmRlcmVkKSB7XG5cdGNvbnN0IHNldHRsZSA9IG93bmVyWzFdO1xuXHRvd25lci5sZW5ndGggPSAwO1xuXHRzZXR0bGU/LihyZW5kZXJlZCk7XG59XG5mdW5jdGlvbiBUcmFuc2l0aW9uZXIoeyB0IH0pIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGNvbnN0IGFja25vd2xlZGdlbWVudCA9IHJvdXRlci5fcmVuZGVyZWQgPz89IFtdO1xuXHRjb25zdCBtb3VudGVkID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gUmVhY3QkMS51c2VSZWYoZmFsc2UpIDogdm9pZCAwO1xuXHRyb3V0ZXIuc3RhcnRUcmFuc2l0aW9uID0gKGZuLCBleHBlY3RlZCkgPT4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRzZXR0bGVPd25lcihhY2tub3dsZWRnZW1lbnQsIGZhbHNlKTtcblx0XHRhY2tub3dsZWRnZW1lbnQucHVzaChleHBlY3RlZCwgcmVzb2x2ZSk7XG5cdFx0dChyb3V0ZXIpO1xuXHRcdFJlYWN0JDEuc3RhcnRUcmFuc2l0aW9uKGZuKTtcblx0fSk7XG5cdHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG5cdFx0Y29uc3QgdW5zdWIgPSByb3V0ZXIuaGlzdG9yeS5zdWJzY3JpYmUocm91dGVyLmxvYWQpO1xuXHRcdGlmIChtb3VudGVkPy5jdXJyZW50KSByZXR1cm4gdW5zdWI7XG5cdFx0aWYgKG1vdW50ZWQpIG1vdW50ZWQuY3VycmVudCA9IHRydWU7XG5cdFx0cm91dGVyLnVwZGF0ZUxhdGVzdExvY2F0aW9uKCk7XG5cdFx0Y29uc3QgbG9jYXRpb24gPSByb3V0ZXIubGF0ZXN0TG9jYXRpb247XG5cdFx0Y29uc3QgbmV4dExvY2F0aW9uID0gcm91dGVyLmJ1aWxkTG9jYXRpb24oe1xuXHRcdFx0dG86IGxvY2F0aW9uLnBhdGhuYW1lLFxuXHRcdFx0c2VhcmNoOiB0cnVlLFxuXHRcdFx0cGFyYW1zOiB0cnVlLFxuXHRcdFx0aGFzaDogdHJ1ZSxcblx0XHRcdHN0YXRlOiB0cnVlLFxuXHRcdFx0X2luY2x1ZGVWYWxpZGF0ZVNlYXJjaDogdHJ1ZVxuXHRcdH0pO1xuXHRcdGlmICh0cmltUGF0aFJpZ2h0KGxvY2F0aW9uLnB1YmxpY0hyZWYpICE9PSB0cmltUGF0aFJpZ2h0KG5leHRMb2NhdGlvbi5wdWJsaWNIcmVmKSkge1xuXHRcdFx0cm91dGVyLmNvbW1pdExvY2F0aW9uKHtcblx0XHRcdFx0Li4ubmV4dExvY2F0aW9uLFxuXHRcdFx0XHRyZXBsYWNlOiB0cnVlLFxuXHRcdFx0XHRpZ25vcmVCbG9ja2VyOiB0cnVlXG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiB1bnN1Yjtcblx0XHR9XG5cdFx0Y29uc3QgcmVzb2x2ZWRMb2NhdGlvbiA9IHJvdXRlci5zdG9yZXMucmVzb2x2ZWRMb2NhdGlvbi5nZXQoKTtcblx0XHRpZiAocmVzb2x2ZWRMb2NhdGlvbj8uaHJlZiA9PT0gbG9jYXRpb24uaHJlZiAmJiByZXNvbHZlZExvY2F0aW9uLnN0YXRlLl9fVFNSX2tleSA9PT0gbG9jYXRpb24uc3RhdGUuX19UU1Jfa2V5KSBhY2tub3dsZWRnZW1lbnQucHVzaChyb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCksIChyZW5kZXJlZCkgPT4ge1xuXHRcdFx0aWYgKHJlbmRlcmVkKSByb3V0ZXIuZW1pdCh7XG5cdFx0XHRcdHR5cGU6IFwib25SZW5kZXJlZFwiLFxuXHRcdFx0XHQuLi5nZXRMb2NhdGlvbkNoYW5nZUluZm8ocmVzb2x2ZWRMb2NhdGlvbiwgcmVzb2x2ZWRMb2NhdGlvbilcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdGVsc2UgaWYgKCFyb3V0ZXIuX3R4KSByb3V0ZXIubG9hZCh7IHN5bmM6IHRydWUgfSkuY2F0Y2goY29uc29sZS5lcnJvcik7XG5cdFx0cmV0dXJuIHVuc3ViO1xuXHR9LCBbcm91dGVyLCByb3V0ZXIuaGlzdG9yeV0pO1xuXHRyZXR1cm4gbnVsbDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgVHJhbnNpdGlvbmVyLCBzZXR0bGVPd25lciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1UcmFuc2l0aW9uZXIuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VMYXlvdXRFZmZlY3QgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgQ2F0Y2hCb3VuZGFyeSB9IGZyb20gXCIuL0NhdGNoQm91bmRhcnkuanNcIjtcbmltcG9ydCB7IG1hdGNoQ29udGV4dCB9IGZyb20gXCIuL21hdGNoQ29udGV4dC5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VTdHJ1Y3R1cmFsU2hhcmluZyB9IGZyb20gXCIuL3VzZU1hdGNoLmpzXCI7XG5pbXBvcnQgeyBUcmFuc2l0aW9uZXIsIHNldHRsZU93bmVyIH0gZnJvbSBcIi4vVHJhbnNpdGlvbmVyLmpzXCI7XG5pbXBvcnQgeyBNYXRjaCwgcmVuZGVyUGVuZGluZyB9IGZyb20gXCIuL01hdGNoLmpzXCI7XG5pbXBvcnQgeyByb290Um91dGVJZCB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbmltcG9ydCB7IEZyYWdtZW50LCBqc3gsIGpzeHMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1zdG9yZVwiO1xuLy8jcmVnaW9uIHNyYy9NYXRjaGVzLnRzeFxuLyoqXG4qIEludGVybmFsIGNvbXBvbmVudCB0aGF0IHJlbmRlcnMgdGhlIHJvdXRlcidzIGFjdGl2ZSBtYXRjaCB0cmVlIHdpdGhcbiogc3VzcGVuc2UsIGVycm9yLCBhbmQgbm90LWZvdW5kIGJvdW5kYXJpZXMuIFJlbmRlcmVkIGJ5IGBSb3V0ZXJQcm92aWRlcmAuXG4qL1xuZnVuY3Rpb24gTWF0Y2hlcygpIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGNvbnN0IHJvb3RSb3V0ZSA9IHJvdXRlci5yb3V0ZXNCeUlkW3Jvb3RSb3V0ZUlkXTtcblx0Y29uc3QgcGVuZGluZ0VsZW1lbnQgPSByZW5kZXJQZW5kaW5nKHJvdXRlciwgcm9vdFJvdXRlKTtcblx0Y29uc3QgaW5uZXIgPSAvKiBAX19QVVJFX18gKi8ganN4cyhGcmFnbWVudCwgeyBjaGlsZHJlbjogWyEoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSAmJiAvKiBAX19QVVJFX18gKi8ganN4KFRyYW5zaXRpb25lciwgeyB0OiBSZWFjdCQxLnVzZVN0YXRlKClbMV0gfSksIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHx8IHJvdXRlci5zc3IgPyAvKiBAX19QVVJFX18gKi8ganN4KE1hdGNoZXNJbm5lciwge30pIDogLyogQF9fUFVSRV9fICovIGpzeChSZWFjdCQxLlN1c3BlbnNlLCB7XG5cdFx0ZmFsbGJhY2s6IHBlbmRpbmdFbGVtZW50LFxuXHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KE1hdGNoZXNJbm5lciwge30pXG5cdH0pXSB9KTtcblx0cmV0dXJuIHJvdXRlci5vcHRpb25zLklubmVyV3JhcCA/IC8qIEBfX1BVUkVfXyAqLyBqc3gocm91dGVyLm9wdGlvbnMuSW5uZXJXcmFwLCB7IGNoaWxkcmVuOiBpbm5lciB9KSA6IGlubmVyO1xufVxuZnVuY3Rpb24gTWF0Y2hlc0lubmVyKCkge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0Y29uc3QgYWNrbm93bGVkZ2VtZW50ID0gcm91dGVyLl9yZW5kZXJlZDtcblx0Y29uc3QgbWF0Y2hlcyA9IGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlciA/IHJvdXRlci5zdG9yZXMubWF0Y2hlcy5nZXQoKSA6IHVzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMubWF0Y2hlcywgKHZhbHVlKSA9PiBhY2tub3dsZWRnZW1lbnRbMF0gPz8gdmFsdWUpO1xuXHRjb25zdCBtYXRjaCA9IG1hdGNoZXNbMF07XG5cdGNvbnN0IHJvdXRlSWQgPSBtYXRjaD8ucm91dGVJZDtcblx0dXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcblx0XHRpZiAoYWNrbm93bGVkZ2VtZW50WzBdID09PSBtYXRjaGVzKSBzZXR0bGVPd25lcihhY2tub3dsZWRnZW1lbnQsIHRydWUpO1xuXHR9LCBbYWNrbm93bGVkZ2VtZW50LCBtYXRjaGVzXSk7XG5cdGNvbnN0IG1hdGNoQ29tcG9uZW50ID0gcm91dGVJZCA/IC8qIEBfX1BVUkVfXyAqLyBqc3goTWF0Y2gsIHsgcm91dGVJZCB9KSA6IG51bGw7XG5cdHJldHVybiByb3V0ZXIub3B0aW9ucy5kaXNhYmxlR2xvYmFsQ2F0Y2hCb3VuZGFyeSA/IG1hdGNoQ29tcG9uZW50IDogLyogQF9fUFVSRV9fICovIGpzeChDYXRjaEJvdW5kYXJ5LCB7XG5cdFx0Z2V0UmVzZXRLZXk6ICgpID0+IG1hdGNoLFxuXHRcdG9uQ2F0Y2g6IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IChlcnJvcikgPT4ge1xuXHRcdFx0Y29uc29sZS53YXJuKGBXYXJuaW5nOiBUaGUgZm9sbG93aW5nIGVycm9yIHdhc24ndCBjYXVnaHQgYnkgYW55IHJvdXRlISBBdCB0aGUgdmVyeSBsZWFzdCwgY29uc2lkZXIgc2V0dGluZyBhbiAnZXJyb3JDb21wb25lbnQnIGluIHlvdXIgUm9vdFJvdXRlIWApO1xuXHRcdFx0Y29uc29sZS53YXJuKFwiV2FybmluZzpcIiwgZXJyb3IpO1xuXHRcdH0gOiB2b2lkIDAsXG5cdFx0Y2hpbGRyZW46IG1hdGNoQ29tcG9uZW50XG5cdH0pO1xufVxuLyoqXG4qIENyZWF0ZSBhIG1hdGNoZXIgZnVuY3Rpb24gZm9yIHRlc3RpbmcgbG9jYXRpb25zIGFnYWluc3Qgcm91dGUgZGVmaW5pdGlvbnMuXG4qXG4qIFRoZSByZXR1cm5lZCBmdW5jdGlvbiBhY2NlcHRzIHN0YW5kYXJkIG5hdmlnYXRpb24gb3B0aW9ucyAoYHRvYCwgYHBhcmFtc2AsXG4qIGBzZWFyY2hgLCBldGMuKSBhbmQgcmV0dXJucyBlaXRoZXIgYGZhbHNlYCAobm8gbWF0Y2gpIG9yIHRoZSBtYXRjaGVkIHBhcmFtc1xuKiBvYmplY3Qgd2hlbiB0aGUgcm91dGUgbWF0Y2hlcyB0aGUgY3VycmVudCBvciBwZW5kaW5nIGxvY2F0aW9uLlxuKlxuKiBVc2VmdWwgZm9yIGNvbmRpdGlvbmFsIHJlbmRlcmluZyBhbmQgYWN0aXZlIFVJIHN0YXRlcyBiZWNhdXNlIGl0IHN1YnNjcmliZXNcbiogdGhlIGNvbXBvbmVudCB0byB0aGUgcm91dGVyIHN0YXRlIHVzZWQgZm9yIG1hdGNoaW5nLiBUaGUgcmV0dXJuZWQgZnVuY3Rpb24nc1xuKiBpZGVudGl0eSBjaGFuZ2VzIHdoZW4gdGhhdCBzdGF0ZSBjaGFuZ2VzLiBGb3IgaW1wZXJhdGl2ZSBjaGVja3MgaW4gZXZlbnRcbiogaGFuZGxlcnMsIGdldCB0aGUgcm91dGVyIHdpdGggYHVzZVJvdXRlcmAgYW5kIGNhbGwgYHJvdXRlci5tYXRjaFJvdXRlKC4uLilgXG4qIHRvIGF2b2lkIHRoYXQgc3Vic2NyaXB0aW9uLlxuKlxuKiBAcmV0dXJucyBBIGBtYXRjaFJvdXRlKG9wdGlvbnMpYCBmdW5jdGlvbiB0aGF0IHJldHVybnMgYGZhbHNlYCBvciBwYXJhbXMuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci91c2VNYXRjaFJvdXRlSG9va1xuKi9cbmZ1bmN0aW9uIHVzZU1hdGNoUm91dGUoKSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSByZXR1cm4gKG9wdHMpID0+IHtcblx0XHRjb25zdCB7IHBlbmRpbmcsIGNhc2VTZW5zaXRpdmUsIGZ1enp5LCBpbmNsdWRlU2VhcmNoLCAuLi5yZXN0IH0gPSBvcHRzO1xuXHRcdHJldHVybiByb3V0ZXIubWF0Y2hSb3V0ZShyZXN0LCB7XG5cdFx0XHRwZW5kaW5nLFxuXHRcdFx0Y2FzZVNlbnNpdGl2ZSxcblx0XHRcdGZ1enp5LFxuXHRcdFx0aW5jbHVkZVNlYXJjaFxuXHRcdH0pO1xuXHR9O1xuXHRyZXR1cm4gUmVhY3QkMS51c2VDYWxsYmFjaygob3B0cykgPT4ge1xuXHRcdGNvbnN0IHsgcGVuZGluZywgY2FzZVNlbnNpdGl2ZSwgZnV6enksIGluY2x1ZGVTZWFyY2gsIC4uLnJlc3QgfSA9IG9wdHM7XG5cdFx0cmV0dXJuIHJvdXRlci5tYXRjaFJvdXRlKHJlc3QsIHtcblx0XHRcdHBlbmRpbmcsXG5cdFx0XHRjYXNlU2Vuc2l0aXZlLFxuXHRcdFx0ZnV6enksXG5cdFx0XHRpbmNsdWRlU2VhcmNoXG5cdFx0fSk7XG5cdH0sIFtcblx0XHRyb3V0ZXIsXG5cdFx0dXNlU2VsZWN0b3Iocm91dGVyLnN0b3Jlcy5sb2NhdGlvbiwgKGxvY2F0aW9uKSA9PiBsb2NhdGlvbi5ocmVmKSxcblx0XHR1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24sIChsb2NhdGlvbikgPT4gbG9jYXRpb24/LmhyZWYpLFxuXHRcdHVzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMuc3RhdHVzKVxuXHRdKTtcbn1cbi8qKlxuKiBDb21wb25lbnQgdGhhdCBjb25kaXRpb25hbGx5IHJlbmRlcnMgaXRzIGNoaWxkcmVuIGJhc2VkIG9uIHdoZXRoZXIgYSByb3V0ZVxuKiBtYXRjaGVzIHRoZSBwcm92aWRlZCBgZnJvbWAvYHRvYCBvcHRpb25zLiBJZiBgY2hpbGRyZW5gIGlzIGEgZnVuY3Rpb24sIGl0XG4qIHJlY2VpdmVzIHRoZSBtYXRjaGVkIHBhcmFtcyBvYmplY3QuXG4qXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9tYXRjaFJvdXRlQ29tcG9uZW50XG4qL1xuZnVuY3Rpb24gTWF0Y2hSb3V0ZShwcm9wcykge1xuXHRjb25zdCBwYXJhbXMgPSB1c2VNYXRjaFJvdXRlKCkocHJvcHMpO1xuXHRpZiAodHlwZW9mIHByb3BzLmNoaWxkcmVuID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBwcm9wcy5jaGlsZHJlbihwYXJhbXMpO1xuXHRyZXR1cm4gcGFyYW1zID8gcHJvcHMuY2hpbGRyZW4gOiBudWxsO1xufVxuZnVuY3Rpb24gdXNlTWF0Y2hlcyhvcHRzKSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSB7XG5cdFx0Y29uc3QgbWF0Y2hlcyA9IHJvdXRlci5zdG9yZXMubWF0Y2hlcy5nZXQoKTtcblx0XHRyZXR1cm4gb3B0cz8uc2VsZWN0ID8gb3B0cy5zZWxlY3QobWF0Y2hlcykgOiBtYXRjaGVzO1xuXHR9XG5cdHJldHVybiB1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLm1hdGNoZXMsIHVzZVN0cnVjdHVyYWxTaGFyaW5nKG9wdHMsIHJvdXRlcikpO1xufVxuLyoqXG4qIFJlYWQgdGhlIHByZXNlbnRlZCByb3V0ZSBtYXRjaGVzIGFib3ZlIHRoZSBjdXJyZW50IG1hdGNoLCBvciBzZWxlY3QgYVxuKiBkZXJpdmVkIHZhbHVlIGZyb20gdGhlbS5cbiovXG5mdW5jdGlvbiB1c2VQYXJlbnRNYXRjaGVzKG9wdHMpIHtcblx0Y29uc3QgY29udGV4dFJvdXRlSWQgPSBSZWFjdCQxLnVzZUNvbnRleHQobWF0Y2hDb250ZXh0KTtcblx0cmV0dXJuIHVzZU1hdGNoZXMoe1xuXHRcdHNlbGVjdDogKG1hdGNoZXMpID0+IHtcblx0XHRcdG1hdGNoZXMgPSBtYXRjaGVzLnNsaWNlKDAsIG1hdGNoZXMuZmluZEluZGV4KChkKSA9PiBkLnJvdXRlSWQgPT09IGNvbnRleHRSb3V0ZUlkKSk7XG5cdFx0XHRyZXR1cm4gb3B0cz8uc2VsZWN0ID8gb3B0cy5zZWxlY3QobWF0Y2hlcykgOiBtYXRjaGVzO1xuXHRcdH0sXG5cdFx0c3RydWN0dXJhbFNoYXJpbmc6IG9wdHM/LnN0cnVjdHVyYWxTaGFyaW5nXG5cdH0pO1xufVxuLyoqXG4qIFJlYWQgdGhlIHByZXNlbnRlZCByb3V0ZSBtYXRjaGVzIGJlbG93IHRoZSBjdXJyZW50IG1hdGNoLCBvciBzZWxlY3QgYVxuKiBkZXJpdmVkIHZhbHVlIGZyb20gdGhlbS5cbiovXG5mdW5jdGlvbiB1c2VDaGlsZE1hdGNoZXMob3B0cykge1xuXHRjb25zdCBjb250ZXh0Um91dGVJZCA9IFJlYWN0JDEudXNlQ29udGV4dChtYXRjaENvbnRleHQpO1xuXHRyZXR1cm4gdXNlTWF0Y2hlcyh7XG5cdFx0c2VsZWN0OiAobWF0Y2hlcykgPT4ge1xuXHRcdFx0bWF0Y2hlcyA9IG1hdGNoZXMuc2xpY2UobWF0Y2hlcy5maW5kSW5kZXgoKGQpID0+IGQucm91dGVJZCA9PT0gY29udGV4dFJvdXRlSWQpICsgMSk7XG5cdFx0XHRyZXR1cm4gb3B0cz8uc2VsZWN0ID8gb3B0cy5zZWxlY3QobWF0Y2hlcykgOiBtYXRjaGVzO1xuXHRcdH0sXG5cdFx0c3RydWN0dXJhbFNoYXJpbmc6IG9wdHM/LnN0cnVjdHVyYWxTaGFyaW5nXG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBNYXRjaFJvdXRlLCBNYXRjaGVzLCB1c2VDaGlsZE1hdGNoZXMsIHVzZU1hdGNoUm91dGUsIHVzZU1hdGNoZXMsIHVzZVBhcmVudE1hdGNoZXMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9TWF0Y2hlcy5qcy5tYXAiLCJpbXBvcnQgeyBjcmVhdGVOb25SZWFjdGl2ZU11dGFibGVTdG9yZSwgY3JlYXRlTm9uUmVhY3RpdmVSZWFkb25seVN0b3JlIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyBiYXRjaCwgY3JlYXRlQXRvbSB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvcm91dGVyU3RvcmVzLnRzXG52YXIgZ2V0U3RvcmVGYWN0b3J5ID0gKG9wdHMpID0+IHtcblx0aWYgKGlzU2VydmVyID8/IG9wdHMuaXNTZXJ2ZXIpIHJldHVybiB7XG5cdFx0Y3JlYXRlTXV0YWJsZVN0b3JlOiBjcmVhdGVOb25SZWFjdGl2ZU11dGFibGVTdG9yZSxcblx0XHRjcmVhdGVSZWFkb25seVN0b3JlOiBjcmVhdGVOb25SZWFjdGl2ZVJlYWRvbmx5U3RvcmUsXG5cdFx0YmF0Y2g6IChmbikgPT4gZm4oKVxuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdGNyZWF0ZU11dGFibGVTdG9yZTogY3JlYXRlQXRvbSxcblx0XHRjcmVhdGVSZWFkb25seVN0b3JlOiBjcmVhdGVBdG9tLFxuXHRcdGJhdGNoXG5cdH07XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBnZXRTdG9yZUZhY3RvcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGVyU3RvcmVzLmpzLm1hcCIsImltcG9ydCB7IGdldFN0b3JlRmFjdG9yeSB9IGZyb20gXCIuL3JvdXRlclN0b3Jlcy5qc1wiO1xuaW1wb3J0IHsgUm91dGVyQ29yZSB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvcm91dGVyLnRzXG4vKipcbiogQ3JlYXRlcyBhIG5ldyBSb3V0ZXIgaW5zdGFuY2UgZm9yIFJlYWN0LlxuKlxuKiBQYXNzIHRoZSByZXR1cm5lZCByb3V0ZXIgdG8gYFJvdXRlclByb3ZpZGVyYCB0byBlbmFibGUgcm91dGluZy5cbiogTm90YWJsZSBvcHRpb25zOiBgcm91dGVUcmVlYCAoeW91ciByb3V0ZSBkZWZpbml0aW9ucykgYW5kIGBjb250ZXh0YFxuKiAocmVxdWlyZWQgaWYgdGhlIHJvb3Qgcm91dGUgd2FzIGNyZWF0ZWQgd2l0aCBgY3JlYXRlUm9vdFJvdXRlV2l0aENvbnRleHRgKS5cbipcbiogQHBhcmFtIG9wdGlvbnMgUm91dGVyIG9wdGlvbnMgdXNlZCB0byBjb25maWd1cmUgdGhlIHJvdXRlci5cbiogQHJldHVybnMgQSBSb3V0ZXIgaW5zdGFuY2UgdG8gYmUgcHJvdmlkZWQgdG8gYFJvdXRlclByb3ZpZGVyYC5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2NyZWF0ZVJvdXRlckZ1bmN0aW9uXG4qL1xudmFyIGNyZWF0ZVJvdXRlciA9IChvcHRpb25zKSA9PiB7XG5cdHJldHVybiBuZXcgUm91dGVyKG9wdGlvbnMpO1xufTtcbnZhciBSb3V0ZXIgPSBjbGFzcyBleHRlbmRzIFJvdXRlckNvcmUge1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIob3B0aW9ucywgZ2V0U3RvcmVGYWN0b3J5KTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUm91dGVyLCBjcmVhdGVSb3V0ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGVyLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgcm91dGVyQ29udGV4dCB9IGZyb20gXCIuL3JvdXRlckNvbnRleHQuanNcIjtcbmltcG9ydCB7IE1hdGNoZXMgfSBmcm9tIFwiLi9NYXRjaGVzLmpzXCI7XG5pbXBvcnQgeyBoYXNLZXlzIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0IFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9Sb3V0ZXJQcm92aWRlci50c3hcbi8qKlxuKiBMb3ctbGV2ZWwgcHJvdmlkZXIgdGhhdCBwbGFjZXMgdGhlIHJvdXRlciBpbnRvIFJlYWN0IGNvbnRleHQgYW5kIG9wdGlvbmFsbHlcbiogdXBkYXRlcyByb3V0ZXIgb3B0aW9ucyBmcm9tIHByb3BzLiBNb3N0IGFwcHMgc2hvdWxkIHVzZSBgUm91dGVyUHJvdmlkZXJgLlxuKi9cbmZ1bmN0aW9uIFJvdXRlckNvbnRleHRQcm92aWRlcih7IHJvdXRlciwgY2hpbGRyZW4sIC4uLnJlc3QgfSkge1xuXHRpZiAoaGFzS2V5cyhyZXN0KSkgcm91dGVyLnVwZGF0ZSh7XG5cdFx0Li4ucm91dGVyLm9wdGlvbnMsXG5cdFx0Li4ucmVzdCxcblx0XHRjb250ZXh0OiB7XG5cdFx0XHQuLi5yb3V0ZXIub3B0aW9ucy5jb250ZXh0LFxuXHRcdFx0Li4ucmVzdC5jb250ZXh0XG5cdFx0fVxuXHR9KTtcblx0Y29uc3QgcHJvdmlkZXIgPSAvKiBAX19QVVJFX18gKi8ganN4KHJvdXRlckNvbnRleHQuUHJvdmlkZXIsIHtcblx0XHR2YWx1ZTogcm91dGVyLFxuXHRcdGNoaWxkcmVuXG5cdH0pO1xuXHRpZiAocm91dGVyLm9wdGlvbnMuV3JhcCkgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3gocm91dGVyLm9wdGlvbnMuV3JhcCwgeyBjaGlsZHJlbjogcHJvdmlkZXIgfSk7XG5cdHJldHVybiBwcm92aWRlcjtcbn1cbi8qKlxuKiBSZW5kZXJzIHRoZSBjdXJyZW50IG1hdGNoIHByZXNlbnRhdGlvbiBhbmQgcHJvdmlkZXMgdGhlIHJvdXRlciB0byB0aGUgUmVhY3RcbiogdHJlZSB2aWEgY29udGV4dC5cbipcbiogQWNjZXB0cyBtdXRhYmxlIHJvdXRlciBvcHRpb25zIHZpYSBwcm9wcy4gQ29uZmlndXJlIGluaXRpYWxpemF0aW9uLW9ubHlcbiogb3B0aW9ucyB3aXRoIGBjcmVhdGVSb3V0ZXJgLlxuKlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvY3JlYXRlUm91dGVyRnVuY3Rpb25cbiovXG5mdW5jdGlvbiBSb3V0ZXJQcm92aWRlcih7IHJvdXRlciwgLi4ucmVzdCB9KSB7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFJvdXRlckNvbnRleHRQcm92aWRlciwge1xuXHRcdHJvdXRlcixcblx0XHQuLi5yZXN0LFxuXHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KE1hdGNoZXMsIHt9KVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUm91dGVyQ29udGV4dFByb3ZpZGVyLCBSb3V0ZXJQcm92aWRlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1Sb3V0ZXJQcm92aWRlci5qcy5tYXAiLCJpbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IGdldEVsZW1lbnRTY3JvbGxSZXN0b3JhdGlvbkVudHJ5LCBzZXR1cFNjcm9sbFJlc3RvcmF0aW9uIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuLy8jcmVnaW9uIHNyYy9TY3JvbGxSZXN0b3JhdGlvbi50c3hcbmZ1bmN0aW9uIHVzZVNjcm9sbFJlc3RvcmF0aW9uKCkge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0c2V0dXBTY3JvbGxSZXN0b3JhdGlvbihyb3V0ZXIsIHRydWUpO1xufVxuLyoqXG4qIEBkZXByZWNhdGVkIFVzZSB0aGUgYHNjcm9sbFJlc3RvcmF0aW9uYCByb3V0ZXIgb3B0aW9uIGluc3RlYWQuXG4qL1xuZnVuY3Rpb24gU2Nyb2xsUmVzdG9yYXRpb24oX3Byb3BzKSB7XG5cdHVzZVNjcm9sbFJlc3RvcmF0aW9uKCk7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJkZXZlbG9wbWVudFwiKSBjb25zb2xlLndhcm4oXCJUaGUgU2Nyb2xsUmVzdG9yYXRpb24gY29tcG9uZW50IGlzIGRlcHJlY2F0ZWQuIFVzZSBjcmVhdGVSb3V0ZXIncyBgc2Nyb2xsUmVzdG9yYXRpb25gIG9wdGlvbiBpbnN0ZWFkLlwiKTtcblx0cmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiB1c2VFbGVtZW50U2Nyb2xsUmVzdG9yYXRpb24ob3B0aW9ucykge1xuXHR1c2VTY3JvbGxSZXN0b3JhdGlvbigpO1xuXHRyZXR1cm4gZ2V0RWxlbWVudFNjcm9sbFJlc3RvcmF0aW9uRW50cnkodXNlUm91dGVyKCksIG9wdGlvbnMpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBTY3JvbGxSZXN0b3JhdGlvbiwgdXNlRWxlbWVudFNjcm9sbFJlc3RvcmF0aW9uIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVNjcm9sbFJlc3RvcmF0aW9uLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuLy8jcmVnaW9uIHNyYy91c2VCbG9ja2VyLnRzeFxuZnVuY3Rpb24gX3Jlc29sdmVCbG9ja2VyT3B0cyhvcHRzLCBjb25kaXRpb24pIHtcblx0aWYgKG9wdHMgPT09IHZvaWQgMCkgcmV0dXJuIHtcblx0XHRzaG91bGRCbG9ja0ZuOiAoKSA9PiB0cnVlLFxuXHRcdHdpdGhSZXNvbHZlcjogZmFsc2Vcblx0fTtcblx0aWYgKFwic2hvdWxkQmxvY2tGblwiIGluIG9wdHMpIHJldHVybiBvcHRzO1xuXHRpZiAodHlwZW9mIG9wdHMgPT09IFwiZnVuY3Rpb25cIikge1xuXHRcdGNvbnN0IHNob3VsZEJsb2NrID0gQm9vbGVhbihjb25kaXRpb24gPz8gdHJ1ZSk7XG5cdFx0Y29uc3QgX2N1c3RvbUJsb2NrZXJGbiA9IGFzeW5jICgpID0+IHtcblx0XHRcdGlmIChzaG91bGRCbG9jaykgcmV0dXJuIGF3YWl0IG9wdHMoKTtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9O1xuXHRcdHJldHVybiB7XG5cdFx0XHRzaG91bGRCbG9ja0ZuOiBfY3VzdG9tQmxvY2tlckZuLFxuXHRcdFx0ZW5hYmxlQmVmb3JlVW5sb2FkOiBzaG91bGRCbG9jayxcblx0XHRcdHdpdGhSZXNvbHZlcjogZmFsc2Vcblx0XHR9O1xuXHR9XG5cdGNvbnN0IHNob3VsZEJsb2NrID0gQm9vbGVhbihvcHRzLmNvbmRpdGlvbiA/PyB0cnVlKTtcblx0Y29uc3QgZm4gPSBvcHRzLmJsb2NrZXJGbjtcblx0Y29uc3QgX2N1c3RvbUJsb2NrZXJGbiA9IGFzeW5jICgpID0+IHtcblx0XHRpZiAoc2hvdWxkQmxvY2sgJiYgZm4gIT09IHZvaWQgMCkgcmV0dXJuIGF3YWl0IGZuKCk7XG5cdFx0cmV0dXJuIHNob3VsZEJsb2NrO1xuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdHNob3VsZEJsb2NrRm46IF9jdXN0b21CbG9ja2VyRm4sXG5cdFx0ZW5hYmxlQmVmb3JlVW5sb2FkOiBzaG91bGRCbG9jayxcblx0XHR3aXRoUmVzb2x2ZXI6IGZuID09PSB2b2lkIDBcblx0fTtcbn1cbmZ1bmN0aW9uIHVzZUJsb2NrZXIob3B0cywgY29uZGl0aW9uKSB7XG5cdGNvbnN0IHsgc2hvdWxkQmxvY2tGbiwgZW5hYmxlQmVmb3JlVW5sb2FkID0gdHJ1ZSwgZGlzYWJsZWQgPSBmYWxzZSwgd2l0aFJlc29sdmVyID0gZmFsc2UgfSA9IF9yZXNvbHZlQmxvY2tlck9wdHMob3B0cywgY29uZGl0aW9uKTtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGNvbnN0IHsgaGlzdG9yeSB9ID0gcm91dGVyO1xuXHRjb25zdCBbcmVzb2x2ZXIsIHNldFJlc29sdmVyXSA9IFJlYWN0JDEudXNlU3RhdGUoe1xuXHRcdHN0YXR1czogXCJpZGxlXCIsXG5cdFx0Y3VycmVudDogdm9pZCAwLFxuXHRcdG5leHQ6IHZvaWQgMCxcblx0XHRhY3Rpb246IHZvaWQgMCxcblx0XHRwcm9jZWVkOiB2b2lkIDAsXG5cdFx0cmVzZXQ6IHZvaWQgMFxuXHR9KTtcblx0UmVhY3QkMS51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGNvbnN0IGJsb2NrZXJGbkNvbXBvc2VkID0gYXN5bmMgKGJsb2NrZXJGbkFyZ3MpID0+IHtcblx0XHRcdGZ1bmN0aW9uIGdldExvY2F0aW9uKGxvY2F0aW9uKSB7XG5cdFx0XHRcdGNvbnN0IHBhcnNlZExvY2F0aW9uID0gcm91dGVyLnBhcnNlTG9jYXRpb24obG9jYXRpb24pO1xuXHRcdFx0XHRjb25zdCBbLCByYXdQYXJhbXMsIGZvdW5kUm91dGVdID0gcm91dGVyLmdldE1hdGNoZWRSb3V0ZXMocGFyc2VkTG9jYXRpb24ucGF0aG5hbWUpO1xuXHRcdFx0XHRpZiAoZm91bmRSb3V0ZSA9PT0gdm9pZCAwKSByZXR1cm4ge1xuXHRcdFx0XHRcdHJvdXRlSWQ6IFwiX19ub3RGb3VuZF9fXCIsXG5cdFx0XHRcdFx0ZnVsbFBhdGg6IHBhcnNlZExvY2F0aW9uLnBhdGhuYW1lLFxuXHRcdFx0XHRcdHBhdGhuYW1lOiBwYXJzZWRMb2NhdGlvbi5wYXRobmFtZSxcblx0XHRcdFx0XHRwYXJhbXM6IHJhd1BhcmFtcyxcblx0XHRcdFx0XHRzZWFyY2g6IHJvdXRlci5vcHRpb25zLnBhcnNlU2VhcmNoKGxvY2F0aW9uLnNlYXJjaClcblx0XHRcdFx0fTtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRyb3V0ZUlkOiBmb3VuZFJvdXRlLmlkLFxuXHRcdFx0XHRcdGZ1bGxQYXRoOiBmb3VuZFJvdXRlLmZ1bGxQYXRoLFxuXHRcdFx0XHRcdHBhdGhuYW1lOiBwYXJzZWRMb2NhdGlvbi5wYXRobmFtZSxcblx0XHRcdFx0XHRwYXJhbXM6IHJhd1BhcmFtcyxcblx0XHRcdFx0XHRzZWFyY2g6IHJvdXRlci5vcHRpb25zLnBhcnNlU2VhcmNoKGxvY2F0aW9uLnNlYXJjaClcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGN1cnJlbnQgPSBnZXRMb2NhdGlvbihibG9ja2VyRm5BcmdzLmN1cnJlbnRMb2NhdGlvbik7XG5cdFx0XHRjb25zdCBuZXh0ID0gZ2V0TG9jYXRpb24oYmxvY2tlckZuQXJncy5uZXh0TG9jYXRpb24pO1xuXHRcdFx0aWYgKGN1cnJlbnQucm91dGVJZCA9PT0gXCJfX25vdEZvdW5kX19cIiAmJiBuZXh0LnJvdXRlSWQgIT09IFwiX19ub3RGb3VuZF9fXCIpIHJldHVybiBmYWxzZTtcblx0XHRcdGNvbnN0IHNob3VsZEJsb2NrID0gYXdhaXQgc2hvdWxkQmxvY2tGbih7XG5cdFx0XHRcdGFjdGlvbjogYmxvY2tlckZuQXJncy5hY3Rpb24sXG5cdFx0XHRcdGN1cnJlbnQsXG5cdFx0XHRcdG5leHRcblx0XHRcdH0pO1xuXHRcdFx0aWYgKCF3aXRoUmVzb2x2ZXIpIHJldHVybiBzaG91bGRCbG9jaztcblx0XHRcdGlmICghc2hvdWxkQmxvY2spIHJldHVybiBmYWxzZTtcblx0XHRcdGNvbnN0IGNhbk5hdmlnYXRlQXN5bmMgPSBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdFx0XHRzZXRSZXNvbHZlcih7XG5cdFx0XHRcdFx0c3RhdHVzOiBcImJsb2NrZWRcIixcblx0XHRcdFx0XHRjdXJyZW50LFxuXHRcdFx0XHRcdG5leHQsXG5cdFx0XHRcdFx0YWN0aW9uOiBibG9ja2VyRm5BcmdzLmFjdGlvbixcblx0XHRcdFx0XHRwcm9jZWVkOiAoKSA9PiByZXNvbHZlKGZhbHNlKSxcblx0XHRcdFx0XHRyZXNldDogKCkgPT4gcmVzb2x2ZSh0cnVlKVxuXHRcdFx0XHR9KTtcblx0XHRcdH0pO1xuXHRcdFx0c2V0UmVzb2x2ZXIoe1xuXHRcdFx0XHRzdGF0dXM6IFwiaWRsZVwiLFxuXHRcdFx0XHRjdXJyZW50OiB2b2lkIDAsXG5cdFx0XHRcdG5leHQ6IHZvaWQgMCxcblx0XHRcdFx0YWN0aW9uOiB2b2lkIDAsXG5cdFx0XHRcdHByb2NlZWQ6IHZvaWQgMCxcblx0XHRcdFx0cmVzZXQ6IHZvaWQgMFxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gY2FuTmF2aWdhdGVBc3luYztcblx0XHR9O1xuXHRcdHJldHVybiBkaXNhYmxlZCA/IHZvaWQgMCA6IGhpc3RvcnkuYmxvY2soe1xuXHRcdFx0YmxvY2tlckZuOiBibG9ja2VyRm5Db21wb3NlZCxcblx0XHRcdGVuYWJsZUJlZm9yZVVubG9hZFxuXHRcdH0pO1xuXHR9LCBbXG5cdFx0c2hvdWxkQmxvY2tGbixcblx0XHRlbmFibGVCZWZvcmVVbmxvYWQsXG5cdFx0ZGlzYWJsZWQsXG5cdFx0d2l0aFJlc29sdmVyLFxuXHRcdGhpc3RvcnksXG5cdFx0cm91dGVyXG5cdF0pO1xuXHRyZXR1cm4gcmVzb2x2ZXI7XG59XG52YXIgX3Jlc29sdmVQcm9tcHRCbG9ja2VyQXJncyA9IChwcm9wcykgPT4ge1xuXHRpZiAoXCJzaG91bGRCbG9ja0ZuXCIgaW4gcHJvcHMpIHJldHVybiB7IC4uLnByb3BzIH07XG5cdGNvbnN0IHNob3VsZEJsb2NrID0gQm9vbGVhbihwcm9wcy5jb25kaXRpb24gPz8gdHJ1ZSk7XG5cdGNvbnN0IGZuID0gcHJvcHMuYmxvY2tlckZuO1xuXHRjb25zdCBfY3VzdG9tQmxvY2tlckZuID0gYXN5bmMgKCkgPT4ge1xuXHRcdGlmIChzaG91bGRCbG9jayAmJiBmbiAhPT0gdm9pZCAwKSByZXR1cm4gYXdhaXQgZm4oKTtcblx0XHRyZXR1cm4gc2hvdWxkQmxvY2s7XG5cdH07XG5cdHJldHVybiB7XG5cdFx0c2hvdWxkQmxvY2tGbjogX2N1c3RvbUJsb2NrZXJGbixcblx0XHRlbmFibGVCZWZvcmVVbmxvYWQ6IHNob3VsZEJsb2NrLFxuXHRcdHdpdGhSZXNvbHZlcjogZm4gPT09IHZvaWQgMFxuXHR9O1xufTtcbmZ1bmN0aW9uIEJsb2NrKG9wdHMpIHtcblx0Y29uc3QgeyBjaGlsZHJlbiwgLi4ucmVzdCB9ID0gb3B0cztcblx0Y29uc3QgcmVzb2x2ZXIgPSB1c2VCbG9ja2VyKF9yZXNvbHZlUHJvbXB0QmxvY2tlckFyZ3MocmVzdCkpO1xuXHRyZXR1cm4gY2hpbGRyZW4gPyB0eXBlb2YgY2hpbGRyZW4gPT09IFwiZnVuY3Rpb25cIiA/IGNoaWxkcmVuKHJlc29sdmVyKSA6IGNoaWxkcmVuIDogbnVsbDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgQmxvY2ssIHVzZUJsb2NrZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlQmxvY2tlci5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgdXNlU3RydWN0dXJhbFNoYXJpbmcgfSBmcm9tIFwiLi91c2VNYXRjaC5qc1wiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlUm91dGVyU3RhdGUudHN4XG4vKipcbiogU3Vic2NyaWJlIHRvIHRoZSByb3V0ZXIncyBzdGF0ZSBzdG9yZSB3aXRoIG9wdGlvbmFsIHNlbGVjdGlvbiBhbmRcbiogc3RydWN0dXJhbCBzaGFyaW5nIGZvciByZW5kZXIgb3B0aW1pemF0aW9uLlxuKlxuKiBPcHRpb25zOlxuKiAtIGBzZWxlY3RgOiBQcm9qZWN0IHRoZSBmdWxsIHJvdXRlciBzdGF0ZSB0byBhIGRlcml2ZWQgc2xpY2VcbiogLSBgc3RydWN0dXJhbFNoYXJpbmdgOiBSZXBsYWNlLWVxdWFsIHNlbWFudGljcyBmb3Igc3RhYmxlIHJlZmVyZW5jZXNcbiogLSBgcm91dGVyYDogUmVhZCBzdGF0ZSBmcm9tIGEgc3BlY2lmaWMgcm91dGVyIGluc3RhbmNlIGluc3RlYWQgb2YgY29udGV4dFxuKlxuKiBAcmV0dXJucyBUaGUgc2VsZWN0ZWQgcm91dGVyIHN0YXRlIChvciB0aGUgZnVsbCBzdGF0ZSBieSBkZWZhdWx0KS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3VzZVJvdXRlclN0YXRlSG9va1xuKi9cbmZ1bmN0aW9uIHVzZVJvdXRlclN0YXRlKG9wdHMpIHtcblx0Y29uc3QgY29udGV4dFJvdXRlciA9IHVzZVJvdXRlcih7IHdhcm46IG9wdHM/LnJvdXRlciA9PT0gdm9pZCAwIH0pO1xuXHRjb25zdCByb3V0ZXIgPSBvcHRzPy5yb3V0ZXIgfHwgY29udGV4dFJvdXRlcjtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikge1xuXHRcdGNvbnN0IHN0YXRlID0gcm91dGVyLnN0b3Jlcy5fX3N0b3JlLmdldCgpO1xuXHRcdHJldHVybiBvcHRzPy5zZWxlY3QgPyBvcHRzLnNlbGVjdChzdGF0ZSkgOiBzdGF0ZTtcblx0fVxuXHRyZXR1cm4gdXNlU2VsZWN0b3Iocm91dGVyLnN0b3Jlcy5fX3N0b3JlLCB1c2VTdHJ1Y3R1cmFsU2hhcmluZyhvcHRzLCByb3V0ZXIpKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlUm91dGVyU3RhdGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlUm91dGVyU3RhdGUuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IHVzZVN0cnVjdHVyYWxTaGFyaW5nIH0gZnJvbSBcIi4vdXNlTWF0Y2guanNcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuaW1wb3J0IHsgdXNlU2VsZWN0b3IgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXN0b3JlXCI7XG4vLyNyZWdpb24gc3JjL3VzZUxvY2F0aW9uLnRzeFxuLyoqXG4qIFJlYWQgdGhlIGN1cnJlbnQgbG9jYXRpb24gZnJvbSB0aGUgcm91dGVyIHN0YXRlIHdpdGggb3B0aW9uYWwgc2VsZWN0aW9uLlxuKiBVc2VmdWwgZm9yIHN1YnNjcmliaW5nIHRvIGp1c3QgdGhlIHBpZWNlcyBvZiBsb2NhdGlvbiB5b3UgY2FyZSBhYm91dC5cbipcbiogT3B0aW9uczpcbiogLSBgc2VsZWN0YDogUHJvamVjdCB0aGUgYGxvY2F0aW9uYCBvYmplY3QgdG8gYSBkZXJpdmVkIHZhbHVlXG4qIC0gYHN0cnVjdHVyYWxTaGFyaW5nYDogRW5hYmxlIHN0cnVjdHVyYWwgc2hhcmluZyBmb3Igc3RhYmxlIHJlZmVyZW5jZXNcbipcbiogQHJldHVybnMgVGhlIGN1cnJlbnQgbG9jYXRpb24gKG9yIHNlbGVjdGVkIHZhbHVlKS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3VzZUxvY2F0aW9uSG9va1xuKi9cbmZ1bmN0aW9uIHVzZUxvY2F0aW9uKG9wdHMpIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHtcblx0XHRjb25zdCBsb2NhdGlvbiA9IHJvdXRlci5zdG9yZXMubG9jYXRpb24uZ2V0KCk7XG5cdFx0cmV0dXJuIG9wdHM/LnNlbGVjdCA/IG9wdHMuc2VsZWN0KGxvY2F0aW9uKSA6IGxvY2F0aW9uO1xuXHR9XG5cdHJldHVybiB1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLCB1c2VTdHJ1Y3R1cmFsU2hhcmluZyhvcHRzLCByb3V0ZXIpKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlTG9jYXRpb24gfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlTG9jYXRpb24uanMubWFwIiwiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbmltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1zdG9yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VDYW5Hb0JhY2sudHNcbmZ1bmN0aW9uIHVzZUNhbkdvQmFjaygpIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHJldHVybiByb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLmdldCgpLnN0YXRlLl9fVFNSX2luZGV4ICE9PSAwO1xuXHRyZXR1cm4gdXNlU2VsZWN0b3Iocm91dGVyLnN0b3Jlcy5sb2NhdGlvbiwgKGxvY2F0aW9uKSA9PiBsb2NhdGlvbi5zdGF0ZS5fX1RTUl9pbmRleCAhPT0gMCk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZUNhbkdvQmFjayB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VDYW5Hb0JhY2suanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VIeWRyYXRlZCB9IGZyb20gXCIuL0NsaWVudE9ubHkuanNcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL0Fzc2V0LnRzeFxudmFyIElOTElORV9DU1NfSFlEUkFUSU9OX0FUVFIgPSBcImRhdGEtdHNyLWlubGluZS1jc3NcIjtcbnZhciBub29wU2NyaXB0SGFuZGxlciA9ICgpID0+IHt9O1xuZnVuY3Rpb24gc2V0U2NyaXB0QXR0cnMoc2NyaXB0LCBhdHRycykge1xuXHRpZiAoIWF0dHJzKSByZXR1cm47XG5cdGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGF0dHJzKSkgaWYgKGtleSAhPT0gXCJzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmdcIiAmJiB2YWx1ZSAhPT0gdm9pZCAwICYmIHZhbHVlICE9PSBmYWxzZSkgc2NyaXB0LnNldEF0dHJpYnV0ZShrZXksIHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgPyBcIlwiIDogU3RyaW5nKHZhbHVlKSk7XG59XG5mdW5jdGlvbiBBc3NldChhc3NldCkge1xuXHRjb25zdCB7IGF0dHJzLCBjaGlsZHJlbiwgbm9uY2UsIHByZXZlbnRTY3JpcHRIb2lzdCB9ID0gYXNzZXQ7XG5cdGNvbnN0IGlubmVySFRNTCA9IFJlYWN0JDEudXNlTWVtbygoKSA9PiBjaGlsZHJlbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogeyBfX2h0bWw6IGNoaWxkcmVuIH0sIFtjaGlsZHJlbl0pO1xuXHRzd2l0Y2ggKGFzc2V0LnRhZykge1xuXHRcdGNhc2UgXCJ0aXRsZVwiOiByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcInRpdGxlXCIsIHtcblx0XHRcdC4uLmF0dHJzLFxuXHRcdFx0c3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlLFxuXHRcdFx0Y2hpbGRyZW5cblx0XHR9KTtcblx0XHRjYXNlIFwibWV0YVwiOiByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcIm1ldGFcIiwge1xuXHRcdFx0Li4uYXR0cnMsXG5cdFx0XHRzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWVcblx0XHR9KTtcblx0XHRjYXNlIFwibGlua1wiOiByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcImxpbmtcIiwge1xuXHRcdFx0Li4uYXR0cnMsXG5cdFx0XHRwcmVjZWRlbmNlOiBhdHRycz8ucHJlY2VkZW5jZSA/PyAoYXR0cnM/LnJlbCA9PT0gXCJzdHlsZXNoZWV0XCIgPyBcImRlZmF1bHRcIiA6IHZvaWQgMCksXG5cdFx0XHRub25jZSxcblx0XHRcdHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZVxuXHRcdH0pO1xuXHRcdGNhc2UgXCJzdHlsZVwiOlxuXHRcdFx0aWYgKGFzc2V0LmlubGluZUNzcyAmJiAocHJvY2Vzcy5lbnYuVFNTX0lOTElORV9DU1NfRU5BQkxFRCA9PT0gXCJ0cnVlXCIgfHwgcHJvY2Vzcy5lbnYuVFNTX0lOTElORV9DU1NfRU5BQkxFRCA9PT0gdm9pZCAwICYmIGlzU2VydmVyKSkgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goSW5saW5lQ3NzU3R5bGUsIHtcblx0XHRcdFx0YXR0cnMsXG5cdFx0XHRcdG5vbmNlLFxuXHRcdFx0XHRjaGlsZHJlblxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcInN0eWxlXCIsIHtcblx0XHRcdFx0Li4uYXR0cnMsXG5cdFx0XHRcdGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MOiBpbm5lckhUTUwsXG5cdFx0XHRcdG5vbmNlXG5cdFx0XHR9KTtcblx0XHRjYXNlIFwic2NyaXB0XCI6IHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFNjcmlwdCwge1xuXHRcdFx0YXR0cnMsXG5cdFx0XHRwcmV2ZW50U2NyaXB0SG9pc3QsXG5cdFx0XHRjaGlsZHJlblxuXHRcdH0pO1xuXHRcdGRlZmF1bHQ6IHJldHVybiBudWxsO1xuXHR9XG59XG5mdW5jdGlvbiBJbmxpbmVDc3NTdHlsZSh7IGF0dHJzLCBjaGlsZHJlbiwgbm9uY2UgfSkge1xuXHRjb25zdCBpc0lubGluZUNzc1BsYWNlaG9sZGVyID0gY2hpbGRyZW4gPT09IHZvaWQgMDtcblx0Y29uc3QgW2h5ZHJhdGVkSW5saW5lQ3NzXSA9IFJlYWN0JDEudXNlU3RhdGUoKCkgPT4ge1xuXHRcdGlmICghaXNJbmxpbmVDc3NQbGFjZWhvbGRlciB8fCB0eXBlb2YgZG9jdW1lbnQgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybjtcblx0XHRyZXR1cm4gZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihgc3R5bGVbJHtJTkxJTkVfQ1NTX0hZRFJBVElPTl9BVFRSfV1gKT8udGV4dENvbnRlbnQgPz8gdm9pZCAwO1xuXHR9KTtcblx0Y29uc3QgaHRtbCA9IGlzSW5saW5lQ3NzUGxhY2Vob2xkZXIgPyBoeWRyYXRlZElubGluZUNzcyA/PyBcIlwiIDogY2hpbGRyZW4gPz8gXCJcIjtcblx0Y29uc3QgaW5uZXJIVE1MID0gUmVhY3QkMS51c2VNZW1vKCgpID0+ICh7IF9faHRtbDogaHRtbCB9KSwgW2h0bWxdKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJzdHlsZVwiLCB7XG5cdFx0Li4uYXR0cnMsXG5cdFx0W0lOTElORV9DU1NfSFlEUkFUSU9OX0FUVFJdOiBcIlwiLFxuXHRcdGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MOiBpbm5lckhUTUwsXG5cdFx0bm9uY2UsXG5cdFx0c3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlXG5cdH0pO1xufVxuZnVuY3Rpb24gU2NyaXB0KHsgYXR0cnMsIGNoaWxkcmVuLCBwcmV2ZW50U2NyaXB0SG9pc3QgfSkge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0Y29uc3QgaHlkcmF0ZWQgPSB1c2VIeWRyYXRlZCgpO1xuXHRjb25zdCBpbm5lckhUTUwgPSBSZWFjdCQxLnVzZU1lbW8oKCkgPT4gY2hpbGRyZW4gPT09IHZvaWQgMCA/IHZvaWQgMCA6IHsgX19odG1sOiBjaGlsZHJlbiB9LCBbY2hpbGRyZW5dKTtcblx0Y29uc3QgZGF0YVNjcmlwdCA9IHR5cGVvZiBhdHRycz8udHlwZSA9PT0gXCJzdHJpbmdcIiAmJiBhdHRycy50eXBlICE9PSBcIlwiICYmIGF0dHJzLnR5cGUgIT09IFwidGV4dC9qYXZhc2NyaXB0XCIgJiYgYXR0cnMudHlwZSAhPT0gXCJtb2R1bGVcIjtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBhdHRycz8uc3JjICYmIHR5cGVvZiBjaGlsZHJlbiA9PT0gXCJzdHJpbmdcIiAmJiBjaGlsZHJlbi50cmltKCkubGVuZ3RoKSBjb25zb2xlLndhcm4oXCJbVGFuU3RhY2sgUm91dGVyXSA8U2NyaXB0PiByZWNlaXZlZCBib3RoIGBzcmNgIGFuZCBgY2hpbGRyZW5gLiBUaGUgYGNoaWxkcmVuYCBjb250ZW50IHdpbGwgYmUgaWdub3JlZC4gUmVtb3ZlIGBjaGlsZHJlbmAgb3IgcmVtb3ZlIGBzcmNgLlwiKTtcblx0UmVhY3QkMS51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGlmIChkYXRhU2NyaXB0KSByZXR1cm47XG5cdFx0aWYgKGF0dHJzPy5zcmMpIHtcblx0XHRcdGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYVwiKTtcblx0XHRcdGxpbmsuaHJlZiA9IGF0dHJzLnNyYztcblx0XHRcdGNvbnN0IG5vcm1TcmMgPSBsaW5rLmhyZWY7XG5cdFx0XHRmb3IgKGNvbnN0IGVsIG9mIGRvY3VtZW50LnNjcmlwdHMpIGlmIChlbC5zcmMgPT09IG5vcm1TcmMpIHJldHVybjtcblx0XHRcdGNvbnN0IHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzY3JpcHRcIik7XG5cdFx0XHRzZXRTY3JpcHRBdHRycyhzY3JpcHQsIGF0dHJzKTtcblx0XHRcdGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoc2NyaXB0KTtcblx0XHRcdHJldHVybiAoKSA9PiBzY3JpcHQucmVtb3ZlKCk7XG5cdFx0fVxuXHRcdGlmICh0eXBlb2YgY2hpbGRyZW4gPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdGNvbnN0IHR5cGVBdHRyID0gdHlwZW9mIGF0dHJzPy50eXBlID09PSBcInN0cmluZ1wiID8gYXR0cnMudHlwZSA6IFwidGV4dC9qYXZhc2NyaXB0XCI7XG5cdFx0XHRjb25zdCBub25jZUF0dHIgPSB0eXBlb2YgYXR0cnM/Lm5vbmNlID09PSBcInN0cmluZ1wiID8gYXR0cnMubm9uY2UgOiB2b2lkIDA7XG5cdFx0XHRmb3IgKGNvbnN0IGVsIG9mIGRvY3VtZW50LnNjcmlwdHMpIHtcblx0XHRcdFx0aWYgKGVsLmhhc0F0dHJpYnV0ZShcInNyY1wiKSkgY29udGludWU7XG5cdFx0XHRcdGNvbnN0IHNUeXBlID0gZWwuZ2V0QXR0cmlidXRlKFwidHlwZVwiKSA/PyBcInRleHQvamF2YXNjcmlwdFwiO1xuXHRcdFx0XHRjb25zdCBzTm9uY2UgPSBlbC5nZXRBdHRyaWJ1dGUoXCJub25jZVwiKSA/PyB2b2lkIDA7XG5cdFx0XHRcdGlmIChlbC50ZXh0Q29udGVudCA9PT0gY2hpbGRyZW4gJiYgc1R5cGUgPT09IHR5cGVBdHRyICYmIHNOb25jZSA9PT0gbm9uY2VBdHRyKSByZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIpO1xuXHRcdFx0c2NyaXB0LnRleHRDb250ZW50ID0gY2hpbGRyZW47XG5cdFx0XHRzZXRTY3JpcHRBdHRycyhzY3JpcHQsIGF0dHJzKTtcblx0XHRcdGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoc2NyaXB0KTtcblx0XHRcdHJldHVybiAoKSA9PiBzY3JpcHQucmVtb3ZlKCk7XG5cdFx0fVxuXHR9LCBbXG5cdFx0YXR0cnMsXG5cdFx0Y2hpbGRyZW4sXG5cdFx0ZGF0YVNjcmlwdFxuXHRdKTtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikge1xuXHRcdGlmIChhdHRycz8uc3JjKSB7XG5cdFx0XHRpZiAoIXByZXZlbnRTY3JpcHRIb2lzdCkgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJzY3JpcHRcIiwge1xuXHRcdFx0XHQuLi5hdHRycyxcblx0XHRcdFx0c3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlXG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwic2NyaXB0XCIsIHtcblx0XHRcdFx0Li4uYXR0cnMsXG5cdFx0XHRcdG9uTG9hZDogbm9vcFNjcmlwdEhhbmRsZXIsXG5cdFx0XHRcdHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdGlmICh0eXBlb2YgY2hpbGRyZW4gPT09IFwic3RyaW5nXCIpIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwic2NyaXB0XCIsIHtcblx0XHRcdC4uLmF0dHJzLFxuXHRcdFx0ZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw6IGlubmVySFRNTCxcblx0XHRcdHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZVxuXHRcdH0pO1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdGlmIChkYXRhU2NyaXB0ICYmIHR5cGVvZiBjaGlsZHJlbiA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJzY3JpcHRcIiwge1xuXHRcdC4uLmF0dHJzLFxuXHRcdHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZSxcblx0XHRkYW5nZXJvdXNseVNldElubmVySFRNTDogaW5uZXJIVE1MXG5cdH0pO1xuXHRpZiAoIWh5ZHJhdGVkKSB7XG5cdFx0aWYgKGF0dHJzPy5zcmMpIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwic2NyaXB0XCIsIHtcblx0XHRcdC4uLmF0dHJzLFxuXHRcdFx0c3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlXG5cdFx0fSk7XG5cdFx0aWYgKHR5cGVvZiBjaGlsZHJlbiA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJzY3JpcHRcIiwge1xuXHRcdFx0Li4uYXR0cnMsXG5cdFx0XHRkYW5nZXJvdXNseVNldElubmVySFRNTDogaW5uZXJIVE1MLFxuXHRcdFx0c3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlXG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIG51bGw7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEFzc2V0IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUFzc2V0LmpzLm1hcCIsImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgX2dldEFzc2V0TWF0Y2hlcywgYXBwZW5kVW5pcXVlVXNlclRhZ3MsIGRlZXBFcXVhbCwgZXNjYXBlSHRtbCwgZ2V0QXNzZXRDcm9zc09yaWdpbiwgZ2V0U2NyaXB0UHJlbG9hZEF0dHJzLCByZXNvbHZlTWFuaWZlc3RDc3NMaW5rIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuaW1wb3J0IHsgdXNlU2VsZWN0b3IgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXN0b3JlXCI7XG4vLyNyZWdpb24gc3JjL2hlYWRDb250ZW50VXRpbHMudHN4XG5mdW5jdGlvbiBidWlsZFRhZ3NGcm9tTWF0Y2hlcyhyb3V0ZXIsIG5vbmNlLCBtYXRjaGVzLCBhc3NldENyb3NzT3JpZ2luKSB7XG5cdG1hdGNoZXMgPSBfZ2V0QXNzZXRNYXRjaGVzKG1hdGNoZXMpO1xuXHRjb25zdCByb3V0ZU1ldGEgPSBtYXRjaGVzLm1hcCgobWF0Y2gpID0+IG1hdGNoLm1ldGEpLmZpbHRlcigobWV0YSkgPT4gbWV0YSAhPT0gdm9pZCAwKTtcblx0Y29uc3QgcmVzdWx0TWV0YSA9IFtdO1xuXHRjb25zdCBtZXRhQnlBdHRyaWJ1dGUgPSB7fTtcblx0bGV0IHRpdGxlO1xuXHRmb3IgKGxldCBpID0gcm91dGVNZXRhLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0Y29uc3QgbWV0YXMgPSByb3V0ZU1ldGFbaV07XG5cdFx0Zm9yIChsZXQgaiA9IG1ldGFzLmxlbmd0aCAtIDE7IGogPj0gMDsgai0tKSB7XG5cdFx0XHRjb25zdCBtID0gbWV0YXNbal07XG5cdFx0XHRpZiAoIW0pIGNvbnRpbnVlO1xuXHRcdFx0aWYgKG0udGl0bGUpIHtcblx0XHRcdFx0aWYgKCF0aXRsZSkgdGl0bGUgPSB7XG5cdFx0XHRcdFx0dGFnOiBcInRpdGxlXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IG0udGl0bGVcblx0XHRcdFx0fTtcblx0XHRcdH0gZWxzZSBpZiAoXCJzY3JpcHQ6bGQranNvblwiIGluIG0pIHRyeSB7XG5cdFx0XHRcdGNvbnN0IGpzb24gPSBKU09OLnN0cmluZ2lmeShtW1wic2NyaXB0OmxkK2pzb25cIl0pO1xuXHRcdFx0XHRyZXN1bHRNZXRhLnB1c2goe1xuXHRcdFx0XHRcdHRhZzogXCJzY3JpcHRcIixcblx0XHRcdFx0XHRhdHRyczogeyB0eXBlOiBcImFwcGxpY2F0aW9uL2xkK2pzb25cIiB9LFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBlc2NhcGVIdG1sKGpzb24pXG5cdFx0XHRcdH0pO1xuXHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdGNvbnN0IGF0dHJpYnV0ZSA9IG0ubmFtZSA/PyBtLnByb3BlcnR5O1xuXHRcdFx0XHRpZiAoYXR0cmlidXRlKSB7XG5cdFx0XHRcdFx0aWYgKG1ldGFCeUF0dHJpYnV0ZVthdHRyaWJ1dGVdKSBjb250aW51ZTtcblx0XHRcdFx0XHRlbHNlIG1ldGFCeUF0dHJpYnV0ZVthdHRyaWJ1dGVdID0gdHJ1ZTtcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXN1bHRNZXRhLnB1c2goe1xuXHRcdFx0XHRcdHRhZzogXCJtZXRhXCIsXG5cdFx0XHRcdFx0YXR0cnM6IHtcblx0XHRcdFx0XHRcdC4uLm0sXG5cdFx0XHRcdFx0XHRub25jZVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cdGlmICh0aXRsZSkgcmVzdWx0TWV0YS5wdXNoKHRpdGxlKTtcblx0aWYgKG5vbmNlKSByZXN1bHRNZXRhLnB1c2goe1xuXHRcdHRhZzogXCJtZXRhXCIsXG5cdFx0YXR0cnM6IHtcblx0XHRcdHByb3BlcnR5OiBcImNzcC1ub25jZVwiLFxuXHRcdFx0Y29udGVudDogbm9uY2Vcblx0XHR9XG5cdH0pO1xuXHRyZXN1bHRNZXRhLnJldmVyc2UoKTtcblx0Y29uc3QgY29uc3RydWN0ZWRMaW5rcyA9IG1hdGNoZXMuZmxhdE1hcCgobWF0Y2gpID0+IG1hdGNoLmxpbmtzID8/IFtdKS5maWx0ZXIoKGxpbmspID0+IGxpbmsgIT09IHZvaWQgMCkubWFwKChsaW5rKSA9PiAoe1xuXHRcdHRhZzogXCJsaW5rXCIsXG5cdFx0YXR0cnM6IHtcblx0XHRcdC4uLmxpbmssXG5cdFx0XHRub25jZVxuXHRcdH1cblx0fSkpO1xuXHRjb25zdCBtYW5pZmVzdCA9IHJvdXRlci5zc3I/Lm1hbmlmZXN0O1xuXHRjb25zdCBtYW5pZmVzdENzc1RhZ3MgPSBbXTtcblx0aWYgKG1hbmlmZXN0KSB7XG5cdFx0bWF0Y2hlcy5mb3JFYWNoKChtYXRjaCkgPT4ge1xuXHRcdFx0KG1hbmlmZXN0LnJvdXRlc1ttYXRjaC5yb3V0ZUlkXT8uY3NzKT8uZm9yRWFjaCgobGluaykgPT4ge1xuXHRcdFx0XHRjb25zdCByZXNvbHZlZExpbmsgPSByZXNvbHZlTWFuaWZlc3RDc3NMaW5rKGxpbmspO1xuXHRcdFx0XHRtYW5pZmVzdENzc1RhZ3MucHVzaCh7XG5cdFx0XHRcdFx0dGFnOiBcImxpbmtcIixcblx0XHRcdFx0XHRhdHRyczoge1xuXHRcdFx0XHRcdFx0cmVsOiBcInN0eWxlc2hlZXRcIixcblx0XHRcdFx0XHRcdC4uLnJlc29sdmVkTGluayxcblx0XHRcdFx0XHRcdGNyb3NzT3JpZ2luOiBnZXRBc3NldENyb3NzT3JpZ2luKGFzc2V0Q3Jvc3NPcmlnaW4sIFwic3R5bGVzaGVldFwiKSA/PyByZXNvbHZlZExpbmsuY3Jvc3NPcmlnaW4sXG5cdFx0XHRcdFx0XHRzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWUsXG5cdFx0XHRcdFx0XHRub25jZVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHRpZiAobWFuaWZlc3QuaW5saW5lU3R5bGUpIG1hbmlmZXN0Q3NzVGFncy5wdXNoKHtcblx0XHRcdHRhZzogXCJzdHlsZVwiLFxuXHRcdFx0YXR0cnM6IHtcblx0XHRcdFx0Li4ubWFuaWZlc3QuaW5saW5lU3R5bGUuYXR0cnMsXG5cdFx0XHRcdG5vbmNlXG5cdFx0XHR9LFxuXHRcdFx0Y2hpbGRyZW46IG1hbmlmZXN0LmlubGluZVN0eWxlLmNoaWxkcmVuLFxuXHRcdFx0aW5saW5lQ3NzOiB0cnVlXG5cdFx0fSk7XG5cdH1cblx0Y29uc3QgcHJlbG9hZExpbmtzID0gW107XG5cdGlmIChtYW5pZmVzdCkgbWF0Y2hlcy5mb3JFYWNoKChtYXRjaCkgPT4ge1xuXHRcdG1hbmlmZXN0LnJvdXRlc1ttYXRjaC5yb3V0ZUlkXT8ucHJlbG9hZHM/LmZvckVhY2goKHByZWxvYWQpID0+IHtcblx0XHRcdHByZWxvYWRMaW5rcy5wdXNoKHtcblx0XHRcdFx0dGFnOiBcImxpbmtcIixcblx0XHRcdFx0YXR0cnM6IHtcblx0XHRcdFx0XHQuLi5nZXRTY3JpcHRQcmVsb2FkQXR0cnMobWFuaWZlc3QsIHByZWxvYWQsIGFzc2V0Q3Jvc3NPcmlnaW4pLFxuXHRcdFx0XHRcdG5vbmNlXG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9KTtcblx0Y29uc3Qgc3R5bGVzID0gbWF0Y2hlcy5mbGF0TWFwKChtYXRjaCkgPT4gbWF0Y2guc3R5bGVzID8/IFtdKS5maWx0ZXIoKHN0eWxlKSA9PiBzdHlsZSAhPT0gdm9pZCAwKS5tYXAoKHsgY2hpbGRyZW4sIC4uLmF0dHJzIH0pID0+ICh7XG5cdFx0dGFnOiBcInN0eWxlXCIsXG5cdFx0YXR0cnM6IHtcblx0XHRcdC4uLmF0dHJzLFxuXHRcdFx0bm9uY2Vcblx0XHR9LFxuXHRcdGNoaWxkcmVuXG5cdH0pKTtcblx0Y29uc3QgaGVhZFNjcmlwdHMgPSBtYXRjaGVzLmZsYXRNYXAoKG1hdGNoKSA9PiBtYXRjaC5oZWFkU2NyaXB0cyA/PyBbXSkuZmlsdGVyKChzY3JpcHQpID0+IHNjcmlwdCAhPT0gdm9pZCAwKS5tYXAoKHsgY2hpbGRyZW4sIC4uLnNjcmlwdCB9KSA9PiAoe1xuXHRcdHRhZzogXCJzY3JpcHRcIixcblx0XHRhdHRyczoge1xuXHRcdFx0Li4uc2NyaXB0LFxuXHRcdFx0bm9uY2Vcblx0XHR9LFxuXHRcdGNoaWxkcmVuXG5cdH0pKTtcblx0Y29uc3QgdGFncyA9IFtdO1xuXHRhcHBlbmRVbmlxdWVVc2VyVGFncyh0YWdzLCByZXN1bHRNZXRhKTtcblx0dGFncy5wdXNoKC4uLnByZWxvYWRMaW5rcyk7XG5cdGFwcGVuZFVuaXF1ZVVzZXJUYWdzKHRhZ3MsIGNvbnN0cnVjdGVkTGlua3MpO1xuXHR0YWdzLnB1c2goLi4ubWFuaWZlc3RDc3NUYWdzKTtcblx0YXBwZW5kVW5pcXVlVXNlclRhZ3ModGFncywgc3R5bGVzKTtcblx0YXBwZW5kVW5pcXVlVXNlclRhZ3ModGFncywgaGVhZFNjcmlwdHMpO1xuXHRyZXR1cm4gdGFncztcbn1cbi8qKlxuKiBCdWlsZCB0aGUgaGVhZC9saW5rL21ldGEvc2NyaXB0IHRhZ3MgZnJvbSB0aGUgcmVuZGVyYWJsZSBwcmVzZW50ZWQgcHJlZml4LlxuKiBVc2VkIGludGVybmFsbHkgYnkgYEhlYWRDb250ZW50YC5cbiovXG52YXIgdXNlVGFncyA9IChhc3NldENyb3NzT3JpZ2luKSA9PiB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCBub25jZSA9IHJvdXRlci5vcHRpb25zLnNzcj8ubm9uY2U7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHJldHVybiBidWlsZFRhZ3NGcm9tTWF0Y2hlcyhyb3V0ZXIsIG5vbmNlLCByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCksIGFzc2V0Q3Jvc3NPcmlnaW4pO1xuXHRjb25zdCBzZWxlY3RUYWdzID0gUmVhY3QkMS51c2VDYWxsYmFjaygobWF0Y2hlcykgPT4gYnVpbGRUYWdzRnJvbU1hdGNoZXMocm91dGVyLCBub25jZSwgbWF0Y2hlcywgYXNzZXRDcm9zc09yaWdpbiksIFtcblx0XHRhc3NldENyb3NzT3JpZ2luLFxuXHRcdG5vbmNlLFxuXHRcdHJvdXRlclxuXHRdKTtcblx0cmV0dXJuIHVzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMubWF0Y2hlcywgc2VsZWN0VGFncywgeyBjb21wYXJlOiBkZWVwRXF1YWwgfSk7XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VUYWdzIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWhlYWRDb250ZW50VXRpbHMuanMubWFwIiwiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBBc3NldCB9IGZyb20gXCIuL0Fzc2V0LmpzXCI7XG5pbXBvcnQgeyBjb21wb3NlU3NyQm9keVNjcmlwdHMsIGRlZXBFcXVhbCwgZ2V0U3NyQm9keVNjcmlwdFBhcnRzIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0IHsgY3JlYXRlRWxlbWVudCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyBGcmFnbWVudCwganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvU2NyaXB0cy50c3hcbnZhciByb3V0ZVNjcmlwdEF0dHJzID0geyBzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWUgfTtcbi8qKlxuKiBSZW5kZXIgYm9keSBzY3JpcHQgdGFncyBjb2xsZWN0ZWQgZnJvbSByb3V0ZSBtYXRjaGVzIGFuZCBTU1IgbWFuaWZlc3RzLlxuKiBEdXJpbmcgc3RyZWFtaW5nIFNTUiwgYDxTY3JpcHRzPmAgbWFya3Mgd2hlcmUgbGF0ZSBoeWRyYXRpb24gc2NyaXB0cyBtYXlcbiogYmVnaW4gdG8gYmUgaW5zZXJ0ZWQuXG4qL1xudmFyIFNjcmlwdHMgPSAoKSA9PiB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCBub25jZSA9IHJvdXRlci5vcHRpb25zLnNzcj8ubm9uY2U7XG5cdGNvbnN0IGdldFBhcnRzID0gKG1hdGNoZXMpID0+IHtcblx0XHRjb25zdCBwYXJ0cyA9IGdldFNzckJvZHlTY3JpcHRQYXJ0cyhtYXRjaGVzLCByb3V0ZXIuc3NyPy5tYW5pZmVzdCwgbm9uY2UsIHJvdXRlU2NyaXB0QXR0cnMpO1xuXHRcdGZvciAoY29uc3Qgc2NyaXB0IG9mIHBhcnRzWzFdKSBpZiAodHlwZW9mIHNjcmlwdC5hdHRycz8uc3JjID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRjb25zdCBzY3JpcHRXaXRoSG9pc3QgPSBzY3JpcHQ7XG5cdFx0XHRzY3JpcHRXaXRoSG9pc3QucHJldmVudFNjcmlwdEhvaXN0ID0gdHJ1ZTtcblx0XHR9XG5cdFx0cmV0dXJuIHBhcnRzO1xuXHR9O1xuXHRjb25zdCBnZXRTY3JpcHRzID0gKG1hdGNoZXMpID0+IHtcblx0XHRyZXR1cm4gY29tcG9zZVNzckJvZHlTY3JpcHRzKGdldFBhcnRzKG1hdGNoZXMpKTtcblx0fTtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikge1xuXHRcdGNvbnN0IGFjdGl2ZU1hdGNoZXMgPSByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCk7XG5cdFx0cmV0dXJuIHJlbmRlclNjcmlwdHMoY29tcG9zZVNzckJvZHlTY3JpcHRzKGdldFBhcnRzKGFjdGl2ZU1hdGNoZXMpLCByb3V0ZXIuc2VydmVyU3NyPy50YWtlSW5pdGlhbEh5ZHJhdGlvblNjcmlwdFRhZ3MoKSkpO1xuXHR9XG5cdHJldHVybiByZW5kZXJTY3JpcHRzKHVzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMubWF0Y2hlcywgZ2V0U2NyaXB0cywgeyBjb21wYXJlOiBkZWVwRXF1YWwgfSkpO1xufTtcbmZ1bmN0aW9uIHJlbmRlclNjcmlwdHMoc2NyaXB0cykge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChGcmFnbWVudCwgeyBjaGlsZHJlbjogc2NyaXB0cy5tYXAoKGFzc2V0LCBpKSA9PiAvKiBAX19QVVJFX18gKi8gY3JlYXRlRWxlbWVudChBc3NldCwge1xuXHRcdC4uLmFzc2V0LFxuXHRcdGtleTogYHRzci1zY3JpcHRzLSR7YXNzZXQudGFnfS0ke2l9YFxuXHR9KSkgfSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFNjcmlwdHMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9U2NyaXB0cy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUh5ZHJhdGVkIH0gZnJvbSBcIi4vQ2xpZW50T25seS5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBBc3NldCB9IGZyb20gXCIuL0Fzc2V0LmpzXCI7XG5pbXBvcnQgeyB1c2VUYWdzIH0gZnJvbSBcIi4vaGVhZENvbnRlbnRVdGlscy5qc1wiO1xuaW1wb3J0IHsgREVWX1NUWUxFU19BVFRSIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNyZWF0ZUVsZW1lbnQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEZyYWdtZW50LCBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvSGVhZENvbnRlbnQuZGV2LnRzeFxuLyoqXG4qIFJlbmRlciByb3V0ZS1tYW5hZ2VkIGhlYWQgdGFncyAodGl0bGUsIG1ldGEsIGxpbmtzLCBzdHlsZXMsIGhlYWQgc2NyaXB0cykuXG4qIFBsYWNlIGluc2lkZSB0aGUgZG9jdW1lbnQgaGVhZCBvZiB5b3VyIGFwcCBzaGVsbC5cbipcbiogRGV2ZWxvcG1lbnQgdmVyc2lvbjogZmlsdGVycyBvdXQgZGV2IHN0eWxlcyBsaW5rIGFmdGVyIGh5ZHJhdGlvbiBhbmRcbiogaW5jbHVkZXMgYSBmYWxsYmFjayBjbGVhbnVwIGVmZmVjdCBmb3IgaHlkcmF0aW9uIG1pc21hdGNoIGNhc2VzLlxuKlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2d1aWRlL2RvY3VtZW50LWhlYWQtbWFuYWdlbWVudFxuKi9cbmZ1bmN0aW9uIEhlYWRDb250ZW50KHByb3BzKSB7XG5cdGNvbnN0IHRhZ3MgPSB1c2VUYWdzKHByb3BzLmFzc2V0Q3Jvc3NPcmlnaW4pO1xuXHRjb25zdCBub25jZSA9IHVzZVJvdXRlcigpLm9wdGlvbnMuc3NyPy5ub25jZTtcblx0Y29uc3QgaHlkcmF0ZWQgPSB1c2VIeWRyYXRlZCgpO1xuXHRSZWFjdCQxLnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0aWYgKGh5ZHJhdGVkKSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKGBsaW5rWyR7REVWX1NUWUxFU19BVFRSfV1gKS5mb3JFYWNoKChlbCkgPT4gZWwucmVtb3ZlKCkpO1xuXHR9LCBbaHlkcmF0ZWRdKTtcblx0Y29uc3QgZmlsdGVyZWRUYWdzID0gaHlkcmF0ZWQgPyB0YWdzLmZpbHRlcigodGFnKSA9PiB0YWcudGFnICE9PSBcImxpbmtcIiB8fCB0YWcuYXR0cnM/LltERVZfU1RZTEVTX0FUVFJdICE9PSB0cnVlKSA6IHRhZ3M7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KEZyYWdtZW50LCB7IGNoaWxkcmVuOiBmaWx0ZXJlZFRhZ3MubWFwKCh0YWcpID0+IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVFbGVtZW50KEFzc2V0LCB7XG5cdFx0Li4udGFnLFxuXHRcdGtleTogYHRzci1tZXRhLSR7SlNPTi5zdHJpbmdpZnkodGFnKX1gLFxuXHRcdG5vbmNlXG5cdH0pKSB9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgSGVhZENvbnRlbnQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9SGVhZENvbnRlbnQuZGV2LmpzLm1hcCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQVlBLFNBQVMsU0FBUyxVQUFVLENBQUMsR0FBRztDQUMvQixRQUFRLGFBQWE7Q0FDckIsSUFBSSxRQUFRLE9BQU8sTUFBTTtDQUN6QixPQUFPO0FBQ1I7O0FBRUEsU0FBUyxXQUFXLEtBQUs7Q0FDeEIsT0FBTyxLQUFLLGVBQWU7QUFDNUI7Ozs7QUNsQkEsSUFBTSxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2dCcEIsU0FBUyxTQUFTLE1BQU07Q0FDdkIsS0FBSyxhQUFhLEtBQUssY0FBYyxLQUFLLFFBQVE7Q0FDbEQsTUFBTSxVQUFVLElBQUksUUFBUSxLQUFLLE9BQU87Q0FDeEMsSUFBSSxLQUFLLFFBQVEsUUFBUSxJQUFJLFVBQVUsTUFBTSxNQUFNLFFBQVEsSUFBSSxZQUFZLEtBQUssSUFBSTtDQUNwRixNQUFNLFdBQVcsSUFBSSxTQUFTLE1BQU07RUFDbkMsUUFBUSxLQUFLO0VBQ2I7Q0FDRCxDQUFDO0NBQ0QsU0FBUyxVQUFVO0NBQ25CLElBQUksS0FBSyxPQUFPLE1BQU07Q0FDdEIsT0FBTztBQUNSOztBQUVBLFNBQVMsV0FBVyxLQUFLO0NBQ3hCLE9BQU8sZUFBZSxZQUFZLENBQUMsQ0FBQyxJQUFJO0FBQ3pDOzs7Ozs7O0FDM0JBLFNBQVMsS0FBSyxLQUFLO0NBQ2xCLE9BQU8sSUFBSSxJQUFJLFNBQVM7QUFDekI7Ozs7O0FBS0EsU0FBUyxpQkFBaUIsU0FBUyxVQUFVO0NBQzVDLElBQUksT0FBTyxZQUFZLFlBQVksT0FBTyxRQUFRLFFBQVE7Q0FDMUQsT0FBTztBQUNSO0FBQ0EsSUFBTSxTQUFTLE9BQU8sVUFBVTtBQUNoQyxTQUFTLFFBQVEsS0FBSztDQUNyQixLQUFLLE1BQU0sT0FBTyxLQUFLLElBQUksT0FBTyxLQUFLLEtBQUssR0FBRyxHQUFHLE9BQU87Q0FDekQsT0FBTztBQUNSO0FBQ0EsSUFBTSxtQkFBbUIsT0FBTyxPQUFPLElBQUk7QUFDM0MsSUFBTSx3QkFBd0IsTUFBTSxTQUFTLGlCQUFpQixNQUFNLE1BQU0sSUFBSTtBQUM5RSxTQUFTLGlCQUFpQixNQUFNLE1BQU0sWUFBWSxTQUFTLEdBQUc7Q0FFN0QsSUFBSSxTQUFTLE1BQU0sT0FBTztDQUMxQixJQUFJLFdBQVcsS0FBSyxPQUFPO0NBQzNCLE1BQU0sUUFBUSxNQUFNLFFBQVEsSUFBSSxLQUFLLE1BQU0sUUFBUSxJQUFJO0NBQ3ZELElBQUksQ0FBQyxTQUFTLEVBQUUsY0FBYyxJQUFJLEtBQUssY0FBYyxJQUFJLElBQUksT0FBTztDQUNwRSxNQUFNLFdBQVcsT0FBTyxLQUFLLElBQUk7Q0FDakMsTUFBTSxnQkFBZ0IsU0FBUztDQUMvQixNQUFNLFdBQVcsT0FBTyxLQUFLLElBQUk7Q0FDakMsTUFBTSxTQUFTLFNBQVM7Q0FDeEIsSUFBSSxRQUFRLGtCQUFrQixLQUFLLFVBQVUsV0FBVyxLQUFLLFVBQVUsaUJBQWlCLEtBQUssUUFBUSxNQUFNLEdBQUcsZ0JBQWdCLE9BQU8sVUFBVSxLQUFLLFFBQVEsTUFBTSxHQUFHLFNBQVMsTUFBTSxrQkFBa0IsT0FBTyxvQkFBb0IsSUFBSSxDQUFDLENBQUMsVUFBVSxXQUFXLE9BQU8sb0JBQW9CLElBQUksQ0FBQyxDQUFDLFVBQVUsT0FBTyxzQkFBc0IsSUFBSSxDQUFDLENBQUMsUUFBUSxPQUFPO0NBQ3pWLElBQUksSUFBSTtDQUNSLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUksT0FBTztFQUNWLE9BQU8sSUFBSSxRQUFRLEtBQUs7R0FDdkIsTUFBTTtHQUNOLFdBQVcsS0FBSztHQUNoQixRQUFRLEtBQUs7R0FDYixRQUFRLGFBQWEsUUFBUSxXQUFXLE9BQU8sYUFBYSxXQUFXLGlCQUFpQixVQUFVLE9BQU8sWUFBWSxNQUFNLElBQUk7R0FDL0gsSUFBSSxVQUFVLFVBQVU7RUFDekI7RUFDQSxJQUFJLE1BQU0sVUFBVSxrQkFBa0IsUUFBUSxPQUFPO0NBQ3RELE9BQU87RUFDTixJQUFJLFFBQVEsa0JBQWtCO0VBQzlCLElBQUksWUFBWTtFQUNoQixPQUFPLElBQUksUUFBUSxLQUFLO0dBQ3ZCLE1BQU0sU0FBUztHQUNmLFdBQVcsS0FBSztHQUNoQixNQUFNLFdBQVcsS0FBSztHQUN0QixRQUFRLGFBQWEsV0FBVyxXQUFXLE9BQU8sYUFBYSxXQUFXLGlCQUFpQixVQUFVLFVBQVUsWUFBWSxNQUFNLElBQUk7R0FDckksVUFBVSxVQUFVLGFBQWEsU0FBUyxPQUFPLE9BQU8sT0FBTyxLQUFLLE1BQU0sR0FBRztHQUM3RSxjQUFjLE9BQU8sR0FBRyxPQUFPLFFBQVE7R0FDdkMsU0FBUyxLQUFLO0VBQ2Y7RUFDQSxJQUFJLE9BQU8sT0FBTyxPQUFPLHNCQUFzQixJQUFJLENBQUMsQ0FBQyxTQUFTLE9BQU87RUFDckUsSUFBSSxXQUFXLE9BQU87Q0FDdkI7Q0FDQSxNQUFNLE9BQU8sUUFBUSxTQUFTLEtBQUssQ0FBQyxJQUFJLGFBQWEsV0FBVyxJQUFJLENBQUM7Q0FDckUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FBSztFQUNoQyxNQUFNLFFBQVEsSUFBSSxTQUFTO0VBQzNCLElBQUksT0FBTztHQUNWLFdBQVcsS0FBSztHQUNoQixJQUFJLElBQUksR0FBRztJQUNWLFFBQVEsS0FBSztJQUNiLFFBQVEsYUFBYSxRQUFRLFdBQVcsT0FBTyxhQUFhLFdBQVcsaUJBQWlCLFVBQVUsT0FBTyxZQUFZLE1BQU0sSUFBSTtHQUNoSTtHQUNBLEtBQUssT0FBTyxJQUFJLElBQUksV0FBVztFQUNoQyxPQUFPLEtBQUssT0FBTyxTQUFTO0NBQzdCO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxjQUFjLEdBQUc7Q0FDekIsSUFBSSxDQUFDLEtBQUssT0FBTyxNQUFNLFVBQVUsT0FBTztDQUN4QyxRQUFRLE9BQU8sZUFBZSxDQUFDLENBQUMsRUFBRSxlQUFlLFlBQVk7QUFDOUQ7Ozs7Ozs7Ozs7QUFVQSxTQUFTLFVBQVUsR0FBRyxHQUFHLFNBQVMsbUJBQW1CO0NBQ3BELElBQUksTUFBTSxHQUFHLE9BQU87Q0FDcEIsSUFBSSxNQUFNLFFBQVEsQ0FBQyxLQUFLLE1BQU0sUUFBUSxDQUFDLEdBQUc7RUFDekMsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLE9BQU87RUFDbEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxJQUFJLEdBQUcsS0FBSztHQUN6QyxNQUFNLEtBQUssRUFBRTtHQUNiLE1BQU0sS0FBSyxFQUFFO0dBQ2IsSUFBSSxPQUFPLE1BQU0sQ0FBQyxVQUFVLElBQUksSUFBSSxTQUFTLGlCQUFpQixHQUFHLE9BQU87RUFDekU7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxJQUFJLGNBQWMsQ0FBQyxLQUFLLGNBQWMsQ0FBQyxHQUFHO0VBQ3pDLElBQUksU0FBUztHQUNaLEtBQUssTUFBTSxLQUFLLEdBQUcsSUFBSSxxQkFBcUIsRUFBRSxPQUFPLEtBQUssR0FDckQ7UUFBQSxDQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUUsSUFBSSxTQUFTLGlCQUFpQixHQUFHLE9BQU87R0FBQTtHQUVoRSxPQUFPO0VBQ1I7RUFDQSxJQUFJLFNBQVM7RUFDYixJQUFJLG1CQUFtQixTQUFTLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQztPQUMxQyxLQUFLLE1BQU0sS0FBSyxHQUFHLElBQUksRUFBRSxPQUFPLEtBQUssR0FBRztFQUM3QyxLQUFLLE1BQU0sS0FBSyxHQUFHLElBQUkscUJBQXFCLEVBQUUsT0FBTyxLQUFLLEdBQ3JEO09BQUEsYUFBYSxLQUFLLENBQUMsVUFBVSxFQUFFLElBQUksRUFBRSxJQUFJLFNBQVMsaUJBQWlCLEdBQUcsT0FBTztFQUFBO0VBRWxGLE9BQU8sV0FBVztDQUNuQjtDQUNBLE9BQU87QUFDUjs7Ozs7QUFLQSxTQUFTLHdCQUF3QixXQUFXO0NBQzNDLElBQUk7Q0FDSixJQUFJO0NBQ0osTUFBTSxvQkFBb0IsSUFBSSxTQUFTLFNBQVMsV0FBVztFQUMxRCxxQkFBcUI7RUFDckIsb0JBQW9CO0NBQ3JCLENBQUM7Q0FDRCxrQkFBa0IsU0FBUztDQUMzQixrQkFBa0IsV0FBVyxVQUFVO0VBQ3RDLGtCQUFrQixTQUFTO0VBQzNCLGtCQUFrQixRQUFRO0VBQzFCLG1CQUFtQixLQUFLO0VBQ3hCLFlBQVksS0FBSztDQUNsQjtDQUNBLGtCQUFrQixVQUFVLE1BQU07RUFDakMsa0JBQWtCLFNBQVM7RUFDM0Isa0JBQWtCLENBQUM7Q0FDcEI7Q0FDQSxPQUFPO0FBQ1I7Ozs7O0FBS0EsU0FBUyxzQkFBc0IsT0FBTztDQUNyQyxJQUFJLE9BQU8sT0FBTyxZQUFZLFVBQVUsT0FBTztDQUMvQyxPQUFPLE1BQU0sUUFBUSxXQUFXLDZDQUE2QyxLQUFLLE1BQU0sUUFBUSxXQUFXLDJDQUEyQyxLQUFLLE1BQU0sUUFBUSxXQUFXLGtDQUFrQztBQUN2TjtBQUlBLFNBQVMsU0FBUyxPQUFPLFdBQVc7Q0FDbkMsS0FBSyxJQUFJLElBQUksTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7RUFDM0MsTUFBTSxPQUFPLE1BQU07RUFDbkIsSUFBSSxVQUFVLElBQUksR0FBRyxPQUFPO0NBQzdCO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7O0FBY0EsSUFBTSxpQkFBaUI7QUFDdkIsU0FBUyxvQkFBb0IsU0FBUztDQUNyQyxPQUFPLFFBQVEsUUFBUSxpQkFBaUIsT0FBTyxNQUFNLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDbEg7QUFDQSxTQUFTLGNBQWMsU0FBUztDQUMvQixJQUFJO0NBQ0osSUFBSTtFQUNILFVBQVUsVUFBVSxPQUFPO0NBQzVCLFFBQVE7RUFDUCxVQUFVLFFBQVEsV0FBVyxtQkFBbUIsVUFBVTtHQUN6RCxJQUFJO0lBQ0gsT0FBTyxVQUFVLEtBQUs7R0FDdkIsUUFBUTtJQUNQLE9BQU87R0FDUjtFQUNELENBQUM7Q0FDRjtDQUNBLE9BQU8sb0JBQW9CLE9BQU87QUFDbkM7Ozs7O0FBS0EsSUFBTSw2QkFBNkI7Q0FDbEM7Q0FDQTtDQUNBO0NBQ0E7QUFDRDs7Ozs7Ozs7QUFRQSxTQUFTLGFBQWEsS0FBSztDQUMxQixJQUFJLElBQUksT0FBTyxLQUFLO0NBQ3BCLElBQUksQ0FBQyxJQUFJLFNBQVMsR0FBRyxHQUFHO0NBQ3hCLE9BQU8sMENBQTBDLEtBQUssR0FBRyxDQUFDLEdBQUcsRUFBRSxFQUFFLFFBQVEsYUFBYSxFQUFFLENBQUMsQ0FBQyxZQUFZO0FBQ3ZHO0FBQ0EsSUFBTSw4QkFBOEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQnBDLFNBQVMsb0JBQW9CLEtBQUssV0FBVztDQUM1QyxJQUFJLENBQUMsS0FBSyxPQUFPO0NBQ2pCLElBQUksNEJBQTRCLEtBQUssR0FBRyxHQUFHLE9BQU87Q0FDbEQsTUFBTSxTQUFTLGFBQWEsR0FBRztDQUMvQixPQUFPLFNBQVMsQ0FBQyxVQUFVLElBQUksTUFBTSxJQUFJO0FBQzFDO0FBQ0EsSUFBTSxxQkFBcUI7Q0FDMUIsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsVUFBVTtDQUNWLFVBQVU7QUFDWDtBQUNBLElBQU0sb0JBQW9COzs7Ozs7OztBQVExQixTQUFTLFdBQVcsS0FBSztDQUN4QixPQUFPLElBQUksUUFBUSxvQkFBb0IsVUFBVSxtQkFBbUIsTUFBTTtBQUMzRTtBQUNBLFNBQVMsV0FBVyxNQUFNO0NBQ3pCLElBQUksQ0FBQyxNQUFNLE9BQU87Q0FDbEIsSUFBSSxTQUFTO0NBQ2IsSUFBSSxxQkFBcUIsS0FBSyxJQUFJLEdBQUc7RUFDcEMsTUFBTSxLQUFLO0VBQ1gsSUFBSSxTQUFTO0VBQ2IsSUFBSTtFQUNKLFNBQVM7RUFDVCxPQUFPLFVBQVUsUUFBUSxHQUFHLEtBQUssSUFBSSxJQUFJO0dBQ3hDLFVBQVUsY0FBYyxLQUFLLE1BQU0sUUFBUSxNQUFNLEtBQUssQ0FBQyxJQUFJLE1BQU07R0FDakUsU0FBUyxHQUFHO0VBQ2I7RUFDQSxVQUFVLGNBQWMsU0FBUyxLQUFLLE1BQU0sTUFBTSxJQUFJLElBQUk7Q0FDM0Q7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBb0JBLFNBQVMsa0JBQWtCLE1BQU07Q0FDaEMsSUFBSSxDQUFDLG9CQUFvQixLQUFLLElBQUksR0FBRyxPQUFPO0NBQzVDLE9BQU8sS0FBSyxRQUFRLHlCQUF5QixrQkFBa0I7QUFDaEU7QUFjQSxTQUFTLFlBQVksR0FBRyxHQUFHO0NBQzFCLElBQUksTUFBTSxHQUFHLE9BQU87Q0FDcEIsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLE9BQU87Q0FDbEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxPQUFPO0NBQzdELE9BQU87QUFDUjs7OztBQ3RUQSxTQUFTLFVBQVUsT0FBTztDQUN6QixPQUFPLFVBQVUsTUFBTSxRQUFRLFFBQVE7RUFDdEMsT0FBTyxRQUFRLEtBQUs7Q0FDckIsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUM7QUFDYjs7QUFFQSxTQUFTLFVBQVUsTUFBTTtDQUN4QixPQUFPLEtBQUssUUFBUSxXQUFXLEdBQUc7QUFDbkM7O0FBRUEsU0FBUyxhQUFhLE1BQU07Q0FDM0IsT0FBTyxTQUFTLE1BQU0sT0FBTyxLQUFLLFFBQVEsUUFBUSxFQUFFO0FBQ3JEOztBQUVBLFNBQVMsY0FBYyxNQUFNO0NBQzVCLE1BQU0sTUFBTSxLQUFLO0NBQ2pCLE9BQU8sTUFBTSxLQUFLLEtBQUssTUFBTSxPQUFPLE1BQU0sS0FBSyxRQUFRLFFBQVEsRUFBRSxJQUFJO0FBQ3RFOztBQUVBLFNBQVMsU0FBUyxNQUFNO0NBQ3ZCLE9BQU8sY0FBYyxhQUFhLElBQUksQ0FBQztBQUN4Qzs7QUFFQSxTQUFTLG9CQUFvQixPQUFPLFVBQVU7Q0FDN0MsSUFBSSxPQUFPLFNBQVMsR0FBRyxLQUFLLFVBQVUsT0FBTyxVQUFVLEdBQUcsU0FBUyxJQUFJLE9BQU8sTUFBTSxNQUFNLEdBQUcsRUFBRTtDQUMvRixPQUFPO0FBQ1I7Ozs7Ozs7O0FBZUEsU0FBUyxZQUFZLE1BQU0sSUFBSSxnQkFBZ0IsU0FBUyxPQUFPO0NBQzlELElBQUksR0FBRyxTQUFTLElBQUksR0FBRyxLQUFLLFVBQVUsRUFBRTtDQUN4QyxJQUFJLEdBQUcsV0FBVyxHQUFHLEdBQUc7RUFDdkIsSUFBSSxHQUFHLFdBQVcsS0FBSyxrQkFBa0IsWUFBWSxPQUFPO0VBQzVELElBQUksa0JBQWtCLFVBQVUsT0FBTyxHQUFHLFNBQVMsR0FBRyxJQUFJLEtBQUssR0FBRyxHQUFHO0VBQ3JFLE9BQU8sR0FBRyxTQUFTLEdBQUcsSUFBSSxHQUFHLE1BQU0sR0FBRyxFQUFFLElBQUk7Q0FDN0M7Q0FDQSxNQUFNLFNBQVMsT0FBTztDQUN0QixJQUFJO0NBQ0osSUFBSSxPQUFPO0VBQ1YsTUFBTSxTQUFTLE9BQU8sT0FBTyxPQUFPO0VBQ3BDLE1BQU0sU0FBUyxNQUFNLElBQUksR0FBRztFQUM1QixJQUFJLFFBQVEsT0FBTztDQUNwQjtDQUNBLElBQUk7Q0FDSixJQUFJLFFBQVEsZUFBZSxLQUFLLE1BQU0sR0FBRztNQUNwQztFQUNKLElBQUksS0FBSyxTQUFTLElBQUksR0FBRyxPQUFPLFVBQVUsSUFBSTtFQUM5QyxlQUFlLEtBQUssTUFBTSxHQUFHO0VBQzdCLE9BQU8sYUFBYSxTQUFTLEtBQUssS0FBSyxZQUFZLE1BQU0sSUFBSSxhQUFhLElBQUk7RUFDOUUsTUFBTSxhQUFhLEdBQUcsTUFBTSxHQUFHO0VBQy9CLEtBQUssSUFBSSxRQUFRLEdBQUcsU0FBUyxXQUFXLFFBQVEsUUFBUSxRQUFRLFNBQVM7R0FDeEUsTUFBTSxRQUFRLFdBQVc7R0FDekIsSUFBSSxVQUFVLElBQUk7SUFDakIsSUFBSSxDQUFDLE9BQU8sZUFBZSxDQUFDLEtBQUs7U0FDNUIsSUFBSSxVQUFVLFNBQVMsR0FBRyxhQUFhLEtBQUssS0FBSztHQUN2RCxPQUFPLElBQUksVUFBVSxNQUFNO0lBQzFCLElBQUksYUFBYSxTQUFTLEdBQUcsYUFBYSxJQUFJO1NBQ3pDLGVBQWUsQ0FBQyxFQUFFO0dBQ3hCLE9BQU8sSUFBSSxVQUFVLEtBQUssQ0FBQyxPQUFPLGFBQWEsS0FBSyxLQUFLO0VBQzFEO0NBQ0Q7Q0FDQSxJQUFJLGFBQWEsU0FBUyxHQUFHO0VBQzVCLElBQUksS0FBSyxZQUFZLE1BQU0sSUFDdEI7T0FBQSxrQkFBa0IsU0FBUyxhQUFhLElBQUk7RUFBQSxPQUMxQyxJQUFJLGtCQUFrQixVQUFVLGFBQWEsS0FBSyxFQUFFO0NBQzVEO0NBQ0EsTUFBTSxTQUFTLGFBQWEsS0FBSyxHQUFHO0NBQ3BDLE1BQU0sVUFBVSxTQUFTLFVBQVUsTUFBTSxJQUFJLFdBQVc7Q0FDeEQsSUFBSSxPQUFPLE9BQU8sTUFBTSxJQUFJLEtBQUssTUFBTTtDQUN2QyxPQUFPO0FBQ1I7Ozs7O0FBS0EsU0FBUyxxQkFBcUIsNkJBQTZCO0NBQzFELE1BQU0sVUFBVSxJQUFJLElBQUksNEJBQTRCLEtBQUssU0FBUyxDQUFDLG1CQUFtQixJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUM7Q0FDbkcsTUFBTSxRQUFRLElBQUksT0FBTyxDQUFDLEdBQUcsUUFBUSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsUUFBUSxXQUFXLE1BQU0sR0FBRyxHQUFHO0NBQ3RGLFFBQVEsWUFBWSxRQUFRLFFBQVEsUUFBUSxVQUFVLFFBQVEsSUFBSSxLQUFLLEtBQUssS0FBSztBQUNsRjs7QUFLQSxTQUFTLGVBQWUsT0FBTztDQUM5QixPQUFPLFNBQVMsUUFBUSxVQUFVO0FBQ25DO0FBU0EsU0FBUyxZQUFZLEtBQUssT0FBTyxTQUFTO0NBQ3pDLElBQUksT0FBTyxVQUFVLFVBQVUsT0FBTyxNQUFNLFNBQVMsS0FBSztDQUMxRCxNQUFNLFFBQVEsUUFBUTtDQUN0QixJQUFJLFVBQVUsQ0FBQyxTQUFTLHdCQUF3QixLQUFLLEtBQUssSUFBSSxPQUFPO0NBQ3JFLElBQUksVUFBVSxtQkFBbUIsS0FBSztDQUN0QyxJQUFJLE9BQU8sVUFBVSxRQUFRLFdBQVcsT0FBTyxHQUFHO0NBQ2xELE9BQU8sVUFBVSxRQUFRLE9BQU8sSUFBSTtBQUNyQzs7QUFFQSxTQUFTLGdCQUFnQixNQUFNLFVBQVUsUUFBUSxTQUFTLFlBQVk7Q0FDckUsTUFBTSxnQkFBZ0IsS0FBSyxTQUFTLEdBQUcsSUFBSSxNQUFNO0NBQ2pELElBQUksU0FBUztDQUNiLEtBQUssTUFBTSxRQUFRLFVBQVU7RUFDNUIsSUFBSSxPQUFPLFNBQVMsVUFBVTtHQUM3QixVQUFVO0dBQ1Y7RUFDRDtFQUNBLE1BQU0sQ0FBQyxNQUFNLEtBQUssUUFBUSxhQUFhO0VBQ3ZDLE1BQU0sUUFBUSxTQUFTO0VBQ3ZCLE1BQU0sU0FBUyxTQUFTLGNBQWMsS0FBSyxJQUFJLFlBQVksZ0JBQWdCO0VBQzNFLElBQUksYUFBYSxPQUFPO0VBQ3hCLElBQUksU0FBUyxLQUFLLGNBQWMsTUFBTTtFQUN0QyxJQUFJLFlBQVk7R0FDZixXQUFXLE9BQU87R0FDbEIsSUFBSSxPQUFPLFdBQVcsT0FBTztFQUM5QjtFQUNBLElBQUksU0FBUyxlQUFlLFVBQVUsR0FBRztHQUN4QyxJQUFJLFdBQVcsT0FBTyxDQUFDLFFBQVE7R0FDL0IsYUFBYTtFQUNkO0VBQ0EsVUFBVSxTQUFTLFlBQVksS0FBSyxZQUFZLE9BQU8sS0FBSyxVQUFVO0NBQ3ZFO0NBQ0EsT0FBTyxTQUFTLGlCQUFpQjtBQUNsQzs7Ozs7Ozs7Ozs7Ozs7O0FDbElBLFNBQVMsaUJBQWlCLEtBQUs7Q0FDOUIsTUFBTSx3QkFBd0IsSUFBSSxJQUFJO0NBQ3RDLElBQUk7Q0FDSixJQUFJO0NBQ0osT0FBTztFQUNOLElBQUksS0FBSztHQUNSLE1BQU0sUUFBUSxNQUFNLElBQUksR0FBRztHQUMzQixJQUFJLENBQUMsT0FBTztHQUNaLE1BQU0sVUFBVTtHQUNoQixPQUFPLE1BQU07RUFDZDtFQUNBLElBQUksS0FBSyxPQUFPO0dBQ2YsTUFBTSxXQUFXLE1BQU0sSUFBSSxHQUFHO0dBQzlCLElBQUksVUFBVTtJQUNiLFNBQVMsUUFBUTtJQUNqQjtHQUNEO0dBQ0EsSUFBSSxNQUFNLFFBQVEsS0FBSztJQUN0QixJQUFJLE9BQU8sTUFBTSxLQUFLLENBQUMsQ0FBQztJQUN4QixPQUFPLENBQUMsUUFBUSxLQUFLLFNBQVM7S0FDN0IsSUFBSSxNQUFNLEtBQUssVUFBVTtVQUNwQixPQUFPLE1BQU0sT0FBTztLQUN6QixPQUFPLEtBQUssS0FBSyxDQUFDLENBQUM7SUFDcEI7SUFDQSxJQUFJLFNBQVMsUUFBUSxPQUFPLEtBQUs7SUFDakMsTUFBTSxPQUFPLEtBQUssR0FBRztHQUN0QjtHQUNBLE1BQU0sUUFBUTtJQUNiO0lBQ0E7SUFDQSxTQUFTO0dBQ1Y7R0FDQSxTQUFTO0dBQ1QsTUFBTSxJQUFJLEtBQUssS0FBSztFQUNyQjtFQUNBLFFBQVE7R0FDUCxNQUFNLE1BQU07R0FDWixPQUFPLEtBQUs7R0FDWixTQUFTLEtBQUs7RUFDZjtDQUNEO0FBQ0Q7OztBQ2xEQSxJQUFNLHFCQUFxQjtBQUMzQixJQUFNLHdCQUF3QjtBQUM5QixTQUFTLGNBQWMsTUFBTTtDQUM1QixNQUFNLFNBQVMsS0FBSztDQUNwQixJQUFJLFFBQVEsT0FBTztDQUNuQixNQUFNLE9BQU8sQ0FBQztDQUNkLEtBQUssTUFBTSxXQUFXLE1BQU0sSUFBSSxPQUFPLFlBQVksVUFBVSxLQUFLLEtBQUssUUFBUSxFQUFFO0NBQ2pGLE9BQU8sS0FBSyxRQUFRO0FBQ3JCOztBQUVBLFNBQVMsYUFBYSxNQUFNLE9BQU8sS0FBSztDQUN2QyxNQUFNLE9BQU8sS0FBSyxNQUFNLE9BQU8sR0FBRztDQUNsQyxJQUFJLEtBQUssV0FBVyxDQUFDLE1BQU0sSUFBSSxPQUFPLEtBQUssV0FBVyxJQUFJO0VBQ3pEO0VBQ0E7RUFDQTtFQUNBLEtBQUs7Q0FDTixJQUFJO0VBQ0g7RUFDQSxLQUFLLE1BQU0sQ0FBQztFQUNaO0VBQ0E7Q0FDRDtDQUNBLE1BQU0sT0FBTyxLQUFLLFFBQVEsR0FBRztDQUM3QixJQUFJLFFBQVEsR0FBRztFQUNkLE1BQU0sUUFBUSxLQUFLLFFBQVEsS0FBSyxJQUFJO0VBQ3BDLE1BQU0sV0FBVyxLQUFLLFdBQVcsT0FBTyxDQUFDLE1BQU07RUFDL0MsTUFBTSxZQUFZLFFBQVEsV0FBVyxJQUFJO0VBQ3pDLElBQUksU0FBUyxLQUFLLEtBQUssV0FBVyxZQUFZLENBQUMsTUFBTSxPQUFPLENBQUMsWUFBWSxZQUFZLFFBQVE7R0FDNUYsTUFBTSxNQUFNLEtBQUssTUFBTSxXQUFXLEtBQUs7R0FDdkMsT0FBTztJQUNOLFdBQVcsSUFBSSxNQUFNLElBQUk7SUFDekIsT0FBTztJQUNQLEtBQUssTUFBTSxHQUFHLElBQUk7SUFDbEIsS0FBSyxNQUFNLFFBQVEsUUFBUSxHQUFHLE1BQU0sTUFBTSxLQUFLLE1BQU07R0FDdEQ7RUFDRDtDQUNEO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxjQUFjLHNCQUFzQixPQUFPLE9BQU8sTUFBTSxvQkFBb0IscUJBQXFCO0NBQ3pHLElBQUksU0FBUztDQUNiLE1BQU0sT0FBTyxNQUFNLFlBQVksTUFBTTtDQUNyQyxNQUFNLFVBQVUsTUFBTTtDQUN0QixNQUFNLFNBQVMsS0FBSztDQUNwQixNQUFNLGFBQWEsS0FBSyxTQUFTLEdBQUcsSUFBSSxTQUFTLElBQUk7Q0FDckQsTUFBTSxnQkFBZ0IsU0FBUyxpQkFBaUI7Q0FDaEQsTUFBTSxjQUFjLFNBQVMsUUFBUSxTQUFTLFNBQVM7Q0FDdkQsSUFBSTtDQUNKLElBQUksZUFBZSxzQkFBc0IsUUFBUSxJQUFJO0NBQ3JELElBQUksQ0FBQyxRQUFRLEtBQUssU0FBUyxHQUFHLEdBQUc7RUFDaEMsZ0JBQWdCLHFCQUFxQixNQUFNLEtBQUssQ0FBQztFQUNqRCxNQUFNLE9BQU8sS0FBSyxhQUFhO0VBQy9CLElBQUksUUFBUSxPQUFPLFNBQVMsWUFBWSxLQUFLLE9BQU8sR0FBRztHQUN0RCxjQUFjLGNBQWMsU0FBUyxLQUFLO0lBQ3pDLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUssT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLFVBQVUsU0FBUyxLQUFLLFFBQVEsT0FBTyxNQUFNLElBQUksSUFBSSxVQUFVO0dBQzdHO0dBQ0EsZUFBZTtFQUNoQjtDQUNEO0NBQ0EsT0FBTyxTQUFTLFFBQVE7RUFDdkIsTUFBTSxRQUFRO0VBQ2QsTUFBTSxPQUFPLEtBQUssUUFBUSxLQUFLLEtBQUs7RUFDcEMsSUFBSSxNQUFNLFNBQVMsS0FBSyxTQUFTO0VBQ2pDLE1BQU0sVUFBVSxhQUFhLE1BQU0sT0FBTyxHQUFHO0VBQzdDLFNBQVMsTUFBTTtFQUNmLElBQUk7RUFDSixJQUFJLE9BQU8sWUFBWSxVQUFVO0dBQ2hDLElBQUksQ0FBQyxNQUFNO0dBQ1gsSUFBSSxPQUFPO0dBQ1gsSUFBSTtHQUNKLElBQUksZUFBZSxpQkFBaUIsS0FBSywyQkFBMkIsSUFBSSxJQUFJO1FBQ3ZFO0lBQ0osT0FBTyxRQUFRLFlBQVk7SUFDM0IsaUJBQWlCLEtBQUssc0NBQXNDLElBQUksSUFBSTtHQUNyRTtHQUNBLE1BQU0sZUFBZSxlQUFlLElBQUksSUFBSTtHQUM1QyxJQUFJLGNBQWMsV0FBVztRQUN4QjtJQUNKLE1BQU0sT0FBTyxrQkFBa0IsSUFBSTtJQUNuQyxXQUFXO0lBQ1gsZUFBZSxJQUFJLE1BQU0sSUFBSTtHQUM5QjtFQUNELE9BQU87R0FDTixNQUFNLE9BQU8sUUFBUTtHQUNyQixJQUFJLFNBQVMsUUFBUTtHQUNyQixJQUFJLFNBQVMsUUFBUSxNQUFNO0dBQzNCLElBQUksU0FBUyxHQUFHO0lBQ2YsTUFBTTtJQUNOLFNBQVMsTUFBTTtHQUNoQjtHQUNBLElBQUksaUJBQWlCLGVBQWUsS0FBSztJQUN4QyxJQUFJLGVBQWUsUUFBUSxHQUFHLGNBQWMsS0FBSyxLQUFLLE1BQU0sY0FBYyxRQUFRLENBQUMsQ0FBQztJQUNwRixRQUFRLEtBQUssTUFBTTtJQUNuQixJQUFJLFNBQVMsS0FBSyxRQUFRLE9BQU8sS0FBSyxLQUFLLGFBQWEsUUFBUSxRQUFRLEtBQUssT0FBTyxNQUFNLEdBQUcsRUFBRTtJQUMvRixjQUFjLEtBQUssT0FBTztJQUMxQixlQUFlO0dBQ2hCO0dBQ0EsSUFBSSxDQUFDLE1BQU07R0FDWCxNQUFNLHdCQUF3QixpQkFBaUIsQ0FBQyxFQUFFLFVBQVU7R0FDNUQsSUFBSSxDQUFDLGVBQWU7SUFDbkIsU0FBUyxPQUFPLFlBQVk7SUFDNUIsU0FBUyxPQUFPLFlBQVk7R0FDN0I7R0FDQSxNQUFNLFdBQVcsU0FBUyxJQUFJLEtBQUssWUFBWSxDQUFDLElBQUksU0FBUyxJQUFJLEtBQUssYUFBYSxDQUFDLElBQUksS0FBSyxhQUFhLENBQUM7R0FDM0csTUFBTSxlQUFlLFNBQVMsS0FBSyxDQUFDLGVBQWUsU0FBUyxNQUFNLE1BQU0sQ0FBQyxFQUFFLFNBQVMsRUFBRSxrQkFBa0IseUJBQXlCLEVBQUUsV0FBVyxVQUFVLEVBQUUsV0FBVyxNQUFNO0dBQzNLLElBQUksY0FBYyxXQUFXO1FBQ3hCO0lBQ0osTUFBTSxPQUFPLGtCQUFrQixNQUFNLE1BQU0sdUJBQXVCLFFBQVEsTUFBTTtJQUNoRixXQUFXO0lBQ1gsU0FBUyxLQUFLLElBQUk7SUFDbEIsSUFBSSxTQUFTLFdBQVcsR0FBRyxvQkFBb0IsS0FBSyxRQUFRO0dBQzdEO0VBQ0Q7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxJQUFJLGlCQUFpQixlQUFlLFlBQVksY0FBYyxLQUFLLEtBQUssTUFBTSxjQUFjLFVBQVUsQ0FBQztDQUN2RyxNQUFNLGNBQWMsZUFBZSxNQUFNO0NBQ3pDLElBQUksQ0FBQyxNQUFNLE9BQU87Q0FDbEIsSUFBSSxlQUFlLE1BQU0sWUFBWSxDQUFDLE1BQU0sVUFBVSxNQUFNLE1BQU0sTUFBTSxHQUFHLFdBQVcsTUFBTSxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsTUFBTSxJQUFJO0VBQzVILE1BQU0sZUFBZSxrQkFBa0IsTUFBTSxxQkFBcUI7RUFDbEUsQ0FBQyxLQUFLLGFBQWEsQ0FBQyxFQUFBLENBQUcsS0FBSyxZQUFZO0VBQ3hDLE9BQU87Q0FDUjtDQUNBLE1BQU0sVUFBVSxNQUFNLFFBQVEsQ0FBQyxNQUFNLGFBQWEsQ0FBQyxNQUFNO0NBQ3pELElBQUksVUFBVSxhQUFhLFFBQVE7RUFDbEMsTUFBTSxZQUFZLGtCQUFrQixNQUFNLGtCQUFrQjtFQUM1RCxLQUFLLFFBQVE7RUFDYixPQUFPO0NBQ1I7Q0FDQSxLQUFLLFFBQVEsZUFBZTtDQUM1QixLQUFLLFdBQVcsU0FBUyxRQUFRLFlBQVk7Q0FDN0MsSUFBSSxDQUFDLEtBQUssT0FBTztFQUNoQixLQUFLLE9BQU87RUFDWixJQUFJLFFBQVEsS0FBSyxRQUFRO0NBQzFCO0NBQ0EsT0FBTztFQUNOO0VBQ0E7RUFDQTtDQUNEO0FBQ0Q7QUFDQSxTQUFTLFlBQVksR0FBRyxHQUFHO0NBQzFCLElBQUksRUFBRSxTQUFTLENBQUMsRUFBRSxPQUFPLE9BQU87Q0FDaEMsSUFBSSxDQUFDLEVBQUUsU0FBUyxFQUFFLE9BQU8sT0FBTztDQUNoQyxJQUFJLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxZQUFZLEVBQUUsV0FBVyxPQUFPLEVBQUUsV0FBVyxFQUFFO0NBQzVFLElBQUksRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLFdBQVcsRUFBRSxRQUFRO0VBQ2xELElBQUksRUFBRSxPQUFPLFdBQVcsRUFBRSxNQUFNLEdBQUcsT0FBTztFQUMxQyxJQUFJLEVBQUUsT0FBTyxXQUFXLEVBQUUsTUFBTSxHQUFHLE9BQU87Q0FDM0M7Q0FDQSxJQUFJLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsUUFBUTtFQUNsRCxJQUFJLEVBQUUsT0FBTyxTQUFTLEVBQUUsTUFBTSxHQUFHLE9BQU87RUFDeEMsSUFBSSxFQUFFLE9BQU8sU0FBUyxFQUFFLE1BQU0sR0FBRyxPQUFPO0NBQ3pDO0NBQ0EsSUFBSSxFQUFFLFVBQVUsQ0FBQyxFQUFFLFFBQVEsT0FBTztDQUNsQyxJQUFJLENBQUMsRUFBRSxVQUFVLEVBQUUsUUFBUSxPQUFPO0NBQ2xDLElBQUksRUFBRSxVQUFVLENBQUMsRUFBRSxRQUFRLE9BQU87Q0FDbEMsSUFBSSxDQUFDLEVBQUUsVUFBVSxFQUFFLFFBQVEsT0FBTztDQUNsQyxJQUFJLEVBQUUsaUJBQWlCLENBQUMsRUFBRSxlQUFlLE9BQU87Q0FDaEQsSUFBSSxDQUFDLEVBQUUsaUJBQWlCLEVBQUUsZUFBZSxPQUFPO0NBQ2hELE9BQU87QUFDUjtBQUNBLFNBQVMsa0JBQWtCLFFBQVEsT0FBTyxHQUFHLGVBQWUsUUFBUSxRQUFRO0NBQzNFLE9BQU87RUFDTjtFQUNBLE9BQU8sU0FBUyxPQUFPLFFBQVEsSUFBSTtFQUNuQyxVQUFVO0VBQ1YsT0FBTztFQUNQLFFBQVE7RUFDUixtQkFBbUI7RUFDbkIsU0FBUztFQUNULFVBQVU7RUFDVixVQUFVO0VBQ1YsT0FBTztFQUNQLE1BQU0sS0FBSztFQUNYO0VBQ0EsT0FBTztFQUNQLFVBQVU7RUFDVjtFQUNBO0VBQ0E7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxrQkFBa0IsV0FBVyxlQUFlO0NBQ3BELE1BQU0sY0FBYyxrQkFBa0I7Q0FDdEMsTUFBTSxxQkFBcUIsQ0FBQztDQUM1QixTQUFTLE1BQU0sT0FBTyxPQUFPLFlBQVkscUJBQXFCO0VBQzdELE1BQU0sQ0FBQyxNQUFNLFFBQVEsWUFBWSxjQUFjLE9BQU8sT0FBTyxPQUFPLFlBQVksb0JBQW9CLG1CQUFtQjtFQUN2SCxJQUFJLE1BQU0sVUFBVSxLQUFLLE1BQU0sU0FBUyxNQUFNLFVBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTSxRQUFRO0NBQzVGO0NBQ0EsS0FBSyxNQUFNLFNBQVMsV0FBVyxNQUFNLE9BQU8sR0FBRyxXQUFXO0NBQzFELEtBQUssTUFBTSxTQUFTLG9CQUFvQixNQUFNLEtBQUssV0FBVztDQUM5RCxjQUFjLFlBQVk7Q0FDMUIsY0FBYyxZQUFZLGlCQUFpQixHQUFHO0FBQy9DOzs7O0FBSUEsU0FBUyxjQUFjLE1BQU0sZUFBZTtDQUMzQyxTQUFTO0NBQ1QsTUFBTSxTQUFTLGNBQWMsVUFBVSxJQUFJLElBQUk7Q0FDL0MsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPO0NBQzlCLE1BQU0sU0FBUyxVQUFVLE1BQU0sY0FBYyxTQUFTO0NBQ3RELGNBQWMsVUFBVSxJQUFJLE1BQU0sTUFBTTtDQUN4QyxPQUFPO0FBQ1I7Ozs7QUFJQSxTQUFTLGdCQUFnQixNQUFNLGVBQWUsT0FBTyxNQUFNLGVBQWU7Q0FDekUsU0FBUztDQUNULFNBQVM7Q0FDVCxNQUFNLE1BQU0sZ0JBQWdCLFNBQVMsU0FBUztDQUM5QyxJQUFJLE9BQU8sY0FBYyxZQUFZLElBQUksR0FBRztDQUM1QyxJQUFJLENBQUMsTUFBTTtFQUNWLE9BQU8sa0JBQWtCO0VBQ3pCLGNBQWMsZUFBZSxFQUFFLEtBQUssR0FBRyxHQUFHLElBQUk7RUFDOUMsY0FBYyxZQUFZLElBQUksS0FBSyxJQUFJO0NBQ3hDO0NBQ0EsT0FBTyxVQUFVLE1BQU0sTUFBTSxLQUFLO0FBQ25DO0FBQ0EsU0FBUyxlQUFlLE1BQU0sZUFBZSxRQUFRLE9BQU87Q0FDM0QsTUFBTSxNQUFNLFFBQVEsT0FBTyxXQUFXO0NBQ3RDLE1BQU0sU0FBUyxjQUFjLFdBQVcsSUFBSSxHQUFHO0NBQy9DLElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTztDQUM5QixTQUFTO0NBQ1QsSUFBSTtDQUNKLElBQUk7RUFDSCxTQUFTLFVBQVUsTUFBTSxjQUFjLGFBQWEsS0FBSztDQUMxRCxTQUFTLEtBQUs7RUFDYixJQUFJLGVBQWUsVUFBVSxTQUFTO09BQ2pDLE1BQU07Q0FDWjtDQUNBLElBQUksUUFBUSxPQUFPLFNBQVMsaUJBQWlCLE9BQU8sS0FBSztDQUN6RCxjQUFjLFdBQVcsSUFBSSxLQUFLLE1BQU07Q0FDeEMsT0FBTztBQUNSOzs7OztBQUtBLFNBQVMsaUJBQWlCLFdBQVcsZ0JBQWdCLE9BQU87Q0FDM0QsTUFBTSxjQUFjLGtCQUFrQjtDQUN0QyxNQUFNLHFCQUFxQixDQUFDO0NBQzVCLE1BQU0sYUFBYSxDQUFDO0NBQ3BCLE1BQU0sZUFBZSxDQUFDO0NBQ3RCLElBQUksUUFBUTtDQUNaLFNBQVMsTUFBTSxPQUFPLE9BQU8sWUFBWSxxQkFBcUI7RUFDN0QsTUFBTSxLQUFLLEtBQUs7RUFDaEIsSUFBSSxNQUFNLE1BQU0sWUFDNEIsTUFBTSxJQUFJLE1BQU0scURBQXFELE9BQU8sTUFBTSxFQUFFLEdBQUc7RUFHbkksV0FBVyxNQUFNLE1BQU07RUFDdkIsSUFBSSxVQUFVLEtBQUssTUFBTSxNQUFNO0dBQzlCLE1BQU0sa0JBQWtCLGNBQWMsTUFBTSxRQUFRO0dBQ3BELElBQUksQ0FBQyxhQUFhLG9CQUFvQixNQUFNLFNBQVMsU0FBUyxHQUFHLEdBQUcsYUFBYSxtQkFBbUI7RUFDckc7RUFDQTtFQUNBLE1BQU0sQ0FBQyxNQUFNLFFBQVEsWUFBWSxjQUFjLGVBQWUsT0FBTyxPQUFPLFlBQVksb0JBQW9CLG1CQUFtQjtFQUMvSCxNQUFNLGlCQUFpQjtFQUN2QixJQUFJLE1BQU0sVUFBVSxLQUFLLE1BQU0sU0FBUyxNQUFNLFVBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTSxRQUFRO0NBQzVGO0NBQ0EsTUFBTSxXQUFXLEdBQUcsV0FBVztDQUMvQixLQUFLLE1BQU0sU0FBUyxvQkFBb0IsTUFBTSxLQUFLLFdBQVc7Q0FDOUQsT0FBTztFQUNOLGVBQWU7R0FDZDtHQUNBLGFBQWEsaUJBQWlCLEdBQUc7R0FDakMsWUFBWSxpQkFBaUIsR0FBRztHQUNoQyxXQUFXO0dBQ1gsV0FBVztFQUNaO0VBQ0E7RUFDQTtDQUNEO0FBQ0Q7QUFDQSxTQUFTLFVBQVUsTUFBTSxhQUFhLFFBQVEsT0FBTztDQUNwRCxNQUFNLFFBQVEsS0FBSyxNQUFNLEdBQUc7Q0FDNUIsTUFBTSxPQUFPLGFBQWEsTUFBTSxPQUFPLGFBQWEsS0FBSztDQUN6RCxJQUFJLENBQUMsTUFBTSxPQUFPO0NBQ2xCLE1BQU0sQ0FBQyxhQUFhLGNBQWMsTUFBTSxPQUFPLElBQUk7Q0FDbkQsT0FBTztFQUNOLE9BQU8sS0FBSyxLQUFLO0VBQ2pCO0NBQ0Q7QUFDRDs7Ozs7Ozs7QUFRQSxTQUFTLGNBQWMsTUFBTSxPQUFPLE1BQU07Q0FDekMsTUFBTSxPQUFPLFlBQVksS0FBSyxJQUFJO0NBQ2xDLE1BQU0sUUFBUSxLQUFLLEtBQUssUUFBUSxjQUFjLEtBQUssS0FBSyxJQUFJO0NBQzVELE1BQU0sWUFBWSxPQUFPLE9BQU8sSUFBSTs7Q0FFcEMsSUFBSSxZQUFZLEtBQUssU0FBUyxRQUFROztDQUV0QyxJQUFJLFlBQVksS0FBSyxTQUFTLFFBQVE7O0NBRXRDLElBQUksWUFBWSxLQUFLLFNBQVMsUUFBUTs7Q0FFdEMsSUFBSSxhQUFhLEtBQUssU0FBUyxTQUFTO0NBQ3hDLE9BQU8sWUFBWSxLQUFLLFFBQVEsYUFBYSxhQUFhLGFBQWE7RUFDdEUsTUFBTSxPQUFPLEtBQUs7RUFDbEIsSUFBSSxLQUFLLFNBQVMsb0JBQW9CO0VBQ3RDLElBQUksS0FBSyxTQUFTLHVCQUF1QjtHQUN4QztHQUNBO0dBQ0E7RUFDRDtFQUNBLE1BQU0sT0FBTyxNQUFNO0VBQ25CLE1BQU0sbUJBQW1CO0VBQ3pCLElBQUksTUFBTSxhQUFhLEtBQUs7RUFDNUIsSUFBSSxLQUFLLFNBQVMsS0FBSyxLQUFLLFNBQVMsR0FBRztHQUN2QyxNQUFNLE9BQU8sTUFBTTtHQUNuQixJQUFJLEtBQUssU0FBUyxLQUFLLEtBQUssVUFBVSxLQUFLLFdBQVc7SUFDckQ7SUFDQSxZQUFZLG1CQUFtQjtJQUMvQjtHQUNEO0dBQ0EsTUFBTSxRQUFRLEtBQUssVUFBVSxLQUFLLFNBQVMsS0FBSyxVQUFVLEtBQUssT0FBTyxRQUFRLEtBQUssU0FBUyxLQUFLLE9BQU8sTUFBTSxJQUFJO0dBQ2xILElBQUksU0FBUyxLQUFLLFNBQVMsR0FBRyxVQUFVLFFBQVEsbUJBQW1CLEtBQUs7RUFDekUsT0FBTyxJQUFJLEtBQUssU0FBUyxHQUFHO0dBQzNCLE1BQU0sSUFBSTtHQUNWLE1BQU0sUUFBUSxLQUFLLFVBQVUsbUJBQW1CLEVBQUUsT0FBTyxRQUFRLEtBQUssU0FBUyxFQUFFLE9BQU8sTUFBTTtHQUM5RixNQUFNLFFBQVEsbUJBQW1CLEtBQUs7R0FDdEMsVUFBVSxPQUFPO0dBQ2pCLFVBQVUsU0FBUztHQUNuQjtFQUNEO0NBQ0Q7Q0FDQSxJQUFJLEtBQUssV0FBVyxPQUFPLE9BQU8sV0FBVyxLQUFLLFNBQVM7Q0FDM0QsT0FBTyxDQUFDLFdBQVc7RUFDbEIsTUFBTTtFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sT0FBTztDQUNSLENBQUM7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLE9BQU87Q0FDaEMsTUFBTSxPQUFPLENBQUMsS0FBSztDQUNuQixPQUFPLE1BQU0sYUFBYTtFQUN6QixRQUFRLE1BQU07RUFDZCxLQUFLLEtBQUssS0FBSztDQUNoQjtDQUNBLEtBQUssUUFBUTtDQUNiLE9BQU87QUFDUjtBQUNBLFNBQVMsWUFBWSxNQUFNO0NBQzFCLE1BQU0sT0FBTyxNQUFNLEtBQUssUUFBUSxDQUFDO0NBQ2pDLEdBQUc7RUFDRixLQUFLLEtBQUssU0FBUztFQUNuQixPQUFPLEtBQUs7Q0FDYixTQUFTO0NBQ1QsT0FBTztBQUNSO0FBQ0EsU0FBUyxhQUFhLE1BQU0sT0FBTyxhQUFhLE9BQU87Q0FDdEQsSUFBSSxTQUFTLE9BQU8sWUFBWSxPQUFPLE9BQU87RUFDN0MsTUFBTSxZQUFZO0VBQ2xCLFNBQVM7Q0FDVjtDQUNBLE1BQU0sZ0JBQWdCLENBQUMsS0FBSyxLQUFLO0NBQ2pDLE1BQU0sY0FBYyxpQkFBaUIsU0FBUztDQUM5QyxNQUFNLGNBQWMsTUFBTSxVQUFVLGdCQUFnQixJQUFJO0NBQ3hELE1BQU0sUUFBUSxDQUFDO0VBQ2QsTUFBTTtFQUNOLE9BQU87RUFDUCxTQUFTO0VBQ1QsU0FBUztFQUNULFVBQVU7RUFDVixXQUFXO0NBQ1osQ0FBQztDQUNELElBQUksWUFBWTtDQUNoQixJQUFJLFlBQVk7Q0FDaEIsT0FBTyxNQUFNLFFBQVE7RUFDcEIsTUFBTSxRQUFRLE1BQU0sSUFBSTtFQUN4QixNQUFNLEVBQUUsTUFBTSxPQUFPLFNBQVMsU0FBUyxVQUFVLGNBQWM7RUFDL0QsSUFBSSxFQUFFLFNBQVMsY0FBYztFQUM3QixJQUFJLEtBQUssU0FBUyxLQUFLLEtBQUssU0FBUyxDQUFDLG9CQUFvQixXQUFXLEtBQUssR0FBRztFQUM3RSxJQUFJLEtBQUssT0FBTztHQUNmLElBQUksQ0FBQyxvQkFBb0IsTUFBTSxPQUFPLEtBQUssR0FBRztHQUM5QyxZQUFZLE1BQU07R0FDbEIsVUFBVSxNQUFNO0VBQ2pCO0VBQ0EsSUFBSSxTQUFTLEtBQUssU0FBUyxLQUFLLFNBQVMsc0JBQXNCLG9CQUFvQixXQUFXLEtBQUssR0FBRyxZQUFZO0VBQ2xILE1BQU0sZUFBZSxVQUFVO0VBQy9CLElBQUksY0FBYztHQUNqQixJQUFJLEtBQUssVUFBVSxDQUFDLGVBQWUsS0FBSyxTQUFTLHNCQUFzQixLQUFLLFNBQVMsTUFBTSxvQkFBb0IsV0FBVyxLQUFLLEdBQUcsWUFBWTtHQUM5SSxJQUFJLENBQUMsS0FBSyxZQUFZLENBQUMsS0FBSyxZQUFZLENBQUMsS0FBSyxTQUFTLENBQUMsS0FBSyxVQUFVO0VBQ3hFO0VBQ0EsTUFBTSxPQUFPLGVBQWUsS0FBSyxJQUFJLE1BQU07RUFDM0MsSUFBSTtFQUNKLElBQUksZ0JBQWdCLEtBQUssT0FBTztHQUMvQixNQUFNLGFBQWE7SUFDbEIsTUFBTSxLQUFLO0lBQ1g7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDRDtHQUNBLElBQUksYUFBYTtHQUNqQixJQUFJLEtBQUssTUFBTSxPQUNWO1FBQUEsQ0FBQyxvQkFBb0IsTUFBTSxPQUFPLFVBQVUsR0FBRyxhQUFhO0dBQUE7R0FFakUsSUFBSSxZQUFZO0lBQ2YsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsV0FBVyxxQkFBcUIsU0FBUyxXQUFXLEdBQUcsT0FBTztJQUM5RixJQUFJLG9CQUFvQixXQUFXLFVBQVUsR0FBRyxZQUFZO0dBQzdEO0VBQ0Q7RUFDQSxJQUFJLEtBQUssVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLFNBQVMsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQ3RFLE1BQU0sVUFBVSxLQUFLLFNBQVM7R0FDOUIsTUFBTSxFQUFFLFFBQVEsV0FBVztHQUMzQixJQUFJLFFBQVE7SUFDWCxJQUFJLGNBQWM7SUFDbEIsSUFBSSxFQUFFLFFBQVEsZ0JBQWdCLE9BQU8sY0FBYyxLQUFLLFlBQVksRUFBQSxDQUFHLFdBQVcsTUFBTSxHQUFHO0dBQzVGO0dBQ0EsSUFBSSxRQUFRO0lBQ1gsSUFBSSxjQUFjO0lBQ2xCLE1BQU0sTUFBTSxNQUFNLE1BQU0sS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHO0lBQ3ZDLE1BQU0sYUFBYSxJQUFJLE1BQU0sQ0FBQyxPQUFPLE1BQU07SUFDM0MsS0FBSyxRQUFRLGdCQUFnQixhQUFhLFdBQVcsWUFBWSxPQUFPLFVBQVUsSUFBSSxTQUFTLE9BQU8sU0FBUyxPQUFPLFFBQVE7R0FDL0g7R0FDQSxNQUFNLEtBQUs7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNELENBQUM7RUFDRjtFQUNBLElBQUksS0FBSyxVQUFVO0dBQ2xCLE1BQU0sY0FBYyxVQUFVLEtBQUssS0FBSyxRQUFRO0dBQ2hELEtBQUssSUFBSSxJQUFJLEtBQUssU0FBUyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7SUFDbkQsTUFBTSxVQUFVLEtBQUssU0FBUztJQUM5QixNQUFNLEtBQUs7S0FDVixNQUFNO0tBQ047S0FDQSxTQUFTO0tBQ1Q7S0FDQTtLQUNBO0tBQ0E7S0FDQTtJQUNELENBQUM7R0FDRjtHQUNBLElBQUksQ0FBQyxjQUFjLEtBQUssSUFBSSxJQUFJLEtBQUssU0FBUyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7SUFDdEUsTUFBTSxVQUFVLEtBQUssU0FBUztJQUM5QixNQUFNLEVBQUUsUUFBUSxXQUFXO0lBQzNCLElBQUksVUFBVSxRQUFRO0tBQ3JCLE1BQU0sV0FBVyxRQUFRLGdCQUFnQixPQUFPLGNBQWMsS0FBSyxZQUFZO0tBQy9FLElBQUksVUFBVSxDQUFDLFNBQVMsV0FBVyxNQUFNLEdBQUc7S0FDNUMsSUFBSSxVQUFVLFNBQVMsUUFBUSxRQUFRLFNBQVMsU0FBUyxPQUFPLE1BQU0sSUFBSSxPQUFPLFFBQVE7SUFDMUY7SUFDQSxNQUFNLEtBQUs7S0FDVixNQUFNO0tBQ04sT0FBTyxRQUFRO0tBQ2Y7S0FDQTtLQUNBO0tBQ0EsV0FBVyxZQUFZLGFBQWEsYUFBYSxLQUFLO0tBQ3REO0tBQ0E7SUFDRCxDQUFDO0dBQ0Y7RUFDRDtFQUNBLElBQUksQ0FBQyxnQkFBZ0IsS0FBSyxXQUFXLE1BQU0sS0FBSyxJQUFJLElBQUksS0FBSyxRQUFRLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztHQUM3RixNQUFNLFVBQVUsS0FBSyxRQUFRO0dBQzdCLE1BQU0sRUFBRSxRQUFRLFdBQVc7R0FDM0IsSUFBSSxVQUFVLFFBQVE7SUFDckIsTUFBTSxXQUFXLFFBQVEsZ0JBQWdCLE9BQU8sY0FBYyxLQUFLLFlBQVk7SUFDL0UsSUFBSSxVQUFVLENBQUMsU0FBUyxXQUFXLE1BQU0sR0FBRztJQUM1QyxJQUFJLFVBQVUsU0FBUyxRQUFRLFFBQVEsU0FBUyxTQUFTLE9BQU8sTUFBTSxJQUFJLE9BQU8sUUFBUTtHQUMxRjtHQUNBLE1BQU0sS0FBSztJQUNWLE1BQU07SUFDTixPQUFPLFFBQVE7SUFDZjtJQUNBO0lBQ0EsVUFBVSxXQUFXLGFBQWEsYUFBYSxLQUFLO0lBQ3BEO0lBQ0E7SUFDQTtHQUNELENBQUM7RUFDRjtFQUNBLElBQUksQ0FBQyxnQkFBZ0IsS0FBSyxtQkFBbUI7R0FDNUMsTUFBTSxRQUFRLEtBQUssa0JBQWtCLElBQUksY0FBYyxLQUFLLFlBQVksQ0FBQztHQUN6RSxJQUFJLE9BQU8sTUFBTSxLQUFLO0lBQ3JCLE1BQU07SUFDTixPQUFPLFFBQVE7SUFDZjtJQUNBLFNBQVMsVUFBVSxhQUFhLGFBQWEsS0FBSztJQUNsRDtJQUNBO0lBQ0E7SUFDQTtHQUNELENBQUM7RUFDRjtFQUNBLElBQUksQ0FBQyxnQkFBZ0IsS0FBSyxRQUFRO0dBQ2pDLE1BQU0sUUFBUSxLQUFLLE9BQU8sSUFBSSxJQUFJO0dBQ2xDLElBQUksT0FBTyxNQUFNLEtBQUs7SUFDckIsTUFBTTtJQUNOLE9BQU8sUUFBUTtJQUNmO0lBQ0EsU0FBUyxVQUFVLGFBQWEsYUFBYSxLQUFLO0lBQ2xEO0lBQ0E7SUFDQTtJQUNBO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsSUFBSSxLQUFLLFVBQVUsS0FBSyxJQUFJLElBQUksS0FBSyxTQUFTLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztHQUN0RSxNQUFNLFVBQVUsS0FBSyxTQUFTO0dBQzlCLE1BQU0sS0FBSztJQUNWLE1BQU07SUFDTjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNELENBQUM7RUFDRjtDQUNEO0NBQ0EsSUFBSSxXQUFXLE9BQU87Q0FDdEIsSUFBSSxTQUFTLFdBQVc7RUFDdkIsSUFBSSxhQUFhLFVBQVU7RUFDM0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsT0FBTyxLQUFLLGNBQWMsTUFBTSxFQUFFLENBQUM7RUFDakUsTUFBTSxRQUFRLGVBQWUsS0FBSyxTQUFTLE1BQU0sS0FBSyxNQUFNLFVBQVU7RUFDdEUsVUFBVSxjQUFjLE9BQU8sT0FBTyxJQUFJO0VBQzFDLFVBQVUsVUFBVSxRQUFRLG1CQUFtQixLQUFLO0VBQ3BELE9BQU87Q0FDUjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsYUFBYSxhQUFhLE9BQU87Q0FDekMsT0FBTyxNQUFNLGNBQWMsUUFBUTtBQUNwQztBQUNBLFNBQVMscUJBQXFCLFNBQVMsYUFBYTtDQUNuRCxPQUFPLFlBQVksTUFBTSxjQUFjLEtBQUs7QUFDN0M7QUFDQSxTQUFTLG9CQUFvQixNQUFNLE9BQU8sT0FBTztDQUNoRCxJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7RUFDSCxDQUFDLFdBQVcsU0FBUyxjQUFjLE1BQU0sT0FBTyxLQUFLO0NBQ3RELFFBQVE7RUFDUCxPQUFPO0NBQ1I7Q0FDQSxNQUFNLFlBQVk7Q0FDbEIsTUFBTSxVQUFVO0NBQ2hCLElBQUksQ0FBQyxNQUFNLEtBQUssT0FBTyxPQUFPO0NBQzlCLElBQUk7RUFDSCxJQUFJLE1BQU0sS0FBSyxNQUFNLFNBQVMsTUFBTSxPQUFPLE9BQU87Q0FDbkQsUUFBUSxDQUFDO0NBQ1QsT0FBTztBQUNSO0FBQ0EsU0FBUyxvQkFBb0IsTUFBTSxNQUFNO0NBQ3hDLElBQUksQ0FBQyxNQUFNLE9BQU87Q0FDbEIsT0FBTyxLQUFLLFVBQVUsS0FBSyxXQUFXLEtBQUssWUFBWSxLQUFLLFlBQVksS0FBSyxXQUFXLEtBQUssWUFBWSxLQUFLLGFBQWEsS0FBSyxhQUFhLEtBQUssWUFBWSxLQUFLLGFBQWEsS0FBSyxjQUFjLEtBQUssZUFBZSxLQUFLLEtBQUssU0FBUyx1QkFBdUIsS0FBSyxLQUFLLFNBQVMsdUJBQXVCLEtBQUssS0FBSyxTQUFTLHdCQUF3QixLQUFLLEtBQUssU0FBUyx1QkFBdUIsS0FBSyxLQUFLLFFBQVEsS0FBSyxLQUFLO0FBQzdaOzs7QUMvakJBLFNBQVMsd0JBQXdCO0NBQ2hDLElBQUk7RUFDSCxPQUFPO0NBQ1IsUUFBUTtFQUNQO0NBQ0Q7QUFDRDtBQUNBLElBQU0sYUFBYTtBQUNuQixJQUFNLHFCQUFxQixzQkFBc0I7QUFDakQsU0FBUywrQkFBK0I7Q0FDdkMsSUFBSTtFQUNILE9BQU8sS0FBSyxNQUFNLG9CQUFvQixRQUFRLDZCQUE2QixLQUFLLElBQUk7Q0FDckYsUUFBUTtFQUNQLE9BQU8sQ0FBQztDQUNUO0FBQ0Q7QUFDQSxJQUFNLHlCQUF5Qyw2Q0FBNkI7QUFDNUUsSUFBTSwrQkFBK0I7Ozs7Ozs7QUFPckMsSUFBTSxrQ0FBa0MsYUFBYTtDQUNwRCxPQUFPLFNBQVMsTUFBTSxhQUFhLFNBQVM7QUFDN0M7QUFDQSxTQUFTLDZCQUE2QixTQUFTO0NBQzlDLE1BQU0sU0FBUyxRQUFRLGFBQWEsNEJBQTRCO0NBQ2hFLElBQUksUUFBUSxPQUFPLElBQUksNkJBQTZCLElBQUksT0FBTztDQUMvRCxJQUFJLFdBQVc7Q0FDZixJQUFJLEtBQUs7Q0FDVCxJQUFJO0NBQ0osT0FBTyxTQUFTLEdBQUcsWUFBWTtFQUM5QixJQUFJLFFBQVE7RUFDWixJQUFJLFVBQVU7RUFDZCxPQUFPLFVBQVUsUUFBUSx3QkFBd0I7RUFDakQsTUFBTSxPQUFPLEdBQUcsR0FBRyxVQUFVLGFBQWEsTUFBTTtFQUNoRCxXQUFXLFdBQVcsR0FBRyxLQUFLLEtBQUssYUFBYTtFQUNoRCxLQUFLO0NBQ047Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLGlDQUFpQyxRQUFRLFNBQVM7Q0FFMUQsTUFBTSxVQUFVLHdCQURJLFFBQVEsVUFBVSwrQkFBQSxDQUFnQyxPQUFPLGNBQ3RDO0NBQ3ZDLElBQUksQ0FBQyxTQUFTO0NBQ2QsSUFBSSxRQUFRLElBQUksT0FBTyxRQUFRLElBQUksNkJBQTZCLElBQUksUUFBUSxHQUFHO0NBQy9FLE1BQU0sVUFBVSxRQUFRLGFBQWE7Q0FDckMsSUFBSSxDQUFDLFNBQVM7Q0FDZCxPQUFPLFFBQVEsWUFBWSxTQUFTLHFCQUFxQiw2QkFBNkIsT0FBTztBQUM5RjtBQUNBLElBQUksZUFBZTtBQUNuQixJQUFNLHFCQUFxQjtBQUMzQixTQUFTLFdBQVcsVUFBVTtDQUM3QixJQUFJO0VBQ0gsT0FBTyxPQUFPLGFBQWEsYUFBYSxTQUFTLElBQUksU0FBUyxjQUFjLFFBQVE7Q0FDckYsUUFBUSxDQUFDO0FBQ1Y7QUFDQSxTQUFTLHVCQUF1QixzQkFBc0I7Q0FDckQsTUFBTSwyQkFBMkIsSUFBSSxJQUFJO0NBQ3pDLEtBQUssTUFBTSxZQUFZLHNCQUFzQjtFQUM1QyxJQUFJLGFBQWEsb0JBQW9CO0VBQ3JDLE1BQU0sVUFBVSxXQUFXLFFBQVE7RUFDbkMsSUFBSSxTQUFTLFNBQVMsSUFBSSxPQUFPO0NBQ2xDO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyx1QkFBdUIsUUFBUSxPQUFPO0NBQzlDLE1BQU0sK0JBQStCLFNBQVMsT0FBTyxRQUFRO0NBQzdELE1BQU0sU0FBUyxPQUFPO0NBQ3RCLElBQUksOEJBQThCLE9BQU8sSUFBSTtDQUM3QyxJQUFnQixPQUFPLFVBQVU7Q0FDakMsTUFBTSxTQUFTLE9BQU8sUUFBUSwyQkFBMkI7Q0FDekQsTUFBTSx1Q0FBdUMsSUFBSSxJQUFJO0NBQ3JELE1BQU0sZ0NBQWdDLGVBQWU7RUFDcEQsTUFBTSxXQUFXLHVCQUF1QixnQkFBZ0IsQ0FBQztFQUN6RCxLQUFLLE1BQU0sVUFBVSxzQkFBc0IsSUFBSSxXQUFXLFVBQVUsU0FBUyxzQkFBc0I7R0FDbEc7R0FDQTtFQUNEO09BQ0ssSUFBSSxPQUFPLGFBQWEsU0FBUyw2QkFBNkIsTUFBTSxLQUFLO0dBQzdFLFNBQVMsT0FBTztHQUNoQixTQUFTLE9BQU87RUFDakI7Q0FDRDtDQUNBLElBQUksZ0NBQWdDLENBQUMsT0FBTyxHQUFHO0VBQzlDLE9BQU8sSUFBSTtFQUNYLGVBQWU7RUFDZixRQUFRLG9CQUFvQjtFQUM1QixTQUFTLGlCQUFpQixXQUFXLFVBQVU7R0FDOUMsSUFBSSxjQUFjO0dBQ2xCLHFCQUFxQixJQUFJLE1BQU0sTUFBTTtFQUN0QyxHQUFHLElBQUk7RUFDUCxPQUFPLFVBQVUsaUJBQWlCLFVBQVU7R0FDM0MsSUFBSSxNQUFNLGNBQWMsNkJBQTZCLE9BQU8sTUFBTSxZQUFZLENBQUM7R0FDL0UscUJBQXFCLE1BQU07RUFDNUIsQ0FBQztFQUNELGlCQUFpQixrQkFBa0I7R0FDbEMsUUFBUSxvQkFBb0I7R0FDNUIsNkJBQTZCLE9BQU8sT0FBTyxPQUFPLGlCQUFpQixJQUFJLEtBQUssT0FBTyxPQUFPLFNBQVMsSUFBSSxDQUFDLENBQUM7R0FDekcsSUFBSTtJQUNILG9CQUFvQixRQUFRLFlBQVksS0FBSyxVQUFVLHNCQUFzQixDQUFDO0dBQy9FLFFBQVE7SUFDb0MsUUFBUSxLQUFLLDJFQUEyRTtHQUNwSTtFQUNELENBQUM7RUFDRCxpQkFBaUIsYUFBYSxVQUFVO0dBQ3ZDLElBQUksTUFBTSxXQUFXLFFBQVEsb0JBQW9CO0VBQ2xELENBQUM7Q0FDRjtDQUNBLElBQUksT0FBTyxHQUFHO0NBQ2QsT0FBTyxJQUFJO0NBQ1gsT0FBTyxVQUFVLGVBQWUsVUFBVTtFQUN6QyxNQUFNLFdBQVcsT0FBTyxRQUFRO0VBQ2hDLE1BQU0sdUJBQXVCLE9BQU8sUUFBUTtFQUM1QyxNQUFNLG9CQUFvQixPQUFPO0VBQ2pDLE1BQU0saUJBQWlCLE9BQU87RUFDOUIsSUFBSTtFQUNKLHFCQUFxQixNQUFNO0VBQzNCLE9BQU8sSUFBSTtFQUNYLE9BQU8sSUFBSTtFQUNYLElBQUksT0FBTyxPQUFPLFFBQVEsc0JBQXNCLGNBQWMsQ0FBQyxPQUFPLFFBQVEsa0JBQWtCLEVBQUUsVUFBVSxPQUFPLGVBQWUsQ0FBQyxHQUFHO0VBQ3RJLE1BQU0sV0FBVyxPQUFPLE1BQU0sVUFBVTtFQUN4QyxNQUFNLGVBQWUsTUFBTSxnQkFBZ0IsT0FBTyxNQUFNLFlBQVk7RUFDcEUsSUFBSSxPQUFPLEtBQUssZ0JBQWdCLGlCQUFpQixVQUFVO0dBQzFELE1BQU0scUJBQXFCLHVCQUF1QjtHQUNsRCxJQUFJLG9CQUFvQjtJQUN2QixJQUFJLG1CQUFtQix1QkFBdUI7SUFDOUMsS0FBSyxNQUFNLG1CQUFtQixvQkFBb0I7S0FDakQsSUFBSSxvQkFBb0Isb0JBQ25CO1VBQUEsbUJBQW1CO0tBQUEsT0FDakI7TUFDTixNQUFNLFVBQVUsV0FBVyxlQUFlO01BQzFDLElBQUksQ0FBQyxTQUFTO01BQ2QsSUFBSSxxQkFBcUIsc0JBQXNCO09BQzlDLHdCQUF3Qix1QkFBdUIsb0JBQW9CO09BQ25FLElBQUksb0JBQW9CLElBQUksT0FBTyxHQUFHO01BQ3ZDO0tBQ0Q7S0FDQSxJQUFJLENBQUMsa0JBQWtCLG1CQUFtQix1QkFBdUIsWUFBWSxDQUFDO0tBQzlFLGlCQUFpQixxQkFBcUIsbUJBQW1CO0lBQzFEO0dBQ0Q7RUFDRDtFQUNBLGVBQWU7RUFDZixJQUFJO0dBQ0gsTUFBTSxPQUFPLE1BQU0sV0FBVztHQUM5QixNQUFNLDRCQUE0QixNQUFNLFdBQVcsTUFBTSwrQkFBK0I7R0FDeEYsSUFBSSxpQkFBaUI7R0FDckIsSUFBSSxtQkFBbUI7SUFDdEIsSUFBSSxDQUFDLFFBQVEsc0JBQXNCLHdCQUF3Qix1QkFBdUIsb0JBQW9CO0lBQ3RHLE1BQU0sb0JBQW9CLFFBQVEsNkJBQTZCO0lBQy9ELE1BQU0saUJBQWlCLE9BQU8sSUFBSSx1QkFBdUIsWUFBWSxLQUFLO0lBQzFFLElBQUksZ0JBQWdCLEtBQUssTUFBTSxtQkFBbUIsZ0JBQWdCO0tBQ2pFLE1BQU0sRUFBRSxTQUFTLFlBQVksZUFBZTtLQUM1QyxJQUFJLG9CQUFvQixvQkFBb0I7TUFDM0MsSUFBSSxtQkFBbUI7TUFDdkIsU0FBUztPQUNSLEtBQUs7T0FDTCxNQUFNO09BQ047TUFDRCxDQUFDO01BQ0QsaUJBQWlCO0tBQ2xCLE9BQU87TUFDTixNQUFNLFVBQVUsV0FBVyxlQUFlO01BQzFDLElBQUksU0FBUztPQUNaLFFBQVEsYUFBYTtPQUNyQixRQUFRLFlBQVk7T0FDcEIscUJBQXFCLE9BQU8sT0FBTztNQUNwQztLQUNEO0lBQ0Q7SUFDQSxJQUFJLENBQUMsTUFBTTtLQUNWLE1BQU0sZ0JBQWdCO01BQ3JCLEtBQUs7TUFDTCxNQUFNO01BQ047S0FDRDtLQUNBLElBQUksQ0FBQyxnQkFBZ0IsU0FBUyxhQUFhO0tBQzNDLElBQUkscUJBQXFCLEtBQUssTUFBTSxXQUFXLHFCQUFxQixRQUFRLFNBQVMsYUFBYTtJQUNuRztHQUNEO0dBQ0EsSUFBSSxDQUFDLGtCQUFrQixRQUFRLDJCQUEyQixTQUFTLGVBQWUsSUFBSSxDQUFDLEVBQUUsZUFBZSx5QkFBeUI7RUFDbEksVUFBVTtHQUNULGVBQWU7RUFDaEI7Q0FDRCxDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEtBLFNBQVMsT0FBTyxLQUFLLFlBQVksUUFBUTtDQUN4QyxJQUFJO0NBQ0osS0FBSyxNQUFNLE9BQU8sS0FBSztFQUN0QixNQUFNLE1BQU0sSUFBSTtFQUNoQixJQUFJLFFBQVEsS0FBSyxHQUFHLENBQUMsV0FBVyxJQUFJLGdCQUFnQixFQUFBLENBQUcsSUFBSSxLQUFLLFVBQVUsR0FBRyxDQUFDO0NBQy9FO0NBQ0EsT0FBTyxTQUFTLE9BQU8sU0FBUyxJQUFJO0FBQ3JDOzs7Ozs7Ozs7QUFTQSxTQUFTLFFBQVEsS0FBSztDQUNyQixJQUFJLENBQUMsS0FBSyxPQUFPO0NBQ2pCLElBQUksUUFBUSxTQUFTLE9BQU87Q0FDNUIsSUFBSSxRQUFRLFFBQVEsT0FBTztDQUMzQixPQUFPLENBQUMsTUFBTSxNQUFNLEtBQUssQ0FBQyxNQUFNLE9BQU8sTUFBTSxDQUFDLE1BQU07QUFDckQ7Ozs7Ozs7OztBQVNBLFNBQVMsT0FBTyxLQUFLO0NBQ3BCLE1BQU0sZUFBZSxJQUFJLGdCQUFnQixHQUFHO0NBQzVDLE1BQU0sU0FBUyxPQUFPLE9BQU8sSUFBSTtDQUNqQyxLQUFLLE1BQU0sQ0FBQyxLQUFLLFVBQVUsYUFBYSxRQUFRLEdBQUc7RUFDbEQsTUFBTSxnQkFBZ0IsT0FBTztFQUM3QixJQUFJLGlCQUFpQixNQUFNLE9BQU8sT0FBTyxRQUFRLEtBQUs7T0FDakQsSUFBSSxNQUFNLFFBQVEsYUFBYSxHQUFHLGNBQWMsS0FBSyxRQUFRLEtBQUssQ0FBQztPQUNuRSxPQUFPLE9BQU8sQ0FBQyxlQUFlLFFBQVEsS0FBSyxDQUFDO0NBQ2xEO0NBQ0EsT0FBTztBQUNSOzs7QUM5REEsSUFBTSxZQUFZOztBQUVsQixJQUFNLHFCQUFxQixnQkFBZ0IsS0FBSyxLQUFLOztBQUVyRCxJQUFNLHlCQUF5QixvQkFBb0IsS0FBSyxXQUFXLEtBQUssS0FBSzs7Ozs7Ozs7Ozs7QUFXN0UsU0FBUyxnQkFBZ0IsUUFBUTtDQUNoQyxNQUFNLGVBQWUsV0FBVyxLQUFLO0NBQ3JDLFFBQVEsY0FBYztFQUNyQixJQUFJLFVBQVUsT0FBTyxLQUFLLFlBQVksVUFBVSxNQUFNLENBQUM7RUFDdkQsTUFBTSxRQUFRLE9BQU8sU0FBUztFQUM5QixLQUFLLE1BQU0sT0FBTyxPQUFPO0dBQ3hCLE1BQU0sUUFBUSxNQUFNO0dBQ3BCLElBQUksT0FBTyxVQUFVLFVBQVU7SUFDOUIsSUFBSSxnQkFBZ0IsQ0FBQyxVQUFVLEtBQUssS0FBSyxHQUFHO0lBQzVDLElBQUk7S0FDSCxNQUFNLE9BQU8sT0FBTyxLQUFLO0lBQzFCLFNBQVMsTUFBTSxDQUFDO0dBQ2pCO0VBQ0Q7RUFDQSxPQUFPO0NBQ1I7QUFDRDs7Ozs7Ozs7Ozs7OztBQWFBLFNBQVMsb0JBQW9CLFdBQVcsUUFBUTtDQUMvQyxNQUFNLGVBQWUsV0FBVyxLQUFLO0NBQ3JDLFNBQVMsZUFBZSxLQUFLO0VBQzVCLElBQUksT0FBTyxPQUFPLFFBQVEsVUFBVSxJQUFJO0dBQ3ZDLE9BQU8sVUFBVSxHQUFHO0VBQ3JCLFNBQVMsTUFBTSxDQUFDO09BQ1gsSUFBSSxVQUFVLE9BQU8sUUFBUSxVQUFVO0dBQzNDLElBQUksZ0JBQWdCLENBQUMsVUFBVSxLQUFLLEdBQUcsR0FBRyxPQUFPO0dBQ2pELElBQUk7SUFDSCxPQUFPLEdBQUc7SUFDVixPQUFPLFVBQVUsR0FBRztHQUNyQixTQUFTLE1BQU0sQ0FBQztFQUNqQjtFQUNBLE9BQU87Q0FDUjtDQUNBLFFBQVEsV0FBVztFQUNsQixNQUFNLFlBQVksT0FBTyxRQUFRLGNBQWM7RUFDL0MsT0FBTyxZQUFZLElBQUksY0FBYztDQUN0QztBQUNEOzs7O0FDOURBLFNBQVMsZ0JBQWdCLFVBQVU7Q0FDbEMsT0FBTztFQUNOLFFBQVEsRUFBRSxVQUFVO0dBQ25CLEtBQUssTUFBTSxXQUFXLFVBQVUsTUFBTSxvQkFBb0IsU0FBUyxHQUFHO0dBQ3RFLE9BQU87RUFDUjtFQUNBLFNBQVMsRUFBRSxVQUFVO0dBQ3BCLEtBQUssSUFBSSxJQUFJLFNBQVMsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLLE1BQU0scUJBQXFCLFNBQVMsSUFBSSxHQUFHO0dBQzFGLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBRUEsU0FBUyxnQkFBZ0IsVUFBVSxlQUFlLFNBQVM7Q0FDMUQsTUFBTSxrQkFBa0IsU0FBUyxRQUFRO0NBQ3pDLE1BQU0scUJBQXFCLElBQUk7Q0FDL0IsTUFBTSxnQkFBZ0IsZ0JBQWdCLHFCQUFxQixtQkFBbUIsWUFBWTtDQUMxRixNQUFNLHlCQUF5QixHQUFHLGNBQWM7Q0FDaEQsTUFBTSxrQkFBa0I7RUFDdkIsUUFBUSxFQUFFLFVBQVU7R0FDbkIsTUFBTSxXQUFXLGdCQUFnQixJQUFJLFdBQVcsSUFBSSxTQUFTLFlBQVk7R0FDekUsSUFBSSxhQUFhLGVBQWUsSUFBSSxXQUFXO1FBQzFDLElBQUksU0FBUyxXQUFXLHNCQUFzQixHQUFHLElBQUksV0FBVyxJQUFJLFNBQVMsTUFBTSxtQkFBbUIsTUFBTTtHQUNqSCxPQUFPO0VBQ1I7RUFDQSxTQUFTLEVBQUUsVUFBVTtHQUNwQixJQUFJLFdBQVcsVUFBVSxJQUFJLGtCQUFrQixJQUFJLFVBQVU7R0FDN0QsT0FBTztFQUNSO0NBQ0Q7Q0FDQSxPQUFPLFVBQVU7RUFDaEIsUUFBUSxFQUFFLFVBQVUsb0JBQW9CLFNBQVMsZ0JBQWdCLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztFQUMvRSxTQUFTLEVBQUUsVUFBVSxnQkFBZ0IsT0FBTyxFQUFFLEtBQUsscUJBQXFCLFNBQVMsR0FBRyxFQUFFLENBQUM7Q0FDeEYsSUFBSTtBQUNMOztBQUVBLFNBQVMsb0JBQW9CLFNBQVMsS0FBSztDQUMxQyxNQUFNLE1BQU0sU0FBUyxRQUFRLEVBQUUsSUFBSSxDQUFDO0NBQ3BDLElBQUksS0FBSztFQUNSLElBQUksT0FBTyxRQUFRLFVBQVUsT0FBTyxJQUFJLElBQUksR0FBRztPQUMxQyxJQUFJLGVBQWUsS0FBSyxPQUFPO0NBQ3JDO0NBQ0EsT0FBTztBQUNSOztBQUVBLFNBQVMscUJBQXFCLFNBQVMsS0FBSztDQUMzQyxNQUFNLE1BQU0sU0FBUyxTQUFTLEVBQUUsSUFBSSxDQUFDO0NBQ3JDLElBQUksS0FBSztFQUNSLElBQUksT0FBTyxRQUFRLFVBQVUsT0FBTyxJQUFJLElBQUksR0FBRztPQUMxQyxJQUFJLGVBQWUsS0FBSyxPQUFPO0NBQ3JDO0NBQ0EsT0FBTztBQUNSOzs7O0FDcERBLFNBQVMsOEJBQThCLGNBQWM7Q0FDcEQsSUFBSSxRQUFRO0NBQ1osT0FBTztFQUNOLE1BQU07R0FDTCxPQUFPO0VBQ1I7RUFDQSxJQUFJLGVBQWU7R0FDbEIsUUFBUSxpQkFBaUIsZUFBZSxLQUFLO0VBQzlDO0NBQ0Q7QUFDRDs7QUFFQSxTQUFTLCtCQUErQixNQUFNO0NBQzdDLE9BQU8sRUFBRSxNQUFNO0VBQ2QsT0FBTyxLQUFLO0NBQ2IsRUFBRTtBQUNIO0FBQ0EsU0FBUyxtQkFBbUIsaUJBQWlCLFFBQVE7Q0FDcEQsTUFBTSxFQUFFLG9CQUFvQixxQkFBcUIsVUFBVTtDQUMzRCxNQUFNLDBCQUEwQixJQUFJLElBQUk7Q0FDeEMsTUFBTSxTQUFTLG1CQUFtQixNQUFNO0NBQ3hDLE1BQU0sV0FBVyxtQkFBbUIsZUFBZTtDQUNuRCxNQUFNLG1CQUFtQixtQkFBbUIsS0FBSyxDQUFDO0NBQ2xELE1BQU0sTUFBTSxtQkFBbUIsQ0FBQyxDQUFDO0NBQ2pDLE1BQU0sVUFBVSwwQkFBMEIsSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLE9BQU8sUUFBUSxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0NBQ3RGLE1BQU0sVUFBVSwyQkFBMkI7RUFDMUMsUUFBUSxPQUFPLElBQUk7RUFDbkIsV0FBVyxPQUFPLElBQUksTUFBTTtFQUM1QixTQUFTLFFBQVEsSUFBSTtFQUNyQixVQUFVLFNBQVMsSUFBSTtFQUN2QixrQkFBa0IsaUJBQWlCLElBQUk7Q0FDeEMsRUFBRTtDQUNGLFNBQVMsY0FBYyxTQUFTO0VBQy9CLElBQUksYUFBYSxRQUFRLElBQUksT0FBTztFQUNwQyxJQUFJLENBQUMsWUFBWTtHQUNoQixhQUFhLG1CQUFtQixLQUFLLENBQUM7R0FDdEMsUUFBUSxJQUFJLFNBQVMsVUFBVTtFQUNoQztFQUNBLE9BQU87Q0FDUjtDQUNBLE1BQU0sUUFBUTtFQUNiO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNEO0NBQ0EsU0FBUyxXQUFXLGFBQWE7RUFDaEMsTUFBTSxjQUFjLElBQUksSUFBSTtFQUM1QixNQUFNLFVBQVUsWUFBWSxLQUFLLFVBQVUsTUFBTSxPQUFPO0VBQ3hELFlBQVk7R0FDWCxJQUFJLENBQUMsWUFBWSxhQUFhLE9BQU8sR0FBRyxJQUFJLElBQUksT0FBTztHQUN2RCxLQUFLLE1BQU0sTUFBTSxhQUFhLElBQUksQ0FBQyxRQUFRLFNBQVMsRUFBRSxHQUFHLFFBQVEsSUFBSSxFQUFFLENBQUMsQ0FBQyxVQUFVLEtBQUssQ0FBQztHQUN6RixLQUFLLE1BQU0sYUFBYSxhQUFhO0lBQ3BDLE1BQU0sYUFBYSxjQUFjLFVBQVUsT0FBTztJQUNsRCxJQUFJLFdBQVcsSUFBSSxNQUFNLFdBQVcsV0FBVyxJQUFJLFNBQVM7R0FDN0Q7RUFDRCxDQUFDO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1I7OztBQ2xFQSxJQUFJLGdCQUFnQjtBQUNwQixJQUFJLGdCQUFnQjtBQUNwQixJQUFJLG9CQUFvQjs7Ozs7Ozs7OztBQVV4QixJQUFJLHlCQUF5QjtBQUM3QixTQUFTLDBCQUEwQixLQUFLO0NBQ3ZDLE1BQU0sUUFBUSx1QkFBdUIsS0FBSyxHQUFHO0NBQzdDLE9BQU8sUUFBUSxNQUFNLElBQUksTUFBTSxNQUFNLEVBQUUsQ0FBQyxNQUFNLElBQUk7QUFDbkQ7QUFDQSxTQUFTLGNBQWMsTUFBTTtDQUM1QixJQUFJLGtCQUFrQixLQUFLLElBQUksR0FBRyxPQUFPLEtBQUssUUFBUSxxQkFBcUIsY0FBYyxRQUFRLFNBQVMsU0FBUyxJQUFJLEtBQUssbUJBQW1CLFNBQVMsQ0FBQztDQUN6SixPQUFPLDBCQUEwQixJQUFJO0FBQ3RDO0FBQ0EsU0FBUyxjQUFjLE1BQU07Q0FDNUIsSUFBSSxXQUFXLEtBQUssWUFBWTtDQUNoQyxNQUFNLDhCQUE4QixJQUFJLElBQUk7Q0FDNUMsTUFBTSxVQUFVLFdBQVc7RUFDMUIsV0FBVyxLQUFLLFlBQVk7RUFDNUIsWUFBWSxTQUFTLGVBQWUsV0FBVztHQUM5QztHQUNBO0VBQ0QsQ0FBQyxDQUFDO0NBQ0g7Q0FDQSxNQUFNLHFCQUFxQixXQUFXO0VBQ3JDLElBQUksS0FBSyx1QkFBdUIsTUFBTSxPQUFPLE1BQU07T0FDOUMsV0FBVyxLQUFLLFlBQVk7Q0FDbEM7Q0FDQSxNQUFNLGdCQUFnQixPQUFPLFNBQVM7RUFDckMsTUFBTSxXQUFXLEtBQUssY0FBYyxnQkFBZ0IsS0FBSyxJQUFJLEtBQUssY0FBYztFQUNoRixJQUFJLE9BQU8sYUFBYSxlQUFlLFVBQVUsV0FBVyxLQUFLLFNBQVMsVUFBVSxLQUFLLFNBQVMsWUFBWSxLQUFLLE1BQU0sV0FBVyxVQUFVO0dBQzdJLE1BQU0sZUFBZSxVQUFVLEtBQUssTUFBTSxLQUFLLEtBQUs7R0FDcEQsSUFBSSxNQUFNLFFBQVEsVUFBVTtJQUMzQixpQkFBaUI7SUFDakI7SUFDQSxRQUFRLEtBQUs7R0FDZCxDQUFDLEdBQUc7SUFDSCxLQUFLLFlBQVk7SUFDakI7R0FDRDtFQUNEO0VBQ0EsS0FBSyxLQUFLO0NBQ1g7Q0FDQSxPQUFPO0VBQ04sSUFBSSxXQUFXO0dBQ2QsT0FBTztFQUNSO0VBQ0EsSUFBSSxTQUFTO0dBQ1osT0FBTyxLQUFLLFVBQVU7RUFDdkI7RUFDQTtFQUNBLFlBQVksT0FBTztHQUNsQixZQUFZLElBQUksRUFBRTtHQUNsQixhQUFhO0lBQ1osWUFBWSxPQUFPLEVBQUU7R0FDdEI7RUFDRDtFQUNBLE9BQU8sTUFBTSxPQUFPLGlCQUFpQjtHQUNwQyxNQUFNLGVBQWUsU0FBUyxNQUFNO0dBQ3BDLFFBQVEsa0JBQWtCLGVBQWUsR0FBRyxLQUFLO0dBQ2pELGNBQWM7SUFDYixZQUFZO0tBQ1gsS0FBSyxVQUFVLE1BQU0sS0FBSztLQUMxQixPQUFPLEVBQUUsTUFBTSxPQUFPLENBQUM7SUFDeEI7SUFDQTtJQUNBLE1BQU07SUFDTjtJQUNBO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsVUFBVSxNQUFNLE9BQU8saUJBQWlCO0dBQ3ZDLE1BQU0sZUFBZSxTQUFTLE1BQU07R0FDcEMsUUFBUSxrQkFBa0IsY0FBYyxLQUFLO0dBQzdDLGNBQWM7SUFDYixZQUFZO0tBQ1gsS0FBSyxhQUFhLE1BQU0sS0FBSztLQUM3QixPQUFPLEVBQUUsTUFBTSxVQUFVLENBQUM7SUFDM0I7SUFDQTtJQUNBLE1BQU07SUFDTjtJQUNBO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsS0FBSyxPQUFPLGlCQUFpQjtHQUM1QixjQUFjO0lBQ2IsWUFBWTtLQUNYLEtBQUssR0FBRyxPQUFPLGNBQWMsaUJBQWlCLEtBQUs7S0FDbkQsa0JBQWtCO01BQ2pCLE1BQU07TUFDTjtLQUNELENBQUM7SUFDRjtJQUNBO0lBQ0EsTUFBTTtHQUNQLENBQUM7RUFDRjtFQUNBLE9BQU8saUJBQWlCO0dBQ3ZCLGNBQWM7SUFDYixZQUFZO0tBQ1gsS0FBSyxLQUFLLGNBQWMsaUJBQWlCLEtBQUs7S0FDOUMsa0JBQWtCLEVBQUUsTUFBTSxPQUFPLENBQUM7SUFDbkM7SUFDQTtJQUNBLE1BQU07R0FDUCxDQUFDO0VBQ0Y7RUFDQSxVQUFVLGlCQUFpQjtHQUMxQixjQUFjO0lBQ2IsWUFBWTtLQUNYLEtBQUssUUFBUSxjQUFjLGlCQUFpQixLQUFLO0tBQ2pELGtCQUFrQixFQUFFLE1BQU0sVUFBVSxDQUFDO0lBQ3RDO0lBQ0E7SUFDQSxNQUFNO0dBQ1AsQ0FBQztFQUNGO0VBQ0EsaUJBQWlCLFNBQVMsTUFBTSxtQkFBbUI7RUFDbkQsYUFBYSxRQUFRLEtBQUssV0FBVyxHQUFHO0VBQ3hDLFFBQVEsWUFBWTtHQUNuQixJQUFJLENBQUMsS0FBSyxhQUFhLGFBQWEsQ0FBQztHQUNyQyxNQUFNLFdBQVcsS0FBSyxjQUFjLEtBQUssQ0FBQztHQUMxQyxLQUFLLFlBQVksQ0FBQyxHQUFHLFVBQVUsT0FBTyxDQUFDO0dBQ3ZDLGFBQWE7SUFDWixNQUFNLFdBQVcsS0FBSyxjQUFjLEtBQUssQ0FBQztJQUMxQyxLQUFLLGNBQWMsU0FBUyxRQUFRLE1BQU0sTUFBTSxPQUFPLENBQUM7R0FDekQ7RUFDRDtFQUNBLGFBQWEsS0FBSyxRQUFRO0VBQzFCLGVBQWUsS0FBSyxVQUFVO0VBQzlCO0VBQ0Esb0JBQW9CLEtBQUssY0FBYyxLQUFLLENBQUM7Q0FDOUM7QUFDRDtBQUNBLFNBQVMsa0JBQWtCLE9BQU8sT0FBTztDQUN4QyxNQUFNLE1BQU0sZ0JBQWdCO0NBQzVCLE9BQU87RUFDTixHQUFHO0VBQ0g7RUFDQSxXQUFXO0dBQ1YsZ0JBQWdCO0NBQ2xCO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQVMscUJBQXFCLE1BQU07Q0FDbkMsTUFBTSxNQUFNLE1BQU0sV0FBVyxPQUFPLGFBQWEsY0FBYyxTQUFTLEtBQUs7Q0FDN0UsTUFBTSxvQkFBb0IsSUFBSSxRQUFRO0NBQ3RDLE1BQU0sdUJBQXVCLElBQUksUUFBUTtDQUN6QyxJQUFJLFdBQVcsQ0FBQztDQUNoQixNQUFNLHFCQUFxQjtDQUMzQixNQUFNLGdCQUFnQixnQkFBZ0IsV0FBVztDQUNqRCxNQUFNLGNBQWMsU0FBUyxjQUFjLE1BQU0sYUFBYSxLQUFLLFdBQVcsSUFBSSxJQUFJLElBQUk7Q0FDMUYsTUFBTSxnQkFBZ0IsTUFBTSx3QkFBd0IsVUFBVSxHQUFHLElBQUksU0FBUyxXQUFXLElBQUksU0FBUyxTQUFTLElBQUksU0FBUyxRQUFRLElBQUksUUFBUSxLQUFLO0NBQ3JKLElBQUksQ0FBQyxJQUFJLFFBQVEsT0FBTyxhQUFhLENBQUMsSUFBSSxRQUFRLE9BQU8sS0FBSztFQUM3RCxNQUFNLFdBQVcsZ0JBQWdCO0VBQ2pDLElBQUksUUFBUSxhQUFhO0lBQ3ZCLGdCQUFnQjtHQUNqQixLQUFLO0dBQ0wsV0FBVztFQUNaLEdBQUcsRUFBRTtDQUNOO0NBQ0EsSUFBSSxrQkFBa0IsY0FBYztDQUNwQyxJQUFJO0NBQ0osSUFBSSxjQUFjO0NBQ2xCLElBQUksZ0JBQWdCO0NBQ3BCLElBQUkscUJBQXFCO0NBQ3pCLElBQUkseUJBQXlCO0NBQzdCLE1BQU0sb0JBQW9CO0NBQzFCLElBQUk7Q0FDSixNQUFNLGNBQWM7RUFDbkIsSUFBSSxDQUFDLE1BQU07RUFDWCxRQUFRLHFCQUFxQjtFQUM3QixDQUFDLEtBQUssS0FBSyxJQUFJLFFBQVEsWUFBWSxJQUFJLFFBQVEsYUFBQSxDQUFjLEtBQUssSUFBSSxJQUFJLEtBQUssRUFBRTtFQUNqRixRQUFRLHFCQUFxQjtFQUM3QixPQUFPLEtBQUs7RUFDWixtQkFBbUIsS0FBSztDQUN6QjtDQUNBLE1BQU0sc0JBQXNCLFFBQVEsVUFBVSxVQUFVO0VBQ3ZELE1BQU0sT0FBTyxNQUFNLGFBQWEsV0FBVyxRQUFRLElBQUksS0FBSztFQUM1RCxNQUFNLG1CQUFtQixDQUFDLENBQUM7RUFDM0IsSUFBSSxDQUFDLGtCQUFrQixtQkFBbUI7RUFDMUMsa0JBQWtCLFVBQVUsVUFBVSxLQUFLO0VBQzNDLE9BQU87R0FDTixRQUFRLGdCQUFnQjtHQUN4QjtHQUNBLE9BQU8sTUFBTTtFQUNkO0VBQ0EsSUFBSSxDQUFDLGtCQUFrQixxQkFBcUIsTUFBTSxDQUFDO0NBQ3BEO0NBQ0EsTUFBTSxhQUFhLFNBQVM7RUFDM0Isa0JBQWtCLGNBQWM7RUFDaEMsUUFBUSxPQUFPLEVBQUUsS0FBSyxDQUFDO0NBQ3hCO0NBQ0EsTUFBTSxpQkFBaUIsWUFBWTtFQUNsQyx5QkFBeUI7RUFDekIsSUFBSSxlQUFlO0dBQ2xCLGdCQUFnQjtHQUNoQjtFQUNEO0VBQ0EsTUFBTSxlQUFlLGNBQWM7RUFDbkMsTUFBTSxRQUFRLGFBQWEsTUFBTSxpQkFBaUIsZ0JBQWdCLE1BQU07RUFDeEUsTUFBTSxZQUFZLFVBQVU7RUFDNUIsTUFBTSxTQUFTLFVBQVU7RUFDekIsTUFBTSxPQUFPLENBQUMsYUFBYSxDQUFDLFVBQVU7RUFDdEMsY0FBYztFQUNkLE1BQU0sU0FBUyxPQUFPLE9BQU8sU0FBUyxTQUFTO0VBQy9DLE1BQU0sU0FBUyxPQUFPO0dBQ3JCLE1BQU07R0FDTixPQUFPO0VBQ1IsSUFBSSxFQUFFLE1BQU0sU0FBUyxTQUFTLFVBQVU7RUFDeEMsSUFBSSxvQkFBb0IscUJBQXFCO09BQ3hDO0dBQ0osTUFBTSxXQUFXLGFBQWE7R0FDOUIsSUFBSSxPQUFPLGFBQWEsZUFBZSxTQUFTLFFBQzFDO1NBQUEsTUFBTSxXQUFXLFVBQVUsSUFBSSxNQUFNLFFBQVEsVUFBVTtLQUMzRDtLQUNBO0tBQ0E7SUFDRCxDQUFDLEdBQUc7S0FDSCxnQkFBZ0I7S0FDaEIsSUFBSSxRQUFRLEdBQUcsQ0FBQyxLQUFLO0tBQ3JCLFFBQVEsT0FBTyxNQUFNO0tBQ3JCO0lBQ0Q7O0VBRUY7RUFDQSxrQkFBa0IsY0FBYztFQUNoQyxRQUFRLE9BQU8sTUFBTTtDQUN0QjtDQUNBLE1BQU0sa0JBQWtCLE1BQU07RUFDN0IsSUFBSSx3QkFBd0I7R0FDM0IseUJBQXlCO0dBQ3pCO0VBQ0Q7RUFDQSxJQUFJLGNBQWM7RUFDbEIsTUFBTSxXQUFXLGFBQWE7RUFDOUIsSUFBSSxPQUFPLGFBQWEsZUFBZSxTQUFTLFFBQVEsS0FBSyxNQUFNLFdBQVcsVUFBVTtHQUN2RixNQUFNLHlCQUF5QixRQUFRLHNCQUFzQjtHQUM3RCxJQUFJLDJCQUEyQixNQUFNO0lBQ3BDLGNBQWM7SUFDZDtHQUNEO0dBQ0EsSUFBSSxPQUFPLDJCQUEyQixjQUFjLHVCQUF1QixNQUFNLE1BQU07SUFDdEYsY0FBYztJQUNkO0dBQ0Q7RUFDRDtFQUNBLElBQUksYUFBYTtHQUNoQixFQUFFLGVBQWU7R0FDakIsT0FBTyxFQUFFLGNBQWM7RUFDeEI7Q0FDRDtDQUNBLE1BQU0sVUFBVSxjQUFjO0VBQzdCO0VBQ0EsaUJBQWlCLElBQUksUUFBUTtFQUM3QixZQUFZLE1BQU0sVUFBVSxtQkFBbUIsTUFBTSxNQUFNLEtBQUs7RUFDaEUsZUFBZSxNQUFNLFVBQVUsbUJBQW1CLE9BQU8sTUFBTSxLQUFLO0VBQ3BFLE9BQU8sa0JBQWtCO0dBQ3hCLElBQUksZUFBZTtJQUNsQixxQkFBcUI7SUFDckIseUJBQXlCO0dBQzFCO0dBQ0EsT0FBTyxJQUFJLFFBQVEsS0FBSztFQUN6QjtFQUNBLFVBQVUsa0JBQWtCO0dBQzNCLElBQUksZUFBZTtJQUNsQixxQkFBcUI7SUFDckIseUJBQXlCO0dBQzFCO0dBQ0EsSUFBSSxRQUFRLFFBQVE7RUFDckI7RUFDQSxLQUFLLEdBQUcsa0JBQWtCO0dBQ3pCLGNBQWM7R0FDZCxJQUFJLGVBQWU7SUFDbEIscUJBQXFCO0lBQ3JCLHlCQUF5QjtHQUMxQjtHQUNBLElBQUksUUFBUSxHQUFHLENBQUM7RUFDakI7RUFDQTtFQUNBO0VBQ0EsZUFBZTtHQUNkLElBQUksUUFBUSxZQUFZO0dBQ3hCLElBQUksUUFBUSxlQUFlO0dBQzNCLElBQUksb0JBQW9CLG1CQUFtQixnQkFBZ0IsRUFBRSxTQUFTLEtBQUssQ0FBQztHQUM1RSxJQUFJLG9CQUFvQixlQUFlLGNBQWM7RUFDdEQ7RUFDQSxpQkFBaUI7R0FDaEIsSUFBSSxvQkFBb0Isb0JBQW9CLGtCQUFrQixrQkFBa0I7RUFDakY7RUFDQSxhQUFhO0VBQ2IsYUFBYTtFQUNiLHFCQUFxQjtDQUN0QixDQUFDO0NBQ0QsUUFBUSwyQkFBMkIsU0FBUztFQUMzQyx5QkFBeUI7RUFDekIsSUFBSTtHQUNILE9BQU8sSUFBSSxJQUFJLE1BQU0sSUFBSSxTQUFTLE9BQU8sQ0FBQyxDQUFDO0dBQzNDLHlCQUF5QixXQUFXLEtBQUssSUFBSSxNQUFNLENBQUMsS0FBSyxTQUFTLEdBQUcsS0FBSyxLQUFLLE1BQU0sR0FBRyxDQUFDLENBQUMsT0FBTyxJQUFJLFNBQVMsS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQy9ILFFBQVEsQ0FBQztDQUNWO0NBQ0EsSUFBSSxpQkFBaUIsbUJBQW1CLGdCQUFnQixFQUFFLFNBQVMsS0FBSyxDQUFDO0NBQ3pFLElBQUksaUJBQWlCLGVBQWUsY0FBYztDQUNsRCxJQUFJLFFBQVEsWUFBWSxTQUFTLEdBQUcsTUFBTTtFQUN6QyxNQUFNLE1BQU0sa0JBQWtCLE1BQU0sSUFBSSxTQUFTLElBQUk7RUFDckQsSUFBSSxDQUFDLFFBQVEsb0JBQW9CLFVBQVUsTUFBTTtFQUNqRCxPQUFPO0NBQ1I7Q0FDQSxJQUFJLFFBQVEsZUFBZSxTQUFTLEdBQUcsTUFBTTtFQUM1QyxNQUFNLE1BQU0scUJBQXFCLE1BQU0sSUFBSSxTQUFTLElBQUk7RUFDeEQsSUFBSSxDQUFDLFFBQVEsb0JBQW9CLFVBQVUsU0FBUztFQUNwRCxPQUFPO0NBQ1I7Q0FDQSxPQUFPO0FBQ1I7Ozs7OztBQU1BLFNBQVMsa0JBQWtCLE1BQU07Q0FDaEMsTUFBTSxNQUFNLE1BQU0sV0FBVyxPQUFPLGFBQWEsY0FBYyxTQUFTLEtBQUs7Q0FDN0UsT0FBTyxxQkFBcUI7RUFDM0IsUUFBUTtFQUNSLHFCQUFxQjtHQUNwQixNQUFNLE9BQU8sSUFBSSxTQUFTO0dBQzFCLElBQUksWUFBWSxLQUFLLFFBQVEsS0FBSyxDQUFDO0dBQ25DLElBQUksWUFBWSxHQUFHLFlBQVksS0FBSztHQUNwQyxPQUFPLFVBQVUsR0FBRyxPQUFPLEtBQUssTUFBTSxHQUFHLFNBQVMsSUFBSSxNQUFNLElBQUksU0FBUyxTQUFTLEtBQUssTUFBTSxTQUFTLEtBQUssSUFBSSxRQUFRLEtBQUs7RUFDN0g7RUFDQSxhQUFhLFNBQVMsR0FBRyxJQUFJLFNBQVMsV0FBVyxJQUFJLFNBQVMsT0FBTyxHQUFHO0NBQ3pFLENBQUM7QUFDRjs7Ozs7O0FBTUEsU0FBUyxvQkFBb0IsT0FBTyxFQUFFLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxHQUFHO0NBQzlELE1BQU0sVUFBVSxLQUFLO0NBQ3JCLElBQUksUUFBUSxLQUFLLGVBQWUsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLGNBQWMsQ0FBQyxHQUFHLFFBQVEsU0FBUyxDQUFDLElBQUksUUFBUSxTQUFTO0NBQ2hILE1BQU0sU0FBUyxRQUFRLEtBQUssUUFBUSxVQUFVLGtCQUFrQixPQUFPLEtBQUssQ0FBQyxDQUFDO0NBQzlFLE1BQU0sb0JBQW9CLFVBQVUsUUFBUSxRQUFRLE9BQU8sTUFBTTtDQUNqRSxJQUFJLFdBQVcsQ0FBQztDQUNoQixNQUFNLHFCQUFxQjtDQUMzQixNQUFNLGdCQUFnQixnQkFBZ0IsV0FBVztDQUNqRCxPQUFPLGNBQWM7RUFDcEI7RUFDQSxpQkFBaUIsUUFBUTtFQUN6QixZQUFZLE1BQU0sVUFBVTtHQUMzQixRQUFRLFFBQVEsUUFBUSxTQUFTLElBQUksUUFBUSxJQUFJLFFBQVE7R0FDekQsT0FBTyxTQUFTO0dBQ2hCLFFBQVEsU0FBUztHQUNqQixJQUFJLFFBQVEsUUFBUSxTQUFTLEdBQUc7SUFDL0IsUUFBUSxTQUFTLFFBQVE7SUFDekIsT0FBTyxTQUFTLFFBQVE7R0FDekI7RUFDRDtFQUNBLGVBQWUsTUFBTSxVQUFVO0dBQzlCLE9BQU8sU0FBUztHQUNoQixRQUFRLFNBQVM7RUFDbEI7RUFDQSxZQUFZO0dBQ1gsUUFBUSxLQUFLLElBQUksUUFBUSxHQUFHLENBQUM7RUFDOUI7RUFDQSxlQUFlO0dBQ2QsUUFBUSxLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsU0FBUyxDQUFDO0VBQy9DO0VBQ0EsS0FBSyxNQUFNO0dBQ1YsUUFBUSxLQUFLLElBQUksS0FBSyxJQUFJLFFBQVEsR0FBRyxDQUFDLEdBQUcsUUFBUSxTQUFTLENBQUM7RUFDNUQ7RUFDQSxZQUFZO0VBQ1osYUFBYTtFQUNiLGFBQWE7Q0FDZCxDQUFDO0FBQ0Y7QUF3Q0EsU0FBUyxVQUFVLE1BQU0sT0FBTztDQUMvQixNQUFNLGdCQUFnQixjQUFjLElBQUk7Q0FDeEMsTUFBTSxZQUFZLGNBQWMsUUFBUSxHQUFHO0NBQzNDLE1BQU0sY0FBYyxjQUFjLFFBQVEsR0FBRztDQUM3QyxJQUFJLENBQUMsT0FBTztFQUNYLE1BQU0sTUFBTSxnQkFBZ0I7RUFDNUIsUUFBUTtJQUNOLGdCQUFnQjtHQUNqQjtHQUNBLFdBQVc7RUFDWjtDQUNEO0NBQ0EsT0FBTztFQUNOLE1BQU07RUFDTixVQUFVLGNBQWMsTUFBTSxHQUFHLFlBQVksS0FBSyxjQUFjLEtBQUssS0FBSyxJQUFJLFdBQVcsV0FBVyxJQUFJLFlBQVksY0FBYyxLQUFLLGNBQWMsY0FBYyxNQUFNO0VBQ3pLLE1BQU0sWUFBWSxLQUFLLGNBQWMsTUFBTSxTQUFTLElBQUk7RUFDeEQsUUFBUSxjQUFjLEtBQUssY0FBYyxNQUFNLGFBQWEsY0FBYyxLQUFLLEtBQUssSUFBSSxTQUFTLElBQUk7RUFDckc7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxrQkFBa0I7Q0FDMUIsUUFBUSxLQUFLLE9BQU8sSUFBSSxFQUFBLENBQUcsU0FBUyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDaEQ7OztBQzliQSxTQUFTLGNBQWMsS0FBSyxRQUFRO0NBQ25DLE9BQU8sSUFBSSxhQUFhLFdBQVcsSUFBSSxhQUFhLFlBQVksSUFBSSxXQUFXLFVBQVUsQ0FBQyxDQUFDLElBQUksWUFBWSxDQUFDLENBQUMsSUFBSTtBQUNsSDtBQUNBLFNBQVMsV0FBVyxLQUFLO0NBQ3hCLE9BQU8sSUFBSSxXQUFXLElBQUksU0FBUyxJQUFJO0FBQ3hDO0FBQ0EsU0FBUyxlQUFlLE9BQU87Q0FDOUIsT0FBTyxNQUFNLFFBQVEsVUFBVSxNQUFNLFFBQVEsY0FBYyxNQUFNLFVBQVUsTUFBTSxRQUFRLFdBQVcsV0FBVyxNQUFNLFFBQVEsa0JBQWtCO0FBQ2hKOzs7OztBQUtBLFNBQVMsc0JBQXNCLEtBQUs7Q0FDbkMsSUFBSSxlQUFlLE9BQU87RUFDekIsTUFBTSxNQUFNO0dBQ1gsTUFBTSxJQUFJO0dBQ1YsU0FBUyxJQUFJO0VBQ2Q7RUFDNEMsSUFBSSxRQUFRLElBQUk7RUFDNUQsT0FBTztDQUNSO0NBQ0EsT0FBTyxFQUFFLE1BQU0sSUFBSTtBQUNwQjs7Ozs7QUFXQSxTQUFTLHNCQUFzQixVQUFVLGtCQUFrQjtDQUMxRCxPQUFPO0VBQ04sY0FBYztFQUNkLFlBQVk7RUFDWixhQUFhLGtCQUFrQixhQUFhLFNBQVM7RUFDckQsYUFBYSxrQkFBa0IsU0FBUyxTQUFTO0VBQ2pELGFBQWEsa0JBQWtCLFNBQVMsU0FBUztDQUNsRDtBQUNEOzs7Ozs7QUFNQSxTQUFTLHFCQUFxQixFQUFFLEtBQUssTUFBTSxXQUFXLFNBQVMsYUFBYSxXQUFXLDZCQUE2QixhQUFhLEdBQUcsU0FBUztDQUM1SSxPQUFPO0FBQ1I7QUFDQSxTQUFTLGFBQWEsU0FBUztDQUM5QixPQUFPLFFBQVEsV0FBVyxVQUFVLE1BQU0sV0FBVyxXQUFXLE1BQU0sV0FBVyxjQUFjLE1BQU0sU0FBUyxJQUFJO0FBQ25IOztBQUVBLFNBQVMsa0JBQWtCLFFBQVEsVUFBVSxTQUFTLGFBQWEsU0FBUyxPQUFPO0NBQ2xGLElBQUksYUFBYSxXQUFXLFNBQVMsTUFBTSxHQUFHLFdBQVc7Q0FDekQsSUFBSSxTQUFTLFVBQVUsUUFBUSxNQUFNLEdBQUcsT0FBTztDQUMvQyxLQUFLLE1BQU0sU0FBUyxVQUFVO0VBQzdCLElBQUksU0FBUyxPQUFPLFFBQVEsT0FBTztFQUNuQyxJQUFJLENBQUMsUUFBUSxNQUFNLGNBQWMsVUFBVSxZQUFZLE1BQU0sT0FBTyxHQUFHLE9BQU8sV0FBVyxNQUFNLFFBQVEsQ0FBQyxRQUFRLFVBQVUsS0FBSztDQUNoSTtDQUNBLEtBQUssTUFBTSxTQUFTLFNBQVM7RUFDNUIsSUFBSSxTQUFTLE9BQU8sUUFBUSxPQUFPO0VBQ25DLE9BQU8sV0FBVyxNQUFNLFFBQVEsQ0FBQyxRQUFRLFNBQVMsTUFBTSxjQUFjLFVBQVUsWUFBWSxNQUFNLE9BQU8sSUFBSSxXQUFXLFVBQVUsR0FBRyxLQUFLO0NBQzNJO0FBQ0Q7Ozs7Ozs7Ozs7QUFVQSxJQUFJLGFBQWEsTUFBTTs7OztDQUl0QixZQUFZLFNBQVMsZ0JBQWdCO0VBQ3BDLEtBQUssa0JBQWtCLEdBQUcsS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQUc7RUFDeEQsS0FBSyxVQUFVLEVBQUUsR0FBRyxLQUFLO0VBQ3pCLEtBQUssOEJBQThCLElBQUksSUFBSTtFQUMzQyxLQUFLLHlCQUF5QixJQUFJLElBQUk7RUFDdEMsS0FBSyxhQUFhLENBQUM7RUFDbkIsS0FBSyxrQkFBa0IsT0FBTyxPQUFPO0dBQ3BDLEdBQUc7R0FDSCxPQUFPO0VBQ1I7RUFDQSxLQUFLLFVBQVUsZUFBZTtHQUU1QixJQUFJLFdBQVcsZUFBZSxRQUFRLEtBQUssK01BQStNO0dBRTNQLE1BQU0sY0FBYyxLQUFLO0dBQ3pCLEtBQUssVUFBVTtJQUNkLEdBQUc7SUFDSCxHQUFHO0dBQ0o7R0FDQSxLQUFLLFdBQVcsS0FBSyxRQUFRLFlBQUEsS0FBQSxLQUF3QixPQUFPLGFBQWE7R0FDekUsSUFBSSxDQUFjLEtBQUssVUFBVyxLQUFLLGtDQUFrQyxJQUFJLFFBQVE7R0FDckYsS0FBSyxvQkFBb0IsSUFBSSxJQUFJLEtBQUssUUFBUSxpQkFBaUI7R0FDL0QsSUFBSSxDQUFDLEtBQUssV0FBVyxLQUFLLFFBQVEsV0FBVyxLQUFLLFFBQVEsWUFBWSxLQUFLLFNBQVM7SUFDbkYsSUFBSSxDQUFDLEtBQUssUUFBUSxTQUNiO1NBQUEsQ0FBYyxLQUFLLFVBQVcsS0FBSyxVQUFVLHFCQUFxQjtJQUFBLE9BQ2hFLEtBQUssVUFBVSxLQUFLLFFBQVE7R0FDcEM7R0FDQSxLQUFLLFNBQVMsS0FBSyxRQUFRO0dBQzNCLElBQUksQ0FBQyxLQUFLLFFBQVE7SUFDakIsSUFBSSxDQUFjLEtBQUssWUFBYSxRQUFRLFVBQVUsT0FBTyxXQUFXLFFBQVEsS0FBSyxTQUFTLE9BQU87U0FDaEcsS0FBSyxTQUFTO0dBQ3BCO0dBQ0EsTUFBTSxlQUFlLEtBQUssUUFBUSxZQUFZO0dBQzlDLE1BQU0sb0JBQW9CLEtBQUssUUFBUTtHQUN2QyxNQUFNLGlCQUFpQixLQUFLLGFBQWEsZ0JBQWdCLGFBQWEsWUFBWSxxQkFBcUIsYUFBYSxrQkFBa0IsS0FBSyxRQUFRO0dBQ25KLElBQUksZ0JBQWdCO0lBQ25CLEtBQUssV0FBVztJQUNoQixLQUFLLFVBQVUsaUJBQWlCLE9BQU8sU0FBUyxZQUFZLElBQUksZ0JBQWdCLGNBQWMsS0FBSyxRQUFRLGVBQWUsaUJBQWlCLElBQUk7R0FDaEo7R0FDQSxJQUFJLEtBQUssU0FBUyxLQUFLLHFCQUFxQjtHQUM1QyxJQUFJLEtBQUssUUFBUSxjQUFjLEtBQUssYUFBMEIsS0FBSyxZQUFhLGFBQWEsa0JBQWtCLEtBQUssUUFBUSxlQUFlO0lBQzFJLEtBQUssWUFBWSxLQUFLLFFBQVE7SUFDOUIsSUFBSTtJQUdILHlCQUF5QixLQUFLLGVBQWU7SUFPOUMsS0FBSyxVQUFVLHNCQUFzQjtHQUN0QztHQUNBLElBQUksQ0FBQyxLQUFLLFFBQ0w7UUFBQSxLQUFLLGdCQUFnQjtLQUN4QixNQUFNLFNBQVMsS0FBSyxlQUFlLElBQUk7S0FDdkMsS0FBSyxRQUFRLE9BQU87S0FDcEIsS0FBSyxTQUFTLG1CQUFtQixLQUFLLGdCQUFnQixNQUFNO0tBQzVELElBQUksQ0FBYyxLQUFLLFVBQVcsdUJBQXVCLElBQUk7SUFDOUQ7VUFDTSxJQUFJLGdCQUFnQixLQUFLLE9BQU8sU0FBUyxJQUFJLEtBQUssY0FBYztFQUN4RTtFQUNBLEtBQUssNkJBQTZCO0dBQ2pDLEtBQUssaUJBQWlCLEtBQUssY0FBYyxLQUFLLFFBQVEsVUFBVSxLQUFLLGNBQWM7RUFDcEY7RUFDQSxLQUFLLHVCQUF1QjtHQUMzQixNQUFNLFNBQVMsaUJBQWlCLEtBQUssV0FBVyxLQUFLLFFBQVEsYUFBYTtHQUMxRSxJQUFJLEtBQUssUUFBUSxZQUFZLGtCQUFrQixLQUFLLFFBQVEsWUFBWSxPQUFPLGFBQWE7R0FDNUYsT0FBTztJQUNOLEdBQUc7SUFDSCxrQkFBa0IsaUJBQWlCLEdBQUc7R0FDdkM7RUFDRDtFQUNBLEtBQUssYUFBYSxXQUFXLE9BQU87R0FDbkMsTUFBTSxXQUFXO0lBQ2hCO0lBQ0E7R0FDRDtHQUNBLEtBQUssWUFBWSxJQUFJLFFBQVE7R0FDN0IsYUFBYTtJQUNaLEtBQUssWUFBWSxPQUFPLFFBQVE7R0FDakM7RUFDRDtFQUNBLEtBQUssUUFBUSxnQkFBZ0I7R0FDNUIsS0FBSyxNQUFNLFlBQVksS0FBSyxhQUFhLElBQUksU0FBUyxjQUFjLFlBQVksTUFBTSxJQUFJO0lBQ3pGLFNBQVMsR0FBRyxXQUFXO0dBQ3hCLFNBQVMsR0FBRztJQUNYLFFBQVEsTUFBTSxDQUFDO0dBQ2hCO0VBQ0Q7RUFDQSxLQUFLLGlCQUFpQixpQkFBaUIscUJBQXFCO0dBQzNELE1BQU0sU0FBUyxFQUFFLFVBQVUsUUFBUSxNQUFNLFFBQVEsVUFBVTtJQUMxRCxJQUFJLENBQUMsS0FBSyxXQUFXLENBQUMsZ0NBQWdDLEtBQUssUUFBUSxHQUFHO0tBQ3JFLE1BQU0sZUFBZSxLQUFLLFFBQVEsWUFBWSxNQUFNO0tBQ3BELE1BQU0sWUFBWSxLQUFLLFFBQVEsZ0JBQWdCLFlBQVk7S0FDM0QsT0FBTztNQUNOLE1BQU0sV0FBVyxZQUFZO01BQzdCLFlBQVksV0FBVyxZQUFZO01BQ25DLFVBQVUsV0FBVyxRQUFRO01BQzdCLFVBQVU7TUFDVjtNQUNBLFFBQVEscUJBQXFCLGtCQUFrQixRQUFRLFlBQVk7TUFDbkUsTUFBTSxXQUFXLEtBQUssTUFBTSxDQUFDLENBQUM7TUFDOUIsT0FBTyxpQkFBaUIsa0JBQWtCLE9BQU8sS0FBSztLQUN2RDtJQUNEO0lBQ0EsTUFBTSxNQUFNLG9CQUFvQixLQUFLLFNBQVMsSUFBSSxJQUFJLE1BQU0sS0FBSyxNQUFNLENBQUM7SUFDeEUsTUFBTSxlQUFlLEtBQUssUUFBUSxZQUFZLElBQUksTUFBTTtJQUN4RCxNQUFNLFlBQVksS0FBSyxRQUFRLGdCQUFnQixZQUFZO0lBQzNELElBQUksU0FBUztJQUNiLE9BQU87S0FDTixNQUFNLElBQUksS0FBSyxRQUFRLElBQUksUUFBUSxFQUFFO0tBQ3JDLFlBQVk7S0FDWixVQUFVLFdBQVcsMEJBQTBCLElBQUksUUFBUSxDQUFDO0tBQzVELFVBQVUsQ0FBQyxDQUFDLEtBQUssV0FBVyxjQUFjLEtBQUssS0FBSyxNQUFNO0tBQzFEO0tBQ0EsUUFBUSxxQkFBcUIsa0JBQWtCLFFBQVEsWUFBWTtLQUNuRSxNQUFNLFdBQVcsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDO0tBQ2xDLE9BQU8saUJBQWlCLGtCQUFrQixPQUFPLEtBQUs7SUFDdkQ7R0FDRDtHQUNBLE1BQU0sV0FBVyxNQUFNLGlCQUFpQixnQkFBZ0IsS0FBSztHQUM3RCxNQUFNLEVBQUUsZ0JBQWdCLGNBQWMsU0FBUztHQUMvQyxJQUFJLG1CQUFtQixDQUFDLGFBQWEsY0FBYyxLQUFLLGtCQUFrQjtJQUN6RSxNQUFNLHFCQUFxQixNQUFNLGdCQUFnQjtLQUNoRCxHQUFHLGVBQWU7S0FDbEIsZ0JBQWdCLEtBQUs7S0FDckIsS0FBSyxTQUFTLE1BQU07S0FDcEIsV0FBVyxTQUFTLE1BQU07SUFDM0IsQ0FBQztJQUNELG1CQUFtQixpQkFBaUI7SUFDcEMsT0FBTztHQUNSO0dBQ0EsT0FBTztFQUNSO0VBQ0EsS0FBSyxlQUFlLGdCQUFnQixzQkFBc0IsU0FBUztHQUNsRSxJQUFJLE9BQU8sbUJBQW1CLFVBQVUsT0FBTyxLQUFLLG9CQUFvQjtJQUN2RSxVQUFVO0lBQ1YsUUFBUTtHQUNULEdBQUcsSUFBSTtHQUNQLE9BQU8sS0FBSyxvQkFBb0IsZ0JBQWdCLG9CQUFvQjtFQUNyRTtFQUNBLEtBQUssb0JBQW9CLGFBQWE7R0FDckMsTUFBTSxZQUFZLE9BQU8sT0FBTyxJQUFJO0dBQ3BDLE1BQU0sUUFBUSxlQUFlLGNBQWMsUUFBUSxHQUFHLEtBQUssZUFBZSxJQUFJO0dBQzlFLElBQUksT0FBTyxPQUFPLE9BQU8sV0FBVyxNQUFNLFNBQVM7R0FDbkQsT0FBTztJQUNOLE9BQU8sVUFBVSxDQUFDLEtBQUssV0FBVyxXQUFXO0lBQzdDO0lBQ0EsT0FBTztHQUNSO0VBQ0Q7RUFDQSxLQUFLLGlCQUFpQixTQUFTO0dBQzlCLElBQUksQ0FBYyxLQUFLLFVBQVc7SUFDakMsTUFBTSxTQUFTLEtBQUssZ0JBQWdCLElBQUksSUFBSTtJQUM1QyxJQUFJLFFBQVEsT0FBTztHQUNwQjtHQUNBLElBQUksY0FBYztHQUNsQixNQUFNLFNBQVMsT0FBTyxDQUFDLE1BQU07SUFDNUIsSUFBSSxLQUFLLE1BQU07S0FDZCxNQUFNLFNBQVMsVUFBVSxLQUFLLE1BQU0sQ0FBQyxDQUFDO0tBQ3RDLE9BQU87TUFDTixHQUFHO01BQ0gsSUFBSSxvQkFBb0IsS0FBSyxTQUFTLElBQUksSUFBSSxPQUFPLFVBQVUsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDO01BQzdFLFFBQVEsS0FBSyxRQUFRLFlBQVksT0FBTyxNQUFNO01BQzlDLE1BQU0sT0FBTyxLQUFLLE1BQU0sQ0FBQztLQUMxQjtJQUNEO0lBQ0EsTUFBTSxrQkFBa0IsS0FBSyxpQkFBaUIsS0FBSyxvQkFBb0IsS0FBSztJQUM1RSxJQUFJO0lBQ0osTUFBTSxnQkFBZ0I7S0FDckIsY0FBYztLQUNkLE9BQU87SUFDUjtJQUNBLE1BQU0scUJBQXFCLGdCQUFnQixLQUFLLHVCQUF1QixRQUFRLENBQUM7SUFDaEYsSUFBNkMsS0FBSyxRQUFRLEtBQUssYUFBYTtLQUMzRSxNQUFNLENBQUMsa0JBQWtCLEtBQUssaUJBQWlCLEtBQUssSUFBSTtLQUN4RCxNQUFNLENBQUMsZUFBZSxZQUFZLGFBQWE7S0FDL0MsTUFBTSxjQUFjLFNBQVMsZ0JBQWdCLE1BQU07TUFDbEQsT0FBTyxhQUFhLEVBQUUsVUFBVSxLQUFLLElBQUk7S0FDMUMsQ0FBQztLQUNELE1BQU0saUJBQWlCLFNBQVMsaUJBQWlCLE1BQU07TUFDdEQsT0FBTyxhQUFhLEVBQUUsVUFBVSxRQUFRO0tBQ3pDLENBQUM7S0FDRCxJQUFJLENBQUMsZUFBZSxDQUFDLGdCQUFnQixRQUFRLEtBQUssa0NBQWtDLEtBQUssTUFBTTtJQUNoRztJQUNBLE1BQU0sS0FBSyxLQUFLLEtBQUssR0FBRyxLQUFLLE9BQU87SUFDcEMsTUFBTSxTQUFTLFlBQVksR0FBRyxPQUFPLE1BQU0sS0FBSyxLQUFLLG1CQUFtQixTQUFTLFFBQVEsQ0FBQyxDQUFDLFdBQVcsS0FBSyxRQUFRLGFBQWEsQ0FBQyxDQUFDLElBQUksSUFBSSxLQUFLLFFBQVEsZUFBZSxLQUFLLGdCQUFnQjtJQUMzTCxNQUFNLFlBQVksS0FBSyxhQUFhLGNBQWMsTUFBTTtJQUN4RCxNQUFNLGFBQWEsT0FBTyxTQUFTLEdBQUc7SUFDdEMsSUFBSTtJQUNKLElBQUksV0FBVyxhQUFhLFVBQVUsWUFBWSxpQkFBaUIsU0FBUztTQUN2RSxJQUFJLFlBQVksYUFBYSxDQUFDO1NBQzlCO0tBQ0osTUFBTSxDQUFDLGVBQWUsV0FBVyxjQUFjLEtBQUssaUJBQWlCLE1BQU07S0FDM0UsYUFBYTtLQUNiLElBQUksS0FBSyxRQUFRLGtCQUFrQixDQUFDLGNBQWMsV0FBVyxTQUFTLE9BQU8sVUFBVSxRQUFRLGFBQWEsQ0FBQyxHQUFHLFlBQVksS0FBSyxRQUFRLGFBQWE7SUFDdko7SUFDQSxNQUFNLGdCQUFnQixhQUFhLFdBQVcsa0JBQWtCLGNBQWMsT0FBTyxFQUFFLFVBQVUsT0FBTyxHQUFHLENBQUMsSUFBSSxLQUFLO0lBQ3JILElBQUk7SUFDSixLQUFLLE1BQU0sU0FBUyxZQUFZO0tBQy9CLE1BQU0sS0FBSyxNQUFNLFFBQVEsUUFBUSxhQUFhLE1BQU0sUUFBUTtLQUM1RCxJQUFJLElBQUk7TUFDUCxNQUFNLGFBQWEsYUFBYSxDQUFDLENBQUM7TUFDbEMsZUFBZSxrQkFBa0IsS0FBSyxRQUFRLFVBQVU7TUFDeEQsSUFBSSxDQUFDLFFBQVEsVUFBVSxHQUFHO01BQzFCLElBQUksZUFBZSxZQUFZLGFBQWEsT0FBTyxPQUFPLFdBQVcsR0FBRyxVQUFVO01BQ2xGLElBQUk7T0FDSCxPQUFPLE9BQU8sWUFBWSxHQUFHLFVBQVUsQ0FBQztNQUN6QyxRQUFRLENBQUM7S0FDVjtJQUNEO0lBQ0EsZUFBZSxrQkFBa0IsS0FBSyxRQUFRLHFCQUFxQixLQUFLLFFBQVEsYUFBYSxJQUFJLGFBQWEsQ0FBQyxDQUFDLEtBQUssWUFBWTtJQUNqSSxNQUFNLGVBQWUsS0FBSyxjQUFjLFNBQVMsMEJBQTBCLFdBQVcsZ0JBQWdCLGdCQUFnQixRQUFRLGVBQWUsWUFBWSxLQUFLLGlCQUFpQixJQUFJLE1BQU0sQ0FBQztJQUMxTCxJQUE2QyxhQUFhLENBQUMsS0FBSyxhQUFhLElBQUk7S0FDaEYsTUFBTSxhQUFhLEtBQUssaUJBQWlCLFlBQVksQ0FBQyxDQUFDO0tBQ3ZELElBQUksWUFBWSxPQUFPLFVBQVUsSUFBSSxRQUFRLEtBQUssbUJBQW1CLGFBQWEsZUFBZSxVQUFVLEdBQUcsbUJBQW1CLFlBQVksR0FBRyxvTUFBb007SUFDclYsUUFBUSxDQUFDO0lBQ1QsTUFBTSxjQUFjLHFCQUFxQixZQUFZLEtBQUssc0JBQXNCO0lBQ2hGLE1BQU0sbUJBQW1CO0tBQ3hCLElBQUksU0FBUyxhQUFhLENBQUMsQ0FBQztLQUM1QixJQUFJLEtBQUssMEJBQTBCLEtBQUssUUFBUSxRQUFRLFFBQVE7TUFDL0QsTUFBTSxrQkFBa0IsQ0FBQztNQUN6QixXQUFXLFNBQVMsVUFBVTtPQUM3QixJQUFJLE1BQU0sUUFBUSxnQkFBZ0IsSUFBSTtRQUNyQyxPQUFPLE9BQU8saUJBQWlCLGVBQWUsTUFBTSxRQUFRLGdCQUFnQjtTQUMzRSxHQUFHO1NBQ0gsR0FBRztRQUNKLENBQUMsQ0FBQztPQUNILFFBQVEsQ0FBQztNQUNWLENBQUM7TUFDRCxTQUFTO0tBQ1Y7S0FDQSxPQUFPO0lBQ1I7SUFDQSxNQUFNLGFBQWEsWUFBWSxTQUFTLHNCQUFzQixhQUFhLFdBQVcsR0FBRyxJQUFJLElBQUksS0FBSyxXQUFXLE9BQU8sV0FBVyxJQUFJLE9BQU8sS0FBSyxXQUFXLGFBQWEsS0FBSyxPQUFPLFdBQVcsQ0FBQyxJQUFJLEtBQUssVUFBVTtJQUN0TixNQUFNLFlBQVksS0FBSyxRQUFRLGdCQUFnQixVQUFVO0lBQ3pELE1BQU0sT0FBTyxLQUFLLFNBQVMsT0FBTyxRQUFRLENBQUMsQ0FBQyxPQUFPLE9BQU8sS0FBSyxTQUFTLGFBQWEsS0FBSyxLQUFLLFFBQVEsQ0FBQyxDQUFDLElBQUksSUFBSSxLQUFLLFFBQVEsS0FBSztJQUNuSSxNQUFNLFVBQVUsT0FBTyxJQUFJLFNBQVM7SUFDcEMsTUFBTSxZQUFZLENBQUMsS0FBSyxRQUFRLGVBQWUsS0FBSyxVQUFVLE9BQU8sUUFBUSxDQUFDLENBQUMsUUFBUSxPQUFPLEtBQUssVUFBVSxhQUFhLEtBQUssTUFBTSxRQUFRLENBQUMsQ0FBQyxLQUFLLElBQUksS0FBSztJQUM3SixNQUFNLFdBQVcsR0FBRyxlQUFlLFlBQVk7SUFDL0MsSUFBSTtJQUNKLElBQUk7SUFDSixJQUFJLFdBQVc7SUFDZixJQUFJLEtBQUssU0FBUztLQUNqQixNQUFNLE1BQU0sSUFBSSxJQUFJLFVBQVUsS0FBSyxNQUFNO0tBQ3pDLE1BQU0sU0FBUyxJQUFJO0tBQ25CLE1BQU0sZUFBZSxxQkFBcUIsS0FBSyxTQUFTLEdBQUc7S0FDM0QsT0FBTyxXQUFXLEdBQUc7S0FDckIsSUFBSSxjQUFjLGNBQWMsTUFBTSxHQUFHO01BQ3hDLGFBQWEsYUFBYTtNQUMxQixXQUFXO0tBQ1osT0FBTyxhQUFhLDBCQUEwQixXQUFXLFlBQVksQ0FBQztJQUN2RSxPQUFPO0tBQ04sT0FBTyxrQkFBa0IsUUFBUTtLQUNqQyxhQUFhO0lBQ2Q7SUFDQSxPQUFPO0tBQ047S0FDQTtLQUNBLFVBQVU7S0FDVixRQUFRO0tBQ1I7S0FDQSxPQUFPO0tBQ1AsTUFBTSxRQUFRO0tBQ2Q7S0FDQSxnQkFBZ0IsS0FBSztJQUN0QjtHQUNEO0dBQ0EsTUFBTSxPQUFPLE1BQU0sSUFBSTtHQUN2QixJQUFJLEtBQUssTUFBTSxLQUFLLGlCQUFpQixNQUFNO0lBQzFDLE1BQU0sS0FBSztJQUNYLEdBQUcsS0FBSztHQUNULENBQUM7UUFDSSxJQUFJLEtBQUssUUFBUSxZQUFZO0lBQ2pDLE1BQU0sUUFBUSxjQUFjLEtBQUssVUFBVSxLQUFLLGFBQWE7SUFDN0QsSUFBSSxPQUFPO0tBQ1YsTUFBTSxTQUFTLE9BQU8sT0FBTyxXQUFXLEdBQUcsTUFBTSxTQUFTO0tBQzFELE1BQU0sRUFBRSxNQUFNLE9BQU8sUUFBUSxZQUFZLEdBQUcsY0FBYyxNQUFNO0tBQ2hFLE1BQU0sYUFBYSxrQkFBa0IsWUFBWSxNQUFNO0tBQ3ZELEtBQUssaUJBQWlCLE1BQU07TUFDM0IsTUFBTSxLQUFLO01BQ1gsR0FBRztNQUNILFFBQVE7S0FDVCxDQUFDO0lBQ0Y7R0FDRDtHQUNBLElBQUksQ0FBYyxLQUFLLFlBQWEsQ0FBQyxlQUFlLEtBQUssZUFBZSxLQUFLLGdCQUFnQixJQUFJLE1BQU0sSUFBSTtHQUMzRyxPQUFPO0VBQ1I7RUFDQSxLQUFLLGlCQUFpQixPQUFPLEVBQUUsZ0JBQWdCLGVBQWUsR0FBRyxXQUFXO0dBQzNFLElBQWdCLEtBQUssVUFBVTtHQUMvQixNQUFNLGVBQWUsS0FBSyxrQkFBa0I7R0FDNUMsSUFBSSxhQUFhLFlBQVksQ0FBYyxLQUFLLFVBQVcsT0FBTyxtQkFBbUIsTUFBTSxhQUFhLFlBQVk7SUFDbkgsU0FBUyxLQUFLO0lBQ2Q7R0FDRCxDQUFDO0dBQ0QsSUFBSTtHQUNKLE1BQU0saUJBQWlCLGNBQWMsS0FBSyxlQUFlLElBQUksTUFBTSxjQUFjLEtBQUssSUFBSSxLQUFLLFVBQVUscUJBQXFCLEtBQUssS0FBSyxHQUFHLHFCQUFxQixLQUFLLGVBQWUsS0FBSyxDQUFDO0dBQzFMLE1BQU0sd0JBQXdCLEtBQUs7R0FDbkMsSUFBSTtHQUNKLE1BQU0sZ0JBQWdCLElBQUksU0FBUyxTQUFTO0lBQzNDLFVBQVU7R0FDWCxDQUFDO0dBQ0QsY0FBYyxnQkFBZ0I7SUFDN0IsUUFBUTtJQUNSLHVCQUF1QixRQUFRO0dBQ2hDO0dBQ0EsS0FBSyxpQkFBaUI7R0FDdEIsSUFBSSxnQkFBZ0IsS0FBSyxLQUFLO1FBQ3pCO0lBQ0osSUFBSSxFQUFFLGdCQUFnQixvQkFBb0IsR0FBRyxnQkFBZ0I7SUFDN0QsSUFBSSxnQkFBZ0I7S0FDbkIsY0FBYztNQUNiLEdBQUc7TUFDSCxPQUFPO09BQ04sR0FBRyxlQUFlO09BQ2xCLFdBQVcsS0FBSztPQUNoQixnQkFBZ0I7UUFDZixHQUFHO1FBQ0gsUUFBUSxZQUFZO1FBQ3BCLE9BQU87U0FDTixHQUFHLFlBQVk7U0FDZixXQUFXLEtBQUs7U0FDaEIsZ0JBQWdCLEtBQUs7U0FDckIsV0FBVyxLQUFLO1NBQ2hCLEtBQUssS0FBSztRQUNYO09BQ0Q7TUFDRDtLQUNEO0tBQ0EsSUFBSSxZQUFZLGtCQUFrQixLQUFLLFFBQVEsa0JBQWtCLE9BQU8sWUFBWSxNQUFNLFlBQVksS0FBSztJQUM1RztJQUNBLFlBQVksUUFBUTtLQUNuQixHQUFHLFlBQVk7S0FDZiw2QkFBNkIsc0JBQXNCLEtBQUssUUFBUSw2QkFBNkI7SUFDOUY7SUFDQSxLQUFLLHVCQUF1QjtJQUM1QixnQkFBZ0IsS0FBSyxVQUFVLFlBQVk7SUFDM0MsS0FBSyxRQUFRLGtCQUFrQixZQUFZLFlBQVksT0FBTyxDQUFDLFlBQVksWUFBWSxZQUFZLE9BQU8sRUFBRSxjQUFjLENBQUM7SUFDM0gsSUFBSSxDQUFDLEtBQUssUUFBUSxZQUFZLE1BQU0sS0FBSyxLQUFLLEVBQUUsUUFBUSxFQUFFLE1BQU0sY0FBYyxFQUFFLENBQUM7R0FDbEY7R0FDQSxLQUFLLFFBQVEsSUFBSSxLQUFLLGVBQWU7R0FDckMsT0FBTyxLQUFLO0VBQ2I7RUFDQSxLQUFLLDBCQUEwQixFQUFFLFNBQVMsYUFBYSxvQkFBb0IsZ0JBQWdCLGVBQWUsR0FBRyxTQUFTLENBQUMsTUFBTTtHQUM1SCxJQUFnQixLQUFLLFVBQVUsT0FBTyxRQUFRLFFBQVE7R0FDdEQsTUFBTSxXQUFXLEtBQUssY0FBYztJQUNuQyxHQUFHO0lBQ0gsd0JBQXdCO0dBQ3pCLENBQUM7R0FDRCxLQUFLLG1CQUFtQjtHQUN4QixNQUFNLGdCQUFnQixLQUFLLGVBQWU7SUFDekMsR0FBRztJQUNIO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDRCxDQUFDO0dBQ0QscUJBQXFCO0lBQ3BCLElBQUksS0FBSyxxQkFBcUIsVUFBVSxLQUFLLG1CQUFtQixLQUFLO0dBQ3RFLENBQUM7R0FDRCxPQUFPO0VBQ1I7RUFDQSxLQUFLLFdBQVcsT0FBTyxFQUFFLElBQUksZ0JBQWdCLE1BQU0sWUFBWSxHQUFHLFdBQVc7R0FDNUUsSUFBZ0IsS0FBSyxVQUFVO0dBQy9CLE1BQU0sYUFBYSxPQUFPLGFBQWEsSUFBSSxJQUFJLEtBQUs7R0FDcEQsSUFBSSxjQUFjLGdCQUFnQjtJQUNqQyxJQUFJLE9BQU8sS0FBSyxLQUFLLENBQUMsTUFBTTtLQUMzQixNQUFNLFdBQVcsS0FBSyxjQUFjO01BQ25DO01BQ0EsR0FBRztLQUNKLENBQUM7S0FDRCxNQUFNLGlCQUFpQixTQUFTLGtCQUFrQjtLQUNsRCxTQUFTLGVBQWU7S0FDeEIsZUFBZSxlQUFlO0lBQy9CO0lBQ0EsTUFBTSxhQUFhLENBQUMsY0FBYyxhQUFhLGFBQWE7SUFDNUQsT0FBTyxtQkFBbUIsTUFBTSxZQUFZLElBQUk7R0FDakQ7R0FDQSxPQUFPLEtBQUssdUJBQXVCO0lBQ2xDLEdBQUc7SUFDSDtJQUNBO0lBQ0EsYUFBYTtHQUNkLENBQUM7RUFDRjtFQUNBLEtBQUssT0FBTyxPQUFPLFNBQVM7R0FDM0IsSUFBZ0IsS0FBSyxVQUFVLE9BQU8sZ0JBQWdCLE1BQU0sSUFBSTtHQUNoRSxLQUFLLHFCQUFxQjtHQUMxQixJQUFJLE1BQU0sUUFBUSxLQUFLLFFBQVEsSUFBSSxLQUFLLE9BQU8sU0FBUyxVQUFVLEtBQUssT0FBTyxTQUFTO0dBQ3ZGLE1BQU0sZ0JBQWdCLE1BQU0sSUFBSTtFQUNqQztFQUNBLEtBQUssdUJBQXVCLE9BQU87R0FDbEMsTUFBTSx1QkFBdUIsS0FBSyx3QkFBd0IsS0FBSyxRQUFRO0dBQ3ZFLEtBQUssdUJBQXVCLEtBQUs7R0FDakMsSUFBSSx3QkFBd0IsRUFBYyxPQUFPLGFBQWEsZ0JBQWdCLE9BQU8sU0FBUyx3QkFBd0IsWUFBWTtJQUNqSSxJQUFJO0lBQ0osSUFBSSxPQUFPLHlCQUF5QixZQUFZLE9BQU8sS0FBSyxXQUFXLDJDQUEyQyxHQUFHO0tBQ3BILE1BQU0sT0FBTyxLQUFLO0tBQ2xCLE1BQU0sZUFBZSxLQUFLLE9BQU8saUJBQWlCLElBQUk7S0FDdEQsTUFBTSw4QkFBOEIsT0FBTyxxQkFBcUIsVUFBVSxhQUFhLHFCQUFxQixNQUFNLHNCQUFzQixNQUFNLFlBQVksQ0FBQyxJQUFJLHFCQUFxQjtLQUNwTCxJQUFJLGdDQUFnQyxPQUFPLE9BQU8sR0FBRztLQUNyRCw0QkFBNEI7TUFDM0IsUUFBUTtNQUNSLE9BQU87S0FDUjtJQUNELE9BQU8sNEJBQTRCO0lBQ25DLE9BQU8sU0FBUyxvQkFBb0IseUJBQXlCLENBQUMsQ0FBQztHQUNoRTtHQUNBLE9BQU8sR0FBRztFQUNYO0VBQ0EsS0FBSyxjQUFjLFNBQVM7R0FDM0IsTUFBTSxtQkFBbUIsS0FBSztHQUM5QixNQUFNLFNBQVMsTUFBTTtHQUNyQixNQUFNLFdBQVcsS0FBSztHQUN0QixNQUFNLDZCQUE2QixJQUFJLElBQUk7R0FDM0MsTUFBTSxZQUFZLFVBQVU7SUFDM0IsSUFBSSxDQUFDLFVBQVUsT0FBTyxLQUFLLEdBQUcsV0FBVyxJQUFJLE1BQU0sRUFBRTtHQUN0RDtHQUNBLGlCQUFpQixRQUFRLFFBQVE7R0FDakMsS0FBSyxPQUFPLFFBQVEsUUFBUTtHQUM1QixVQUFVLFNBQVMsWUFBWSxRQUFRLFFBQVEsUUFBUSxDQUFDO0dBQ3hELEtBQUssTUFBTSxFQUFFLENBQUMsUUFBUSxRQUFRO0dBQzlCLE1BQU0sUUFBUSxDQUFDO0dBQ2YsS0FBSyxNQUFNLENBQUMsWUFBWSxZQUFZLFlBQVksQ0FBQyxHQUFHLElBQUksUUFBUSxNQUFNLFVBQVUsV0FBVyxJQUFJLE1BQU0sRUFBRSxDQUFDLEdBQUc7SUFDMUcsU0FBUyxPQUFPLFVBQVU7SUFDMUIsTUFBTSxLQUFLLFVBQVU7R0FDdEI7R0FDQSxNQUFNLGNBQWMsTUFBTTtJQUN6QixJQUFJLFdBQVcsSUFBSSxFQUFFLEVBQUUsR0FBRztLQUN6QixNQUFNLFFBQVEsS0FBSyxXQUFXLEVBQUU7S0FDaEMsTUFBTSxPQUFPO01BQ1osR0FBRztNQUNILFNBQVM7TUFDVCxJQUFJLE1BQU0sZ0JBQWdCLEVBQUUsV0FBVyxXQUFXLEVBQUUsV0FBVyxlQUFlLGVBQWUsS0FBSyxJQUFJO09BQ3JHLFFBQVE7T0FDUixPQUFPLEtBQUs7TUFDYixJQUFJLEtBQUs7S0FDVjtLQUNBLEVBQUUsVUFBVSxLQUFLO0tBQ2pCLE9BQU87SUFDUjtJQUNBLE9BQU87R0FDUjtHQUNBLEtBQUssYUFBYSxpQkFBaUIsSUFBSSxVQUFVO0dBQ2pELEtBQUssTUFBTSxDQUFDLElBQUksVUFBVSxLQUFLLFFBQVEsSUFBSSxXQUFXLElBQUksRUFBRSxHQUFHO0lBQzlELE1BQU0sVUFBVTtJQUNoQixJQUFJLE1BQU0sY0FBYyxNQUFNLFNBQVM7R0FDeEM7R0FDQSxLQUFLLE1BQU0sTUFBTSxZQUFZO0lBQzVCLE1BQU0sU0FBUyxLQUFLLFVBQVUsSUFBSSxFQUFFO0lBQ3BDLEtBQUssVUFBVSxPQUFPLEVBQUU7SUFDeEIsSUFBSSxVQUFVLENBQUMsT0FBTyxJQUFJLE1BQU0sS0FBSyxPQUFPLEVBQUU7R0FDL0M7R0FDQSxLQUFLLE1BQU0sY0FBYyxPQUFPLFdBQVcsTUFBTTtHQUNqRCxLQUFLLHVCQUF1QjtHQUM1QixPQUFPLEtBQUssS0FBSyxFQUFFLE1BQU0sTUFBTSxLQUFLLENBQUM7RUFDdEM7RUFDQSxLQUFLLG1CQUFtQixhQUFhO0dBQ3BDLE1BQU0sVUFBVSxTQUFTO0dBQ3pCLElBQUksT0FBTyxTQUFTLFFBQVEsSUFBSSxVQUFVLEtBQUssUUFBUTtHQUN2RCxJQUFJLENBQUMsTUFBTTtJQUNWLE1BQU0sV0FBVyxLQUFLLGNBQWMsT0FBTztJQUMzQyxRQUFRLFNBQVMsa0JBQWtCLFNBQUEsQ0FBVSxjQUFjO0dBQzVEO0dBQ0EsSUFBSTtHQUNKLElBQUksNEJBQTRCLEtBQUssSUFBSSxNQUFNLFNBQVMsYUFBYSxJQUFJLE1BQU0sQ0FBQyxLQUFLLGtCQUFrQixJQUFJLE1BQU0sR0FBRyxNQUFNLElBQUksTUFBOEMsOENBQThDLEtBQUssd0JBQXdCLE1BQU0sS0FBSyxLQUFLLGlCQUFpQixDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUUsRUFBd0M7R0FDN1UsSUFBSSxXQUFXLFdBQVcsV0FBVyxVQUFVO0lBQzlDLE1BQU0sTUFBTSxJQUFJLElBQUksSUFBSTtJQUN4QixJQUFJLElBQUksU0FBUyxXQUFXLElBQUksR0FBRyxPQUFPLElBQUk7U0FDekMsSUFBSSxDQUFDLGNBQWMsS0FBSyxLQUFLLE1BQU0sR0FBRztLQUMxQyxPQUFPLFdBQVcsR0FBRztLQUNyQixTQUFTLEtBQUs7SUFDZjtHQUNEO0dBQ0EsSUFBSSxRQUFRLFFBQVEsaUJBQWlCO0dBQ3JDLFFBQVEsT0FBTztHQUNmLFNBQVMsUUFBUSxJQUFJLFlBQVksSUFBSTtHQUNyQyxPQUFPO0VBQ1I7RUFDQSxLQUFLLGNBQWMsU0FBUztHQUMzQixNQUFNLFNBQVMsS0FBSztHQUNwQixNQUFNLFdBQVcsS0FBSztHQUN0QixNQUFNLFNBQVMsTUFBTTtHQUNyQixNQUFNLFlBQVksQ0FBQztHQUNuQixNQUFNLGVBQWUsQ0FBQztHQUN0QixLQUFLLE1BQU0sQ0FBQyxJQUFJLFVBQVUsUUFBUSxJQUFJLENBQUMsVUFBVSxPQUFPLEtBQUssR0FBRztJQUMvRCxhQUFhLEtBQUssRUFBRTtJQUNwQixVQUFVLEtBQUssS0FBSztHQUNyQjtHQUNBLE1BQU0sUUFBUSxDQUFDO0dBQ2YsS0FBSyxNQUFNLENBQUMsWUFBWSxZQUFZLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLFFBQVEsS0FBSyxNQUFNLEdBQUc7SUFDeEYsTUFBTSxLQUFLLFVBQVU7SUFDckIsVUFBVSxLQUFLLEdBQUcsT0FBTztHQUMxQjtHQUNBLEtBQUssTUFBTSxNQUFNLGNBQWMsT0FBTyxPQUFPLEVBQUU7R0FDL0MsS0FBSyxNQUFNLGNBQWMsT0FBTyxTQUFTLE9BQU8sVUFBVTtHQUMxRCxLQUFLLE1BQU0sU0FBUyxXQUFXO0lBQzlCLE1BQU0sU0FBUyxNQUFNO0lBQ3JCLE1BQU0sVUFBVSxLQUFLO0lBQ3JCLElBQUksVUFBVSxDQUFDLEVBQUUsT0FBTyxJQUFJO0tBQzNCLElBQUksS0FBSyxVQUFVLElBQUksTUFBTSxFQUFFLE1BQU0sUUFBUSxLQUFLLFNBQVMsT0FBTyxNQUFNLEVBQUU7S0FDMUUsTUFBTSxLQUFLLE9BQU8sRUFBRTtJQUNyQjtHQUNEO0dBQ0EsS0FBSyxNQUFNLGNBQWMsT0FBTyxXQUFXLE1BQU07RUFDbEQ7RUFDQSxLQUFLLGlCQUFpQjtFQUN0QixLQUFLLGdCQUFnQixTQUFTLG1CQUFtQixNQUFNLElBQUk7RUFDM0QsS0FBSyxjQUFjLFVBQVUsU0FBUztHQUNyQyxNQUFNLGdCQUFnQjtJQUNyQixHQUFHO0lBQ0gsSUFBSSxTQUFTLEtBQUssWUFBWSxTQUFTLFFBQVEsSUFBSSxTQUFTLElBQUksS0FBSyxRQUFRLGVBQWUsS0FBSyxnQkFBZ0IsSUFBSSxLQUFLO0lBQzFILFFBQVEsU0FBUyxVQUFVLENBQUM7SUFDNUIsYUFBYTtHQUNkO0dBQ0EsTUFBTSxPQUFPLEtBQUssY0FBYyxhQUFhO0dBQzdDLE1BQU0sWUFBWSxLQUFLLE9BQU8sT0FBTyxJQUFJLE1BQU07R0FDL0MsSUFBSSxNQUFNLFdBQVcsQ0FBQyxXQUFXLE9BQU87R0FDeEMsTUFBTSxlQUFlLE1BQU0sV0FBVyxDQUFDLFlBQVksS0FBSyxpQkFBaUIsS0FBSyxPQUFPLGlCQUFpQixJQUFJLEtBQUssS0FBSyxPQUFPLFNBQVMsSUFBSTtHQUN4SSxNQUFNLFFBQVEsZ0JBQWdCLEtBQUssVUFBVSxNQUFNLGlCQUFpQixPQUFPLE1BQU0sU0FBUyxPQUFPLGFBQWEsVUFBVSxLQUFLLGFBQWE7R0FDMUksSUFBSSxDQUFDLE9BQU8sT0FBTztHQUNuQixJQUFJLFNBQVMsUUFDUjtRQUFBLENBQUMsVUFBVSxNQUFNLFdBQVcsU0FBUyxRQUFRLElBQUksR0FBRyxPQUFPO0dBQUE7R0FFaEUsSUFBSSxNQUFNLGlCQUFpQixNQUFNLE9BQU8sVUFBVSxhQUFhLFFBQVEsS0FBSyxRQUFRLElBQUksSUFBSSxNQUFNLFlBQVk7R0FDOUcsT0FBTyxNQUFNO0VBQ2Q7RUFDQSxLQUFLLGlCQUFpQjtFQUN0QixJQUFJLFFBQVEsNkJBQTZCLFFBQVEsS0FBSyxvQkFBb0IscUJBQXFCLFFBQVEsMkJBQTJCO0VBQ2xJLEtBQUssT0FBTztHQUNYLHFCQUFxQjtHQUNyQixrQkFBa0I7R0FDbEIscUJBQXFCO0dBQ3JCLFNBQVMsS0FBSztHQUNkLEdBQUc7R0FDSCxlQUFlLFFBQVEsaUJBQWlCO0dBQ3hDLGNBQWMsUUFBUSxnQkFBZ0I7R0FDdEMsaUJBQWlCLFFBQVEsbUJBQW1CO0dBQzVDLGFBQWEsUUFBUSxlQUFlO0dBQ3BDLG1CQUFtQixRQUFRLHFCQUFxQjtFQUNqRCxDQUFDO0VBQ0QsSUFBSSxFQUFjLE9BQU8sYUFBYSxjQUFjLEtBQUssaUJBQWlCO0NBQzNFO0NBQ0EsVUFBVTtFQUNULE9BQU8sQ0FBQyxDQUFDLEtBQUssUUFBUTtDQUN2QjtDQUNBLElBQUksUUFBUTtFQUNYLE9BQU8sS0FBSyxPQUFPLFFBQVEsSUFBSTtDQUNoQztDQUNBLFVBQVUsUUFBUTtFQUNqQixPQUFPLE9BQU8sTUFBTSxNQUFNO0VBQzFCLEtBQUssbUNBQW1DLElBQUksUUFBUTtFQUNwRCxJQUFJLENBQWMsS0FBSyxVQUFXLEtBQUssa0NBQWtDLElBQUksUUFBUTtFQUNyRixNQUFNLGdCQUFnQixLQUFLLFFBQVE7RUFDbkMsSUFBSSxlQUFlO0dBQ2xCLGNBQWMsS0FBSyxXQUFXO0dBQzlCLElBQUksS0FBSyxXQUFXLGNBQWMsUUFBUSxlQUFlLGNBQWMsaUJBQWlCLGNBQWMsT0FBTyxlQUFlLENBQUM7R0FDN0gsS0FBSyxXQUFXLGNBQWMsTUFBTTtFQUNyQztDQUNEO0NBQ0Esb0JBQW9CLE1BQU0sTUFBTTtFQUMvQixNQUFNLENBQUMsc0JBQXNCLFdBQVcsY0FBYyxLQUFLLGlCQUFpQixLQUFLLFFBQVE7RUFDekYsSUFBSSxnQkFBZ0I7RUFDcEIsSUFBSSxtQkFBbUI7RUFDdkIsSUFBSSxhQUFhLFdBQVcsU0FBUyxPQUFPLFVBQVUsUUFBUSxjQUFjLEtBQUssUUFBUSxHQUFHO0dBQzNGLElBQUksS0FBSyxRQUFRLGVBQWUsZ0JBQWdCLENBQUMsR0FBRyxlQUFlLEtBQUssUUFBUSxhQUFhO1FBQ3hGLG1CQUFtQjtFQUN6QjtFQUNBLE1BQU0sbUJBQW1CLG1CQUFtQiwwQkFBMEIsS0FBSyxRQUFRLGNBQWMsYUFBYSxJQUFJLEtBQUs7RUFDdkgsTUFBTSxVQUFVLElBQUksTUFBTSxjQUFjLE1BQU07RUFDOUMsTUFBTSxZQUFZLEtBQUs7RUFDdkIsTUFBTSxjQUFjLE9BQU8sVUFBVTtHQUNwQyxNQUFNLFFBQVEsVUFBVTtHQUN4QixPQUFPLE9BQU8sWUFBWSxNQUFNLEtBQUssUUFBUSxVQUFVLEtBQUssUUFBUSxnQkFBZ0IsVUFBVSxNQUFNLGNBQWMsVUFBVSxZQUFZLE1BQU0sRUFBRSxJQUFJLEtBQUs7RUFDMUo7RUFDQSxJQUFJO0VBQ0osS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLGNBQWMsUUFBUSxTQUFTO0dBQzFELE1BQU0sUUFBUSxjQUFjO0dBQzVCLE1BQU0sY0FBYyxRQUFRLFFBQVE7R0FDcEMsSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0o7SUFDQyxNQUFNLGVBQWUsYUFBYSxVQUFVLEtBQUs7SUFDakQsTUFBTSxxQkFBcUIsYUFBYSxpQkFBaUIsS0FBSztJQUM5RCxJQUFJO0tBQ0gsTUFBTSxlQUFlLGVBQWUsTUFBTSxRQUFRLGdCQUFnQixFQUFFLEdBQUcsYUFBYSxDQUFDLEtBQUssS0FBSztLQUMvRixpQkFBaUI7TUFDaEIsR0FBRztNQUNILEdBQUc7S0FDSjtLQUNBLG9CQUFvQjtNQUNuQixHQUFHO01BQ0gsR0FBRztLQUNKO0lBQ0QsU0FBUyxLQUFLO0tBQ2IsSUFBSSxtQkFBbUI7S0FDdkIsSUFBSSxFQUFFLGVBQWUsbUJBQW1CLG1CQUFtQixJQUFJLGlCQUFpQixJQUFJLFNBQVMsRUFBRSxPQUFPLElBQUksQ0FBQztLQUMzRyxJQUFJLE1BQU0sY0FBYyxNQUFNO0tBQzlCLGlCQUFpQjtLQUNqQixvQkFBb0IsQ0FBQztLQUNyQixjQUFjO0lBQ2Y7R0FDRDtHQUNBLElBQUksYUFBYTtHQUNqQixJQUFJLGlCQUFpQjtHQUNyQixJQUFJO0lBQ0gsYUFBYSxNQUFNLFFBQVEsYUFBYSxFQUFFLFFBQVEsZUFBZSxDQUFDLEtBQUs7SUFDdkUsaUJBQWlCLGFBQWEsS0FBSyxVQUFVLFVBQVUsS0FBSyxLQUFLO0dBQ2xFLFNBQVMsT0FBTztJQUNmLElBQUksTUFBTSxjQUFjLE1BQU07SUFDOUIsZ0JBQWdCO0dBQ2pCO0dBQ0EsTUFBTSxhQUFhLFdBQVc7R0FDOUIsTUFBTSxtQkFBbUIsTUFBTSxpQkFBaUIsZ0JBQWdCLE1BQU0sVUFBVSxNQUFNLGdCQUFnQixXQUFXLEtBQUssbUJBQW1CLFVBQVUsSUFBSSxNQUFNO0dBQzdKLE1BQU0sVUFBVSxNQUFNLEtBQUssbUJBQW1CO0dBQzlDLE1BQU0sZ0JBQWdCLFdBQVcsT0FBTyxLQUFLO0dBQzdDLE1BQU0sZ0JBQXlELE1BQU0saUJBQWlCLEtBQUssSUFBSSxLQUFLLE9BQU8sSUFBSSxPQUFPLE1BQU0sZUFBZSxPQUFPLFVBQVUsZ0JBQWdCLEtBQUs7R0FDakwsZUFBZSxlQUFlLGlCQUFpQixPQUFPLE9BQU8sWUFBWSxZQUFZO0dBQ3JGLElBQUk7R0FDSixJQUFJLENBQUMsZUFBZSxJQUFJO0lBQ3ZCLG9CQUFvQixPQUFPLFlBQVk7R0FDeEMsU0FBUyxLQUFLO0lBQ2IsSUFBSSxXQUFXLEdBQUcsS0FBSyxXQUFXLEdBQUcsR0FBRyxjQUFjO1NBQ2pELGNBQWMsSUFBSSxlQUFlLElBQUksU0FBUyxFQUFFLE9BQU8sSUFBSSxDQUFDO0lBQ2pFLElBQUksTUFBTSxjQUFjLE1BQU07R0FDL0I7R0FDQSxNQUFNLFFBQVEsZ0JBQWdCLFNBQVM7R0FDdkMsSUFBSTtHQUNKLElBQUksZUFBZSxRQUFRO0lBQzFCLEdBQUc7SUFDSDtJQUNBLFFBQVEsZ0JBQWdCLHFCQUFxQixjQUFjLFFBQVEsY0FBYyxJQUFJLHFCQUFxQixjQUFjLFFBQVEsY0FBYztJQUM5SSxlQUFlO0lBQ2Y7R0FDRDtRQUNLO0lBQ0osTUFBTSxTQUFTLGVBQWUsS0FBSyxJQUFJLFlBQVk7SUFDbkQsUUFBUTtLQUNQLElBQUk7S0FDSixLQUFpQixLQUFLLFdBQVcsS0FBSyxJQUFJLE1BQU0sUUFBUTtLQUN4RDtLQUNBLFNBQVMsTUFBTTtLQUNmLFFBQVEsZUFBZSxVQUFVO0tBQ2pDLGVBQWU7S0FDZixVQUFVO0tBQ1YsV0FBVyxLQUFLLElBQUk7S0FDcEIsUUFBUSxnQkFBZ0IscUJBQXFCLGNBQWMsUUFBUSxjQUFjLElBQUk7S0FDckYsZUFBZTtLQUNmO0tBQ0E7S0FDQSxZQUFZO0tBQ1osT0FBTyxLQUFLO0tBQ1o7S0FDQSxTQUFTLENBQUM7S0FDVixpQkFBaUIsTUFBTSxlQUFlLElBQUksZ0JBQWdCO0tBQzFEO0tBQ0EsWUFBWSxnQkFBZ0IsaUJBQWlCLGNBQWMsWUFBWSxVQUFVLElBQUk7S0FDckYsU0FBUztLQUNULFNBQVM7S0FDVCxZQUFZLE1BQU0sUUFBUSxjQUFjLENBQUM7S0FDekMsVUFBVSxNQUFNO0lBQ2pCO0dBQ0Q7R0FDQSxNQUFNLFlBQVkscUJBQXFCLE1BQU07R0FDN0MsSUFBSSxNQUFNLGFBQWEsQ0FBQyxXQUFXLE1BQU0sUUFBUSxLQUFLO0dBQ3RELE1BQU0sWUFBWTtHQUNsQixRQUFRLFNBQVM7RUFDbEI7RUFDQSxLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsUUFBUSxRQUFRLFNBQVM7R0FDcEQsTUFBTSxRQUFRLFFBQVE7R0FDdEIsTUFBTSxTQUFTLE1BQU0sVUFBVSxTQUFTLHFCQUFxQixNQUFNLFFBQVEsWUFBWSxJQUFJO0dBQzNGLElBQUksTUFBTSxhQUFhLE1BQU0sVUFBVSxDQUFDO0VBQ3pDO0VBQ0EsT0FBTztDQUNSOzs7Ozs7Q0FNQSx1QkFBdUIsVUFBVTtFQUNoQyxNQUFNLGNBQWMsS0FBSyxLQUFLLE9BQU8sSUFBSSxJQUFJLENBQUM7RUFDOUMsTUFBTSxpQkFBaUIsY0FBYyxLQUFLLE9BQU8sUUFBUSxJQUFJLFdBQVcsQ0FBQyxDQUFDLElBQUksSUFBSSxLQUFLO0VBQ3ZGLE1BQU0sbUJBQW1CLGdCQUFnQjtFQUN6QyxNQUFNLFNBQVMsS0FBSyxpQkFBaUIsSUFBSSxRQUFRO0VBQ2pELElBQUksVUFBVSxPQUFPLE9BQU8sa0JBQWtCLE9BQU8sT0FBTztFQUM1RCxNQUFNLENBQUMsZUFBZSxhQUFhLEtBQUssaUJBQWlCLFNBQVMsUUFBUTtFQUMxRSxNQUFNLFlBQVksS0FBSyxhQUFhO0VBQ3BDLE1BQU0sb0JBQW9CLEVBQUUsR0FBRyxTQUFTLE9BQU87RUFDL0MsS0FBSyxNQUFNLFNBQVMsZUFBZSxJQUFJO0dBQ3RDLE9BQU8sT0FBTyxtQkFBbUIsZUFBZSxNQUFNLFFBQVEsZ0JBQWdCLGlCQUFpQixDQUFDO0VBQ2pHLFFBQVEsQ0FBQztFQUNULE1BQU0saUJBQWlCLGtCQUFrQixlQUFlLFlBQVksVUFBVSxNQUFNLGVBQWUsYUFBYSxTQUFTO0VBQ3pILElBQUk7RUFDSixJQUFJLGdCQUFnQixTQUFTLGVBQWU7T0FDdkM7R0FDSixNQUFNLGVBQWU7R0FDckIsS0FBSyxNQUFNLFNBQVMsZUFBZSxJQUFJO0lBQ3RDLG9CQUFvQixPQUFPLFlBQVk7R0FDeEMsUUFBUSxDQUFDO0dBQ1QsU0FBUztFQUNWO0VBQ0EsTUFBTSxTQUFTO0dBQ2Q7R0FDQSxVQUFVO0dBQ1Y7R0FDQTtFQUNEO0VBQ0EsS0FBSyxpQkFBaUIsSUFBSSxVQUFVLENBQUMsa0JBQWtCLE1BQU0sQ0FBQztFQUM5RCxPQUFPO0NBQ1I7QUFDRDtBQUNBLGVBQWUsbUJBQW1CLFFBQVEsTUFBTSxFQUFFLFNBQVMsaUJBQWlCO0NBQzNFLElBQUksb0JBQW9CLE1BQU0sT0FBTyxpQkFBaUIsR0FBRztFQUNiLFFBQVEsS0FBSyw2Q0FBNkMsTUFBTTtFQUMzRztDQUNEO0NBQ0EsSUFBSSxDQUFDLGVBQWU7RUFDbkIsTUFBTSxXQUFXLE9BQU8sUUFBUSxhQUFhO0VBQzdDLEtBQUssTUFBTSxXQUFXLFVBQVUsSUFBSSxTQUFTLFdBQ3hDO09BQUEsTUFBTSxRQUFRLFVBQVU7SUFDM0IsaUJBQWlCLE9BQU8sUUFBUTtJQUNoQyxjQUFjLE9BQU8sUUFBUTtJQUM3QixRQUFRLFVBQVUsWUFBWTtHQUMvQixDQUFDLEdBQUc7RUFBQTtDQUVOO0NBQ0EsT0FBTyxRQUFRLDBCQUEwQixJQUFJO0NBQzdDLElBQUksU0FBUyxPQUFPLFNBQVMsUUFBUSxJQUFJO01BQ3BDLE9BQU8sU0FBUyxPQUFPO0FBQzdCO0FBT0MsV0FBVyxVQUFVLHFCQUFxQjtBQUMxQyxXQUFXLFVBQVUsZ0JBQWdCLGlCQUFpQjtDQUNyRCxLQUFLLGdCQUFnQixLQUFLO0NBQzFCLEtBQUsscUJBQXFCO0NBQzFCLE1BQU0sbUJBQW1CLElBQUk7QUFDOUI7O0FBR0QsSUFBSSxtQkFBbUIsY0FBYyxNQUFNLENBQUM7O0FBRTVDLElBQUksaUJBQWlCLGNBQWMsTUFBTSxDQUFDO0FBQzFDLElBQU1BLGVBQWEsUUFBUSxJQUFJLFNBQVMsR0FBRyxLQUFLLElBQUksU0FBUyxJQUFJLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSTtBQUNwRixTQUFTLGFBQWEsR0FBRyxHQUFHO0NBQzNCLE9BQU9BLFlBQVUsQ0FBQyxNQUFNQSxZQUFVLENBQUM7QUFDcEM7Ozs7O0FBS0EsU0FBUyxPQUFPLElBQUksS0FBSztDQUN4QixPQUFPLE9BQU8sR0FBRyxTQUFTO0VBQ3pCLFFBQVEsTUFBTSxHQUFHLEVBQUEsQ0FBRyxPQUFPLFVBQVUsQ0FBQyxHQUFHLElBQUk7Q0FDOUM7QUFDRDtBQVdBLFNBQVMsZUFBZSxnQkFBZ0IsT0FBTztDQUM5QyxJQUFJLGtCQUFrQixNQUFNLE9BQU8sQ0FBQztDQUNwQyxJQUFJLGVBQWUsZ0JBQWdCO0VBQ2xDLE1BQU0sU0FBUyxlQUFlLFlBQVksQ0FBQyxTQUFTLEtBQUs7RUFDekQsSUFBSSxrQkFBa0IsU0FBUyxNQUFNLElBQUksaUJBQWlCLGdDQUFnQztFQUMxRixJQUFJLE9BQU8sUUFBUSxNQUFNLElBQUksaUJBQWlCLEtBQUssVUFBVSxPQUFPLFFBQVEsS0FBSyxHQUFHLENBQUMsR0FBRyxFQUFFLE9BQU8sT0FBTyxDQUFDO0VBQ3pHLE9BQU8sT0FBTztDQUNmO0NBQ0EsSUFBSSxXQUFXLGdCQUFnQixPQUFPLGVBQWUsTUFBTSxLQUFLO0NBQ2hFLElBQUksT0FBTyxtQkFBbUIsWUFBWSxPQUFPLGVBQWUsS0FBSztDQUNyRSxPQUFPLENBQUM7QUFDVDtBQUNBLFNBQVMsa0JBQWtCLE1BQU0sTUFBTTtDQUN0QyxJQUFJLFNBQVMsS0FBSyxLQUFLLFNBQVMsTUFBTSxPQUFPO0NBQzdDLE1BQU0sT0FBTyxPQUFPLE9BQU8sSUFBSTtDQUMvQixJQUFJLFNBQVMsU0FBUyxTQUFTLE1BQU0sT0FBTztDQUM1QyxJQUFJLE9BQU8sU0FBUyxZQUFZO0VBQy9CLE9BQU8sT0FBTyxNQUFNLElBQUk7RUFDeEIsT0FBTyxPQUFPLE9BQU8sTUFBTSxLQUFLLElBQUksQ0FBQztDQUN0QztDQUNBLE9BQU8sT0FBTyxPQUFPLE1BQU0sTUFBTSxJQUFJO0FBQ3RDO0FBQ0EsU0FBUyxxQkFBcUIsTUFBTSxlQUFlO0NBQ2xELElBQUksT0FBTyxTQUFTLFlBQVksT0FBTztDQUN2QyxJQUFJLENBQUMsaUJBQWlCLFNBQVMsU0FBUyxTQUFTLE1BQU0sT0FBTztDQUM5RCxPQUFPLFNBQVMsS0FBSyxLQUFLLFNBQVMsUUFBUSxjQUFjLE1BQU0sU0FBUyxPQUFPLFNBQVMsWUFBWSxDQUFDLE9BQU8sS0FBSyxNQUFNLEtBQUssRUFBRSxDQUFDO0FBQ2hJO0FBQ0EsSUFBTSxlQUFlLE9BQU8sT0FBTyxDQUFDLENBQUM7QUFDckMsU0FBUyxxQkFBcUIsWUFBWSx1QkFBdUI7Q0FDaEUsTUFBTSxjQUFjLENBQUM7Q0FDckIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFdBQVcsUUFBUSxLQUFLO0VBQzNDLE1BQU0sZUFBZSxXQUFXLEVBQUUsQ0FBQztFQUNuQyxJQUFJLFlBQVksY0FDWDtPQUFBLGFBQWEsUUFBUSxhQUFhLFlBQVksS0FBSyxHQUFHLGFBQWEsT0FBTyxXQUFXO0VBQUEsT0FDbkYsSUFBSSxhQUFhLG9CQUFvQixhQUFhLG1CQUFtQjtHQUMzRSxNQUFNLG9CQUFvQixFQUFFLFFBQVEsV0FBVztJQUM5QyxNQUFNLFNBQVMsS0FBSyxhQUFhLG1CQUFtQixhQUFhLGlCQUFpQixRQUFRLE1BQU0sU0FBUyxLQUFLLElBQUksR0FBRyxNQUFNLElBQUksTUFBTTtJQUNySSxPQUFPLGFBQWEsb0JBQW9CLGFBQWEsa0JBQWtCLFFBQVEsTUFBTSxTQUFTLEtBQUssSUFBSSxHQUFHLE1BQU0sSUFBSTtHQUNySDtHQUNBLFlBQVksS0FBSyxnQkFBZ0I7RUFDbEM7RUFDQSxNQUFNLHNCQUFzQixhQUFhO0VBQ3pDLElBQUkseUJBQXlCLHFCQUFxQjtHQUNqRCxNQUFNLFlBQVksRUFBRSxRQUFRLE1BQU0sV0FBVztJQUM1QyxNQUFNLFNBQVMsS0FBSyxNQUFNO0lBQzFCLElBQUk7S0FDSCxNQUFNLFlBQVksZUFBZSxxQkFBcUIsTUFBTTtLQUM1RCxJQUFJLFFBQVEsV0FDTjtXQUFBLE1BQU0sT0FBTyxXQUFXLElBQUksRUFBRSxPQUFPLFNBQVMsQ0FBQyxLQUFLLDhCQUE4QixJQUFJLElBQUksRUFBQSxDQUFHLElBQUksS0FBSyxVQUFVLElBQUk7S0FBQTtLQUUxSCxPQUFPO01BQ04sR0FBRztNQUNILEdBQUc7S0FDSjtJQUNELFFBQVEsQ0FBQztJQUNULE9BQU87R0FDUjtHQUNBLFlBQVksS0FBSyxRQUFRO0VBQzFCO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLHNCQUFzQixhQUFhLFFBQVEsTUFBTTtDQUN6RCxNQUFNLGFBQWEsT0FBTyxlQUFlLFNBQVM7RUFDakQsSUFBSSxTQUFTLFlBQVksUUFBUTtHQUNoQyxJQUFJLENBQUMsS0FBSyxRQUFRLE9BQU8sQ0FBQztHQUMxQixJQUFJLEtBQUssV0FBVyxNQUFNLE9BQU87R0FDakMsTUFBTSxTQUFTLGlCQUFpQixLQUFLLFFBQVEsYUFBYTtHQUMxRCxJQUFJLE1BQU0sS0FBSyxXQUFXO0dBQzFCLE9BQU87RUFDUjtFQUNBLE1BQU0sUUFBUSxXQUFXLGdCQUFnQjtHQUN4QyxJQUFJLGFBQWE7SUFDaEIsTUFBTSxXQUFXLFFBQVEsQ0FBQztJQUMxQixPQUFPO0tBQ04sUUFBUSxVQUFVLFFBQVEsR0FBRyxXQUFXLFFBQVE7S0FDaEQsTUFBTTtJQUNQO0dBQ0Q7R0FDQSxPQUFPLFVBQVUsUUFBUSxHQUFHLFdBQVcsSUFBSTtFQUM1QztFQUNBLE9BQU8sWUFBWSxNQUFNLENBQUM7R0FDekIsUUFBUTtHQUNSO0dBQ0E7RUFDRCxDQUFDO0NBQ0Y7Q0FDQSxPQUFPLFVBQVUsR0FBRyxNQUFNO0FBQzNCO0FBQ0EsU0FBUywwQkFBMEIsY0FBYyxRQUFRO0NBQ3hELElBQUksaUJBQWlCLFFBQVE7RUFDNUIsSUFBSTtFQUNKLEtBQUssSUFBSSxJQUFJLE9BQU8sU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQzVDLE1BQU0sUUFBUSxPQUFPO0dBQ3JCLElBQUksTUFBTSxRQUFRLG1CQUFtQixPQUFPLE1BQU07R0FDbEQsYUFBYSxNQUFNLFlBQVksTUFBTTtFQUN0QztFQUNBLElBQUksVUFBVSxPQUFPO0NBQ3RCO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxvQkFBb0IsT0FBTyxtQkFBbUI7Q0FDdEQsTUFBTSxjQUFjLE1BQU0sUUFBUSxRQUFRLFNBQVMsTUFBTSxRQUFRO0NBQ2pFLElBQUksYUFBYSxPQUFPLE9BQU8sbUJBQW1CLFlBQVksaUJBQWlCLENBQUM7QUFDakY7OztBQzE4QkEsU0FBUyxrQkFBa0IsT0FBTyxRQUFRO0NBQ3pDLE1BQU0sU0FBUyxVQUFVLE1BQU07Q0FDL0IsTUFBTSxRQUFRLEtBQUs7QUFDcEI7QUFDQSxTQUFTLGlCQUFpQixPQUFPLE1BQU07Q0FDdEMsT0FBTyxNQUFNLFFBQVEsS0FBSyxFQUFFLFVBQVU7QUFDdkM7QUFDQSxTQUFTLGVBQWUsT0FBTyxnQkFBZ0I7Q0FDOUMsTUFBTSxZQUFZLGlCQUFpQixPQUFPLFdBQVc7Q0FDckQsSUFBSSxVQUFVLGlCQUFpQixPQUFPLGtCQUFrQjtDQUN4RCxJQUFJLGdCQUFnQjtFQUNuQixJQUFJLFNBQVMsVUFBVSxRQUFRLEtBQUssY0FBYztPQUM3QyxlQUFlO0NBQ3JCO0NBQ0EsSUFBSSxhQUFhLFNBQVMsT0FBTyxRQUFRLElBQUksQ0FBQyxXQUFXLE9BQU8sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7Q0FDaEYsT0FBTyxhQUFhO0FBQ3JCO0FBQ0EsU0FBUyxlQUFlLE9BQU8sZUFBZSxnQkFBZ0I7Q0FDN0QsTUFBTSxrQkFBa0Isa0JBQWtCLFFBQVEsS0FBSyxJQUFJLGdCQUFnQixpQkFBaUIsT0FBTyxhQUFhLElBQUksZUFBZSxPQUFPLGNBQWM7Q0FDeEosTUFBTSxVQUFVLE1BQU07Q0FDdEIsSUFBSSxTQUFTLE9BQU8sWUFBWSxPQUFPLFVBQVUsSUFBSSxRQUFRLEtBQUssU0FBUztDQUMzRSxJQUFJLENBQUMsTUFBTSxRQUFRLE9BQU8sVUFBVTtDQUNwQyxNQUFNLFVBQVUsTUFBTSxPQUFPLENBQUMsQ0FBQyxNQUFNLGNBQWM7RUFDbEQsSUFBNkMsTUFBTSxVQUFVLFNBQVM7R0FDckUsTUFBTSxFQUFFLElBQUksS0FBSyxHQUFHLFlBQVksVUFBVTtHQUMxQyxPQUFPLE9BQU8sTUFBTSxTQUFTLE9BQU87R0FDcEMsTUFBTSxRQUFRO0VBQ2Y7Q0FDRCxJQUFJLFVBQVU7RUFDYixJQUE2QyxNQUFNLFVBQVUsU0FBUyxNQUFNLFFBQVEsS0FBSztFQUN6RixNQUFNO0NBQ1AsQ0FBQztDQUNELE1BQU0sUUFBUTtDQUNkLE9BQU8sUUFBUSxLQUFLLFNBQVM7QUFDOUI7O0FBRUEsU0FBUyxvQkFBb0IsU0FBUztDQUNyQyxNQUFNLE1BQU0sUUFBUSxXQUFXLFVBQVUsTUFBTSxXQUFXLGFBQWEsTUFBTSxTQUFTLElBQUk7Q0FDMUYsT0FBTyxPQUFPLE1BQU0sUUFBUSxTQUFTLFFBQVEsTUFBTSxHQUFHLEdBQUcsSUFBSTtBQUM5RDs7Ozs7Ozs7OztBQVVBLFNBQVMsa0JBQWtCLFFBQVEsU0FBUyxVQUFVO0NBQ3JELE1BQU0sS0FBSyxPQUFPO0NBQ2xCLE9BQU8sV0FBVyxLQUFLLE9BQU8sWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sVUFBVSxNQUFNLFlBQVksT0FBTztBQUMzRjs7QUFFQSxTQUFTLGlCQUFpQixTQUFTO0NBQ2xDLElBQUksTUFBTSxRQUFRO0NBQ2xCLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxLQUFLLFNBQVM7RUFDekMsTUFBTSxRQUFRLFFBQVE7RUFDdEIsSUFBSSxNQUFNLGNBQWMsS0FBSyxHQUFHO0dBQy9CLE1BQU0sS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLFFBQVEsR0FBRyxNQUFNLFNBQVMsQ0FBQztHQUN4RDtFQUNEO0VBQ0EsSUFBSSxNQUFNLFdBQVcsYUFBYSxNQUFNLFdBQVc7R0FDbEQsTUFBTSxRQUFRO0dBQ2Q7RUFDRDtDQUNEO0NBQ0EsT0FBTyxNQUFNLFFBQVEsU0FBUyxRQUFRLE1BQU0sR0FBRyxHQUFHLElBQUk7QUFDdkQ7QUFDQSxJQUFNQyxZQUFVO0FBQ2hCLElBQU1DLFVBQVE7QUFDZCxJQUFNQyxjQUFZO0FBQ2xCLElBQU1DLGVBQWE7QUFDbkIsSUFBTSxtQkFBbUIsQ0FBQyxDQUFDO0FBQzNCLFNBQVMsVUFBVSxRQUFRO0NBQzFCLE9BQU8sT0FBTyxPQUFPLE9BQU87QUFDN0I7QUFDQSxTQUFTQyxVQUFRLE9BQU8sUUFBUTtDQUMvQixJQUFJLE9BQU8sU0FBUyxPQUFPLFFBQVEsS0FBSyxDQUFDLFFBQVEsT0FBTyxNQUFNLEdBQUcsS0FBSyxDQUFDO0NBQ3ZFLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztFQUN2QyxNQUFNLGNBQWMsT0FBTyxNQUFNO0VBQ2pDLE9BQU8saUJBQWlCLFNBQVMsT0FBTyxFQUFFLE1BQU0sS0FBSyxDQUFDO0VBQ3RELFFBQVEsUUFBUSxLQUFLLENBQUMsQ0FBQyxLQUFLLFNBQVMsTUFBTSxDQUFDLENBQUMsV0FBVyxPQUFPLG9CQUFvQixTQUFTLEtBQUssQ0FBQztDQUNuRyxDQUFDO0FBQ0Y7QUFDQSxTQUFTQyxXQUFTLFFBQVEsT0FBTztDQUNoQyxPQUFPLE9BQU8sV0FBVyxNQUFNO0FBQ2hDO0FBQ0EsU0FBU0MsWUFBVSxPQUFPLFVBQVUsU0FBUztDQUM1QyxJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU8sQ0FBQ0gsY0FBWSxLQUFLO0NBQ2hELElBQUksV0FBVyxLQUFLLEdBQUc7RUFDdEIsTUFBTSxZQUFZO0VBQ2xCLE9BQU8sQ0FBQ0QsYUFBVyxLQUFLO0NBQ3pCO0NBQ0EsSUFBSSxDQUFDLFVBQVUsT0FBTyxDQUFDRixXQUFTLEtBQUs7Q0FDckMsSUFBSSxPQUFPLE9BQU8sU0FBUyxZQUFZLFFBQVEsSUFBSSxNQUFNLHdCQUF3QixFQUFFLE9BQU8sTUFBTSxDQUFDO0NBQ2pHLE9BQU8sQ0FBQ0MsU0FBTyxLQUFLO0FBQ3JCO0FBQ0EsU0FBU00saUJBQWUsT0FBTyxPQUFPO0NBQ3JDLElBQUksVUFBVUQsWUFBVSxPQUFPLE1BQU0sTUFBTSxFQUFFO0NBQzdDLElBQUksUUFBUSxPQUFPTCxTQUFPLE9BQU87Q0FDakMsSUFBSTtFQUNILE1BQU0sUUFBUSxVQUFVLFFBQVEsRUFBRTtDQUNuQyxTQUFTLGNBQWM7RUFDdEIsVUFBVUssWUFBVSxjQUFjLE1BQU0sTUFBTSxFQUFFO0NBQ2pEO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxtQkFBbUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxTQUFTO0NBQ2hFLElBQUksUUFBUSxFQUFFLENBQUMsT0FBTyxTQUFTLE9BQU87Q0FDdEMsT0FBT0Usc0JBQW9CLFFBQVEsTUFBTSxPQUFPRCxpQkFBZSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RGO0FBQ0EsZUFBZUUsZ0JBQWMsUUFBUSxNQUFNLFNBQVMsS0FBSyxvQkFBb0IsYUFBYTtDQUN6RixNQUFNLENBQUMsVUFBVSxXQUFXO0NBQzVCLE1BQU0sU0FBUyxRQUFRLEVBQUUsQ0FBQztDQUMxQixNQUFNLFVBQVUsQ0FBQyxDQUFDLFFBQVE7Q0FDMUIsS0FBSyxJQUFJLFFBQVEsUUFBUSxNQUFNLEdBQUcsUUFBUSxLQUFLLFNBQVM7RUFDdkQsTUFBTSxRQUFRLFFBQVE7RUFDdEIsTUFBTSxRQUFRSixXQUFTLFFBQVEsS0FBSztFQUNwQyxNQUFNLGtCQUFrQixRQUFRO0VBQ2hDLE1BQU0sZ0JBQWdCLFFBQVEsUUFBUSxFQUFFLEVBQUUsV0FBVyxPQUFPLFFBQVEsV0FBVyxDQUFDO0VBQ2hGLE1BQU0sU0FBUztHQUNkLFFBQVEsTUFBTTtHQUNkO0dBQ0EsV0FBVyxTQUFTLE9BQU8sU0FBUztJQUNuQyxHQUFHO0lBQ0gsZUFBZTtHQUNoQixDQUFDO0dBQ0QsZUFBZSxPQUFPO0dBQ3RCLE9BQU8sVUFBVSxZQUFZLE1BQU07R0FDbkMsaUJBQWlCLFFBQVE7R0FDekI7R0FDQTtHQUNBLFNBQVMsTUFBTTtFQUNoQjtFQUNBLElBQUk7R0FDSCxNQUFNLGVBQWUsTUFBTSxTQUFTLE1BQU0sUUFBUSxVQUFVLE1BQU0sUUFBUSxRQUFRO0lBQ2pGLEdBQUc7SUFDSCxNQUFNLE1BQU07SUFDWixTQUFTO0dBQ1YsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLO0dBQ2hCLE1BQU0sVUFBVTtJQUNmLEdBQUc7SUFDSCxHQUFHO0dBQ0o7RUFDRCxTQUFTLE9BQU87R0FDZixjQUFjLFFBQVEsS0FBSztHQUMzQixPQUFPLENBQUMsT0FBTyxtQkFBbUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxPQUFPLENBQUM7RUFDdkU7RUFDQSxJQUFJLE9BQU8sU0FBUyxPQUFPLENBQUMsT0FBTyxnQkFBZ0I7RUFDbkQsTUFBTSxrQkFBa0IsTUFBTSxlQUFlLE1BQU07RUFDbkQsSUFBSSxvQkFBb0IsS0FBSyxHQUFHO0dBQy9CLGNBQWMsUUFBUSxLQUFLO0dBQzNCLE9BQU8sQ0FBQyxPQUFPLG1CQUFtQixRQUFRLE1BQU0sT0FBTyxpQkFBaUIsT0FBTyxDQUFDO0VBQ2pGO0VBQ0EsTUFBTSxhQUFhLE1BQU0sUUFBUTtFQUNqQyxJQUFJLENBQUMsWUFBWTtFQUNqQixNQUFNLGlCQUFpQixNQUFNO0VBQzdCLElBQUksU0FBUyxhQUFhO0dBQ3pCLE1BQU0sU0FBUztHQUNmLFFBQVEsRUFBRSxHQUFHO0VBQ2Q7RUFDQSxJQUFJO0dBQ0gsWUFBWSxRQUFRLE9BQU8sY0FBYyxRQUFRLEVBQUU7R0FDbkQsTUFBTSxRQUFRLFdBQVc7SUFDeEIsR0FBRztJQUNILFFBQVEsTUFBTTtJQUNkLFNBQVMsTUFBTTtJQUNmLEdBQUcsT0FBTyxRQUFRO0dBQ25CLENBQUM7R0FDRCxNQUFNLFNBQVMsT0FBTyxPQUFPLE9BQU8sU0FBUyxhQUFhRCxVQUFRLE9BQU8sTUFBTSxJQUFJO0dBQ25GLElBQUksT0FBTyxTQUFTLE9BQU8sQ0FBQyxPQUFPLGdCQUFnQjtHQUNuRCxNQUFNLFVBQVVJLHNCQUFvQixRQUFRLE1BQU0sT0FBT0YsWUFBVSxRQUFRLE9BQU8sTUFBTSxFQUFFLEdBQUcsT0FBTztHQUNwRyxJQUFJLFFBQVEsT0FBT04sV0FBUztJQUMzQixjQUFjLFFBQVEsS0FBSztJQUMzQixPQUFPLENBQUMsT0FBTyxPQUFPO0dBQ3ZCO0dBQ0EsTUFBTSxVQUFVO0lBQ2YsR0FBRyxNQUFNO0lBQ1QsR0FBRztHQUNKO0VBQ0QsU0FBUyxPQUFPO0dBQ2YsY0FBYyxRQUFRLEtBQUs7R0FDM0IsT0FBTyxDQUFDLE9BQU8sbUJBQW1CLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTyxDQUFDO0VBQ3ZFLFVBQVU7R0FDVCxNQUFNLFNBQVM7R0FDZixZQUFZLFFBQVEsT0FBTyxPQUFPLFFBQVEsRUFBRTtFQUM3QztDQUNEO0NBQ0EsbUJBQW1CO0FBQ3BCO0FBQ0EsU0FBUyxtQkFBbUIsUUFBUSxPQUFPLFFBQVE7Q0FDbEQsSUFBSSxDQUFDLFVBQVUsRUFBRSxPQUFPLElBQUk7Q0FDNUIsSUFBSSxPQUFPLFVBQVUsSUFBSSxNQUFNLEVBQUUsTUFBTSxRQUFRO0VBQzlDLE1BQU0sVUFBVSxPQUFPO0VBQ3ZCLElBQUksV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDLFNBQVMsS0FBSyxLQUFLLFFBQVEsRUFBRSxDQUFDLE1BQU0sY0FBYyxVQUFVLE9BQU8sTUFBTSxFQUFFLEtBQUssUUFBUSxFQUFFLENBQUMsTUFBTSxjQUFjLFVBQVUsZUFBZSxZQUFZLEdBQUc7RUFDaE4sT0FBTyxTQUFTLE9BQU8sTUFBTSxFQUFFO0NBQ2hDO0NBQ0EsT0FBTyxPQUFPO0FBQ2Y7QUFDQSxTQUFTLGNBQWMsUUFBUSxPQUFPO0NBQ3JDLE1BQU0sU0FBUyxNQUFNO0NBQ3JCLE1BQU0sVUFBVSxLQUFLO0NBQ3JCLG1CQUFtQixRQUFRLE9BQU8sTUFBTSxDQUFDLEVBQUUsTUFBTTtBQUNsRDs7Ozs7QUFLQSxTQUFTLHVCQUF1QixRQUFRLFVBQVUsTUFBTSxtQkFBbUI7Q0FDMUUsTUFBTSxRQUFRLENBQUM7Q0FDZixLQUFLLE1BQU0sU0FBUyxVQUFVLElBQUksQ0FBQyxNQUFNLFNBQVMsS0FBSyxHQUFHO0VBQ3pELE1BQU0sU0FBUyxNQUFNO0VBQ3JCLE1BQU0sVUFBVSxLQUFLO0VBQ3JCLElBQUkscUJBQXFCLFNBQVMsT0FBTyxLQUFLLE9BQU8sVUFBVSxJQUFJLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTSxNQUFNLGNBQWMsVUFBVSxPQUFPLE1BQU0sRUFBRSxHQUFHLE9BQU8sS0FBSztPQUN4SjtHQUNKLE1BQU0sYUFBYSxtQkFBbUIsUUFBUSxPQUFPLE1BQU07R0FDM0QsSUFBSSxZQUFZLE1BQU0sS0FBSyxVQUFVO0VBQ3RDO0NBQ0Q7Q0FDQSxLQUFLLE1BQU0sY0FBYyxPQUFPLFdBQVcsTUFBTTtBQUNsRDtBQUNBLFNBQVMsc0JBQXNCLFNBQVM7Q0FDdkMsS0FBSyxNQUFNLFNBQVMsU0FBUztFQUM1QixNQUFNLFNBQVMsTUFBTTtFQUNyQixJQUFJLFFBQVEsT0FBTyxFQUFFO0NBQ3RCO0FBQ0Q7QUFDQSxTQUFTLFlBQVksUUFBUSxPQUFPLE9BQU8sT0FBTztDQUNqRCxNQUFNLGFBQWE7Q0FDbkIsSUFBSSxTQUFTLE9BQU8sTUFBTSxPQUFPLE9BQU87Q0FDeEMsTUFBTSxRQUFRLE9BQU8sT0FBTyxRQUFRLElBQUksTUFBTSxPQUFPO0NBQ3JELE1BQU0sWUFBWSxPQUFPLElBQUk7Q0FDN0IsSUFBSSxXQUFXLE9BQU8sTUFBTSxJQUFJLE1BQU0sSUFBSTtFQUN6QyxHQUFHO0VBQ0gsWUFBWTtDQUNiLENBQUM7QUFDRjtBQUNBLFNBQVNVLG1CQUFpQixRQUFRLE1BQU0sT0FBTyxPQUFPLFlBQVksb0JBQW9CLFNBQVM7Q0FDOUYsTUFBTSxXQUFXLEtBQUs7Q0FDdEIsT0FBTztFQUNOLFFBQVEsTUFBTTtFQUNkO0VBQ0EsV0FBVyxTQUFTLE9BQU8sU0FBUztHQUNuQyxHQUFHO0dBQ0gsZUFBZTtFQUNoQixDQUFDO0VBQ0QsT0FBTyxVQUFVLFlBQVksTUFBTTtFQUNuQyxpQkFBaUI7RUFDakI7RUFDQSxNQUFNLE1BQU07RUFDWjtFQUNBLFNBQVMsTUFBTTtFQUNmO0VBQ0EsR0FBRyxPQUFPLFFBQVE7Q0FDbkI7QUFDRDtBQUNBLGVBQWUsYUFBYSxRQUFRLE1BQU0sT0FBTyxPQUFPLFFBQVEsb0JBQW9CLFNBQVM7Q0FDNUYsTUFBTSxRQUFRLFFBQVE7Q0FDdEIsTUFBTSxTQUFTLE1BQU07Q0FDckIsSUFBSSxPQUFPLFNBQVMsT0FBTztDQUMzQixJQUFJLENBQUMsUUFBUSxPQUFPLENBQUNWLFdBQVMsS0FBSyxDQUFDO0NBQ3BDLElBQUksU0FBUyxNQUFNO0NBQ25CLFlBQVksUUFBUSxPQUFPLFVBQVUsS0FBSztDQUMxQyxJQUFJO0VBQ0gsSUFBSSxDQUFDLFFBQVE7R0FDWixNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7R0FDdkMsU0FBUztJQUNSLFFBQVEsUUFBUSxDQUFDLENBQUMsV0FBVyxPQUFPVSxtQkFBaUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxZQUFZLG9CQUFvQixDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxVQUFVSixZQUFVLE9BQU8sT0FBTyxNQUFNLEVBQUUsSUFBSSxVQUFVQSxZQUFVLE9BQU8sTUFBTSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxXQUFXO0tBQ2pQLElBQUksT0FBTyxPQUFPTixhQUFXLE9BQU8sVUFBVSxJQUFJLE1BQU0sRUFBRSxNQUFNLFFBQVE7TUFDdkUsT0FBTyxTQUFTLE9BQU8sTUFBTSxFQUFFO01BQy9CLElBQUksQ0FBQyxPQUFPLElBQUksV0FBVyxNQUFNO0tBQ2xDO0tBQ0EsT0FBTyxPQUFPLE9BQU9DLFdBQVMsT0FBTyxLQUFLTSxpQkFBZSxPQUFPLE9BQU8sRUFBRSxJQUFJO0lBQzlFLENBQUM7SUFDRDtJQUNBO0dBQ0Q7R0FDQSxDQUFDLE9BQU8sNkJBQTZCLElBQUksSUFBSSxFQUFBLENBQUcsSUFBSSxNQUFNLElBQUksTUFBTTtFQUNyRTtFQUNBLE1BQU0sVUFBVTtFQUNoQixNQUFNLGtCQUFrQixPQUFPO0VBQy9CLE9BQU9DLHNCQUFvQixRQUFRLE1BQU0sT0FBTyxNQUFNSixVQUFRLE9BQU8sSUFBSSxNQUFNLEdBQUcsT0FBTztDQUMxRixTQUFTLE9BQU87RUFDZixJQUFJLFVBQVUsVUFBVSxDQUFDLE9BQU8sU0FBUyxNQUFNO0VBQy9DLGNBQWMsUUFBUSxLQUFLO0VBQzNCLE9BQU87Q0FDUixVQUFVO0VBQ1QsWUFBWSxRQUFRLE9BQU8sT0FBTyxLQUFLO0NBQ3hDO0FBQ0Q7QUFDQSxTQUFTLFdBQVcsT0FBTyxRQUFRLFNBQVM7Q0FDM0MsSUFBSSxPQUFPLE9BQU9ELGNBQVk7Q0FDOUIsTUFBTSxTQUFTO0NBQ2YsTUFBTSxRQUFRLEtBQUs7Q0FDbkIsSUFBSSxPQUFPLE9BQU9ILFdBQVM7RUFDMUIsTUFBTSxhQUFhLE9BQU87RUFDMUIsTUFBTSxVQUFVO0VBQ2hCLE1BQU0sWUFBWSxLQUFLLElBQUk7RUFDM0IsTUFBTSxVQUFVO0NBQ2pCLE9BQU8sTUFBTSxVQUFVO0FBQ3hCO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUSxPQUFPLFNBQVM7Q0FDakQsTUFBTSxVQUFVLE9BQU8sT0FBTyxJQUFJLE1BQU0sRUFBRTtDQUMxQyxJQUFJLFlBQVksV0FBVyxPQUFPLFdBQVcsTUFBTSxjQUFjLFVBQVUsT0FBTyxNQUFNLE1BQU0sVUFBVSxZQUFZLE1BQU0sT0FBTyxHQUFHO0NBQ3BJLE1BQU0sU0FBUztFQUNkLEdBQUc7RUFDSCxXQUFXLEtBQUs7RUFDaEIsU0FBUyxDQUFDO0NBQ1g7Q0FDQSxJQUFJLE9BQU8sU0FBUyxPQUFPLFFBQVEsRUFBRTtDQUNyQyxPQUFPLE9BQU8sSUFBSSxNQUFNLElBQUksTUFBTTtDQUNsQyxJQUFJLFNBQVMsY0FBYyxRQUFRLE9BQU87QUFDM0M7QUFDQSxTQUFTLGtCQUFrQixPQUFPLFNBQVM7Q0FDMUMsSUFBSSxRQUFRLE9BQU9DLFdBQVMsUUFBUSxPQUFPQyxhQUFXLE9BQU87RUFDNUQsR0FBRztFQUNILFFBQVEsUUFBUSxPQUFPRCxVQUFRLFVBQVU7RUFDekMsT0FBTyxRQUFRO0VBQ2YsU0FBUyxLQUFLO0NBQ2Y7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTVSxtQkFBaUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxnQkFBZ0IsU0FBUyxhQUFhO0NBQzNGLE1BQU0sUUFBUSxLQUFLLEVBQUUsQ0FBQztDQUN0QixNQUFNLFFBQVFOLFdBQVMsUUFBUSxLQUFLO0NBQ3BDLE1BQU0sVUFBVSxDQUFDLENBQUMsUUFBUTtDQUMxQixNQUFNLG9CQUFvQixPQUFPLE9BQU8sSUFBSSxNQUFNLEVBQUU7Q0FDcEQsSUFBSTtDQUNKLElBQUksU0FBUztDQUNiLElBQUk7Q0FDSixJQUFJO0VBQ0gsSUFBSSxNQUFNLFdBQVcsV0FBVztHQUMvQixhQUFhLE1BQU0sUUFBUTtHQUMzQixJQUFJLE9BQU8sZUFBZSxZQUFZLGFBQWEsV0FBV0ssbUJBQWlCLFFBQVEsTUFBTSxPQUFPLE9BQU8sUUFBUSxJQUFJLGdCQUFnQixPQUFPLENBQUM7R0FDL0ksSUFBSSxRQUFRLEVBQUUsQ0FBQyxPQUFPLFNBQVMsZ0JBQWdCO0VBQ2hEO0VBQ0EsSUFBSSxDQUFDLGVBQWU7R0FDbkIsSUFBSSxNQUFNLFdBQVcsV0FBVyxTQUFTO1FBQ3BDO0lBQ0osTUFBTSxXQUFXLFdBQVcsTUFBTSxVQUFVLE1BQU0sUUFBUSxvQkFBb0IsT0FBTyxRQUFRLDJCQUEyQixNQUFNLE1BQU0sUUFBUSxhQUFhLE9BQU8sUUFBUSxvQkFBb0I7SUFDNUwsU0FBUyxDQUFDLEVBQUUsTUFBTSxXQUFXLGNBQWMsZUFBZSxLQUFLLEtBQUssS0FBSyxJQUFJLElBQUksTUFBTSxhQUFhLGFBQWEsUUFBUSxNQUFNLE1BQU0sVUFBVSxXQUFXLFFBQVEsRUFBRSxDQUFDLE1BQU0sY0FBYyxVQUFVLFlBQVksTUFBTSxXQUFXLFVBQVUsT0FBTyxNQUFNLEVBQUU7R0FDMVA7RUFDRDtDQUNELFNBQVMsT0FBTztFQUNmLE1BQU0sVUFBVTtFQUNoQixjQUFjLFFBQVEsS0FBSztFQUMzQixnQkFBZ0IsbUJBQW1CLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTztDQUN2RTtDQUNBLE1BQU0sY0FBYyxNQUFNLFFBQVE7Q0FDbEMsTUFBTSxhQUFhLE9BQU8sZ0JBQWdCO0NBQzFDLE1BQU0sU0FBUyxhQUFhLGNBQWMsYUFBYTtDQUN2RCxNQUFNLGNBQWMsQ0FBQyxXQUFXLE1BQU0sUUFBUSxZQUFZO0NBQzFELElBQUksUUFBUSxlQUFlLGVBQWUsQ0FBMkMsT0FBTyxNQUFNLEtBQU0sT0FBTyxVQUFVLElBQUksTUFBTSxFQUFFLElBQUksS0FBSztDQUM5SSxJQUFJLFVBQVUsTUFBTSxXQUFXLGVBQWUsUUFBUSxLQUFLO01BQ3RELElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxXQUFXLGVBQWUsS0FBSyxHQUFHLFNBQVM7TUFDcEUsSUFBSSxDQUFDLFFBQVEsUUFBUSxLQUFLO0NBQy9CLE1BQU0sYUFBYSxDQUFDLEVBQUUsZUFBZSxVQUFVLE1BQU0sV0FBVyxhQUFhLENBQUMsV0FBVyxDQUFDLFFBQVEsUUFBUSxhQUFhLEtBQUssSUFBSSxZQUFZLG9CQUFvQixPQUFPLFFBQVEsNEJBQTRCO0NBQzNNLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sV0FBVyxVQUFVLENBQUMsZUFBZSxNQUFNLFdBQVcsYUFBYSxDQUFDLENBQUM7Q0FDM0UsTUFBTSxVQUFVLFNBQVMsY0FBYyxRQUFRLEtBQUssS0FBSztDQUN6RCxNQUFNLGNBQWMsTUFBTSxVQUFVLE1BQU0sVUFBVSxPQUFPLFVBQVUsS0FBSztDQUMxRSxJQUFJLFVBQVUsQ0FBQyxhQUFhO0VBQzNCLE1BQU0sVUFBVTtFQUNoQixNQUFNLFlBQVksS0FBSyxJQUFJO0NBQzVCO0NBQ0EsSUFBSSxPQUFPLE1BQU0sRUFBRTtDQUNuQixJQUFJLFVBQVU7RUFDYixNQUFNLGlCQUFpQixNQUFNO0VBQzdCLE1BQU0sVUFBVTtFQUNoQixtQkFBbUIsUUFBUSxPQUFPLGNBQWMsQ0FBQyxFQUFFLE1BQU07RUFDekQsSUFBSSxTQUFTLGFBQWEsTUFBTSxTQUFTO0VBQ3pDLFVBQVU7Q0FDWDtDQUNBLElBQUksQ0FBQyxRQUFRLE1BQU0sYUFBYTtDQUNoQyxNQUFNLFVBQVUsQ0FBQyxpQkFBaUIsV0FBVyxhQUFhLFFBQVEsTUFBTSxPQUFPLE9BQU8sUUFBUSxnQkFBZ0IsT0FBTyxDQUFDLENBQUMsTUFBTSxXQUFXO0VBQ3ZJLFdBQVcsT0FBTyxRQUFRLE9BQU87RUFDakMsSUFBSSxPQUFPLE9BQU9WLFdBQVM7R0FDMUIsSUFBSSxlQUFlLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxTQUFTLGlCQUFpQixRQUFRLE9BQU8saUJBQWlCO0dBQ2hHLElBQUksU0FBUyxhQUFhLE1BQU0sU0FBUztFQUMxQztFQUNBLE9BQU87Q0FDUixDQUFDLElBQUksUUFBUSxRQUFRLGlCQUFpQixDQUFDQSxXQUFTLE1BQU0sVUFBVSxDQUFDO0NBQ2pFLE1BQU0sZ0JBQWdCLFlBQVk7RUFDakMsSUFBSTtHQUNILE1BQU0sUUFBUSxlQUFlLE9BQU8sS0FBSyxHQUFHLFdBQVc7R0FDdkQsSUFBSSxPQUFPLE1BQU1JLFVBQVEsT0FBTyxRQUFRLEVBQUUsQ0FBQyxNQUFNO0VBQ2xELFNBQVMsT0FBTztHQUNmLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxNQUFNLFdBQVcsbUJBQW1CLGtCQUFrQixVQUFVLFVBQVUsV0FBVyxXQUFXLFVBQVUsV0FBVyxjQUFjLFVBQVUsVUFBVSxHQUFHLE9BQU8sQ0FBQyxPQUFPLG1CQUFtQixRQUFRLE1BQU0sT0FBTyxPQUFPLE9BQU8sQ0FBQztFQUM5TztFQUNBLE1BQU0sU0FBUyxNQUFNO0VBQ3JCLElBQUksWUFBWSxPQUFPLE9BQU9KLGFBQVcsTUFBTSxXQUFXLGFBQWEsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLFNBQVM7R0FDbEcsTUFBTSxTQUFTO0dBQ2YsVUFBVTtFQUNYO0NBQ0QsRUFBQSxDQUFHO0NBQ0gsTUFBTSxLQUFLO0VBQ1Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELElBQUksQ0FBQyxZQUFZLE9BQU8sUUFBUSxNQUFNLFdBQVcsa0JBQWtCLE9BQU8sTUFBTSxDQUFDO0NBQ2pGLE1BQU0sWUFBWTtFQUNqQixHQUFHO0VBQ0gsUUFBUTtFQUNSLFNBQVM7RUFDVCxTQUFTO0NBQ1Y7Q0FDQSxNQUFNLFVBQVU7Q0FDaEIsTUFBTSxhQUFhO0NBQ25CLE1BQU0sb0JBQW9CLGFBQWEsUUFBUSxNQUFNLFdBQVcsT0FBTyxRQUFRLGdCQUFnQixPQUFPLENBQUMsQ0FBQyxNQUFNLFdBQVc7RUFDeEgsTUFBTSxhQUFhO0VBQ25CLFdBQVcsV0FBVyxRQUFRLEtBQUs7RUFDbkMsT0FBTztDQUNSLENBQUM7Q0FDRCxDQUFDLEtBQUssT0FBTyxDQUFDLEVBQUEsQ0FBRyxLQUFLO0VBQ3JCO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELE9BQU8sa0JBQWtCLE1BQU0sV0FBVyxrQkFBa0IsV0FBVyxNQUFNLENBQUM7QUFDL0U7QUFDQSxlQUFlWSxzQkFBb0IsUUFBUSxTQUFTLFNBQVMsUUFBUSxXQUFXLEdBQUc7Q0FDbEYsTUFBTSxRQUFRLFVBQVUsRUFBRSxDQUFDO0NBQzNCLElBQUksUUFBUSxPQUFPLFVBQVUsUUFBUSxXQUFXLFVBQVUsTUFBTSxZQUFZLE1BQU0sT0FBTyxJQUFJLFVBQVUsTUFBTSxRQUFRLFNBQVM7Q0FDOUgsSUFBSSxRQUFRLEdBQUcsUUFBUTtDQUN2QixLQUFLLElBQUksSUFBSSxPQUFPLEtBQUssR0FBRyxLQUFLO0VBQ2hDLE1BQU0sUUFBUVAsV0FBUyxRQUFRLFFBQVEsRUFBRTtFQUN6QyxJQUFJO0dBQ0gsTUFBTSxVQUFVLGVBQWUsT0FBTyxLQUFLO0dBQzNDLElBQUksU0FBUyxNQUFNRCxVQUFRLFNBQVMsTUFBTTtFQUMzQyxTQUFTLE9BQU87R0FDZixJQUFJLFVBQVUsVUFBVSxPQUFPLFNBQVMsTUFBTTtFQUMvQztFQUNBLElBQUksTUFBTSxRQUFRLG1CQUFtQixPQUFPO0NBQzdDO0NBQ0EsT0FBTyxPQUFPLFVBQVUsUUFBUTtBQUNqQztBQUNBLFNBQVMsa0JBQWtCLFFBQVEsTUFBTTtDQUN4QyxJQUFJLEtBQUssSUFBSTtFQUNaLHVCQUF1QixRQUFRLEtBQUssRUFBRSxDQUFDLEtBQUssU0FBUyxLQUFLLEVBQUUsQ0FBQztFQUM3RCxLQUFLLEtBQUssS0FBSztDQUNoQjtBQUNEO0FBQ0EsZUFBZSxZQUFZLE9BQU8sZUFBZSxlQUFlLE1BQU07Q0FDckUsSUFBSTtDQUNKLElBQUk7RUFDSCxNQUFNLFFBQVEsSUFBSSxNQUFNLEtBQUssU0FBUyxLQUFLLEVBQUUsQ0FBQyxLQUFLLE9BQU8sWUFBWTtHQUNyRSxNQUFNLFlBQVksS0FBSztHQUN2QixJQUFJLFFBQVEsYUFBYSxNQUFNLE1BQU07R0FDckMsSUFBSSxRQUFRLE1BQU1ELGNBQVksTUFBTSxDQUFDLFdBQVcsT0FBTztHQUN2RCxJQUFJLENBQUMsaUJBQWlCLFFBQVEsT0FBT0gsV0FBUztJQUM3QyxnQkFBZ0IsQ0FBQyxXQUFXLE9BQU87SUFDbkMsTUFBTSxRQUFRLEtBQUssaUJBQWlCLENBQUMsRUFBQSxDQUFHLEtBQUssYUFBYTtLQUN6RCxJQUFJLFNBQVMsTUFBTSxXQUFXO0tBQzlCLE9BQU8sU0FBUyxFQUFFLENBQUMsTUFBTSxnQkFBZ0I7TUFDeEMsSUFBSSxZQUFZLE9BQU9HLGNBQVksTUFBTSxDQUFDLFNBQVMsSUFBSSxXQUFXO0tBQ25FLENBQUM7SUFDRixDQUFDLENBQUM7R0FDSDtFQUNELENBQUMsQ0FBQyxDQUFDO0NBQ0osU0FBUyxPQUFPO0VBQ2YsT0FBTztDQUNSO0NBQ0EsT0FBTyxpQkFBaUI7QUFDekI7QUFDQSxTQUFTSyxzQkFBb0IsUUFBUSxNQUFNLE9BQU8sU0FBUyxTQUFTLFFBQVE7Q0FDM0UsT0FBTyxRQUFRLE9BQU9MLGNBQVk7RUFDakMsTUFBTSxXQUFXLFFBQVE7RUFDekIsTUFBTSxrQkFBa0IsU0FBUztFQUNqQyxJQUFJO0dBQ0gsSUFBSSxnQkFBZ0IsUUFBUSxTQUFTLFFBQVEsSUFBSSxVQUFVLEdBQUc7SUFDN0QsT0FBTyxnQkFBZ0IsUUFBUTtJQUMvQixJQUFJLGdCQUFnQixnQkFBZ0IsT0FBTztHQUM1QztHQUNBLElBQUksZ0JBQWdCLGlCQUFpQixRQUFRLEtBQUssUUFBUSxNQUFNLElBQUksT0FBTztHQUMzRSxNQUFNLFdBQVcsT0FBTyxjQUFjO0lBQ3JDLEdBQUc7SUFDSCxlQUFlLEtBQUs7SUFDcEIsd0JBQXdCO0dBQ3pCLENBQUM7R0FDRCxNQUFNLGlCQUFpQixTQUFTLGtCQUFrQjtHQUNsRCxJQUFJLGVBQWUsVUFBVTtJQUM1QixNQUFNLFdBQVcsU0FBUyxNQUFNO0lBQ2hDLFNBQVMsVUFBVSxFQUFFLEdBQUcsZ0JBQWdCO0lBQ3hDLFNBQVMsUUFBUSxJQUFJLFlBQVksZUFBZSxVQUFVO0lBQzFELE9BQU8sZ0JBQWdCLFFBQVE7SUFDL0IsT0FBTyxRQUFRLEtBQUssQ0FBQ0EsY0FBWSxRQUFRLElBQUk7S0FDNUNBO0tBQ0E7S0FDQTtJQUNEO0dBQ0Q7R0FDQSxPQUFPO0lBQ05BO0lBQ0E7SUFDQTtHQUNEO0VBQ0QsU0FBUyxPQUFPO0dBQ2YsVUFBVSxTQUFTLENBQUNGLFNBQU8sS0FBSyxJQUFJTSxpQkFBZSxPQUFPLEtBQUs7R0FDL0QsU0FBUztFQUNWO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxlQUFlLFdBQVcsUUFBUSxNQUFNLE9BQU8sWUFBWSxZQUFZLFNBQVM7Q0FDL0UsTUFBTSxVQUFVLEtBQUs7Q0FDckIsSUFBSSxVQUFVLE1BQU07Q0FDcEIsSUFBSSx3QkFBd0I7Q0FDNUIsTUFBTSxrQkFBa0IsUUFBUSxXQUFXLFVBQVUsTUFBTSxTQUFTO0NBQ3BFLE1BQU0sY0FBYyxVQUFVLE1BQU0sRUFBRSxDQUFDLE9BQU9MLGNBQVlVLHNCQUFvQixRQUFRLFNBQVMsT0FBTyxXQUFXLE1BQU0sSUFBSSxNQUFNO0NBQ2pJLElBQUksZUFBZSxrQkFBa0IsSUFBSSxRQUFRLFNBQVM7Q0FDMUQsS0FBSyxVQUFVLEVBQUUsQ0FBQyxNQUFNLE1BQU1ULGNBQVksZUFBZTtNQUNwRCxJQUFJLFNBQVM7RUFDakIsZUFBZSxRQUFRLE9BQU8sTUFBTSxXQUFXLE9BQU87RUFDdEQsS0FBSyxNQUFNLFFBQVEsT0FBTztHQUN6QixJQUFJLEtBQUssTUFBTSxjQUFjO0dBQzdCLE1BQU0sVUFBVSxNQUFNLEtBQUs7R0FDM0IsSUFBSSxRQUFRLE9BQU9ILGFBQVcsUUFBUSxLQUFLRyxnQkFBYyxFQUFFLGdCQUFnQixRQUFRLEtBQUssTUFBTTtJQUM3RixVQUFVLENBQUMsS0FBSyxJQUFJLE9BQU87SUFDM0IsZUFBZSxRQUFRLEtBQUssTUFBTSxXQUFXLE9BQU87SUFDcEQ7R0FDRDtFQUNEO0NBQ0Q7Q0FDQSxLQUFLLE1BQU0sUUFBUSxPQUFPO0VBQ3pCLElBQUksS0FBSyxNQUFNLGNBQWM7RUFDN0IsTUFBTSxlQUFlLE1BQU0sS0FBSztFQUNoQyxJQUFJLENBQUMsY0FBYztFQUNuQixVQUFVO0VBQ1Y7Q0FDRDtDQUNBLEtBQUssVUFBVSxFQUFFLENBQUMsTUFBTSxNQUFNQSxjQUFZO0VBQ3pDLE1BQU0sVUFBVSxRQUFRO0VBQ3hCLElBQUksUUFBUSxPQUFPQSxnQkFBYyxRQUFRLEVBQUUsQ0FBQyxRQUFRLGtCQUFrQixRQUFRLElBQUk7R0FDakYsa0JBQWtCLFFBQVEsSUFBSTtHQUM5QixPQUFPO0VBQ1I7RUFDQSx3QkFBd0I7RUFDeEIsVUFBVSxDQUFDLEdBQUcsQ0FBQ0YseUJBQXVCLElBQUksTUFBTSxvQkFBb0IsQ0FBQyxDQUFDO0NBQ3ZFO0NBQ0EsTUFBTSxXQUFXLFVBQVUsUUFBUSxNQUFNLE1BQU0sV0FBVyxPQUFPLElBQUk7Q0FDckUsSUFBSSxZQUFZLEdBQUc7RUFDbEIsTUFBTSxVQUFVLFVBQVU7RUFDMUIsTUFBTSxPQUFPLFVBQVU7RUFDdkIsTUFBTSxRQUFRLFFBQVE7RUFDdEIsTUFBTSxRQUFRLFVBQVU7RUFDeEIsTUFBTSxnQkFBZ0I7R0FDckIsSUFBSSxTQUFTO0lBQ1osTUFBTSxZQUFZLEtBQUs7SUFDdkIsSUFBSSxTQUFTQSxTQUFPLE1BQU0sU0FBUztTQUM5QjtLQUNKLE1BQU0sVUFBVSxNQUFNO0tBQ3RCLElBQUksTUFBTSxZQUFZLE9BQU8sVUFBVSxJQUFJO01BQzFDLE1BQU0sU0FBUztNQUNmLE1BQU0sWUFBWTtLQUNuQixPQUFPLE1BQU0sU0FBUztJQUN2QjtJQUNBLE1BQU0sUUFBUTtJQUNkLE1BQU0sYUFBYTtHQUNwQjtFQUNEO0VBQ0EsUUFBUTtFQUNSLElBQUksQ0FBQyxTQUFTLFVBQVU7RUFDeEIsTUFBTSxRQUFRSSxXQUFTLFFBQVEsS0FBSztFQUNwQyxJQUFJO0dBQ0gsTUFBTUQsVUFBUSxVQUFVLFFBQVEsUUFBUSxDQUFDLENBQUMsV0FBVyxlQUFlLE9BQU8sU0FBU0gsVUFBUSxtQkFBbUIsbUJBQW1CLENBQUMsSUFBSSxRQUFRLElBQUksQ0FBQyxlQUFlLEtBQUssR0FBRyxlQUFlLE9BQU8sbUJBQW1CLENBQUMsQ0FBQyxHQUFHLFdBQVcsTUFBTTtFQUMzTyxTQUFTLE9BQU87R0FDZixJQUFJLFVBQVUsV0FBVyxVQUFVLFdBQVcsT0FBTyxTQUFTO0lBQzdELGtCQUFrQixRQUFRLElBQUk7SUFDOUIsT0FBTztHQUNSO0VBQ0Q7RUFDQSxJQUFJLENBQUMsU0FBUyxNQUFNLFNBQVM7T0FDeEIsSUFBSSx1QkFBdUI7R0FDL0IsV0FBVyxNQUFNO0dBQ2pCLE1BQU0sUUFBUSxJQUFJO0lBQ2pCLEdBQUcsTUFBTSxLQUFLLFNBQVMsS0FBSyxFQUFFO0lBQzlCLEdBQUcsTUFBTSxLQUFLLFNBQVMsS0FBSyxFQUFFO0lBQzlCLElBQUksS0FBSyxNQUFNLENBQUMsRUFBQSxDQUFHLEtBQUssU0FBUyxLQUFLLEVBQUU7R0FDekMsQ0FBQztHQUNELGtCQUFrQixRQUFRLElBQUk7R0FDOUIsdUJBQXVCLFFBQVEsT0FBTztHQUN0QyxRQUFRO0VBQ1Q7Q0FDRDtDQUNBLE9BQU87QUFDUjtBQUNBLGVBQWVZLGNBQVksUUFBUSxNQUFNLFFBQVEsUUFBUSxHQUFHLE1BQU0sS0FBSyxFQUFFLENBQUMsUUFBUTtDQUNqRixNQUFNLFVBQVUsS0FBSztDQUNyQixLQUFLLElBQUksUUFBUSxPQUFPLFFBQVEsS0FBSyxTQUFTO0VBQzdDLE1BQU0sUUFBUSxRQUFRO0VBQ3RCLE1BQU0sZUFBZVIsV0FBUyxRQUFRLEtBQUssQ0FBQyxDQUFDO0VBQzdDLElBQUksYUFBYSxRQUFRLGFBQWEsU0FBUyxJQUFJO0dBQ2xELE1BQU0sVUFBVTtJQUNmLEtBQUssT0FBTyxRQUFRO0lBQ3BCO0lBQ0E7SUFDQSxRQUFRLE1BQU07SUFDZCxZQUFZLE1BQU07R0FDbkI7R0FDQSxNQUFNLENBQUMsTUFBTSxXQUFXLE1BQU1ELFVBQVEsUUFBUSxJQUFJLENBQUMsYUFBYSxPQUFPLE9BQU8sR0FBRyxhQUFhLFVBQVUsT0FBTyxDQUFDLENBQUMsR0FBRyxNQUFNO0dBQzFILE1BQU0sT0FBTyxNQUFNO0dBQ25CLE1BQU0sUUFBUSxNQUFNO0dBQ3BCLE1BQU0sY0FBYyxNQUFNO0dBQzFCLE1BQU0sU0FBUyxNQUFNO0dBQ3JCLE1BQU0sVUFBVTtFQUNqQixTQUFTLE9BQU87R0FDZixJQUFJLFVBQVUsVUFBVSxPQUFPLFNBQVM7R0FDeEMsUUFBUSxNQUFNLEtBQUs7RUFDcEI7RUFDQSxJQUFJLE1BQU0sV0FBVyxhQUFhLE1BQU0sV0FBVztDQUNwRDtDQUNBLE9BQU87QUFDUjtBQUNBLGVBQWUsa0JBQWtCLFFBQVEsVUFBVSxTQUFTLFNBQVM7Q0FDcEUsTUFBTSxVQUFVLENBQUMsVUFBVSxPQUFPO0NBQ2xDLE1BQU0sU0FBUyxRQUFRLEVBQUUsQ0FBQztDQUMxQixJQUFJO0NBQ0osSUFBSTtFQUNILE1BQU0sWUFBWSxPQUFPLE9BQU8sUUFBUSxJQUFJO0VBQzVDLElBQUksa0JBQWtCLFFBQVEsV0FBVyxVQUFVLE1BQU0sU0FBUztFQUNsRSxJQUFJLE9BQU8sUUFBUSxpQkFBaUIsVUFBVSxtQkFBbUIsR0FBRztHQUNuRSxNQUFNLFdBQVcsTUFBTVEsc0JBQW9CLFFBQVEsU0FBUyxLQUFLLEdBQUcsUUFBUSxlQUFlO0dBQzNGLFFBQVEsZ0JBQWdCLENBQUMsWUFBWSxLQUFLO0dBQzFDLFFBQVEsU0FBUyxDQUFDLFlBQVk7R0FDOUIsa0JBQWtCO0VBQ25CO0VBQ0EsSUFBSSxNQUFNLGtCQUFrQixJQUFJLFFBQVEsU0FBUyxrQkFBa0I7RUFDbkUsSUFBSSxjQUFjO0VBQ2xCLE9BQU8sY0FBYyxPQUFPLGdCQUFnQixpQkFBaUI7R0FDNUQsTUFBTSxRQUFRLFFBQVE7R0FDdEIsTUFBTSxZQUFZLFFBQVEsRUFBRSxDQUFDO0dBQzdCLE1BQU0sVUFBVSxVQUFVO0dBQzFCLElBQUksV0FBVyxPQUFPLE1BQU0sTUFBTSxVQUFVLFdBQVcsYUFBYSxNQUFNLFdBQVcsU0FBUyxPQUFPLE1BQU0sTUFBTSxRQUFRLFdBQVcsV0FBVztHQUMvSTtHQUNBLElBQUksVUFBVSxhQUFhLFFBQVEsV0FBVztFQUMvQztFQUNBLE1BQU0sUUFBUSxDQUFDO0VBQ2YsTUFBTSxRQUFRLFFBQVEsTUFBTTtFQUM1QixJQUFJLGlCQUFpQixRQUFRLFFBQVEsUUFBUSxRQUFRLFFBQVEsRUFBRSxJQUFJLEtBQUs7RUFDeEUsTUFBTSwyQkFBMkI7R0FDaEMsS0FBSyxJQUFJLFFBQVEsT0FBTyxRQUFRLEtBQUssU0FBUztJQUM3QyxJQUFJLE9BQU8sU0FBUztJQUNwQixpQkFBaUJELG1CQUFpQixRQUFRLFNBQVMsT0FBTyxPQUFPLGdCQUFnQixTQUFTLFdBQVc7R0FDdEc7RUFDRDtFQUNBLE1BQU0sVUFBVSxNQUFNRixnQkFBYyxRQUFRLFNBQVMsU0FBUyxLQUFLLG9CQUFvQixXQUFXO0VBQ2xHLElBQUksU0FBUztHQUNaLFFBQVEsS0FBSztHQUNiLE1BQU0sUUFBUTtHQUNkLElBQUksUUFBUSxFQUFFLENBQUMsT0FBT1AsYUFBVztJQUNoQyxNQUFNLFdBQVcsTUFBTVUsc0JBQW9CLFFBQVEsU0FBUyxTQUFTLE1BQU07SUFDM0UsUUFBUSxLQUFLO0lBQ2IsTUFBTSxLQUFLLElBQUksS0FBSyxXQUFXLENBQUM7R0FDakMsT0FBTyxJQUFJLFFBQVEsRUFBRSxDQUFDLE1BQU1ULGNBQVksTUFBTTtHQUM5QyxtQkFBbUI7RUFDcEI7RUFDQSxJQUFJLENBQUMsT0FBTyxXQUFXLENBQUMsUUFBUSxJQUFJO0dBQ25DLE1BQU0sUUFBUSxDQUFDO0dBQ2YsS0FBSyxNQUFNLENBQUMsSUFBSSxXQUFXLE9BQU8sWUFBWSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sSUFBSTtJQUNqRSxPQUFPLFNBQVMsT0FBTyxFQUFFO0lBQ3pCLE1BQU0sS0FBSyxPQUFPLEVBQUU7R0FDckI7R0FDQSxLQUFLLE1BQU0sY0FBYyxPQUFPLFdBQVcsTUFBTTtFQUNsRDtFQUNBLE1BQU0sWUFBWSxXQUFXLFFBQVEsU0FBUyxPQUFPLFFBQVEsSUFBSSxZQUFZLE9BQU8sU0FBUyxRQUFRLEVBQUUsR0FBRyxRQUFRLEVBQUU7RUFDcEgsSUFBSSxRQUFRLEVBQUUsRUFBRSxRQUFRLFFBQVEsS0FBSyxZQUFZLFFBQVEsSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLFVBQVUsTUFBTSxlQUFlLFVBQVUsVUFBVSxJQUFJLElBQUksb0JBQW9CLE9BQU8sQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0VBQ3JMLFVBQVUsTUFBTTtDQUNqQixTQUFTLE9BQU87RUFDZixrQkFBa0IsUUFBUSxPQUFPO0VBQ2pDLElBQUksVUFBVSxVQUFVLE9BQU8sU0FBUyxPQUFPO0VBQy9DLE1BQU07Q0FDUDtDQUNBLElBQUksVUFBVSxPQUFPLEdBQUcsT0FBTztDQUMvQixPQUFPVSxjQUFZLFFBQVEsU0FBUyxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVMsUUFBUSxLQUFLLENBQUM7QUFDM0Y7Ozs7Ozs7QUFPQSxTQUFTLGFBQWEsUUFBUSxJQUFJO0NBQ2pDLElBQUksT0FBTyxRQUFRLElBQUk7Q0FDdkIsTUFBTSxVQUFVLEdBQUc7Q0FDbkIsTUFBTSxZQUFZLE9BQU8sT0FBTyxRQUFRLElBQUk7Q0FDNUMsSUFBSSxVQUFVLE9BQU87Q0FDckIsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLFFBQVEsUUFBUSxTQUFTO0VBQ3BELE1BQU0sUUFBUSxRQUFRO0VBQ3RCLE1BQU0sVUFBVSxNQUFNLFdBQVcsYUFBYSxDQUFDLE1BQU07RUFDckQsTUFBTSxtQkFBbUIsVUFBVSxNQUFNLEVBQUUsT0FBTyxNQUFNLE1BQU0sVUFBVSxNQUFNLEVBQUUsV0FBVztFQUMzRixJQUFJLFdBQVcsQ0FBQyxrQkFBa0I7RUFDbEMsTUFBTSxRQUFRUixXQUFTLFFBQVEsS0FBSztFQUNwQyxNQUFNLFFBQVEsV0FBVyxNQUFNLFVBQVUsSUFBSSxNQUFNLFFBQVEsYUFBYSxPQUFPLFFBQVE7RUFDdkYsTUFBTSxZQUFZLE1BQU0sUUFBUSxvQkFBb0IsT0FBTyxRQUFRO0VBQ25FLElBQUksQ0FBQyxhQUFhLE9BQU8sVUFBVSxZQUFZLFVBQVUsVUFBVTtHQUNsRSxJQUFJLFNBQVM7SUFDWixRQUFRLEtBQUs7SUFDYixRQUFRLEtBQUs7SUFDYixRQUFRLEtBQUs7R0FDZDtHQUNBO0VBQ0Q7RUFDQSxNQUFNLE1BQU0sTUFBTSxRQUFRLGdCQUFnQixPQUFPLFFBQVEsdUJBQXVCO0VBQ2hGLElBQUksV0FBVztFQUNmLElBQUksVUFBVSxPQUFPLE1BQU0sSUFBSTtHQUM5QixXQUFXLFFBQVEsT0FBTztHQUMxQixRQUFRLEtBQUs7RUFDZCxPQUFPO0dBQ04sYUFBYSxVQUFVLEVBQUU7R0FDekIsT0FBTyxXQUFXLFVBQVUsS0FBSztFQUNsQztFQUNBLElBQUksQ0FBQyxTQUFTLE9BQU8sV0FBVyxVQUFVO0dBQ3pDO0dBQ0EsTUFBTTtHQUNOLG1CQUFtQixLQUFLLElBQUksSUFBSSxNQUFNLEdBQUcsS0FBSztHQUM5QyxLQUFLO0dBQ0wsb0JBQW9CLEtBQUs7R0FDekI7RUFDRDtFQUNBLElBQUksUUFBUSxNQUFNLENBQUMsWUFBWSxRQUFRLE9BQU8sV0FBVztFQUN6RCxRQUFRLEtBQUs7RUFDYixJQUFJLENBQUMsUUFBUSxJQUFJO0dBQ2hCLGFBQWEsUUFBUSxFQUFFO0dBQ3ZCLE1BQU0sWUFBWSxRQUFRLEtBQUssS0FBSyxJQUFJO0dBQ3hDLElBQUksWUFBWSxHQUFHO0lBQ2xCLFFBQVEsS0FBSyxpQkFBaUIsYUFBYSxRQUFRLEVBQUUsR0FBRyxTQUFTO0lBQ2pFO0dBQ0Q7R0FDQSxRQUFRLEtBQUs7RUFDZDtFQUNBLE1BQU0sVUFBVSxRQUFRLEtBQUssV0FBVztHQUN2QyxHQUFHO0dBQ0gsU0FBUyxLQUFLO0VBQ2YsRUFBRTtFQUNGLFFBQVEsTUFBTSxDQUFDLFNBQVM7RUFDeEIsTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLHNCQUFzQixPQUFPLE9BQU8sV0FBVyxPQUFPLEdBQUcsT0FBTyxDQUFDLENBQUMsTUFBTSxhQUFhO0dBQ3BILElBQUksWUFBWSxPQUFPLGFBQWEsV0FBVyxRQUFRLE9BQU8sT0FBTyxDQUFDLFFBQVEsSUFBSSxRQUFRLEtBQUssS0FBSyxJQUFJLElBQUk7R0FDNUcsT0FBTztFQUNSLENBQUM7RUFDRDtDQUNEO0FBQ0Q7Ozs7O0FBS0EsU0FBUyxjQUFjLFFBQVEsSUFBSTtDQUNsQyxNQUFNLFVBQVUsT0FBTztDQUN2QixJQUFJLE9BQU8sUUFBUSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxNQUFNLFVBQVUsTUFBTSxPQUFPLFVBQVUsRUFBRSxHQUFHO0VBQ3JGLGFBQWEsVUFBVSxFQUFFO0VBQ3pCLE9BQU8sV0FBVyxLQUFLO0NBQ3hCO0FBQ0Q7QUFDQSxlQUFlLG9CQUFvQixRQUFRLElBQUk7Q0FDOUMsTUFBTSxVQUFVLE9BQU87Q0FDdkIsSUFBSSxDQUFDLFNBQVM7Q0FDZCxhQUFhLFFBQVEsRUFBRTtDQUN2QixNQUFNLFlBQVksUUFBUSxLQUFLLEtBQUssSUFBSTtDQUN4QyxJQUFJLENBQUMsUUFBUSxNQUFNLGFBQWEsS0FBSyxDQUFDLG9CQUFvQixHQUFHLEVBQUUsQ0FBQyxDQUFDLE1BQU0sVUFBVSxNQUFNLE9BQU8sUUFBUSxFQUFFLEdBQUc7Q0FDM0csSUFBSTtDQUNKLElBQUk7RUFDSCxNQUFNRCxVQUFRLElBQUksU0FBUyxZQUFZO0dBQ3RDLFFBQVEsV0FBVyxTQUFTLFNBQVM7RUFDdEMsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLE1BQU07Q0FDakIsUUFBUSxDQUFDO0NBQ1QsYUFBYSxLQUFLO0FBQ25CO0FBQ0EsU0FBUyxlQUFlLFFBQVEsU0FBUztDQUN4QyxPQUFPLGFBQWE7Q0FDcEIsT0FBTyxPQUFPLFdBQVcsT0FBTztBQUNqQztBQUNBLFNBQVMsY0FBYyxRQUFRLElBQUksU0FBUyxnQkFBZ0I7Q0FDM0QsTUFBTSxXQUFXLE9BQU87Q0FDeEIsTUFBTSxjQUFjLE9BQU87Q0FDM0IsTUFBTSxpQkFBaUIsT0FBTztDQUM5QixLQUFLLE1BQU0sU0FBUyxTQUFTO0VBQzVCLE1BQU0sVUFBVTtFQUNoQixJQUFJLGdCQUFnQixNQUFNLFlBQVksS0FBSztDQUM1QztDQUNBLE1BQU0sTUFBTSxvQkFBb0IsT0FBTyxDQUFDLENBQUM7Q0FDekMsTUFBTSx5QkFBeUIsSUFBSSxJQUFJO0NBQ3ZDLElBQTZDLENBQUMsR0FBRyxJQUFJO0VBQ3BELE1BQU0sTUFBTSxLQUFLLElBQUk7RUFDckIsTUFBTSw2QkFBNkIsSUFBSSxJQUFJO0VBQzNDLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxRQUFRLFFBQVEsU0FBUztHQUNwRCxNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLFFBQVEsT0FBTyxNQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksTUFBTSxFQUFFO0VBQ3ZFO0VBQ0EsS0FBSyxNQUFNLFNBQVMsQ0FBQyxHQUFHLFVBQVUsR0FBRyxlQUFlLE9BQU8sQ0FBQyxHQUFHO0dBQzlELElBQUksTUFBTSxXQUFXLGFBQWEsV0FBVyxJQUFJLE1BQU0sRUFBRSxHQUFHO0dBQzVELE1BQU0sUUFBUUMsV0FBUyxRQUFRLEtBQUs7R0FDcEMsSUFBSSxDQUFDLE1BQU0sUUFBUSxVQUFVLE1BQU0sTUFBTSxjQUFjLE1BQU0sVUFBVSxNQUFNLFFBQVEsaUJBQWlCLE9BQU8sUUFBUSx3QkFBd0IsTUFBTSxNQUFNLFFBQVEsVUFBVSxPQUFPLFFBQVEsaUJBQWlCLE1BQU07R0FDak4sT0FBTyxJQUFJLE1BQU0sSUFBSSxlQUFlLElBQUksTUFBTSxFQUFFLE1BQU0sUUFBUSxRQUFRO0lBQ3JFLEdBQUc7SUFDSCxTQUFTLEtBQUs7SUFDZCxZQUFZO0lBQ1osU0FBUyxDQUFDO0dBQ1gsQ0FBQztFQUNGO0NBQ0Q7Q0FDQSxHQUFHLEtBQUssQ0FBQztDQUNULE9BQU8sU0FBUztDQUNoQixNQUFNLFVBQVUsT0FBTyxnQkFBZ0IsYUFBYSxPQUFPO0NBQzNELGVBQWUsUUFBUSxPQUFPO0NBQzlCLHVCQUF1QixRQUFRLENBQUMsR0FBRyxlQUFlLE9BQU8sR0FBRyxHQUFHLFFBQVEsQ0FBQyxDQUFDLFFBQVEsVUFBVSxNQUFNLFdBQVcsT0FBTyxJQUFJLE1BQU0sRUFBRSxNQUFNLEtBQUssR0FBRyxPQUFPO0NBQ3pHO0VBQzFDLE1BQU0sVUFBVSxHQUFHLEVBQUUsR0FBRztFQUN4QixJQUFJLFdBQVcsT0FBTyxhQUFhLFNBQVMsUUFBUSxFQUFFLENBQUM7Q0FDeEQ7Q0FDQSxrQkFBa0IsUUFBUSxVQUFVLFNBQVMsYUFBYSxTQUFTLEVBQUU7QUFDdEU7Ozs7OztBQU1BLGVBQWUsYUFBYSxRQUFRLE9BQU87Q0FDMUMsSUFBSSxVQUFVLE9BQU87Q0FDckIsT0FBTyxXQUFXLFlBQVksT0FBTztFQUNwQyxRQUFRO0VBQ1IsTUFBTSxRQUFRO0VBQ2QsVUFBVSxPQUFPO0NBQ2xCO0FBQ0Q7QUFDQSxTQUFTLGVBQWUsUUFBUSxJQUFJLFNBQVM7Q0FDNUMsTUFBTSxVQUFVLFFBQVEsRUFBRSxDQUFDO0NBQzNCLE1BQU0sV0FBVyxRQUFRO0NBQ3pCLElBQUksQ0FBQyxVQUFVLE9BQU8sT0FBTyxTQUFTO0VBQ3JDLEdBQUc7RUFDSCxTQUFTO0VBQ1QsZUFBZTtDQUNoQixDQUFDO0NBQ0QsSUFBSSxRQUFRLGdCQUFnQixPQUFPLE9BQU8sU0FBUztFQUNsRCxPQUFPLFNBQVMsa0JBQWtCLFNBQUEsQ0FBVTtFQUM1QyxnQkFBZ0I7RUFDaEIsU0FBUztFQUNULGVBQWU7Q0FDaEIsQ0FBQztDQUNELFNBQVMsYUFBYSxHQUFHLEtBQUs7Q0FDOUIsT0FBTyxtQkFBbUI7Q0FDMUIsTUFBTSxZQUFZLE9BQU8sZUFBZTtFQUN2QyxHQUFHO0VBQ0gsZ0JBQWdCLFFBQVE7RUFDeEIsU0FBUztFQUNULGFBQWEsUUFBUTtFQUNyQixvQkFBb0IsUUFBUTtFQUM1QixlQUFlO0NBQ2hCLENBQUM7Q0FDRCxxQkFBcUI7RUFDcEIsSUFBSSxPQUFPLHFCQUFxQixVQUFVLE9BQU8sbUJBQW1CLEtBQUs7Q0FDMUUsQ0FBQztDQUNELE9BQU87QUFDUjtBQUNBLGVBQWUsY0FBYyxRQUFRLElBQUksTUFBTSxPQUFPLFlBQVk7Q0FDakUsTUFBTSxPQUFPLEtBQUssS0FBSyxXQUFXLEVBQUUsR0FBRyxNQUFNLEVBQUU7Q0FDL0Msc0JBQXNCLElBQUk7Q0FDMUIsS0FBSyxNQUFNLFFBQVEsT0FBTztFQUN6QixjQUFjLFFBQVEsS0FBSyxLQUFLLEdBQUc7RUFDbkMsS0FBSyxLQUFLLE1BQU0sS0FBSztDQUN0QjtDQUNBLE1BQU0sT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJO0NBQ3pCLElBQUk7Q0FDSixJQUFJO0VBQ0gsVUFBVSxNQUFNLFdBQVcsUUFBUSxNQUFNLE9BQU8sR0FBRyxJQUFJLFVBQVU7Q0FDbEUsU0FBUyxPQUFPO0VBQ2YsdUJBQXVCLFFBQVEsSUFBSTtFQUNuQyxNQUFNO0NBQ1A7Q0FDQSxJQUFJLFVBQVUsT0FBTyxHQUFHO0VBQ3ZCLHVCQUF1QixRQUFRLElBQUk7RUFDbkMsSUFBSSxRQUFRLE9BQU9GLGdCQUFjLE9BQU8sUUFBUSxNQUFNLE9BQU8sZUFBZSxNQUFNLE1BQU0sZUFBZSxRQUFRLElBQUksT0FBTztFQUMxSDtDQUNEO0NBQ0EsTUFBTVUsY0FBWSxRQUFRLFNBQVMsR0FBRyxFQUFFLENBQUMsTUFBTTtDQUMvQyxJQUFJLE9BQU8sUUFBUSxNQUFNLE9BQU8sZUFBZSxNQUFNO0VBQ3BELHVCQUF1QixRQUFRLElBQUk7RUFDbkM7Q0FDRDtDQUNBLEtBQUssTUFBTSxTQUFTLE1BQU07RUFDekIsTUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJLE1BQU0sRUFBRTtFQUN6QyxJQUFJLFFBQVEsV0FBVyxPQUFPLFlBQVksTUFBTSxTQUFTO0dBQ3hELE9BQU8sT0FBTyxPQUFPLE1BQU0sRUFBRTtHQUM3QixjQUFjLFFBQVEsTUFBTTtFQUM3QjtDQUNEO0NBQ0EsZUFBZSxRQUFRLElBQUk7Q0FDM0IsdUJBQXVCLFFBQVEsTUFBTSxJQUFJO0FBQzFDO0FBQ0EsZUFBZSxxQkFBcUIsUUFBUSxJQUFJLGtCQUFrQixTQUFTLE1BQU0sZ0JBQWdCO0NBQ2hHLE1BQU0sU0FBUyxNQUFNLGtCQUFrQixRQUFRLEdBQUcsSUFBSSxHQUFHLElBQUk7RUFDNUQsR0FBRztFQUNILEdBQUc7RUFDSCxPQUFPO0VBQ1AsS0FBSztFQUNMO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELElBQUksVUFBVSxNQUFNLEdBQUc7RUFDdEIsTUFBTSxTQUFTLE9BQU8sT0FBT1YsZ0JBQWMsT0FBTyxRQUFRO0VBQzFELElBQUksQ0FBQyxVQUFVLE9BQU8sRUFBRSxDQUFDLFFBQVEsZ0JBQWdCLGNBQWMsUUFBUSxFQUFFO0VBQ3pFLHVCQUF1QixRQUFRLEdBQUcsRUFBRTtFQUNwQyxHQUFHLEtBQUssQ0FBQztFQUNULElBQUksQ0FBQyxRQUFRO0VBQ2IsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUN0QixjQUFjLFFBQVEsRUFBRTtHQUN4QjtFQUNEO0VBQ0EsSUFBNkMsR0FBRyxJQUFJLE9BQU8sbUJBQW1CO0VBQzlFLE1BQU0sZUFBZSxRQUFRLElBQUksTUFBTTtFQUN2QztDQUNEO0NBQ0EsTUFBTSxVQUFVLE9BQU87Q0FDdkIsSUFBSSxPQUFPLFFBQVEsSUFBSSxNQUFNLG9CQUFvQixRQUFRLEVBQUU7Q0FDM0QsSUFBSSxPQUFPLFFBQVEsSUFBSTtFQUN0QixjQUFjLFFBQVEsRUFBRTtFQUN4Qix1QkFBdUIsUUFBUSxPQUFPO0VBQ3RDLGtCQUFrQixRQUFRLE1BQU07RUFDaEM7Q0FDRDtDQUNBLE1BQU0sYUFBYSxHQUFHO0NBQ3RCLE1BQU0sYUFBYSxzQkFBc0IsWUFBWSxPQUFPLE9BQU8saUJBQWlCLElBQUksQ0FBQztDQUN6RixNQUFNLGFBQWEsT0FBTztDQUMxQixNQUFNLE9BQU8sb0JBQW9CLFlBQVk7RUFDNUMsSUFBSSxPQUFPLFFBQVEsSUFBSSxNQUFNLG9CQUFvQixRQUFRLEVBQUU7RUFDM0QsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUN0QixjQUFjLFFBQVEsRUFBRTtHQUN4Qix1QkFBdUIsUUFBUSxPQUFPO0dBQ3RDLGtCQUFrQixRQUFRLE1BQU07R0FDaEM7RUFDRDtFQUNBLE1BQU0sZUFBZTtHQUNwQixjQUFjLFFBQVEsRUFBRTtHQUN4QixjQUFjLFFBQVEsSUFBSSxTQUFTLGNBQWM7R0FDakQsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUN2QixPQUFPLEtBQUs7SUFDWCxNQUFNO0lBQ04sR0FBRztHQUNKLENBQUM7R0FDRCxJQUFJLE9BQU8sUUFBUSxJQUFJLE9BQU8sS0FBSztJQUNsQyxNQUFNO0lBQ04sR0FBRztHQUNKLENBQUM7RUFDRjtFQUNBLE1BQU0sV0FBVyxNQUFNLE9BQU8sZ0JBQWdCLFFBQVEsT0FBTztFQUM3RCxJQUE2QyxHQUFHLElBQUksR0FBRyxLQUFLLEtBQUs7RUFDakUsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUN0QixrQkFBa0IsUUFBUSxNQUFNO0dBQ2hDO0VBQ0Q7RUFDQSxJQUFJLFlBQVksUUFBUSxjQUFjLFFBQVEsSUFBSSxTQUFTLFlBQVksT0FBTyxFQUFFLENBQUMsQ0FBQyxNQUFNLFFBQVEsS0FBSztFQUNyRyxPQUFPLFlBQVk7R0FDbEIsT0FBTyxPQUFPLGlCQUFpQixJQUFJLFVBQVU7R0FDN0MsT0FBTyxPQUFPLE9BQU8sSUFBSSxNQUFNO0dBQy9CLElBQUksT0FBTyxRQUFRLElBQUksT0FBTyxLQUFLO0lBQ2xDLE1BQU07SUFDTixHQUFHO0dBQ0osQ0FBQztHQUNELElBQUksWUFBWSxPQUFPLFFBQVEsSUFBSSxPQUFPLEtBQUs7SUFDOUMsTUFBTTtJQUNOLEdBQUc7R0FDSixDQUFDO0VBQ0YsQ0FBQztFQUNELElBQUksT0FBTyxRQUFRLElBQUk7RUFDdkIsT0FBTyxnQkFBZ0IsUUFBUTtFQUMvQixPQUFPLGlCQUFpQixLQUFLO0NBQzlCLENBQUM7QUFDRjtBQUNBLGVBQWUsZ0JBQWdCLFFBQVEsTUFBTTtDQUM1QyxJQUFJLGdCQUFnQjtDQUN1QixnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLENBQUMsQ0FBQyxPQUFPLE1BQU07Q0FDdkcsTUFBTSxnQkFBZ0IsT0FBTztDQUM3QixNQUFNLG1CQUFtQixPQUFPLE9BQU8saUJBQWlCLElBQUk7Q0FDNUQsTUFBTSxtQkFBbUIsb0JBQW9CLE9BQU8sT0FBTyxTQUFTLElBQUk7Q0FDeEUsTUFBTSxXQUFXLE9BQU87Q0FDeEIsTUFBTSxrQkFBa0IsT0FBTztDQUMvQixNQUFNLFlBQVksaUJBQWlCLFNBQVMsU0FBUyxPQUFPLGdCQUFnQixjQUFjLElBQUk7Q0FDOUYsTUFBTSxVQUFVLE9BQU87Q0FDdkIsTUFBTSxzQkFBc0IsZ0JBQWdCLEtBQUssSUFBSSxVQUFVLEVBQUUsQ0FBQztDQUNsRSxNQUFNLFlBQVksSUFBSSxnQkFBZ0I7Q0FDdEMsTUFBTSxvQkFBb0IsT0FBTztDQUNqQyxPQUFPLGFBQWE7Q0FDcEIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixVQUFVLEVBQUUsQ0FBQztDQUN6RCxtQkFBbUIsTUFBTTtDQUN6QixJQUFJLENBQUMsVUFBVSxPQUFPLFNBQVM7RUFDOUIsTUFBTSxhQUFhLHNCQUFzQixVQUFVLGdCQUFnQjtFQUNuRSxPQUFPLEtBQUs7R0FDWCxNQUFNO0dBQ04sR0FBRztFQUNKLENBQUM7RUFDRCxJQUFJLENBQUMsVUFBVSxPQUFPLFNBQVMsT0FBTyxLQUFLO0dBQzFDLE1BQU07R0FDTixHQUFHO0VBQ0osQ0FBQztDQUNGO0NBQ0EsSUFBSSxVQUFVLE9BQU8sU0FBUztFQUM3QixNQUFNLGFBQWEsUUFBUSxhQUFhO0VBQ3hDO0NBQ0Q7Q0FDQSxNQUFNLFdBQVcsaUJBQWlCLFNBQVMsU0FBUztDQUNwRCxJQUFJLGFBQWE7Q0FDakIsTUFBTSxVQUFtRCxnQkFBZ0IsT0FBTyxZQUFZLFVBQVU7RUFDckcsYUFBYTtFQUNiLGdCQUFnQjtDQUNqQixDQUFDLElBQUksT0FBTyxZQUFZLFVBQVUsRUFBRSxhQUFhLFVBQVUsQ0FBQztDQUM1RCxzQkFBc0IsT0FBTztDQUM3QixNQUFNLGlCQUFpQixzQkFBc0IsUUFBUSxFQUFFLENBQUMsT0FBTyxJQUFJLEtBQUs7Q0FDeEUsSUFBSSxnQkFBZ0IsYUFBYTtNQUM1QixxQkFBcUIsTUFBTTtDQUNoQyxJQUFJLFVBQVUsT0FBTyxTQUFTO0VBQzdCLHVCQUF1QixRQUFRLE9BQU87RUFDdEMsTUFBTSxhQUFhLFFBQVEsYUFBYTtFQUN4QztDQUNEO0NBQ0EsT0FBTyxhQUFhLEtBQUs7Q0FDekIsSUFBSTtDQUNKLE1BQU0sWUFBWSxxQkFBcUIsUUFBUSxJQUFJLGdCQUFnQixhQUFhLFFBQVEsRUFBRSxHQUFHLE1BQU0sTUFBTSxjQUFjO0NBQ3ZILE1BQU0sT0FBTyxNQUFNLE9BQU8sSUFBSSxTQUFTLFlBQVksU0FBUyxPQUFPLElBQUksUUFBUSxRQUFRLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDakcsTUFBTSxLQUFLO0VBQ1Y7RUFDQTtFQUNBO0VBQ0E7RUFDQSxLQUFLLElBQUk7RUFDVCxLQUFLLFdBQVcsYUFBYSxRQUFRLEVBQUUsQ0FBQztDQUN6QztDQUNBLElBQTZDLGVBQWU7RUFDM0QsR0FBRyxLQUFLLENBQUMsT0FBTztFQUNoQixPQUFPLG1CQUFtQixLQUFLO0NBQ2hDO0NBQ0EsT0FBTyxNQUFNO0NBQ2IsSUFBSSxlQUFlO0VBQ2xCLEtBQUssTUFBTSxTQUFTLE9BQU8sT0FBTyxRQUFRLElBQUksR0FBRztHQUNoRCxJQUFJLE9BQU8sUUFBUSxJQUFJO0dBQ3ZCLElBQUksTUFBTSxZQUFZLFlBQVksUUFBUSxPQUFPLEtBQUs7RUFDdkQ7RUFDQSxjQUFjLEVBQUUsQ0FBQyxNQUFNO0VBQ3ZCLHVCQUF1QixRQUFRLGNBQWMsSUFBSSxHQUFHLElBQUksSUFBSTtDQUM3RDtDQUNBLElBQUksT0FBTyxRQUFRLElBQUk7RUFDdEIsdUJBQXVCLFFBQVEsR0FBRyxFQUFFO0VBQ3BDLEdBQUcsS0FBSyxDQUFDO0VBQ1QsU0FBUztFQUNULE1BQU0sYUFBYSxRQUFRLEVBQUU7RUFDN0I7Q0FDRDtDQUNBLE9BQU8sWUFBWTtFQUNsQixPQUFPLE9BQU8sT0FBTyxJQUFJLFNBQVM7RUFDbEMsT0FBTyxPQUFPLFNBQVMsSUFBSSxRQUFRO0NBQ3BDLENBQUM7Q0FDRCxJQUFJLGtCQUFrQixDQUFDLE9BQU8sV0FBVyxVQUFVLFFBQVEsRUFBRSxFQUFFLFdBQVcsYUFBYSxDQUFDLFFBQVEsTUFBTSxVQUFVLE1BQU0sU0FBUyxHQUFHLGFBQWEsUUFBUSxFQUFFO0NBQ3pKLFNBQVMsSUFBSSxDQUFDO0NBQ2QsTUFBTSxHQUFHO0FBQ1Y7QUFDQSxlQUFlLG1CQUFtQixRQUFRO0NBQ3pDLE1BQU0sVUFBVSxPQUFPO0NBQ3ZCLElBQUksV0FBVyxDQUFDLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTyxJQUFJLE1BQU0sV0FBVztFQUN2RSxNQUFNLFFBQVE7RUFDZCxJQUFJLE9BQU8sUUFBUSxTQUFTLE1BQU0sYUFBYSxRQUFRLE9BQU87Q0FDL0Q7Q0FDQSxPQUFPLFVBQVUsTUFBTTtDQUN2QixPQUFPLFdBQVc7Q0FDbEIsT0FBTyxtQkFBbUI7Q0FDMUIsTUFBTSxnQkFBZ0IsUUFBUSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzdDO0FBQ0EsZUFBZSxtQkFBbUIsUUFBUSxNQUFNO0NBQy9DLElBQThDLE9BQU8sb0JBQW9CLE9BQU8sTUFBTSxJQUFLO0NBQzNGLElBQUksV0FBVyxPQUFPLGNBQWMsSUFBSTtDQUN4QyxLQUFLLElBQUksWUFBWSxJQUFJLGFBQWE7RUFDckMsTUFBTSxPQUFPLE9BQU87RUFDcEIsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0VBQ3ZDLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7R0FDSCxJQUFJO0lBQ0gsVUFBVSxPQUFPLFlBQVksVUFBVSxFQUFFLGFBQWEsV0FBVyxDQUFDO0lBQ2xFLHNCQUFzQixPQUFPO0lBQzdCLFVBQVUsT0FBTyw4QkFBOEIsSUFBSSxJQUFJLEVBQUEsQ0FBRyxJQUFJLFlBQVksT0FBTztJQUNqRixTQUFTLE1BQU0sa0JBQWtCLFFBQVEsVUFBVSxTQUFTO0tBQzNEO0tBQ0E7S0FDQTtLQUNBO0lBQ0QsQ0FBQztHQUNGLFVBQVU7SUFDVCxJQUFJLFFBQVE7S0FDWCxTQUFTLE9BQU8sT0FBTyxVQUFVO0tBQ2pDLHVCQUF1QixRQUFRLE9BQU87SUFDdkM7SUFDQSxXQUFXLE1BQU07R0FDbEI7R0FDQSxJQUFJLENBQUMsVUFBVSxNQUFNLEdBQUcsT0FBTyxPQUFPO0dBQ3RDLElBQUksQ0FBQyxVQUFVLE9BQU8sU0FBUyxLQUErQyxPQUFPLG9CQUFvQixPQUFPLE1BQU0sSUFBSztHQUMzSCxXQUFXLE9BQU87RUFDbkIsU0FBUyxPQUFPO0dBQ2YsSUFBSSxDQUFDLFdBQVcsS0FBSyxHQUFHLFFBQVEsTUFBTSxLQUFLO0dBQzNDO0VBQ0Q7Q0FDRDtBQUNEOzs7QUNwbENBLFNBQVMsWUFBWSxVQUFVLE9BQU87Q0FDckMsSUFBSSxDQUFDLFVBQVU7Q0FDZixJQUFJO0VBQ0gsTUFBTSxTQUFTLFNBQVMsS0FBSztFQUM3QixJQUFJLFdBQVcsS0FBSyxHQUFHLFFBQVEsUUFBUSxNQUFNLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztDQUM5RCxRQUFRLENBQUM7QUFDVjs7Ozs7Ozs7QUFRQSxTQUFTLGNBQWMsT0FBTyxRQUFRLFFBQVEsYUFBYTtDQUMxRCxNQUFNLFVBQVUsUUFBUSxRQUFRLEtBQUs7Q0FDckMsSUFBSSxPQUFPLFNBQVM7RUFDbkIsUUFBUSxNQUFNLFdBQVcsWUFBWSxRQUFRLE1BQU0sSUFBSSxVQUFVLFlBQVksYUFBYSxLQUFLLENBQUM7RUFDaEcsT0FBTyxRQUFRLE9BQU8sT0FBTyxNQUFNO0NBQ3BDO0NBQ0EsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ3ZDLE1BQU0sY0FBYyxPQUFPLE9BQU8sTUFBTTtFQUN4QyxPQUFPLGlCQUFpQixTQUFTLE9BQU8sRUFBRSxNQUFNLEtBQUssQ0FBQztFQUN0RCxRQUFRLE1BQU0sV0FBVztHQUN4QixPQUFPLG9CQUFvQixTQUFTLEtBQUs7R0FDekMsSUFBSSxPQUFPLFNBQVMsWUFBWSxRQUFRLE1BQU07UUFDekMsUUFBUSxNQUFNO0VBQ3BCLElBQUksVUFBVTtHQUNiLE9BQU8sb0JBQW9CLFNBQVMsS0FBSztHQUN6QyxJQUFJLE9BQU8sU0FBUyxZQUFZLGFBQWEsS0FBSztRQUM3QyxPQUFPLEtBQUs7RUFDbEIsQ0FBQztDQUNGLENBQUM7QUFDRjs7O0FDM0JBLElBQU0sVUFBVTtBQUNoQixJQUFNLFFBQVE7QUFDZCxJQUFNLFlBQVk7QUFDbEIsSUFBTSxhQUFhO0FBQ25CLElBQU0sVUFBVTtBQUNoQixJQUFNLDZCQUE2QixPQUFPLE9BQU87Q0FDaEQsTUFBTTtDQUNOLFNBQVM7QUFDVixDQUFDO0FBQ0QsSUFBTSx3QkFBd0IsT0FBTyxPQUFPO0NBQzNDLE1BQU07Q0FDTixTQUFTO0FBQ1YsQ0FBQztBQUNELFNBQVMsU0FBUyxRQUFRLE9BQU87Q0FDaEMsT0FBTyxPQUFPLFdBQVcsTUFBTTtBQUNoQztBQUNBLFNBQVMsVUFBVSxPQUFPLFVBQVU7Q0FDbkMsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPLENBQUMsWUFBWSxLQUFLO0NBQ2hELElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTyxDQUFDLFdBQVcsS0FBSztDQUMvQyxJQUFJLFlBQVksT0FBTyxPQUFPLFNBQVMsWUFBWSxRQUFRLElBQUksTUFBTSx3QkFBd0IsRUFBRSxPQUFPLE1BQU0sQ0FBQztDQUM3RyxPQUFPLFdBQVcsQ0FBQyxPQUFPLEtBQUssSUFBSSxDQUFDLFNBQVMsS0FBSztBQUNuRDtBQUNBLFNBQVMsZUFBZSxRQUFRLE1BQU0sT0FBTyxPQUFPLFFBQVEsU0FBUyxNQUFNO0NBQzFFLFFBQVEsZUFBZTtDQUN2QixJQUFJLFVBQVUsVUFBVSxPQUFPLElBQUk7Q0FDbkMsSUFBSSxRQUFRLE9BQU8sT0FBTyxPQUFPLG9CQUFvQixRQUFRLE1BQU0sT0FBTyxTQUFTLFFBQVEsTUFBTTtDQUNqRyxJQUFJO0VBQ0gsTUFBTSxRQUFRLFVBQVUsUUFBUSxFQUFFO0NBQ25DLFNBQVMsY0FBYztFQUN0QixVQUFVLFVBQVUsY0FBYyxJQUFJO0NBQ3ZDO0NBQ0EsUUFBUSxlQUFlO0NBQ3ZCLE9BQU8sb0JBQW9CLFFBQVEsTUFBTSxPQUFPLFNBQVMsUUFBUSxNQUFNO0FBQ3hFO0FBQ0EsU0FBUyxvQkFBb0IsUUFBUSxNQUFNLE9BQU8sU0FBUyxRQUFRLFNBQVMsTUFBTTtDQUNqRixJQUFJLFFBQVEsT0FBTyxZQUFZLE9BQU87Q0FDdEMsUUFBUSxlQUFlO0NBQ3ZCLElBQUk7RUFDSCxRQUFRLEVBQUUsQ0FBQyxRQUFRLGdCQUFnQixLQUFLO0VBQ3hDLE9BQU8sZ0JBQWdCLFFBQVEsRUFBRTtFQUNqQyxRQUFRLGVBQWU7RUFDdkIsT0FBTztDQUNSLFNBQVMsT0FBTztFQUNmLFFBQVEsZUFBZTtFQUN2QixPQUFPLFNBQVMsZUFBZSxRQUFRLE1BQU0sT0FBTyxPQUFPLFFBQVEsS0FBSyxJQUFJLENBQUMsT0FBTyxLQUFLO0NBQzFGO0FBQ0Q7QUFDQSxTQUFTLE1BQU0sT0FBTyxPQUFPO0NBQzVCLElBQUksVUFBVSxLQUFLLEdBQUcsT0FBTztFQUM1QixRQUFRO0VBQ1IsT0FBTztDQUNSO0NBQ0EsT0FBTztFQUNOLFFBQVE7RUFDUjtDQUNEO0FBQ0Q7QUFDQSxTQUFTLGFBQWEsUUFBUSxVQUFVO0NBQ3ZDLFFBQVEsWUFBWSxPQUFPLFNBQVM7RUFDbkMsR0FBRztFQUNILGVBQWU7Q0FDaEIsQ0FBQztBQUNGO0FBQ0EsU0FBUyxRQUFRLE9BQU8sUUFBUTtDQUMvQixPQUFPLFNBQVMsY0FBYyxPQUFPLE1BQU0sSUFBSTtBQUNoRDtBQUNBLFNBQVMsV0FBVyxRQUFRLE1BQU0sT0FBTztDQUN4QyxNQUFNLFFBQVEsS0FBSyxRQUFRO0NBQzNCLE1BQU0sUUFBUSxTQUFTLFFBQVEsS0FBSztDQUNwQyxNQUFNLFlBQVksS0FBSyxRQUFRLFFBQVEsRUFBRSxFQUFFO0NBQzNDLElBQUksT0FBTyxRQUFRLEdBQUcsT0FBTyxNQUFNLE9BQU87Q0FDMUMsSUFBSSxjQUFjLE9BQU8sT0FBTztDQUNoQyxNQUFNLFdBQVcsVUFBVTtFQUMxQixPQUFPLFVBQVUsUUFBUSxjQUFjLGNBQWMsY0FBYztDQUNwRTtDQUNBLE1BQU0sYUFBYSxPQUFPLFFBQVEsY0FBYztDQUNoRCxNQUFNLG1CQUFtQixRQUFRLFVBQVU7Q0FDM0MsTUFBTSxNQUFNO0NBQ1osTUFBTSxTQUFTLE1BQU0sUUFBUTtDQUM3QixJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU87Q0FDOUIsSUFBSSxPQUFPLFdBQVcsWUFBWSxPQUFPLFFBQVEsTUFBTTtDQUN2RCxNQUFNLFVBQVU7RUFDZixRQUFRLE1BQU0sTUFBTSxRQUFRLE1BQU0sV0FBVztFQUM3QyxRQUFRLE1BQU0sTUFBTSxRQUFRLE1BQU0sV0FBVztFQUM3QyxVQUFVLEtBQUs7RUFDZixTQUFTLEtBQUssUUFBUSxLQUFLLGVBQWU7R0FDekMsT0FBTyxVQUFVO0dBQ2pCLFVBQVUsVUFBVTtHQUNwQixVQUFVLFVBQVU7R0FDcEIsWUFBWSxVQUFVO0dBQ3RCLElBQUksVUFBVTtHQUNkLFNBQVMsVUFBVTtHQUNuQixRQUFRLE1BQU0sVUFBVSxRQUFRLFVBQVUsV0FBVztHQUNyRCxRQUFRLE1BQU0sVUFBVSxRQUFRLFVBQVUsV0FBVztHQUNyRCxLQUFLLFVBQVU7RUFDaEIsRUFBRTtDQUNIO0NBQ0EsSUFBSTtFQUNILE9BQU8sUUFBUSxRQUFRLE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLFVBQVUsUUFBUSxTQUFTLFVBQVUsQ0FBQztDQUNyRixTQUFTLE9BQU87RUFDZixPQUFPLFFBQVEsT0FBTyxLQUFLO0NBQzVCO0FBQ0Q7QUFDQSxTQUFTLGNBQWMsT0FBTyxTQUFTO0NBQ3RDLElBQUksUUFBUSxPQUFPLGFBQWEsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxTQUFTLFFBQVEsRUFBRSxDQUFDLFVBQVUsTUFBTTtDQUNoRixPQUFPO0FBQ1I7QUFDQSxlQUFlLGNBQWMsUUFBUSxNQUFNLFFBQVE7Q0FDbEQsTUFBTSxpQkFBaUIsS0FBSyxRQUFRLFdBQVcsVUFBVSxNQUFNLFNBQVM7Q0FDeEUsSUFBSSxNQUFNLGlCQUFpQixJQUFJLEtBQUssUUFBUSxTQUFTLGlCQUFpQjtDQUN0RSxJQUFJO0NBQ0osSUFBSSxnQkFBZ0IsRUFBRSxHQUFHLE9BQU8sUUFBUSxXQUFXLENBQUMsRUFBRTtDQUN0RCxLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsS0FBSyxTQUFTO0VBQ3pDLE1BQU0sUUFBUSxLQUFLLFFBQVE7RUFDM0IsTUFBTSxRQUFRLFNBQVMsUUFBUSxLQUFLO0VBQ3BDLElBQUk7R0FDSCxNQUFNLE1BQU0sV0FBVyxRQUFRLE1BQU0sS0FBSztHQUMxQyxNQUFNLE1BQU0sZUFBZSxVQUFVLE1BQU0sTUFBTTtFQUNsRCxTQUFTLE9BQU87R0FDZixRQUFRLGVBQWU7R0FDdkIsVUFBVSxDQUFDLE9BQU8sY0FBYyxPQUFPLGVBQWUsUUFBUSxNQUFNLE9BQU8sT0FBTyxNQUFNLENBQUMsQ0FBQztHQUMxRixNQUFNO0VBQ1A7RUFDQSxRQUFRLGVBQWU7RUFDdkIsSUFBSSxVQUFVLEVBQUUsQ0FBQyxPQUFPLFlBQVk7RUFDcEMsTUFBTSxzQkFBc0IsS0FBSztFQUNqQyxJQUFJLFVBQVU7RUFDZCxJQUFJO0dBQ0gsSUFBSTtHQUNKLElBQUksTUFBTSxRQUFRLFNBQVM7SUFDMUIsTUFBTSxzQkFBc0I7S0FDM0IsTUFBTSxNQUFNO0tBQ1osUUFBUSxNQUFNO0tBQ2QsU0FBUztLQUNULFVBQVUsS0FBSztLQUNmLFVBQVUsYUFBYSxRQUFRLEtBQUssUUFBUTtLQUM1QyxlQUFlLE9BQU87S0FDdEIsT0FBTyxNQUFNO0tBQ2IsaUJBQWlCLE1BQU07S0FDdkIsU0FBUztLQUNULFNBQVMsS0FBSztLQUNkLFNBQVMsTUFBTTtJQUNoQjtJQUNBLGVBQWUsTUFBTSxRQUFRLFFBQVEsbUJBQW1CLEtBQUssS0FBSztHQUNuRTtHQUNBLFVBQVU7SUFDVCxHQUFHO0lBQ0gsR0FBRztHQUNKO0dBQ0EsTUFBTSxVQUFVO0VBQ2pCLFNBQVMsT0FBTztHQUNmLFFBQVEsZUFBZTtHQUN2QixJQUFJLENBQUMsU0FBUyxVQUFVLENBQUMsT0FBTyxjQUFjLE9BQU8sZUFBZSxRQUFRLE1BQU0sT0FBTyxPQUFPLE1BQU0sQ0FBQyxDQUFDO0dBQ3hHLE1BQU07R0FDTjtFQUNEO0VBQ0EsUUFBUSxlQUFlO0VBQ3ZCLElBQUksU0FBUztFQUNiLE1BQU0sa0JBQWtCLE1BQU0sZUFBZSxNQUFNO0VBQ25ELElBQUksb0JBQW9CLEtBQUssR0FBRztHQUMvQixVQUFVLENBQUMsT0FBTyxjQUFjLE9BQU8sZUFBZSxRQUFRLE1BQU0sT0FBTyxpQkFBaUIsTUFBTSxDQUFDLENBQUM7R0FDcEcsTUFBTTtHQUNOO0VBQ0Q7RUFDQSxRQUFRLGVBQWU7RUFDdkIsSUFBSSxNQUFNLFFBQVEsU0FBUyxDQUFDLE1BQU0sUUFBUSxZQUFZO0dBQ3JELGdCQUFnQjtHQUNoQjtFQUNEO0VBQ0EsTUFBTSxrQkFBa0IsTUFBTTtFQUM5QixNQUFNLFVBQVU7R0FDZixRQUFRLE1BQU07R0FDZDtHQUNBLFFBQVEsTUFBTTtHQUNkLFNBQVM7R0FDVDtHQUNBLFVBQVUsS0FBSztHQUNmLFVBQVUsYUFBYSxRQUFRLEtBQUssUUFBUTtHQUM1QyxlQUFlLE9BQU87R0FDdEIsT0FBTyxNQUFNO0dBQ2IsU0FBUyxLQUFLO0dBQ2QsU0FBUyxNQUFNO0dBQ2YsR0FBRyxPQUFPLFFBQVE7RUFDbkI7RUFDQSxJQUFJO0dBQ0gsTUFBTSxvQkFBb0IsTUFBTSxNQUFNLFFBQVEsV0FBVyxPQUFPO0dBQ2hFLFFBQVEsZUFBZTtHQUN2QixNQUFNLFVBQVUsY0FBYyxPQUFPLG9CQUFvQixRQUFRLE1BQU0sT0FBTyxVQUFVLG1CQUFtQixLQUFLLEdBQUcsTUFBTSxDQUFDO0dBQzFILElBQUksUUFBUSxPQUFPLFNBQVM7SUFDM0IsVUFBVSxDQUFDLE9BQU8sT0FBTztJQUN6QixNQUFNO0lBQ047R0FDRDtHQUNBLE1BQU0sc0JBQXNCO0dBQzVCLE1BQU0sVUFBVTtJQUNmLEdBQUc7SUFDSCxHQUFHO0dBQ0o7R0FDQSxnQkFBZ0IsTUFBTTtFQUN2QixTQUFTLE9BQU87R0FDZixRQUFRLGVBQWU7R0FDdkIsVUFBVSxDQUFDLE9BQU8sY0FBYyxPQUFPLGVBQWUsUUFBUSxNQUFNLE9BQU8sT0FBTyxNQUFNLENBQUMsQ0FBQztHQUMxRixNQUFNO0dBQ047RUFDRDtDQUNEO0NBQ0EsT0FBTztFQUNOLFVBQVUsS0FBSztFQUNmLFNBQVMsS0FBSztFQUNkO0VBQ0E7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxPQUFPLE9BQU87Q0FDbkUsT0FBTztFQUNOLFFBQVEsTUFBTTtFQUNkLE1BQU0sTUFBTTtFQUNaLFNBQVM7RUFDVCxvQkFBb0IsTUFBTSxRQUFRLEVBQUUsRUFBRTtFQUN0QyxpQkFBaUIsTUFBTTtFQUN2QixTQUFTLE1BQU07RUFDZixVQUFVLEtBQUs7RUFDZixVQUFVLGFBQWEsUUFBUSxLQUFLLFFBQVE7RUFDNUMsT0FBTyxNQUFNO0VBQ2I7RUFDQSxHQUFHLE9BQU8sUUFBUTtDQUNuQjtBQUNEO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxRQUFRO0NBQzdELE1BQU0sUUFBUSxLQUFLLFFBQVE7Q0FDM0IsTUFBTSxRQUFRLFNBQVMsUUFBUSxLQUFLO0NBQ3BDLElBQUk7Q0FDSixJQUFJLE1BQU0sUUFBUSxPQUFPLFVBQVUsUUFBUSxRQUFRLENBQUMsT0FBTyxDQUFDO01BQ3ZEO0VBQ0osTUFBTSxjQUFjLE1BQU0sUUFBUTtFQUNsQyxNQUFNLFNBQVMsT0FBTyxnQkFBZ0IsYUFBYSxjQUFjLGFBQWE7RUFDOUUsSUFBSSxDQUFDLFFBQVEsVUFBVSxRQUFRLFFBQVEsQ0FBQyxTQUFTLEtBQUssQ0FBQyxDQUFDO09BQ25ELFVBQVUsUUFBUSxRQUFRLENBQUMsQ0FBQyxXQUFXLE9BQU8saUJBQWlCLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxXQUFXLFVBQVUsUUFBUSxLQUFLLElBQUksVUFBVSxVQUFVLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLFdBQVc7R0FDOU0sSUFBSSxRQUFRLFdBQVcsTUFBTSxnQkFBZ0IsT0FBTyxXQUFXLHVCQUF1QixPQUFPLENBQUMsT0FBTztHQUNyRyxJQUFJLE9BQU8sT0FBTyxPQUFPLFNBQVMsZUFBZSxRQUFRLE1BQU0sT0FBTyxPQUFPLElBQUksTUFBTTtRQUNsRixTQUFTLG9CQUFvQixRQUFRLE1BQU0sT0FBTyxRQUFRLE1BQU07R0FDckUsT0FBTyxjQUFjLE9BQU8sTUFBTTtFQUNuQyxDQUFDO0NBQ0Y7Q0FDQSxNQUFNLGNBQWMsUUFBUSxNQUFNLFdBQVc7RUFDNUMsTUFBTSxXQUFXLEVBQUUsR0FBRyxNQUFNO0VBQzVCLElBQUksT0FBTyxPQUFPLFNBQVM7R0FDMUIsU0FBUyxhQUFhLE9BQU87R0FDN0IsU0FBUyxTQUFTO0dBQ2xCLFNBQVMsUUFBUSxLQUFLO0dBQ3RCLFNBQVMsVUFBVTtHQUNuQixTQUFTLGFBQWE7RUFDdkIsT0FBTyxJQUFJLE9BQU8sT0FBTyxPQUFPO0dBQy9CLFNBQVMsU0FBUztHQUNsQixTQUFTLFFBQVEsT0FBTztFQUN6QixPQUFPLElBQUksT0FBTyxPQUFPLFdBQVc7R0FDbkMsU0FBUyxTQUFTO0dBQ2xCLFNBQVMsUUFBUSxPQUFPO0VBQ3pCO0VBQ0EsT0FBTztDQUNSLENBQUM7Q0FDRCxPQUFPO0VBQ047RUFDQTtFQUNBLE9BQU87Q0FDUjtBQUNEO0FBQ0EsZUFBZSxvQkFBb0IsUUFBUSxTQUFTLFNBQVMsUUFBUSxXQUFXLEdBQUc7Q0FDbEYsTUFBTSxRQUFRLFVBQVUsRUFBRSxDQUFDO0NBQzNCLElBQUksUUFBUSxPQUFPLFVBQVUsUUFBUSxXQUFXLFVBQVUsTUFBTSxZQUFZLE1BQU0sT0FBTyxJQUFJLFVBQVUsTUFBTSxRQUFRLFNBQVM7Q0FDOUgsSUFBSSxRQUFRLEdBQUcsUUFBUTtDQUN2QixLQUFLLElBQUksWUFBWSxPQUFPLGFBQWEsR0FBRyxhQUFhO0VBQ3hELE1BQU0sUUFBUSxTQUFTLFFBQVEsUUFBUSxVQUFVO0VBQ2pELElBQUk7R0FDSCxNQUFNLFVBQVUsZUFBZSxPQUFPLEtBQUs7R0FDM0MsSUFBSSxTQUFTLE1BQU07RUFDcEIsUUFBUTtHQUNQLFFBQVEsZUFBZTtFQUN4QjtFQUNBLFFBQVEsZUFBZTtFQUN2QixJQUFJLE1BQU0sUUFBUSxtQkFBbUIsT0FBTztDQUM3QztDQUNBLE9BQU8sT0FBTyxVQUFVLFFBQVE7QUFDakM7QUFDQSxTQUFTLGFBQWEsU0FBUyxRQUFRLEdBQUcsU0FBUyw0QkFBNEI7Q0FDOUUsS0FBSyxJQUFJLFFBQVEsT0FBTyxRQUFRLFFBQVEsUUFBUSxTQUFTLFFBQVEsTUFBTSxDQUFDLGdCQUFnQixNQUFNLE1BQU07QUFDckc7QUFDQSxlQUFlLGFBQWEsUUFBUSxNQUFNLFNBQVMsUUFBUTtDQUMxRCxJQUFJLENBQUMsU0FBUztFQUNiLE1BQU0sV0FBVyxLQUFLLFFBQVEsV0FBVyxVQUFVLE1BQU0sU0FBUztFQUNsRSxJQUFJLFlBQVksR0FBRztHQUNsQixhQUFhLEtBQUssU0FBUyxXQUFXLENBQUM7R0FDdkMsT0FBTztJQUNOLFFBQVE7SUFDUjtJQUNBLE1BQU07R0FDUDtFQUNEO0VBQ0EsT0FBTyxFQUFFLFFBQVEsSUFBSTtDQUN0QjtDQUNBLE1BQU0sQ0FBQyxPQUFPLFdBQVc7Q0FDekIsSUFBSSxRQUFRLE9BQU8sT0FBTztFQUN6QixNQUFNLFFBQVEsS0FBSyxRQUFRO0VBQzNCLE1BQU0sWUFBWSxLQUFLO0VBQ3ZCLE1BQU0sU0FBUztFQUNmLE1BQU0sUUFBUSxRQUFRO0VBQ3RCLE1BQU0sYUFBYTtFQUNuQixhQUFhLEtBQUssU0FBUyxRQUFRLENBQUM7RUFDcEMsT0FBTztHQUNOLFFBQVE7R0FDUixVQUFVO0dBQ1YsTUFBTTtFQUNQO0NBQ0Q7Q0FDQSxNQUFNLFdBQVcsUUFBUSxNQUFNLE1BQU0sb0JBQW9CLFFBQVEsS0FBSyxTQUFTLFNBQVMsTUFBTTtDQUM5RixNQUFNLFFBQVEsS0FBSyxRQUFRO0NBQzNCLE1BQU0sUUFBUSxRQUFRO0NBQ3RCLE1BQU0sVUFBVSxNQUFNO0NBQ3RCLE1BQU0sWUFBWSxLQUFLO0NBQ3ZCLElBQUksTUFBTSxZQUFZLE9BQU8sVUFBVSxJQUFJO0VBQzFDLE1BQU0sU0FBUztFQUNmLE1BQU0sWUFBWTtFQUNsQixNQUFNLFFBQVE7Q0FDZixPQUFPO0VBQ04sTUFBTSxTQUFTO0VBQ2YsTUFBTSxRQUFRO0NBQ2Y7Q0FDQSxNQUFNLGFBQWE7Q0FDbkIsYUFBYSxLQUFLLFNBQVMsV0FBVyxDQUFDO0NBQ3ZDLE9BQU87RUFDTixRQUFRO0VBQ1I7RUFDQSxNQUFNO0NBQ1A7QUFDRDtBQUNBLGVBQWUsaUJBQWlCLFFBQVEsTUFBTSxLQUFLLFFBQVE7Q0FDMUQsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLEtBQUssUUFBUSxRQUFRLFNBQVM7RUFDekQsTUFBTSxRQUFRLEtBQUssUUFBUTtFQUMzQixJQUFJLFNBQVMsT0FBTyxNQUFNLFFBQVEsUUFBUSxNQUFNLFdBQVcsV0FBVztFQUN0RSxNQUFNLFFBQVEsU0FBUyxRQUFRLEtBQUs7RUFDcEMsSUFBSTtHQUNILE1BQU0sVUFBVSxlQUFlLEtBQUs7R0FDcEMsSUFBSSxTQUFTO0lBQ1osTUFBTSxRQUFRLFFBQVEsV0FBVztLQUNoQyxRQUFRLGVBQWU7SUFDeEIsSUFBSSxVQUFVO0tBQ2IsUUFBUSxlQUFlO0tBQ3ZCLE9BQU8sQ0FBQyxPQUFPLGNBQWMsT0FBTyxlQUFlLFFBQVEsTUFBTSxPQUFPLE9BQU8sTUFBTSxDQUFDLENBQUM7SUFDeEYsQ0FBQztJQUNELE1BQU0sWUFBWSxDQUFDLENBQUM7SUFDcEIsT0FBTyxLQUFLLEtBQUs7R0FDbEI7RUFDRCxTQUFTLE9BQU87R0FDZixRQUFRLGVBQWU7R0FDdkIsT0FBTyxLQUFLLENBQUMsT0FBTyxjQUFjLE9BQU8sZUFBZSxRQUFRLE1BQU0sT0FBTyxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDOUY7Q0FDRDtDQUNBLEtBQUssTUFBTSxTQUFTLFFBQVE7RUFDM0IsTUFBTSxVQUFVLE1BQU0sUUFBUSxLQUFLLElBQUksUUFBUSxNQUFNO0VBQ3JELElBQUksU0FBUyxPQUFPO0NBQ3JCO0FBQ0Q7QUFDQSxlQUFlLFlBQVksUUFBUSxNQUFNLFFBQVE7Q0FDaEQsS0FBSyxNQUFNLFNBQVMsS0FBSyxTQUFTO0VBQ2pDLE1BQU0sZUFBZSxTQUFTLFFBQVEsS0FBSyxDQUFDLENBQUM7RUFDN0MsSUFBSSxhQUFhLFFBQVEsYUFBYSxXQUFXLGFBQWEsU0FBUztHQUN0RSxNQUFNLFVBQVU7SUFDZixLQUFLLE9BQU8sUUFBUTtJQUNwQixTQUFTLEtBQUs7SUFDZDtJQUNBLFFBQVEsTUFBTTtJQUNkLFlBQVksTUFBTTtHQUNuQjtHQUNBLElBQUk7SUFDSCxNQUFNLENBQUMsTUFBTSxTQUFTLFdBQVcsTUFBTSxRQUFRLElBQUk7S0FDbEQsYUFBYSxPQUFPLE9BQU87S0FDM0IsYUFBYSxVQUFVLE9BQU87S0FDOUIsYUFBYSxVQUFVLE9BQU87SUFDL0IsQ0FBQztJQUNELFFBQVEsZUFBZTtJQUN2QixNQUFNLE9BQU8sTUFBTTtJQUNuQixNQUFNLFFBQVEsTUFBTTtJQUNwQixNQUFNLGNBQWMsTUFBTTtJQUMxQixNQUFNLFNBQVMsTUFBTTtJQUNyQixNQUFNLFVBQVU7SUFDaEIsTUFBTSxVQUFVO0dBQ2pCLFNBQVMsT0FBTztJQUNmLFFBQVEsZUFBZTtJQUN2QixRQUFRLE1BQU0sS0FBSztHQUNwQjtFQUNEO0VBQ0EsSUFBSSxNQUFNLFFBQVEsU0FBUyxNQUFNLFdBQVcsYUFBYSxNQUFNLFdBQVc7Q0FDM0U7QUFDRDtBQUNBLGVBQWUsa0JBQWtCLFFBQVEsVUFBVSxnQkFBZ0IsUUFBUTtDQUMxRSxNQUFNLFVBQVU7RUFDZjtFQUNBLFNBQVMsZUFBZSxLQUFLLFdBQVc7R0FDdkMsR0FBRztHQUNILHFCQUFxQixLQUFLO0dBQzFCLFNBQVMsQ0FBQztHQUNWLFlBQVk7R0FDWixpQkFBaUIsSUFBSSxnQkFBZ0I7RUFDdEMsRUFBRTtDQUNIO0NBQ0EsTUFBTSxrQkFBa0IsYUFBYSxRQUFRLFNBQVMsR0FBRyxRQUFRLFVBQVUsMEJBQTBCO0NBQ3JHLElBQUksUUFBUSxTQUFTO0VBQ3BCLFVBQVU7RUFDVixPQUFPLGVBQWU7Q0FDdkI7Q0FDQSxRQUFRLGlCQUFpQixTQUFTLFdBQVcsRUFBRSxNQUFNLEtBQUssQ0FBQztDQUMzRCxJQUFJO0VBQ0gsTUFBTSx3QkFBd0IsUUFBUSxRQUFRLFdBQVcsVUFBVSxNQUFNLFNBQVM7RUFDbEYsSUFBSSxPQUFPLFFBQVEsaUJBQWlCLFVBQVUseUJBQXlCLEdBQUc7R0FDekUsTUFBTSxXQUFXLE1BQU0sb0JBQW9CLFFBQVEsUUFBUSxTQUFTLEtBQUssR0FBRyxRQUFRLHFCQUFxQjtHQUN6RyxJQUFJLGFBQWEsdUJBQXVCO0lBQ3ZDLFFBQVEsUUFBUSxzQkFBc0IsQ0FBQyxZQUFZLEtBQUs7SUFDeEQsUUFBUSxRQUFRLFNBQVMsQ0FBQyxZQUFZO0dBQ3ZDO0VBQ0Q7RUFDQSxNQUFNLE9BQU8sTUFBTSxjQUFjLFFBQVEsU0FBUyxNQUFNO0VBQ3hELFFBQVEsZUFBZTtFQUN2QixJQUFJLFlBQVksS0FBSztFQUNyQixJQUFJLEtBQUssVUFBVSxFQUFFLENBQUMsT0FBTyxZQUFZLFlBQVk7T0FDaEQsSUFBSSxLQUFLLFVBQVUsRUFBRSxDQUFDLE9BQU8sV0FBVztHQUM1QyxLQUFLLFFBQVEsS0FBSyxNQUFNLG9CQUFvQixRQUFRLEtBQUssU0FBUyxLQUFLLFNBQVMsTUFBTTtHQUN0RixZQUFZLEtBQUssSUFBSSxXQUFXLEtBQUssUUFBUSxLQUFLLENBQUM7RUFDcEQ7RUFDQSxNQUFNLFFBQVEsQ0FBQztFQUNmLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxXQUFXLFNBQVM7R0FDL0MsTUFBTSxPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxPQUFPLE1BQU07R0FDaEUsTUFBTSxLQUFLLElBQUk7RUFDaEI7RUFDQSxJQUFJO0VBQ0osSUFBSSxVQUFVLEtBQUssVUFBVSxFQUFFLENBQUMsT0FBTyxhQUFhLEtBQUssVUFBVSxLQUFLO0VBQ3hFLElBQUk7R0FDSCxNQUFNLFFBQVEsSUFBSSxNQUFNLEtBQUssU0FBUyxLQUFLLFFBQVEsTUFBTSxrQkFBa0I7SUFDMUUsTUFBTSxRQUFRLEtBQUssUUFBUSxLQUFLO0lBQ2hDLE1BQU0sVUFBVTtJQUNoQixJQUFJLFFBQVEsT0FBTyxTQUFTO0tBQzNCLE1BQU0sYUFBYSxRQUFRO0tBQzNCLE1BQU0sU0FBUztLQUNmLE1BQU0sUUFBUSxLQUFLO0tBQ25CLE1BQU0sVUFBVTtLQUNoQixNQUFNLGFBQWE7S0FDbkIsTUFBTSxZQUFZLEtBQUssSUFBSTtJQUM1QixPQUFPLElBQUksUUFBUSxPQUFPLFlBQVk7S0FDckMsVUFBVSxDQUFDLEtBQUssT0FBTyxPQUFPO0tBQzlCLE1BQU07SUFDUCxPQUFPO0tBQ04sSUFBSSxNQUFNLFFBQVEsT0FBTztNQUN4QixNQUFNLFNBQVM7TUFDZixNQUFNLFFBQVEsS0FBSztNQUNuQixNQUFNLFVBQVU7TUFDaEIsTUFBTSxhQUFhO0tBQ3BCO0tBQ0EsSUFBSSxDQUFDLGlCQUFpQixRQUFRLE9BQU8sU0FBUyxnQkFBZ0IsQ0FBQyxLQUFLLE9BQU8sT0FBTztJQUNuRjtHQUNELENBQUMsQ0FBQyxDQUFDO0VBQ0osU0FBUyxPQUFPO0dBQ2YsSUFBSSxDQUFDLE1BQU0sUUFBUSxLQUFLLEdBQUcsTUFBTTtHQUNqQyxVQUFVO0VBQ1g7RUFDQSxRQUFRLGVBQWU7RUFDdkIsSUFBSSxVQUFVLEVBQUUsQ0FBQyxPQUFPLFlBQVk7R0FDbkMsYUFBYSxLQUFLLFNBQVMsR0FBRyxxQkFBcUI7R0FDbkQsT0FBTztJQUNOLE1BQU07SUFDTixVQUFVLFFBQVEsRUFBRSxDQUFDO0dBQ3RCO0VBQ0Q7RUFDQSxJQUFJLFVBQVUsS0FBSyxXQUFXO0VBQzlCLE1BQU0sa0JBQWtCLEtBQUssUUFBUSxXQUFXLFVBQVUsTUFBTSxTQUFTO0VBQ3pFLElBQUk7RUFDSixJQUFJLFNBQVM7R0FDWixNQUFNLGFBQWEsUUFBUSxPQUFPLFFBQVEsRUFBRSxDQUFDLE9BQU8sWUFBWSxNQUFNLG9CQUFvQixRQUFRLEtBQUssU0FBUyxTQUFTLE1BQU0sSUFBSSxRQUFRO0dBQzNJLEtBQUssTUFBTSxRQUFRLE9BQU87SUFDekIsSUFBSSxLQUFLLFNBQVMsWUFBWTtJQUM5QixNQUFNLFVBQVUsTUFBTSxLQUFLO0lBQzNCLElBQUksUUFBUSxPQUFPLFdBQVcsUUFBUSxLQUFLLGNBQWMsRUFBRSxnQkFBZ0IsS0FBSyxRQUFRLEtBQUssU0FBUztLQUNyRyxVQUFVLENBQUMsS0FBSyxPQUFPLE9BQU87S0FDOUIsUUFBUSxLQUFLLFFBQVEsT0FBTyxZQUFZLE1BQU0sb0JBQW9CLFFBQVEsS0FBSyxTQUFTLFNBQVMsTUFBTSxJQUFJLEtBQUs7S0FDaEg7SUFDRDtHQUNEO0dBQ0EsZUFBZSxRQUFRO0VBQ3hCLE9BQU8sZUFBZSxrQkFBa0IsSUFBSSxLQUFLLFFBQVEsU0FBUztFQUNsRSxNQUFNLGtCQUFrQixNQUFNLGlCQUFpQixRQUFRLE1BQU0sY0FBYyxNQUFNO0VBQ2pGLFFBQVEsZUFBZTtFQUN2QixJQUFJLGlCQUFpQjtHQUNwQixJQUFJLGdCQUFnQixFQUFFLENBQUMsT0FBTyxZQUFZO0lBQ3pDLGFBQWEsS0FBSyxTQUFTLEdBQUcscUJBQXFCO0lBQ25ELE9BQU87S0FDTixNQUFNO0tBQ04sVUFBVSxnQkFBZ0IsRUFBRSxDQUFDO0lBQzlCO0dBQ0Q7R0FDQSxVQUFVO0VBQ1g7RUFDQSxNQUFNLFdBQVcsTUFBTSxhQUFhLFFBQVEsTUFBTSxTQUFTLE1BQU07RUFDakUsSUFBSSxTQUFTLGFBQWEsS0FBSyxHQUFHO0dBQ2pDLE1BQU0sUUFBUSxLQUFLLFFBQVEsU0FBUztHQUNwQyxJQUFJLE1BQU0sUUFBUSxNQUFNO0lBQ3ZCLE1BQU0sUUFBUSxTQUFTLFFBQVEsS0FBSztJQUNwQyxJQUFJO0tBQ0gsSUFBSSxTQUFTLFNBQVMsT0FBTyxNQUFNLGVBQWUsT0FBTyxnQkFBZ0I7VUFDcEUsSUFBSSxNQUFNLFdBQVcsTUFBTSxRQUFRLElBQUksQ0FBQyxlQUFlLEtBQUssR0FBRyxlQUFlLE9BQU8sbUJBQW1CLENBQUMsQ0FBQztVQUMxRyxNQUFNLGVBQWUsT0FBTyxtQkFBbUI7SUFDckQsUUFBUSxDQUFDO0lBQ1QsUUFBUSxlQUFlO0dBQ3hCO0VBQ0Q7RUFDQSxRQUFRLGVBQWU7RUFDdkIsTUFBTSxZQUFZLFFBQVE7R0FDekIsVUFBVSxLQUFLO0dBQ2YsU0FBUyxLQUFLO0VBQ2YsR0FBRyxNQUFNO0VBQ1QsUUFBUSxlQUFlO0VBQ3ZCLE9BQU8sV0FBVyxXQUFXLFlBQVk7R0FDeEMsSUFBSSxDQUFDLFNBQVMsVUFBVTtFQUN6QixDQUFDO0VBQ0QsT0FBTztHQUNOLE1BQU07R0FDTixRQUFRLFNBQVM7R0FDakIsU0FBUyxLQUFLO0VBQ2Y7Q0FDRCxVQUFVO0VBQ1QsUUFBUSxvQkFBb0IsU0FBUyxTQUFTO0NBQy9DO0FBQ0Q7QUFDQSxlQUFlLGdCQUFnQixRQUFRLE1BQU07Q0FDNUMsSUFBSSxDQUFDLE1BQU0scUJBQXFCLE9BQU8scUJBQXFCO0NBQzVELE1BQU0sT0FBTyxPQUFPO0NBQ3BCLE1BQU0sV0FBVyxPQUFPO0NBQ3hCLE1BQU0sY0FBYyxPQUFPO0NBQzNCLElBQUk7Q0FDSixJQUFJO0VBQ0gsTUFBTSxZQUFZLE9BQU8sY0FBYztHQUN0QyxJQUFJLEtBQUs7R0FDVCxRQUFRO0dBQ1IsUUFBUTtHQUNSLE1BQU07R0FDTixPQUFPO0dBQ1Asd0JBQXdCO0VBQ3pCLENBQUM7RUFDRCxJQUFJLEtBQUssZUFBZSxVQUFVLFlBRWpDLE1BQU0sU0FBUyxFQUFFLE1BREosVUFBVSxjQUFjLElBQ2YsQ0FBQztFQUd4QixNQUFNLGFBQWEsc0JBQXNCLE1BRHBCLE9BQU8sT0FBTyxpQkFBaUIsSUFDTCxDQUFZO0VBQzNELE9BQU8sS0FBSztHQUNYLE1BQU07R0FDTixHQUFHO0VBQ0osQ0FBQztFQUNELE9BQU8sS0FBSztHQUNYLE1BQU07R0FDTixHQUFHO0VBQ0osQ0FBQztFQUNELE1BQU0sU0FBUyxlQUFlO0VBQzlCLFNBQVMsTUFBTSxRQUFRLGtCQUFrQixRQUFRLE1BQU0sT0FBTyxZQUFZLElBQUksR0FBRyxNQUFNLE9BQU8sR0FBRyxNQUFNLE9BQU87RUFDOUcsTUFBTSxTQUFTLGVBQWU7Q0FDL0IsU0FBUyxPQUFPO0VBQ2YsTUFBTSxTQUFTLGVBQWU7RUFDOUIsSUFBSSxDQUFDLFdBQVcsS0FBSyxHQUFHLE1BQU07RUFDOUIsTUFBTSxRQUFRLGdCQUFnQjtFQUM5QixTQUFTO0dBQ1IsTUFBTTtHQUNOLFVBQVUsT0FBTyxnQkFBZ0IsS0FBSztFQUN2QztDQUNEO0NBQ0EsT0FBTyxnQkFBZ0I7Q0FDdkIsSUFBSSxVQUFVO0NBQ2QsT0FBTyxZQUFZO0VBQ2xCLE9BQU8sT0FBTyxTQUFTLElBQUksSUFBSTtFQUMvQixPQUFPLE9BQU8sT0FBTyxJQUFJLE1BQU07RUFDL0IsSUFBSSxPQUFPLFNBQVMsVUFBVTtHQUM3QixPQUFPLGFBQWEsT0FBTztHQUMzQixVQUFVLE9BQU8sZ0JBQWdCLGFBQWEsT0FBTyxPQUFPO0dBQzVELE9BQU8sT0FBTyxXQUFXLE9BQU8sT0FBTztHQUN2QyxPQUFPLE9BQU8saUJBQWlCLElBQUksSUFBSTtFQUN4QztDQUNELENBQUM7Q0FDRCxJQUFJLE9BQU8sU0FBUyxVQUFVLGtCQUFrQixRQUFRLFVBQVUsT0FBTyxTQUFTLGFBQWEsT0FBTztDQUN0RyxPQUFPLGdCQUFnQixRQUFRO0NBQy9CLE9BQU8saUJBQWlCLEtBQUs7QUFDOUI7Ozs7Ozs7O0FDM2tCQSxJQUFJLFdBQUEsYUFBbUJXO0FBQ3ZCLElBQUksa0JBQThCLE9BQU8sV0FBVyxjQUFBLGFBQXNCLFlBQUEsYUFBb0I7Ozs7Ozs7O0FDRDlGLElBQU0sdUJBQXVCLE9BQU8sSUFBSSxzQkFBc0I7Ozs7Ozs7Ozs7Ozs7QUFhOUQsU0FBUyxNQUFNLFVBQVUsU0FBUztDQUNqQyxNQUFNLFVBQVU7Q0FDaEIsSUFBSSxRQUFRLHVCQUF1QixPQUFPO0NBQzFDLFFBQVEsd0JBQXdCLEVBQUUsUUFBUSxVQUFVO0NBQ3BELFFBQVEsTUFBTSxTQUFTO0VBQ3RCLFFBQVEscUJBQXFCLENBQUMsU0FBUztFQUN2QyxRQUFRLHFCQUFxQixDQUFDLE9BQU87Q0FDdEMsQ0FBQyxDQUFDLENBQUMsT0FBTyxVQUFVO0VBQ25CLFFBQVEscUJBQXFCLENBQUMsU0FBUztFQUN2QyxRQUFRLHFCQUFxQixDQUFDLFFBQVE7R0FDckMsT0FBTyxTQUFTLGtCQUFrQixzQkFBQSxDQUF1QixLQUFLO0dBQzlELGlCQUFpQjtFQUNsQjtDQUNELENBQUM7Q0FDRCxPQUFPO0FBQ1I7OztBQ2xDQSxJQUFNLGlCQUFpQjs7O0FDQXZCLElBQU0sa0JBQWtCO0FBQ3hCLFNBQVMsb0JBQW9CLGtCQUFrQixNQUFNO0NBQ3BELElBQUksQ0FBQyxrQkFBa0I7Q0FDdkIsSUFBSSxPQUFPLHFCQUFxQixVQUFVLE9BQU87Q0FDakQsT0FBTyxpQkFBaUI7QUFDekI7QUFDQSxTQUFTLHdCQUF3QixVQUFVO0NBQzFDLE9BQU8sVUFBVSxnQkFBZ0I7QUFDbEM7QUFDQSxTQUFTLHNCQUFzQixVQUFVLE1BQU0sa0JBQWtCO0NBQ2hFLE1BQU0sY0FBYyx5QkFBeUIsSUFBSTtDQUNqRCxNQUFNLGNBQWMsb0JBQW9CLGtCQUFrQixRQUFRLEtBQUssWUFBWTtDQUNuRixPQUFPO0VBQ04sR0FBRyx3QkFBd0IsUUFBUSxNQUFNLFNBQVM7R0FDakQsS0FBSztHQUNMLElBQUk7RUFDTCxJQUFJLEVBQUUsS0FBSyxnQkFBZ0I7RUFDM0IsTUFBTSxZQUFZO0VBQ2xCLGVBQWU7RUFDZixHQUFHLGNBQWMsRUFBRSxZQUFZLElBQUksQ0FBQztDQUNyQztBQUNEO0FBQ0EsU0FBUyx5QkFBeUIsTUFBTTtDQUN2QyxJQUFJLE9BQU8sU0FBUyxVQUFVLE9BQU87RUFDcEMsTUFBTTtFQUNOLGFBQWEsS0FBSztDQUNuQjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMscUJBQXFCLFFBQVEsTUFBTTtDQUMzQyxJQUFJLEtBQUssV0FBVyxHQUFHO0NBQ3ZCLElBQUksS0FBSyxXQUFXLEdBQUc7RUFDdEIsT0FBTyxLQUFLLEtBQUssRUFBRTtFQUNuQjtDQUNEO0NBQ0EsTUFBTSx1QkFBdUIsSUFBSSxJQUFJO0NBQ3JDLEtBQUssTUFBTSxPQUFPLE1BQU07RUFDdkIsTUFBTSxNQUFNLEtBQUssVUFBVSxHQUFHO0VBQzlCLElBQUksS0FBSyxJQUFJLEdBQUcsR0FBRztFQUNuQixLQUFLLElBQUksR0FBRztFQUNaLE9BQU8sS0FBSyxHQUFHO0NBQ2hCO0FBQ0Q7QUFJQSxTQUFTLHVCQUF1QixNQUFNO0NBQ3JDLElBQUksT0FBTyxTQUFTLFVBQVUsT0FBTztFQUNwQyxNQUFNO0VBQ04sYUFBYSxLQUFLO0NBQ25CO0NBQ0EsT0FBTztBQUNSOzs7Ozs7O0FDaERBLElBQU0sV0FBVyxPQUFPLFNBQVM7Q0FDaEMsTUFBTSxRQUFRLEtBQUssTUFBTSxHQUFHO0NBQzVCLElBQUk7Q0FDSixJQUFJLElBQUk7Q0FDUixJQUFJLFFBQVE7Q0FDWixRQUFRLE9BQU8sTUFBTSxTQUFTLFFBQVEsU0FBUyxNQUFNLFFBQVEsTUFBTTtDQUNuRSxPQUFPLFNBQVM7QUFDakI7OztBQ1ZBLFNBQVMsc0JBQXNCLFNBQVMsVUFBVSxPQUFPLGtCQUFrQjtDQUMxRSxNQUFNLGVBQWUsaUJBQWlCLE9BQU87Q0FDN0MsTUFBTSxlQUFlLENBQUM7Q0FDdEIsTUFBTSxrQkFBa0IsQ0FBQztDQUN6QixLQUFLLE1BQU0sU0FBUyxjQUFjLEtBQUssTUFBTSxVQUFVLE1BQU0sUUFBUSxNQUFNLE9BQU8sSUFBSSxNQUFNLFVBQVUsQ0FBQyxHQUFHO0VBQ3pHLElBQUksQ0FBQyxRQUFRO0VBQ2IsTUFBTSxFQUFFLFVBQVUsR0FBRyxVQUFVO0VBQy9CLGFBQWEsS0FBSztHQUNqQixLQUFLO0dBQ0wsT0FBTztJQUNOLEdBQUc7SUFDSCxHQUFHO0lBQ0g7R0FDRDtHQUNBO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsSUFBSSxVQUFVLEtBQUssTUFBTSxTQUFTLGNBQWMsS0FBSyxNQUFNLFNBQVMsU0FBUyxPQUFPLE1BQU0sUUFBUSxFQUFFLFdBQVcsQ0FBQyxHQUFHLGdCQUFnQixLQUFLO0VBQ3ZJLEtBQUs7RUFDTCxPQUFPO0dBQ04sR0FBRyxNQUFNO0dBQ1Q7RUFDRDtFQUNBLFVBQVUsTUFBTTtDQUNqQixDQUFDO0NBQ0QsT0FBTyxDQUFDLGNBQWMsZUFBZTtBQUN0QztBQUNBLFNBQVMsc0JBQXNCLENBQUMsY0FBYyxrQkFBa0IseUJBQXlCO0NBQ3hGLElBQUksQ0FBQyx5QkFBeUIsT0FBTyxDQUFDLEdBQUcsY0FBYyxHQUFHLGVBQWU7Q0FDekUsT0FBTztFQUNOLEdBQUcsd0JBQXdCO0VBQzNCLEdBQUc7RUFDSCxHQUFHO0VBQ0gsd0JBQXdCO0NBQ3pCO0FBQ0Q7OztBQy9CQSxJQUFJLFlBQVksTUFBTTtDQUNyQixJQUFJLEtBQUs7RUFDUixPQUFPLEtBQUs7Q0FDYjtDQUNBLElBQUksS0FBSztFQUNSLE9BQU8sS0FBSztDQUNiO0NBQ0EsSUFBSSxPQUFPO0VBQ1YsT0FBTyxLQUFLO0NBQ2I7Q0FDQSxJQUFJLFdBQVc7RUFDZCxPQUFPLEtBQUs7Q0FDYjtDQUNBLFlBQVksU0FBUztFQUNwQixLQUFLLFFBQVEsa0JBQWtCO0dBQzlCLEtBQUssZ0JBQWdCO0dBQ3JCLEtBQUssVUFBVSxLQUFLO0dBQ3BCLE1BQU0sVUFBVSxLQUFLO0dBQ3JCLE1BQU0sU0FBUyxDQUFDLFNBQVMsUUFBUSxDQUFDLFNBQVM7R0FDM0MsS0FBSyxjQUFjLEtBQUssUUFBUSxpQkFBaUI7R0FDakQsSUFBSSxRQUFRLEtBQUssUUFBUTtRQUNwQixJQUFJLENBQUMsS0FBSyxhQUM2QixNQUFNLElBQUksTUFBTSwrSEFBK0g7R0FHM0wsSUFBSSxPQUFPLFNBQVMsY0FBYyxTQUFTO0dBQzNDLElBQUksUUFBUSxTQUFTLEtBQUssT0FBTyxhQUFhLElBQUk7R0FDbEQsTUFBTSxXQUFXLFNBQVMsTUFBTTtHQUNoQyxNQUFNLEtBQUssU0FBUyxjQUFjLFdBQVcsS0FBSyxZQUFZLE9BQU8sYUFBYSxLQUFLLEtBQUssWUFBWSxNQUFNLE9BQU8sWUFBWSxHQUFHO0dBQ3BJLElBQUksU0FBUyxZQUFZLE9BQU87R0FDaEMsTUFBTSxXQUFXLE9BQU8sYUFBYSxNQUFNLFNBQVMsS0FBSyxJQUFJLEtBQUssWUFBWSxXQUFXLFVBQVUsS0FBSyxZQUFZLFdBQVcsTUFBTSxJQUFJO0dBQ3pJLEtBQUssUUFBUTtHQUNiLEtBQUssTUFBTTtHQUNYLEtBQUssWUFBWTtHQUNqQixLQUFLLE1BQU0sY0FBYyxRQUFRO0VBQ2xDO0VBQ0EsS0FBSyxlQUFlLGFBQWE7R0FDaEMsT0FBTyxLQUFLLGlCQUFpQixRQUFRO0VBQ3RDO0VBQ0EsS0FBSyxvQkFBb0IsYUFBYTtHQUNyQyxJQUFJLE1BQU0sUUFBUSxRQUFRLEdBQUcsS0FBSyxXQUFXO0dBQzdDLElBQUksT0FBTyxhQUFhLFlBQVksYUFBYSxNQUFNLEtBQUssV0FBVyxPQUFPLE9BQU8sUUFBUTtHQUM3RixPQUFPO0VBQ1I7RUFDQSxLQUFLLHNCQUFzQjtHQUMxQixPQUFPO0VBQ1I7RUFDQSxLQUFLLGdCQUFnQixZQUFZO0dBQ2hDLE9BQU8sT0FBTyxLQUFLLFNBQVMsT0FBTztHQUNuQyxPQUFPO0VBQ1I7RUFDQSxLQUFLLFVBQVUsWUFBWTtHQUMxQixPQUFPLE9BQU8sS0FBSyxTQUFTLE9BQU87R0FDbkMsT0FBTztFQUNSO0VBQ0EsS0FBSyxRQUFRLFdBQVc7R0FDdkIsS0FBSyxTQUFTO0dBQ2QsT0FBTztFQUNSO0VBQ0EsS0FBSyxZQUFZLFNBQVMsU0FBUztHQUNsQyxNQUFNLEtBQUs7R0FDWCxHQUFHO0VBQ0osQ0FBQztFQUNELEtBQUssVUFBVSxXQUFXLENBQUM7RUFDM0IsS0FBSyxTQUFTLENBQUMsU0FBUztFQUN4QixJQUFJLFNBQVMsTUFBTSxTQUFTLE1BQU0sTUFBTSxJQUFJLE1BQU0scURBQXFEO0NBQ3hHO0FBQ0Q7QUFDQSxJQUFJLGVBQWUsTUFBTTtDQUN4QixZQUFZLEVBQUUsTUFBTTtFQUNuQixLQUFLLFlBQVksU0FBUztHQUN6QixPQUFPLFNBQVM7SUFDZixTQUFTLEtBQUs7SUFDZCxHQUFHO0dBQ0osQ0FBQztFQUNGO0VBQ0EsS0FBSyxZQUFZLFNBQVMsU0FBUztHQUNsQyxNQUFNLEtBQUs7R0FDWCxHQUFHO0VBQ0osQ0FBQztFQUNELEtBQUssS0FBSztDQUNYO0FBQ0Q7QUFDQSxJQUFJLGdCQUFnQixjQUFjLFVBQVU7Q0FDM0MsWUFBWSxTQUFTO0VBQ3BCLE1BQU0sT0FBTztDQUNkO0FBQ0Q7OztBQzVGQSxJQUFNLHNCQUFzQixZQUFZO0NBQ3ZDLE9BQU87RUFDTix1QkFBdUIsUUFBUTtFQUMvQixZQUFZLFFBQVE7Q0FDckI7QUFDRDs7Ozs7Ozs7Ozs7OztBQ01BLFNBQVMsbUJBQW1CLE1BQU07Q0FDakMsUUFBUSxFQUFFLFFBQVEsV0FBVztFQUM1QixNQUFNLEVBQUUsUUFBUSxjQUFjLFNBQVMsS0FBSyxRQUFRLElBQUk7RUFDeEQsSUFBSSxTQUFTLE1BQU07R0FDbEIsTUFBTSxPQUFPO0lBQ1osR0FBRztJQUNILEdBQUc7R0FDSjtHQUNBLE1BQU0sVUFBVSxLQUFLO0dBQ3JCLE1BQU0sV0FBVyxLQUFLO0dBQ3RCLEtBQUssTUFBTSxPQUFPLFNBQVMsS0FBSyxLQUFLLENBQUMsR0FBRyxJQUFJLFlBQVksT0FBTyxLQUFLLFVBQVUsR0FBRyxLQUFLLFVBQVUsT0FBTyxNQUFNLFFBQVEsSUFBSSxHQUFHLENBQUMsR0FBRyxPQUFPLEtBQUs7R0FDN0ksS0FBSyxNQUFNLE9BQU8sS0FBSyxjQUFjLENBQUMsR0FBRyxPQUFPLEtBQUs7R0FDckQsS0FBSyxNQUFNLE9BQU8sS0FBSyxXQUFXLEtBQUssS0FBSyxDQUFDLEdBQUcsSUFBSSxPQUFPLFVBQVUsQ0FBQyxLQUFLLFlBQVksSUFBSSxHQUFHLEtBQUssRUFBRSxLQUFLLFNBQVMsSUFBSSxHQUFHLE1BQU0sWUFBWSxPQUFPLEtBQUssVUFBVSxHQUFHLEtBQUssVUFBVSxPQUFPLE1BQU0sS0FBSyxRQUFRLElBQUksR0FBRyxDQUFDLEtBQUssS0FBSyxPQUFPLE9BQU87R0FDOU8sT0FBTztFQUNSO0VBQ0EsTUFBTSxPQUFPLEVBQUUsR0FBRyxhQUFhO0VBQy9CLE1BQU0sV0FBVyxLQUFLO0VBQ3RCLEtBQUssTUFBTSxPQUFPLE1BQU07R0FDdkIsTUFBTSxZQUFZO0dBQ2xCLElBQUksRUFBRSxLQUFLLFlBQVksSUFBSSxTQUFTLEtBQUssS0FBSyxTQUFTLElBQUksU0FBUyxNQUFNLFlBQVksT0FBTyxLQUFLLFVBQVUsU0FBUyxLQUFLLFVBQVUsT0FBTyxNQUFNLEtBQUssUUFBUSxJQUFJLFNBQVMsQ0FBQyxRQUFRLEVBQUUsT0FBTyxTQUFTLE9BQU8sVUFBVSxLQUFLLFdBQVcsSUFBSSxTQUFTLEtBQUssVUFBVSxLQUFLLE1BQU0sS0FBSyxVQUFVLElBQUksU0FBUyxDQUFDLElBQUksS0FBSyxPQUFPLE9BQU87RUFDblU7RUFDQSxPQUFPO0NBQ1I7QUFDRDs7Ozs7Ozs7Ozs7QUFXQSxTQUFTLGtCQUFrQixPQUFPO0NBQ2pDLFNBQVMsRUFBRSxRQUFRLE1BQU0sV0FBVztFQUNuQyxJQUFJLFVBQVUsTUFBTTtHQUNuQixPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsU0FBUyxRQUFRO0lBQ3BDLElBQUksTUFBTSxDQUFDLEtBQUssK0JBQStCLElBQUksSUFBSSxFQUFBLENBQUcsSUFBSSxHQUFHO0dBQ2xFLENBQUM7R0FDRCxPQUFPLENBQUM7RUFDVDtFQUNBLE1BQU0sU0FBUyxFQUFFLEdBQUcsS0FBSyxNQUFNLEVBQUU7RUFDakMsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHLE1BQU0sU0FBUyxRQUFRO0dBQ2hELE9BQU8sT0FBTztHQUNkLElBQUksTUFBTSxDQUFDLEtBQUssK0JBQStCLElBQUksSUFBSSxFQUFBLENBQUcsSUFBSSxHQUFHO0VBQ2xFLENBQUM7T0FDSSxPQUFPLFFBQVEsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssV0FBVztHQUNwRCxJQUFJLFVBQVUsT0FBTyxNQUFNLEtBQUssR0FBRztJQUNsQyxPQUFPLE9BQU87SUFDZCxJQUFJLE1BQU0sQ0FBQyxLQUFLLDRCQUE0QixJQUFJLElBQUksRUFBQSxDQUFHLElBQUksS0FBSyxLQUFLO0dBQ3RFO0VBQ0QsQ0FBQztFQUNELE9BQU87Q0FDUjtBQUNEOzs7Ozs7O0FDOURBLFNBQVMsMkJBQTJCLE1BQU07Q0FFeEMsSUFBSSxDQUFDLEtBQUssT0FBTyw4Q0FBOEMsS0FBSyxLQUFLLEdBQUcsR0FBRyxNQUFNLElBQUksTUFBTSxtQ0FBbUMsS0FBSyxVQUFVLEtBQUssR0FBRyxFQUFFLHNLQUFzSztDQUVsVSxPQUFPO0FBQ1I7Ozs7O0FDSkEsU0FBUyxXQUFXLEVBQUUsU0FBUyxZQUFZO0NBQzFDLElBQUksVUFBVSxPQUFPLFNBQVMsUUFBUTtDQUN0QyxNQUFNLFVBQVUsTUFBTSxRQUFRO0NBQzlCLElBQUksUUFBUSxxQkFBcUIsQ0FBQyxXQUFXLFdBQVcsTUFBTTtDQUM5RCxJQUFJLFFBQVEscUJBQXFCLENBQUMsV0FBVyxTQUFTLE1BQU0sUUFBUSxxQkFBcUIsQ0FBQztDQUMxRixPQUFPLFFBQVEscUJBQXFCLENBQUM7QUFDdEM7Ozs7O0FBS0EsU0FBUyxNQUFNLE9BQU87Q0FDckIsTUFBTSxRQUF3QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxZQUFZLEVBQUUsR0FBRyxNQUFNLENBQUM7Q0FDMUQsSUFBSSxNQUFNLFVBQVUsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUEsYUFBWSxVQUFVO0VBQ2hFLFVBQVUsTUFBTTtFQUNoQixVQUFVO0NBQ1gsQ0FBQztDQUNELE9BQU87QUFDUjtBQUNBLFNBQVMsV0FBVyxPQUFPO0NBQzFCLE1BQU0sT0FBTyxXQUFXLEtBQUs7Q0FDN0IsT0FBTyxNQUFNLFNBQVMsSUFBSTtBQUMzQjs7O0FDeEJBLElBQUksMkJBQUEsYUFBMkUsY0FBYyxLQUFLLENBQUM7QUFDbkcsU0FBUywrQkFBK0IsU0FBUyxXQUFXO0NBQzNELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLHlCQUF5QixVQUFVO0VBQzdELE9BQU87RUFDUCxVQUFVO0NBQ1gsQ0FBQztBQUNGOzs7QUNMQSxJQUFJLGdCQUFnQixjQUFBLGFBQXNCLFVBQVU7Q0FDbkQsWUFBWSxHQUFHLE9BQU87RUFDckIsTUFBTSxHQUFHLEtBQUs7RUFDZCxLQUFLLFFBQVEsRUFBRSxPQUFPLEVBQUU7RUFDeEIsS0FBSyxjQUFjO0dBQ2xCLEtBQUssU0FBUyxFQUFFLE9BQU8sRUFBRSxDQUFDO0VBQzNCO0NBQ0Q7Q0FDQSxPQUFPLHlCQUF5QixPQUFPLE9BQU87RUFDN0MsTUFBTSxXQUFXLE1BQU0sWUFBWTtFQUNuQyxJQUFJLE1BQU0sU0FBUyxNQUFNLGFBQWEsVUFBVSxPQUFPO0dBQ3REO0dBQ0EsT0FBTztFQUNSO0VBQ0EsT0FBTyxFQUFFLFNBQVM7Q0FDbkI7Q0FDQSxPQUFPLHlCQUF5QixPQUFPO0VBQ3RDLE9BQU8sRUFBRSxPQUFPLENBQUMsS0FBSyxFQUFFO0NBQ3pCO0NBQ0Esa0JBQWtCLE9BQU8sV0FBVztFQUNuQyxLQUFLLE1BQU0sVUFBVSxPQUFPLFNBQVM7Q0FDdEM7Q0FDQSxTQUFTO0VBQ1IsTUFBTSxRQUFRLEtBQUssTUFBTTtFQUN6QixJQUFJLE9BS0gsT0FBK0MsK0JBSnpDLGFBQWtCLGNBQWMsS0FBSyxNQUFNLGtCQUFrQixnQkFBZ0I7R0FDbEYsT0FBTyxNQUFNO0dBQ2IsT0FBTyxLQUFLO0VBQ2IsQ0FDOEUsR0FBUyxnQkFBZ0I7RUFFeEcsT0FBTyxLQUFLLE1BQU07Q0FDbkI7QUFDRDtBQUNBLFNBQVMsZUFBZSxFQUFFLFNBQVM7Q0FDbEMsTUFBTSxDQUFDLE1BQU0sV0FBQSxhQUFtQixTQUFTLElBQXFDO0NBQzlFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFLLE9BQU87RUFDbEMsT0FBTztHQUNOLFNBQVM7R0FDVCxVQUFVO0VBQ1g7RUFDQSxVQUFVO0dBQ08saUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUssT0FBTztJQUMzQixPQUFPO0tBQ04sU0FBUztLQUNULFlBQVk7S0FDWixLQUFLO0lBQ047SUFDQSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVU7S0FDeEMsT0FBTyxFQUFFLFVBQVUsT0FBTztLQUMxQixVQUFVO0lBQ1gsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0tBQ2pDLE9BQU87TUFDTixZQUFZO01BQ1osVUFBVTtNQUNWLFFBQVE7TUFDUixTQUFTO01BQ1QsWUFBWTtNQUNaLGNBQWM7S0FDZjtLQUNBLGVBQWUsU0FBUyxNQUFNLENBQUMsQ0FBQztLQUNoQyxVQUFVLE9BQU8sZUFBZTtJQUNqQyxDQUFDLENBQUM7R0FDSCxDQUFDO0dBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLFNBQVMsRUFBRSxDQUFDO0dBQzFELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE9BQU8sRUFBRSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxPQUFPO0lBQ3hFLE9BQU87S0FDTixVQUFVO0tBQ1YsUUFBUTtLQUNSLGNBQWM7S0FDZCxTQUFTO0tBQ1QsT0FBTztLQUNQLFVBQVU7SUFDWDtJQUNBLFVBQVUsT0FBTyxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxRQUFRLEVBQUUsVUFBVSxNQUFNLFFBQVEsQ0FBQyxJQUFJO0dBQ3ZGLENBQUMsRUFBRSxDQUFDLElBQUk7RUFDVDtDQUNELENBQUM7QUFDRjs7O0FDL0VBLElBQUksb0JBQW9CO0FBQ3hCLElBQUksMEJBQTBCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQjlCLFNBQVMsV0FBVyxFQUFFLFVBQVUsV0FBVyxRQUFRO0NBQ2xELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFBLGFBQVUsVUFBVSxFQUFFLFVBQVUsWUFBWSxJQUFJLFdBQVcsU0FBUyxDQUFDO0FBQzdGOztBQUVBLFNBQVMsWUFBWSxVQUFVLE1BQU07Q0FDcEMsT0FBQSxhQUFhLHFCQUFxQixXQUFXLGFBQWEsVUFBVSxvQkFBb0IsV0FBVztBQUNwRztBQUNBLFNBQVMsWUFBWTtDQUNwQixhQUFhLENBQUM7QUFDZjs7O0FDN0JBLElBQUksZ0JBQUEsYUFBd0IsY0FBYyxJQUFJOzs7Ozs7Ozs7Ozs7O0FDVzlDLFNBQVMsVUFBVSxNQUFNO0NBQ3hCLE1BQU0sUUFBQSxhQUFnQixXQUFXLGFBQWE7Q0FDOUMsSUFBSSxDQUFDLE9BQU8sa0JBQWtCLElBQUk7Q0FDbEMsT0FBTztBQUNSO0FBQ0EsU0FBUyxrQkFBa0IsTUFBTTtDQUNoQyxJQUE4QyxNQUFNLFFBQVEsTUFBTyxRQUFRLEtBQUssc0VBQXNFO0FBQ3ZKOzs7QUNqQkEsU0FBUyxnQkFBZ0IsUUFBUSxTQUFTO0NBQ3pDLE1BQU0sUUFBUSxPQUFPLE9BQU87Q0FDNUIsTUFBTSw0QkFBNEIsSUFBSSxJQUFJO0NBQzFDLElBQUk7Q0FDSixJQUFJO0NBQ0osTUFBTSxVQUFVLGFBQWE7RUFDNUIsSUFBSSxDQUFDLGtCQUFrQixRQUFRLFNBQVMsUUFBUSxHQUFHO0dBQ2xELFNBQVM7R0FDVCxVQUFVLFNBQVMsYUFBYSxTQUFTLENBQUM7RUFDM0M7Q0FDRDtDQUNBLE9BQU8sT0FBTyxVQUFVLE1BQU0sSUFBSSxJQUFJLGFBQWE7RUFDbEQsSUFBSSxDQUFDLFVBQVUsTUFBTTtHQUNwQixTQUFTLE1BQU0sSUFBSTtHQUNuQixjQUFjLE1BQU0sVUFBVSxNQUFNLENBQUMsQ0FBQztFQUN2QztFQUNBLFVBQVUsSUFBSSxRQUFRO0VBQ3RCLGFBQWE7R0FDWixVQUFVLE9BQU8sUUFBUTtHQUN6QixJQUFJLENBQUMsVUFBVSxNQUFNO0lBQ3BCLFlBQVk7SUFDWixTQUFTLEtBQUs7R0FDZjtFQUNEO0NBQ0QsQ0FBQztBQUNGO0FBQ0EsSUFBSSxlQUFBLGFBQXVCLGNBQWMsS0FBSyxDQUFDO0FBQy9DLElBQUksb0JBQUEsYUFBNEIsY0FBYyxLQUFLLENBQUM7Ozs7QUN0QnBELFNBQVMscUJBQXFCLEVBQUUsUUFBUSxRQUFRLGFBQWE7Q0FDNUQsT0FBTztFQUNOO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRDtDQUNBLFNBQVMsS0FBSyxLQUFLLEtBQUssU0FBUztFQUNoQyxNQUFNLFVBQVUsSUFBSTtFQUNwQixJQUFJLFlBQVksS0FBSyxLQUFLLFFBQVEsUUFBUSxLQUFLO0VBQy9DLE1BQU0sVUFBVSxZQUFZLEtBQUssSUFBSSxRQUFRLFVBQVUsSUFBSTtFQUMzRCxJQUFJLFlBQVksS0FBSyxLQUFLLFFBQVEsUUFBUSxLQUFLO0dBQzlDLFFBQVEsVUFBVTtHQUNsQixJQUFJLFdBQVc7R0FDZjtFQUNEO0VBQ0EsTUFBTSxVQUFVLElBQUk7RUFDcEIsSUFBSSxZQUFZLEtBQUssS0FBSyxRQUFRLFlBQVksV0FBVyxRQUFRLFFBQVEsS0FBSztFQUM5RSxNQUFNLFVBQVUsSUFBSSxXQUFXLElBQUksV0FBVztHQUM3QztHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQSxTQUFTLEtBQUs7RUFDZjtFQUNBLElBQUksWUFBWSxLQUFLLEdBQUcsUUFBUSxVQUFVO0VBQzFDLElBQUksWUFBWSxLQUFLLEdBQUcsUUFBUSxVQUFVO09BQ3JDLElBQUksT0FBTztFQUNoQixJQUFJLFlBQVksS0FBSyxHQUFHLFFBQVEsVUFBVTtPQUNyQyxJQUFJLE9BQU87Q0FDakI7Q0FDQSxTQUFTLE9BQU8sTUFBTSxNQUFNLEtBQUssS0FBSztFQUNyQyxNQUFNLE1BQU0sS0FBSztFQUNqQixNQUFNLFVBQVUsS0FBSztFQUNyQixNQUFNLFVBQVUsS0FBSztFQUNyQixNQUFNLFVBQVUsS0FBSztFQUNyQixNQUFNLFVBQVUsS0FBSztFQUNyQixJQUFJLFlBQVksS0FBSyxHQUFHLFFBQVEsVUFBVTtPQUNyQyxJQUFJLFdBQVc7RUFDcEIsSUFBSSxZQUFZLEtBQUssR0FBRyxRQUFRLFVBQVU7T0FDckMsSUFBSSxPQUFPO0VBQ2hCLElBQUksWUFBWSxLQUFLLEdBQUcsUUFBUSxVQUFVO09BQ3JDLElBQUksV0FBVztFQUNwQixJQUFJLFlBQVksS0FBSyxHQUFHLFFBQVEsVUFBVTtPQUNyQyxLQUFLLElBQUksT0FBTyxhQUFhLEtBQUssR0FBRyxVQUFVLEdBQUc7RUFDdkQsT0FBTztDQUNSO0NBQ0EsU0FBUyxVQUFVLE1BQU07RUFDeEIsSUFBSSxPQUFPLEtBQUs7RUFDaEIsSUFBSTtFQUNKLEtBQUssR0FBRztHQUNQLE1BQU0sTUFBTSxLQUFLO0dBQ2pCLElBQUksUUFBUSxJQUFJO0dBQ2hCLElBQUksRUFBRSxRQUFRLEtBQUssSUFBSSxRQUFRLFFBQVE7UUFDbEMsSUFBSSxFQUFFLFFBQVMsS0FBUyxRQUFRO1FBQ2hDLElBQUksRUFBRSxRQUFRLElBQUksSUFBSSxRQUFRLFFBQVEsS0FBSztRQUMzQyxJQUFJLEVBQUUsUUFBUyxPQUFhLFlBQVksTUFBTSxHQUFHLEdBQUc7SUFDeEQsSUFBSSxRQUFRLFFBQVM7SUFDckIsU0FBUztHQUNWLE9BQU8sUUFBUTtHQUNmLElBQUksUUFBUSxHQUFHLE9BQU8sR0FBRztHQUN6QixJQUFJLFFBQVEsR0FBRztJQUNkLE1BQU0sVUFBVSxJQUFJO0lBQ3BCLElBQUksWUFBWSxLQUFLLEdBQUc7S0FDdkIsTUFBTSxXQUFXLE9BQU8sUUFBQSxDQUFTO0tBQ2pDLElBQUksWUFBWSxLQUFLLEdBQUc7TUFDdkIsUUFBUTtPQUNQLE9BQU87T0FDUCxNQUFNO01BQ1A7TUFDQSxPQUFPO0tBQ1I7S0FDQTtJQUNEO0dBQ0Q7R0FDQSxLQUFLLE9BQU8sVUFBVSxLQUFLLEdBQUc7SUFDN0IsT0FBTyxLQUFLO0lBQ1o7R0FDRDtHQUNBLE9BQU8sVUFBVSxLQUFLLEdBQUc7SUFDeEIsT0FBTyxNQUFNO0lBQ2IsUUFBUSxNQUFNO0lBQ2QsSUFBSSxTQUFTLEtBQUssR0FBRztLQUNwQixPQUFPLEtBQUs7S0FDWixTQUFTO0lBQ1Y7R0FDRDtHQUNBO0VBQ0QsU0FBUztDQUNWO0NBQ0EsU0FBUyxXQUFXLE1BQU0sS0FBSztFQUM5QixJQUFJO0VBQ0osSUFBSSxhQUFhO0VBQ2pCLElBQUksUUFBUTtFQUNaLEtBQUssR0FBRztHQUNQLE1BQU0sTUFBTSxLQUFLO0dBQ2pCLE1BQU0sUUFBUSxJQUFJO0dBQ2xCLElBQUksSUFBSSxRQUFRLElBQUksUUFBUTtRQUN2QixLQUFLLFFBQVMsUUFBYyxJQUM1QjtRQUFBLE9BQU8sR0FBRyxHQUFHO0tBQ2hCLE1BQU0sT0FBTyxJQUFJO0tBQ2pCLElBQUksS0FBSyxZQUFZLEtBQUssR0FBRyxpQkFBaUIsSUFBSTtLQUNsRCxRQUFRO0lBQ1Q7VUFDTSxLQUFLLFFBQVMsUUFBYyxJQUFTO0lBQzNDLElBQUksS0FBSyxZQUFZLEtBQUssS0FBSyxLQUFLLFlBQVksS0FBSyxHQUFHLFFBQVE7S0FDL0QsT0FBTztLQUNQLE1BQU07SUFDUDtJQUNBLE9BQU8sSUFBSTtJQUNYLE1BQU07SUFDTixFQUFFO0lBQ0Y7R0FDRDtHQUNBLElBQUksQ0FBQyxPQUFPO0lBQ1gsTUFBTSxVQUFVLEtBQUs7SUFDckIsSUFBSSxZQUFZLEtBQUssR0FBRztLQUN2QixPQUFPO0tBQ1A7SUFDRDtHQUNEO0dBQ0EsT0FBTyxjQUFjO0lBQ3BCLE1BQU0sV0FBVyxJQUFJO0lBQ3JCLE1BQU0sa0JBQWtCLFNBQVMsWUFBWSxLQUFLO0lBQ2xELElBQUksaUJBQWlCO0tBQ3BCLE9BQU8sTUFBTTtLQUNiLFFBQVEsTUFBTTtJQUNmLE9BQU8sT0FBTztJQUNkLElBQUksT0FBTztLQUNWLElBQUksT0FBTyxHQUFHLEdBQUc7TUFDaEIsSUFBSSxpQkFBaUIsaUJBQWlCLFFBQVE7TUFDOUMsTUFBTSxLQUFLO01BQ1g7S0FDRDtLQUNBLFFBQVE7SUFDVCxPQUFPLElBQUksU0FBUztJQUNwQixNQUFNLEtBQUs7SUFDWCxNQUFNLFVBQVUsS0FBSztJQUNyQixJQUFJLFlBQVksS0FBSyxHQUFHO0tBQ3ZCLE9BQU87S0FDUCxTQUFTO0lBQ1Y7R0FDRDtHQUNBLE9BQU87RUFDUixTQUFTO0NBQ1Y7Q0FDQSxTQUFTLGlCQUFpQixNQUFNO0VBQy9CLEdBQUc7R0FDRixNQUFNLE1BQU0sS0FBSztHQUNqQixNQUFNLFFBQVEsSUFBSTtHQUNsQixLQUFLLFFBQVMsUUFBYyxJQUFJO0lBQy9CLElBQUksUUFBUSxRQUFRO0lBQ3BCLEtBQUssUUFBUyxPQUFZLEdBQUcsT0FBTyxHQUFHO0dBQ3hDO0VBQ0QsVUFBVSxPQUFPLEtBQUssYUFBYSxLQUFLO0NBQ3pDO0NBQ0EsU0FBUyxZQUFZLFdBQVcsS0FBSztFQUNwQyxJQUFJLE9BQU8sSUFBSTtFQUNmLE9BQU8sU0FBUyxLQUFLLEdBQUc7R0FDdkIsSUFBSSxTQUFTLFdBQVcsT0FBTztHQUMvQixPQUFPLEtBQUs7RUFDYjtFQUNBLE9BQU87Q0FDUjtBQUNEOzs7QUM3S0EsU0FBUyxXQUFXLGFBQWEsY0FBYyxtQkFBbUI7Q0FDakUsTUFBTSxhQUFhLE9BQU8sZ0JBQWdCO0NBQzFDLE1BQU0sT0FBTyxhQUFhLGNBQWMsS0FBSztDQUM3QyxPQUFPO0VBQ04sT0FBTyxhQUFhLFlBQVksT0FBTyxZQUFBLEVBQWMsS0FBSyxJQUFJO0VBQzlELFFBQVEsYUFBYSxZQUFZLFFBQVEsYUFBQSxFQUFlLEtBQUssSUFBSTtFQUNqRSxXQUFXLGFBQWEsWUFBWSxXQUFXLGtCQUFBLEVBQW9CLEtBQUssSUFBSTtDQUM3RTtBQUNEO0FBQ0EsSUFBTSxnQkFBZ0IsQ0FBQztBQUN2QixJQUFJLFFBQVE7QUFDWixJQUFNLEVBQUUsTUFBTSxRQUFRLFdBQVcsWUFBWSxxQkFBcUMscUNBQXFCO0NBQ3RHLE9BQU8sTUFBTTtFQUNaLE9BQU8sS0FBSyxRQUFRO0NBQ3JCO0NBQ0EsT0FBTyxRQUFRO0VBQ2QsY0FBYyx5QkFBeUI7RUFDdkMsT0FBTyxTQUFTO0NBQ2pCO0NBQ0EsVUFBVSxNQUFNO0VBQ2YsSUFBSSxLQUFLLGFBQWEsS0FBSyxHQUFHO0dBQzdCLEtBQUssV0FBVyxLQUFLO0dBQ3JCLEtBQUssUUFBUTtHQUNiLFVBQVUsSUFBSTtFQUNmO0NBQ0Q7QUFDRCxDQUFDO0FBQ0QsSUFBSSxjQUFjO0FBQ2xCLElBQUksc0JBQXNCO0FBQzFCLElBQUk7QUFDSixJQUFJLGFBQWE7QUFDakIsU0FBUyxNQUFNLElBQUk7Q0FDbEIsSUFBSTtFQUNILEVBQUU7RUFDRixHQUFHO0NBQ0osVUFBVTtFQUNULElBQUksQ0FBQyxFQUFFLFlBQVksTUFBTTtDQUMxQjtBQUNEO0FBQ0EsU0FBUyxVQUFVLEtBQUs7Q0FDdkIsTUFBTSxXQUFXLElBQUk7Q0FDckIsSUFBSSxNQUFNLGFBQWEsS0FBSyxJQUFJLFNBQVMsVUFBVSxJQUFJO0NBQ3ZELE9BQU8sUUFBUSxLQUFLLEdBQUcsTUFBTSxPQUFPLEtBQUssR0FBRztBQUM3QztBQUNBLFNBQVMsUUFBUTtDQUNoQixJQUFJLGFBQWEsR0FBRztDQUNwQixPQUFPLGNBQWMscUJBQXFCO0VBQ3pDLE1BQU0sU0FBUyxjQUFjO0VBQzdCLGNBQWMsaUJBQWlCLEtBQUs7RUFDcEMsT0FBTyxPQUFPO0NBQ2Y7Q0FDQSxjQUFjO0NBQ2Qsc0JBQXNCO0FBQ3ZCO0FBb0NBLFNBQVMsV0FBVyxXQUFXLFNBQVM7Q0FDdkMsTUFBTSxhQUFhLE9BQU8sY0FBYztDQUN4QyxNQUFNLFNBQVM7Q0FDZixNQUFNLE9BQU87RUFDWixXQUFXLGFBQWEsS0FBSyxJQUFJO0VBQ2pDLE1BQU0sS0FBSztFQUNYLFVBQVUsS0FBSztFQUNmLE1BQU0sS0FBSztFQUNYLFVBQVUsS0FBSztFQUNmLE9BQU8sYUFBYSxJQUFJO0VBQ3hCLE1BQU07R0FDTCxJQUFJLGNBQWMsS0FBSyxHQUFHLEtBQUssTUFBTSxXQUFXLEtBQUs7R0FDckQsT0FBTyxLQUFLO0VBQ2I7RUFDQSxVQUFVLGNBQWM7R0FDdkIsTUFBTSxNQUFNLFdBQVcsWUFBWTtHQUNuQyxNQUFNLFdBQVcsRUFBRSxTQUFTLE1BQU07R0FDbEMsTUFBTSxJQUFJLGFBQWE7SUFDdEIsS0FBSyxJQUFJO0lBQ1QsSUFBSSxDQUFDLFNBQVMsU0FBUyxTQUFTLFVBQVU7U0FDckM7S0FDSixZQUFZLEtBQUs7S0FDakIsSUFBSSxPQUFPLEtBQUssU0FBUztJQUMxQjtHQUNELENBQUM7R0FDRCxPQUFPLEVBQUUsbUJBQW1CO0lBQzNCLEVBQUUsS0FBSztHQUNSLEVBQUU7RUFDSDtFQUNBLFFBQVEsVUFBVTtHQUNqQixNQUFNLFVBQVU7R0FDaEIsTUFBTSxVQUFVLFNBQVMsV0FBVyxPQUFPO0dBQzNDLElBQUksWUFBWTtJQUNmLFlBQVk7SUFDWixFQUFFO0lBQ0YsS0FBSyxXQUFXLEtBQUs7R0FDdEIsT0FBTyxJQUFJLGFBQWEsS0FBSyxHQUFHLE9BQU87R0FDdkMsSUFBSSxZQUFZLEtBQUssUUFBUTtHQUM3QixJQUFJO0lBQ0gsTUFBTSxXQUFXLEtBQUs7SUFDdEIsTUFBTSxXQUFXLE9BQU8sYUFBYSxhQUFhLFNBQVMsUUFBUSxJQUFJLGFBQWEsS0FBSyxLQUFLLGFBQWEsT0FBTyxRQUFRLElBQUk7SUFDOUgsSUFBSSxhQUFhLEtBQUssS0FBSyxDQUFDLFFBQVEsVUFBVSxRQUFRLEdBQUc7S0FDeEQsS0FBSyxZQUFZO0tBQ2pCLE9BQU87SUFDUjtJQUNBLE9BQU87R0FDUixVQUFVO0lBQ1QsWUFBWTtJQUNaLElBQUksWUFBWSxLQUFLLFNBQVM7SUFDOUIsVUFBVSxJQUFJO0dBQ2Y7RUFDRDtDQUNEO0NBQ0EsSUFBSSxZQUFZO0VBQ2YsS0FBSyxRQUFRO0VBQ2IsS0FBSyxNQUFNLFdBQVc7R0FDckIsTUFBTSxRQUFRLEtBQUs7R0FDbkIsSUFBSSxRQUFRLE1BQU0sUUFBUSxNQUFNLFdBQVcsS0FBSyxNQUFNLElBQUksR0FDckQ7UUFBQSxLQUFLLFFBQVEsR0FBRztLQUNuQixNQUFNLE9BQU8sS0FBSztLQUNsQixJQUFJLFNBQVMsS0FBSyxHQUFHLGlCQUFpQixJQUFJO0lBQzNDO1VBQ00sSUFBSSxRQUFRLElBQUksS0FBSyxRQUFRLFFBQVE7R0FDNUMsSUFBSSxjQUFjLEtBQUssR0FBRyxLQUFLLE1BQU0sV0FBVyxLQUFLO0dBQ3JELE9BQU8sS0FBSztFQUNiO0NBQ0QsT0FBTyxLQUFLLE1BQU0sU0FBUyxXQUFXO0VBQ3JDLElBQUksS0FBSyxRQUFRLFNBQVMsR0FBRztHQUM1QixNQUFNLE9BQU8sS0FBSztHQUNsQixJQUFJLFNBQVMsS0FBSyxHQUFHO0lBQ3BCLFVBQVUsSUFBSTtJQUNkLGlCQUFpQixJQUFJO0lBQ3JCLE1BQU07R0FDUDtFQUNEO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLE9BQU8sSUFBSTtDQUNuQixNQUFNLFlBQVk7RUFDakIsTUFBTSxVQUFVO0VBQ2hCLFlBQVk7RUFDWixFQUFFO0VBQ0YsVUFBVSxXQUFXLEtBQUs7RUFDMUIsVUFBVSxRQUFRO0VBQ2xCLElBQUk7R0FDSCxPQUFPLEdBQUc7RUFDWCxVQUFVO0dBQ1QsWUFBWTtHQUNaLFVBQVUsU0FBUztHQUNuQixVQUFVLFNBQVM7RUFDcEI7Q0FDRDtDQUNBLE1BQU0sWUFBWTtFQUNqQixNQUFNLEtBQUs7RUFDWCxVQUFVLEtBQUs7RUFDZixNQUFNLEtBQUs7RUFDWCxVQUFVLEtBQUs7RUFDZixPQUFPO0VBQ1AsU0FBUztHQUNSLE1BQU0sUUFBUSxLQUFLO0dBQ25CLElBQUksUUFBUSxNQUFNLFFBQVEsTUFBTSxXQUFXLEtBQUssTUFBTSxJQUFJLEdBQUcsSUFBSTtRQUM1RCxLQUFLLFFBQVE7RUFDbkI7RUFDQSxPQUFPO0dBQ04sS0FBSyxRQUFRO0dBQ2IsS0FBSyxXQUFXLEtBQUs7R0FDckIsVUFBVSxJQUFJO0VBQ2Y7Q0FDRDtDQUNBLElBQUk7Q0FDSixPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7Q0NqTUEsQ0FDRyxXQUFZO0VBQ1gsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixPQUFRLE1BQU0sTUFBTSxNQUFNLEtBQUssSUFBSSxNQUFNLElBQUksTUFBUSxNQUFNLEtBQUssTUFBTTtFQUN4RTtFQUNBLFNBQVMsdUJBQXVCLFdBQVcsYUFBYTtHQUN0RCxxQkFDRSxLQUFLLE1BQU0sTUFBTSxvQkFDZixvQkFBb0IsQ0FBQyxHQUN2QixRQUFRLE1BQ04sZ01BQ0Y7R0FDRixJQUFJLFFBQVEsWUFBWTtHQUN4QixJQUFJLENBQUMsNEJBQTRCO0lBQy9CLElBQUksY0FBYyxZQUFZO0lBQzlCLFNBQVMsT0FBTyxXQUFXLE1BQ3hCLFFBQVEsTUFDUCxzRUFDRixHQUNDLDZCQUE2QixDQUFDO0dBQ25DO0dBQ0EsY0FBYyxTQUFTLEVBQ3JCLE1BQU07SUFBUztJQUFvQjtHQUFZLEVBQ2pELENBQUM7R0FDRCxJQUFJLE9BQU8sWUFBWSxFQUFFLENBQUMsTUFDeEIsY0FBYyxZQUFZO0dBQzVCLGdCQUNFLFdBQVk7SUFDVixLQUFLLFFBQVE7SUFDYixLQUFLLGNBQWM7SUFDbkIsdUJBQXVCLElBQUksS0FBSyxZQUFZLEVBQVEsS0FBSyxDQUFDO0dBQzVELEdBQ0E7SUFBQztJQUFXO0lBQU87R0FBVyxDQUNoQztHQUNBLFVBQ0UsV0FBWTtJQUNWLHVCQUF1QixJQUFJLEtBQUssWUFBWSxFQUFRLEtBQUssQ0FBQztJQUMxRCxPQUFPLFVBQVUsV0FBWTtLQUMzQix1QkFBdUIsSUFBSSxLQUFLLFlBQVksRUFBUSxLQUFLLENBQUM7SUFDNUQsQ0FBQztHQUNILEdBQ0EsQ0FBQyxTQUFTLENBQ1o7R0FDQSxjQUFjLEtBQUs7R0FDbkIsT0FBTztFQUNUO0VBQ0EsU0FBUyx1QkFBdUIsTUFBTTtHQUNwQyxJQUFJLG9CQUFvQixLQUFLO0dBQzdCLE9BQU8sS0FBSztHQUNaLElBQUk7SUFDRixJQUFJLFlBQVksa0JBQWtCO0lBQ2xDLE9BQU8sQ0FBQyxTQUFTLE1BQU0sU0FBUztHQUNsQyxTQUFTLE9BQU87SUFDZCxPQUFPLENBQUM7R0FDVjtFQUNGO0VBQ0EsU0FBUyx1QkFBdUIsV0FBVyxhQUFhO0dBQ3RELE9BQU8sWUFBWTtFQUNyQjtFQUNBLGdCQUFnQixPQUFPLGtDQUNyQixlQUNFLE9BQU8sK0JBQStCLCtCQUN4QywrQkFBK0IsNEJBQTRCLE1BQU0sQ0FBQztFQUNwRSxJQUFJLFFBQUEsY0FBQSxHQUNGLFdBQVcsZUFBZSxPQUFPLE9BQU8sS0FBSyxPQUFPLEtBQUssSUFDekQsV0FBVyxNQUFNLFVBQ2pCLFlBQVksTUFBTSxXQUNsQixrQkFBa0IsTUFBTSxpQkFDeEIsZ0JBQWdCLE1BQU0sZUFDdEIsb0JBQW9CLENBQUMsR0FDckIsNkJBQTZCLENBQUMsR0FDOUIsT0FDRSxnQkFBZ0IsT0FBTyxVQUN2QixnQkFBZ0IsT0FBTyxPQUFPLFlBQzlCLGdCQUFnQixPQUFPLE9BQU8sU0FBUyxnQkFDbkMseUJBQ0E7RUFDUixRQUFRLHVCQUNOLEtBQUssTUFBTSxNQUFNLHVCQUF1QixNQUFNLHVCQUF1QjtFQUN2RSxnQkFBZ0IsT0FBTyxrQ0FDckIsZUFDRSxPQUFPLCtCQUErQiw4QkFDeEMsK0JBQStCLDJCQUEyQixNQUFNLENBQUM7Q0FDckUsRUFBQSxDQUFHOzs7OztDQ3pGSCxPQUFPLFVBQUEsaURBQUE7Ozs7Ozs7Ozs7Ozs7O0NDTVQsQ0FDRyxXQUFZO0VBQ1gsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixPQUFRLE1BQU0sTUFBTSxNQUFNLEtBQUssSUFBSSxNQUFNLElBQUksTUFBUSxNQUFNLEtBQUssTUFBTTtFQUN4RTtFQUNBLGdCQUFnQixPQUFPLGtDQUNyQixlQUNFLE9BQU8sK0JBQStCLCtCQUN4QywrQkFBK0IsNEJBQTRCLE1BQU0sQ0FBQztFQUNwRSxJQUFJLFFBQUEsY0FBQSxHQUNGLE9BQUEsYUFBQSxHQUNBLFdBQVcsZUFBZSxPQUFPLE9BQU8sS0FBSyxPQUFPLEtBQUssSUFDekQsdUJBQXVCLEtBQUssc0JBQzVCLFNBQVMsTUFBTSxRQUNmLFlBQVksTUFBTSxXQUNsQixVQUFVLE1BQU0sU0FDaEIsZ0JBQWdCLE1BQU07RUFDeEIsUUFBUSxtQ0FBbUMsU0FDekMsV0FDQSxhQUNBLG1CQUNBLFVBQ0EsU0FDQTtHQUNBLElBQUksVUFBVSxPQUFPLElBQUk7R0FDekIsSUFBSSxTQUFTLFFBQVEsU0FBUztJQUM1QixJQUFJLE9BQU87S0FBRSxVQUFVLENBQUM7S0FBRyxPQUFPO0lBQUs7SUFDdkMsUUFBUSxVQUFVO0dBQ3BCLE9BQU8sT0FBTyxRQUFRO0dBQ3RCLFVBQVUsUUFDUixXQUFZO0lBQ1YsU0FBUyxpQkFBaUIsY0FBYztLQUN0QyxJQUFJLENBQUMsU0FBUztNQUNaLFVBQVUsQ0FBQztNQUNYLG1CQUFtQjtNQUNuQixlQUFlLFNBQVMsWUFBWTtNQUNwQyxJQUFJLEtBQUssTUFBTSxXQUFXLEtBQUssVUFBVTtPQUN2QyxJQUFJLG1CQUFtQixLQUFLO09BQzVCLElBQUksUUFBUSxrQkFBa0IsWUFBWSxHQUN4QyxPQUFRLG9CQUFvQjtNQUNoQztNQUNBLE9BQVEsb0JBQW9CO0tBQzlCO0tBQ0EsbUJBQW1CO0tBQ25CLElBQUksU0FBUyxrQkFBa0IsWUFBWSxHQUN6QyxPQUFPO0tBQ1QsSUFBSSxnQkFBZ0IsU0FBUyxZQUFZO0tBQ3pDLElBQUksS0FBSyxNQUFNLFdBQVcsUUFBUSxrQkFBa0IsYUFBYSxHQUMvRCxPQUFRLG1CQUFtQixjQUFlO0tBQzVDLG1CQUFtQjtLQUNuQixPQUFRLG9CQUFvQjtJQUM5QjtJQUNBLElBQUksVUFBVSxDQUFDLEdBQ2Isa0JBQ0EsbUJBQ0EseUJBQ0UsS0FBSyxNQUFNLG9CQUFvQixPQUFPO0lBQzFDLE9BQU8sQ0FDTCxXQUFZO0tBQ1YsT0FBTyxpQkFBaUIsWUFBWSxDQUFDO0lBQ3ZDLEdBQ0EsU0FBUyx5QkFDTCxLQUFLLElBQ0wsV0FBWTtLQUNWLE9BQU8saUJBQWlCLHVCQUF1QixDQUFDO0lBQ2xELENBQ047R0FDRixHQUNBO0lBQUM7SUFBYTtJQUFtQjtJQUFVO0dBQU8sQ0FDcEQ7R0FDQSxJQUFJLFFBQVEscUJBQXFCLFdBQVcsUUFBUSxJQUFJLFFBQVEsRUFBRTtHQUNsRSxVQUNFLFdBQVk7SUFDVixLQUFLLFdBQVcsQ0FBQztJQUNqQixLQUFLLFFBQVE7R0FDZixHQUNBLENBQUMsS0FBSyxDQUNSO0dBQ0EsY0FBYyxLQUFLO0dBQ25CLE9BQU87RUFDVDtFQUNBLGdCQUFnQixPQUFPLGtDQUNyQixlQUNFLE9BQU8sK0JBQStCLDhCQUN4QywrQkFBK0IsMkJBQTJCLE1BQU0sQ0FBQztDQUNyRSxFQUFBLENBQUc7Ozs7O0NDM0ZILE9BQU8sVUFBQSxrQ0FBQTs7QUNEVCxTQUFTLGVBQWUsR0FBRyxHQUFHO0NBQzdCLE9BQU8sTUFBTTtBQUNkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQkEsU0FBUyxZQUFZLFFBQVEsWUFBWSxNQUFNLEdBQUcsU0FBUztDQUMxRCxNQUFNLFVBQVUsU0FBUyxXQUFXO0NBQ3BDLE1BQU0sYUFBQSxHQUFZQyxhQUFBQSxZQUFBQSxFQUFhLHNCQUFzQjtFQUNwRCxNQUFNLEVBQUUsZ0JBQWdCLE9BQU8sVUFBVSxpQkFBaUI7RUFDMUQsT0FBTztDQUNSLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FDWCxNQUFNLGVBQUEsR0FBY0EsYUFBQUEsWUFBQUEsT0FBa0IsT0FBTyxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FDNUQsUUFBQSxHQUFPQyxxQkFBQUEsaUNBQUFBLENBQWlDLFdBQVcsYUFBYSxhQUFhLFVBQVUsT0FBTztBQUMvRjs7O0FDM0JBLElBQUksYUFBYSxDQUFDO0FBQ2xCLFNBQVMscUJBQXFCLE1BQU0sUUFBUTtDQUMzQyxNQUFNLGlCQUFBLGFBQXlCLE9BQU87Q0FDdEMsUUFBUSxVQUFVO0VBQ2pCLE1BQU0sV0FBVyxNQUFNLFNBQVMsS0FBSyxPQUFPLEtBQUssSUFBSTtFQUNyRCxJQUFJLE1BQU0scUJBQXFCLE9BQU8sUUFBUSwwQkFBMEIsT0FBTyxlQUFlLFVBQVUsaUJBQWlCLGVBQWUsU0FBUyxRQUFRO0VBQ3pKLE9BQU87Q0FDUjtBQUNEOzs7OztBQUtBLFNBQVMsU0FBUyxNQUFNO0NBQ3ZCLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0saUJBQUEsYUFBeUIsV0FBVyxLQUFLLE9BQU8sb0JBQW9CLFlBQVk7Q0FDdEYsTUFBTSxVQUFVLEtBQUssUUFBUTtDQUM3QixNQUFNLGFBQWEsT0FBTyxPQUFPLGNBQWMsT0FBTztDQUN0RCxJQUFnQixPQUFPLFVBQVU7RUFDaEMsTUFBTSxRQUFRLFdBQVcsSUFBSTtFQUM3QixJQUFJLENBQUMsT0FBTztHQUNYLElBQUksS0FBSyxlQUFlLE1BQ29CLE1BQU0sSUFBSSxNQUFNLG9DQUFvQyxLQUFLLE9BQU8seUJBQXlCLEtBQUssS0FBSyxLQUFLLG9CQUFvQjtHQUd4SztFQUNEO0VBQ0EsT0FBTyxLQUFLLFNBQVMsS0FBSyxPQUFPLEtBQUssSUFBSTtDQUMzQztDQUNBLE1BQU0sV0FBVyxxQkFBcUIsTUFBTSxNQUFNO0NBQ2xELE1BQU0saUJBQWlCLFlBQVksYUFBYSxVQUFVLFFBQVEsU0FBUyxLQUFLLElBQUksVUFBVTtDQUM5RixJQUFJLG1CQUFtQixZQUFZLE9BQU87Q0FDMUMsSUFBSSxLQUFLLGVBQWUsTUFDb0IsTUFBTSxJQUFJLE1BQU0sb0NBQW9DLEtBQUssT0FBTyx5QkFBeUIsS0FBSyxLQUFLLEtBQUssb0JBQW9CO0FBR3pLOzs7Ozs7Ozs7Ozs7OztBQy9CQSxTQUFTLGNBQWMsTUFBTTtDQUM1QixPQUFPLFNBQVM7RUFDZixNQUFNLEtBQUs7RUFDWCxRQUFRLEtBQUs7RUFDYixtQkFBbUIsS0FBSztFQUN4QixTQUFTLFVBQVU7R0FDbEIsT0FBTyxLQUFLLFNBQVMsS0FBSyxPQUFPLE1BQU0sVUFBVSxJQUFJLE1BQU07RUFDNUQ7Q0FDRCxDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7O0FDVEEsU0FBUyxjQUFjLE1BQU07Q0FDNUIsTUFBTSxFQUFFLFFBQVEsR0FBRyxTQUFTO0NBQzVCLE9BQU8sU0FBUztFQUNmLEdBQUc7RUFDSCxTQUFTLFVBQVU7R0FDbEIsT0FBTyxTQUFTLE9BQU8sTUFBTSxVQUFVLElBQUksTUFBTTtFQUNsRDtDQUNELENBQUM7QUFDRjs7Ozs7Ozs7Ozs7Ozs7O0FDUEEsU0FBUyxVQUFVLE1BQU07Q0FDeEIsT0FBTyxTQUFTO0VBQ2YsTUFBTSxLQUFLO0VBQ1gsYUFBYSxLQUFLO0VBQ2xCLG1CQUFtQixLQUFLO0VBQ3hCLFFBQVEsS0FBSztFQUNiLFNBQVMsVUFBVTtHQUNsQixNQUFNLFNBQVMsS0FBSyxXQUFXLFFBQVEsTUFBTSxTQUFTLE1BQU07R0FDNUQsT0FBTyxLQUFLLFNBQVMsS0FBSyxPQUFPLE1BQU0sSUFBSTtFQUM1QztDQUNELENBQUM7QUFDRjs7Ozs7Ozs7Ozs7Ozs7O0FDWEEsU0FBUyxVQUFVLE1BQU07Q0FDeEIsT0FBTyxTQUFTO0VBQ2YsTUFBTSxLQUFLO0VBQ1gsUUFBUSxLQUFLO0VBQ2IsYUFBYSxLQUFLO0VBQ2xCLG1CQUFtQixLQUFLO0VBQ3hCLFNBQVMsVUFBVTtHQUNsQixPQUFPLEtBQUssU0FBUyxLQUFLLE9BQU8sTUFBTSxNQUFNLElBQUksTUFBTTtFQUN4RDtDQUNELENBQUM7QUFDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNMQSxTQUFTLFlBQVksY0FBYztDQUNsQyxNQUFNLFNBQVMsVUFBVTtDQUN6QixPQUFBLGFBQWUsYUFBYSxZQUFZO0VBQ3ZDLE9BQU8sT0FBTyxTQUFTO0dBQ3RCLEdBQUc7R0FDSCxNQUFNLFFBQVEsUUFBUSxjQUFjO0VBQ3JDLENBQUM7Q0FDRixHQUFHLENBQUMsY0FBYyxNQUFNLE1BQU0sQ0FBQztBQUNoQzs7Ozs7Ozs7OztBQVVBLFNBQVMsU0FBUyxPQUFPO0NBQ3hCLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sbUJBQUEsYUFBMkIsT0FBTyxJQUFJO0NBQzVDLHNCQUFzQjtFQUNyQixJQUFJLGlCQUFpQixZQUFZLE9BQU87R0FDdkMsU0FBUyxLQUFLO0dBQ2QsaUJBQWlCLFVBQVU7RUFDNUI7Q0FDRCxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELE9BQU87QUFDUjs7O0FDbERBLFNBQVMsZ0JBQWdCLE1BQU07Q0FDOUIsT0FBTyxTQUFTO0VBQ2YsR0FBRztFQUNILFNBQVMsVUFBVSxLQUFLLFNBQVMsS0FBSyxPQUFPLE1BQU0sT0FBTyxJQUFJLE1BQU07Q0FDckUsQ0FBQztBQUNGOzs7QUNDQSxTQUFTLGdCQUFnQixHQUFHLFFBQVE7Q0FDbkMsTUFBTSxNQUFBLGFBQWMsT0FBTyxNQUFNO0NBQ2pDLE1BQU0sU0FBUyxJQUFJO0NBQ25CLE9BQU8sU0FBUyxPQUFPLFVBQVU7RUFDaEMsSUFBSSxDQUFDLFVBQVUsT0FBTyxRQUFRLE9BQU8sT0FBTyxJQUFJLEdBQUcsT0FBTyxTQUFTO0NBQ3BFLENBQUM7Q0FDRCxPQUFPLElBQUk7QUFDWjtBQUNBLFNBQVMsWUFBWSxRQUFRLFNBQVM7Q0FDckMsT0FBTyxhQUFhLE9BQU8sQ0FBQyxDQUFDLE9BQU8sUUFBUTtFQUMzQyxRQUFRLEtBQUssR0FBRztFQUNoQixRQUFRLEtBQUssY0FBYztDQUM1QixDQUFDO0FBQ0Y7QUFDQSxTQUFTLG9CQUFvQixJQUFJLG1CQUFtQjtDQUNuRCxNQUFNLFNBQVMsT0FBTyxPQUFPLFlBQVksYUFBYSxFQUFFO0NBQ3hELElBQUksQ0FBQyxRQUFRO0NBQ2IsSUFBSSxDQUFDLGtCQUFrQixJQUFJLE1BQU0sR0FBRztFQUNRLFFBQVEsS0FBSyx5Q0FBeUMsSUFBSTtFQUNyRyxPQUFPO0NBQ1I7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLGdCQUFnQixVQUFVLE1BQU0sZUFBZSxVQUFVO0NBQ2pFLE1BQU0sY0FBYyxvQkFBb0IsU0FBUyxVQUFVLFFBQVE7Q0FDbkUsTUFBTSxXQUFXLG9CQUFvQixLQUFLLFVBQVUsUUFBUTtDQUM1RCxJQUFJLGVBQWUsUUFBUSxnQkFBZ0IsV0FBVyxFQUFFLFlBQVksV0FBVyxRQUFRLE1BQU0sWUFBWSxXQUFXLFNBQVMsVUFBVSxZQUFZLFNBQVMsWUFBWSxPQUFPLE9BQU87Q0FDdEwsSUFBSSxlQUFlLGlCQUFpQixNQUMvQjtNQUFBLENBQUMsVUFBVSxTQUFTLFFBQVEsS0FBSyxRQUFRLENBQUMsZUFBZSxPQUFPLGVBQWUsaUJBQWlCLEdBQUcsT0FBTztDQUFBO0NBRS9HLE9BQU8sQ0FBQyxlQUFlLGVBQWUsU0FBUyxTQUFTLEtBQUs7QUFDOUQ7QUFDQSxTQUFTLGFBQWEsU0FBUyxjQUFjLE1BQU07Q0FDbEQsTUFBTSxTQUFTLFVBQVU7Q0FDekIsSUFBZ0IsT0FBTyxVQUFVLE9BQU8sbUJBQW1CLFFBQVEsU0FBUyxjQUFjLElBQUk7Q0FDOUYsTUFBTSxXQUFBLGFBQW1CLE9BQU8sSUFBSTtDQUNwQyxNQUFNLFlBQUEsYUFBb0IsYUFBYSxZQUFZO0VBQ2xELFNBQVMsVUFBVTtFQUNuQixJQUFJLE9BQU8saUJBQWlCLFlBQVksT0FBTyxhQUFhLE9BQU87RUFDbkUsSUFBSSxjQUFjLGFBQWEsVUFBVTtDQUMxQyxHQUFHLENBQUMsWUFBWSxDQUFDO0NBQ2pCLE1BQU0sRUFBRSxlQUFlLElBQUksU0FBUyxhQUFhLGNBQWMsa0JBQWtCLFVBQVUsUUFBUSxTQUFTLFFBQVEsU0FBUyxjQUFjLGNBQWMsaUJBQWlCO0NBQzFLLE1BQU0sQ0FBQyxjQUFjLGNBQWMsdUJBQXVCLGdCQUFnQixRQUFRLFFBQVEsUUFBUSxRQUFRLGFBQWE7Q0FDdkgsTUFBTSxVQUFBLGFBQWtCLFdBQVcsWUFBWTtDQUMvQyxNQUFNLFFBQVEsQ0FBQyxPQUFPLE9BQU8sZ0JBQWdCLENBQUMsRUFBQSxDQUFHLGFBQWEsZ0JBQWdCLFFBQVEsT0FBTztDQUM3RixNQUFNLENBQUMsTUFBTSxjQUFjLHFCQUFBLGFBQTZCLGNBQWM7RUFDckUsTUFBTSxxQkFBcUIsb0JBQW9CLElBQUksT0FBTyxpQkFBaUI7RUFDM0UsSUFBSSx1QkFBdUIsS0FBSyxHQUFHO0dBQ2xDLE1BQU0sUUFBUSxDQUFDLHNCQUFzQixLQUFLLENBQUM7R0FDM0MsT0FBTyxDQUFDLGVBQWUsS0FBSztFQUM3QjtFQUNBLE1BQU0sT0FBTyxFQUFFLEdBQUcsUUFBUTtFQUMxQixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixNQUFNLHFCQUFxQjtHQUMxQixNQUFNLFdBQVcsTUFBTSxFQUFFLENBQUM7R0FDMUIsSUFBSSxhQUFhLFFBQVE7SUFDeEIsS0FBSyxnQkFBZ0I7SUFDckIsTUFBTSxPQUFPLE9BQU8sY0FBYyxJQUFJO0lBQ3RDLE1BQU0sT0FBTyxjQUFjLE1BQU0sUUFBUSxRQUFRO0lBQ2pELE1BQU0sV0FBVyxZQUFZLFFBQVEsQ0FBQyxhQUFhLElBQUksSUFBSSxnQkFBZ0IsVUFBVSxNQUFNLHFCQUFxQixPQUFPLFFBQVEsSUFBSSxLQUFLO0lBQ3hJLElBQUksQ0FBQyxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxVQUFVLFFBQVEsQ0FBQyxNQUFNLFFBQVE7SUFDakYsU0FBUztHQUNWO0dBQ0EsT0FBTztFQUNSO0VBQ0EsT0FBTztHQUNOO0dBQ0E7R0FDQSxxQkFBcUIsc0JBQXNCO0lBQzFDLE1BQU0sUUFBUSxhQUFhO0lBQzNCLE9BQU8sTUFBTSxLQUFLLG1CQUFtQixDQUFDLE1BQU0sSUFBSSxLQUFLLElBQUk7R0FDMUQ7RUFDRDtDQUNELEdBQUc7RUFDRjtFQUNBO0VBQ0EsUUFBUTtFQUNSLFFBQVE7RUFDUixRQUFRO0VBQ1I7RUFDQTtFQUNBO0VBQ0EsUUFBUTtFQUNSLFFBQVE7RUFDUixRQUFRO0VBQ1I7RUFDQTtDQUNELENBQUM7Q0FDRCxNQUFNLENBQUMsTUFBTSxZQUFBLGFBQW9CLHFCQUFxQixNQUFNLElBQUksY0FBYyxxQkFBcUIsWUFBWTtDQUMvRyxNQUFNLGVBQWUsYUFBYSxLQUFLLEtBQUs7Q0FDNUMsTUFBTSxlQUFlLFlBQVksU0FBUyxLQUFLO0NBQy9DLE1BQU0sbUJBQUEsYUFBMkIsT0FBTyxLQUFLO0NBQzdDLE1BQU0sVUFBVSxRQUFRLGtCQUFrQixnQkFBZ0IsZUFBZSxRQUFRLGVBQWUsT0FBTyxRQUFRO0NBQy9HLE1BQU0sZUFBZSxvQkFBb0IsT0FBTyxRQUFRLHVCQUF1QjtDQUMvRSxNQUFNLGlCQUFBLGFBQXlCLGFBQWEsTUFBTTtFQUNqRCxNQUFNLGlCQUFpQixHQUFHO0VBQzFCLElBQUksRUFBRSxrQkFBa0IsWUFBWSxXQUFXO0dBQzlDLElBQUksbUJBQW1CLE9BQU8sY0FBYyxRQUFRO0dBQ3BEO0VBQ0Q7RUFDQSxJQUFJLENBQUMsY0FBYztHQUNsQixZQUFZLFFBQVEsSUFBSTtHQUN4QjtFQUNEO0VBQ0EsU0FBUyxNQUFNLGlCQUFpQjtHQUMvQixTQUFTLElBQUksS0FBSztHQUNsQixZQUFZLFFBQVEsSUFBSTtFQUN6QixHQUFHLFlBQVk7Q0FDaEIsR0FBRztFQUNGO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsYUFBUSxnQkFBZ0I7RUFDdkIsSUFBSSxDQUFDLFNBQVM7RUFDZCxJQUFJLFlBQVksWUFBWSxDQUFDLGlCQUFpQixTQUFTO0dBQ3RELGlCQUFpQixVQUFVO0dBQzNCLFlBQVksUUFBUSxJQUFJO0VBQ3pCO0VBQ0EsSUFBSSxTQUFTO0VBQ2IsSUFBSTtFQUNKLElBQUksWUFBWSxjQUFjLFNBQVMsV0FBVyxPQUFPLHlCQUF5QixZQUFZO0dBQzdGLFdBQVcsSUFBSSxzQkFBc0IsWUFBWTtJQUNoRCxJQUFJLFFBQVEsZUFBZSxRQUFRLElBQUksQ0FBQztHQUN6QyxHQUFHLEVBQUUsWUFBWSxRQUFRLENBQUM7R0FDMUIsU0FBUyxRQUFRLFNBQVMsT0FBTztFQUNsQztFQUNBLGFBQWE7R0FDWixTQUFTO0dBQ1QsVUFBVSxXQUFXO0dBQ3JCLGNBQWMsUUFBUTtFQUN2QjtDQUNELEdBQUc7RUFDRjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELE1BQU0sUUFBUSxvQkFBb0IsU0FBUyxJQUFJO0NBQy9DLE1BQU0sTUFBTSxlQUFlLFlBQVk7Q0FDdkMsSUFBSSxjQUFjO0VBQ2pCLE1BQU0sT0FBTztFQUNiLE9BQU87Q0FDUjtDQUNBLE1BQU0sZUFBZSxNQUFNO0VBQzFCLE1BQU0sa0JBQWtCLFVBQVUsRUFBRSxjQUFjLGFBQWEsUUFBUTtFQUN2RSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLFdBQVcsRUFBRSxhQUFhLENBQUMsRUFBRSxxQkFBcUIsQ0FBQyxtQkFBbUIsb0JBQW9CLFlBQVksRUFBRSxXQUFXLEdBQUc7R0FDdkssRUFBRSxlQUFlO0dBQ2pCLGNBQWMsUUFBUTtHQUN0QixPQUFPLFNBQVM7SUFDZixHQUFHO0lBQ0gsZUFBZSxLQUFLO0dBQ3JCLENBQUM7RUFDRjtDQUNEO0NBQ0EsTUFBTSx5QkFBeUI7RUFDOUIsSUFBSSxZQUFZLFVBQVUsWUFBWSxRQUFRLElBQUk7Q0FDbkQ7Q0FDQSxNQUFNLG9CQUFvQjtFQUN6QixJQUFJLFlBQVksVUFBVSxjQUFjLFFBQVE7Q0FDakQ7Q0FDQSxNQUFNLFVBQVUsZ0JBQWdCLFNBQVMsV0FBVztDQUNwRCxNQUFNLFNBQVMsZ0JBQWdCLFFBQVEsV0FBVztDQUNsRCxNQUFNLFVBQVUsZ0JBQWdCLFNBQVMsY0FBYztDQUN2RCxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsY0FBYztDQUNqRSxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsV0FBVztDQUM5RCxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsZ0JBQWdCO0NBQ25FLE9BQU8sZUFBZSxPQUFPLFNBQVMsVUFBVSxNQUFNLGNBQWMsSUFBSTtBQUN6RTtBQUNBLElBQUksc0JBQXNCLENBQUM7QUFDM0IsSUFBSSx1QkFBdUIsRUFBRSxXQUFXLFNBQVM7QUFDakQsSUFBSSxxQ0FBcUMsSUFBSSxJQUFJO0NBQ2hEO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0QsQ0FBQztBQUNELFNBQVMsb0JBQW9CLFNBQVMsTUFBTTtDQUMzQyxNQUFNLFFBQVEsQ0FBQztDQUNmLEtBQUssTUFBTSxPQUFPLFNBQVM7RUFDMUIsSUFBSSxtQkFBbUIsSUFBSSxHQUFHLEtBQUssUUFBUSxVQUFVLFNBQVMsS0FBSyxLQUFLLFFBQVEsY0FBYyxTQUFTLEtBQUs7RUFDNUcsTUFBTSxPQUFPLFFBQVE7Q0FDdEI7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLGVBQWUsT0FBTyxTQUFTLFVBQVUsTUFBTSxjQUFjLE1BQU07Q0FDM0UsTUFBTSxFQUFFLGFBQWEsZUFBZSxXQUFXLE9BQU8sV0FBVztDQUNqRSxNQUFNLGFBQWEsaUJBQWlCLFdBQVcsY0FBYyxlQUFlLENBQUMsQ0FBQyxNQUFNLFdBQVcsdUJBQXVCO0NBQ3RILE9BQU8sT0FBTyxPQUFPLFVBQVU7Q0FDL0IsTUFBTSxPQUFPO0NBQ2IsSUFBSSxTQUFTLEtBQUssTUFBTSxXQUFXO0NBQ25DLE1BQU0sU0FBUztDQUNmLE1BQU0sYUFBYSxXQUFXO0NBQzlCLElBQUksU0FBUyxZQUFZLE1BQU0sUUFBUSxTQUFTLGFBQWE7RUFDNUQsR0FBRztFQUNILEdBQUc7Q0FDSixJQUFJLFNBQVM7Q0FDYixNQUFNLGlCQUFpQixXQUFXO0NBQ2xDLElBQUksYUFBYSxnQkFBZ0IsTUFBTSxZQUFZLFlBQVksaUJBQWlCLEdBQUcsVUFBVSxHQUFHLG1CQUFtQixZQUFZO0NBQy9ILElBQUksY0FBYztFQUNqQixNQUFNLE9BQU87RUFDYixNQUFNLG1CQUFtQjtDQUMxQjtDQUNBLElBQUksVUFBVTtFQUNiLE1BQU0saUJBQWlCO0VBQ3ZCLE1BQU0sa0JBQWtCO0NBQ3pCO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxtQkFBbUIsUUFBUSxTQUFTLGNBQWMsTUFBTTtDQUNoRSxNQUFNLEVBQUUsSUFBSSxVQUFVLGtCQUFrQjtDQUN4QyxNQUFNLHFCQUFxQixvQkFBb0IsSUFBSSxPQUFPLGlCQUFpQjtDQUMzRSxNQUFNLE9BQU8sdUJBQXVCLEtBQUssSUFBSSxPQUFPLGNBQWMsT0FBTyxJQUFJLEtBQUs7Q0FDbEYsTUFBTSxhQUFhLE9BQU8sY0FBYyxNQUFNLFFBQVEsUUFBUSxJQUFJLHNCQUFzQixLQUFLO0NBQzdGLE1BQU0sZUFBZSxZQUFZLENBQUM7Q0FDbEMsTUFBTSxlQUFlLHVCQUF1QixjQUFjLGFBQWEsVUFBVSxJQUFJLGFBQWEsS0FBSztDQUN2RyxNQUFNLFFBQVEsb0JBQW9CLFNBQVMsSUFBSTtDQUMvQyxNQUFNLE1BQU07Q0FDWixJQUFJLGNBQWM7RUFDakIsTUFBTSxPQUFPO0VBQ2IsT0FBTztDQUNSO0NBQ0EsT0FBTyxlQUFlLE9BQU8sU0FBUyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxlQUFlLGVBQWUsZ0JBQWdCLE9BQU8sT0FBTyxTQUFTLElBQUksR0FBRyxNQUFNLGVBQWUsT0FBTyxRQUFRLEdBQUcsWUFBWSxjQUFjLElBQUk7QUFDbE87QUFDQSxJQUFJLGlCQUFpQixRQUFRO0NBQzVCLGFBQWEsSUFBSSxDQUFDO0NBQ2xCLElBQUksSUFBSSxLQUFLO0FBQ2Q7QUFDQSxJQUFJLG1CQUFtQixPQUFPLFdBQVc7Q0FDeEMsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUNuQixRQUFRLFVBQVUsTUFBTSxxQkFBcUIsTUFBTSxLQUFLLEdBQUcsTUFBTSxvQkFBb0IsT0FBTyxLQUFLO0FBQ2xHO0FBQ0EsU0FBUyxjQUFjLE1BQU0sUUFBUSxVQUFVO0NBQzlDLElBQUksVUFBVTtDQUNkLE1BQU0sV0FBVyxLQUFLLGtCQUFrQjtDQUN4QyxNQUFNLE9BQU8sU0FBUyxXQUFXLFNBQVMsYUFBYSxPQUFPLFFBQVEsV0FBVyxTQUFTLFVBQVUsS0FBSztDQUN6RyxLQUFLLFNBQVMsWUFBWSxTQUFTLFNBQVMsZUFBZSxvQkFBb0IsTUFBTSxPQUFPLGlCQUFpQixHQUFHO0VBQ3BFLFFBQVEsS0FBSyx5Q0FBeUMsTUFBTTtFQUN2RztDQUNEO0NBQ0EsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7O0FBYUEsU0FBUyxXQUFXLE1BQU07Q0FDekIsT0FBQSxhQUFlLFdBQVcsU0FBUyxZQUFZLE9BQU8sS0FBSztFQUMxRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxNQUFNO0dBQ2hDLEdBQUc7R0FDSCxVQUFVO0dBQ1Y7RUFDRCxDQUFDO0NBQ0YsQ0FBQztBQUNGOzs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQSxJQUFJLE9BQUEsYUFBZSxLQUFBLGFBQWEsWUFBWSxPQUFPLFFBQVE7Q0FDMUQsTUFBTSxPQUFPLE1BQU0sWUFBWTtDQUMvQixNQUFNLFlBQVksYUFBYSxPQUFPLEtBQUssSUFBSTtDQUMvQyxNQUFNLFdBQVcsT0FBTyxNQUFNLGFBQWEsYUFBYSxNQUFNLFNBQVMsRUFBRSxVQUFVLFVBQVUsbUJBQW1CLFNBQVMsQ0FBQyxJQUFJLE1BQU07Q0FDcEksT0FBQSxhQUFlLGNBQWMsTUFBTSxXQUFXLFFBQVE7QUFDdkQsQ0FBQyxHQUFHLGlCQUFpQjtBQUNyQixTQUFTLGtCQUFrQixNQUFNLE1BQU07Q0FDdEMsSUFBSSxZQUFZO0NBQ2hCLEtBQUssTUFBTSxPQUFPLE1BQU07RUFDdkI7RUFDQSxJQUFJLEtBQUssU0FBUyxLQUFLLE1BQU07RUFDN0IsSUFBSSxDQUFDLG1CQUFtQixJQUFJLEdBQUcsS0FBSyxDQUFDLFVBQVUsS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLElBQUksR0FBRyxPQUFPO0NBQzNGO0NBQ0EsS0FBSyxNQUFNLFFBQVEsTUFBTTtDQUN6QixPQUFPLGNBQWM7QUFDdEI7Ozs7Ozs7O0FBUUEsSUFBSSxlQUFlLFlBQVk7Q0FDOUIsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7QUN6VEEsU0FBUyxZQUFZLElBQUk7Q0FDeEIsT0FBTyxJQUFJLFNBQVMsRUFBRSxHQUFHLENBQUM7QUFDM0I7QUFDQSxJQUFJLFdBQVcsY0FBYyxhQUFhOzs7O0NBSXpDLFlBQVksRUFBRSxNQUFNO0VBQ25CLE1BQU0sRUFBRSxHQUFHLENBQUM7RUFDWixLQUFLLFlBQVksU0FBUztHQUN6QixPQUFPLFNBQVM7SUFDZixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxtQkFBbUIsU0FBUztHQUNoQyxPQUFPLGdCQUFnQjtJQUN0QixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxhQUFhLFNBQVM7R0FDMUIsT0FBTyxVQUFVO0lBQ2hCLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGFBQWEsU0FBUztHQUMxQixPQUFPLFVBQVU7SUFDaEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssaUJBQWlCLFNBQVM7R0FDOUIsT0FBTyxjQUFjO0lBQ3BCLEdBQUc7SUFDSCxNQUFNLEtBQUs7SUFDWCxRQUFRO0dBQ1QsQ0FBQztFQUNGO0VBQ0EsS0FBSyxpQkFBaUIsU0FBUztHQUM5QixPQUFPLGNBQWM7SUFDcEIsR0FBRztJQUNILE1BQU0sS0FBSztJQUNYLFFBQVE7R0FDVCxDQUFDO0VBQ0Y7RUFDQSxLQUFLLG9CQUFvQjtHQUV4QixPQUFPLFlBQVksRUFBRSxNQUROLFVBQ1ksQ0FBQSxDQUFPLFdBQVcsS0FBSyxHQUFHLENBQUMsU0FBUyxDQUFDO0VBQ2pFO0VBQ0EsS0FBSyxZQUFZLFNBQVM7R0FDekIsT0FBTyxTQUFTO0lBQ2YsU0FBUyxLQUFLO0lBQ2QsR0FBRztHQUNKLENBQUM7RUFDRjtFQUNBLEtBQUssT0FBQSxhQUFhLFlBQVksT0FBTyxRQUFRO0dBQzVDLE1BQU0sV0FBVyxVQUFVLENBQUMsQ0FBQyxXQUFXLEtBQUssR0FBRyxDQUFDO0dBQ2pELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE1BQU07SUFDaEM7SUFDQSxNQUFNO0lBQ04sR0FBRztHQUNKLENBQUM7RUFDRixDQUFDO0NBQ0Y7QUFDRDtBQUNBLElBQUksUUFBUSxjQUFjLFVBQVU7Ozs7Q0FJbkMsWUFBWSxTQUFTO0VBQ3BCLE1BQU0sT0FBTztFQUNiLEtBQUssWUFBWSxTQUFTO0dBQ3pCLE9BQU8sU0FBUztJQUNmLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLG1CQUFtQixTQUFTO0dBQ2hDLE9BQU8sZ0JBQWdCO0lBQ3RCLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGFBQWEsU0FBUztHQUMxQixPQUFPLFVBQVU7SUFDaEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssYUFBYSxTQUFTO0dBQzFCLE9BQU8sVUFBVTtJQUNoQixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxpQkFBaUIsU0FBUztHQUM5QixPQUFPLGNBQWM7SUFDcEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssaUJBQWlCLFNBQVM7R0FDOUIsT0FBTyxjQUFjO0lBQ3BCLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLG9CQUFvQjtHQUN4QixPQUFPLFlBQVksRUFBRSxNQUFNLEtBQUssU0FBUyxDQUFDO0VBQzNDO0VBQ0EsS0FBSyxPQUFBLGFBQWEsWUFBWSxPQUFPLFFBQVE7R0FDNUMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksTUFBTTtJQUNoQztJQUNBLE1BQU0sS0FBSztJQUNYLEdBQUc7R0FDSixDQUFDO0VBQ0YsQ0FBQztDQUNGO0FBQ0Q7Ozs7Ozs7Ozs7OztBQVlBLFNBQVMsWUFBWSxTQUFTO0NBQzdCLE9BQU8sSUFBSSxNQUFNLE9BQU87QUFDekI7Ozs7Ozs7Ozs7QUFVQSxTQUFTLDZCQUE2QjtDQUNyQyxRQUFRLFlBQVk7RUFDbkIsT0FBTyxnQkFBZ0IsT0FBTztDQUMvQjtBQUNEOzs7O0FBSUEsSUFBSSx1QkFBdUI7QUFDM0IsSUFBSSxZQUFZLGNBQWMsY0FBYzs7OztDQUkzQyxZQUFZLFNBQVM7RUFDcEIsTUFBTSxPQUFPO0VBQ2IsS0FBSyxZQUFZLFNBQVM7R0FDekIsT0FBTyxTQUFTO0lBQ2YsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssbUJBQW1CLFNBQVM7R0FDaEMsT0FBTyxnQkFBZ0I7SUFDdEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssYUFBYSxTQUFTO0dBQzFCLE9BQU8sVUFBVTtJQUNoQixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxhQUFhLFNBQVM7R0FDMUIsT0FBTyxVQUFVO0lBQ2hCLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGlCQUFpQixTQUFTO0dBQzlCLE9BQU8sY0FBYztJQUNwQixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxpQkFBaUIsU0FBUztHQUM5QixPQUFPLGNBQWM7SUFDcEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssb0JBQW9CO0dBQ3hCLE9BQU8sWUFBWSxFQUFFLE1BQU0sS0FBSyxTQUFTLENBQUM7RUFDM0M7RUFDQSxLQUFLLE9BQUEsYUFBYSxZQUFZLE9BQU8sUUFBUTtHQUM1QyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxNQUFNO0lBQ2hDO0lBQ0EsTUFBTSxLQUFLO0lBQ1gsR0FBRztHQUNKLENBQUM7RUFDRixDQUFDO0NBQ0Y7QUFDRDs7Ozs7Ozs7Ozs7QUFXQSxTQUFTLGdCQUFnQixTQUFTO0NBQ2pDLE9BQU8sSUFBSSxVQUFVLE9BQU87QUFDN0I7QUFDQSxTQUFTLGdCQUFnQixNQUFNO0NBQzlCLE9BQU87QUFDUjtBQUNBLElBQUksZ0JBQWdCLGNBQWMsTUFBTTtDQUN2QyxZQUFZLFNBQVM7RUFDcEIsTUFBTTtHQUNMLEdBQUc7R0FDSCxJQUFJO0VBQ0wsQ0FBQztDQUNGO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7O0FDdk9BLFNBQVMsZ0JBQWdCLE1BQU07Q0FDOUIsUUFBUSxZQUFZO0VBQ25CLE1BQU0sUUFBUSxZQUFZLE9BQU87RUFDakMsTUFBTSxTQUFTO0VBQ2YsT0FBTztDQUNSO0FBQ0Q7Ozs7O0FBS0EsSUFBSSxZQUFZLE1BQU07Q0FDckIsWUFBWSxNQUFNLE9BQU87RUFDeEIsS0FBSyxPQUFPO0VBQ1osS0FBSyxlQUFlLFlBQVk7R0FFOUIsSUFBSSxDQUFDLEtBQUssUUFBUSxRQUFRLEtBQUssMElBQTBJO0dBRTFLLE1BQU0sUUFBUSxZQUFZLE9BQU87R0FDakMsTUFBTSxTQUFTO0dBQ2YsT0FBTztFQUNSO0VBQ0EsS0FBSyxTQUFTLE9BQU87Q0FDdEI7QUFDRDs7Ozs7QUFLQSxTQUFTLGdCQUFnQixPQUFPO0NBQ1ksUUFBUSxLQUFLLGlOQUFpTjtDQUN6USxRQUFRLGFBQWE7QUFDdEI7QUFDQSxJQUFJLFlBQVksTUFBTTtDQUNyQixZQUFZLE1BQU07RUFDakIsS0FBSyxZQUFZLFNBQVM7R0FDekIsT0FBTyxTQUFTO0lBQ2YsR0FBRztJQUNILE1BQU0sS0FBSyxRQUFRO0dBQ3BCLENBQUM7RUFDRjtFQUNBLEtBQUssbUJBQW1CLFNBQVM7R0FDaEMsT0FBTyxnQkFBZ0I7SUFDdEIsR0FBRztJQUNILE1BQU0sS0FBSyxRQUFRO0dBQ3BCLENBQUM7RUFDRjtFQUNBLEtBQUssYUFBYSxTQUFTO0dBQzFCLE9BQU8sVUFBVTtJQUNoQixHQUFHO0lBQ0gsTUFBTSxLQUFLLFFBQVE7R0FDcEIsQ0FBQztFQUNGO0VBQ0EsS0FBSyxhQUFhLFNBQVM7R0FDMUIsT0FBTyxVQUFVO0lBQ2hCLEdBQUc7SUFDSCxNQUFNLEtBQUssUUFBUTtHQUNwQixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGlCQUFpQixTQUFTO0dBQzlCLE9BQU8sY0FBYztJQUNwQixHQUFHO0lBQ0gsTUFBTSxLQUFLLFFBQVE7R0FDcEIsQ0FBQztFQUNGO0VBQ0EsS0FBSyxpQkFBaUIsU0FBUztHQUM5QixPQUFPLGNBQWM7SUFDcEIsR0FBRztJQUNILE1BQU0sS0FBSyxRQUFRO0dBQ3BCLENBQUM7RUFDRjtFQUNBLEtBQUssb0JBQW9CO0dBRXhCLE9BQU8sWUFBWSxFQUFFLE1BRE4sVUFDWSxDQUFBLENBQU8sV0FBVyxLQUFLLFFBQVEsR0FBRyxDQUFDLFNBQVMsQ0FBQztFQUN6RTtFQUNBLEtBQUssVUFBVTtDQUNoQjtBQUNEOzs7Ozs7Ozs7Ozs7O0FBYUEsU0FBUyxnQkFBZ0IsSUFBSTtDQUM1QixRQUFRLFNBQVM7RUFDaEIsT0FBTyxJQUFJLFVBQVU7R0FDcEI7R0FDQSxHQUFHO0VBQ0osQ0FBQztDQUNGO0FBQ0Q7Ozs7Ozs7Ozs7OztBQVlBLFNBQVMsb0JBQW9CLElBQUk7Q0FDaEMsSUFBSSxPQUFPLE9BQU8sVUFBVSxPQUFPLElBQUksVUFBVSxFQUFFO0NBQ25ELFFBQVEsU0FBUyxJQUFJLFVBQVU7RUFDOUI7RUFDQSxHQUFHO0NBQ0osQ0FBQztBQUNGOzs7Ozs7Ozs7Ozs7QUMxSEEsU0FBUyxtQkFBbUIsVUFBVSxZQUFZO0NBQ2pELElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLE1BQU0sYUFBYTtFQUNsQixJQUFJLENBQUMsYUFBYTtHQUNqQixRQUFRLEtBQUs7R0FDYixjQUFjLFNBQVMsQ0FBQyxDQUFDLE1BQU0sUUFBUTtJQUN0QyxJQUFJLEVBQWMsT0FBTyxXQUFXLGNBQWM7S0FDakQsY0FBYyxLQUFLO0tBQ25CLFNBQVMsVUFBVSxLQUFLO0lBQ3pCO0lBQ0EsT0FBTyxJQUFJLGNBQWM7R0FDMUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxRQUFRO0lBQ2pCLGNBQWMsS0FBSztJQUNuQixRQUFRO0dBQ1QsQ0FBQztFQUNGO0VBQ0EsT0FBTztDQUNSO0NBQ0EsTUFBTSxXQUFXLFNBQVMsS0FBSyxPQUFPO0VBQ3JDLElBQUksT0FBTztHQUNWLElBQUksc0JBQXNCLEtBQUssS0FBSyxFQUFjLE9BQU8sV0FBVyxnQkFBZ0IsT0FBTyxtQkFBbUIsYUFBYTtJQUMxSCxNQUFNLGFBQWEsMEJBQTBCLE1BQU07SUFDbkQsSUFBSSxDQUFDLGVBQWUsUUFBUSxVQUFVLEdBQUc7S0FDeEMsZUFBZSxRQUFRLFlBQVksR0FBRztLQUN0QyxPQUFPLFNBQVMsT0FBTztLQUN2QixNQUFNLElBQUksY0FBYyxDQUFDLENBQUM7SUFDM0I7R0FDRDtHQUNBLE1BQU07RUFDUDtFQUNBLElBQUksQ0FBQyxNQUFNO0dBQ1YsSUFBSSxVQUFVLFNBQVMsS0FBSyxDQUFDO1FBQ3hCLE1BQU0sS0FBSztFQUNqQjtFQUNBLE9BQUEsYUFBZSxjQUFjLE1BQU0sS0FBSztDQUN6QztDQUNBLFNBQVMsVUFBVTtDQUNuQixPQUFPO0FBQ1I7OztBQzlDQSxTQUFTLGNBQWMsT0FBTztDQUM3QixNQUFNLFNBQVMsVUFBVTtDQUN6QixJQUFnQixPQUFPLFVBQVU7RUFDaEMsTUFBTSxXQUFXLGFBQWEsT0FBTyxPQUFPLFNBQVMsSUFBSSxDQUFDLENBQUMsU0FBUyxHQUFHLE9BQU8sT0FBTyxPQUFPLElBQUk7RUFDaEcsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksZUFBZTtHQUN6QyxtQkFBbUI7R0FDbkIsVUFBVSxPQUFPLGNBQWM7SUFDOUIsSUFBSSxXQUFXLEtBQUssR0FBRyxNQUFNLFVBQVUsT0FBTyxTQUFTO1NBQ2xELE1BQU07R0FDWjtHQUNBLGlCQUFpQixFQUFFLFlBQVk7SUFDOUIsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPLE1BQU0sV0FBVyxLQUFLO1NBQy9DLE1BQU07R0FDWjtHQUNBLFVBQVUsTUFBTTtFQUNqQixDQUFDO0NBQ0Y7Q0FDQSxNQUFNLFdBQVcsYUFBYSxZQUFZLE9BQU8sT0FBTyxXQUFXLGFBQWEsU0FBUyxRQUFRLEVBQUUsR0FBRyxZQUFZLE9BQU8sT0FBTyxNQUFNO0NBQ3RJLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGVBQWU7RUFDekMsbUJBQW1CO0VBQ25CLFVBQVUsT0FBTyxjQUFjO0dBQzlCLElBQUksV0FBVyxLQUFLLEdBQUcsTUFBTSxVQUFVLE9BQU8sU0FBUztRQUNsRCxNQUFNO0VBQ1o7RUFDQSxpQkFBaUIsRUFBRSxZQUFZO0dBQzlCLElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTyxNQUFNLFdBQVcsS0FBSztRQUMvQyxNQUFNO0VBQ1o7RUFDQSxVQUFVLE1BQU07Q0FDakIsQ0FBQztBQUNGO0FBQ0EsU0FBUyx3QkFBd0I7Q0FDaEMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksS0FBSyxFQUFFLFVBQVUsWUFBWSxDQUFDO0FBQzFEOzs7Ozs7QUNsQ0EsU0FBUyxXQUFXLEVBQUUsWUFBWTtDQUNqQyxNQUFNLFNBQVMsVUFBVTtDQUN6QixJQUFJLENBQWMsT0FBTyxVQUFXLE9BQU87Q0FDM0MsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksVUFBVTtFQUNwQyxPQUFPLE9BQU8sUUFBUSxLQUFLO0VBQzNCLHlCQUF5QixFQUFFLFFBQVEsV0FBVyxtQ0FBbUM7Q0FDbEYsQ0FBQztBQUNGOzs7Ozs7Ozs7OztBQ0RBLFNBQVMsb0JBQW9CLFFBQVEsT0FBTyxNQUFNO0NBQ2pELElBQUksQ0FBQyxNQUFNLFFBQVEsbUJBQW1CO0VBQ3JDLElBQUksT0FBTyxRQUFRLDBCQUVsQixPQUErQywrQkFBK0IsaUJBRHRDLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE9BQU8sUUFBUSwwQkFBMEIsRUFBRSxHQUFHLEtBQUssQ0FDakIsR0FBaUIsbUJBQW1CO0VBR2xILElBQUksQ0FBQyxNQUFNLFFBQVEsbUJBQW1CLFFBQVEsS0FBSyxrRUFBa0UsTUFBTSxHQUFHLG1QQUFtUDtFQUVsWCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSx1QkFBdUIsQ0FBQyxDQUFDO0NBQ3JEO0NBRUEsT0FBK0MsK0JBQStCLGlCQUR0QyxHQUFBLG1CQUFBLElBQUEsQ0FBSSxNQUFNLFFBQVEsbUJBQW1CLEVBQUUsR0FBRyxLQUFLLENBQ1QsR0FBaUIsbUJBQW1CO0FBQ25IOzs7QUN6QkEsU0FBUyxvQ0FBb0MsU0FBUztDQUNyRCxPQUFPO0FBQ1I7OztBQ0VBLFNBQVNDLHNCQUFvQjtDQUU1QixNQUFNLFNBQVMsb0NBREEsVUFDb0MsQ0FBTTtDQUN6RCxJQUFJLENBQUMsUUFBUSxPQUFPO0NBQ3BCLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFlBQVksRUFBRSxVQUFVLE9BQU8sQ0FBQztBQUM1RDs7O0FDS0EsU0FBUyxjQUFjLFFBQVEsT0FBTztDQUNyQyxNQUFNLG1CQUFtQixPQUFPLFFBQVEsb0JBQW9CLE9BQU8sUUFBUTtDQUMzRSxJQUFJLENBQUMsa0JBQWtCLE9BQU87Q0FFOUIsT0FBK0MsK0JBQStCLGlCQUFBLEdBRHZDQyxtQkFBQUEsSUFBQUEsQ0FBSSxrQkFBa0IsQ0FBQyxDQUM2QixHQUFHLGtCQUFrQjtBQUNqSDtBQUNBLElBQUksNkJBQTZCLEdBQUcsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFO0FBQ3RFLElBQUkscUJBQXFCLFFBQVEsT0FBTyxRQUFRLENBQUMsTUFBTSxVQUFVLE1BQU0sUUFBUSxrQkFBa0IsTUFBTSxRQUFRLGtCQUFrQixRQUFRLFNBQVMsUUFBUSxlQUFlLEVBQWUsT0FBTyxZQUFhLE9BQU87QUFDbk4sSUFBSSxRQUFBLGFBQWdCLEtBQUssU0FBUyxVQUFVLEVBQUUsV0FBVztDQUN4RCxNQUFNLFNBQVMsVUFBVTtDQUN6QixJQUFnQixPQUFPLFVBQVUsT0FBTyxVQUFVLFFBQVEsT0FBTyxPQUFPLFFBQVEsSUFBSSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUM7Q0FFbEcsT0FBTyxVQUFVLFFBQVEsWUFETixPQUFPLE9BQU8sY0FBYyxPQUNWLENBQVUsQ0FBQztBQUNqRCxDQUFDO0FBQ0QsU0FBUyxVQUFVLFFBQVEsT0FBTztDQUNqQyxNQUFNLFFBQVEsT0FBTyxXQUFXLE1BQU07Q0FDdEMsTUFBTSxpQkFBaUIsY0FBYyxRQUFRLEtBQUs7Q0FDbEQsTUFBTSxzQkFBc0IsTUFBTSxRQUFRLGtCQUFrQixPQUFPLFFBQVE7Q0FDM0UsTUFBTSxlQUFlLE1BQU0sUUFBUSxXQUFXLE9BQU8sUUFBUTtDQUM3RCxNQUFNLHlCQUF5QixNQUFNLFNBQVMsTUFBTSxRQUFRLHFCQUFxQixPQUFPLFFBQVEsZUFBZSxRQUFRLFlBQVksTUFBTSxRQUFRO0NBQ2pKLE1BQU0sZ0JBQWdCLE1BQU0sUUFBUSxTQUFTLE1BQU0sUUFBUTtDQUMzRCxNQUFNLGlCQUFpQixrQkFBa0IsUUFBUSxPQUFPLE1BQU0sR0FBRyxNQUFNLE1BQU0sUUFBUSxrQkFBa0IsbUJBQW1CLE1BQU0sUUFBUSxnQkFBZ0IsV0FBVztDQUNuSyxJQUFJLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFlBQVksRUFBRSxNQUFNLENBQUM7Q0FDdkQsSUFBSSxlQUFlLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFlBQVk7RUFDNUQsVUFBVTtFQUNWLFVBQVU7Q0FDWCxDQUFDO0NBQ0QsSUFBSSx3QkFBd0IsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksZUFBZTtFQUN4RSxXQUFXLFVBQVU7R0FDcEIsTUFBTSxZQUFZLE1BQU07R0FDeEIsSUFBSSxNQUFNLFlBQVksTUFBTSxTQUFTLE1BQU07R0FFM0MsT0FBK0MsK0JBRHpDLGFBQTBCLGNBQWMsd0JBQXdCLEtBQ1EsR0FBaUIsbUJBQW1CO0VBQ25IO0VBQ0EsVUFBVTtDQUNYLENBQUM7Q0FDRCxJQUFJLHFCQUFxQixVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxlQUFlO0VBQ3JFLG1CQUFtQjtFQUNuQixnQkFBZ0I7RUFDaEIsVUFBVSxPQUFPLGNBQWM7R0FDOUIsSUFBSSxXQUFXLEtBQUssR0FBRztJQUN0QixNQUFNLFlBQVksTUFBTTtJQUN4QixNQUFNO0dBQ1A7R0FDMkMsUUFBUSxLQUFLLGtDQUFrQyxNQUFNLElBQUk7R0FDcEcsZUFBZSxPQUFPLFNBQVM7RUFDaEM7RUFDQSxVQUFVO0NBQ1gsQ0FBQztDQUNELElBQUksZ0JBQWdCLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFBLGFBQVksVUFBVTtFQUNuRSxVQUFVO0VBQ1YsVUFBVTtDQUNYLENBQUM7Q0FDRCxNQUFNLG9CQUFpQyxPQUFPLFlBQWEsTUFBTSxhQUFhLE9BQUEsY0FBc0IsT0FBTyxRQUFRLG9CQUFvQyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSUMscUJBQW1CLENBQUMsQ0FBQyxJQUFJO0NBQ3BMLE1BQU0saUJBQWlCLE1BQU0sVUFBVSxNQUFNLFFBQVE7Q0FDckQsT0FBTyxpQkFBaUMsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksYUFBYSxVQUFVO0VBQ2xFLE9BQU8sTUFBTTtFQUNiLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFLLGdCQUFnQixFQUFFLFVBQVUsQ0FBQyxTQUFTLGlCQUFpQixFQUFFLENBQUM7Q0FDMUYsQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBSyxhQUFhLFVBQVU7RUFDaEQsT0FBTyxNQUFNO0VBQ2IsVUFBVSxDQUFDLFNBQVMsaUJBQWlCO0NBQ3RDLENBQUM7QUFDRjtBQUNBLElBQUksYUFBQSxhQUFxQixLQUFLLFNBQVMsZUFBZSxFQUFFLFNBQVM7Q0FDaEUsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxVQUFVLE1BQU07Q0FDdEIsTUFBTSxRQUFRLE9BQU8sV0FBVztDQUNoQyxNQUFNLE1BQUEsYUFBYyxjQUFjO0VBQ2pDLE1BQU0sZUFBZSxNQUFNLFFBQVEsZUFBZSxPQUFPLFFBQVEsbUJBQUEsR0FBc0I7R0FDdEY7R0FDQSxZQUFZLE1BQU07R0FDbEIsUUFBUSxNQUFNO0dBQ2QsUUFBUSxNQUFNO0VBQ2YsQ0FBQztFQUNELE9BQU8sY0FBYyxLQUFLLFVBQVUsV0FBVyxJQUFJLEtBQUs7Q0FDekQsR0FBRztFQUNGO0VBQ0EsTUFBTTtFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sTUFBTSxRQUFRO0VBQ2QsT0FBTyxRQUFRO0NBQ2hCLENBQUM7Q0FDRCxNQUFNLE1BQUEsYUFBYyxjQUFjO0VBQ2pDLE1BQU0sT0FBTyxNQUFNLFFBQVEsYUFBYSxPQUFPLFFBQVE7RUFDdkQsT0FBTyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxNQUFNLENBQUMsR0FBRyxHQUFHLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFFBQVEsQ0FBQyxDQUFDO0NBQ2xGLEdBQUc7RUFDRjtFQUNBLE1BQU0sUUFBUTtFQUNkLE9BQU8sUUFBUTtDQUNoQixDQUFDO0NBQ0QsSUFBSSxNQUFNLFdBQVcsV0FBVztFQUMvQixJQUFJLE9BQU8sT0FBTyxDQUFDLGtCQUFrQixRQUFRLE9BQU8sTUFBTSxHQUFHLEdBQUcsT0FBTztFQUN2RSxJQUFJLE9BQU8sS0FBSyxNQUFNLE9BQU8sSUFBSTtFQUNqQyxPQUFPLGNBQWMsUUFBUSxLQUFLO0NBQ25DO0NBQ0EsSUFBSSxNQUFNLFdBQVcsWUFBWSxPQUFPLG9CQUFvQixRQUFRLE9BQU8sTUFBTSxLQUFLO0NBQ3RGLElBQUksTUFBTSxXQUFXLFNBQVM7RUFDN0IsSUFBZ0IsT0FBTyxVQUFVO0dBQ2hDLE1BQU0sdUJBQXVCLE1BQU0sUUFBUSxrQkFBa0IsT0FBTyxRQUFRLDBCQUEwQjtHQU10RyxPQUErQywrQkFBK0IsaUJBTHpDLEdBQUEsbUJBQUEsSUFBQSxDQUFJLHFCQUFxQjtJQUM3RCxPQUFPLE1BQU07SUFDYixPQUFPLEtBQUs7SUFDWixNQUFNLEVBQUUsZ0JBQWdCLEdBQUc7R0FDNUIsQ0FDOEUsR0FBYyxnQkFBZ0I7RUFDN0c7RUFDQSxNQUFNLE1BQU07Q0FDYjtDQUNBLE9BQU87QUFDUixDQUFDOzs7Ozs7O0FBT0QsSUFBSSxTQUFBLGFBQWlCLEtBQUssU0FBUyxhQUFhO0NBQ0o7RUFDMUMsTUFBTSxvQkFBQSxhQUE0QixXQUFXLHdCQUF3QjtFQUNyRSxJQUFJLG1CQUFtQixRQUFRLEtBQUssZ0RBQWdELGtCQUFrQiwrREFBK0Q7Q0FDdEs7Q0FDQSxNQUFNLFNBQVMsVUFBVTtDQUN6QixNQUFNLFVBQUEsYUFBa0IsV0FBVyxZQUFZO0NBQy9DLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQWdCLE9BQU8sVUFBVTtFQUNoQyxNQUFNLFVBQVUsT0FBTyxPQUFPLFFBQVEsSUFBSTtFQUMxQyxNQUFNLGNBQWMsUUFBUSxXQUFXLFVBQVUsTUFBTSxZQUFZLE9BQU87RUFDMUUsTUFBTSxjQUFjLFFBQVE7RUFDNUIsdUJBQXVCLENBQUMsQ0FBQyxZQUFZO0VBQ3JDLHNCQUFzQixZQUFZO0VBQ2xDLGVBQWUsUUFBUSxjQUFjLEVBQUUsRUFBRTtDQUMxQyxPQUFPO0VBQ04sTUFBTSxtQkFBbUIsT0FBTyxPQUFPLGNBQWMsT0FBTztFQUM1RCxDQUFDLHNCQUFzQix1QkFBdUIsWUFBWSxtQkFBbUIsVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLFdBQVcsTUFBTSxLQUFLLEdBQUcsRUFBRSxTQUFTLDBCQUEwQixDQUFDO0VBQy9KLGVBQWUsWUFBWSxPQUFPLE9BQU8sTUFBTSxRQUFRO0dBQ3RELE9BQU8sSUFBSSxJQUFJLFFBQVEsT0FBTyxJQUFJO0VBQ25DLENBQUM7Q0FDRjtDQUNBLElBQUksc0JBQXNCLE9BQU8sb0JBQW9CLFFBQVEsT0FBTyxXQUFXLFVBQVUsbUJBQW1CO0NBQzVHLElBQUksQ0FBQyxjQUFjLE9BQU87Q0FDMUIsTUFBTSxZQUE0QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxPQUFPLEVBQUUsU0FBUyxhQUFhLENBQUM7Q0FDdEUsSUFBSSxZQUFBLFlBQXlCLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFBLGFBQVksVUFBVTtFQUN6RSxVQUFVLGNBQWMsTUFBTTtFQUM5QixVQUFVO0NBQ1gsQ0FBQztDQUNELE9BQU87QUFDUixDQUFDOzs7QUM5SkQsU0FBUyxZQUFZLE9BQU8sVUFBVTtDQUNyQyxNQUFNLFNBQVMsTUFBTTtDQUNyQixNQUFNLFNBQVM7Q0FDZixTQUFTLFFBQVE7QUFDbEI7QUFDQSxTQUFTLGFBQWEsRUFBRSxLQUFLO0NBQzVCLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sa0JBQWtCLE9BQU8sY0FBYyxDQUFDO0NBQzlDLE1BQU0sVUFBQSxhQUEwRCxPQUFPLEtBQUs7Q0FDNUUsT0FBTyxtQkFBbUIsSUFBSSxhQUFhLElBQUksU0FBUyxZQUFZO0VBQ25FLFlBQVksaUJBQWlCLEtBQUs7RUFDbEMsZ0JBQWdCLEtBQUssVUFBVSxPQUFPO0VBQ3RDLEVBQUUsTUFBTTtFQUNSLGFBQVEsZ0JBQWdCLEVBQUU7Q0FDM0IsQ0FBQztDQUNELHNCQUFzQjtFQUNyQixNQUFNLFFBQVEsT0FBTyxRQUFRLFVBQVUsT0FBTyxJQUFJO0VBQ2xELElBQUksU0FBUyxTQUFTLE9BQU87RUFDN0IsSUFBSSxTQUFTLFFBQVEsVUFBVTtFQUMvQixPQUFPLHFCQUFxQjtFQUM1QixNQUFNLFdBQVcsT0FBTztFQUN4QixNQUFNLGVBQWUsT0FBTyxjQUFjO0dBQ3pDLElBQUksU0FBUztHQUNiLFFBQVE7R0FDUixRQUFRO0dBQ1IsTUFBTTtHQUNOLE9BQU87R0FDUCx3QkFBd0I7RUFDekIsQ0FBQztFQUNELElBQUksY0FBYyxTQUFTLFVBQVUsTUFBTSxjQUFjLGFBQWEsVUFBVSxHQUFHO0dBQ2xGLE9BQU8sZUFBZTtJQUNyQixHQUFHO0lBQ0gsU0FBUztJQUNULGVBQWU7R0FDaEIsQ0FBQztHQUNELE9BQU87RUFDUjtFQUNBLE1BQU0sbUJBQW1CLE9BQU8sT0FBTyxpQkFBaUIsSUFBSTtFQUM1RCxJQUFJLGtCQUFrQixTQUFTLFNBQVMsUUFBUSxpQkFBaUIsTUFBTSxjQUFjLFNBQVMsTUFBTSxXQUFXLGdCQUFnQixLQUFLLE9BQU8sT0FBTyxRQUFRLElBQUksSUFBSSxhQUFhO0dBQzlLLElBQUksVUFBVSxPQUFPLEtBQUs7SUFDekIsTUFBTTtJQUNOLEdBQUcsc0JBQXNCLGtCQUFrQixnQkFBZ0I7R0FDNUQsQ0FBQztFQUNGLENBQUM7T0FDSSxJQUFJLENBQUMsT0FBTyxLQUFLLE9BQU8sS0FBSyxFQUFFLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLFFBQVEsS0FBSztFQUNyRSxPQUFPO0NBQ1IsR0FBRyxDQUFDLFFBQVEsT0FBTyxPQUFPLENBQUM7Q0FDM0IsT0FBTztBQUNSOzs7Ozs7O0FDcENBLFNBQVMsVUFBVTtDQUNsQixNQUFNLFNBQVMsVUFBVTtDQUN6QixNQUFNLFlBQVksT0FBTyxXQUFXO0NBQ3BDLE1BQU0saUJBQWlCLGNBQWMsUUFBUSxTQUFTO0NBQ3RELE1BQU0sUUFBd0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUtDLG1CQUFBQSxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQWMsT0FBTyxZQUE2QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxjQUFjLEVBQUUsR0FBQSxhQUFXLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFnQixPQUFPLFlBQWEsT0FBTyxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxjQUFjLENBQUMsQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBQSxhQUFZLFVBQVU7RUFDeFIsVUFBVTtFQUNWLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGNBQWMsQ0FBQyxDQUFDO0NBQy9DLENBQUMsQ0FBQyxFQUFFLENBQUM7Q0FDTCxPQUFPLE9BQU8sUUFBUSxZQUE0QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxPQUFPLFFBQVEsV0FBVyxFQUFFLFVBQVUsTUFBTSxDQUFDLElBQUk7QUFDeEc7QUFDQSxTQUFTLGVBQWU7Q0FDdkIsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxrQkFBa0IsT0FBTztDQUMvQixNQUFNLFVBQXNCLE9BQU8sV0FBVyxPQUFPLE9BQU8sUUFBUSxJQUFJLElBQUksWUFBWSxPQUFPLE9BQU8sVUFBVSxVQUFVLGdCQUFnQixNQUFNLEtBQUs7Q0FDckosTUFBTSxRQUFRLFFBQVE7Q0FDdEIsTUFBTSxVQUFVLE9BQU87Q0FDdkIsc0JBQXNCO0VBQ3JCLElBQUksZ0JBQWdCLE9BQU8sU0FBUyxZQUFZLGlCQUFpQixJQUFJO0NBQ3RFLEdBQUcsQ0FBQyxpQkFBaUIsT0FBTyxDQUFDO0NBQzdCLE1BQU0saUJBQWlCLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE9BQU8sRUFBRSxRQUFRLENBQUMsSUFBSTtDQUMzRSxPQUFPLE9BQU8sUUFBUSw2QkFBNkIsaUJBQWlDLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGVBQWU7RUFDdEcsbUJBQW1CO0VBQ25CLFVBQWtELFVBQVU7R0FDM0QsUUFBUSxLQUFLLHFJQUFxSTtHQUNsSixRQUFRLEtBQUssWUFBWSxLQUFLO0VBQy9CO0VBQ0EsVUFBVTtDQUNYLENBQUM7QUFDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsU0FBUyxnQkFBZ0I7Q0FDeEIsTUFBTSxTQUFTLFVBQVU7Q0FDekIsSUFBZ0IsT0FBTyxVQUFVLFFBQVEsU0FBUztFQUNqRCxNQUFNLEVBQUUsU0FBUyxlQUFlLE9BQU8sZUFBZSxHQUFHLFNBQVM7RUFDbEUsT0FBTyxPQUFPLFdBQVcsTUFBTTtHQUM5QjtHQUNBO0dBQ0E7R0FDQTtFQUNELENBQUM7Q0FDRjtDQUNBLE9BQUEsYUFBZSxhQUFhLFNBQVM7RUFDcEMsTUFBTSxFQUFFLFNBQVMsZUFBZSxPQUFPLGVBQWUsR0FBRyxTQUFTO0VBQ2xFLE9BQU8sT0FBTyxXQUFXLE1BQU07R0FDOUI7R0FDQTtHQUNBO0dBQ0E7RUFDRCxDQUFDO0NBQ0YsR0FBRztFQUNGO0VBQ0EsWUFBWSxPQUFPLE9BQU8sV0FBVyxhQUFhLFNBQVMsSUFBSTtFQUMvRCxZQUFZLE9BQU8sT0FBTyxtQkFBbUIsYUFBYSxVQUFVLElBQUk7RUFDeEUsWUFBWSxPQUFPLE9BQU8sTUFBTTtDQUNqQyxDQUFDO0FBQ0Y7Ozs7Ozs7O0FBUUEsU0FBUyxXQUFXLE9BQU87Q0FDMUIsTUFBTSxTQUFTLGNBQWMsQ0FBQyxDQUFDLEtBQUs7Q0FDcEMsSUFBSSxPQUFPLE1BQU0sYUFBYSxZQUFZLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDdEUsT0FBTyxTQUFTLE1BQU0sV0FBVztBQUNsQztBQUNBLFNBQVMsV0FBVyxNQUFNO0NBQ3pCLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLElBQWdCLE9BQU8sVUFBVTtFQUNoQyxNQUFNLFVBQVUsT0FBTyxPQUFPLFFBQVEsSUFBSTtFQUMxQyxPQUFPLE1BQU0sU0FBUyxLQUFLLE9BQU8sT0FBTyxJQUFJO0NBQzlDO0NBQ0EsT0FBTyxZQUFZLE9BQU8sT0FBTyxTQUFTLHFCQUFxQixNQUFNLE1BQU0sQ0FBQztBQUM3RTs7Ozs7QUFLQSxTQUFTLGlCQUFpQixNQUFNO0NBQy9CLE1BQU0saUJBQUEsYUFBeUIsV0FBVyxZQUFZO0NBQ3RELE9BQU8sV0FBVztFQUNqQixTQUFTLFlBQVk7R0FDcEIsVUFBVSxRQUFRLE1BQU0sR0FBRyxRQUFRLFdBQVcsTUFBTSxFQUFFLFlBQVksY0FBYyxDQUFDO0dBQ2pGLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxPQUFPLElBQUk7RUFDOUM7RUFDQSxtQkFBbUIsTUFBTTtDQUMxQixDQUFDO0FBQ0Y7Ozs7O0FBS0EsU0FBUyxnQkFBZ0IsTUFBTTtDQUM5QixNQUFNLGlCQUFBLGFBQXlCLFdBQVcsWUFBWTtDQUN0RCxPQUFPLFdBQVc7RUFDakIsU0FBUyxZQUFZO0dBQ3BCLFVBQVUsUUFBUSxNQUFNLFFBQVEsV0FBVyxNQUFNLEVBQUUsWUFBWSxjQUFjLElBQUksQ0FBQztHQUNsRixPQUFPLE1BQU0sU0FBUyxLQUFLLE9BQU8sT0FBTyxJQUFJO0VBQzlDO0VBQ0EsbUJBQW1CLE1BQU07Q0FDMUIsQ0FBQztBQUNGOzs7QUNwSUEsSUFBSSxtQkFBbUIsU0FBUztDQUMvQixJQUFnQixLQUFLLFVBQVUsT0FBTztFQUNyQyxvQkFBb0I7RUFDcEIscUJBQXFCO0VBQ3JCLFFBQVEsT0FBTyxHQUFHO0NBQ25CO0NBQ0EsT0FBTztFQUNOLG9CQUFvQjtFQUNwQixxQkFBcUI7RUFDckI7Q0FDRDtBQUNEOzs7Ozs7Ozs7Ozs7OztBQ0RBLElBQUksZ0JBQWdCLFlBQVk7Q0FDL0IsT0FBTyxJQUFJLE9BQU8sT0FBTztBQUMxQjtBQUNBLElBQUksU0FBUyxjQUFjLFdBQVc7Q0FDckMsWUFBWSxTQUFTO0VBQ3BCLE1BQU0sU0FBUyxlQUFlO0NBQy9CO0FBQ0Q7Ozs7Ozs7QUNWQSxTQUFTLHNCQUFzQixFQUFFLFFBQVEsVUFBVSxHQUFHLFFBQVE7Q0FDN0QsSUFBSSxRQUFRLElBQUksR0FBRyxPQUFPLE9BQU87RUFDaEMsR0FBRyxPQUFPO0VBQ1YsR0FBRztFQUNILFNBQVM7R0FDUixHQUFHLE9BQU8sUUFBUTtHQUNsQixHQUFHLEtBQUs7RUFDVDtDQUNELENBQUM7Q0FDRCxNQUFNLFdBQTJCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGNBQWMsVUFBVTtFQUM1RCxPQUFPO0VBQ1A7Q0FDRCxDQUFDO0NBQ0QsSUFBSSxPQUFPLFFBQVEsTUFBTSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxPQUFPLFFBQVEsTUFBTSxFQUFFLFVBQVUsU0FBUyxDQUFDO0NBQy9GLE9BQU87QUFDUjs7Ozs7Ozs7OztBQVVBLFNBQVMsZUFBZSxFQUFFLFFBQVEsR0FBRyxRQUFRO0NBQzVDLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLHVCQUF1QjtFQUNqRDtFQUNBLEdBQUc7RUFDSCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxTQUFTLENBQUMsQ0FBQztDQUMxQyxDQUFDO0FBQ0Y7OztBQ3ZDQSxTQUFTLHVCQUF1QjtDQUUvQix1QkFEZSxVQUNRLEdBQVEsSUFBSTtBQUNwQzs7OztBQUlBLFNBQVMsa0JBQWtCLFFBQVE7Q0FDbEMscUJBQXFCO0NBQ3VCLFFBQVEsS0FBSyx1R0FBdUc7Q0FDaEssT0FBTztBQUNSO0FBQ0EsU0FBUyw0QkFBNEIsU0FBUztDQUM3QyxxQkFBcUI7Q0FDckIsT0FBTyxpQ0FBaUMsVUFBVSxHQUFHLE9BQU87QUFDN0Q7OztBQ2RBLFNBQVMsb0JBQW9CLE1BQU0sV0FBVztDQUM3QyxJQUFJLFNBQVMsS0FBSyxHQUFHLE9BQU87RUFDM0IscUJBQXFCO0VBQ3JCLGNBQWM7Q0FDZjtDQUNBLElBQUksbUJBQW1CLE1BQU0sT0FBTztDQUNwQyxJQUFJLE9BQU8sU0FBUyxZQUFZO0VBQy9CLE1BQU0sY0FBYyxRQUFRLGFBQWEsSUFBSTtFQUM3QyxNQUFNLG1CQUFtQixZQUFZO0dBQ3BDLElBQUksYUFBYSxPQUFPLE1BQU0sS0FBSztHQUNuQyxPQUFPO0VBQ1I7RUFDQSxPQUFPO0dBQ04sZUFBZTtHQUNmLG9CQUFvQjtHQUNwQixjQUFjO0VBQ2Y7Q0FDRDtDQUNBLE1BQU0sY0FBYyxRQUFRLEtBQUssYUFBYSxJQUFJO0NBQ2xELE1BQU0sS0FBSyxLQUFLO0NBQ2hCLE1BQU0sbUJBQW1CLFlBQVk7RUFDcEMsSUFBSSxlQUFlLE9BQU8sS0FBSyxHQUFHLE9BQU8sTUFBTSxHQUFHO0VBQ2xELE9BQU87Q0FDUjtDQUNBLE9BQU87RUFDTixlQUFlO0VBQ2Ysb0JBQW9CO0VBQ3BCLGNBQWMsT0FBTyxLQUFLO0NBQzNCO0FBQ0Q7QUFDQSxTQUFTLFdBQVcsTUFBTSxXQUFXO0NBQ3BDLE1BQU0sRUFBRSxlQUFlLHFCQUFxQixNQUFNLFdBQVcsT0FBTyxlQUFlLFVBQVUsb0JBQW9CLE1BQU0sU0FBUztDQUNoSSxNQUFNLFNBQVMsVUFBVTtDQUN6QixNQUFNLEVBQUUsWUFBWTtDQUNwQixNQUFNLENBQUMsVUFBVSxlQUFBLGFBQXVCLFNBQVM7RUFDaEQsUUFBUTtFQUNSLFNBQVMsS0FBSztFQUNkLE1BQU0sS0FBSztFQUNYLFFBQVEsS0FBSztFQUNiLFNBQVMsS0FBSztFQUNkLE9BQU8sS0FBSztDQUNiLENBQUM7Q0FDRCxhQUFRLGdCQUFnQjtFQUN2QixNQUFNLG9CQUFvQixPQUFPLGtCQUFrQjtHQUNsRCxTQUFTLFlBQVksVUFBVTtJQUM5QixNQUFNLGlCQUFpQixPQUFPLGNBQWMsUUFBUTtJQUNwRCxNQUFNLEdBQUcsV0FBVyxjQUFjLE9BQU8saUJBQWlCLGVBQWUsUUFBUTtJQUNqRixJQUFJLGVBQWUsS0FBSyxHQUFHLE9BQU87S0FDakMsU0FBUztLQUNULFVBQVUsZUFBZTtLQUN6QixVQUFVLGVBQWU7S0FDekIsUUFBUTtLQUNSLFFBQVEsT0FBTyxRQUFRLFlBQVksU0FBUyxNQUFNO0lBQ25EO0lBQ0EsT0FBTztLQUNOLFNBQVMsV0FBVztLQUNwQixVQUFVLFdBQVc7S0FDckIsVUFBVSxlQUFlO0tBQ3pCLFFBQVE7S0FDUixRQUFRLE9BQU8sUUFBUSxZQUFZLFNBQVMsTUFBTTtJQUNuRDtHQUNEO0dBQ0EsTUFBTSxVQUFVLFlBQVksY0FBYyxlQUFlO0dBQ3pELE1BQU0sT0FBTyxZQUFZLGNBQWMsWUFBWTtHQUNuRCxJQUFJLFFBQVEsWUFBWSxrQkFBa0IsS0FBSyxZQUFZLGdCQUFnQixPQUFPO0dBQ2xGLE1BQU0sY0FBYyxNQUFNLGNBQWM7SUFDdkMsUUFBUSxjQUFjO0lBQ3RCO0lBQ0E7R0FDRCxDQUFDO0dBQ0QsSUFBSSxDQUFDLGNBQWMsT0FBTztHQUMxQixJQUFJLENBQUMsYUFBYSxPQUFPO0dBQ3pCLE1BQU0sbUJBQW1CLE1BQU0sSUFBSSxTQUFTLFlBQVk7SUFDdkQsWUFBWTtLQUNYLFFBQVE7S0FDUjtLQUNBO0tBQ0EsUUFBUSxjQUFjO0tBQ3RCLGVBQWUsUUFBUSxLQUFLO0tBQzVCLGFBQWEsUUFBUSxJQUFJO0lBQzFCLENBQUM7R0FDRixDQUFDO0dBQ0QsWUFBWTtJQUNYLFFBQVE7SUFDUixTQUFTLEtBQUs7SUFDZCxNQUFNLEtBQUs7SUFDWCxRQUFRLEtBQUs7SUFDYixTQUFTLEtBQUs7SUFDZCxPQUFPLEtBQUs7R0FDYixDQUFDO0dBQ0QsT0FBTztFQUNSO0VBQ0EsT0FBTyxXQUFXLEtBQUssSUFBSSxRQUFRLE1BQU07R0FDeEMsV0FBVztHQUNYO0VBQ0QsQ0FBQztDQUNGLEdBQUc7RUFDRjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsT0FBTztBQUNSO0FBQ0EsSUFBSSw2QkFBNkIsVUFBVTtDQUMxQyxJQUFJLG1CQUFtQixPQUFPLE9BQU8sRUFBRSxHQUFHLE1BQU07Q0FDaEQsTUFBTSxjQUFjLFFBQVEsTUFBTSxhQUFhLElBQUk7Q0FDbkQsTUFBTSxLQUFLLE1BQU07Q0FDakIsTUFBTSxtQkFBbUIsWUFBWTtFQUNwQyxJQUFJLGVBQWUsT0FBTyxLQUFLLEdBQUcsT0FBTyxNQUFNLEdBQUc7RUFDbEQsT0FBTztDQUNSO0NBQ0EsT0FBTztFQUNOLGVBQWU7RUFDZixvQkFBb0I7RUFDcEIsY0FBYyxPQUFPLEtBQUs7Q0FDM0I7QUFDRDtBQUNBLFNBQVMsTUFBTSxNQUFNO0NBQ3BCLE1BQU0sRUFBRSxVQUFVLEdBQUcsU0FBUztDQUM5QixNQUFNLFdBQVcsV0FBVywwQkFBMEIsSUFBSSxDQUFDO0NBQzNELE9BQU8sV0FBVyxPQUFPLGFBQWEsYUFBYSxTQUFTLFFBQVEsSUFBSSxXQUFXO0FBQ3BGOzs7Ozs7Ozs7Ozs7Ozs7QUM5R0EsU0FBUyxlQUFlLE1BQU07Q0FDN0IsTUFBTSxnQkFBZ0IsVUFBVSxFQUFFLE1BQU0sTUFBTSxXQUFXLEtBQUssRUFBRSxDQUFDO0NBQ2pFLE1BQU0sU0FBUyxNQUFNLFVBQVU7Q0FDL0IsSUFBZ0IsT0FBTyxVQUFVO0VBQ2hDLE1BQU0sUUFBUSxPQUFPLE9BQU8sUUFBUSxJQUFJO0VBQ3hDLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxLQUFLLElBQUk7Q0FDNUM7Q0FDQSxPQUFPLFlBQVksT0FBTyxPQUFPLFNBQVMscUJBQXFCLE1BQU0sTUFBTSxDQUFDO0FBQzdFOzs7Ozs7Ozs7Ozs7OztBQ1RBLFNBQVMsWUFBWSxNQUFNO0NBQzFCLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLElBQWdCLE9BQU8sVUFBVTtFQUNoQyxNQUFNLFdBQVcsT0FBTyxPQUFPLFNBQVMsSUFBSTtFQUM1QyxPQUFPLE1BQU0sU0FBUyxLQUFLLE9BQU8sUUFBUSxJQUFJO0NBQy9DO0NBQ0EsT0FBTyxZQUFZLE9BQU8sT0FBTyxVQUFVLHFCQUFxQixNQUFNLE1BQU0sQ0FBQztBQUM5RTs7O0FDcEJBLFNBQVMsZUFBZTtDQUN2QixNQUFNLFNBQVMsVUFBVTtDQUN6QixJQUFnQixPQUFPLFVBQVUsT0FBTyxPQUFPLE9BQU8sU0FBUyxJQUFJLENBQUMsQ0FBQyxNQUFNLGdCQUFnQjtDQUMzRixPQUFPLFlBQVksT0FBTyxPQUFPLFdBQVcsYUFBYSxTQUFTLE1BQU0sZ0JBQWdCLENBQUM7QUFDMUY7OztBQ0RBLElBQUksNEJBQTRCO0FBQ2hDLElBQUksMEJBQTBCLENBQUM7QUFDL0IsU0FBUyxlQUFlLFFBQVEsT0FBTztDQUN0QyxJQUFJLENBQUMsT0FBTztDQUNaLEtBQUssTUFBTSxDQUFDLEtBQUssVUFBVSxPQUFPLFFBQVEsS0FBSyxHQUFHLElBQUksUUFBUSw4QkFBOEIsVUFBVSxLQUFLLEtBQUssVUFBVSxPQUFPLE9BQU8sYUFBYSxLQUFLLE9BQU8sVUFBVSxZQUFZLEtBQUssT0FBTyxLQUFLLENBQUM7QUFDMU07QUFDQSxTQUFTLE1BQU0sT0FBTztDQUNyQixNQUFNLEVBQUUsT0FBTyxVQUFVLE9BQU8sdUJBQXVCO0NBQ3ZELE1BQU0sWUFBQSxhQUFvQixjQUFjLGFBQWEsS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFFLFFBQVEsU0FBUyxHQUFHLENBQUMsUUFBUSxDQUFDO0NBQ3ZHLFFBQVEsTUFBTSxLQUFkO0VBQ0MsS0FBSyxTQUFTLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFNBQVM7R0FDakQsR0FBRztHQUNILDBCQUEwQjtHQUMxQjtFQUNELENBQUM7RUFDRCxLQUFLLFFBQVEsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksUUFBUTtHQUMvQyxHQUFHO0dBQ0gsMEJBQTBCO0VBQzNCLENBQUM7RUFDRCxLQUFLLFFBQVEsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksUUFBUTtHQUMvQyxHQUFHO0dBQ0gsWUFBWSxPQUFPLGVBQWUsT0FBTyxRQUFRLGVBQWUsWUFBWSxLQUFLO0dBQ2pGO0dBQ0EsMEJBQTBCO0VBQzNCLENBQUM7RUFDRCxLQUFLO0dBQ0osSUFBSSxNQUFNLGNBQWMsUUFBUSxJQUFJLDJCQUEyQixVQUFVLFFBQVEsSUFBSSwyQkFBMkIsS0FBSyxLQUFBLEtBQUEsSUFBZ0IsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksZ0JBQWdCO0lBQy9LO0lBQ0E7SUFDQTtHQUNELENBQUM7R0FDRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxTQUFTO0lBQ25DLEdBQUc7SUFDSCx5QkFBeUI7SUFDekI7R0FDRCxDQUFDO0VBQ0YsS0FBSyxVQUFVLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFFBQVE7R0FDakQ7R0FDQTtHQUNBO0VBQ0QsQ0FBQztFQUNELFNBQVMsT0FBTztDQUNqQjtBQUNEO0FBQ0EsU0FBUyxlQUFlLEVBQUUsT0FBTyxVQUFVLFNBQVM7Q0FDbkQsTUFBTSx5QkFBeUIsYUFBYSxLQUFLO0NBQ2pELE1BQU0sQ0FBQyxxQkFBQSxhQUE2QixlQUFlO0VBQ2xELElBQUksQ0FBQywwQkFBMEIsT0FBTyxhQUFhLGFBQWE7RUFDaEUsT0FBTyxTQUFTLGNBQWMsU0FBUywwQkFBMEIsRUFBRSxDQUFDLEVBQUUsZUFBZSxLQUFLO0NBQzNGLENBQUM7Q0FDRCxNQUFNLE9BQU8seUJBQXlCLHFCQUFxQixLQUFLLFlBQVk7Q0FDNUUsTUFBTSxZQUFBLGFBQW9CLGVBQWUsRUFBRSxRQUFRLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQztDQUNsRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxTQUFTO0VBQ25DLEdBQUc7R0FDRiw0QkFBNEI7RUFDN0IseUJBQXlCO0VBQ3pCO0VBQ0EsMEJBQTBCO0NBQzNCLENBQUM7QUFDRjtBQUNBLFNBQVMsT0FBTyxFQUFFLE9BQU8sVUFBVSxzQkFBc0I7Q0FDeEQsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxZQUFBLGFBQW9CLGNBQWMsYUFBYSxLQUFLLElBQUksS0FBSyxJQUFJLEVBQUUsUUFBUSxTQUFTLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FDdkcsTUFBTSxhQUFhLE9BQU8sT0FBTyxTQUFTLFlBQVksTUFBTSxTQUFTLE1BQU0sTUFBTSxTQUFTLHFCQUFxQixNQUFNLFNBQVM7Q0FDOUgsSUFBNkMsT0FBTyxPQUFPLE9BQU8sYUFBYSxZQUFZLFNBQVMsS0FBSyxDQUFDLENBQUMsUUFBUSxRQUFRLEtBQUssMklBQTJJO0NBQzNRLGFBQVEsZ0JBQWdCO0VBQ3ZCLElBQUksWUFBWTtFQUNoQixJQUFJLE9BQU8sS0FBSztHQUNmLE1BQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztHQUN2QyxLQUFLLE9BQU8sTUFBTTtHQUNsQixNQUFNLFVBQVUsS0FBSztHQUNyQixLQUFLLE1BQU0sTUFBTSxTQUFTLFNBQVMsSUFBSSxHQUFHLFFBQVEsU0FBUztHQUMzRCxNQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7R0FDOUMsZUFBZSxRQUFRLEtBQUs7R0FDNUIsU0FBUyxLQUFLLFlBQVksTUFBTTtHQUNoQyxhQUFhLE9BQU8sT0FBTztFQUM1QjtFQUNBLElBQUksT0FBTyxhQUFhLFVBQVU7R0FDakMsTUFBTSxXQUFXLE9BQU8sT0FBTyxTQUFTLFdBQVcsTUFBTSxPQUFPO0dBQ2hFLE1BQU0sWUFBWSxPQUFPLE9BQU8sVUFBVSxXQUFXLE1BQU0sUUFBUSxLQUFLO0dBQ3hFLEtBQUssTUFBTSxNQUFNLFNBQVMsU0FBUztJQUNsQyxJQUFJLEdBQUcsYUFBYSxLQUFLLEdBQUc7SUFDNUIsTUFBTSxRQUFRLEdBQUcsYUFBYSxNQUFNLEtBQUs7SUFDekMsTUFBTSxTQUFTLEdBQUcsYUFBYSxPQUFPLEtBQUssS0FBSztJQUNoRCxJQUFJLEdBQUcsZ0JBQWdCLFlBQVksVUFBVSxZQUFZLFdBQVcsV0FBVztHQUNoRjtHQUNBLE1BQU0sU0FBUyxTQUFTLGNBQWMsUUFBUTtHQUM5QyxPQUFPLGNBQWM7R0FDckIsZUFBZSxRQUFRLEtBQUs7R0FDNUIsU0FBUyxLQUFLLFlBQVksTUFBTTtHQUNoQyxhQUFhLE9BQU8sT0FBTztFQUM1QjtDQUNELEdBQUc7RUFDRjtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsSUFBZ0IsT0FBTyxVQUFVO0VBQ2hDLElBQUksT0FBTyxLQUFLO0dBQ2YsSUFBSSxDQUFDLG9CQUFvQixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0lBQzdELEdBQUc7SUFDSCwwQkFBMEI7R0FDM0IsQ0FBQztHQUNELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVU7SUFDcEMsR0FBRztJQUNILFFBQVE7SUFDUiwwQkFBMEI7R0FDM0IsQ0FBQztFQUNGO0VBQ0EsSUFBSSxPQUFPLGFBQWEsVUFBVSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0dBQ3RFLEdBQUc7R0FDSCx5QkFBeUI7R0FDekIsMEJBQTBCO0VBQzNCLENBQUM7RUFDRCxPQUFPO0NBQ1I7Q0FDQSxJQUFJLGNBQWMsT0FBTyxhQUFhLFVBQVUsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksVUFBVTtFQUNwRixHQUFHO0VBQ0gsMEJBQTBCO0VBQzFCLHlCQUF5QjtDQUMxQixDQUFDO0NBQ0QsSUFBSSxDQUFDLFVBQVU7RUFDZCxJQUFJLE9BQU8sS0FBSyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0dBQ3BELEdBQUc7R0FDSCwwQkFBMEI7RUFDM0IsQ0FBQztFQUNELElBQUksT0FBTyxhQUFhLFVBQVUsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksVUFBVTtHQUN0RSxHQUFHO0dBQ0gseUJBQXlCO0dBQ3pCLDBCQUEwQjtFQUMzQixDQUFDO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1I7OztBQ3ZJQSxTQUFTLHFCQUFxQixRQUFRLE9BQU8sU0FBUyxrQkFBa0I7Q0FDdkUsVUFBVSxpQkFBaUIsT0FBTztDQUNsQyxNQUFNLFlBQVksUUFBUSxLQUFLLFVBQVUsTUFBTSxJQUFJLENBQUMsQ0FBQyxRQUFRLFNBQVMsU0FBUyxLQUFLLENBQUM7Q0FDckYsTUFBTSxhQUFhLENBQUM7Q0FDcEIsTUFBTSxrQkFBa0IsQ0FBQztDQUN6QixJQUFJO0NBQ0osS0FBSyxJQUFJLElBQUksVUFBVSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7RUFDL0MsTUFBTSxRQUFRLFVBQVU7RUFDeEIsS0FBSyxJQUFJLElBQUksTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7R0FDM0MsTUFBTSxJQUFJLE1BQU07R0FDaEIsSUFBSSxDQUFDLEdBQUc7R0FDUixJQUFJLEVBQUUsT0FDRDtRQUFBLENBQUMsT0FBTyxRQUFRO0tBQ25CLEtBQUs7S0FDTCxVQUFVLEVBQUU7SUFDYjtHQUFBLE9BQ00sSUFBSSxvQkFBb0IsR0FBRyxJQUFJO0lBQ3JDLE1BQU0sT0FBTyxLQUFLLFVBQVUsRUFBRSxpQkFBaUI7SUFDL0MsV0FBVyxLQUFLO0tBQ2YsS0FBSztLQUNMLE9BQU8sRUFBRSxNQUFNLHNCQUFzQjtLQUNyQyxVQUFVLFdBQVcsSUFBSTtJQUMxQixDQUFDO0dBQ0YsUUFBUSxDQUFDO1FBQ0o7SUFDSixNQUFNLFlBQVksRUFBRSxRQUFRLEVBQUU7SUFDOUIsSUFBSSxXQUFXO0tBQ2QsSUFBSSxnQkFBZ0IsWUFBWTtVQUMzQixnQkFBZ0IsYUFBYTtJQUNuQztJQUNBLFdBQVcsS0FBSztLQUNmLEtBQUs7S0FDTCxPQUFPO01BQ04sR0FBRztNQUNIO0tBQ0Q7SUFDRCxDQUFDO0dBQ0Y7RUFDRDtDQUNEO0NBQ0EsSUFBSSxPQUFPLFdBQVcsS0FBSyxLQUFLO0NBQ2hDLElBQUksT0FBTyxXQUFXLEtBQUs7RUFDMUIsS0FBSztFQUNMLE9BQU87R0FDTixVQUFVO0dBQ1YsU0FBUztFQUNWO0NBQ0QsQ0FBQztDQUNELFdBQVcsUUFBUTtDQUNuQixNQUFNLG1CQUFtQixRQUFRLFNBQVMsVUFBVSxNQUFNLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLFNBQVMsU0FBUyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssVUFBVTtFQUN2SCxLQUFLO0VBQ0wsT0FBTztHQUNOLEdBQUc7R0FDSDtFQUNEO0NBQ0QsRUFBRTtDQUNGLE1BQU0sV0FBVyxPQUFPLEtBQUs7Q0FDN0IsTUFBTSxrQkFBa0IsQ0FBQztDQUN6QixJQUFJLFVBQVU7RUFDYixRQUFRLFNBQVMsVUFBVTtHQUMxQixDQUFDLFNBQVMsT0FBTyxNQUFNLFFBQVEsRUFBRSxJQUFBLEVBQU0sU0FBUyxTQUFTO0lBQ3hELE1BQU0sZUFBZSx1QkFBdUIsSUFBSTtJQUNoRCxnQkFBZ0IsS0FBSztLQUNwQixLQUFLO0tBQ0wsT0FBTztNQUNOLEtBQUs7TUFDTCxHQUFHO01BQ0gsYUFBYSxvQkFBb0Isa0JBQWtCLFlBQVksS0FBSyxhQUFhO01BQ2pGLDBCQUEwQjtNQUMxQjtLQUNEO0lBQ0QsQ0FBQztHQUNGLENBQUM7RUFDRixDQUFDO0VBQ0QsSUFBSSxTQUFTLGFBQWEsZ0JBQWdCLEtBQUs7R0FDOUMsS0FBSztHQUNMLE9BQU87SUFDTixHQUFHLFNBQVMsWUFBWTtJQUN4QjtHQUNEO0dBQ0EsVUFBVSxTQUFTLFlBQVk7R0FDL0IsV0FBVztFQUNaLENBQUM7Q0FDRjtDQUNBLE1BQU0sZUFBZSxDQUFDO0NBQ3RCLElBQUksVUFBVSxRQUFRLFNBQVMsVUFBVTtFQUN4QyxTQUFTLE9BQU8sTUFBTSxRQUFRLEVBQUUsVUFBVSxTQUFTLFlBQVk7R0FDOUQsYUFBYSxLQUFLO0lBQ2pCLEtBQUs7SUFDTCxPQUFPO0tBQ04sR0FBRyxzQkFBc0IsVUFBVSxTQUFTLGdCQUFnQjtLQUM1RDtJQUNEO0dBQ0QsQ0FBQztFQUNGLENBQUM7Q0FDRixDQUFDO0NBQ0QsTUFBTSxTQUFTLFFBQVEsU0FBUyxVQUFVLE1BQU0sVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsVUFBVSxVQUFVLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLFVBQVUsR0FBRyxhQUFhO0VBQ2xJLEtBQUs7RUFDTCxPQUFPO0dBQ04sR0FBRztHQUNIO0VBQ0Q7RUFDQTtDQUNELEVBQUU7Q0FDRixNQUFNLGNBQWMsUUFBUSxTQUFTLFVBQVUsTUFBTSxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxXQUFXLFdBQVcsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsVUFBVSxHQUFHLGNBQWM7RUFDL0ksS0FBSztFQUNMLE9BQU87R0FDTixHQUFHO0dBQ0g7RUFDRDtFQUNBO0NBQ0QsRUFBRTtDQUNGLE1BQU0sT0FBTyxDQUFDO0NBQ2QscUJBQXFCLE1BQU0sVUFBVTtDQUNyQyxLQUFLLEtBQUssR0FBRyxZQUFZO0NBQ3pCLHFCQUFxQixNQUFNLGdCQUFnQjtDQUMzQyxLQUFLLEtBQUssR0FBRyxlQUFlO0NBQzVCLHFCQUFxQixNQUFNLE1BQU07Q0FDakMscUJBQXFCLE1BQU0sV0FBVztDQUN0QyxPQUFPO0FBQ1I7Ozs7O0FBS0EsSUFBSSxXQUFXLHFCQUFxQjtDQUNuQyxNQUFNLFNBQVMsVUFBVTtDQUN6QixNQUFNLFFBQVEsT0FBTyxRQUFRLEtBQUs7Q0FDbEMsSUFBZ0IsT0FBTyxVQUFVLE9BQU8scUJBQXFCLFFBQVEsT0FBTyxPQUFPLE9BQU8sUUFBUSxJQUFJLEdBQUcsZ0JBQWdCO0NBQ3pILE1BQU0sYUFBQSxhQUFxQixhQUFhLFlBQVkscUJBQXFCLFFBQVEsT0FBTyxTQUFTLGdCQUFnQixHQUFHO0VBQ25IO0VBQ0E7RUFDQTtDQUNELENBQUM7Q0FDRCxPQUFPLFlBQVksT0FBTyxPQUFPLFNBQVMsWUFBWSxFQUFFLFNBQVMsVUFBVSxDQUFDO0FBQzdFOzs7QUNySUEsSUFBSSxtQkFBbUIsRUFBRSwwQkFBMEIsS0FBSzs7Ozs7O0FBTXhELElBQUksZ0JBQWdCO0NBQ25CLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sUUFBUSxPQUFPLFFBQVEsS0FBSztDQUNsQyxNQUFNLFlBQVksWUFBWTtFQUM3QixNQUFNLFFBQVEsc0JBQXNCLFNBQVMsT0FBTyxLQUFLLFVBQVUsT0FBTyxnQkFBZ0I7RUFDMUYsS0FBSyxNQUFNLFVBQVUsTUFBTSxJQUFJLElBQUksT0FBTyxPQUFPLE9BQU8sUUFBUSxVQUFVO0dBQ3pFLE1BQU0sa0JBQWtCO0dBQ3hCLGdCQUFnQixxQkFBcUI7RUFDdEM7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxNQUFNLGNBQWMsWUFBWTtFQUMvQixPQUFPLHNCQUFzQixTQUFTLE9BQU8sQ0FBQztDQUMvQztDQUNBLElBQWdCLE9BQU8sVUFFdEIsT0FBTyxjQUFjLHNCQUFzQixTQURyQixPQUFPLE9BQU8sUUFBUSxJQUNRLENBQWEsR0FBRyxPQUFPLFdBQVcsK0JBQStCLENBQUMsQ0FBQztDQUV4SCxPQUFPLGNBQWMsWUFBWSxPQUFPLE9BQU8sU0FBUyxZQUFZLEVBQUUsU0FBUyxVQUFVLENBQUMsQ0FBQztBQUM1RjtBQUNBLFNBQVMsY0FBYyxTQUFTO0NBQy9CLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJQyxtQkFBQUEsVUFBVSxFQUFFLFVBQVUsUUFBUSxLQUFLLE9BQU8sTUFBc0IsaUJBQUEsR0FBQSxhQUFBLGNBQUEsQ0FBYyxPQUFPO0VBQy9HLEdBQUc7RUFDSCxLQUFLLGVBQWUsTUFBTSxJQUFJLEdBQUc7Q0FDbEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNOOzs7Ozs7Ozs7Ozs7QUNwQkEsU0FBUyxZQUFZLE9BQU87Q0FDM0IsTUFBTSxPQUFPLFFBQVEsTUFBTSxnQkFBZ0I7Q0FDM0MsTUFBTSxRQUFRLFVBQVUsQ0FBQyxDQUFDLFFBQVEsS0FBSztDQUN2QyxNQUFNLFdBQVcsWUFBWTtDQUM3QixhQUFRLGdCQUFnQjtFQUN2QixJQUFJLFVBQVUsU0FBUyxpQkFBaUIsUUFBUSxnQkFBZ0IsRUFBRSxDQUFDLENBQUMsU0FBUyxPQUFPLEdBQUcsT0FBTyxDQUFDO0NBQ2hHLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FDYixNQUFNLGVBQWUsV0FBVyxLQUFLLFFBQVEsUUFBUSxJQUFJLFFBQVEsVUFBVSxJQUFJLFFBQUEsdUNBQTZCLElBQUksSUFBSTtDQUNwSCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSUMsbUJBQUFBLFVBQVUsRUFBRSxVQUFVLGFBQWEsS0FBSyxRQUF3QixpQkFBQSxHQUFBLGFBQUEsY0FBQSxDQUFjLE9BQU87RUFDL0csR0FBRztFQUNILEtBQUssWUFBWSxLQUFLLFVBQVUsR0FBRztFQUNuQztDQUNELENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDTiIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDI5LDMwLDMxLDMyLDMzLDM0LDM1LDM2LDM3LDM4LDM5LDQwLDQxLDQyLDQzLDQ0LDQ1LDQ2LDQ3LDQ4LDQ5LDUwLDUxLDUyLDUzLDU0LDU1LDU2LDU3LDU4LDU5LDYwLDYxLDYyLDYzLDY0LDY1LDY2LDY3LDY4LDY5LDcwLDcxXX0=