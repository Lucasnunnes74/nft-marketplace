import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/nft-detail.tsx");const useId = __vite__cjsImport2_react["useId"]; const useState = __vite__cjsImport2_react["useState"];const _jsxDEV = __vite__cjsImport20_react_jsxDevRuntime["jsxDEV"];import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=5d4ac5a9";
import { getRouteApi, useNavigate, useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { chainLabels } from "/src/api/contracts.ts";
import { ApiError, toApiError } from "/src/api/errors.ts";
import { Breadcrumb, ErrorState, NotFoundState } from "/src/components/common/states.tsx";
import { LiveIndicator } from "/src/components/layout/footer.tsx";
import { FavoriteButton } from "/src/components/nft/favorite-button.tsx";
import { NftCard, NftCardSkeleton } from "/src/components/nft/nft-card.tsx";
import { Price } from "/src/components/nft/price.tsx";
import { QuantityStepper } from "/src/components/nft/quantity-stepper.tsx";
import { Alert } from "/src/components/ui/alert.tsx";
import { Dialog, DialogContent, DialogTitle } from "/src/components/ui/dialog.tsx";
import { FigmaIcon } from "/src/components/ui/figma-icon.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { useAddToCart, useCart, useNft, useNftList } from "/src/hooks/use-api.ts";
import { useIsDesktop } from "/src/hooks/use-media.ts";
import { usePageTitle } from "/src/hooks/use-page.ts";
import { cn } from "/src/lib/utils.ts";
import { toast } from "/src/stores/toasts.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/pages/nft-detail.tsx";
import __vite__cjsImport20_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$();
const route = getRouteApi("/nft/$nftId");
export function NftDetailPage() {
	_s();
	const { nftId } = route.useParams();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const isDesktop = useIsDesktop();
	const nft = useNft(nftId);
	const cart = useCart();
	const add = useAddToCart();
	const [requested, setRequested] = useState(1);
	usePageTitle(nft.data?.name ?? "NFT");
	const data = nft.data;
	const inCart = cart.data?.items.find((i) => i.nftId === nftId)?.quantity ?? 0;
	// Limite = menor entre estoque e máximo por pedido, descontando o que já está no carrinho.
	const maxAdd = data ? Math.max(0, Math.min(data.available, data.maxPerOrder) - inCart) : 0;
	// Se o estoque cair em tempo real, a quantidade escolhida acompanha o novo limite (derivado no render).
	const quantity = Math.min(Math.max(1, requested), Math.max(1, maxAdd));
	async function addToCart(goToCart) {
		try {
			await add.mutateAsync({
				nftId,
				quantity
			});
			if (goToCart) {
				void navigate({ to: "/cart" });
				return;
			}
			toast({
				title: "Adicionado ao carrinho",
				description: `${quantity} × ${data?.name}`,
				variant: "success"
			});
		} catch (e) {
			const err = toApiError(e);
			toast({
				title: "Não foi possível adicionar",
				description: err.message,
				variant: "warning"
			});
			// Estoque/limite mudou: atualiza a tela com os dados reais.
			void qc.invalidateQueries({ queryKey: [
				"nfts",
				"detail",
				nftId
			] });
		}
	}
	if (nft.isPending) return /* @__PURE__ */ _jsxDEV(DetailSkeleton, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 58,
		columnNumber: 29
	}, this);
	if (nft.isError) {
		if (nft.error instanceof ApiError && nft.error.code === "NOT_FOUND") {
			return /* @__PURE__ */ _jsxDEV(NotFoundState, {
				title: "NFT não encontrado",
				description: "Este NFT não existe ou foi removido do catálogo."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 14
			}, this);
		}
		return /* @__PURE__ */ _jsxDEV(ErrorState, {
			error: nft.error,
			onRetry: () => void nft.refetch(),
			retrying: nft.isFetching
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 12
		}, this);
	}
	const n = nft.data;
	const purchase = {
		quantity,
		maxAdd,
		inCart,
		pending: add.isPending,
		onQuantity: setRequested,
		onBuy: () => void addToCart(true),
		onAdd: () => void addToCart(false)
	};
	return isDesktop ? /* @__PURE__ */ _jsxDEV(DesktopDetail, {
		n,
		purchase
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 76,
		columnNumber: 22
	}, this) : /* @__PURE__ */ _jsxDEV(MobileDetail, {
		n,
		purchase
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 76,
		columnNumber: 68
	}, this);
}
_s(NftDetailPage, "209RjJV3VbyTA8Gmg6bhFB1MfzI=", false, function() {
	return [
		route.useParams,
		useNavigate,
		useQueryClient,
		useIsDesktop,
		useNft,
		useCart,
		useAddToCart,
		usePageTitle
	];
});
_c = NftDetailPage;
function DesktopDetail({ n, purchase }) {
	_s2();
	const [image, setImage] = useState(1);
	const [zoom, setZoom] = useState(false);
	const soldOut = n.available === 0;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-24",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ _jsxDEV(Breadcrumb, { items: [{
					label: "Início",
					to: "/"
				}, {
					label: "Mercado",
					to: "/",
					hash: "catalogo"
				}] }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex gap-8",
					children: [/* @__PURE__ */ _jsxDEV("section", {
						"aria-label": "Galeria",
						className: "flex h-[448px] shrink-0 items-center gap-7",
						children: [/* @__PURE__ */ _jsxDEV("ul", {
							className: "flex w-[100px] flex-col gap-4",
							children: n.images.map((src, i) => /* @__PURE__ */ _jsxDEV("li", {
								className: "rounded-[6px] bg-card",
								children: /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setImage(i),
									"aria-label": `Ver imagem ${i + 1} de ${n.images.length}`,
									"aria-current": i === image,
									className: cn("block size-[100px] overflow-hidden rounded-[8px] border", i === image ? "border-primary" : "border-transparent opacity-80 hover:opacity-100"),
									children: /* @__PURE__ */ _jsxDEV("img", {
										src,
										alt: "",
										width: 100,
										height: 100,
										className: "size-full object-cover"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 113,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 103,
									columnNumber: 19
								}, this)
							}, `${src}-${i}`, false, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "relative grid size-[444px] place-items-center rounded-[6px] bg-card p-4",
							children: [/* @__PURE__ */ _jsxDEV("img", {
								src: n.images[image],
								alt: `${n.name}, imagem ${image + 1} de ${n.images.length}`,
								width: 404,
								height: 404,
								fetchPriority: "high",
								className: "size-[404px] rounded-3xl object-cover"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								"aria-label": "Ampliar imagem",
								onClick: () => setZoom(true),
								className: "absolute right-3 top-[15px] grid size-[30px] place-items-center rounded-full",
								children: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
									name: "icon-zoom",
									width: 30,
									original: true
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("section", {
						"aria-label": "Informações",
						className: "flex min-w-0 flex-1 flex-col justify-between gap-5",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col gap-3",
								children: [
									/* @__PURE__ */ _jsxDEV("h1", {
										className: "text-[28px] font-bold leading-normal text-foreground",
										children: n.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 140,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between gap-4",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[22px] font-bold leading-4 text-accent",
											"data-testid": "detail-price",
											children: [/* @__PURE__ */ _jsxDEV(Price, { value: n.price }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 143,
												columnNumber: 19
											}, this), n.previousPrice ? /* @__PURE__ */ _jsxDEV("span", {
												className: "ml-3 text-lg font-normal text-subtle",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "sr-only",
													children: "Preço anterior: "
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 146,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV(Price, {
													value: n.previousPrice,
													className: "font-normal"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 147,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 145,
												columnNumber: 21
											}, this) : null]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 142,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV(Rating, {
											rating: n.rating,
											count: n.reviewCount
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 151,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 141,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { className: "k-hairline mt-0" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 153,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col gap-3",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-[15px] font-bold leading-4 text-foreground",
									children: "Sobre este NFT:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 157,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm leading-6 text-muted-foreground",
									children: n.summary
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(EditionPills, { edition: n.edition }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 13
							}, this),
							soldOut ? /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between gap-4",
								children: [/* @__PURE__ */ _jsxDEV(Alert, {
									variant: "warning",
									title: "Esta edição está esgotada",
									className: "flex-1 py-3",
									children: "Favorite para acompanhar novas edições."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 165,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV(FavoriteButton, {
									nftId: n.id,
									name: n.name,
									isFavorite: n.isFavorite
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 168,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col gap-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV(QuantityStepper, {
										variant: "round",
										label: "Quantidade a comprar",
										value: purchase.quantity,
										max: Math.max(1, purchase.maxAdd),
										onChange: purchase.onQuantity,
										disabled: purchase.maxAdd === 0
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 173,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											disabled: purchase.maxAdd === 0 || purchase.pending,
											onClick: purchase.onBuy,
											className: "flex h-10 w-[130px] items-center justify-center rounded-[6px] bg-primary text-sm font-bold leading-5 text-primary-foreground hover:brightness-110 disabled:opacity-50",
											children: purchase.pending ? "ADICIONANDO…" : "COMPRAR"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 182,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV(FavoriteButton, {
											nftId: n.id,
											name: n.name,
											isFavorite: n.isFavorite
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 190,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 181,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 172,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV(PurchaseNotes, {
									purchase,
									maxPerOrder: n.maxPerOrder
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 193,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col gap-3",
								children: [/* @__PURE__ */ _jsxDEV(TokenInfo, { n }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 198,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV(ShareRow, { name: n.name }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 199,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(DescriptionTabs, { n }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 205,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(RelatedProducts, { n }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 206,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: zoom,
				onOpenChange: setZoom,
				children: /* @__PURE__ */ _jsxDEV(DialogContent, {
					className: "max-w-[min(90vw,760px)] p-4",
					children: [/* @__PURE__ */ _jsxDEV(DialogTitle, {
						className: "sr-only",
						children: n.name
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 210,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("img", {
						src: n.images[image],
						alt: n.name,
						className: "w-full rounded-3xl object-cover"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 209,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 208,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 95,
		columnNumber: 5
	}, this);
}
_s2(DesktopDetail, "AMHuoaeavLn61k69gThr5d+AIgA=");
_c2 = DesktopDetail;
function MobileDetail({ n, purchase }) {
	_s3();
	const router = useRouter();
	const soldOut = n.available === 0;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "-mx-6 flex flex-col pb-[180px]",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "relative h-[506px] bg-[linear-gradient(137.6deg,#241612_12%,#2f1d15_106.6%)] px-7 pt-[23px]",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							"aria-label": "Voltar",
							onClick: () => window.history.length > 1 ? router.history.back() : void router.navigate({ to: "/" }),
							className: "grid size-[35px] place-items-center rounded-full border border-border bg-surface-raised text-accent",
							children: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
								name: "m-arrow-left",
								width: 11,
								height: 6,
								className: "rotate-90"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 231,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 225,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(LiveIndicator, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 233,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(FavoriteButton, {
							nftId: n.id,
							name: n.name,
							isFavorite: n.isFavorite,
							variant: "chip-lg"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 224,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("img", {
					src: n.images[0],
					alt: n.name,
					width: 361,
					height: 356,
					fetchPriority: "high",
					className: "mt-2 h-[356px] w-full rounded-3xl object-cover"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 236,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 223,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				"aria-label": "Informações",
				className: "relative -mt-[114px] flex flex-col gap-3 rounded-t-[31px] bg-card px-6 pb-6 pt-8",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-xl font-bold leading-6 text-foreground",
							children: n.name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 248,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "flex h-[27px] shrink-0 items-center gap-1 rounded-[32px] border border-primary px-1.5 text-sm leading-4",
							"aria-label": `Nota ${n.rating.toLocaleString("pt-BR")} de 5, ${n.reviewCount} avaliações`,
							children: [
								/* @__PURE__ */ _jsxDEV(FigmaIcon, {
									name: "m-star",
									width: 12,
									height: 11,
									className: "text-warning"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 253,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									"aria-hidden": true,
									className: "font-medium text-foreground",
									children: n.rating.toLocaleString("pt-BR")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 254,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									"aria-hidden": true,
									className: "text-muted-foreground",
									children: [
										"(",
										n.reviewCount,
										")"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 257,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 249,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 247,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm leading-6 text-muted-foreground",
						children: n.summary
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(EditionPills, {
						edition: n.edition,
						gap: "gap-3"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 263,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(TokenInfo, { n }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 264,
						columnNumber: 9
					}, this),
					soldOut ? /* @__PURE__ */ _jsxDEV(Alert, {
						variant: "warning",
						title: "Esta edição está esgotada",
						children: "Favorite para acompanhar novas edições."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 266,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV(PurchaseNotes, {
						purchase,
						maxPerOrder: n.maxPerOrder
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 270,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 246,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "px-6 pt-10",
				children: /* @__PURE__ */ _jsxDEV(DescriptionTabs, { n }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 275,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 274,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "px-6 pt-10",
				children: /* @__PURE__ */ _jsxDEV(RelatedProducts, { n }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 278,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 277,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-x-0 bottom-0 z-40 rounded-t-[40px] bg-card px-6 pb-9 pt-5 shadow-[0_0_10px_rgba(10,6,4,0.45)]",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col gap-5",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[15px] font-medium leading-4 text-muted-foreground",
								children: "Qtd."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 285,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(QuantityStepper, {
								variant: "pill",
								label: "Quantidade a comprar",
								value: purchase.quantity,
								max: Math.max(1, purchase.maxAdd),
								onChange: purchase.onQuantity,
								disabled: soldOut || purchase.maxAdd === 0
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 286,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 284,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xl font-bold leading-4 text-accent",
							"data-testid": "detail-price",
							children: /* @__PURE__ */ _jsxDEV(Price, { value: n.price }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 296,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 295,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 283,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							disabled: soldOut || purchase.maxAdd === 0 || purchase.pending,
							onClick: purchase.onBuy,
							className: "flex h-[60px] flex-1 items-center justify-center rounded-[40px] bg-[linear-gradient(100deg,#d28a4c_4%,rgba(210,138,76,0.8)_122%)] text-base font-bold leading-5 text-primary-foreground disabled:opacity-50",
							children: soldOut ? "Esgotado" : purchase.pending ? "Adicionando…" : "Comprar NFT"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 300,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							"aria-label": "Adicionar ao carrinho",
							disabled: soldOut || purchase.maxAdd === 0 || purchase.pending,
							onClick: purchase.onAdd,
							className: "grid size-[60px] shrink-0 place-items-center rounded-[40px] border border-border bg-surface-raised text-subtle disabled:opacity-50",
							children: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
								name: "m-shop",
								width: 20
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 315,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 308,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 299,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 282,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 281,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 222,
		columnNumber: 5
	}, this);
}
_s3(MobileDetail, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
	return [useRouter];
});
_c3 = MobileDetail;
function PurchaseNotes({ purchase, maxPerOrder }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-1 text-xs text-muted-foreground",
		children: [
			/* @__PURE__ */ _jsxDEV("span", { children: [
				"Máximo de ",
				maxPerOrder,
				" por pedido."
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 327,
				columnNumber: 7
			}, this),
			purchase.inCart > 0 ? /* @__PURE__ */ _jsxDEV("span", {
				"data-testid": "in-cart-note",
				children: [
					"Você já tem ",
					purchase.inCart,
					" no carrinho."
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 328,
				columnNumber: 30
			}, this) : null,
			purchase.maxAdd === 0 ? /* @__PURE__ */ _jsxDEV("span", {
				className: "text-accent",
				children: "Você já tem a quantidade máxima disponível no carrinho."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 329,
				columnNumber: 32
			}, this) : null
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 326,
		columnNumber: 5
	}, this);
}
_c4 = PurchaseNotes;
function Rating({ rating, count }) {
	const filled = Math.floor(rating);
	return /* @__PURE__ */ _jsxDEV("p", {
		className: "flex items-center gap-1",
		"aria-label": `Nota ${rating.toLocaleString("pt-BR")} de 5, ${count} avaliações de colecionadores`,
		children: [Array.from({ length: 5 }, (_, i) => /* @__PURE__ */ _jsxDEV("span", {
			"aria-hidden": true,
			className: "grid size-[15px] place-items-center",
			children: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
				name: i < filled ? "icon-star" : "icon-star-empty",
				width: 12.5,
				height: 11.9,
				original: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 340,
				columnNumber: 11
			}, this)
		}, i, false, {
			fileName: _jsxFileName,
			lineNumber: 339,
			columnNumber: 9
		}, this)), /* @__PURE__ */ _jsxDEV("span", {
			"aria-hidden": true,
			className: "ml-px text-[15px] leading-normal text-foreground",
			children: [count, " avaliações de colecionadores"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 343,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 337,
		columnNumber: 5
	}, this);
}
_c5 = Rating;
/** Pílulas "Edição": 1/1, 1/10, 1/50 e ABERTA; a edição do NFT fica destacada (borda e cor). */
function EditionPills({ edition, gap = "gap-1.5" }) {
	const options = [
		{
			key: 1,
			label: "1/1"
		},
		{
			key: 10,
			label: "1/10"
		},
		{
			key: 50,
			label: "1/50"
		},
		{
			key: 100,
			label: "ABERTA"
		}
	];
	const current = edition >= 100 ? 100 : edition;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-2 md:gap-3",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "text-[15px] font-bold leading-4 text-foreground",
			children: "Edição:"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 361,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("ul", {
			className: cn("flex items-center", gap),
			"aria-label": "Tamanho da edição",
			children: options.map((o) => {
				const active = o.key === current;
				return /* @__PURE__ */ _jsxDEV("li", {
					"aria-current": active ? "true" : undefined,
					className: cn("flex h-7 items-center justify-center rounded-full border-2 px-1.5 text-sm leading-4", o.key === 100 && "px-2", active ? "border-primary font-medium text-accent" : "border-border text-muted-foreground"),
					children: [o.label, active ? /* @__PURE__ */ _jsxDEV("span", {
						className: "sr-only",
						children: " (edição deste NFT)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 376,
						columnNumber: 25
					}, this) : null]
				}, o.key, true, {
					fileName: _jsxFileName,
					lineNumber: 366,
					columnNumber: 13
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 362,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 360,
		columnNumber: 5
	}, this);
}
_c6 = EditionPills;
function TokenInfo({ n }) {
	const soldOut = n.available === 0;
	return /* @__PURE__ */ _jsxDEV("dl", {
		className: "flex flex-col gap-3 text-[15px] leading-normal text-subtle",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex gap-1",
				children: [/* @__PURE__ */ _jsxDEV("dt", { children: "ID do token:" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 390,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("dd", { children: ["#", n.tokenId] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 391,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 389,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex gap-1",
				children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Coleção:" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 394,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("dd", { children: n.collection }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 395,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 393,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex gap-1",
				children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Atributos:" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 398,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("dd", { children: n.attributes.map((a) => a.value).join(", ") }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 399,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 397,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex gap-1",
				children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Disponíveis:" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 402,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("dd", {
					"data-testid": "detail-availability",
					children: soldOut ? /* @__PURE__ */ _jsxDEV("span", {
						className: "font-bold text-coral",
						children: "Esgotado"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 404,
						columnNumber: 22
					}, this) : `${n.available} de ${n.edition}`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 403,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 401,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 388,
		columnNumber: 5
	}, this);
}
_c7 = TokenInfo;
function ShareRow({ name }) {
	const url = typeof window !== "undefined" ? window.location.href : "";
	const text = `${name} na Kurio`;
	const links = [
		{
			label: "Compartilhar no LinkedIn",
			href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
			icon: "share-linkedin",
			w: 15,
			h: 14
		},
		{
			label: "Compartilhar por e-mail",
			href: `mailto:?subject=${encodeURIComponent(text)}&body=${encodeURIComponent(url)}`,
			icon: "icon-message",
			w: 18,
			h: 18
		},
		{
			label: "Compartilhar no X (Twitter)",
			href: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`,
			icon: "share-twitter",
			w: 16,
			h: 12
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex items-center gap-2",
		children: [/* @__PURE__ */ _jsxDEV("p", {
			className: "text-[15px] font-bold leading-4 text-foreground",
			children: "Compartilhar este NFT:"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 421,
			columnNumber: 7
		}, this), links.map((l) => /* @__PURE__ */ _jsxDEV("a", {
			href: l.href,
			target: "_blank",
			rel: "noopener noreferrer",
			"aria-label": l.label,
			className: "grid place-items-center text-foreground hover:opacity-80",
			children: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
				name: l.icon,
				width: l.w,
				height: l.h,
				original: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 424,
				columnNumber: 11
			}, this)
		}, l.icon, false, {
			fileName: _jsxFileName,
			lineNumber: 423,
			columnNumber: 9
		}, this))]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 420,
		columnNumber: 5
	}, this);
}
_c8 = ShareRow;
function DescriptionTabs({ n }) {
	_s4();
	const [tab, setTab] = useState("details");
	const id = useId();
	const tabs = [{
		key: "details",
		label: "Detalhes do NFT"
	}, {
		key: "reviews",
		label: `Avaliações de colecionadores (${n.reviewCount})`
	}];
	const chain = chainLabels[n.chain];
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-label": "Descrição",
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				role: "tablist",
				"aria-label": "Descrição do NFT",
				className: "flex gap-8 overflow-x-auto",
				children: tabs.map((t) => {
					const active = t.key === tab;
					return /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						role: "tab",
						id: `${id}-${t.key}`,
						"aria-selected": active,
						"aria-controls": `${id}-${t.key}-panel`,
						tabIndex: active ? 0 : -1,
						onClick: () => setTab(t.key),
						onKeyDown: (e) => {
							if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
								const next = tab === "details" ? "reviews" : "details";
								setTab(next);
								document.getElementById(`${id}-${next}`)?.focus();
							}
						},
						className: cn("flex shrink-0 flex-col gap-3 whitespace-nowrap text-[17px] leading-4", active ? "font-bold text-accent" : "text-foreground hover:text-accent"),
						children: [t.label, /* @__PURE__ */ _jsxDEV("span", {
							"aria-hidden": true,
							className: cn("h-[3px] w-full", active ? "bg-primary" : "bg-transparent")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 468,
							columnNumber: 17
						}, this)]
					}, t.key, true, {
						fileName: _jsxFileName,
						lineNumber: 446,
						columnNumber: 15
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 442,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", { className: "k-hairline" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 473,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 441,
			columnNumber: 7
		}, this), tab === "details" ? /* @__PURE__ */ _jsxDEV("div", {
			role: "tabpanel",
			id: `${id}-details-panel`,
			"aria-labelledby": `${id}-details`,
			className: "flex flex-col gap-3 text-sm leading-6",
			children: [n.description.split("\n\n").map((p) => /* @__PURE__ */ _jsxDEV("p", {
				className: "text-muted-foreground",
				children: p
			}, p.slice(0, 24), false, {
				fileName: _jsxFileName,
				lineNumber: 479,
				columnNumber: 13
			}, this)), /* @__PURE__ */ _jsxDEV("dl", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
						className: "font-bold text-foreground",
						children: "Rede:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 485,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("dd", {
						className: "text-muted-foreground",
						children: [
							"Cunhado na ",
							chain,
							" com procedência imutável e metadados armazenados no IPFS."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 486,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 484,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
						className: "font-bold text-foreground",
						children: "Contrato:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 489,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("dd", {
						className: "text-muted-foreground",
						children: [n.contractAddress, " • Contrato inteligente ERC-721 verificado."]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 490,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 488,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
						className: "font-bold text-foreground",
						children: "Direitos autorais:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 493,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("dd", {
						className: "text-muted-foreground",
						children: [
							"Direitos autorais do criador: ",
							n.royaltyBps / 100,
							"% nas vendas secundárias, pagos automaticamente pelos mercados compatíveis."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 494,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 492,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 483,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 477,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			role: "tabpanel",
			id: `${id}-reviews-panel`,
			"aria-labelledby": `${id}-reviews`,
			className: "flex flex-col gap-3 text-sm leading-6",
			children: [/* @__PURE__ */ _jsxDEV(Rating, {
				rating: n.rating,
				count: n.reviewCount
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 502,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-muted-foreground",
				children: [
					"Nota média ",
					n.rating.toLocaleString("pt-BR"),
					" de 5, com base em ",
					n.reviewCount,
					" avaliações de colecionadores verificados."
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 503,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 501,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 440,
		columnNumber: 5
	}, this);
}
_s4(DescriptionTabs, "LCq5NMMZb9Q2oclyUs0GUOUeuIY=");
_c9 = DescriptionTabs;
const RELATED_PER_PAGE = 5;
/** "Mais desta coleção": itens da mesma coleção, em páginas de 5 (pontos do carrossel). */
function RelatedProducts({ n }) {
	_s5();
	const related = useNftList({
		q: n.collection,
		sort: "newest",
		pageSize: 16,
		page: 1
	});
	const [page, setPage] = useState(0);
	const items = (related.data?.items ?? []).filter((i) => i.id !== n.id && i.collection === n.collection);
	const pages = Math.max(1, Math.ceil(items.length / RELATED_PER_PAGE));
	const current = Math.min(page, pages - 1);
	const visible = items.slice(current * RELATED_PER_PAGE, current * RELATED_PER_PAGE + RELATED_PER_PAGE);
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-labelledby": "related-title",
		className: "flex flex-col gap-8",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col gap-3",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				id: "related-title",
				className: "text-[17px] font-bold leading-4 text-accent",
				children: "Mais desta coleção"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 526,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", { className: "k-hairline" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 529,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 525,
			columnNumber: 7
		}, this), related.isError ? /* @__PURE__ */ _jsxDEV(ErrorState, {
			compact: true,
			error: related.error,
			onRetry: () => void related.refetch(),
			retrying: related.isFetching
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 532,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col items-center gap-8",
			children: [
				/* @__PURE__ */ _jsxDEV("ul", {
					className: "grid w-full grid-cols-2 gap-x-4 gap-y-6 md:grid-cols-5 md:gap-x-[26px]",
					children: related.isPending ? Array.from({ length: RELATED_PER_PAGE }, (_, i) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(NftCardSkeleton, { size: "related" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 539,
						columnNumber: 21
					}, this) }, i, false, {
						fileName: _jsxFileName,
						lineNumber: 538,
						columnNumber: 19
					}, this)) : visible.map((item) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(NftCard, {
						nft: item,
						size: "related"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 544,
						columnNumber: 21
					}, this) }, item.id, false, {
						fileName: _jsxFileName,
						lineNumber: 543,
						columnNumber: 19
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 535,
					columnNumber: 11
				}, this),
				!related.isPending && items.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-muted-foreground",
					children: "Ainda não há outros itens desta coleção."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 549,
					columnNumber: 13
				}, this) : null,
				pages > 1 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					role: "group",
					"aria-label": "Páginas de itens relacionados",
					children: Array.from({ length: pages }, (_, i) => /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						"aria-label": `Itens relacionados, página ${i + 1} de ${pages}`,
						"aria-pressed": i === current,
						onClick: () => setPage(i),
						className: cn("size-3 rounded-full border-[1.3px] border-primary", i === current && "bg-primary")
					}, i, false, {
						fileName: _jsxFileName,
						lineNumber: 554,
						columnNumber: 17
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 552,
					columnNumber: 13
				}, this) : null
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 534,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 524,
		columnNumber: 5
	}, this);
}
_s5(RelatedProducts, "duI2KW5cv/9EE1PyxlHQ6m6sPdo=", false, function() {
	return [useNftList];
});
_c10 = RelatedProducts;
function DetailSkeleton() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-6 md:flex-row md:gap-8",
		"aria-busy": true,
		"aria-label": "Carregando NFT",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "hidden flex-col gap-4 md:flex",
				children: Array.from({ length: 4 }, (_, i) => /* @__PURE__ */ _jsxDEV(Skeleton, { className: "size-[100px] bg-card" }, i, false, {
					fileName: _jsxFileName,
					lineNumber: 576,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 574,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Skeleton, { className: "aspect-square w-full bg-card md:size-[444px]" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 579,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-1 flex-col gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-8 w-2/3 bg-card" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 581,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-6 w-1/3 bg-card" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 582,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-24 w-full bg-card" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 583,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-10 w-full bg-card" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 584,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 580,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 573,
		columnNumber: 5
	}, this);
}
_c11 = DetailSkeleton;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
$RefreshReg$(_c, "NftDetailPage");
$RefreshReg$(_c2, "DesktopDetail");
$RefreshReg$(_c3, "MobileDetail");
$RefreshReg$(_c4, "PurchaseNotes");
$RefreshReg$(_c5, "Rating");
$RefreshReg$(_c6, "EditionPills");
$RefreshReg$(_c7, "TokenInfo");
$RefreshReg$(_c8, "ShareRow");
$RefreshReg$(_c9, "DescriptionTabs");
$RefreshReg$(_c10, "RelatedProducts");
$RefreshReg$(_c11, "DetailSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/nft-detail.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/pages/nft-detail.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/pages/nft-detail.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/pages/nft-detail.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxhQUFhLGFBQWEsaUJBQWlCO0FBQ3BELFNBQVMsT0FBTyxnQkFBZ0I7QUFDaEMsU0FBUyxtQkFBbUM7QUFDNUMsU0FBUyxVQUFVLGtCQUFrQjtBQUNyQyxTQUFTLFlBQVksWUFBWSxxQkFBcUI7QUFDdEQsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxTQUFTLHVCQUF1QjtBQUN6QyxTQUFTLGFBQWE7QUFDdEIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsUUFBUSxlQUFlLG1CQUFtQjtBQUNuRCxTQUFTLGlCQUFpQjtBQUMxQixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGNBQWMsU0FBUyxRQUFRLGtCQUFrQjtBQUMxRCxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLFVBQVU7QUFDbkIsU0FBUyxhQUFhOzs7O0FBRXRCLE1BQU0sUUFBUSxZQUFZLGFBQWE7QUFFdkMsT0FBTyxTQUFTLGdCQUFnQjs7Q0FDOUIsTUFBTSxFQUFFLFVBQVUsTUFBTSxVQUFVO0NBQ2xDLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sS0FBSyxlQUFlO0NBQzFCLE1BQU0sWUFBWSxhQUFhO0NBQy9CLE1BQU0sTUFBTSxPQUFPLEtBQUs7Q0FDeEIsTUFBTSxPQUFPLFFBQVE7Q0FDckIsTUFBTSxNQUFNLGFBQWE7Q0FDekIsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsQ0FBQztDQUM1QyxhQUFhLElBQUksTUFBTSxRQUFRLEtBQUs7Q0FFcEMsTUFBTSxPQUFPLElBQUk7Q0FDakIsTUFBTSxTQUFTLEtBQUssTUFBTSxNQUFNLE1BQU0sTUFBTSxFQUFFLFVBQVUsS0FBSyxDQUFDLEVBQUUsWUFBWTs7Q0FFNUUsTUFBTSxTQUFTLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEtBQUssV0FBVyxLQUFLLFdBQVcsSUFBSSxNQUFNLElBQUk7O0NBRXpGLE1BQU0sV0FBVyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsU0FBUyxHQUFHLEtBQUssSUFBSSxHQUFHLE1BQU0sQ0FBQztDQUVyRSxlQUFlLFVBQVUsVUFBbUI7RUFDMUMsSUFBSTtHQUNGLE1BQU0sSUFBSSxZQUFZO0lBQUU7SUFBTztHQUFTLENBQUM7R0FDekMsSUFBSSxVQUFVO0lBQ1osS0FBSyxTQUFTLEVBQUUsSUFBSSxRQUFRLENBQUM7SUFDN0I7R0FDRjtHQUNBLE1BQU07SUFBRSxPQUFPO0lBQTBCLGFBQWEsR0FBRyxTQUFTLEtBQUssTUFBTTtJQUFRLFNBQVM7R0FBVSxDQUFDO0VBQzNHLFNBQVMsR0FBRztHQUNWLE1BQU0sTUFBTSxXQUFXLENBQUM7R0FDeEIsTUFBTTtJQUFFLE9BQU87SUFBOEIsYUFBYSxJQUFJO0lBQVMsU0FBUztHQUFVLENBQUM7O0dBRTNGLEtBQUssR0FBRyxrQkFBa0IsRUFBRSxVQUFVO0lBQUM7SUFBUTtJQUFVO0dBQUssRUFBRSxDQUFDO0VBQ25FO0NBQ0Y7Q0FFQSxJQUFJLElBQUksV0FBVyxPQUFPLHdCQUFDLGdCQUFELENBQWlCOzs7OztDQUMzQyxJQUFJLElBQUksU0FBUztFQUNmLElBQUksSUFBSSxpQkFBaUIsWUFBWSxJQUFJLE1BQU0sU0FBUyxhQUFhO0dBQ25FLE9BQU8sd0JBQUMsZUFBRDtJQUFlLE9BQU07SUFBcUIsYUFBWTtHQUFvRDs7Ozs7RUFDbkg7RUFDQSxPQUFPLHdCQUFDLFlBQUQ7R0FBWSxPQUFPLElBQUk7R0FBTyxlQUFlLEtBQUssSUFBSSxRQUFRO0dBQUcsVUFBVSxJQUFJO0VBQWE7Ozs7O0NBQ3JHO0NBQ0EsTUFBTSxJQUFJLElBQUk7Q0FDZCxNQUFNLFdBQVc7RUFDZjtFQUNBO0VBQ0E7RUFDQSxTQUFTLElBQUk7RUFDYixZQUFZO0VBQ1osYUFBYSxLQUFLLFVBQVUsSUFBSTtFQUNoQyxhQUFhLEtBQUssVUFBVSxLQUFLO0NBQ25DO0NBRUEsT0FBTyxZQUFZLHdCQUFDLGVBQUQ7RUFBa0I7RUFBYTtDQUFXOzs7O1lBQUksd0JBQUMsY0FBRDtFQUFpQjtFQUFhO0NBQVc7Ozs7O0FBQzVHOzs7Ozs7Ozs7Ozs7OztBQVlBLFNBQVMsY0FBYyxFQUFFLEdBQUcsWUFBa0Q7O0NBQzVFLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxDQUFDO0NBQ3BDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxLQUFLO0NBQ3RDLE1BQU0sVUFBVSxFQUFFLGNBQWM7Q0FFaEMsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFlBQUQsRUFBWSxPQUFPLENBQUM7S0FBRSxPQUFPO0tBQVUsSUFBSTtJQUFJLEdBQUc7S0FBRSxPQUFPO0tBQVcsSUFBSTtLQUFLLE1BQU07SUFBVyxDQUFDLEVBQUk7Ozs7Y0FDckcsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFdBQUQ7TUFBUyxjQUFXO01BQVUsV0FBVTtnQkFBeEMsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWCxFQUFFLE9BQU8sS0FBSyxLQUFLLE1BQ2xCLHdCQUFDLE1BQUQ7UUFBd0IsV0FBVTtrQkFDaEMsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLFNBQVMsQ0FBQztTQUN6QixjQUFZLGNBQWMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPO1NBQy9DLGdCQUFjLE1BQU07U0FDcEIsV0FBVyxHQUNULDJEQUNBLE1BQU0sUUFBUSxtQkFBbUIsaURBQ25DO21CQUVBLHdCQUFDLE9BQUQ7VUFBVTtVQUFLLEtBQUk7VUFBRyxPQUFPO1VBQUssUUFBUTtVQUFLLFdBQVU7U0FBMEI7Ozs7O1FBQzdFOzs7OztPQUNOLEdBYkssR0FBRyxJQUFJLEdBQUc7Ozs7Y0FhZixDQUNMO01BQ0M7Ozs7Z0JBQ0osd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQ0UsS0FBSyxFQUFFLE9BQU87UUFDZCxLQUFLLEdBQUcsRUFBRSxLQUFLLFdBQVcsUUFBUSxFQUFFLE1BQU0sRUFBRSxPQUFPO1FBQ25ELE9BQU87UUFDUCxRQUFRO1FBQ1IsZUFBYztRQUNkLFdBQVU7T0FDWDs7OztpQkFDRCx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGNBQVc7UUFDWCxlQUFlLFFBQVEsSUFBSTtRQUMzQixXQUFVO2tCQUVWLHdCQUFDLFdBQUQ7U0FBVyxNQUFLO1NBQVksT0FBTztTQUFJO1FBQVU7Ozs7O09BQzNDOzs7O2VBQ0w7Ozs7O2NBQ0U7Ozs7O2VBRVQsd0JBQUMsV0FBRDtNQUFTLGNBQVc7TUFBYyxXQUFVO2dCQUE1QztPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXdELEVBQUU7U0FBUzs7Ozs7U0FDakYsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtXQUE4QyxlQUFZO3FCQUF2RSxDQUNFLHdCQUFDLE9BQUQsRUFBTyxPQUFPLEVBQUUsTUFBUTs7OztxQkFDdkIsRUFBRSxnQkFDRCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEIsQ0FDRSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBVTtZQUFzQjs7OztzQkFDaEQsd0JBQUMsT0FBRDthQUFPLE9BQU8sRUFBRTthQUFlLFdBQVU7WUFBZTs7OztvQkFDcEQ7Ozs7O3NCQUNKLElBQ0g7Ozs7O29CQUNILHdCQUFDLFFBQUQ7V0FBUSxRQUFRLEVBQUU7V0FBUSxPQUFPLEVBQUU7VUFBYzs7OztrQkFDOUM7Ozs7OztTQUNMLHdCQUFDLE9BQUQsRUFBSyxXQUFVLGtCQUFtQjs7Ozs7UUFDL0I7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWtEO1FBQW1COzs7O2tCQUNuRix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBMkMsRUFBRTtRQUFXOzs7O2dCQUNsRTs7Ozs7O09BRUwsd0JBQUMsY0FBRCxFQUFjLFNBQVMsRUFBRSxRQUFVOzs7OztPQUVsQyxVQUNDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFPLFNBQVE7U0FBVSxPQUFNO1NBQTRCLFdBQVU7bUJBQWM7UUFFNUU7Ozs7a0JBQ1Asd0JBQUMsZ0JBQUQ7U0FBZ0IsT0FBTyxFQUFFO1NBQUksTUFBTSxFQUFFO1NBQU0sWUFBWSxFQUFFO1FBQWE7Ozs7Z0JBQ25FOzs7OztrQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsaUJBQUQ7VUFDRSxTQUFRO1VBQ1IsT0FBTTtVQUNOLE9BQU8sU0FBUztVQUNoQixLQUFLLEtBQUssSUFBSSxHQUFHLFNBQVMsTUFBTTtVQUNoQyxVQUFVLFNBQVM7VUFDbkIsVUFBVSxTQUFTLFdBQVc7U0FDL0I7Ozs7bUJBQ0Qsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsTUFBSztXQUNMLFVBQVUsU0FBUyxXQUFXLEtBQUssU0FBUztXQUM1QyxTQUFTLFNBQVM7V0FDbEIsV0FBVTtxQkFFVCxTQUFTLFVBQVUsaUJBQWlCO1VBQy9COzs7O29CQUNSLHdCQUFDLGdCQUFEO1dBQWdCLE9BQU8sRUFBRTtXQUFJLE1BQU0sRUFBRTtXQUFNLFlBQVksRUFBRTtVQUFhOzs7O2tCQUNuRTs7Ozs7aUJBQ0Y7Ozs7O2tCQUNMLHdCQUFDLGVBQUQ7U0FBeUI7U0FBVSxhQUFhLEVBQUU7UUFBYzs7OztnQkFDN0Q7Ozs7OztPQUdQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsV0FBRCxFQUFjLEVBQUk7Ozs7a0JBQ2xCLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEVBQUUsS0FBTzs7OztnQkFDdEI7Ozs7OztNQUNFOzs7OzthQUNOOzs7OztZQUNGOzs7Ozs7R0FFTCx3QkFBQyxpQkFBRCxFQUFvQixFQUFJOzs7OztHQUN4Qix3QkFBQyxpQkFBRCxFQUFvQixFQUFJOzs7OztHQUV4Qix3QkFBQyxRQUFEO0lBQVEsTUFBTTtJQUFNLGNBQWM7Y0FDaEMsd0JBQUMsZUFBRDtLQUFlLFdBQVU7ZUFBekIsQ0FDRSx3QkFBQyxhQUFEO01BQWEsV0FBVTtnQkFBVyxFQUFFO0tBQWtCOzs7O2VBQ3RELHdCQUFDLE9BQUQ7TUFBSyxLQUFLLEVBQUUsT0FBTztNQUFRLEtBQUssRUFBRTtNQUFNLFdBQVU7S0FBbUM7Ozs7YUFDeEU7Ozs7OztHQUNUOzs7OztFQUNMOzs7Ozs7QUFFVDs7O0FBRUEsU0FBUyxhQUFhLEVBQUUsR0FBRyxZQUFrRDs7Q0FDM0UsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxVQUFVLEVBQUUsY0FBYztDQUNoQyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsY0FBVztPQUNYLGVBQWdCLE9BQU8sUUFBUSxTQUFTLElBQUksT0FBTyxRQUFRLEtBQUssSUFBSSxLQUFLLE9BQU8sU0FBUyxFQUFFLElBQUksSUFBSSxDQUFDO09BQ3BHLFdBQVU7aUJBRVYsd0JBQUMsV0FBRDtRQUFXLE1BQUs7UUFBZSxPQUFPO1FBQUksUUFBUTtRQUFHLFdBQVU7T0FBYTs7Ozs7TUFDdEU7Ozs7O01BQ1Isd0JBQUMsZUFBRCxDQUFnQjs7Ozs7TUFDaEIsd0JBQUMsZ0JBQUQ7T0FBZ0IsT0FBTyxFQUFFO09BQUksTUFBTSxFQUFFO09BQU0sWUFBWSxFQUFFO09BQVksU0FBUTtNQUFXOzs7OztLQUNyRjs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQ0UsS0FBSyxFQUFFLE9BQU87S0FDZCxLQUFLLEVBQUU7S0FDUCxPQUFPO0tBQ1AsUUFBUTtLQUNSLGVBQWM7S0FDZCxXQUFVO0lBQ1g7Ozs7WUFDRTs7Ozs7O0dBRUwsd0JBQUMsV0FBRDtJQUFTLGNBQVc7SUFBYyxXQUFVO2NBQTVDO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBK0MsRUFBRTtNQUFTOzs7O2dCQUN4RSx3QkFBQyxLQUFEO09BQ0UsV0FBVTtPQUNWLGNBQVksUUFBUSxFQUFFLE9BQU8sZUFBZSxPQUFPLEVBQUUsU0FBUyxFQUFFLFlBQVk7aUJBRjlFO1FBSUUsd0JBQUMsV0FBRDtTQUFXLE1BQUs7U0FBUyxPQUFPO1NBQUksUUFBUTtTQUFJLFdBQVU7UUFBZ0I7Ozs7O1FBQzFFLHdCQUFDLFFBQUQ7U0FBTTtTQUFZLFdBQVU7bUJBQ3pCLEVBQUUsT0FBTyxlQUFlLE9BQU87UUFDNUI7Ozs7O1FBQ04sd0JBQUMsUUFBRDtTQUFNO1NBQVksV0FBVTttQkFBNUI7VUFBb0Q7VUFDaEQsRUFBRTtVQUFZO1NBQ1o7Ozs7OztPQUNMOzs7OztjQUNBOzs7Ozs7S0FDTCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBMkMsRUFBRTtLQUFXOzs7OztLQUNyRSx3QkFBQyxjQUFEO01BQWMsU0FBUyxFQUFFO01BQVMsS0FBSTtLQUFTOzs7OztLQUMvQyx3QkFBQyxXQUFELEVBQWMsRUFBSTs7Ozs7S0FDakIsVUFDQyx3QkFBQyxPQUFEO01BQU8sU0FBUTtNQUFVLE9BQU07Z0JBQTRCO0tBRXBEOzs7O2dCQUVQLHdCQUFDLGVBQUQ7TUFBeUI7TUFBVSxhQUFhLEVBQUU7S0FBYzs7Ozs7SUFFM0Q7Ozs7OztHQUVULHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsaUJBQUQsRUFBb0IsRUFBSTs7Ozs7R0FDckI7Ozs7O0dBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxpQkFBRCxFQUFvQixFQUFJOzs7OztHQUNyQjs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTBEO09BQVU7Ozs7aUJBQ3BGLHdCQUFDLGlCQUFEO1FBQ0UsU0FBUTtRQUNSLE9BQU07UUFDTixPQUFPLFNBQVM7UUFDaEIsS0FBSyxLQUFLLElBQUksR0FBRyxTQUFTLE1BQU07UUFDaEMsVUFBVSxTQUFTO1FBQ25CLFVBQVUsV0FBVyxTQUFTLFdBQVc7T0FDMUM7Ozs7ZUFDRTs7Ozs7Z0JBQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7T0FBMEMsZUFBWTtpQkFDakUsd0JBQUMsT0FBRCxFQUFPLE9BQU8sRUFBRSxNQUFROzs7OztNQUN2Qjs7OztjQUNBOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxVQUFVLFdBQVcsU0FBUyxXQUFXLEtBQUssU0FBUztPQUN2RCxTQUFTLFNBQVM7T0FDbEIsV0FBVTtpQkFFVCxVQUFVLGFBQWEsU0FBUyxVQUFVLGlCQUFpQjtNQUN0RDs7OztnQkFDUix3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLGNBQVc7T0FDWCxVQUFVLFdBQVcsU0FBUyxXQUFXLEtBQUssU0FBUztPQUN2RCxTQUFTLFNBQVM7T0FDbEIsV0FBVTtpQkFFVix3QkFBQyxXQUFEO1FBQVcsTUFBSztRQUFTLE9BQU87T0FBSzs7Ozs7TUFDL0I7Ozs7Y0FDTDs7Ozs7YUFDRjs7Ozs7O0dBQ0Y7Ozs7O0VBQ0Y7Ozs7OztBQUVUOzs7OztBQUVBLFNBQVMsY0FBYyxFQUFFLFVBQVUsZUFBNEQ7Q0FDN0YsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsUUFBRDtJQUFNO0lBQVc7SUFBWTtHQUFrQjs7Ozs7R0FDOUMsU0FBUyxTQUFTLElBQUksd0JBQUMsUUFBRDtJQUFNLGVBQVk7Y0FBbEI7S0FBaUM7S0FBYSxTQUFTO0tBQU87SUFBbUI7Ozs7O2NBQUk7R0FDM0csU0FBUyxXQUFXLElBQUksd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBYztHQUE2RDs7OztjQUFJO0VBQ3JIOzs7Ozs7QUFFVDs7QUFFQSxTQUFTLE9BQU8sRUFBRSxRQUFRLFNBQTRDO0NBQ3BFLE1BQU0sU0FBUyxLQUFLLE1BQU0sTUFBTTtDQUNoQyxPQUNFLHdCQUFDLEtBQUQ7RUFBRyxXQUFVO0VBQTBCLGNBQVksUUFBUSxPQUFPLGVBQWUsT0FBTyxFQUFFLFNBQVMsTUFBTTtZQUF6RyxDQUNHLE1BQU0sS0FBSyxFQUFFLFFBQVEsRUFBRSxJQUFJLEdBQUcsTUFDN0Isd0JBQUMsUUFBRDtHQUFjO0dBQVksV0FBVTthQUNsQyx3QkFBQyxXQUFEO0lBQVcsTUFBTSxJQUFJLFNBQVMsY0FBYztJQUFtQixPQUFPO0lBQU0sUUFBUTtJQUFNO0dBQVU7Ozs7O0VBQ2hHLEdBRks7Ozs7U0FFTCxDQUNQLEdBQ0Qsd0JBQUMsUUFBRDtHQUFNO0dBQVksV0FBVTthQUE1QixDQUNHLE9BQU0sK0JBQ0g7Ozs7O1VBQ0w7Ozs7OztBQUVQOzs7QUFHQSxTQUFTLGFBQWEsRUFBRSxTQUFTLE1BQU0sYUFBZ0Q7Q0FDckYsTUFBTSxVQUFVO0VBQ2Q7R0FBRSxLQUFLO0dBQUcsT0FBTztFQUFNO0VBQ3ZCO0dBQUUsS0FBSztHQUFJLE9BQU87RUFBTztFQUN6QjtHQUFFLEtBQUs7R0FBSSxPQUFPO0VBQU87RUFDekI7R0FBRSxLQUFLO0dBQUssT0FBTztFQUFTO0NBQzlCO0NBQ0EsTUFBTSxVQUFVLFdBQVcsTUFBTSxNQUFNO0NBQ3ZDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQWtEO0VBQVc7Ozs7WUFDM0Usd0JBQUMsTUFBRDtHQUFJLFdBQVcsR0FBRyxxQkFBcUIsR0FBRztHQUFHLGNBQVc7YUFDckQsUUFBUSxLQUFLLE1BQU07SUFDbEIsTUFBTSxTQUFTLEVBQUUsUUFBUTtJQUN6QixPQUNFLHdCQUFDLE1BQUQ7S0FFRSxnQkFBYyxTQUFTLFNBQVM7S0FDaEMsV0FBVyxHQUNULHVGQUNBLEVBQUUsUUFBUSxPQUFPLFFBQ2pCLFNBQVMsMkNBQTJDLHFDQUN0RDtlQVBGLENBU0csRUFBRSxPQUNGLFNBQVMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQVU7S0FBeUI7Ozs7Z0JBQUksSUFDL0Q7T0FWRyxFQUFFOzs7O1dBVUw7R0FFUixDQUFDO0VBQ0M7Ozs7VUFDRDs7Ozs7O0FBRVQ7O0FBRUEsU0FBUyxVQUFVLEVBQUUsS0FBdUI7Q0FDMUMsTUFBTSxVQUFVLEVBQUUsY0FBYztDQUNoQyxPQUNFLHdCQUFDLE1BQUQ7RUFBSSxXQUFVO1lBQWQ7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLGVBQWdCOzs7O2NBQ3BCLHdCQUFDLE1BQUQsYUFBSSxLQUFFLEVBQUUsT0FBWTs7OztZQUNqQjs7Ozs7O0dBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQsWUFBSSxXQUFZOzs7O2NBQ2hCLHdCQUFDLE1BQUQsWUFBSyxFQUFFLFdBQWU7Ozs7WUFDbkI7Ozs7OztHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUksYUFBYzs7OztjQUNsQix3QkFBQyxNQUFELFlBQUssRUFBRSxXQUFXLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFNOzs7O1lBQ2xEOzs7Ozs7R0FDTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLGVBQWdCOzs7O2NBQ3BCLHdCQUFDLE1BQUQ7S0FBSSxlQUFZO2VBQ2IsVUFBVSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBdUI7S0FBYzs7OztnQkFBSSxHQUFHLEVBQUUsVUFBVSxNQUFNLEVBQUU7SUFDekY7Ozs7WUFDRDs7Ozs7O0VBQ0g7Ozs7OztBQUVSOztBQUVBLFNBQVMsU0FBUyxFQUFFLFFBQTBCO0NBQzVDLE1BQU0sTUFBTSxPQUFPLFdBQVcsY0FBYyxPQUFPLFNBQVMsT0FBTztDQUNuRSxNQUFNLE9BQU8sR0FBRyxLQUFLO0NBQ3JCLE1BQU0sUUFBUTtFQUNaO0dBQUUsT0FBTztHQUE0QixNQUFNLHVEQUF1RCxtQkFBbUIsR0FBRztHQUFLLE1BQU07R0FBa0IsR0FBRztHQUFJLEdBQUc7RUFBRztFQUNsSztHQUFFLE9BQU87R0FBMkIsTUFBTSxtQkFBbUIsbUJBQW1CLElBQUksRUFBRSxRQUFRLG1CQUFtQixHQUFHO0dBQUssTUFBTTtHQUFnQixHQUFHO0dBQUksR0FBRztFQUFHO0VBQzVKO0dBQUUsT0FBTztHQUErQixNQUFNLHlDQUF5QyxtQkFBbUIsSUFBSSxFQUFFLE9BQU8sbUJBQW1CLEdBQUc7R0FBSyxNQUFNO0dBQWlCLEdBQUc7R0FBSSxHQUFHO0VBQUc7Q0FDeEw7Q0FDQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUFrRDtFQUF5Qjs7OztZQUN2RixNQUFNLEtBQUssTUFDVix3QkFBQyxLQUFEO0dBQWdCLE1BQU0sRUFBRTtHQUFNLFFBQU87R0FBUyxLQUFJO0dBQXNCLGNBQVksRUFBRTtHQUFPLFdBQVU7YUFDckcsd0JBQUMsV0FBRDtJQUFXLE1BQU0sRUFBRTtJQUFNLE9BQU8sRUFBRTtJQUFHLFFBQVEsRUFBRTtJQUFHO0dBQVU7Ozs7O0VBQzNELEdBRkssRUFBRTs7OztTQUVQLENBQ0osQ0FDRTs7Ozs7O0FBRVQ7O0FBRUEsU0FBUyxnQkFBZ0IsRUFBRSxLQUF1Qjs7Q0FDaEQsTUFBTSxDQUFDLEtBQUssVUFBVSxTQUFnQyxTQUFTO0NBQy9ELE1BQU0sS0FBSyxNQUFNO0NBQ2pCLE1BQU0sT0FBTyxDQUNYO0VBQUUsS0FBSztFQUFvQixPQUFPO0NBQWtCLEdBQ3BEO0VBQUUsS0FBSztFQUFvQixPQUFPLGlDQUFpQyxFQUFFLFlBQVk7Q0FBRyxDQUN0RjtDQUNBLE1BQU0sUUFBUSxZQUFZLEVBQUU7Q0FDNUIsT0FDRSx3QkFBQyxXQUFEO0VBQVMsY0FBVztFQUFZLFdBQVU7WUFBMUMsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLE1BQUs7SUFBVSxjQUFXO0lBQW1CLFdBQVU7Y0FDekQsS0FBSyxLQUFLLE1BQU07S0FDZixNQUFNLFNBQVMsRUFBRSxRQUFRO0tBQ3pCLE9BQ0Usd0JBQUMsVUFBRDtNQUVFLE1BQUs7TUFDTCxNQUFLO01BQ0wsSUFBSSxHQUFHLEdBQUcsR0FBRyxFQUFFO01BQ2YsaUJBQWU7TUFDZixpQkFBZSxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUk7TUFDOUIsVUFBVSxTQUFTLElBQUksQ0FBQztNQUN4QixlQUFlLE9BQU8sRUFBRSxHQUFHO01BQzNCLFlBQVksTUFBTTtPQUNoQixJQUFJLEVBQUUsUUFBUSxnQkFBZ0IsRUFBRSxRQUFRLGFBQWE7UUFDbkQsTUFBTSxPQUFPLFFBQVEsWUFBWSxZQUFZO1FBQzdDLE9BQU8sSUFBSTtRQUNYLFNBQVMsZUFBZSxHQUFHLEdBQUcsR0FBRyxNQUFNLENBQUMsRUFBRSxNQUFNO09BQ2xEO01BQ0Y7TUFDQSxXQUFXLEdBQ1Qsd0VBQ0EsU0FBUywwQkFBMEIsbUNBQ3JDO2dCQW5CRixDQXFCRyxFQUFFLE9BQ0gsd0JBQUMsUUFBRDtPQUFNO09BQVksV0FBVyxHQUFHLGtCQUFrQixTQUFTLGVBQWUsZ0JBQWdCO01BQUk7Ozs7Y0FDeEY7UUF0QkQsRUFBRTs7OztZQXNCRDtJQUVaLENBQUM7R0FDRTs7OzthQUNMLHdCQUFDLE9BQUQsRUFBSyxXQUFVLGFBQWM7Ozs7V0FDMUI7Ozs7O1lBRUosUUFBUSxZQUNQLHdCQUFDLE9BQUQ7R0FBSyxNQUFLO0dBQVcsSUFBSSxHQUFHLEdBQUc7R0FBaUIsbUJBQWlCLEdBQUcsR0FBRztHQUFXLFdBQVU7YUFBNUYsQ0FDRyxFQUFFLFlBQVksTUFBTSxNQUFNLENBQUMsQ0FBQyxLQUFLLE1BQ2hDLHdCQUFDLEtBQUQ7SUFBd0IsV0FBVTtjQUMvQjtHQUNBLEdBRkssRUFBRSxNQUFNLEdBQUcsRUFBRTs7OztVQUVsQixDQUNKLEdBQ0Qsd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBZDtLQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBNEI7S0FBUzs7OztlQUNuRCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZDtPQUFzQztPQUFZO09BQU07TUFBOEQ7Ozs7O2FBQ25IOzs7OztLQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBNEI7S0FBYTs7OztlQUN2RCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUF1QyxFQUFFLGlCQUFnQiw2Q0FBK0M7Ozs7O2FBQ3JHOzs7OztLQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBNEI7S0FBc0I7Ozs7ZUFDaEUsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQ7T0FBc0M7T0FDTCxFQUFFLGFBQWE7T0FBSTtNQUNoRDs7Ozs7YUFDRDs7Ozs7SUFDSDs7Ozs7V0FDRDs7Ozs7YUFFTCx3QkFBQyxPQUFEO0dBQUssTUFBSztHQUFXLElBQUksR0FBRyxHQUFHO0dBQWlCLG1CQUFpQixHQUFHLEdBQUc7R0FBVyxXQUFVO2FBQTVGLENBQ0Usd0JBQUMsUUFBRDtJQUFRLFFBQVEsRUFBRTtJQUFRLE9BQU8sRUFBRTtHQUFjOzs7O2FBQ2pELHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWI7S0FBcUM7S0FDdkIsRUFBRSxPQUFPLGVBQWUsT0FBTztLQUFFO0tBQW9CLEVBQUU7S0FBWTtJQUM5RTs7Ozs7V0FDQTs7Ozs7VUFFQTs7Ozs7O0FBRWI7OztBQUVBLE1BQU0sbUJBQW1COztBQUd6QixTQUFTLGdCQUFnQixFQUFFLEtBQXVCOztDQUNoRCxNQUFNLFVBQVUsV0FBVztFQUFFLEdBQUcsRUFBRTtFQUFZLE1BQU07RUFBVSxVQUFVO0VBQUksTUFBTTtDQUFFLENBQUM7Q0FDckYsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLENBQUM7Q0FDbEMsTUFBTSxTQUFTLFFBQVEsTUFBTSxTQUFTLENBQUMsRUFBQyxDQUFFLFFBQVEsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsZUFBZSxFQUFFLFVBQVU7Q0FDdEcsTUFBTSxRQUFRLEtBQUssSUFBSSxHQUFHLEtBQUssS0FBSyxNQUFNLFNBQVMsZ0JBQWdCLENBQUM7Q0FDcEUsTUFBTSxVQUFVLEtBQUssSUFBSSxNQUFNLFFBQVEsQ0FBQztDQUN4QyxNQUFNLFVBQVUsTUFBTSxNQUFNLFVBQVUsa0JBQWtCLFVBQVUsbUJBQW1CLGdCQUFnQjtDQUVyRyxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxtQkFBZ0I7RUFBZ0IsV0FBVTtZQUFuRCxDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxNQUFEO0lBQUksSUFBRztJQUFnQixXQUFVO2NBQThDO0dBRTNFOzs7O2FBQ0osd0JBQUMsT0FBRCxFQUFLLFdBQVUsYUFBYzs7OztXQUMxQjs7Ozs7WUFDSixRQUFRLFVBQ1Asd0JBQUMsWUFBRDtHQUFZO0dBQVEsT0FBTyxRQUFRO0dBQU8sZUFBZSxLQUFLLFFBQVEsUUFBUTtHQUFHLFVBQVUsUUFBUTtFQUFhOzs7O2FBRWhILHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLFFBQVEsWUFDTCxNQUFNLEtBQUssRUFBRSxRQUFRLGlCQUFpQixJQUFJLEdBQUcsTUFDM0Msd0JBQUMsTUFBRCxZQUNFLHdCQUFDLGlCQUFELEVBQWlCLE1BQUssVUFBVzs7OztjQUMvQixHQUZLOzs7O1lBRUwsQ0FDTCxJQUNELFFBQVEsS0FBSyxTQUNYLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxTQUFEO01BQVMsS0FBSztNQUFNLE1BQUs7S0FBVzs7OztjQUNsQyxHQUZLLEtBQUs7Ozs7WUFFVixDQUNMO0lBQ0g7Ozs7O0lBQ0gsQ0FBQyxRQUFRLGFBQWEsTUFBTSxXQUFXLElBQ3RDLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWdDO0lBQTJDOzs7O2VBQ3RGO0lBQ0gsUUFBUSxJQUNQLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQTBCLE1BQUs7S0FBUSxjQUFXO2VBQzlELE1BQU0sS0FBSyxFQUFFLFFBQVEsTUFBTSxJQUFJLEdBQUcsTUFDakMsd0JBQUMsVUFBRDtNQUVFLE1BQUs7TUFDTCxjQUFZLDhCQUE4QixJQUFJLEVBQUUsTUFBTTtNQUN0RCxnQkFBYyxNQUFNO01BQ3BCLGVBQWUsUUFBUSxDQUFDO01BQ3hCLFdBQVcsR0FBRyxxREFBcUQsTUFBTSxXQUFXLFlBQVk7S0FDakcsR0FOTTs7OztZQU1OLENBQ0Y7SUFDRTs7OztlQUNIO0dBQ0Q7Ozs7O1VBRUE7Ozs7OztBQUViOzs7OztBQUVBLFNBQVMsaUJBQWlCO0NBQ3hCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBMkM7RUFBVSxjQUFXO1lBQS9FO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWixNQUFNLEtBQUssRUFBRSxRQUFRLEVBQUUsSUFBSSxHQUFHLE1BQzdCLHdCQUFDLFVBQUQsRUFBa0IsV0FBVSx1QkFBd0IsR0FBckM7Ozs7V0FBcUMsQ0FDckQ7R0FDRTs7Ozs7R0FDTCx3QkFBQyxVQUFELEVBQVUsV0FBVSwrQ0FBZ0Q7Ozs7O0dBQ3BFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxvQkFBcUI7Ozs7O0tBQ3pDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLG9CQUFxQjs7Ozs7S0FDekMsd0JBQUMsVUFBRCxFQUFVLFdBQVUsc0JBQXVCOzs7OztLQUMzQyx3QkFBQyxVQUFELEVBQVUsV0FBVSxzQkFBdUI7Ozs7O0lBQ3hDOzs7Ozs7RUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibmZ0LWRldGFpbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBnZXRSb3V0ZUFwaSwgdXNlTmF2aWdhdGUsIHVzZVJvdXRlciB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyB1c2VJZCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IGNoYWluTGFiZWxzLCB0eXBlIE5mdERldGFpbCB9IGZyb20gJ0AvYXBpL2NvbnRyYWN0cydcbmltcG9ydCB7IEFwaUVycm9yLCB0b0FwaUVycm9yIH0gZnJvbSAnQC9hcGkvZXJyb3JzJ1xuaW1wb3J0IHsgQnJlYWRjcnVtYiwgRXJyb3JTdGF0ZSwgTm90Rm91bmRTdGF0ZSB9IGZyb20gJ0AvY29tcG9uZW50cy9jb21tb24vc3RhdGVzJ1xuaW1wb3J0IHsgTGl2ZUluZGljYXRvciB9IGZyb20gJ0AvY29tcG9uZW50cy9sYXlvdXQvZm9vdGVyJ1xuaW1wb3J0IHsgRmF2b3JpdGVCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvbmZ0L2Zhdm9yaXRlLWJ1dHRvbidcbmltcG9ydCB7IE5mdENhcmQsIE5mdENhcmRTa2VsZXRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9uZnQvbmZ0LWNhcmQnXG5pbXBvcnQgeyBQcmljZSB9IGZyb20gJ0AvY29tcG9uZW50cy9uZnQvcHJpY2UnXG5pbXBvcnQgeyBRdWFudGl0eVN0ZXBwZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvbmZ0L3F1YW50aXR5LXN0ZXBwZXInXG5pbXBvcnQgeyBBbGVydCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9hbGVydCdcbmltcG9ydCB7IERpYWxvZywgRGlhbG9nQ29udGVudCwgRGlhbG9nVGl0bGUgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvZGlhbG9nJ1xuaW1wb3J0IHsgRmlnbWFJY29uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2ZpZ21hLWljb24nXG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9za2VsZXRvbidcbmltcG9ydCB7IHVzZUFkZFRvQ2FydCwgdXNlQ2FydCwgdXNlTmZ0LCB1c2VOZnRMaXN0IH0gZnJvbSAnQC9ob29rcy91c2UtYXBpJ1xuaW1wb3J0IHsgdXNlSXNEZXNrdG9wIH0gZnJvbSAnQC9ob29rcy91c2UtbWVkaWEnXG5pbXBvcnQgeyB1c2VQYWdlVGl0bGUgfSBmcm9tICdAL2hvb2tzL3VzZS1wYWdlJ1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAnQC9zdG9yZXMvdG9hc3RzJ1xuXG5jb25zdCByb3V0ZSA9IGdldFJvdXRlQXBpKCcvbmZ0LyRuZnRJZCcpXG5cbmV4cG9ydCBmdW5jdGlvbiBOZnREZXRhaWxQYWdlKCkge1xuICBjb25zdCB7IG5mdElkIH0gPSByb3V0ZS51c2VQYXJhbXMoKVxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3QgcWMgPSB1c2VRdWVyeUNsaWVudCgpXG4gIGNvbnN0IGlzRGVza3RvcCA9IHVzZUlzRGVza3RvcCgpXG4gIGNvbnN0IG5mdCA9IHVzZU5mdChuZnRJZClcbiAgY29uc3QgY2FydCA9IHVzZUNhcnQoKVxuICBjb25zdCBhZGQgPSB1c2VBZGRUb0NhcnQoKVxuICBjb25zdCBbcmVxdWVzdGVkLCBzZXRSZXF1ZXN0ZWRdID0gdXNlU3RhdGUoMSlcbiAgdXNlUGFnZVRpdGxlKG5mdC5kYXRhPy5uYW1lID8/ICdORlQnKVxuXG4gIGNvbnN0IGRhdGEgPSBuZnQuZGF0YVxuICBjb25zdCBpbkNhcnQgPSBjYXJ0LmRhdGE/Lml0ZW1zLmZpbmQoKGkpID0+IGkubmZ0SWQgPT09IG5mdElkKT8ucXVhbnRpdHkgPz8gMFxuICAvLyBMaW1pdGUgPSBtZW5vciBlbnRyZSBlc3RvcXVlIGUgbcOheGltbyBwb3IgcGVkaWRvLCBkZXNjb250YW5kbyBvIHF1ZSBqw6EgZXN0w6Egbm8gY2FycmluaG8uXG4gIGNvbnN0IG1heEFkZCA9IGRhdGEgPyBNYXRoLm1heCgwLCBNYXRoLm1pbihkYXRhLmF2YWlsYWJsZSwgZGF0YS5tYXhQZXJPcmRlcikgLSBpbkNhcnQpIDogMFxuICAvLyBTZSBvIGVzdG9xdWUgY2FpciBlbSB0ZW1wbyByZWFsLCBhIHF1YW50aWRhZGUgZXNjb2xoaWRhIGFjb21wYW5oYSBvIG5vdm8gbGltaXRlIChkZXJpdmFkbyBubyByZW5kZXIpLlxuICBjb25zdCBxdWFudGl0eSA9IE1hdGgubWluKE1hdGgubWF4KDEsIHJlcXVlc3RlZCksIE1hdGgubWF4KDEsIG1heEFkZCkpXG5cbiAgYXN5bmMgZnVuY3Rpb24gYWRkVG9DYXJ0KGdvVG9DYXJ0OiBib29sZWFuKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGFkZC5tdXRhdGVBc3luYyh7IG5mdElkLCBxdWFudGl0eSB9KVxuICAgICAgaWYgKGdvVG9DYXJ0KSB7XG4gICAgICAgIHZvaWQgbmF2aWdhdGUoeyB0bzogJy9jYXJ0JyB9KVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cbiAgICAgIHRvYXN0KHsgdGl0bGU6ICdBZGljaW9uYWRvIGFvIGNhcnJpbmhvJywgZGVzY3JpcHRpb246IGAke3F1YW50aXR5fSDDlyAke2RhdGE/Lm5hbWV9YCwgdmFyaWFudDogJ3N1Y2Nlc3MnIH0pXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc3QgZXJyID0gdG9BcGlFcnJvcihlKVxuICAgICAgdG9hc3QoeyB0aXRsZTogJ07Do28gZm9pIHBvc3PDrXZlbCBhZGljaW9uYXInLCBkZXNjcmlwdGlvbjogZXJyLm1lc3NhZ2UsIHZhcmlhbnQ6ICd3YXJuaW5nJyB9KVxuICAgICAgLy8gRXN0b3F1ZS9saW1pdGUgbXVkb3U6IGF0dWFsaXphIGEgdGVsYSBjb20gb3MgZGFkb3MgcmVhaXMuXG4gICAgICB2b2lkIHFjLmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsnbmZ0cycsICdkZXRhaWwnLCBuZnRJZF0gfSlcbiAgICB9XG4gIH1cblxuICBpZiAobmZ0LmlzUGVuZGluZykgcmV0dXJuIDxEZXRhaWxTa2VsZXRvbiAvPlxuICBpZiAobmZ0LmlzRXJyb3IpIHtcbiAgICBpZiAobmZ0LmVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgbmZ0LmVycm9yLmNvZGUgPT09ICdOT1RfRk9VTkQnKSB7XG4gICAgICByZXR1cm4gPE5vdEZvdW5kU3RhdGUgdGl0bGU9XCJORlQgbsOjbyBlbmNvbnRyYWRvXCIgZGVzY3JpcHRpb249XCJFc3RlIE5GVCBuw6NvIGV4aXN0ZSBvdSBmb2kgcmVtb3ZpZG8gZG8gY2F0w6Fsb2dvLlwiIC8+XG4gICAgfVxuICAgIHJldHVybiA8RXJyb3JTdGF0ZSBlcnJvcj17bmZ0LmVycm9yfSBvblJldHJ5PXsoKSA9PiB2b2lkIG5mdC5yZWZldGNoKCl9IHJldHJ5aW5nPXtuZnQuaXNGZXRjaGluZ30gLz5cbiAgfVxuICBjb25zdCBuID0gbmZ0LmRhdGFcbiAgY29uc3QgcHVyY2hhc2UgPSB7XG4gICAgcXVhbnRpdHksXG4gICAgbWF4QWRkLFxuICAgIGluQ2FydCxcbiAgICBwZW5kaW5nOiBhZGQuaXNQZW5kaW5nLFxuICAgIG9uUXVhbnRpdHk6IHNldFJlcXVlc3RlZCxcbiAgICBvbkJ1eTogKCkgPT4gdm9pZCBhZGRUb0NhcnQodHJ1ZSksXG4gICAgb25BZGQ6ICgpID0+IHZvaWQgYWRkVG9DYXJ0KGZhbHNlKSxcbiAgfVxuXG4gIHJldHVybiBpc0Rlc2t0b3AgPyA8RGVza3RvcERldGFpbCBuPXtufSBwdXJjaGFzZT17cHVyY2hhc2V9IC8+IDogPE1vYmlsZURldGFpbCBuPXtufSBwdXJjaGFzZT17cHVyY2hhc2V9IC8+XG59XG5cbnR5cGUgUHVyY2hhc2UgPSB7XG4gIHF1YW50aXR5OiBudW1iZXJcbiAgbWF4QWRkOiBudW1iZXJcbiAgaW5DYXJ0OiBudW1iZXJcbiAgcGVuZGluZzogYm9vbGVhblxuICBvblF1YW50aXR5OiAocTogbnVtYmVyKSA9PiB2b2lkXG4gIG9uQnV5OiAoKSA9PiB2b2lkXG4gIG9uQWRkOiAoKSA9PiB2b2lkXG59XG5cbmZ1bmN0aW9uIERlc2t0b3BEZXRhaWwoeyBuLCBwdXJjaGFzZSB9OiB7IG46IE5mdERldGFpbDsgcHVyY2hhc2U6IFB1cmNoYXNlIH0pIHtcbiAgY29uc3QgW2ltYWdlLCBzZXRJbWFnZV0gPSB1c2VTdGF0ZSgxKVxuICBjb25zdCBbem9vbSwgc2V0Wm9vbV0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3Qgc29sZE91dCA9IG4uYXZhaWxhYmxlID09PSAwXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTI0XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgICAgPEJyZWFkY3J1bWIgaXRlbXM9e1t7IGxhYmVsOiAnSW7DrWNpbycsIHRvOiAnLycgfSwgeyBsYWJlbDogJ01lcmNhZG8nLCB0bzogJy8nLCBoYXNoOiAnY2F0YWxvZ28nIH1dfSAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLThcIj5cbiAgICAgICAgICA8c2VjdGlvbiBhcmlhLWxhYmVsPVwiR2FsZXJpYVwiIGNsYXNzTmFtZT1cImZsZXggaC1bNDQ4cHhdIHNocmluay0wIGl0ZW1zLWNlbnRlciBnYXAtN1wiPlxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImZsZXggdy1bMTAwcHhdIGZsZXgtY29sIGdhcC00XCI+XG4gICAgICAgICAgICAgIHtuLmltYWdlcy5tYXAoKHNyYywgaSkgPT4gKFxuICAgICAgICAgICAgICAgIDxsaSBrZXk9e2Ake3NyY30tJHtpfWB9IGNsYXNzTmFtZT1cInJvdW5kZWQtWzZweF0gYmctY2FyZFwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SW1hZ2UoaSl9XG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BWZXIgaW1hZ2VtICR7aSArIDF9IGRlICR7bi5pbWFnZXMubGVuZ3RofWB9XG4gICAgICAgICAgICAgICAgICAgIGFyaWEtY3VycmVudD17aSA9PT0gaW1hZ2V9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgJ2Jsb2NrIHNpemUtWzEwMHB4XSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1bOHB4XSBib3JkZXInLFxuICAgICAgICAgICAgICAgICAgICAgIGkgPT09IGltYWdlID8gJ2JvcmRlci1wcmltYXJ5JyA6ICdib3JkZXItdHJhbnNwYXJlbnQgb3BhY2l0eS04MCBob3ZlcjpvcGFjaXR5LTEwMCcsXG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtzcmN9IGFsdD1cIlwiIHdpZHRoPXsxMDB9IGhlaWdodD17MTAwfSBjbGFzc05hbWU9XCJzaXplLWZ1bGwgb2JqZWN0LWNvdmVyXCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZ3JpZCBzaXplLVs0NDRweF0gcGxhY2UtaXRlbXMtY2VudGVyIHJvdW5kZWQtWzZweF0gYmctY2FyZCBwLTRcIj5cbiAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgIHNyYz17bi5pbWFnZXNbaW1hZ2VdfVxuICAgICAgICAgICAgICAgIGFsdD17YCR7bi5uYW1lfSwgaW1hZ2VtICR7aW1hZ2UgKyAxfSBkZSAke24uaW1hZ2VzLmxlbmd0aH1gfVxuICAgICAgICAgICAgICAgIHdpZHRoPXs0MDR9XG4gICAgICAgICAgICAgICAgaGVpZ2h0PXs0MDR9XG4gICAgICAgICAgICAgICAgZmV0Y2hQcmlvcml0eT1cImhpZ2hcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNpemUtWzQwNHB4XSByb3VuZGVkLTN4bCBvYmplY3QtY292ZXJcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkFtcGxpYXIgaW1hZ2VtXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRab29tKHRydWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTMgdG9wLVsxNXB4XSBncmlkIHNpemUtWzMwcHhdIHBsYWNlLWl0ZW1zLWNlbnRlciByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPEZpZ21hSWNvbiBuYW1lPVwiaWNvbi16b29tXCIgd2lkdGg9ezMwfSBvcmlnaW5hbCAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICAgIDxzZWN0aW9uIGFyaWEtbGFiZWw9XCJJbmZvcm1hw6fDtWVzXCIgY2xhc3NOYW1lPVwiZmxleCBtaW4tdy0wIGZsZXgtMSBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1ib2xkIGxlYWRpbmctbm9ybWFsIHRleHQtZm9yZWdyb3VuZFwiPntuLm5hbWV9PC9oMT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsyMnB4XSBmb250LWJvbGQgbGVhZGluZy00IHRleHQtYWNjZW50XCIgZGF0YS10ZXN0aWQ9XCJkZXRhaWwtcHJpY2VcIj5cbiAgICAgICAgICAgICAgICAgIDxQcmljZSB2YWx1ZT17bi5wcmljZX0gLz5cbiAgICAgICAgICAgICAgICAgIHtuLnByZXZpb3VzUHJpY2UgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1sZyBmb250LW5vcm1hbCB0ZXh0LXN1YnRsZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5QcmXDp28gYW50ZXJpb3I6IDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8UHJpY2UgdmFsdWU9e24ucHJldmlvdXNQcmljZX0gY2xhc3NOYW1lPVwiZm9udC1ub3JtYWxcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPFJhdGluZyByYXRpbmc9e24ucmF0aW5nfSBjb3VudD17bi5yZXZpZXdDb3VudH0gLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiay1oYWlybGluZSBtdC0wXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtYm9sZCBsZWFkaW5nLTQgdGV4dC1mb3JlZ3JvdW5kXCI+U29icmUgZXN0ZSBORlQ6PC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBsZWFkaW5nLTYgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e24uc3VtbWFyeX08L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPEVkaXRpb25QaWxscyBlZGl0aW9uPXtuLmVkaXRpb259IC8+XG5cbiAgICAgICAgICAgIHtzb2xkT3V0ID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgICAgIDxBbGVydCB2YXJpYW50PVwid2FybmluZ1wiIHRpdGxlPVwiRXN0YSBlZGnDp8OjbyBlc3TDoSBlc2dvdGFkYVwiIGNsYXNzTmFtZT1cImZsZXgtMSBweS0zXCI+XG4gICAgICAgICAgICAgICAgICBGYXZvcml0ZSBwYXJhIGFjb21wYW5oYXIgbm92YXMgZWRpw6fDtWVzLlxuICAgICAgICAgICAgICAgIDwvQWxlcnQ+XG4gICAgICAgICAgICAgICAgPEZhdm9yaXRlQnV0dG9uIG5mdElkPXtuLmlkfSBuYW1lPXtuLm5hbWV9IGlzRmF2b3JpdGU9e24uaXNGYXZvcml0ZX0gLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPFF1YW50aXR5U3RlcHBlclxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwicm91bmRcIlxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlF1YW50aWRhZGUgYSBjb21wcmFyXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3B1cmNoYXNlLnF1YW50aXR5fVxuICAgICAgICAgICAgICAgICAgICBtYXg9e01hdGgubWF4KDEsIHB1cmNoYXNlLm1heEFkZCl9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtwdXJjaGFzZS5vblF1YW50aXR5fVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cHVyY2hhc2UubWF4QWRkID09PSAwfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwdXJjaGFzZS5tYXhBZGQgPT09IDAgfHwgcHVyY2hhc2UucGVuZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtwdXJjaGFzZS5vbkJ1eX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGgtMTAgdy1bMTMwcHhdIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLVs2cHhdIGJnLXByaW1hcnkgdGV4dC1zbSBmb250LWJvbGQgbGVhZGluZy01IHRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kIGhvdmVyOmJyaWdodG5lc3MtMTEwIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge3B1cmNoYXNlLnBlbmRpbmcgPyAnQURJQ0lPTkFORE/igKYnIDogJ0NPTVBSQVInfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPEZhdm9yaXRlQnV0dG9uIG5mdElkPXtuLmlkfSBuYW1lPXtuLm5hbWV9IGlzRmF2b3JpdGU9e24uaXNGYXZvcml0ZX0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxQdXJjaGFzZU5vdGVzIHB1cmNoYXNlPXtwdXJjaGFzZX0gbWF4UGVyT3JkZXI9e24ubWF4UGVyT3JkZXJ9IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxUb2tlbkluZm8gbj17bn0gLz5cbiAgICAgICAgICAgICAgPFNoYXJlUm93IG5hbWU9e24ubmFtZX0gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPERlc2NyaXB0aW9uVGFicyBuPXtufSAvPlxuICAgICAgPFJlbGF0ZWRQcm9kdWN0cyBuPXtufSAvPlxuXG4gICAgICA8RGlhbG9nIG9wZW49e3pvb219IG9uT3BlbkNoYW5nZT17c2V0Wm9vbX0+XG4gICAgICAgIDxEaWFsb2dDb250ZW50IGNsYXNzTmFtZT1cIm1heC13LVttaW4oOTB2dyw3NjBweCldIHAtNFwiPlxuICAgICAgICAgIDxEaWFsb2dUaXRsZSBjbGFzc05hbWU9XCJzci1vbmx5XCI+e24ubmFtZX08L0RpYWxvZ1RpdGxlPlxuICAgICAgICAgIDxpbWcgc3JjPXtuLmltYWdlc1tpbWFnZV19IGFsdD17bi5uYW1lfSBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC0zeGwgb2JqZWN0LWNvdmVyXCIgLz5cbiAgICAgICAgPC9EaWFsb2dDb250ZW50PlxuICAgICAgPC9EaWFsb2c+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gTW9iaWxlRGV0YWlsKHsgbiwgcHVyY2hhc2UgfTogeyBuOiBOZnREZXRhaWw7IHB1cmNoYXNlOiBQdXJjaGFzZSB9KSB7XG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG4gIGNvbnN0IHNvbGRPdXQgPSBuLmF2YWlsYWJsZSA9PT0gMFxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiLW14LTYgZmxleCBmbGV4LWNvbCBwYi1bMTgwcHhdXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtWzUwNnB4XSBiZy1bbGluZWFyLWdyYWRpZW50KDEzNy42ZGVnLCMyNDE2MTJfMTIlLCMyZjFkMTVfMTA2LjYlKV0gcHgtNyBwdC1bMjNweF1cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJWb2x0YXJcIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gKHdpbmRvdy5oaXN0b3J5Lmxlbmd0aCA+IDEgPyByb3V0ZXIuaGlzdG9yeS5iYWNrKCkgOiB2b2lkIHJvdXRlci5uYXZpZ2F0ZSh7IHRvOiAnLycgfSkpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JpZCBzaXplLVszNXB4XSBwbGFjZS1pdGVtcy1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLXN1cmZhY2UtcmFpc2VkIHRleHQtYWNjZW50XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RmlnbWFJY29uIG5hbWU9XCJtLWFycm93LWxlZnRcIiB3aWR0aD17MTF9IGhlaWdodD17Nn0gY2xhc3NOYW1lPVwicm90YXRlLTkwXCIgLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8TGl2ZUluZGljYXRvciAvPlxuICAgICAgICAgIDxGYXZvcml0ZUJ1dHRvbiBuZnRJZD17bi5pZH0gbmFtZT17bi5uYW1lfSBpc0Zhdm9yaXRlPXtuLmlzRmF2b3JpdGV9IHZhcmlhbnQ9XCJjaGlwLWxnXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxpbWdcbiAgICAgICAgICBzcmM9e24uaW1hZ2VzWzBdfVxuICAgICAgICAgIGFsdD17bi5uYW1lfVxuICAgICAgICAgIHdpZHRoPXszNjF9XG4gICAgICAgICAgaGVpZ2h0PXszNTZ9XG4gICAgICAgICAgZmV0Y2hQcmlvcml0eT1cImhpZ2hcIlxuICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgaC1bMzU2cHhdIHctZnVsbCByb3VuZGVkLTN4bCBvYmplY3QtY292ZXJcIlxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxzZWN0aW9uIGFyaWEtbGFiZWw9XCJJbmZvcm1hw6fDtWVzXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgLW10LVsxMTRweF0gZmxleCBmbGV4LWNvbCBnYXAtMyByb3VuZGVkLXQtWzMxcHhdIGJnLWNhcmQgcHgtNiBwYi02IHB0LThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgbGVhZGluZy02IHRleHQtZm9yZWdyb3VuZFwiPntuLm5hbWV9PC9oMT5cbiAgICAgICAgICA8cFxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLVsyN3B4XSBzaHJpbmstMCBpdGVtcy1jZW50ZXIgZ2FwLTEgcm91bmRlZC1bMzJweF0gYm9yZGVyIGJvcmRlci1wcmltYXJ5IHB4LTEuNSB0ZXh0LXNtIGxlYWRpbmctNFwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPXtgTm90YSAke24ucmF0aW5nLnRvTG9jYWxlU3RyaW5nKCdwdC1CUicpfSBkZSA1LCAke24ucmV2aWV3Q291bnR9IGF2YWxpYcOnw7Vlc2B9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEZpZ21hSWNvbiBuYW1lPVwibS1zdGFyXCIgd2lkdGg9ezEyfSBoZWlnaHQ9ezExfSBjbGFzc05hbWU9XCJ0ZXh0LXdhcm5pbmdcIiAvPlxuICAgICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIHtuLnJhdGluZy50b0xvY2FsZVN0cmluZygncHQtQlInKX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAoe24ucmV2aWV3Q291bnR9KVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gbGVhZGluZy02IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntuLnN1bW1hcnl9PC9wPlxuICAgICAgICA8RWRpdGlvblBpbGxzIGVkaXRpb249e24uZWRpdGlvbn0gZ2FwPVwiZ2FwLTNcIiAvPlxuICAgICAgICA8VG9rZW5JbmZvIG49e259IC8+XG4gICAgICAgIHtzb2xkT3V0ID8gKFxuICAgICAgICAgIDxBbGVydCB2YXJpYW50PVwid2FybmluZ1wiIHRpdGxlPVwiRXN0YSBlZGnDp8OjbyBlc3TDoSBlc2dvdGFkYVwiPlxuICAgICAgICAgICAgRmF2b3JpdGUgcGFyYSBhY29tcGFuaGFyIG5vdmFzIGVkacOnw7Vlcy5cbiAgICAgICAgICA8L0FsZXJ0PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxQdXJjaGFzZU5vdGVzIHB1cmNoYXNlPXtwdXJjaGFzZX0gbWF4UGVyT3JkZXI9e24ubWF4UGVyT3JkZXJ9IC8+XG4gICAgICAgICl9XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBwdC0xMFwiPlxuICAgICAgICA8RGVzY3JpcHRpb25UYWJzIG49e259IC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBwdC0xMFwiPlxuICAgICAgICA8UmVsYXRlZFByb2R1Y3RzIG49e259IC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC14LTAgYm90dG9tLTAgei00MCByb3VuZGVkLXQtWzQwcHhdIGJnLWNhcmQgcHgtNiBwYi05IHB0LTUgc2hhZG93LVswXzBfMTBweF9yZ2JhKDEwLDYsNCwwLjQ1KV1cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC01XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW0gbGVhZGluZy00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlF0ZC48L3NwYW4+XG4gICAgICAgICAgICAgIDxRdWFudGl0eVN0ZXBwZXJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwicGlsbFwiXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJRdWFudGlkYWRlIGEgY29tcHJhclwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3B1cmNoYXNlLnF1YW50aXR5fVxuICAgICAgICAgICAgICAgIG1heD17TWF0aC5tYXgoMSwgcHVyY2hhc2UubWF4QWRkKX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17cHVyY2hhc2Uub25RdWFudGl0eX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17c29sZE91dCB8fCBwdXJjaGFzZS5tYXhBZGQgPT09IDB9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIGxlYWRpbmctNCB0ZXh0LWFjY2VudFwiIGRhdGEtdGVzdGlkPVwiZGV0YWlsLXByaWNlXCI+XG4gICAgICAgICAgICAgIDxQcmljZSB2YWx1ZT17bi5wcmljZX0gLz5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17c29sZE91dCB8fCBwdXJjaGFzZS5tYXhBZGQgPT09IDAgfHwgcHVyY2hhc2UucGVuZGluZ31cbiAgICAgICAgICAgICAgb25DbGljaz17cHVyY2hhc2Uub25CdXl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC1bNjBweF0gZmxleC0xIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLVs0MHB4XSBiZy1bbGluZWFyLWdyYWRpZW50KDEwMGRlZywjZDI4YTRjXzQlLHJnYmEoMjEwLDEzOCw3NiwwLjgpXzEyMiUpXSB0ZXh0LWJhc2UgZm9udC1ib2xkIGxlYWRpbmctNSB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3NvbGRPdXQgPyAnRXNnb3RhZG8nIDogcHVyY2hhc2UucGVuZGluZyA/ICdBZGljaW9uYW5kb+KApicgOiAnQ29tcHJhciBORlQnfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQWRpY2lvbmFyIGFvIGNhcnJpbmhvXCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NvbGRPdXQgfHwgcHVyY2hhc2UubWF4QWRkID09PSAwIHx8IHB1cmNoYXNlLnBlbmRpbmd9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9e3B1cmNoYXNlLm9uQWRkfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncmlkIHNpemUtWzYwcHhdIHNocmluay0wIHBsYWNlLWl0ZW1zLWNlbnRlciByb3VuZGVkLVs0MHB4XSBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1zdXJmYWNlLXJhaXNlZCB0ZXh0LXN1YnRsZSBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEZpZ21hSWNvbiBuYW1lPVwibS1zaG9wXCIgd2lkdGg9ezIwfSAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gUHVyY2hhc2VOb3Rlcyh7IHB1cmNoYXNlLCBtYXhQZXJPcmRlciB9OiB7IHB1cmNoYXNlOiBQdXJjaGFzZTsgbWF4UGVyT3JkZXI6IG51bWJlciB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICA8c3Bhbj5Nw6F4aW1vIGRlIHttYXhQZXJPcmRlcn0gcG9yIHBlZGlkby48L3NwYW4+XG4gICAgICB7cHVyY2hhc2UuaW5DYXJ0ID4gMCA/IDxzcGFuIGRhdGEtdGVzdGlkPVwiaW4tY2FydC1ub3RlXCI+Vm9jw6ogasOhIHRlbSB7cHVyY2hhc2UuaW5DYXJ0fSBubyBjYXJyaW5oby48L3NwYW4+IDogbnVsbH1cbiAgICAgIHtwdXJjaGFzZS5tYXhBZGQgPT09IDAgPyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFjY2VudFwiPlZvY8OqIGrDoSB0ZW0gYSBxdWFudGlkYWRlIG3DoXhpbWEgZGlzcG9uw612ZWwgbm8gY2FycmluaG8uPC9zcGFuPiA6IG51bGx9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gUmF0aW5nKHsgcmF0aW5nLCBjb3VudCB9OiB7IHJhdGluZzogbnVtYmVyOyBjb3VudDogbnVtYmVyIH0pIHtcbiAgY29uc3QgZmlsbGVkID0gTWF0aC5mbG9vcihyYXRpbmcpXG4gIHJldHVybiAoXG4gICAgPHAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIiBhcmlhLWxhYmVsPXtgTm90YSAke3JhdGluZy50b0xvY2FsZVN0cmluZygncHQtQlInKX0gZGUgNSwgJHtjb3VudH0gYXZhbGlhw6fDtWVzIGRlIGNvbGVjaW9uYWRvcmVzYH0+XG4gICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogNSB9LCAoXywgaSkgPT4gKFxuICAgICAgICA8c3BhbiBrZXk9e2l9IGFyaWEtaGlkZGVuIGNsYXNzTmFtZT1cImdyaWQgc2l6ZS1bMTVweF0gcGxhY2UtaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgPEZpZ21hSWNvbiBuYW1lPXtpIDwgZmlsbGVkID8gJ2ljb24tc3RhcicgOiAnaWNvbi1zdGFyLWVtcHR5J30gd2lkdGg9ezEyLjV9IGhlaWdodD17MTEuOX0gb3JpZ2luYWwgLz5cbiAgICAgICAgPC9zcGFuPlxuICAgICAgKSl9XG4gICAgICA8c3BhbiBhcmlhLWhpZGRlbiBjbGFzc05hbWU9XCJtbC1weCB0ZXh0LVsxNXB4XSBsZWFkaW5nLW5vcm1hbCB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAge2NvdW50fSBhdmFsaWHDp8O1ZXMgZGUgY29sZWNpb25hZG9yZXNcbiAgICAgIDwvc3Bhbj5cbiAgICA8L3A+XG4gIClcbn1cblxuLyoqIFDDrWx1bGFzIFwiRWRpw6fDo29cIjogMS8xLCAxLzEwLCAxLzUwIGUgQUJFUlRBOyBhIGVkacOnw6NvIGRvIE5GVCBmaWNhIGRlc3RhY2FkYSAoYm9yZGEgZSBjb3IpLiAqL1xuZnVuY3Rpb24gRWRpdGlvblBpbGxzKHsgZWRpdGlvbiwgZ2FwID0gJ2dhcC0xLjUnIH06IHsgZWRpdGlvbjogbnVtYmVyOyBnYXA/OiBzdHJpbmcgfSkge1xuICBjb25zdCBvcHRpb25zID0gW1xuICAgIHsga2V5OiAxLCBsYWJlbDogJzEvMScgfSxcbiAgICB7IGtleTogMTAsIGxhYmVsOiAnMS8xMCcgfSxcbiAgICB7IGtleTogNTAsIGxhYmVsOiAnMS81MCcgfSxcbiAgICB7IGtleTogMTAwLCBsYWJlbDogJ0FCRVJUQScgfSxcbiAgXVxuICBjb25zdCBjdXJyZW50ID0gZWRpdGlvbiA+PSAxMDAgPyAxMDAgOiBlZGl0aW9uXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0yIG1kOmdhcC0zXCI+XG4gICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1ib2xkIGxlYWRpbmctNCB0ZXh0LWZvcmVncm91bmRcIj5FZGnDp8Ojbzo8L2gyPlxuICAgICAgPHVsIGNsYXNzTmFtZT17Y24oJ2ZsZXggaXRlbXMtY2VudGVyJywgZ2FwKX0gYXJpYS1sYWJlbD1cIlRhbWFuaG8gZGEgZWRpw6fDo29cIj5cbiAgICAgICAge29wdGlvbnMubWFwKChvKSA9PiB7XG4gICAgICAgICAgY29uc3QgYWN0aXZlID0gby5rZXkgPT09IGN1cnJlbnRcbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGxpXG4gICAgICAgICAgICAgIGtleT17by5rZXl9XG4gICAgICAgICAgICAgIGFyaWEtY3VycmVudD17YWN0aXZlID8gJ3RydWUnIDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICdmbGV4IGgtNyBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlci0yIHB4LTEuNSB0ZXh0LXNtIGxlYWRpbmctNCcsXG4gICAgICAgICAgICAgICAgby5rZXkgPT09IDEwMCAmJiAncHgtMicsXG4gICAgICAgICAgICAgICAgYWN0aXZlID8gJ2JvcmRlci1wcmltYXJ5IGZvbnQtbWVkaXVtIHRleHQtYWNjZW50JyA6ICdib3JkZXItYm9yZGVyIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCcsXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtvLmxhYmVsfVxuICAgICAgICAgICAgICB7YWN0aXZlID8gPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPiAoZWRpw6fDo28gZGVzdGUgTkZUKTwvc3Bhbj4gOiBudWxsfVxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApXG4gICAgICAgIH0pfVxuICAgICAgPC91bD5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5mdW5jdGlvbiBUb2tlbkluZm8oeyBuIH06IHsgbjogTmZ0RGV0YWlsIH0pIHtcbiAgY29uc3Qgc29sZE91dCA9IG4uYXZhaWxhYmxlID09PSAwXG4gIHJldHVybiAoXG4gICAgPGRsIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTMgdGV4dC1bMTVweF0gbGVhZGluZy1ub3JtYWwgdGV4dC1zdWJ0bGVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMVwiPlxuICAgICAgICA8ZHQ+SUQgZG8gdG9rZW46PC9kdD5cbiAgICAgICAgPGRkPiN7bi50b2tlbklkfTwvZGQ+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMVwiPlxuICAgICAgICA8ZHQ+Q29sZcOnw6NvOjwvZHQ+XG4gICAgICAgIDxkZD57bi5jb2xsZWN0aW9ufTwvZGQ+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMVwiPlxuICAgICAgICA8ZHQ+QXRyaWJ1dG9zOjwvZHQ+XG4gICAgICAgIDxkZD57bi5hdHRyaWJ1dGVzLm1hcCgoYSkgPT4gYS52YWx1ZSkuam9pbignLCAnKX08L2RkPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTFcIj5cbiAgICAgICAgPGR0PkRpc3BvbsOtdmVpczo8L2R0PlxuICAgICAgICA8ZGQgZGF0YS10ZXN0aWQ9XCJkZXRhaWwtYXZhaWxhYmlsaXR5XCI+XG4gICAgICAgICAge3NvbGRPdXQgPyA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1jb3JhbFwiPkVzZ290YWRvPC9zcGFuPiA6IGAke24uYXZhaWxhYmxlfSBkZSAke24uZWRpdGlvbn1gfVxuICAgICAgICA8L2RkPlxuICAgICAgPC9kaXY+XG4gICAgPC9kbD5cbiAgKVxufVxuXG5mdW5jdGlvbiBTaGFyZVJvdyh7IG5hbWUgfTogeyBuYW1lOiBzdHJpbmcgfSkge1xuICBjb25zdCB1cmwgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IHdpbmRvdy5sb2NhdGlvbi5ocmVmIDogJydcbiAgY29uc3QgdGV4dCA9IGAke25hbWV9IG5hIEt1cmlvYFxuICBjb25zdCBsaW5rcyA9IFtcbiAgICB7IGxhYmVsOiAnQ29tcGFydGlsaGFyIG5vIExpbmtlZEluJywgaHJlZjogYGh0dHBzOi8vd3d3LmxpbmtlZGluLmNvbS9zaGFyaW5nL3NoYXJlLW9mZnNpdGUvP3VybD0ke2VuY29kZVVSSUNvbXBvbmVudCh1cmwpfWAsIGljb246ICdzaGFyZS1saW5rZWRpbicsIHc6IDE1LCBoOiAxNCB9LFxuICAgIHsgbGFiZWw6ICdDb21wYXJ0aWxoYXIgcG9yIGUtbWFpbCcsIGhyZWY6IGBtYWlsdG86P3N1YmplY3Q9JHtlbmNvZGVVUklDb21wb25lbnQodGV4dCl9JmJvZHk9JHtlbmNvZGVVUklDb21wb25lbnQodXJsKX1gLCBpY29uOiAnaWNvbi1tZXNzYWdlJywgdzogMTgsIGg6IDE4IH0sXG4gICAgeyBsYWJlbDogJ0NvbXBhcnRpbGhhciBubyBYIChUd2l0dGVyKScsIGhyZWY6IGBodHRwczovL3R3aXR0ZXIuY29tL2ludGVudC90d2VldD90ZXh0PSR7ZW5jb2RlVVJJQ29tcG9uZW50KHRleHQpfSZ1cmw9JHtlbmNvZGVVUklDb21wb25lbnQodXJsKX1gLCBpY29uOiAnc2hhcmUtdHdpdHRlcicsIHc6IDE2LCBoOiAxMiB9LFxuICBdXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1ib2xkIGxlYWRpbmctNCB0ZXh0LWZvcmVncm91bmRcIj5Db21wYXJ0aWxoYXIgZXN0ZSBORlQ6PC9wPlxuICAgICAge2xpbmtzLm1hcCgobCkgPT4gKFxuICAgICAgICA8YSBrZXk9e2wuaWNvbn0gaHJlZj17bC5ocmVmfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCIgYXJpYS1sYWJlbD17bC5sYWJlbH0gY2xhc3NOYW1lPVwiZ3JpZCBwbGFjZS1pdGVtcy1jZW50ZXIgdGV4dC1mb3JlZ3JvdW5kIGhvdmVyOm9wYWNpdHktODBcIj5cbiAgICAgICAgICA8RmlnbWFJY29uIG5hbWU9e2wuaWNvbn0gd2lkdGg9e2wud30gaGVpZ2h0PXtsLmh9IG9yaWdpbmFsIC8+XG4gICAgICAgIDwvYT5cbiAgICAgICkpfVxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIERlc2NyaXB0aW9uVGFicyh7IG4gfTogeyBuOiBOZnREZXRhaWwgfSkge1xuICBjb25zdCBbdGFiLCBzZXRUYWJdID0gdXNlU3RhdGU8J2RldGFpbHMnIHwgJ3Jldmlld3MnPignZGV0YWlscycpXG4gIGNvbnN0IGlkID0gdXNlSWQoKVxuICBjb25zdCB0YWJzID0gW1xuICAgIHsga2V5OiAnZGV0YWlscycgYXMgY29uc3QsIGxhYmVsOiAnRGV0YWxoZXMgZG8gTkZUJyB9LFxuICAgIHsga2V5OiAncmV2aWV3cycgYXMgY29uc3QsIGxhYmVsOiBgQXZhbGlhw6fDtWVzIGRlIGNvbGVjaW9uYWRvcmVzICgke24ucmV2aWV3Q291bnR9KWAgfSxcbiAgXVxuICBjb25zdCBjaGFpbiA9IGNoYWluTGFiZWxzW24uY2hhaW5dXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gYXJpYS1sYWJlbD1cIkRlc2NyacOnw6NvXCIgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgIDxkaXYgcm9sZT1cInRhYmxpc3RcIiBhcmlhLWxhYmVsPVwiRGVzY3Jpw6fDo28gZG8gTkZUXCIgY2xhc3NOYW1lPVwiZmxleCBnYXAtOCBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICB7dGFicy5tYXAoKHQpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZSA9IHQua2V5ID09PSB0YWJcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBrZXk9e3Qua2V5fVxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIHJvbGU9XCJ0YWJcIlxuICAgICAgICAgICAgICAgIGlkPXtgJHtpZH0tJHt0LmtleX1gfVxuICAgICAgICAgICAgICAgIGFyaWEtc2VsZWN0ZWQ9e2FjdGl2ZX1cbiAgICAgICAgICAgICAgICBhcmlhLWNvbnRyb2xzPXtgJHtpZH0tJHt0LmtleX0tcGFuZWxgfVxuICAgICAgICAgICAgICAgIHRhYkluZGV4PXthY3RpdmUgPyAwIDogLTF9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VGFiKHQua2V5KX1cbiAgICAgICAgICAgICAgICBvbktleURvd249eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICBpZiAoZS5rZXkgPT09ICdBcnJvd1JpZ2h0JyB8fCBlLmtleSA9PT0gJ0Fycm93TGVmdCcpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV4dCA9IHRhYiA9PT0gJ2RldGFpbHMnID8gJ3Jldmlld3MnIDogJ2RldGFpbHMnXG4gICAgICAgICAgICAgICAgICAgIHNldFRhYihuZXh0KVxuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChgJHtpZH0tJHtuZXh0fWApPy5mb2N1cygpXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgJ2ZsZXggc2hyaW5rLTAgZmxleC1jb2wgZ2FwLTMgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1bMTdweF0gbGVhZGluZy00JyxcbiAgICAgICAgICAgICAgICAgIGFjdGl2ZSA/ICdmb250LWJvbGQgdGV4dC1hY2NlbnQnIDogJ3RleHQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWFjY2VudCcsXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt0LmxhYmVsfVxuICAgICAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT17Y24oJ2gtWzNweF0gdy1mdWxsJywgYWN0aXZlID8gJ2JnLXByaW1hcnknIDogJ2JnLXRyYW5zcGFyZW50Jyl9IC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJrLWhhaXJsaW5lXCIgLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7dGFiID09PSAnZGV0YWlscycgPyAoXG4gICAgICAgIDxkaXYgcm9sZT1cInRhYnBhbmVsXCIgaWQ9e2Ake2lkfS1kZXRhaWxzLXBhbmVsYH0gYXJpYS1sYWJlbGxlZGJ5PXtgJHtpZH0tZGV0YWlsc2B9IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTMgdGV4dC1zbSBsZWFkaW5nLTZcIj5cbiAgICAgICAgICB7bi5kZXNjcmlwdGlvbi5zcGxpdCgnXFxuXFxuJykubWFwKChwKSA9PiAoXG4gICAgICAgICAgICA8cCBrZXk9e3Auc2xpY2UoMCwgMjQpfSBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAge3B9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgKSl9XG4gICAgICAgICAgPGRsIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+UmVkZTo8L2R0PlxuICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Q3VuaGFkbyBuYSB7Y2hhaW59IGNvbSBwcm9jZWTDqm5jaWEgaW11dMOhdmVsIGUgbWV0YWRhZG9zIGFybWF6ZW5hZG9zIG5vIElQRlMuPC9kZD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWZvcmVncm91bmRcIj5Db250cmF0bzo8L2R0PlxuICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e24uY29udHJhY3RBZGRyZXNzfSDigKIgQ29udHJhdG8gaW50ZWxpZ2VudGUgRVJDLTcyMSB2ZXJpZmljYWRvLjwvZGQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+RGlyZWl0b3MgYXV0b3JhaXM6PC9kdD5cbiAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgIERpcmVpdG9zIGF1dG9yYWlzIGRvIGNyaWFkb3I6IHtuLnJveWFsdHlCcHMgLyAxMDB9JSBuYXMgdmVuZGFzIHNlY3VuZMOhcmlhcywgcGFnb3MgYXV0b21hdGljYW1lbnRlIHBlbG9zIG1lcmNhZG9zIGNvbXBhdMOtdmVpcy5cbiAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGw+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdiByb2xlPVwidGFicGFuZWxcIiBpZD17YCR7aWR9LXJldmlld3MtcGFuZWxgfSBhcmlhLWxhYmVsbGVkYnk9e2Ake2lkfS1yZXZpZXdzYH0gY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMyB0ZXh0LXNtIGxlYWRpbmctNlwiPlxuICAgICAgICAgIDxSYXRpbmcgcmF0aW5nPXtuLnJhdGluZ30gY291bnQ9e24ucmV2aWV3Q291bnR9IC8+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICBOb3RhIG3DqWRpYSB7bi5yYXRpbmcudG9Mb2NhbGVTdHJpbmcoJ3B0LUJSJyl9IGRlIDUsIGNvbSBiYXNlIGVtIHtuLnJldmlld0NvdW50fSBhdmFsaWHDp8O1ZXMgZGUgY29sZWNpb25hZG9yZXMgdmVyaWZpY2Fkb3MuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9zZWN0aW9uPlxuICApXG59XG5cbmNvbnN0IFJFTEFURURfUEVSX1BBR0UgPSA1XG5cbi8qKiBcIk1haXMgZGVzdGEgY29sZcOnw6NvXCI6IGl0ZW5zIGRhIG1lc21hIGNvbGXDp8OjbywgZW0gcMOhZ2luYXMgZGUgNSAocG9udG9zIGRvIGNhcnJvc3NlbCkuICovXG5mdW5jdGlvbiBSZWxhdGVkUHJvZHVjdHMoeyBuIH06IHsgbjogTmZ0RGV0YWlsIH0pIHtcbiAgY29uc3QgcmVsYXRlZCA9IHVzZU5mdExpc3QoeyBxOiBuLmNvbGxlY3Rpb24sIHNvcnQ6ICduZXdlc3QnLCBwYWdlU2l6ZTogMTYsIHBhZ2U6IDEgfSlcbiAgY29uc3QgW3BhZ2UsIHNldFBhZ2VdID0gdXNlU3RhdGUoMClcbiAgY29uc3QgaXRlbXMgPSAocmVsYXRlZC5kYXRhPy5pdGVtcyA/PyBbXSkuZmlsdGVyKChpKSA9PiBpLmlkICE9PSBuLmlkICYmIGkuY29sbGVjdGlvbiA9PT0gbi5jb2xsZWN0aW9uKVxuICBjb25zdCBwYWdlcyA9IE1hdGgubWF4KDEsIE1hdGguY2VpbChpdGVtcy5sZW5ndGggLyBSRUxBVEVEX1BFUl9QQUdFKSlcbiAgY29uc3QgY3VycmVudCA9IE1hdGgubWluKHBhZ2UsIHBhZ2VzIC0gMSlcbiAgY29uc3QgdmlzaWJsZSA9IGl0ZW1zLnNsaWNlKGN1cnJlbnQgKiBSRUxBVEVEX1BFUl9QQUdFLCBjdXJyZW50ICogUkVMQVRFRF9QRVJfUEFHRSArIFJFTEFURURfUEVSX1BBR0UpXG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBhcmlhLWxhYmVsbGVkYnk9XCJyZWxhdGVkLXRpdGxlXCIgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtOFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zXCI+XG4gICAgICAgIDxoMiBpZD1cInJlbGF0ZWQtdGl0bGVcIiBjbGFzc05hbWU9XCJ0ZXh0LVsxN3B4XSBmb250LWJvbGQgbGVhZGluZy00IHRleHQtYWNjZW50XCI+XG4gICAgICAgICAgTWFpcyBkZXN0YSBjb2xlw6fDo29cbiAgICAgICAgPC9oMj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJrLWhhaXJsaW5lXCIgLz5cbiAgICAgIDwvZGl2PlxuICAgICAge3JlbGF0ZWQuaXNFcnJvciA/IChcbiAgICAgICAgPEVycm9yU3RhdGUgY29tcGFjdCBlcnJvcj17cmVsYXRlZC5lcnJvcn0gb25SZXRyeT17KCkgPT4gdm9pZCByZWxhdGVkLnJlZmV0Y2goKX0gcmV0cnlpbmc9e3JlbGF0ZWQuaXNGZXRjaGluZ30gLz5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLThcIj5cbiAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZ3JpZCB3LWZ1bGwgZ3JpZC1jb2xzLTIgZ2FwLXgtNCBnYXAteS02IG1kOmdyaWQtY29scy01IG1kOmdhcC14LVsyNnB4XVwiPlxuICAgICAgICAgICAge3JlbGF0ZWQuaXNQZW5kaW5nXG4gICAgICAgICAgICAgID8gQXJyYXkuZnJvbSh7IGxlbmd0aDogUkVMQVRFRF9QRVJfUEFHRSB9LCAoXywgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGxpIGtleT17aX0+XG4gICAgICAgICAgICAgICAgICAgIDxOZnRDYXJkU2tlbGV0b24gc2l6ZT1cInJlbGF0ZWRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICA6IHZpc2libGUubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8bGkga2V5PXtpdGVtLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgPE5mdENhcmQgbmZ0PXtpdGVtfSBzaXplPVwicmVsYXRlZFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgeyFyZWxhdGVkLmlzUGVuZGluZyAmJiBpdGVtcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkFpbmRhIG7Do28gaMOhIG91dHJvcyBpdGVucyBkZXN0YSBjb2xlw6fDo28uPC9wPlxuICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgIHtwYWdlcyA+IDEgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCIgcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD1cIlDDoWdpbmFzIGRlIGl0ZW5zIHJlbGFjaW9uYWRvc1wiPlxuICAgICAgICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogcGFnZXMgfSwgKF8sIGkpID0+IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e2l9XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BJdGVucyByZWxhY2lvbmFkb3MsIHDDoWdpbmEgJHtpICsgMX0gZGUgJHtwYWdlc31gfVxuICAgICAgICAgICAgICAgICAgYXJpYS1wcmVzc2VkPXtpID09PSBjdXJyZW50fVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGFnZShpKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oJ3NpemUtMyByb3VuZGVkLWZ1bGwgYm9yZGVyLVsxLjNweF0gYm9yZGVyLXByaW1hcnknLCBpID09PSBjdXJyZW50ICYmICdiZy1wcmltYXJ5Jyl9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvc2VjdGlvbj5cbiAgKVxufVxuXG5mdW5jdGlvbiBEZXRhaWxTa2VsZXRvbigpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTYgbWQ6ZmxleC1yb3cgbWQ6Z2FwLThcIiBhcmlhLWJ1c3kgYXJpYS1sYWJlbD1cIkNhcnJlZ2FuZG8gTkZUXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBmbGV4LWNvbCBnYXAtNCBtZDpmbGV4XCI+XG4gICAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiA0IH0sIChfLCBpKSA9PiAoXG4gICAgICAgICAgPFNrZWxldG9uIGtleT17aX0gY2xhc3NOYW1lPVwic2l6ZS1bMTAwcHhdIGJnLWNhcmRcIiAvPlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImFzcGVjdC1zcXVhcmUgdy1mdWxsIGJnLWNhcmQgbWQ6c2l6ZS1bNDQ0cHhdXCIgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LTEgZmxleC1jb2wgZ2FwLTRcIj5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtOCB3LTIvMyBiZy1jYXJkXCIgLz5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNiB3LTEvMyBiZy1jYXJkXCIgLz5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtMjQgdy1mdWxsIGJnLWNhcmRcIiAvPlxuICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC0xMCB3LWZ1bGwgYmctY2FyZFwiIC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl19