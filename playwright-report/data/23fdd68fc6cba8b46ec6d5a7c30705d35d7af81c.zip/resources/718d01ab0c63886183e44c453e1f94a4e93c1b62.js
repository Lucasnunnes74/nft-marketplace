import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/login.tsx");const useState = __vite__cjsImport2_react["useState"];const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"];import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=9ef19319";
import { getRouteApi, Link, useNavigate } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=aac570e2";
import { loginBodySchema } from "/src/api/contracts.ts";
import { toApiError } from "/src/api/errors.ts";
import { AuthShell, useAuthFieldClass } from "/src/components/auth/auth-shell.tsx";
import { Alert } from "/src/components/ui/alert.tsx";
import { FormField, PasswordField } from "/src/components/ui/form-field.tsx";
import { useLogin } from "/src/hooks/use-api.ts";
import { useIsDesktop } from "/src/hooks/use-media.ts";
import { usePageTitle } from "/src/hooks/use-page.ts";
import { applyApiFieldErrors } from "/src/lib/form.ts";
import { safeRedirect } from "/src/lib/format.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/pages/login.tsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$();
const route = getRouteApi("/login");
const reasons = {
	expired: "Sua sessão expirou. Entre novamente para continuar de onde parou.",
	favorite: "Entre para salvar favoritos.",
	checkout: "Entre para finalizar sua compra. Seu carrinho será mantido."
};
export function LoginPage() {
	_s();
	usePageTitle("Entrar");
	const { redirect, reason } = route.useSearch();
	const navigate = useNavigate();
	const login = useLogin();
	const isDesktop = useIsDesktop();
	const field = useAuthFieldClass();
	const [formError, setFormError] = useState(null);
	const [showHelp, setShowHelp] = useState(false);
	const { register, handleSubmit, setError, formState: { errors } } = useForm({
		resolver: zodResolver(loginBodySchema),
		defaultValues: {
			email: "",
			password: ""
		}
	});
	async function onSubmit(values) {
		setFormError(null);
		try {
			await login.mutateAsync(values);
			// Volta exatamente ao ponto de origem (caminho + busca).
			void navigate({
				to: safeRedirect(redirect),
				replace: true
			});
		} catch (e) {
			if (!applyApiFieldErrors(e, setError, ["email", "password"])) setFormError(toApiError(e).message);
		}
	}
	return /* @__PURE__ */ _jsxDEV(AuthShell, {
		mode: "login",
		redirect,
		title: "Entrar",
		mobileTitle: "Entrar",
		description: "Entre para gerenciar sua carteira, coleção e perfil de criador.",
		footer: /* @__PURE__ */ _jsxDEV("p", {
			className: "flex flex-col items-center gap-1 text-center",
			children: [/* @__PURE__ */ _jsxDEV("span", { children: [
				"Novo na Kurio?",
				" ",
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/signup",
					search: { redirect },
					className: "text-accent hover:underline",
					children: "Crie uma conta"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 13
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "text-xs text-subtle",
				children: [
					"Demonstração: ",
					/* @__PURE__ */ _jsxDEV("code", { children: "demo@nft.test" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 27
					}, this),
					" / ",
					/* @__PURE__ */ _jsxDEV("code", { children: "Demo@1234" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 56
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 9
		}, this),
		children: /* @__PURE__ */ _jsxDEV("form", {
			className: cn("flex flex-col", isDesktop ? "gap-6 px-20 pt-6" : "gap-10"),
			onSubmit: handleSubmit(onSubmit),
			noValidate: true,
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col gap-3",
				children: [
					reason ? /* @__PURE__ */ _jsxDEV(Alert, {
						variant: reason === "expired" ? "warning" : "info",
						children: reasons[reason]
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 21
					}, this) : null,
					formError ? /* @__PURE__ */ _jsxDEV(Alert, {
						variant: "destructive",
						title: "Não foi possível entrar",
						children: formError
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 13
					}, this) : null,
					/* @__PURE__ */ _jsxDEV(FormField, {
						id: "email",
						label: "E-mail",
						hideLabel: true,
						type: "email",
						autoComplete: "email",
						placeholder: "contato@email.com",
						error: errors.email?.message,
						className: field,
						...register("email")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(PasswordField, {
						id: "password",
						label: "Senha",
						hideLabel: true,
						autoComplete: "current-password",
						placeholder: "Senha",
						error: errors.password?.message,
						inputClassName: cn(field, "text-base"),
						...register("password")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col items-end gap-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							"aria-expanded": showHelp,
							onClick: () => setShowHelp((v) => !v),
							className: "text-sm leading-4 text-accent hover:underline",
							children: "Esqueceu a senha?"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 13
						}, this), showHelp ? /* @__PURE__ */ _jsxDEV("p", {
							role: "status",
							className: "text-right text-xs text-muted-foreground",
							children: "A recuperação de senha é simulada. Use a conta de demonstração: demo@nft.test / Demo@1234."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 107,
							columnNumber: 15
						}, this) : null]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "submit",
				disabled: login.isPending,
				className: cn("flex w-full items-center justify-center bg-primary text-base font-bold leading-4 text-primary-foreground hover:brightness-110 disabled:opacity-60", isDesktop ? "h-[45px] rounded-[5px]" : "h-[60px] rounded-[10px]"),
				children: login.isPending ? "Entrando…" : "Entrar"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 113,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 73,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 53,
		columnNumber: 5
	}, this);
}
_s(LoginPage, "ORsmloP7iOARCVMF3uCKktyYles=", false, function() {
	return [
		usePageTitle,
		route.useSearch,
		useNavigate,
		useLogin,
		useIsDesktop,
		useAuthFieldClass,
		useForm
	];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/login.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/pages/login.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/pages/login.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/pages/login.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxhQUFhLE1BQU0sbUJBQW1CO0FBQy9DLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsZUFBZTtBQUN4QixTQUF5Qix1QkFBdUI7QUFDaEQsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxXQUFXLHlCQUF5QjtBQUM3QyxTQUFTLGFBQWE7QUFDdEIsU0FBUyxXQUFXLHFCQUFxQjtBQUN6QyxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLDJCQUEyQjtBQUNwQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLFVBQVU7Ozs7QUFFbkIsTUFBTSxRQUFRLFlBQVksUUFBUTtBQUVsQyxNQUFNLFVBQVU7Q0FDZCxTQUFTO0NBQ1QsVUFBVTtDQUNWLFVBQVU7QUFDWjtBQUVBLE9BQU8sU0FBUyxZQUFZOztDQUMxQixhQUFhLFFBQVE7Q0FDckIsTUFBTSxFQUFFLFVBQVUsV0FBVyxNQUFNLFVBQVU7Q0FDN0MsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxRQUFRLFNBQVM7Q0FDdkIsTUFBTSxZQUFZLGFBQWE7Q0FDL0IsTUFBTSxRQUFRLGtCQUFrQjtDQUNoQyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBd0IsSUFBSTtDQUM5RCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsS0FBSztDQUM5QyxNQUFNLEVBQ0osVUFDQSxjQUNBLFVBQ0EsV0FBVyxFQUFFLGFBQ1gsUUFBbUI7RUFBRSxVQUFVLFlBQVksZUFBZTtFQUFHLGVBQWU7R0FBRSxPQUFPO0dBQUksVUFBVTtFQUFHO0NBQUUsQ0FBQztDQUU3RyxlQUFlLFNBQVMsUUFBbUI7RUFDekMsYUFBYSxJQUFJO0VBQ2pCLElBQUk7R0FDRixNQUFNLE1BQU0sWUFBWSxNQUFNOztHQUU5QixLQUFLLFNBQVM7SUFBRSxJQUFJLGFBQWEsUUFBUTtJQUFHLFNBQVM7R0FBSyxDQUFDO0VBQzdELFNBQVMsR0FBRztHQUNWLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxVQUFVLENBQUMsU0FBUyxVQUFVLENBQUMsR0FBRyxhQUFhLFdBQVcsQ0FBQyxDQUFDLENBQUMsT0FBTztFQUNsRztDQUNGO0NBRUEsT0FDRSx3QkFBQyxXQUFEO0VBQ0UsTUFBSztFQUNLO0VBQ1YsT0FBTTtFQUNOLGFBQVk7RUFDWixhQUFZO0VBQ1osUUFDRSx3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUFiLENBQ0Usd0JBQUMsUUFBRDtJQUFNO0lBQ1c7SUFDZix3QkFBQyxNQUFEO0tBQU0sSUFBRztLQUFVLFFBQVEsRUFBRSxTQUFTO0tBQUcsV0FBVTtlQUE4QjtJQUUzRTs7Ozs7R0FDRjs7OzthQUNOLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWhCO0tBQXNDO0tBQ3RCLHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7O0tBQUM7S0FBRyx3QkFBQyxRQUFELFlBQU0sWUFBZTs7Ozs7SUFDNUQ7Ozs7O1dBQ0w7Ozs7OztZQUdMLHdCQUFDLFFBQUQ7R0FBTSxXQUFXLEdBQUcsaUJBQWlCLFlBQVkscUJBQXFCLFFBQVE7R0FBRyxVQUFVLGFBQWEsUUFBUTtHQUFHO2FBQW5ILENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNHLFNBQVMsd0JBQUMsT0FBRDtNQUFPLFNBQVMsV0FBVyxZQUFZLFlBQVk7Z0JBQVMsUUFBUTtLQUFlOzs7O2dCQUFJO0tBQ2hHLFlBQ0Msd0JBQUMsT0FBRDtNQUFPLFNBQVE7TUFBYyxPQUFNO2dCQUNoQztLQUNJOzs7O2dCQUNMO0tBQ0osd0JBQUMsV0FBRDtNQUNFLElBQUc7TUFDSCxPQUFNO01BQ047TUFDQSxNQUFLO01BQ0wsY0FBYTtNQUNiLGFBQVk7TUFDWixPQUFPLE9BQU8sT0FBTztNQUNyQixXQUFXO01BQ1gsR0FBSSxTQUFTLE9BQU87S0FDckI7Ozs7O0tBQ0Qsd0JBQUMsZUFBRDtNQUNFLElBQUc7TUFDSCxPQUFNO01BQ047TUFDQSxjQUFhO01BQ2IsYUFBWTtNQUNaLE9BQU8sT0FBTyxVQUFVO01BQ3hCLGdCQUFnQixHQUFHLE9BQU8sV0FBVztNQUNyQyxHQUFJLFNBQVMsVUFBVTtLQUN4Qjs7Ozs7S0FDRCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FBUSxNQUFLO09BQVMsaUJBQWU7T0FBVSxlQUFlLGFBQWEsTUFBTSxDQUFDLENBQUM7T0FBRyxXQUFVO2lCQUFnRDtNQUV4STs7OztnQkFDUCxXQUNDLHdCQUFDLEtBQUQ7T0FBRyxNQUFLO09BQVMsV0FBVTtpQkFBMkM7TUFFbkU7Ozs7aUJBQ0QsSUFDRDs7Ozs7O0lBQ0Y7Ozs7O2FBQ0wsd0JBQUMsVUFBRDtJQUNFLE1BQUs7SUFDTCxVQUFVLE1BQU07SUFDaEIsV0FBVyxHQUNULHFKQUNBLFlBQVksMkJBQTJCLHlCQUN6QztjQUVDLE1BQU0sWUFBWSxjQUFjO0dBQzNCOzs7O1dBQ0o7Ozs7OztDQUNHOzs7OztBQUVmIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImxvZ2luLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gJ0Bob29rZm9ybS9yZXNvbHZlcnMvem9kJ1xuaW1wb3J0IHsgZ2V0Um91dGVBcGksIExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xuaW1wb3J0IHsgdHlwZSBMb2dpbkJvZHksIGxvZ2luQm9keVNjaGVtYSB9IGZyb20gJ0AvYXBpL2NvbnRyYWN0cydcbmltcG9ydCB7IHRvQXBpRXJyb3IgfSBmcm9tICdAL2FwaS9lcnJvcnMnXG5pbXBvcnQgeyBBdXRoU2hlbGwsIHVzZUF1dGhGaWVsZENsYXNzIH0gZnJvbSAnQC9jb21wb25lbnRzL2F1dGgvYXV0aC1zaGVsbCdcbmltcG9ydCB7IEFsZXJ0IH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2FsZXJ0J1xuaW1wb3J0IHsgRm9ybUZpZWxkLCBQYXNzd29yZEZpZWxkIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2Zvcm0tZmllbGQnXG5pbXBvcnQgeyB1c2VMb2dpbiB9IGZyb20gJ0AvaG9va3MvdXNlLWFwaSdcbmltcG9ydCB7IHVzZUlzRGVza3RvcCB9IGZyb20gJ0AvaG9va3MvdXNlLW1lZGlhJ1xuaW1wb3J0IHsgdXNlUGFnZVRpdGxlIH0gZnJvbSAnQC9ob29rcy91c2UtcGFnZSdcbmltcG9ydCB7IGFwcGx5QXBpRmllbGRFcnJvcnMgfSBmcm9tICdAL2xpYi9mb3JtJ1xuaW1wb3J0IHsgc2FmZVJlZGlyZWN0IH0gZnJvbSAnQC9saWIvZm9ybWF0J1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcblxuY29uc3Qgcm91dGUgPSBnZXRSb3V0ZUFwaSgnL2xvZ2luJylcblxuY29uc3QgcmVhc29ucyA9IHtcbiAgZXhwaXJlZDogJ1N1YSBzZXNzw6NvIGV4cGlyb3UuIEVudHJlIG5vdmFtZW50ZSBwYXJhIGNvbnRpbnVhciBkZSBvbmRlIHBhcm91LicsXG4gIGZhdm9yaXRlOiAnRW50cmUgcGFyYSBzYWx2YXIgZmF2b3JpdG9zLicsXG4gIGNoZWNrb3V0OiAnRW50cmUgcGFyYSBmaW5hbGl6YXIgc3VhIGNvbXByYS4gU2V1IGNhcnJpbmhvIHNlcsOhIG1hbnRpZG8uJyxcbn0gYXMgY29uc3RcblxuZXhwb3J0IGZ1bmN0aW9uIExvZ2luUGFnZSgpIHtcbiAgdXNlUGFnZVRpdGxlKCdFbnRyYXInKVxuICBjb25zdCB7IHJlZGlyZWN0LCByZWFzb24gfSA9IHJvdXRlLnVzZVNlYXJjaCgpXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCBsb2dpbiA9IHVzZUxvZ2luKClcbiAgY29uc3QgaXNEZXNrdG9wID0gdXNlSXNEZXNrdG9wKClcbiAgY29uc3QgZmllbGQgPSB1c2VBdXRoRmllbGRDbGFzcygpXG4gIGNvbnN0IFtmb3JtRXJyb3IsIHNldEZvcm1FcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKVxuICBjb25zdCBbc2hvd0hlbHAsIHNldFNob3dIZWxwXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCB7XG4gICAgcmVnaXN0ZXIsXG4gICAgaGFuZGxlU3VibWl0LFxuICAgIHNldEVycm9yLFxuICAgIGZvcm1TdGF0ZTogeyBlcnJvcnMgfSxcbiAgfSA9IHVzZUZvcm08TG9naW5Cb2R5Pih7IHJlc29sdmVyOiB6b2RSZXNvbHZlcihsb2dpbkJvZHlTY2hlbWEpLCBkZWZhdWx0VmFsdWVzOiB7IGVtYWlsOiAnJywgcGFzc3dvcmQ6ICcnIH0gfSlcblxuICBhc3luYyBmdW5jdGlvbiBvblN1Ym1pdCh2YWx1ZXM6IExvZ2luQm9keSkge1xuICAgIHNldEZvcm1FcnJvcihudWxsKVxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBsb2dpbi5tdXRhdGVBc3luYyh2YWx1ZXMpXG4gICAgICAvLyBWb2x0YSBleGF0YW1lbnRlIGFvIHBvbnRvIGRlIG9yaWdlbSAoY2FtaW5obyArIGJ1c2NhKS5cbiAgICAgIHZvaWQgbmF2aWdhdGUoeyB0bzogc2FmZVJlZGlyZWN0KHJlZGlyZWN0KSwgcmVwbGFjZTogdHJ1ZSB9KVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGlmICghYXBwbHlBcGlGaWVsZEVycm9ycyhlLCBzZXRFcnJvciwgWydlbWFpbCcsICdwYXNzd29yZCddKSkgc2V0Rm9ybUVycm9yKHRvQXBpRXJyb3IoZSkubWVzc2FnZSlcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxBdXRoU2hlbGxcbiAgICAgIG1vZGU9XCJsb2dpblwiXG4gICAgICByZWRpcmVjdD17cmVkaXJlY3R9XG4gICAgICB0aXRsZT1cIkVudHJhclwiXG4gICAgICBtb2JpbGVUaXRsZT1cIkVudHJhclwiXG4gICAgICBkZXNjcmlwdGlvbj1cIkVudHJlIHBhcmEgZ2VyZW5jaWFyIHN1YSBjYXJ0ZWlyYSwgY29sZcOnw6NvIGUgcGVyZmlsIGRlIGNyaWFkb3IuXCJcbiAgICAgIGZvb3Rlcj17XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICBOb3ZvIG5hIEt1cmlvP3snICd9XG4gICAgICAgICAgICA8TGluayB0bz1cIi9zaWdudXBcIiBzZWFyY2g9e3sgcmVkaXJlY3QgfX0gY2xhc3NOYW1lPVwidGV4dC1hY2NlbnQgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgIENyaWUgdW1hIGNvbnRhXG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zdWJ0bGVcIj5cbiAgICAgICAgICAgIERlbW9uc3RyYcOnw6NvOiA8Y29kZT5kZW1vQG5mdC50ZXN0PC9jb2RlPiAvIDxjb2RlPkRlbW9AMTIzNDwvY29kZT5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvcD5cbiAgICAgIH1cbiAgICA+XG4gICAgICA8Zm9ybSBjbGFzc05hbWU9e2NuKCdmbGV4IGZsZXgtY29sJywgaXNEZXNrdG9wID8gJ2dhcC02IHB4LTIwIHB0LTYnIDogJ2dhcC0xMCcpfSBvblN1Ym1pdD17aGFuZGxlU3VibWl0KG9uU3VibWl0KX0gbm9WYWxpZGF0ZT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zXCI+XG4gICAgICAgICAge3JlYXNvbiA/IDxBbGVydCB2YXJpYW50PXtyZWFzb24gPT09ICdleHBpcmVkJyA/ICd3YXJuaW5nJyA6ICdpbmZvJ30+e3JlYXNvbnNbcmVhc29uXX08L0FsZXJ0PiA6IG51bGx9XG4gICAgICAgICAge2Zvcm1FcnJvciA/IChcbiAgICAgICAgICAgIDxBbGVydCB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIiB0aXRsZT1cIk7Do28gZm9pIHBvc3PDrXZlbCBlbnRyYXJcIj5cbiAgICAgICAgICAgICAge2Zvcm1FcnJvcn1cbiAgICAgICAgICAgIDwvQWxlcnQ+XG4gICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgPEZvcm1GaWVsZFxuICAgICAgICAgICAgaWQ9XCJlbWFpbFwiXG4gICAgICAgICAgICBsYWJlbD1cIkUtbWFpbFwiXG4gICAgICAgICAgICBoaWRlTGFiZWxcbiAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJlbWFpbFwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cImNvbnRhdG9AZW1haWwuY29tXCJcbiAgICAgICAgICAgIGVycm9yPXtlcnJvcnMuZW1haWw/Lm1lc3NhZ2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2ZpZWxkfVxuICAgICAgICAgICAgey4uLnJlZ2lzdGVyKCdlbWFpbCcpfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFBhc3N3b3JkRmllbGRcbiAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgbGFiZWw9XCJTZW5oYVwiXG4gICAgICAgICAgICBoaWRlTGFiZWxcbiAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImN1cnJlbnQtcGFzc3dvcmRcIlxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZW5oYVwiXG4gICAgICAgICAgICBlcnJvcj17ZXJyb3JzLnBhc3N3b3JkPy5tZXNzYWdlfVxuICAgICAgICAgICAgaW5wdXRDbGFzc05hbWU9e2NuKGZpZWxkLCAndGV4dC1iYXNlJyl9XG4gICAgICAgICAgICB7Li4ucmVnaXN0ZXIoJ3Bhc3N3b3JkJyl9XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtZW5kIGdhcC0yXCI+XG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBhcmlhLWV4cGFuZGVkPXtzaG93SGVscH0gb25DbGljaz17KCkgPT4gc2V0U2hvd0hlbHAoKHYpID0+ICF2KX0gY2xhc3NOYW1lPVwidGV4dC1zbSBsZWFkaW5nLTQgdGV4dC1hY2NlbnQgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgIEVzcXVlY2V1IGEgc2VuaGE/XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIHtzaG93SGVscCA/IChcbiAgICAgICAgICAgICAgPHAgcm9sZT1cInN0YXR1c1wiIGNsYXNzTmFtZT1cInRleHQtcmlnaHQgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICBBIHJlY3VwZXJhw6fDo28gZGUgc2VuaGEgw6kgc2ltdWxhZGEuIFVzZSBhIGNvbnRhIGRlIGRlbW9uc3RyYcOnw6NvOiBkZW1vQG5mdC50ZXN0IC8gRGVtb0AxMjM0LlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICBkaXNhYmxlZD17bG9naW4uaXNQZW5kaW5nfVxuICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAnZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLXByaW1hcnkgdGV4dC1iYXNlIGZvbnQtYm9sZCBsZWFkaW5nLTQgdGV4dC1wcmltYXJ5LWZvcmVncm91bmQgaG92ZXI6YnJpZ2h0bmVzcy0xMTAgZGlzYWJsZWQ6b3BhY2l0eS02MCcsXG4gICAgICAgICAgICBpc0Rlc2t0b3AgPyAnaC1bNDVweF0gcm91bmRlZC1bNXB4XScgOiAnaC1bNjBweF0gcm91bmRlZC1bMTBweF0nLFxuICAgICAgICAgICl9XG4gICAgICAgID5cbiAgICAgICAgICB7bG9naW4uaXNQZW5kaW5nID8gJ0VudHJhbmRv4oCmJyA6ICdFbnRyYXInfVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L0F1dGhTaGVsbD5cbiAgKVxufVxuIl19