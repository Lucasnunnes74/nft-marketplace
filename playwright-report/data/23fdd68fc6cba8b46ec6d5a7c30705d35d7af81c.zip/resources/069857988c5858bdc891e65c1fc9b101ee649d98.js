const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import { createRootRoute, createRoute, createRouter, lazyRouteComponent, redirect } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import { sessionStore } from "/src/auth/session-store.ts";
import { ErrorState, NotFoundState } from "/src/components/common/states.tsx";
import { AppShell } from "/src/components/layout/app-shell.tsx";
import { HomePage } from "/src/pages/home.tsx";
import { safeRedirect } from "/src/lib/format.ts";
import { authSearchSchema, homeSearchSchema, profileSearchSchema } from "/src/search-schemas.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/router.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
/** Rotas privadas: sem sessão válida, vai ao login e volta ao mesmo caminho (com busca) depois. */
function requireAuth(reason) {
	return ({ location }) => {
		const session = sessionStore.getSnapshot();
		if (!session || sessionStore.isExpired()) {
			if (session) sessionStore.end("expired");
			throw redirect({
				to: "/login",
				search: {
					redirect: location.href,
					reason
				}
			});
		}
	};
}
/** Login/cadastro: usuário já autenticado é enviado para o destino original ou o início. */
function guestOnly({ search }) {
	if (sessionStore.getSnapshot() && !sessionStore.isExpired()) {
		throw redirect({ to: safeRedirect(search.redirect) });
	}
}
/** Cada instância tem seu próprio estado: permite testes isolados com histórico em memória. */
export function createAppRouter(history) {
	const rootRoute = createRootRoute({
		component: AppShell,
		notFoundComponent: () => /* @__PURE__ */ _jsxDEV(NotFoundState, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 30
		}, this),
		errorComponent: ({ error, reset }) => /* @__PURE__ */ _jsxDEV(ErrorState, {
			error,
			onRetry: reset,
			title: "Algo deu errado nesta página"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 43
		}, this)
	});
	const indexRoute = createRoute({
		getParentRoute: () => rootRoute,
		path: "/",
		validateSearch: (raw) => homeSearchSchema.parse(raw),
		component: HomePage
	});
	const nftRoute = createRoute({
		getParentRoute: () => rootRoute,
		path: "/nft/$nftId",
		component: lazyRouteComponent(() => import("/src/pages/nft-detail.tsx"), "NftDetailPage")
	});
	const cartRoute = createRoute({
		getParentRoute: () => rootRoute,
		path: "/cart",
		component: lazyRouteComponent(() => import("/src/pages/cart.tsx"), "CartPage")
	});
	const checkoutRoute = createRoute({
		getParentRoute: () => rootRoute,
		path: "/checkout",
		beforeLoad: requireAuth("checkout"),
		component: lazyRouteComponent(() => import("/src/pages/checkout.tsx"), "CheckoutPage")
	});
	const orderRoute = createRoute({
		getParentRoute: () => rootRoute,
		path: "/orders/$orderId",
		beforeLoad: requireAuth(),
		component: lazyRouteComponent(() => import("/src/pages/order.tsx"), "OrderPage")
	});
	const loginRoute = createRoute({
		getParentRoute: () => rootRoute,
		path: "/login",
		validateSearch: (raw) => authSearchSchema.parse(raw),
		beforeLoad: guestOnly,
		component: lazyRouteComponent(() => import("/src/pages/login.tsx"), "LoginPage")
	});
	const signupRoute = createRoute({
		getParentRoute: () => rootRoute,
		path: "/signup",
		validateSearch: (raw) => authSearchSchema.parse(raw),
		beforeLoad: guestOnly,
		component: lazyRouteComponent(() => import("/src/pages/signup.tsx"), "SignupPage")
	});
	const profileRoute = createRoute({
		getParentRoute: () => rootRoute,
		path: "/profile",
		validateSearch: (raw) => profileSearchSchema.parse(raw),
		beforeLoad: requireAuth(),
		component: lazyRouteComponent(() => import("/src/pages/profile.tsx"), "ProfilePage")
	});
	const walletsRoute = createRoute({
		getParentRoute: () => rootRoute,
		path: "/wallets",
		beforeLoad: requireAuth(),
		component: lazyRouteComponent(() => import("/src/pages/wallets.tsx"), "WalletsPage")
	});
	const routeTree = rootRoute.addChildren([
		indexRoute,
		nftRoute,
		cartRoute,
		checkoutRoute,
		orderRoute,
		loginRoute,
		signupRoute,
		profileRoute,
		walletsRoute
	]);
	return createRouter({
		routeTree,
		history,
		defaultPreload: "intent",
		defaultPendingMs: 200,
		defaultPendingComponent: () => /* @__PURE__ */ _jsxDEV("p", {
			role: "status",
			className: "py-10 text-center text-sm text-muted-foreground",
			children: "Carregando…"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 119,
			columnNumber: 36
		}, this),
		scrollRestoration: true,
		defaultNotFoundComponent: () => /* @__PURE__ */ _jsxDEV(NotFoundState, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 121,
			columnNumber: 37
		}, this)
	});
}
export const router = createAppRouter();

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDRSxpQkFDQSxhQUNBLGNBQ0Esb0JBRUEsZ0JBQ0s7QUFDUCxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLFlBQVkscUJBQXFCO0FBQzFDLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsa0JBQWtCLGtCQUFrQiwyQkFBMkI7Ozs7QUFHeEUsU0FBUyxZQUFZLFFBQXFCO0NBQ3hDLFFBQVEsRUFBRSxlQUErQztFQUN2RCxNQUFNLFVBQVUsYUFBYSxZQUFZO0VBQ3pDLElBQUksQ0FBQyxXQUFXLGFBQWEsVUFBVSxHQUFHO0dBQ3hDLElBQUksU0FBUyxhQUFhLElBQUksU0FBUztHQUN2QyxNQUFNLFNBQVM7SUFBRSxJQUFJO0lBQVUsUUFBUTtLQUFFLFVBQVUsU0FBUztLQUFNO0lBQU87R0FBRSxDQUFDO0VBQzlFO0NBQ0Y7QUFDRjs7QUFHQSxTQUFTLFVBQVUsRUFBRSxVQUE2QztDQUNoRSxJQUFJLGFBQWEsWUFBWSxLQUFLLENBQUMsYUFBYSxVQUFVLEdBQUc7RUFDM0QsTUFBTSxTQUFTLEVBQUUsSUFBSSxhQUFhLE9BQU8sUUFBUSxFQUFFLENBQUM7Q0FDdEQ7QUFDRjs7QUFHQSxPQUFPLFNBQVMsZ0JBQWdCLFNBQXlCO0NBQ3ZELE1BQU0sWUFBWSxnQkFBZ0I7RUFDaEMsV0FBVztFQUNYLHlCQUF5Qix3QkFBQyxlQUFELENBQWdCOzs7OztFQUN6QyxpQkFBaUIsRUFBRSxPQUFPLFlBQVksd0JBQUMsWUFBRDtHQUFtQjtHQUFPLFNBQVM7R0FBTyxPQUFNO0VBQWdDOzs7OztDQUN4SCxDQUFDO0NBRUQsTUFBTSxhQUFhLFlBQVk7RUFDN0Isc0JBQXNCO0VBQ3RCLE1BQU07RUFDTixpQkFBaUIsUUFBUSxpQkFBaUIsTUFBTSxHQUFHO0VBQ25ELFdBQVc7Q0FDYixDQUFDO0NBRUQsTUFBTSxXQUFXLFlBQVk7RUFDM0Isc0JBQXNCO0VBQ3RCLE1BQU07RUFDTixXQUFXLHlCQUF5QixPQUFPLHVCQUF1QixlQUFlO0NBQ25GLENBQUM7Q0FFRCxNQUFNLFlBQVksWUFBWTtFQUFFLHNCQUFzQjtFQUFXLE1BQU07RUFBUyxXQUFXLHlCQUF5QixPQUFPLGlCQUFpQixVQUFVO0NBQUUsQ0FBQztDQUV6SixNQUFNLGdCQUFnQixZQUFZO0VBQ2hDLHNCQUFzQjtFQUN0QixNQUFNO0VBQ04sWUFBWSxZQUFZLFVBQVU7RUFDbEMsV0FBVyx5QkFBeUIsT0FBTyxxQkFBcUIsY0FBYztDQUNoRixDQUFDO0NBRUQsTUFBTSxhQUFhLFlBQVk7RUFDN0Isc0JBQXNCO0VBQ3RCLE1BQU07RUFDTixZQUFZLFlBQVk7RUFDeEIsV0FBVyx5QkFBeUIsT0FBTyxrQkFBa0IsV0FBVztDQUMxRSxDQUFDO0NBRUQsTUFBTSxhQUFhLFlBQVk7RUFDN0Isc0JBQXNCO0VBQ3RCLE1BQU07RUFDTixpQkFBaUIsUUFBUSxpQkFBaUIsTUFBTSxHQUFHO0VBQ25ELFlBQVk7RUFDWixXQUFXLHlCQUF5QixPQUFPLGtCQUFrQixXQUFXO0NBQzFFLENBQUM7Q0FFRCxNQUFNLGNBQWMsWUFBWTtFQUM5QixzQkFBc0I7RUFDdEIsTUFBTTtFQUNOLGlCQUFpQixRQUFRLGlCQUFpQixNQUFNLEdBQUc7RUFDbkQsWUFBWTtFQUNaLFdBQVcseUJBQXlCLE9BQU8sbUJBQW1CLFlBQVk7Q0FDNUUsQ0FBQztDQUVELE1BQU0sZUFBZSxZQUFZO0VBQy9CLHNCQUFzQjtFQUN0QixNQUFNO0VBQ04saUJBQWlCLFFBQVEsb0JBQW9CLE1BQU0sR0FBRztFQUN0RCxZQUFZLFlBQVk7RUFDeEIsV0FBVyx5QkFBeUIsT0FBTyxvQkFBb0IsYUFBYTtDQUM5RSxDQUFDO0NBRUQsTUFBTSxlQUFlLFlBQVk7RUFDL0Isc0JBQXNCO0VBQ3RCLE1BQU07RUFDTixZQUFZLFlBQVk7RUFDeEIsV0FBVyx5QkFBeUIsT0FBTyxvQkFBb0IsYUFBYTtDQUM5RSxDQUFDO0NBRUQsTUFBTSxZQUFZLFVBQVUsWUFBWTtFQUN0QztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBRUQsT0FBTyxhQUFhO0VBQ2xCO0VBQ0E7RUFDQSxnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCLCtCQUErQix3QkFBQyxLQUFEO0dBQUcsTUFBSztHQUFTLFdBQVU7YUFBa0Q7RUFBYzs7Ozs7RUFDMUgsbUJBQW1CO0VBQ25CLGdDQUFnQyx3QkFBQyxlQUFELENBQWdCOzs7OztDQUNsRCxDQUFDO0FBQ0g7QUFFQSxPQUFPLE1BQU0sU0FBUyxnQkFBZ0IiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicm91dGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBjcmVhdGVSb290Um91dGUsXG4gIGNyZWF0ZVJvdXRlLFxuICBjcmVhdGVSb3V0ZXIsXG4gIGxhenlSb3V0ZUNvbXBvbmVudCxcbiAgdHlwZSBSb3V0ZXJIaXN0b3J5LFxuICByZWRpcmVjdCxcbn0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IHNlc3Npb25TdG9yZSB9IGZyb20gJ0AvYXV0aC9zZXNzaW9uLXN0b3JlJ1xuaW1wb3J0IHsgRXJyb3JTdGF0ZSwgTm90Rm91bmRTdGF0ZSB9IGZyb20gJ0AvY29tcG9uZW50cy9jb21tb24vc3RhdGVzJ1xuaW1wb3J0IHsgQXBwU2hlbGwgfSBmcm9tICdAL2NvbXBvbmVudHMvbGF5b3V0L2FwcC1zaGVsbCdcbmltcG9ydCB7IEhvbWVQYWdlIH0gZnJvbSAnQC9wYWdlcy9ob21lJ1xuaW1wb3J0IHsgc2FmZVJlZGlyZWN0IH0gZnJvbSAnQC9saWIvZm9ybWF0J1xuaW1wb3J0IHsgYXV0aFNlYXJjaFNjaGVtYSwgaG9tZVNlYXJjaFNjaGVtYSwgcHJvZmlsZVNlYXJjaFNjaGVtYSB9IGZyb20gJ0Avc2VhcmNoLXNjaGVtYXMnXG5cbi8qKiBSb3RhcyBwcml2YWRhczogc2VtIHNlc3PDo28gdsOhbGlkYSwgdmFpIGFvIGxvZ2luIGUgdm9sdGEgYW8gbWVzbW8gY2FtaW5obyAoY29tIGJ1c2NhKSBkZXBvaXMuICovXG5mdW5jdGlvbiByZXF1aXJlQXV0aChyZWFzb24/OiAnY2hlY2tvdXQnKSB7XG4gIHJldHVybiAoeyBsb2NhdGlvbiB9OiB7IGxvY2F0aW9uOiB7IGhyZWY6IHN0cmluZyB9IH0pID0+IHtcbiAgICBjb25zdCBzZXNzaW9uID0gc2Vzc2lvblN0b3JlLmdldFNuYXBzaG90KClcbiAgICBpZiAoIXNlc3Npb24gfHwgc2Vzc2lvblN0b3JlLmlzRXhwaXJlZCgpKSB7XG4gICAgICBpZiAoc2Vzc2lvbikgc2Vzc2lvblN0b3JlLmVuZCgnZXhwaXJlZCcpXG4gICAgICB0aHJvdyByZWRpcmVjdCh7IHRvOiAnL2xvZ2luJywgc2VhcmNoOiB7IHJlZGlyZWN0OiBsb2NhdGlvbi5ocmVmLCByZWFzb24gfSB9KVxuICAgIH1cbiAgfVxufVxuXG4vKiogTG9naW4vY2FkYXN0cm86IHVzdcOhcmlvIGrDoSBhdXRlbnRpY2FkbyDDqSBlbnZpYWRvIHBhcmEgbyBkZXN0aW5vIG9yaWdpbmFsIG91IG8gaW7DrWNpby4gKi9cbmZ1bmN0aW9uIGd1ZXN0T25seSh7IHNlYXJjaCB9OiB7IHNlYXJjaDogeyByZWRpcmVjdD86IHN0cmluZyB9IH0pIHtcbiAgaWYgKHNlc3Npb25TdG9yZS5nZXRTbmFwc2hvdCgpICYmICFzZXNzaW9uU3RvcmUuaXNFeHBpcmVkKCkpIHtcbiAgICB0aHJvdyByZWRpcmVjdCh7IHRvOiBzYWZlUmVkaXJlY3Qoc2VhcmNoLnJlZGlyZWN0KSB9KVxuICB9XG59XG5cbi8qKiBDYWRhIGluc3TDom5jaWEgdGVtIHNldSBwcsOzcHJpbyBlc3RhZG86IHBlcm1pdGUgdGVzdGVzIGlzb2xhZG9zIGNvbSBoaXN0w7NyaWNvIGVtIG1lbcOzcmlhLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUFwcFJvdXRlcihoaXN0b3J5PzogUm91dGVySGlzdG9yeSkge1xuICBjb25zdCByb290Um91dGUgPSBjcmVhdGVSb290Um91dGUoe1xuICAgIGNvbXBvbmVudDogQXBwU2hlbGwsXG4gICAgbm90Rm91bmRDb21wb25lbnQ6ICgpID0+IDxOb3RGb3VuZFN0YXRlIC8+LFxuICAgIGVycm9yQ29tcG9uZW50OiAoeyBlcnJvciwgcmVzZXQgfSkgPT4gPEVycm9yU3RhdGUgZXJyb3I9e2Vycm9yfSBvblJldHJ5PXtyZXNldH0gdGl0bGU9XCJBbGdvIGRldSBlcnJhZG8gbmVzdGEgcMOhZ2luYVwiIC8+LFxuICB9KVxuXG4gIGNvbnN0IGluZGV4Um91dGUgPSBjcmVhdGVSb3V0ZSh7XG4gICAgZ2V0UGFyZW50Um91dGU6ICgpID0+IHJvb3RSb3V0ZSxcbiAgICBwYXRoOiAnLycsXG4gICAgdmFsaWRhdGVTZWFyY2g6IChyYXcpID0+IGhvbWVTZWFyY2hTY2hlbWEucGFyc2UocmF3KSxcbiAgICBjb21wb25lbnQ6IEhvbWVQYWdlLFxuICB9KVxuXG4gIGNvbnN0IG5mdFJvdXRlID0gY3JlYXRlUm91dGUoe1xuICAgIGdldFBhcmVudFJvdXRlOiAoKSA9PiByb290Um91dGUsXG4gICAgcGF0aDogJy9uZnQvJG5mdElkJyxcbiAgICBjb21wb25lbnQ6IGxhenlSb3V0ZUNvbXBvbmVudCgoKSA9PiBpbXBvcnQoJ0AvcGFnZXMvbmZ0LWRldGFpbCcpLCAnTmZ0RGV0YWlsUGFnZScpLFxuICB9KVxuXG4gIGNvbnN0IGNhcnRSb3V0ZSA9IGNyZWF0ZVJvdXRlKHsgZ2V0UGFyZW50Um91dGU6ICgpID0+IHJvb3RSb3V0ZSwgcGF0aDogJy9jYXJ0JywgY29tcG9uZW50OiBsYXp5Um91dGVDb21wb25lbnQoKCkgPT4gaW1wb3J0KCdAL3BhZ2VzL2NhcnQnKSwgJ0NhcnRQYWdlJykgfSlcblxuICBjb25zdCBjaGVja291dFJvdXRlID0gY3JlYXRlUm91dGUoe1xuICAgIGdldFBhcmVudFJvdXRlOiAoKSA9PiByb290Um91dGUsXG4gICAgcGF0aDogJy9jaGVja291dCcsXG4gICAgYmVmb3JlTG9hZDogcmVxdWlyZUF1dGgoJ2NoZWNrb3V0JyksXG4gICAgY29tcG9uZW50OiBsYXp5Um91dGVDb21wb25lbnQoKCkgPT4gaW1wb3J0KCdAL3BhZ2VzL2NoZWNrb3V0JyksICdDaGVja291dFBhZ2UnKSxcbiAgfSlcblxuICBjb25zdCBvcmRlclJvdXRlID0gY3JlYXRlUm91dGUoe1xuICAgIGdldFBhcmVudFJvdXRlOiAoKSA9PiByb290Um91dGUsXG4gICAgcGF0aDogJy9vcmRlcnMvJG9yZGVySWQnLFxuICAgIGJlZm9yZUxvYWQ6IHJlcXVpcmVBdXRoKCksXG4gICAgY29tcG9uZW50OiBsYXp5Um91dGVDb21wb25lbnQoKCkgPT4gaW1wb3J0KCdAL3BhZ2VzL29yZGVyJyksICdPcmRlclBhZ2UnKSxcbiAgfSlcblxuICBjb25zdCBsb2dpblJvdXRlID0gY3JlYXRlUm91dGUoe1xuICAgIGdldFBhcmVudFJvdXRlOiAoKSA9PiByb290Um91dGUsXG4gICAgcGF0aDogJy9sb2dpbicsXG4gICAgdmFsaWRhdGVTZWFyY2g6IChyYXcpID0+IGF1dGhTZWFyY2hTY2hlbWEucGFyc2UocmF3KSxcbiAgICBiZWZvcmVMb2FkOiBndWVzdE9ubHksXG4gICAgY29tcG9uZW50OiBsYXp5Um91dGVDb21wb25lbnQoKCkgPT4gaW1wb3J0KCdAL3BhZ2VzL2xvZ2luJyksICdMb2dpblBhZ2UnKSxcbiAgfSlcblxuICBjb25zdCBzaWdudXBSb3V0ZSA9IGNyZWF0ZVJvdXRlKHtcbiAgICBnZXRQYXJlbnRSb3V0ZTogKCkgPT4gcm9vdFJvdXRlLFxuICAgIHBhdGg6ICcvc2lnbnVwJyxcbiAgICB2YWxpZGF0ZVNlYXJjaDogKHJhdykgPT4gYXV0aFNlYXJjaFNjaGVtYS5wYXJzZShyYXcpLFxuICAgIGJlZm9yZUxvYWQ6IGd1ZXN0T25seSxcbiAgICBjb21wb25lbnQ6IGxhenlSb3V0ZUNvbXBvbmVudCgoKSA9PiBpbXBvcnQoJ0AvcGFnZXMvc2lnbnVwJyksICdTaWdudXBQYWdlJyksXG4gIH0pXG5cbiAgY29uc3QgcHJvZmlsZVJvdXRlID0gY3JlYXRlUm91dGUoe1xuICAgIGdldFBhcmVudFJvdXRlOiAoKSA9PiByb290Um91dGUsXG4gICAgcGF0aDogJy9wcm9maWxlJyxcbiAgICB2YWxpZGF0ZVNlYXJjaDogKHJhdykgPT4gcHJvZmlsZVNlYXJjaFNjaGVtYS5wYXJzZShyYXcpLFxuICAgIGJlZm9yZUxvYWQ6IHJlcXVpcmVBdXRoKCksXG4gICAgY29tcG9uZW50OiBsYXp5Um91dGVDb21wb25lbnQoKCkgPT4gaW1wb3J0KCdAL3BhZ2VzL3Byb2ZpbGUnKSwgJ1Byb2ZpbGVQYWdlJyksXG4gIH0pXG5cbiAgY29uc3Qgd2FsbGV0c1JvdXRlID0gY3JlYXRlUm91dGUoe1xuICAgIGdldFBhcmVudFJvdXRlOiAoKSA9PiByb290Um91dGUsXG4gICAgcGF0aDogJy93YWxsZXRzJyxcbiAgICBiZWZvcmVMb2FkOiByZXF1aXJlQXV0aCgpLFxuICAgIGNvbXBvbmVudDogbGF6eVJvdXRlQ29tcG9uZW50KCgpID0+IGltcG9ydCgnQC9wYWdlcy93YWxsZXRzJyksICdXYWxsZXRzUGFnZScpLFxuICB9KVxuXG4gIGNvbnN0IHJvdXRlVHJlZSA9IHJvb3RSb3V0ZS5hZGRDaGlsZHJlbihbXG4gICAgaW5kZXhSb3V0ZSxcbiAgICBuZnRSb3V0ZSxcbiAgICBjYXJ0Um91dGUsXG4gICAgY2hlY2tvdXRSb3V0ZSxcbiAgICBvcmRlclJvdXRlLFxuICAgIGxvZ2luUm91dGUsXG4gICAgc2lnbnVwUm91dGUsXG4gICAgcHJvZmlsZVJvdXRlLFxuICAgIHdhbGxldHNSb3V0ZSxcbiAgXSlcblxuICByZXR1cm4gY3JlYXRlUm91dGVyKHtcbiAgICByb3V0ZVRyZWUsXG4gICAgaGlzdG9yeSxcbiAgICBkZWZhdWx0UHJlbG9hZDogJ2ludGVudCcsXG4gICAgZGVmYXVsdFBlbmRpbmdNczogMjAwLFxuICAgIGRlZmF1bHRQZW5kaW5nQ29tcG9uZW50OiAoKSA9PiA8cCByb2xlPVwic3RhdHVzXCIgY2xhc3NOYW1lPVwicHktMTAgdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5DYXJyZWdhbmRv4oCmPC9wPixcbiAgICBzY3JvbGxSZXN0b3JhdGlvbjogdHJ1ZSxcbiAgICBkZWZhdWx0Tm90Rm91bmRDb21wb25lbnQ6ICgpID0+IDxOb3RGb3VuZFN0YXRlIC8+LFxuICB9KVxufVxuXG5leHBvcnQgY29uc3Qgcm91dGVyID0gY3JlYXRlQXBwUm91dGVyKClcblxuZGVjbGFyZSBtb2R1bGUgJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInIHtcbiAgaW50ZXJmYWNlIFJlZ2lzdGVyIHtcbiAgICByb3V0ZXI6IHR5cGVvZiByb3V0ZXJcbiAgfVxufVxuIl19