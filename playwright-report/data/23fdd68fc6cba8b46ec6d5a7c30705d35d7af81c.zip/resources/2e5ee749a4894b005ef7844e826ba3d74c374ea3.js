import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/app-shell.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_ENABLE_MOCKS": "true"};const lazy = __vite__cjsImport1_react["lazy"]; const Suspense = __vite__cjsImport1_react["Suspense"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import { Outlet, useRouterState } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { SessionEffects } from "/src/app/session-effects.tsx";
import { Toaster } from "/src/components/ui/toaster.tsx";
import { useIsDesktop } from "/src/hooks/use-media.ts";
import { cn } from "/src/lib/utils.ts";
import { Footer, LiveIndicator } from "/src/components/layout/footer.tsx";
import { Header } from "/src/components/layout/header.tsx";
import { MobileTabBar } from "/src/components/layout/mobile-nav.tsx";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/app-shell.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$();
// O painel e os mocks só entram no bundle quando VITE_ENABLE_MOCKS=true.
const MockPanel = import.meta.env.VITE_ENABLE_MOCKS === "true" ? lazy(() => import("/src/components/mock/mock-panel.tsx")) : null;
/** No mobile, a tab bar aparece só nas telas que a têm no layout (início e conta). */
const tabBarPaths = [
	"/",
	"/profile",
	"/wallets"
];
const authPaths = ["/login", "/signup"];
export function AppShell() {
	_s();
	const isDesktop = useIsDesktop();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const showTabBar = !isDesktop && tabBarPaths.includes(pathname);
	const isAuth = authPaths.includes(pathname);
	const isDetail = pathname.startsWith("/nft/");
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "relative flex min-h-dvh flex-col",
		children: [
			/* @__PURE__ */ _jsxDEV("a", {
				href: "#main",
				className: "sr-only z-50 rounded-[6px] bg-primary px-4 py-2 font-bold text-primary-foreground focus:not-sr-only focus:fixed focus:left-4 focus:top-4",
				children: "Pular para o conteúdo"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(SessionEffects, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mx-auto flex w-full max-w-[1248px] flex-1 flex-col px-6",
				children: [
					isDesktop ? /* @__PURE__ */ _jsxDEV(Header, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 22
					}, this) : !isAuth && !isDetail ? /* @__PURE__ */ _jsxDEV(LiveIndicator, { className: "absolute right-6 top-3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 58
					}, this) : null,
					/* @__PURE__ */ _jsxDEV("main", {
						id: "main",
						tabIndex: -1,
						className: cn("flex-1 outline-none", isDesktop ? "pt-8" : isDetail ? "pt-0" : "pt-10", showTabBar && "pb-[150px]"),
						children: /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 9
					}, this),
					isDesktop ? /* @__PURE__ */ _jsxDEV("div", {
						className: "mb-6 mt-24",
						children: /* @__PURE__ */ _jsxDEV(Footer, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 11
					}, this) : null
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 7
			}, this),
			showTabBar ? /* @__PURE__ */ _jsxDEV(MobileTabBar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 21
			}, this) : null,
			/* @__PURE__ */ _jsxDEV(Toaster, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 7
			}, this),
			MockPanel ? /* @__PURE__ */ _jsxDEV(Suspense, {
				fallback: null,
				children: /* @__PURE__ */ _jsxDEV(MockPanel, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 9
			}, this) : null
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
}
_s(AppShell, "UrtQUg80EWLQZdt+cCnnk3OOvuE=", false, function() {
	return [useIsDesktop, useRouterState];
});
_c = AppShell;
var _c;
$RefreshReg$(_c, "AppShell");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/app-shell.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/app-shell.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/app-shell.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/app-shell.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLHNCQUFzQjtBQUN2QyxTQUFTLE1BQU0sZ0JBQWdCO0FBQy9CLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsZUFBZTtBQUN4QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLFVBQVU7QUFDbkIsU0FBUyxRQUFRLHFCQUFxQjtBQUN0QyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxvQkFBb0I7Ozs7O0FBRzdCLE1BQU0sWUFBWSxZQUFZLElBQUksc0JBQXNCLFNBQVMsV0FBVyxPQUFPLCtCQUErQixJQUFJOztBQUd0SCxNQUFNLGNBQWM7Q0FBQztDQUFLO0NBQVk7QUFBVTtBQUNoRCxNQUFNLFlBQVksQ0FBQyxVQUFVLFNBQVM7QUFFdEMsT0FBTyxTQUFTLFdBQVc7O0NBQ3pCLE1BQU0sWUFBWSxhQUFhO0NBQy9CLE1BQU0sV0FBVyxlQUFlLEVBQUUsU0FBUyxNQUFNLEVBQUUsU0FBUyxTQUFTLENBQUM7Q0FDdEUsTUFBTSxhQUFhLENBQUMsYUFBYSxZQUFZLFNBQVMsUUFBUTtDQUM5RCxNQUFNLFNBQVMsVUFBVSxTQUFTLFFBQVE7Q0FDMUMsTUFBTSxXQUFXLFNBQVMsV0FBVyxPQUFPO0NBRTVDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLEtBQUQ7SUFDRSxNQUFLO0lBQ0wsV0FBVTtjQUNYO0dBRUU7Ozs7O0dBQ0gsd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7O0dBQ2pCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRyxZQUFZLHdCQUFDLFFBQUQsQ0FBUzs7OztnQkFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLHdCQUFDLGVBQUQsRUFBZSxXQUFVLHlCQUEwQjs7OztnQkFBSTtLQUN4Ryx3QkFBQyxRQUFEO01BQ0UsSUFBRztNQUNILFVBQVUsQ0FBQztNQUNYLFdBQVcsR0FBRyx1QkFBdUIsWUFBWSxTQUFTLFdBQVcsU0FBUyxTQUFTLGNBQWMsWUFBWTtnQkFFakgsd0JBQUMsUUFBRCxDQUFTOzs7OztLQUNMOzs7OztLQUNMLFlBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsUUFBRCxDQUFTOzs7OztLQUNOOzs7O2dCQUNIO0lBQ0Q7Ozs7OztHQUNKLGFBQWEsd0JBQUMsY0FBRCxDQUFlOzs7O2NBQUk7R0FDakMsd0JBQUMsU0FBRCxDQUFVOzs7OztHQUNULFlBQ0Msd0JBQUMsVUFBRDtJQUFVLFVBQVU7Y0FDbEIsd0JBQUMsV0FBRCxDQUFZOzs7OztHQUNKOzs7O2NBQ1I7RUFDRDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYXBwLXNoZWxsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBPdXRsZXQsIHVzZVJvdXRlclN0YXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IGxhenksIFN1c3BlbnNlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBTZXNzaW9uRWZmZWN0cyB9IGZyb20gJ0AvYXBwL3Nlc3Npb24tZWZmZWN0cydcbmltcG9ydCB7IFRvYXN0ZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvdG9hc3RlcidcbmltcG9ydCB7IHVzZUlzRGVza3RvcCB9IGZyb20gJ0AvaG9va3MvdXNlLW1lZGlhJ1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcbmltcG9ydCB7IEZvb3RlciwgTGl2ZUluZGljYXRvciB9IGZyb20gJy4vZm9vdGVyJ1xuaW1wb3J0IHsgSGVhZGVyIH0gZnJvbSAnLi9oZWFkZXInXG5pbXBvcnQgeyBNb2JpbGVUYWJCYXIgfSBmcm9tICcuL21vYmlsZS1uYXYnXG5cbi8vIE8gcGFpbmVsIGUgb3MgbW9ja3Mgc8OzIGVudHJhbSBubyBidW5kbGUgcXVhbmRvIFZJVEVfRU5BQkxFX01PQ0tTPXRydWUuXG5jb25zdCBNb2NrUGFuZWwgPSBpbXBvcnQubWV0YS5lbnYuVklURV9FTkFCTEVfTU9DS1MgPT09ICd0cnVlJyA/IGxhenkoKCkgPT4gaW1wb3J0KCdAL2NvbXBvbmVudHMvbW9jay9tb2NrLXBhbmVsJykpIDogbnVsbFxuXG4vKiogTm8gbW9iaWxlLCBhIHRhYiBiYXIgYXBhcmVjZSBzw7MgbmFzIHRlbGFzIHF1ZSBhIHTDqm0gbm8gbGF5b3V0IChpbsOtY2lvIGUgY29udGEpLiAqL1xuY29uc3QgdGFiQmFyUGF0aHMgPSBbJy8nLCAnL3Byb2ZpbGUnLCAnL3dhbGxldHMnXVxuY29uc3QgYXV0aFBhdGhzID0gWycvbG9naW4nLCAnL3NpZ251cCddXG5cbmV4cG9ydCBmdW5jdGlvbiBBcHBTaGVsbCgpIHtcbiAgY29uc3QgaXNEZXNrdG9wID0gdXNlSXNEZXNrdG9wKClcbiAgY29uc3QgcGF0aG5hbWUgPSB1c2VSb3V0ZXJTdGF0ZSh7IHNlbGVjdDogKHMpID0+IHMubG9jYXRpb24ucGF0aG5hbWUgfSlcbiAgY29uc3Qgc2hvd1RhYkJhciA9ICFpc0Rlc2t0b3AgJiYgdGFiQmFyUGF0aHMuaW5jbHVkZXMocGF0aG5hbWUpXG4gIGNvbnN0IGlzQXV0aCA9IGF1dGhQYXRocy5pbmNsdWRlcyhwYXRobmFtZSlcbiAgY29uc3QgaXNEZXRhaWwgPSBwYXRobmFtZS5zdGFydHNXaXRoKCcvbmZ0LycpXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggbWluLWgtZHZoIGZsZXgtY29sXCI+XG4gICAgICA8YVxuICAgICAgICBocmVmPVwiI21haW5cIlxuICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHotNTAgcm91bmRlZC1bNnB4XSBiZy1wcmltYXJ5IHB4LTQgcHktMiBmb250LWJvbGQgdGV4dC1wcmltYXJ5LWZvcmVncm91bmQgZm9jdXM6bm90LXNyLW9ubHkgZm9jdXM6Zml4ZWQgZm9jdXM6bGVmdC00IGZvY3VzOnRvcC00XCJcbiAgICAgID5cbiAgICAgICAgUHVsYXIgcGFyYSBvIGNvbnRlw7pkb1xuICAgICAgPC9hPlxuICAgICAgPFNlc3Npb25FZmZlY3RzIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gZmxleCB3LWZ1bGwgbWF4LXctWzEyNDhweF0gZmxleC0xIGZsZXgtY29sIHB4LTZcIj5cbiAgICAgICAge2lzRGVza3RvcCA/IDxIZWFkZXIgLz4gOiAhaXNBdXRoICYmICFpc0RldGFpbCA/IDxMaXZlSW5kaWNhdG9yIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTYgdG9wLTNcIiAvPiA6IG51bGx9XG4gICAgICAgIDxtYWluXG4gICAgICAgICAgaWQ9XCJtYWluXCJcbiAgICAgICAgICB0YWJJbmRleD17LTF9XG4gICAgICAgICAgY2xhc3NOYW1lPXtjbignZmxleC0xIG91dGxpbmUtbm9uZScsIGlzRGVza3RvcCA/ICdwdC04JyA6IGlzRGV0YWlsID8gJ3B0LTAnIDogJ3B0LTEwJywgc2hvd1RhYkJhciAmJiAncGItWzE1MHB4XScpfVxuICAgICAgICA+XG4gICAgICAgICAgPE91dGxldCAvPlxuICAgICAgICA8L21haW4+XG4gICAgICAgIHtpc0Rlc2t0b3AgPyAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IG10LTI0XCI+XG4gICAgICAgICAgICA8Rm9vdGVyIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgPC9kaXY+XG4gICAgICB7c2hvd1RhYkJhciA/IDxNb2JpbGVUYWJCYXIgLz4gOiBudWxsfVxuICAgICAgPFRvYXN0ZXIgLz5cbiAgICAgIHtNb2NrUGFuZWwgPyAoXG4gICAgICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17bnVsbH0+XG4gICAgICAgICAgPE1vY2tQYW5lbCAvPlxuICAgICAgICA8L1N1c3BlbnNlPlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==