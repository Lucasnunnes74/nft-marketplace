"use client";
import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-Bk_YeHJf.js?v=1500aecb";
import { t as require_react } from "/node_modules/.vite/deps/react-Bk9vEtng.js?v=1500aecb";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom-f6U-7Wx1.js?v=1500aecb";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-XdfVfXhi.js?v=1500aecb";
import { a as useComposedRefs, r as createSlot } from "/node_modules/.vite/deps/dist-CqoI-OJ1.js?v=1500aecb";
import { n as dispatchDiscreteCustomEvent, t as Primitive } from "/node_modules/.vite/deps/dist-B-0rLcLG.js?v=1500aecb";
//#region node_modules/@radix-ui/primitive/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var __defProp$11 = Object.defineProperty;
var __name$11 = (target, value) => __defProp$11(target, "name", {
	value,
	configurable: true
});
var canUseDOM = !!(typeof window !== "undefined" && window.document && window.document.createElement);
function composeEventHandlers(originalEventHandler, ourEventHandler, { checkForDefaultPrevented = true } = {}) {
	return /* @__PURE__ */ __name$11(function handleEvent(event) {
		originalEventHandler?.(event);
		if (checkForDefaultPrevented === false || !event || !event.defaultPrevented) return ourEventHandler?.(event);
	}, "handleEvent");
}
__name$11(composeEventHandlers, "composeEventHandlers");
function getOwnerWindow(element) {
	if (!canUseDOM) throw new Error("Cannot access window outside of the DOM");
	return element?.ownerDocument?.defaultView ?? window;
}
__name$11(getOwnerWindow, "getOwnerWindow");
function getOwnerDocument(element) {
	if (!canUseDOM) throw new Error("Cannot access document outside of the DOM");
	return element?.ownerDocument ?? document;
}
__name$11(getOwnerDocument, "getOwnerDocument");
function getActiveElement(node, activeDescendant = false) {
	const { activeElement } = getOwnerDocument(node);
	if (!activeElement?.nodeName) return null;
	if (isFrame(activeElement) && activeElement.contentDocument) return getActiveElement(activeElement.contentDocument.body, activeDescendant);
	if (activeDescendant) {
		const id = activeElement.getAttribute("aria-activedescendant");
		if (id) {
			const element = getOwnerDocument(activeElement).getElementById(id);
			if (element) return element;
		}
	}
	return activeElement;
}
__name$11(getActiveElement, "getActiveElement");
function isFrame(element) {
	return element.tagName === "IFRAME";
}
__name$11(isFrame, "isFrame");
//#endregion
//#region node_modules/@radix-ui/react-context/dist/index.mjs
var import_jsx_runtime = require_jsx_runtime();
var __defProp$10 = Object.defineProperty;
var __name$10 = (target, value) => __defProp$10(target, "name", {
	value,
	configurable: true
});
// @__NO_SIDE_EFFECTS__
function createContext2(rootComponentName, defaultContext) {
	const Context = import_react.createContext(defaultContext);
	Context.displayName = rootComponentName + "Context";
	const Provider = /* @__PURE__ */ __name$10((props) => {
		const { children, ...context } = props;
		const value = import_react.useMemo(() => context, Object.values(context));
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Context.Provider, {
			value,
			children
		});
	}, "Provider");
	Provider.displayName = rootComponentName + "Provider";
	function useContext2(consumerName, options = {}) {
		const { optional = false } = options;
		const context = import_react.useContext(Context);
		if (context) return context;
		if (defaultContext !== void 0) return defaultContext;
		if (optional) return void 0;
		throw new Error(`\`${consumerName}\` must be used within \`${rootComponentName}\``);
	}
	__name$10(useContext2, "useContext");
	return [Provider, useContext2];
}
__name$10(createContext2, "createContext");
// @__NO_SIDE_EFFECTS__
function createContextScope(scopeName, createContextScopeDeps = []) {
	let defaultContexts = [];
	function createContext3(rootComponentName, defaultContext) {
		const BaseContext = import_react.createContext(defaultContext);
		BaseContext.displayName = rootComponentName + "Context";
		const index = defaultContexts.length;
		defaultContexts = [...defaultContexts, defaultContext];
		const Provider = /* @__PURE__ */ __name$10((props) => {
			const { scope, children, ...context } = props;
			const Context = scope?.[scopeName]?.[index] || BaseContext;
			const value = import_react.useMemo(() => context, Object.values(context));
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Context.Provider, {
				value,
				children
			});
		}, "Provider");
		Provider.displayName = rootComponentName + "Provider";
		function useContext2(consumerName, scope, options = {}) {
			const { optional = false } = options;
			const Context = scope?.[scopeName]?.[index] || BaseContext;
			const context = import_react.useContext(Context);
			if (context) return context;
			if (defaultContext !== void 0) return defaultContext;
			if (optional) return void 0;
			throw new Error(`\`${consumerName}\` must be used within \`${rootComponentName}\``);
		}
		__name$10(useContext2, "useContext");
		return [Provider, useContext2];
	}
	__name$10(createContext3, "createContext");
	const createScope = /* @__PURE__ */ __name$10(() => {
		const scopeContexts = defaultContexts.map((defaultContext) => {
			return import_react.createContext(defaultContext);
		});
		return /* @__PURE__ */ __name$10(function useScope(scope) {
			const contexts = scope?.[scopeName] || scopeContexts;
			return import_react.useMemo(() => ({ [`__scope${scopeName}`]: {
				...scope,
				[scopeName]: contexts
			} }), [scope, contexts]);
		}, "useScope");
	}, "createScope");
	createScope.scopeName = scopeName;
	return [createContext3, composeContextScopes(createScope, ...createContextScopeDeps)];
}
__name$10(createContextScope, "createContextScope");
function composeContextScopes(...scopes) {
	const baseScope = scopes[0];
	if (scopes.length === 1) return baseScope;
	const createScope = /* @__PURE__ */ __name$10(() => {
		const scopeHooks = scopes.map((createScope2) => ({
			useScope: createScope2(),
			scopeName: createScope2.scopeName
		}));
		return /* @__PURE__ */ __name$10(function useComposedScopes(overrideScopes) {
			const nextScopes = scopeHooks.reduce((nextScopes2, { useScope, scopeName }) => {
				const currentScope = useScope(overrideScopes)[`__scope${scopeName}`];
				return {
					...nextScopes2,
					...currentScope
				};
			}, {});
			return import_react.useMemo(() => ({ [`__scope${baseScope.scopeName}`]: nextScopes }), [nextScopes]);
		}, "useComposedScopes");
	}, "createScope");
	createScope.scopeName = baseScope.scopeName;
	return createScope;
}
__name$10(composeContextScopes, "composeContextScopes");
//#endregion
//#region node_modules/@radix-ui/react-use-layout-effect/dist/index.mjs
var useLayoutEffect2 = globalThis?.document ? import_react.useLayoutEffect : () => {};
//#endregion
//#region node_modules/@radix-ui/react-id/dist/index.mjs
var __defProp$9 = Object.defineProperty;
var __name$9 = (target, value) => __defProp$9(target, "name", {
	value,
	configurable: true
});
var useReactId = import_react[" useId ".trim().toString()] || (() => void 0);
var count$1 = 0;
function useId(deterministicId) {
	const [id, setId] = import_react.useState(useReactId());
	useLayoutEffect2(() => {
		if (!deterministicId) setId((reactId) => reactId ?? String(count$1++));
	}, [deterministicId]);
	return deterministicId || (id ? `radix-${id}` : "");
}
__name$9(useId, "useId");
//#endregion
//#region node_modules/@radix-ui/react-use-effect-event/dist/index.mjs
var __defProp$8 = Object.defineProperty;
var __name$8 = (target, value) => __defProp$8(target, "name", {
	value,
	configurable: true
});
var useReactEffectEvent = import_react[" useEffectEvent ".trim().toString()];
var useReactInsertionEffect$1 = import_react[" useInsertionEffect ".trim().toString()];
function useEffectEvent(callback) {
	if (typeof useReactEffectEvent === "function") return useReactEffectEvent(callback);
	const ref = import_react.useRef(() => {
		throw new Error("Cannot call an event handler while rendering.");
	});
	if (typeof useReactInsertionEffect$1 === "function") useReactInsertionEffect$1(() => {
		ref.current = callback;
	});
	else useLayoutEffect2(() => {
		ref.current = callback;
	});
	return import_react.useMemo(() => ((...args) => ref.current?.(...args)), []);
}
__name$8(useEffectEvent, "useEffectEvent");
//#endregion
//#region node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
var __defProp$7 = Object.defineProperty;
var __name$7 = (target, value) => __defProp$7(target, "name", {
	value,
	configurable: true
});
var useInsertionEffect = import_react[" useInsertionEffect ".trim().toString()] || useLayoutEffect2;
function useControllableState({ prop, defaultProp, onChange = /* @__PURE__ */ __name$7(() => {}, "onChange"), caller }) {
	const [uncontrolledProp, setUncontrolledProp, onChangeRef] = useUncontrolledState({
		defaultProp,
		onChange
	});
	const isControlled = prop !== void 0;
	const value = isControlled ? prop : uncontrolledProp;
	{
		const isControlledRef = import_react.useRef(prop !== void 0);
		import_react.useEffect(() => {
			const wasControlled = isControlledRef.current;
			if (wasControlled !== isControlled) console.warn(`${caller} is changing from ${wasControlled ? "controlled" : "uncontrolled"} to ${isControlled ? "controlled" : "uncontrolled"}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`);
			isControlledRef.current = isControlled;
		}, [isControlled, caller]);
	}
	return [value, import_react.useCallback((nextValue) => {
		if (isControlled) {
			const value2 = isFunction(nextValue) ? nextValue(prop) : nextValue;
			if (value2 !== prop) onChangeRef.current?.(value2);
		} else setUncontrolledProp(nextValue);
	}, [
		isControlled,
		prop,
		setUncontrolledProp,
		onChangeRef
	])];
}
__name$7(useControllableState, "useControllableState");
function useUncontrolledState({ defaultProp, onChange }) {
	const [value, setValue] = import_react.useState(defaultProp);
	const prevValueRef = import_react.useRef(value);
	const onChangeRef = import_react.useRef(onChange);
	useInsertionEffect(() => {
		onChangeRef.current = onChange;
	}, [onChange]);
	import_react.useEffect(() => {
		if (prevValueRef.current !== value) {
			onChangeRef.current?.(value);
			prevValueRef.current = value;
		}
	}, [value, prevValueRef]);
	return [
		value,
		setValue,
		onChangeRef
	];
}
__name$7(useUncontrolledState, "useUncontrolledState");
function isFunction(value) {
	return typeof value === "function";
}
__name$7(isFunction, "isFunction");
var SYNC_STATE = Symbol("RADIX:SYNC_STATE");
function useControllableStateReducer(reducer, userArgs, initialArg, init) {
	const { prop: controlledState, defaultProp, onChange: onChangeProp, caller } = userArgs;
	const isControlled = controlledState !== void 0;
	const onChange = useEffectEvent(onChangeProp);
	{
		const isControlledRef = import_react.useRef(controlledState !== void 0);
		import_react.useEffect(() => {
			const wasControlled = isControlledRef.current;
			if (wasControlled !== isControlled) console.warn(`${caller} is changing from ${wasControlled ? "controlled" : "uncontrolled"} to ${isControlled ? "controlled" : "uncontrolled"}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`);
			isControlledRef.current = isControlled;
		}, [isControlled, caller]);
	}
	const args = [{
		...initialArg,
		state: defaultProp
	}];
	if (init) args.push(init);
	const [internalState, dispatch] = import_react.useReducer((state2, action) => {
		if (action.type === SYNC_STATE) return {
			...state2,
			state: action.state
		};
		const next = reducer(state2, action);
		if (isControlled && !Object.is(next.state, state2.state)) onChange(next.state);
		return next;
	}, ...args);
	const uncontrolledState = internalState.state;
	const prevValueRef = import_react.useRef(uncontrolledState);
	import_react.useEffect(() => {
		if (prevValueRef.current !== uncontrolledState) {
			prevValueRef.current = uncontrolledState;
			if (!isControlled) onChange(uncontrolledState);
		}
	}, [
		uncontrolledState,
		prevValueRef,
		isControlled
	]);
	const state = import_react.useMemo(() => {
		if (controlledState !== void 0) return {
			...internalState,
			state: controlledState
		};
		return internalState;
	}, [internalState, controlledState]);
	import_react.useEffect(() => {
		if (isControlled && !Object.is(controlledState, internalState.state)) dispatch({
			type: SYNC_STATE,
			state: controlledState
		});
	}, [
		controlledState,
		internalState.state,
		isControlled
	]);
	return [state, dispatch];
}
__name$7(useControllableStateReducer, "useControllableStateReducer");
//#endregion
//#region node_modules/@radix-ui/react-use-callback-ref/dist/index.mjs
var __defProp$6 = Object.defineProperty;
var __name$6 = (target, value) => __defProp$6(target, "name", {
	value,
	configurable: true
});
var useReactInsertionEffect = import_react[" useInsertionEffect ".trim().toString()];
function useCallbackRef$1(callback) {
	const callbackRef = import_react.useRef(callback);
	if (typeof useReactInsertionEffect === "function") useReactInsertionEffect(() => {
		callbackRef.current = callback;
	});
	else useLayoutEffect2(() => {
		callbackRef.current = callback;
	});
	return import_react.useMemo(() => ((...args) => callbackRef.current?.(...args)), []);
}
__name$6(useCallbackRef$1, "useCallbackRef");
//#endregion
//#region node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs
var __defProp$5 = Object.defineProperty;
var __name$5 = (target, value) => __defProp$5(target, "name", {
	value,
	configurable: true
});
var CONTEXT_UPDATE = "dismissableLayer.update";
var POINTER_DOWN_OUTSIDE = "dismissableLayer.pointerDownOutside";
var FOCUS_OUTSIDE = "dismissableLayer.focusOutside";
var originalBodyPointerEvents;
var DismissableLayerContext = import_react.createContext({
	layers: /* @__PURE__ */ new Set(),
	layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
	branches: /* @__PURE__ */ new Set(),
	dismissableSurfaces: /* @__PURE__ */ new Set()
});
var DismissableLayer = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$5(function DismissableLayer2(props, forwardedRef) {
	const { disableOutsidePointerEvents = false, deferPointerDownOutside = false, onEscapeKeyDown, onPointerDownOutside, onFocusOutside, onInteractOutside, onDismiss, ...layerProps } = props;
	const context = import_react.useContext(DismissableLayerContext);
	const [node, setNode] = import_react.useState(null);
	const ownerDocument = node?.ownerDocument ?? globalThis?.document;
	const [, force] = import_react.useState({});
	const composedRefs = useComposedRefs(forwardedRef, setNode);
	const layers = Array.from(context.layers);
	const [highestLayerWithOutsidePointerEventsDisabled] = [...context.layersWithOutsidePointerEventsDisabled].slice(-1);
	const highestLayerWithOutsidePointerEventsDisabledIndex = highestLayerWithOutsidePointerEventsDisabled ? layers.indexOf(highestLayerWithOutsidePointerEventsDisabled) : -1;
	const index = node ? layers.indexOf(node) : -1;
	const isBodyPointerEventsDisabled = context.layersWithOutsidePointerEventsDisabled.size > 0;
	const isPointerEventsEnabled = index >= highestLayerWithOutsidePointerEventsDisabledIndex;
	const isDeferredPointerDownOutsideRef = import_react.useRef(false);
	const pointerDownOutside = usePointerDownOutside((event) => {
		onPointerDownOutside?.(event);
		onInteractOutside?.(event);
		if (!event.defaultPrevented) onDismiss?.();
	}, {
		ownerDocument,
		deferPointerDownOutside,
		isDeferredPointerDownOutsideRef,
		dismissableSurfaces: context.dismissableSurfaces,
		shouldHandlePointerDownOutside: import_react.useCallback((target) => {
			if (!(target instanceof Node)) return false;
			const isPointerDownOnBranch = [...context.branches].some((branch) => branch.contains(target));
			return isPointerEventsEnabled && !isPointerDownOnBranch;
		}, [context.branches, isPointerEventsEnabled])
	});
	const focusOutside = useFocusOutside((event) => {
		if (deferPointerDownOutside && isDeferredPointerDownOutsideRef.current) return;
		const target = event.target;
		if ([...context.branches].some((branch) => branch.contains(target))) return;
		onFocusOutside?.(event);
		onInteractOutside?.(event);
		if (!event.defaultPrevented) onDismiss?.();
	}, ownerDocument);
	const isHighestLayer = node ? index === layers.length - 1 : false;
	const handleKeyDown = useCallbackRef$1((event) => {
		if (event.key !== "Escape") return;
		onEscapeKeyDown?.(event);
		if (!event.defaultPrevented && onDismiss) {
			event.preventDefault();
			onDismiss();
		}
	});
	import_react.useEffect(() => {
		if (!isHighestLayer) return;
		ownerDocument.addEventListener("keydown", handleKeyDown, { capture: true });
		return () => ownerDocument.removeEventListener("keydown", handleKeyDown, { capture: true });
	}, [
		ownerDocument,
		isHighestLayer,
		handleKeyDown
	]);
	import_react.useEffect(() => {
		if (!node) return;
		if (disableOutsidePointerEvents) {
			if (context.layersWithOutsidePointerEventsDisabled.size === 0) {
				originalBodyPointerEvents = ownerDocument.body.style.pointerEvents;
				ownerDocument.body.style.pointerEvents = "none";
			}
			context.layersWithOutsidePointerEventsDisabled.add(node);
		}
		context.layers.add(node);
		dispatchUpdate();
		return () => {
			if (disableOutsidePointerEvents) {
				context.layersWithOutsidePointerEventsDisabled.delete(node);
				if (context.layersWithOutsidePointerEventsDisabled.size === 0) ownerDocument.body.style.pointerEvents = originalBodyPointerEvents;
			}
		};
	}, [
		node,
		ownerDocument,
		disableOutsidePointerEvents,
		context
	]);
	import_react.useEffect(() => {
		return () => {
			if (!node) return;
			context.layers.delete(node);
			context.layersWithOutsidePointerEventsDisabled.delete(node);
			dispatchUpdate();
		};
	}, [node, context]);
	import_react.useEffect(() => {
		const handleUpdate = /* @__PURE__ */ __name$5(() => force({}), "handleUpdate");
		document.addEventListener(CONTEXT_UPDATE, handleUpdate);
		return () => document.removeEventListener(CONTEXT_UPDATE, handleUpdate);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		...layerProps,
		ref: composedRefs,
		style: {
			pointerEvents: isBodyPointerEventsDisabled ? isPointerEventsEnabled ? "auto" : "none" : void 0,
			...props.style
		},
		onFocusCapture: composeEventHandlers(props.onFocusCapture, focusOutside.onFocusCapture),
		onBlurCapture: composeEventHandlers(props.onBlurCapture, focusOutside.onBlurCapture),
		onPointerDownCapture: composeEventHandlers(props.onPointerDownCapture, pointerDownOutside.onPointerDownCapture)
	});
}, "DismissableLayer"));
function useDismissableLayerSurface() {
	const context = import_react.useContext(DismissableLayerContext);
	const [node, setNode] = import_react.useState(null);
	import_react.useEffect(() => {
		if (!node) return;
		context.dismissableSurfaces.add(node);
		return () => {
			context.dismissableSurfaces.delete(node);
		};
	}, [node, context.dismissableSurfaces]);
	return setNode;
}
__name$5(useDismissableLayerSurface, "useDismissableLayerSurface");
var IS_TRUE = /* @__PURE__ */ __name$5(() => true, "IS_TRUE");
function usePointerDownOutside(onPointerDownOutside, args) {
	const { ownerDocument = globalThis?.document, deferPointerDownOutside = false, isDeferredPointerDownOutsideRef, dismissableSurfaces, shouldHandlePointerDownOutside = IS_TRUE } = args;
	const handlePointerDownOutside = useCallbackRef$1(onPointerDownOutside);
	const isPointerInsideReactTreeRef = import_react.useRef(false);
	const isPointerDownOutsideRef = import_react.useRef(false);
	const interceptedOutsideInteractionEventsRef = import_react.useRef(/* @__PURE__ */ new Map());
	const handleClickRef = import_react.useRef(() => {});
	import_react.useEffect(() => {
		function resetOutsideInteraction() {
			isPointerDownOutsideRef.current = false;
			isDeferredPointerDownOutsideRef.current = false;
			interceptedOutsideInteractionEventsRef.current.clear();
		}
		__name$5(resetOutsideInteraction, "resetOutsideInteraction");
		function isOutsideInteractionIntercepted() {
			return Array.from(interceptedOutsideInteractionEventsRef.current.values()).some(Boolean);
		}
		__name$5(isOutsideInteractionIntercepted, "isOutsideInteractionIntercepted");
		function handleInteractionCapture(event) {
			if (!isPointerDownOutsideRef.current) return;
			const target = event.target;
			if (!(target instanceof Node && [...dismissableSurfaces].some((surface) => surface.contains(target)))) interceptedOutsideInteractionEventsRef.current.set(event.type, true);
			if (event.type === "click") window.setTimeout(() => {
				if (isPointerDownOutsideRef.current) handleClickRef.current();
			}, 0);
		}
		__name$5(handleInteractionCapture, "handleInteractionCapture");
		function handleInteractionBubble(event) {
			if (isPointerDownOutsideRef.current) interceptedOutsideInteractionEventsRef.current.set(event.type, false);
		}
		__name$5(handleInteractionBubble, "handleInteractionBubble");
		const handlePointerDown = /* @__PURE__ */ __name$5((event) => {
			if (event.target && !isPointerInsideReactTreeRef.current) {
				let handleAndDispatchPointerDownOutsideEvent2 = function() {
					ownerDocument.removeEventListener("click", handleClickRef.current);
					const wasOutsideInteractionIntercepted = isOutsideInteractionIntercepted();
					resetOutsideInteraction();
					if (!wasOutsideInteractionIntercepted) handleAndDispatchCustomEvent(POINTER_DOWN_OUTSIDE, handlePointerDownOutside, eventDetail, { discrete: true });
				};
				__name$5(handleAndDispatchPointerDownOutsideEvent2, "handleAndDispatchPointerDownOutsideEvent");
				if (!shouldHandlePointerDownOutside(event.target)) {
					ownerDocument.removeEventListener("click", handleClickRef.current);
					resetOutsideInteraction();
					isPointerInsideReactTreeRef.current = false;
					return;
				}
				const eventDetail = { originalEvent: event };
				isPointerDownOutsideRef.current = true;
				isDeferredPointerDownOutsideRef.current = deferPointerDownOutside && event.button === 0;
				interceptedOutsideInteractionEventsRef.current.clear();
				if (!deferPointerDownOutside || event.button !== 0) handleAndDispatchPointerDownOutsideEvent2();
				else {
					ownerDocument.removeEventListener("click", handleClickRef.current);
					handleClickRef.current = handleAndDispatchPointerDownOutsideEvent2;
					ownerDocument.addEventListener("click", handleClickRef.current, { once: true });
				}
			} else {
				ownerDocument.removeEventListener("click", handleClickRef.current);
				resetOutsideInteraction();
			}
			isPointerInsideReactTreeRef.current = false;
		}, "handlePointerDown");
		const outsideInteractionEvents = [
			"pointerup",
			"mousedown",
			"mouseup",
			"touchstart",
			"touchend",
			"click"
		];
		for (const eventName of outsideInteractionEvents) {
			ownerDocument.addEventListener(eventName, handleInteractionCapture, true);
			ownerDocument.addEventListener(eventName, handleInteractionBubble);
		}
		const timerId = window.setTimeout(() => {
			ownerDocument.addEventListener("pointerdown", handlePointerDown);
		}, 0);
		return () => {
			window.clearTimeout(timerId);
			ownerDocument.removeEventListener("pointerdown", handlePointerDown);
			ownerDocument.removeEventListener("click", handleClickRef.current);
			for (const eventName of outsideInteractionEvents) {
				ownerDocument.removeEventListener(eventName, handleInteractionCapture, true);
				ownerDocument.removeEventListener(eventName, handleInteractionBubble);
			}
		};
	}, [
		ownerDocument,
		handlePointerDownOutside,
		deferPointerDownOutside,
		isDeferredPointerDownOutsideRef,
		dismissableSurfaces,
		shouldHandlePointerDownOutside
	]);
	return { onPointerDownCapture: /* @__PURE__ */ __name$5(() => isPointerInsideReactTreeRef.current = true, "onPointerDownCapture") };
}
__name$5(usePointerDownOutside, "usePointerDownOutside");
function useFocusOutside(onFocusOutside, ownerDocument = globalThis?.document) {
	const handleFocusOutside = useCallbackRef$1(onFocusOutside);
	const isFocusInsideReactTreeRef = import_react.useRef(false);
	import_react.useEffect(() => {
		const handleFocus = /* @__PURE__ */ __name$5((event) => {
			if (event.target && !isFocusInsideReactTreeRef.current) handleAndDispatchCustomEvent(FOCUS_OUTSIDE, handleFocusOutside, { originalEvent: event }, { discrete: false });
		}, "handleFocus");
		ownerDocument.addEventListener("focusin", handleFocus);
		return () => ownerDocument.removeEventListener("focusin", handleFocus);
	}, [ownerDocument, handleFocusOutside]);
	return {
		onFocusCapture: /* @__PURE__ */ __name$5(() => isFocusInsideReactTreeRef.current = true, "onFocusCapture"),
		onBlurCapture: /* @__PURE__ */ __name$5(() => isFocusInsideReactTreeRef.current = false, "onBlurCapture")
	};
}
__name$5(useFocusOutside, "useFocusOutside");
function dispatchUpdate() {
	const event = new CustomEvent(CONTEXT_UPDATE);
	document.dispatchEvent(event);
}
__name$5(dispatchUpdate, "dispatchUpdate");
function handleAndDispatchCustomEvent(name, handler, detail, { discrete }) {
	const target = detail.originalEvent.target;
	const event = new CustomEvent(name, {
		bubbles: false,
		cancelable: true,
		detail
	});
	if (handler) target.addEventListener(name, handler, { once: true });
	if (discrete) dispatchDiscreteCustomEvent(target, event);
	else target.dispatchEvent(event);
}
__name$5(handleAndDispatchCustomEvent, "handleAndDispatchCustomEvent");
//#endregion
//#region node_modules/@radix-ui/react-focus-scope/dist/index.mjs
var __defProp$4 = Object.defineProperty;
var __name$4 = (target, value) => __defProp$4(target, "name", {
	value,
	configurable: true
});
var AUTOFOCUS_ON_MOUNT = "focusScope.autoFocusOnMount";
var AUTOFOCUS_ON_UNMOUNT = "focusScope.autoFocusOnUnmount";
var EVENT_OPTIONS = {
	bubbles: false,
	cancelable: true
};
var FocusScope = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$4(function FocusScope2(props, forwardedRef) {
	const { loop = false, trapped = false, branches, onMountAutoFocus: onMountAutoFocusProp, onUnmountAutoFocus: onUnmountAutoFocusProp, ...scopeProps } = props;
	const [container, setContainer] = import_react.useState(null);
	const onMountAutoFocus = useCallbackRef$1(onMountAutoFocusProp);
	const onUnmountAutoFocus = useCallbackRef$1(onUnmountAutoFocusProp);
	const lastFocusedElementRef = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, setContainer);
	const branchesRef = import_react.useRef(branches);
	import_react.useEffect(() => {
		branchesRef.current = branches;
	});
	const isTargetInScope = import_react.useCallback((target) => {
		if (!target) return false;
		if (container?.contains(target)) return true;
		return Boolean(branchesRef.current?.some((branch) => branch.contains(target)));
	}, [container]);
	const focusScope = import_react.useRef({
		paused: false,
		pause() {
			this.paused = true;
		},
		resume() {
			this.paused = false;
		}
	}).current;
	import_react.useEffect(() => {
		if (trapped) {
			let handleFocusIn2 = function(event) {
				if (focusScope.paused || !container) return;
				const target = event.target;
				if (isTargetInScope(target)) lastFocusedElementRef.current = target;
				else focus(lastFocusedElementRef.current, { select: true });
			}, handleFocusOut2 = function(event) {
				if (focusScope.paused || !container) return;
				const relatedTarget = event.relatedTarget;
				if (relatedTarget === null) return;
				if (!isTargetInScope(relatedTarget)) focus(lastFocusedElementRef.current, { select: true });
			}, handleMutations2 = function(mutations) {
				if (document.activeElement !== document.body) return;
				for (const mutation of mutations) if (mutation.removedNodes.length > 0) focus(container);
			};
			__name$4(handleFocusIn2, "handleFocusIn");
			__name$4(handleFocusOut2, "handleFocusOut");
			__name$4(handleMutations2, "handleMutations");
			document.addEventListener("focusin", handleFocusIn2);
			document.addEventListener("focusout", handleFocusOut2);
			const mutationObserver = new MutationObserver(handleMutations2);
			if (container) mutationObserver.observe(container, {
				childList: true,
				subtree: true
			});
			return () => {
				document.removeEventListener("focusin", handleFocusIn2);
				document.removeEventListener("focusout", handleFocusOut2);
				mutationObserver.disconnect();
			};
		}
	}, [
		trapped,
		container,
		focusScope.paused,
		isTargetInScope
	]);
	import_react.useEffect(() => {
		if (container) {
			focusScopesStack.add(focusScope);
			const previouslyFocusedElement = document.activeElement;
			if (!container.contains(previouslyFocusedElement)) {
				const mountEvent = new CustomEvent(AUTOFOCUS_ON_MOUNT, EVENT_OPTIONS);
				container.addEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
				container.dispatchEvent(mountEvent);
				if (!mountEvent.defaultPrevented) {
					focusFirst(removeLinks(getTabbableCandidates(container)), { select: true });
					if (document.activeElement === previouslyFocusedElement) focus(container);
				}
			}
			return () => {
				container.removeEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
				const ownerDocument = container.ownerDocument;
				const UnmountEvent = CustomEvent;
				setTimeout(() => {
					const unmountEvent = new UnmountEvent(AUTOFOCUS_ON_UNMOUNT, EVENT_OPTIONS);
					container.addEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
					container.dispatchEvent(unmountEvent);
					if (!unmountEvent.defaultPrevented) focus(previouslyFocusedElement ?? ownerDocument.body, { select: true });
					container.removeEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
					focusScopesStack.remove(focusScope);
				}, 0);
			};
		}
	}, [
		container,
		onMountAutoFocus,
		onUnmountAutoFocus,
		focusScope
	]);
	const handleKeyDown = import_react.useCallback((event) => {
		if (!loop && !trapped) return;
		if (focusScope.paused) return;
		const isTabKey = event.key === "Tab" && !event.altKey && !event.ctrlKey && !event.metaKey;
		const focusedElement = document.activeElement;
		if (isTabKey && focusedElement) {
			const container2 = event.currentTarget;
			const [first, last] = getTabbableEdges(container2);
			if (!(first && last)) {
				if (focusedElement === container2) event.preventDefault();
			} else if (!event.shiftKey && focusedElement === last) {
				event.preventDefault();
				if (loop) focus(first, { select: true });
			} else if (event.shiftKey && focusedElement === first) {
				event.preventDefault();
				if (loop) focus(last, { select: true });
			}
		}
	}, [
		loop,
		trapped,
		focusScope.paused
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		tabIndex: -1,
		...scopeProps,
		ref: composedRefs,
		onKeyDown: handleKeyDown
	});
}, "FocusScope"));
var FocusScopeBranchContext = import_react.createContext(null);
function FocusScopeBranchProvider({ registry, children }) {
	if (!registry) return children;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FocusScopeBranchContext.Provider, {
		value: registry,
		children
	});
}
__name$4(FocusScopeBranchProvider, "FocusScopeBranchProvider");
function useFocusScopeBranchRegistry() {
	const [nodes, setNodes] = import_react.useState([]);
	return {
		nodes,
		registry: import_react.useMemo(() => ({
			add: /* @__PURE__ */ __name$4((node) => setNodes((prev) => prev.includes(node) ? prev : [...prev, node]), "add"),
			remove: /* @__PURE__ */ __name$4((node) => setNodes((prev) => prev.filter((current) => current !== node)), "remove")
		}), [])
	};
}
__name$4(useFocusScopeBranchRegistry, "useFocusScopeBranchRegistry");
function useFocusScopeBranch(node) {
	const registry = import_react.useContext(FocusScopeBranchContext);
	import_react.useEffect(() => {
		if (!node || !registry) return;
		registry.add(node);
		return () => registry.remove(node);
	}, [node, registry]);
}
__name$4(useFocusScopeBranch, "useFocusScopeBranch");
function focusFirst(candidates, { select = false } = {}) {
	const previouslyFocusedElement = document.activeElement;
	for (const candidate of candidates) {
		focus(candidate, { select });
		if (document.activeElement !== previouslyFocusedElement) return;
	}
}
__name$4(focusFirst, "focusFirst");
function getTabbableEdges(container) {
	const candidates = getTabbableCandidates(container);
	return [findVisible(candidates, container), findVisible(candidates.reverse(), container)];
}
__name$4(getTabbableEdges, "getTabbableEdges");
function getTabbableCandidates(container) {
	const nodes = [];
	const walker = container.ownerDocument.createTreeWalker(container, NodeFilter.SHOW_ELEMENT, { acceptNode: /* @__PURE__ */ __name$4((node) => {
		const isHiddenInput = node.tagName === "INPUT" && node.type === "hidden";
		if (node.disabled || node.hidden || isHiddenInput) return NodeFilter.FILTER_SKIP;
		return node.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
	}, "acceptNode") });
	while (walker.nextNode()) nodes.push(walker.currentNode);
	return nodes;
}
__name$4(getTabbableCandidates, "getTabbableCandidates");
function findVisible(elements, container) {
	const canUseCheckVisibility = typeof container.checkVisibility === "function" && container.checkVisibility({ checkVisibilityCSS: true });
	for (const element of elements) if (!(canUseCheckVisibility ? !element.checkVisibility({ checkVisibilityCSS: true }) : isHidden(element, { upTo: container }))) return element;
}
__name$4(findVisible, "findVisible");
function isHidden(node, { upTo }) {
	if (getComputedStyle(node).visibility === "hidden") return true;
	while (node) {
		if (upTo !== void 0 && node === upTo) return false;
		if (getComputedStyle(node).display === "none") return true;
		node = node.parentElement;
	}
	return false;
}
__name$4(isHidden, "isHidden");
function isSelectableInput(element) {
	return element.tagName === "INPUT" && typeof element.select === "function";
}
__name$4(isSelectableInput, "isSelectableInput");
function focus(element, { select = false } = {}) {
	if (element && element.focus) {
		const previouslyFocusedElement = (element.ownerDocument ?? document).activeElement;
		element.focus({ preventScroll: true });
		if (element !== previouslyFocusedElement && isSelectableInput(element) && select) element.select();
	}
}
__name$4(focus, "focus");
var focusScopesStack = createFocusScopesStack();
function createFocusScopesStack() {
	let stack = [];
	return {
		add(focusScope) {
			const activeFocusScope = stack[0];
			if (focusScope !== activeFocusScope) activeFocusScope?.pause();
			stack = arrayRemove(stack, focusScope);
			stack.unshift(focusScope);
		},
		remove(focusScope) {
			stack = arrayRemove(stack, focusScope);
			stack[0]?.resume();
		}
	};
}
__name$4(createFocusScopesStack, "createFocusScopesStack");
function arrayRemove(array, item) {
	const updatedArray = [...array];
	const index = updatedArray.indexOf(item);
	if (index !== -1) updatedArray.splice(index, 1);
	return updatedArray;
}
__name$4(arrayRemove, "arrayRemove");
function removeLinks(items) {
	return items.filter((item) => item.tagName !== "A");
}
__name$4(removeLinks, "removeLinks");
//#endregion
//#region node_modules/@radix-ui/react-portal/dist/index.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var __defProp$3 = Object.defineProperty;
var __name$3 = (target, value) => __defProp$3(target, "name", {
	value,
	configurable: true
});
var Portal = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$3(function Portal2(props, forwardedRef) {
	const { container: containerProp, ...portalProps } = props;
	const [mounted, setMounted] = import_react.useState(false);
	useLayoutEffect2(() => setMounted(true), []);
	const container = containerProp || mounted && globalThis?.document?.body;
	return container ? import_react_dom.createPortal(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		...portalProps,
		ref: forwardedRef
	}), container) : null;
}, "Portal"));
//#endregion
//#region node_modules/@radix-ui/react-presence/dist/index.mjs
var __defProp$2 = Object.defineProperty;
var __name$2 = (target, value) => __defProp$2(target, "name", {
	value,
	configurable: true
});
function useStateMachine(initialState, machine) {
	return import_react.useReducer((state, event) => {
		return machine[state][event] ?? state;
	}, initialState);
}
__name$2(useStateMachine, "useStateMachine");
var Presence = /* @__PURE__ */ __name$2((props) => {
	const { present, children } = props;
	const presence = usePresence(present);
	const child = typeof children === "function" ? children({ present: presence.isPresent }) : import_react.Children.only(children);
	const ref = useStableComposedRefs(presence.ref, getElementRef(child));
	return typeof children === "function" || presence.isPresent ? import_react.cloneElement(child, { ref }) : null;
}, "Presence");
function usePresence(present) {
	const [node, setNode] = import_react.useState();
	const stylesRef = import_react.useRef(null);
	const prevPresentRef = import_react.useRef(present);
	const prevAnimationNameRef = import_react.useRef("none");
	const mountAnimationNameRef = import_react.useRef(void 0);
	const [state, send] = useStateMachine(present ? "mounted" : "unmounted", {
		mounted: {
			UNMOUNT: "unmounted",
			ANIMATION_OUT: "unmountSuspended"
		},
		unmountSuspended: {
			MOUNT: "mounted",
			ANIMATION_END: "unmounted"
		},
		unmounted: { MOUNT: "mounted" }
	});
	import_react.useEffect(() => {
		if (state === "mounted") {
			prevAnimationNameRef.current = mountAnimationNameRef.current ?? getAnimationName(stylesRef.current);
			mountAnimationNameRef.current = void 0;
		} else prevAnimationNameRef.current = "none";
	}, [state]);
	useLayoutEffect2(() => {
		const styles = stylesRef.current;
		const wasPresent = prevPresentRef.current;
		if (wasPresent !== present) {
			const prevAnimationName = prevAnimationNameRef.current;
			const currentAnimationName = getAnimationName(styles);
			if (present) {
				mountAnimationNameRef.current = currentAnimationName;
				send("MOUNT");
			} else if (currentAnimationName === "none" || styles?.display === "none") send("UNMOUNT");
			else if (wasPresent && prevAnimationName !== currentAnimationName) send("ANIMATION_OUT");
			else send("UNMOUNT");
			prevPresentRef.current = present;
		}
	}, [present, send]);
	useLayoutEffect2(() => {
		if (node) {
			let timeoutId;
			const ownerWindow = node.ownerDocument.defaultView ?? window;
			const handleAnimationEnd = /* @__PURE__ */ __name$2((event) => {
				const isCurrentAnimation = getAnimationName(stylesRef.current).includes(CSS.escape(event.animationName));
				if (event.target === node && isCurrentAnimation) {
					send("ANIMATION_END");
					if (!prevPresentRef.current) {
						const currentFillMode = node.style.animationFillMode;
						node.style.animationFillMode = "forwards";
						timeoutId = ownerWindow.setTimeout(() => {
							if (node.style.animationFillMode === "forwards") node.style.animationFillMode = currentFillMode;
						});
					}
				}
			}, "handleAnimationEnd");
			const handleAnimationStart = /* @__PURE__ */ __name$2((event) => {
				if (event.target === node) prevAnimationNameRef.current = getAnimationName(stylesRef.current);
			}, "handleAnimationStart");
			node.addEventListener("animationstart", handleAnimationStart);
			node.addEventListener("animationcancel", handleAnimationEnd);
			node.addEventListener("animationend", handleAnimationEnd);
			return () => {
				ownerWindow.clearTimeout(timeoutId);
				node.removeEventListener("animationstart", handleAnimationStart);
				node.removeEventListener("animationcancel", handleAnimationEnd);
				node.removeEventListener("animationend", handleAnimationEnd);
			};
		} else send("ANIMATION_END");
	}, [node, send]);
	return {
		isPresent: ["mounted", "unmountSuspended"].includes(state),
		ref: import_react.useCallback((node2) => {
			if (node2) {
				const styles = getComputedStyle(node2);
				stylesRef.current = styles;
				mountAnimationNameRef.current = getAnimationName(styles);
			} else stylesRef.current = null;
			setNode(node2);
		}, [])
	};
}
__name$2(usePresence, "usePresence");
function setRef(ref, value) {
	if (typeof ref === "function") return ref(value);
	else if (ref !== null && ref !== void 0) ref.current = value;
}
__name$2(setRef, "setRef");
function useStableComposedRefs(...refs) {
	const refsRef = import_react.useRef(refs);
	refsRef.current = refs;
	return import_react.useCallback((node) => {
		const currentRefs = refsRef.current;
		let hasCleanup = false;
		const cleanups = currentRefs.map((ref) => {
			const cleanup = setRef(ref, node);
			if (!hasCleanup && typeof cleanup === "function") hasCleanup = true;
			return cleanup;
		});
		if (hasCleanup) return () => {
			for (let i = 0; i < cleanups.length; i++) {
				const cleanup = cleanups[i];
				if (typeof cleanup === "function") cleanup();
				else setRef(currentRefs[i], null);
			}
		};
	}, []);
}
__name$2(useStableComposedRefs, "useStableComposedRefs");
function getAnimationName(styles) {
	return styles?.animationName || "none";
}
__name$2(getAnimationName, "getAnimationName");
function getElementRef(element) {
	let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
	let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
	if (mayWarn) return element.ref;
	getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
	mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
	if (mayWarn) return element.props.ref;
	return element.props.ref || element.ref;
}
__name$2(getElementRef, "getElementRef");
//#endregion
//#region node_modules/@radix-ui/react-focus-guards/dist/index.mjs
var __defProp$1 = Object.defineProperty;
var __name$1 = (target, value) => __defProp$1(target, "name", {
	value,
	configurable: true
});
var count = 0;
var guards = null;
function FocusGuards(props) {
	useFocusGuards();
	return props.children;
}
__name$1(FocusGuards, "FocusGuards");
function useFocusGuards() {
	import_react.useEffect(() => {
		if (!guards) guards = {
			start: createFocusGuard(),
			end: createFocusGuard()
		};
		const { start, end } = guards;
		if (document.body.firstElementChild !== start) document.body.insertAdjacentElement("afterbegin", start);
		if (document.body.lastElementChild !== end) document.body.insertAdjacentElement("beforeend", end);
		count++;
		return () => {
			if (count === 1) {
				guards?.start.remove();
				guards?.end.remove();
				guards = null;
			}
			count = Math.max(0, count - 1);
		};
	}, []);
}
__name$1(useFocusGuards, "useFocusGuards");
function createFocusGuard() {
	const element = document.createElement("span");
	element.setAttribute("data-radix-focus-guard", "");
	element.tabIndex = 0;
	element.style.outline = "none";
	element.style.opacity = "0";
	element.style.position = "fixed";
	element.style.pointerEvents = "none";
	return element;
}
__name$1(createFocusGuard, "createFocusGuard");
//#endregion
//#region node_modules/tslib/tslib.es6.mjs
var __assign = function() {
	__assign = Object.assign || function __assign(t) {
		for (var s, i = 1, n = arguments.length; i < n; i++) {
			s = arguments[i];
			for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
		}
		return t;
	};
	return __assign.apply(this, arguments);
};
function __rest(s, e) {
	var t = {};
	for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
	if (s != null && typeof Object.getOwnPropertySymbols === "function") {
		for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
	}
	return t;
}
function __spreadArray(to, from, pack) {
	if (pack || arguments.length === 2) {
		for (var i = 0, l = from.length, ar; i < l; i++) if (ar || !(i in from)) {
			if (!ar) ar = Array.prototype.slice.call(from, 0, i);
			ar[i] = from[i];
		}
	}
	return to.concat(ar || Array.prototype.slice.call(from));
}
//#endregion
//#region node_modules/react-remove-scroll-bar/dist/es2015/constants.js
var zeroRightClassName = "right-scroll-bar-position";
var fullWidthClassName = "width-before-scroll-bar";
var noScrollbarsClassName = "with-scroll-bars-hidden";
/**
* Name of a CSS variable containing the amount of "hidden" scrollbar
* ! might be undefined ! use will fallback!
*/
var removedBarSizeVariable = "--removed-body-scroll-bar-size";
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/assignRef.js
/**
* Assigns a value for a given ref, no matter of the ref format
* @param {RefObject} ref - a callback function or ref object
* @param value - a new value
*
* @see https://github.com/theKashey/use-callback-ref#assignref
* @example
* const refObject = useRef();
* const refFn = (ref) => {....}
*
* assignRef(refObject, "refValue");
* assignRef(refFn, "refValue");
*/
function assignRef(ref, value) {
	if (typeof ref === "function") ref(value);
	else if (ref) ref.current = value;
	return ref;
}
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/useRef.js
/**
* creates a MutableRef with ref change callback
* @param initialValue - initial ref value
* @param {Function} callback - a callback to run when value changes
*
* @example
* const ref = useCallbackRef(0, (newValue, oldValue) => console.log(oldValue, '->', newValue);
* ref.current = 1;
* // prints 0 -> 1
*
* @see https://reactjs.org/docs/hooks-reference.html#useref
* @see https://github.com/theKashey/use-callback-ref#usecallbackref---to-replace-reactuseref
* @returns {MutableRefObject}
*/
function useCallbackRef(initialValue, callback) {
	var ref = (0, import_react.useState)(function() {
		return {
			value: initialValue,
			callback,
			facade: {
				get current() {
					return ref.value;
				},
				set current(value) {
					var last = ref.value;
					if (last !== value) {
						ref.value = value;
						ref.callback(value, last);
					}
				}
			}
		};
	})[0];
	ref.callback = callback;
	return ref.facade;
}
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/useMergeRef.js
var useIsomorphicLayoutEffect = typeof window !== "undefined" ? import_react.useLayoutEffect : import_react.useEffect;
var currentValues = /* @__PURE__ */ new WeakMap();
/**
* Merges two or more refs together providing a single interface to set their value
* @param {RefObject|Ref} refs
* @returns {MutableRefObject} - a new ref, which translates all changes to {refs}
*
* @see {@link mergeRefs} a version without buit-in memoization
* @see https://github.com/theKashey/use-callback-ref#usemergerefs
* @example
* const Component = React.forwardRef((props, ref) => {
*   const ownRef = useRef();
*   const domRef = useMergeRefs([ref, ownRef]); // 👈 merge together
*   return <div ref={domRef}>...</div>
* }
*/
function useMergeRefs(refs, defaultValue) {
	var callbackRef = useCallbackRef(defaultValue || null, function(newValue) {
		return refs.forEach(function(ref) {
			return assignRef(ref, newValue);
		});
	});
	useIsomorphicLayoutEffect(function() {
		var oldValue = currentValues.get(callbackRef);
		if (oldValue) {
			var prevRefs_1 = new Set(oldValue);
			var nextRefs_1 = new Set(refs);
			var current_1 = callbackRef.current;
			prevRefs_1.forEach(function(ref) {
				if (!nextRefs_1.has(ref)) assignRef(ref, null);
			});
			nextRefs_1.forEach(function(ref) {
				if (!prevRefs_1.has(ref)) assignRef(ref, current_1);
			});
		}
		currentValues.set(callbackRef, refs);
	}, [refs]);
	return callbackRef;
}
//#endregion
//#region node_modules/use-sidecar/dist/es2015/medium.js
function ItoI(a) {
	return a;
}
function innerCreateMedium(defaults, middleware) {
	if (middleware === void 0) middleware = ItoI;
	var buffer = [];
	var assigned = false;
	return {
		read: function() {
			if (assigned) throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
			if (buffer.length) return buffer[buffer.length - 1];
			return defaults;
		},
		useMedium: function(data) {
			var item = middleware(data, assigned);
			buffer.push(item);
			return function() {
				buffer = buffer.filter(function(x) {
					return x !== item;
				});
			};
		},
		assignSyncMedium: function(cb) {
			assigned = true;
			while (buffer.length) {
				var cbs = buffer;
				buffer = [];
				cbs.forEach(cb);
			}
			buffer = {
				push: function(x) {
					return cb(x);
				},
				filter: function() {
					return buffer;
				}
			};
		},
		assignMedium: function(cb) {
			assigned = true;
			var pendingQueue = [];
			if (buffer.length) {
				var cbs = buffer;
				buffer = [];
				cbs.forEach(cb);
				pendingQueue = buffer;
			}
			var executeQueue = function() {
				var cbs = pendingQueue;
				pendingQueue = [];
				cbs.forEach(cb);
			};
			var cycle = function() {
				return Promise.resolve().then(executeQueue);
			};
			cycle();
			buffer = {
				push: function(x) {
					pendingQueue.push(x);
					cycle();
				},
				filter: function(filter) {
					pendingQueue = pendingQueue.filter(filter);
					return buffer;
				}
			};
		}
	};
}
function createSidecarMedium(options) {
	if (options === void 0) options = {};
	var medium = innerCreateMedium(null);
	medium.options = __assign({
		async: true,
		ssr: false
	}, options);
	return medium;
}
//#endregion
//#region node_modules/use-sidecar/dist/es2015/exports.js
var SideCar = function(_a) {
	var sideCar = _a.sideCar, rest = __rest(_a, ["sideCar"]);
	if (!sideCar) throw new Error("Sidecar: please provide `sideCar` property to import the right car");
	var Target = sideCar.read();
	if (!Target) throw new Error("Sidecar medium not found");
	return import_react.createElement(Target, __assign({}, rest));
};
SideCar.isSideCarExport = true;
function exportSidecar(medium, exported) {
	medium.useMedium(exported);
	return SideCar;
}
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/medium.js
var effectCar = createSidecarMedium();
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/UI.js
var nothing = function() {};
/**
* Removes scrollbar from the page and contain the scroll within the Lock
*/
var RemoveScroll = import_react.forwardRef(function(props, parentRef) {
	var ref = import_react.useRef(null);
	var _a = import_react.useState({
		onScrollCapture: nothing,
		onWheelCapture: nothing,
		onTouchMoveCapture: nothing
	}), callbacks = _a[0], setCallbacks = _a[1];
	var forwardProps = props.forwardProps, children = props.children, className = props.className, removeScrollBar = props.removeScrollBar, enabled = props.enabled, shards = props.shards, sideCar = props.sideCar, noRelative = props.noRelative, noIsolation = props.noIsolation, inert = props.inert, allowPinchZoom = props.allowPinchZoom, _b = props.as, Container = _b === void 0 ? "div" : _b, gapMode = props.gapMode, rest = __rest(props, [
		"forwardProps",
		"children",
		"className",
		"removeScrollBar",
		"enabled",
		"shards",
		"sideCar",
		"noRelative",
		"noIsolation",
		"inert",
		"allowPinchZoom",
		"as",
		"gapMode"
	]);
	var SideCar = sideCar;
	var containerRef = useMergeRefs([ref, parentRef]);
	var containerProps = __assign(__assign({}, rest), callbacks);
	return import_react.createElement(import_react.Fragment, null, enabled && import_react.createElement(SideCar, {
		sideCar: effectCar,
		removeScrollBar,
		shards,
		noRelative,
		noIsolation,
		inert,
		setCallbacks,
		allowPinchZoom: !!allowPinchZoom,
		lockRef: ref,
		gapMode
	}), forwardProps ? import_react.cloneElement(import_react.Children.only(children), __assign(__assign({}, containerProps), { ref: containerRef })) : import_react.createElement(Container, __assign({}, containerProps, {
		className,
		ref: containerRef
	}), children));
});
RemoveScroll.defaultProps = {
	enabled: true,
	removeScrollBar: true,
	inert: false
};
RemoveScroll.classNames = {
	fullWidth: fullWidthClassName,
	zeroRight: zeroRightClassName
};
var getNonce = function() {
	if (typeof __webpack_nonce__ !== "undefined") return __webpack_nonce__;
};
//#endregion
//#region node_modules/react-style-singleton/dist/es2015/singleton.js
function makeStyleTag() {
	if (!document) return null;
	var tag = document.createElement("style");
	tag.type = "text/css";
	var nonce = getNonce();
	if (nonce) tag.setAttribute("nonce", nonce);
	return tag;
}
function injectStyles(tag, css) {
	if (tag.styleSheet) tag.styleSheet.cssText = css;
	else tag.appendChild(document.createTextNode(css));
}
function insertStyleTag(tag) {
	(document.head || document.getElementsByTagName("head")[0]).appendChild(tag);
}
var stylesheetSingleton = function() {
	var counter = 0;
	var stylesheet = null;
	return {
		add: function(style) {
			if (counter == 0) {
				if (stylesheet = makeStyleTag()) {
					injectStyles(stylesheet, style);
					insertStyleTag(stylesheet);
				}
			}
			counter++;
		},
		remove: function() {
			counter--;
			if (!counter && stylesheet) {
				stylesheet.parentNode && stylesheet.parentNode.removeChild(stylesheet);
				stylesheet = null;
			}
		}
	};
};
//#endregion
//#region node_modules/react-style-singleton/dist/es2015/hook.js
/**
* creates a hook to control style singleton
* @see {@link styleSingleton} for a safer component version
* @example
* ```tsx
* const useStyle = styleHookSingleton();
* ///
* useStyle('body { overflow: hidden}');
*/
var styleHookSingleton = function() {
	var sheet = stylesheetSingleton();
	return function(styles, isDynamic) {
		import_react.useEffect(function() {
			sheet.add(styles);
			return function() {
				sheet.remove();
			};
		}, [styles && isDynamic]);
	};
};
//#endregion
//#region node_modules/react-style-singleton/dist/es2015/component.js
/**
* create a Component to add styles on demand
* - styles are added when first instance is mounted
* - styles are removed when the last instance is unmounted
* - changing styles in runtime does nothing unless dynamic is set. But with multiple components that can lead to the undefined behavior
*/
var styleSingleton = function() {
	var useStyle = styleHookSingleton();
	var Sheet = function(_a) {
		var styles = _a.styles, dynamic = _a.dynamic;
		useStyle(styles, dynamic);
		return null;
	};
	return Sheet;
};
//#endregion
//#region node_modules/react-remove-scroll-bar/dist/es2015/utils.js
var zeroGap = {
	left: 0,
	top: 0,
	right: 0,
	gap: 0
};
var parse = function(x) {
	return parseInt(x || "", 10) || 0;
};
var getOffset = function(gapMode) {
	var cs = window.getComputedStyle(document.body);
	var left = cs[gapMode === "padding" ? "paddingLeft" : "marginLeft"];
	var top = cs[gapMode === "padding" ? "paddingTop" : "marginTop"];
	var right = cs[gapMode === "padding" ? "paddingRight" : "marginRight"];
	return [
		parse(left),
		parse(top),
		parse(right)
	];
};
var getGapWidth = function(gapMode) {
	if (gapMode === void 0) gapMode = "margin";
	if (typeof window === "undefined") return zeroGap;
	var offsets = getOffset(gapMode);
	var documentWidth = document.documentElement.clientWidth;
	var windowWidth = window.innerWidth;
	return {
		left: offsets[0],
		top: offsets[1],
		right: offsets[2],
		gap: Math.max(0, windowWidth - documentWidth + offsets[2] - offsets[0])
	};
};
//#endregion
//#region node_modules/react-remove-scroll-bar/dist/es2015/component.js
var Style = styleSingleton();
var lockAttribute = "data-scroll-locked";
var getStyles = function(_a, allowRelative, gapMode, important) {
	var left = _a.left, top = _a.top, right = _a.right, gap = _a.gap;
	if (gapMode === void 0) gapMode = "margin";
	return "\n  .".concat(noScrollbarsClassName, " {\n   overflow: hidden ").concat(important, ";\n   padding-right: ").concat(gap, "px ").concat(important, ";\n  }\n  body[").concat(lockAttribute, "] {\n    overflow: hidden ").concat(important, ";\n    overscroll-behavior: contain;\n    ").concat([
		allowRelative && "position: relative ".concat(important, ";"),
		gapMode === "margin" && "\n    padding-left: ".concat(left, "px;\n    padding-top: ").concat(top, "px;\n    padding-right: ").concat(right, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(gap, "px ").concat(important, ";\n    "),
		gapMode === "padding" && "padding-right: ".concat(gap, "px ").concat(important, ";")
	].filter(Boolean).join(""), "\n  }\n  \n  .").concat(zeroRightClassName, " {\n    right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " {\n    margin-right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(zeroRightClassName, " .").concat(zeroRightClassName, " {\n    right: 0 ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " .").concat(fullWidthClassName, " {\n    margin-right: 0 ").concat(important, ";\n  }\n  \n  body[").concat(lockAttribute, "] {\n    ").concat(removedBarSizeVariable, ": ").concat(gap, "px;\n  }\n");
};
var getCurrentUseCounter = function() {
	var counter = parseInt(document.body.getAttribute("data-scroll-locked") || "0", 10);
	return isFinite(counter) ? counter : 0;
};
var useLockAttribute = function() {
	import_react.useEffect(function() {
		document.body.setAttribute(lockAttribute, (getCurrentUseCounter() + 1).toString());
		return function() {
			var newCounter = getCurrentUseCounter() - 1;
			if (newCounter <= 0) document.body.removeAttribute(lockAttribute);
			else document.body.setAttribute(lockAttribute, newCounter.toString());
		};
	}, []);
};
/**
* Removes page scrollbar and blocks page scroll when mounted
*/
var RemoveScrollBar = function(_a) {
	var noRelative = _a.noRelative, noImportant = _a.noImportant, _b = _a.gapMode, gapMode = _b === void 0 ? "margin" : _b;
	useLockAttribute();
	var gap = import_react.useMemo(function() {
		return getGapWidth(gapMode);
	}, [gapMode]);
	return import_react.createElement(Style, { styles: getStyles(gap, !noRelative, gapMode, !noImportant ? "!important" : "") });
};
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/aggresiveCapture.js
var passiveSupported = false;
if (typeof window !== "undefined") try {
	var options = Object.defineProperty({}, "passive", { get: function() {
		passiveSupported = true;
		return true;
	} });
	window.addEventListener("test", options, options);
	window.removeEventListener("test", options, options);
} catch (err) {
	passiveSupported = false;
}
var nonPassive = passiveSupported ? { passive: false } : false;
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/handleScroll.js
var alwaysContainsScroll = function(node) {
	return node.tagName === "TEXTAREA";
};
var elementCanBeScrolled = function(node, overflow) {
	if (!(node instanceof Element)) return false;
	var styles = window.getComputedStyle(node);
	return styles[overflow] !== "hidden" && !(styles.overflowY === styles.overflowX && !alwaysContainsScroll(node) && styles[overflow] === "visible");
};
var elementCouldBeVScrolled = function(node) {
	return elementCanBeScrolled(node, "overflowY");
};
var elementCouldBeHScrolled = function(node) {
	return elementCanBeScrolled(node, "overflowX");
};
var locationCouldBeScrolled = function(axis, node) {
	var ownerDocument = node.ownerDocument;
	var current = node;
	do {
		if (typeof ShadowRoot !== "undefined" && current instanceof ShadowRoot) current = current.host;
		if (elementCouldBeScrolled(axis, current)) {
			var _a = getScrollVariables(axis, current);
			if (_a[1] > _a[2]) return true;
		}
		current = current.parentNode;
	} while (current && current !== ownerDocument.body);
	return false;
};
var getVScrollVariables = function(_a) {
	return [
		_a.scrollTop,
		_a.scrollHeight,
		_a.clientHeight
	];
};
var getHScrollVariables = function(_a) {
	return [
		_a.scrollLeft,
		_a.scrollWidth,
		_a.clientWidth
	];
};
var elementCouldBeScrolled = function(axis, node) {
	return axis === "v" ? elementCouldBeVScrolled(node) : elementCouldBeHScrolled(node);
};
var getScrollVariables = function(axis, node) {
	return axis === "v" ? getVScrollVariables(node) : getHScrollVariables(node);
};
var getDirectionFactor = function(axis, direction) {
	/**
	* If the element's direction is rtl (right-to-left), then scrollLeft is 0 when the scrollbar is at its rightmost position,
	* and then increasingly negative as you scroll towards the end of the content.
	* @see https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollLeft
	*/
	return axis === "h" && direction === "rtl" ? -1 : 1;
};
var handleScroll = function(axis, endTarget, event, sourceDelta, noOverscroll) {
	var directionFactor = getDirectionFactor(axis, window.getComputedStyle(endTarget).direction);
	var delta = directionFactor * sourceDelta;
	var target = event.target;
	var targetInLock = endTarget.contains(target);
	var shouldCancelScroll = false;
	var isDeltaPositive = delta > 0;
	var availableScroll = 0;
	var availableScrollTop = 0;
	do {
		if (!target) break;
		var _a = getScrollVariables(axis, target), position = _a[0];
		var elementScroll = _a[1] - _a[2] - directionFactor * position;
		if (position || elementScroll) {
			if (elementCouldBeScrolled(axis, target)) {
				availableScroll += elementScroll;
				availableScrollTop += position;
			}
		}
		var parent_1 = target.parentNode;
		target = parent_1 && parent_1.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? parent_1.host : parent_1;
	} while (!targetInLock && target !== document.body || targetInLock && (endTarget.contains(target) || endTarget === target));
	if (isDeltaPositive && (noOverscroll && Math.abs(availableScroll) < 1 || !noOverscroll && delta > availableScroll)) shouldCancelScroll = true;
	else if (!isDeltaPositive && (noOverscroll && Math.abs(availableScrollTop) < 1 || !noOverscroll && -delta > availableScrollTop)) shouldCancelScroll = true;
	return shouldCancelScroll;
};
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/SideEffect.js
var getTouchXY = function(event) {
	return "changedTouches" in event ? [event.changedTouches[0].clientX, event.changedTouches[0].clientY] : [0, 0];
};
var getDeltaXY = function(event) {
	return [event.deltaX, event.deltaY];
};
var extractRef = function(ref) {
	return ref && "current" in ref ? ref.current : ref;
};
var deltaCompare = function(x, y) {
	return x[0] === y[0] && x[1] === y[1];
};
var generateStyle = function(id) {
	return "\n  .block-interactivity-".concat(id, " {pointer-events: none;}\n  .allow-interactivity-").concat(id, " {pointer-events: all;}\n");
};
var idCounter = 0;
var lockStack = [];
function RemoveScrollSideCar(props) {
	var shouldPreventQueue = import_react.useRef([]);
	var touchStartRef = import_react.useRef([0, 0]);
	var activeAxis = import_react.useRef();
	var id = import_react.useState(idCounter++)[0];
	var Style = import_react.useState(styleSingleton)[0];
	var lastProps = import_react.useRef(props);
	import_react.useEffect(function() {
		lastProps.current = props;
	}, [props]);
	import_react.useEffect(function() {
		if (props.inert) {
			document.body.classList.add("block-interactivity-".concat(id));
			var allow_1 = __spreadArray([props.lockRef.current], (props.shards || []).map(extractRef), true).filter(Boolean);
			allow_1.forEach(function(el) {
				return el.classList.add("allow-interactivity-".concat(id));
			});
			return function() {
				document.body.classList.remove("block-interactivity-".concat(id));
				allow_1.forEach(function(el) {
					return el.classList.remove("allow-interactivity-".concat(id));
				});
			};
		}
	}, [
		props.inert,
		props.lockRef.current,
		props.shards
	]);
	var shouldCancelEvent = import_react.useCallback(function(event, parent) {
		if ("touches" in event && event.touches.length === 2 || event.type === "wheel" && event.ctrlKey) return !lastProps.current.allowPinchZoom;
		var touch = getTouchXY(event);
		var touchStart = touchStartRef.current;
		var deltaX = "deltaX" in event ? event.deltaX : touchStart[0] - touch[0];
		var deltaY = "deltaY" in event ? event.deltaY : touchStart[1] - touch[1];
		var currentAxis;
		var target = event.target;
		var moveDirection = Math.abs(deltaX) > Math.abs(deltaY) ? "h" : "v";
		if ("touches" in event && moveDirection === "h" && target.type === "range") return false;
		var selection = window.getSelection();
		var anchorNode = selection && selection.anchorNode;
		if (anchorNode ? anchorNode === target || anchorNode.contains(target) : false) return false;
		var canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
		if (!canBeScrolledInMainDirection) return true;
		if (canBeScrolledInMainDirection) currentAxis = moveDirection;
		else {
			currentAxis = moveDirection === "v" ? "h" : "v";
			canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
		}
		if (!canBeScrolledInMainDirection) return false;
		if (!activeAxis.current && "changedTouches" in event && (deltaX || deltaY)) activeAxis.current = currentAxis;
		if (!currentAxis) return true;
		var cancelingAxis = activeAxis.current || currentAxis;
		return handleScroll(cancelingAxis, parent, event, cancelingAxis === "h" ? deltaX : deltaY, true);
	}, []);
	var shouldPrevent = import_react.useCallback(function(_event) {
		var event = _event;
		if (!lockStack.length || lockStack[lockStack.length - 1] !== Style) return;
		var delta = "deltaY" in event ? getDeltaXY(event) : getTouchXY(event);
		var sourceEvent = shouldPreventQueue.current.filter(function(e) {
			return e.name === event.type && (e.target === event.target || event.target === e.shadowParent) && deltaCompare(e.delta, delta);
		})[0];
		if (sourceEvent && sourceEvent.should) {
			if (event.cancelable) event.preventDefault();
			return;
		}
		if (!sourceEvent) {
			var shardNodes = (lastProps.current.shards || []).map(extractRef).filter(Boolean).filter(function(node) {
				return node.contains(event.target);
			});
			if (shardNodes.length > 0 ? shouldCancelEvent(event, shardNodes[0]) : !lastProps.current.noIsolation) {
				if (event.cancelable) event.preventDefault();
			}
		}
	}, []);
	var shouldCancel = import_react.useCallback(function(name, delta, target, should) {
		var event = {
			name,
			delta,
			target,
			should,
			shadowParent: getOutermostShadowParent(target)
		};
		shouldPreventQueue.current.push(event);
		setTimeout(function() {
			shouldPreventQueue.current = shouldPreventQueue.current.filter(function(e) {
				return e !== event;
			});
		}, 1);
	}, []);
	var scrollTouchStart = import_react.useCallback(function(event) {
		touchStartRef.current = getTouchXY(event);
		activeAxis.current = void 0;
	}, []);
	var scrollWheel = import_react.useCallback(function(event) {
		shouldCancel(event.type, getDeltaXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
	}, []);
	var scrollTouchMove = import_react.useCallback(function(event) {
		shouldCancel(event.type, getTouchXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
	}, []);
	import_react.useEffect(function() {
		lockStack.push(Style);
		props.setCallbacks({
			onScrollCapture: scrollWheel,
			onWheelCapture: scrollWheel,
			onTouchMoveCapture: scrollTouchMove
		});
		document.addEventListener("wheel", shouldPrevent, nonPassive);
		document.addEventListener("touchmove", shouldPrevent, nonPassive);
		document.addEventListener("touchstart", scrollTouchStart, nonPassive);
		return function() {
			lockStack = lockStack.filter(function(inst) {
				return inst !== Style;
			});
			document.removeEventListener("wheel", shouldPrevent, nonPassive);
			document.removeEventListener("touchmove", shouldPrevent, nonPassive);
			document.removeEventListener("touchstart", scrollTouchStart, nonPassive);
		};
	}, []);
	var removeScrollBar = props.removeScrollBar, inert = props.inert;
	return import_react.createElement(import_react.Fragment, null, inert ? import_react.createElement(Style, { styles: generateStyle(id) }) : null, removeScrollBar ? import_react.createElement(RemoveScrollBar, {
		noRelative: props.noRelative,
		gapMode: props.gapMode
	}) : null);
}
function getOutermostShadowParent(node) {
	var shadowParent = null;
	while (node !== null) {
		if (node instanceof ShadowRoot) {
			shadowParent = node.host;
			node = node.host;
		}
		node = node.parentNode;
	}
	return shadowParent;
}
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/sidecar.js
var sidecar_default = exportSidecar(effectCar, RemoveScrollSideCar);
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/Combination.js
var ReactRemoveScroll = import_react.forwardRef(function(props, ref) {
	return import_react.createElement(RemoveScroll, __assign({}, props, {
		ref,
		sideCar: sidecar_default
	}));
});
ReactRemoveScroll.classNames = RemoveScroll.classNames;
//#endregion
//#region node_modules/aria-hidden/dist/es2015/index.js
var getDefaultParent = function(originalTarget) {
	if (typeof document === "undefined") return null;
	return (Array.isArray(originalTarget) ? originalTarget[0] : originalTarget).ownerDocument.body;
};
var counterMap = /* @__PURE__ */ new WeakMap();
var uncontrolledNodes = /* @__PURE__ */ new WeakMap();
var markerMap = {};
var lockCount = 0;
var unwrapHost = function(node) {
	return node && (node.host || unwrapHost(node.parentNode));
};
var correctTargets = function(parent, targets) {
	return targets.map(function(target) {
		if (parent.contains(target)) return target;
		var correctedTarget = unwrapHost(target);
		if (correctedTarget && parent.contains(correctedTarget)) return correctedTarget;
		console.error("aria-hidden", target, "in not contained inside", parent, ". Doing nothing");
		return null;
	}).filter(function(x) {
		return Boolean(x);
	});
};
/**
* Marks everything except given node(or nodes) as aria-hidden
* @param {Element | Element[]} originalTarget - elements to keep on the page
* @param [parentNode] - top element, defaults to document.body
* @param {String} [markerName] - a special attribute to mark every node
* @param {String} [controlAttribute] - html Attribute to control
* @return {Undo} undo command
*/
var applyAttributeToOthers = function(originalTarget, parentNode, markerName, controlAttribute) {
	var targets = correctTargets(parentNode, Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
	if (!markerMap[markerName]) markerMap[markerName] = /* @__PURE__ */ new WeakMap();
	var markerCounter = markerMap[markerName];
	var hiddenNodes = [];
	var elementsToKeep = /* @__PURE__ */ new Set();
	var elementsToStop = new Set(targets);
	var keep = function(el) {
		if (!el || elementsToKeep.has(el)) return;
		elementsToKeep.add(el);
		keep(el.parentNode);
	};
	targets.forEach(keep);
	var deep = function(parent) {
		if (!parent || elementsToStop.has(parent)) return;
		Array.prototype.forEach.call(parent.children, function(node) {
			if (elementsToKeep.has(node)) deep(node);
			else try {
				var attr = node.getAttribute(controlAttribute);
				var alreadyHidden = attr !== null && attr !== "false";
				var counterValue = (counterMap.get(node) || 0) + 1;
				var markerValue = (markerCounter.get(node) || 0) + 1;
				counterMap.set(node, counterValue);
				markerCounter.set(node, markerValue);
				hiddenNodes.push(node);
				if (counterValue === 1 && alreadyHidden) uncontrolledNodes.set(node, true);
				if (markerValue === 1) node.setAttribute(markerName, "true");
				if (!alreadyHidden) node.setAttribute(controlAttribute, "true");
			} catch (e) {
				console.error("aria-hidden: cannot operate on ", node, e);
			}
		});
	};
	deep(parentNode);
	elementsToKeep.clear();
	lockCount++;
	return function() {
		hiddenNodes.forEach(function(node) {
			var counterValue = counterMap.get(node) - 1;
			var markerValue = markerCounter.get(node) - 1;
			counterMap.set(node, counterValue);
			markerCounter.set(node, markerValue);
			if (!counterValue) {
				if (!uncontrolledNodes.has(node)) node.removeAttribute(controlAttribute);
				uncontrolledNodes.delete(node);
			}
			if (!markerValue) node.removeAttribute(markerName);
		});
		lockCount--;
		if (!lockCount) {
			counterMap = /* @__PURE__ */ new WeakMap();
			counterMap = /* @__PURE__ */ new WeakMap();
			uncontrolledNodes = /* @__PURE__ */ new WeakMap();
			markerMap = {};
		}
	};
};
/**
* Marks everything except given node(or nodes) as aria-hidden
* @param {Element | Element[]} originalTarget - elements to keep on the page
* @param [parentNode] - top element, defaults to document.body
* @param {String} [markerName] - a special attribute to mark every node
* @return {Undo} undo command
*/
var hideOthers = function(originalTarget, parentNode, markerName) {
	if (markerName === void 0) markerName = "data-aria-hidden";
	var targets = Array.from(Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
	var activeParentNode = parentNode || getDefaultParent(originalTarget);
	if (!activeParentNode) return function() {
		return null;
	};
	targets.push.apply(targets, Array.from(activeParentNode.querySelectorAll("[aria-live], script")));
	return applyAttributeToOthers(targets, activeParentNode, markerName, "aria-hidden");
};
//#endregion
//#region node_modules/@radix-ui/react-dialog/dist/index.mjs
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var DIALOG_NAME = "Dialog";
var [createDialogContext, createDialogScope] = /* @__PURE__ */ createContextScope(DIALOG_NAME);
var [DialogProvider, useDialogContext] = createDialogContext(DIALOG_NAME);
var Dialog = /* @__PURE__ */ __name((props) => {
	const { __scopeDialog, children, open: openProp, defaultOpen, onOpenChange, modal = true } = props;
	const triggerRef = import_react.useRef(null);
	const contentRef = import_react.useRef(null);
	const { nodes: branchNodes, registry: branchRegistry } = useFocusScopeBranchRegistry();
	const [open, setOpen] = useControllableState({
		prop: openProp,
		defaultProp: defaultOpen ?? false,
		onChange: onOpenChange,
		caller: DIALOG_NAME
	});
	const [titleCount, setTitleCount] = import_react.useState(0);
	const [descriptionCount, setDescriptionCount] = import_react.useState(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogProvider, {
		scope: __scopeDialog,
		triggerRef,
		contentRef,
		contentId: useId(),
		titleId: useId(),
		descriptionId: useId(),
		titlePresent: titleCount > 0,
		descriptionPresent: descriptionCount > 0,
		setTitleCount,
		setDescriptionCount,
		open,
		onOpenChange: setOpen,
		onOpenToggle: import_react.useCallback(() => setOpen((prevOpen) => !prevOpen), [setOpen]),
		modal,
		branchNodes,
		branchRegistry,
		children
	});
}, "Dialog");
var TRIGGER_NAME = "DialogTrigger";
var DialogTrigger = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogTrigger2(props, forwardedRef) {
	const { __scopeDialog, ...triggerProps } = props;
	const context = useDialogContext(TRIGGER_NAME, __scopeDialog);
	const composedTriggerRef = useComposedRefs(forwardedRef, context.triggerRef);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.button, {
		type: "button",
		"aria-haspopup": "dialog",
		"aria-expanded": context.open,
		"aria-controls": context.open ? context.contentId : void 0,
		"data-state": getState(context.open),
		...triggerProps,
		ref: composedTriggerRef,
		onClick: composeEventHandlers(props.onClick, context.onOpenToggle)
	});
}, "DialogTrigger"));
var PORTAL_NAME = "DialogPortal";
var [PortalProvider, usePortalContext] = createDialogContext(PORTAL_NAME, { forceMount: void 0 });
var DialogPortal = /* @__PURE__ */ __name((props) => {
	const { __scopeDialog, forceMount, children, container } = props;
	const context = useDialogContext(PORTAL_NAME, __scopeDialog);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalProvider, {
		scope: __scopeDialog,
		forceMount,
		children: import_react.Children.map(children, (child) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
			present: forceMount || context.open,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, {
				asChild: true,
				container,
				children: child
			})
		}))
	});
}, "DialogPortal");
var OVERLAY_NAME = "DialogOverlay";
var DialogOverlay = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogOverlay2(props, forwardedRef) {
	const portalContext = usePortalContext(OVERLAY_NAME, props.__scopeDialog);
	const { forceMount = portalContext.forceMount, ...overlayProps } = props;
	const context = useDialogContext(OVERLAY_NAME, props.__scopeDialog);
	return context.modal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
		present: forceMount || context.open,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlayImpl, {
			...overlayProps,
			ref: forwardedRef
		})
	}) : null;
}, "DialogOverlay"));
var Slot = createSlot("DialogOverlay.RemoveScroll");
var DialogOverlayImpl = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogOverlayImpl2(props, forwardedRef) {
	const { __scopeDialog, ...overlayProps } = props;
	const context = useDialogContext(OVERLAY_NAME, __scopeDialog);
	const registerDismissableSurface = useDismissableLayerSurface();
	const composedRefs = useComposedRefs(forwardedRef, registerDismissableSurface);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReactRemoveScroll, {
		as: Slot,
		allowPinchZoom: true,
		shards: import_react.useMemo(() => [context.contentRef, ...context.branchNodes.map((node) => ({ current: node }))], [context.contentRef, context.branchNodes]),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
			"data-state": getState(context.open),
			...overlayProps,
			ref: composedRefs,
			style: {
				pointerEvents: "auto",
				...overlayProps.style
			}
		})
	});
}, "DialogOverlayImpl"));
var CONTENT_NAME = "DialogContent";
var DialogContent = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogContent2(props, forwardedRef) {
	const portalContext = usePortalContext(CONTENT_NAME, props.__scopeDialog);
	const { forceMount = portalContext.forceMount, ...contentProps } = props;
	const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
		present: forceMount || context.open,
		children: context.modal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContentModal, {
			...contentProps,
			ref: forwardedRef
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContentNonModal, {
			...contentProps,
			ref: forwardedRef
		})
	});
}, "DialogContent"));
var DialogContentModal = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogContentModal2(props, forwardedRef) {
	const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
	const contentRef = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, context.contentRef, contentRef);
	import_react.useEffect(() => {
		const content = contentRef.current;
		if (content) return hideOthers(content);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContentImpl, {
		...props,
		ref: composedRefs,
		trapFocus: context.open,
		disableOutsidePointerEvents: context.open,
		onCloseAutoFocus: composeEventHandlers(props.onCloseAutoFocus, (event) => {
			event.preventDefault();
			context.triggerRef.current?.focus();
		}),
		onPointerDownOutside: composeEventHandlers(props.onPointerDownOutside, (event) => {
			const originalEvent = event.detail.originalEvent;
			const ctrlLeftClick = originalEvent.button === 0 && originalEvent.ctrlKey === true;
			if (originalEvent.button === 2 || ctrlLeftClick) event.preventDefault();
		}),
		onFocusOutside: composeEventHandlers(props.onFocusOutside, (event) => event.preventDefault())
	});
}, "DialogContentModal"));
var DialogContentNonModal = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogContentNonModal2(props, forwardedRef) {
	const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
	const hasInteractedOutsideRef = import_react.useRef(false);
	const hasPointerDownOutsideRef = import_react.useRef(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContentImpl, {
		...props,
		ref: forwardedRef,
		trapFocus: false,
		disableOutsidePointerEvents: false,
		onCloseAutoFocus: (event) => {
			props.onCloseAutoFocus?.(event);
			if (!event.defaultPrevented) {
				if (!hasInteractedOutsideRef.current) context.triggerRef.current?.focus();
				event.preventDefault();
			}
			hasInteractedOutsideRef.current = false;
			hasPointerDownOutsideRef.current = false;
		},
		onInteractOutside: (event) => {
			props.onInteractOutside?.(event);
			if (!event.defaultPrevented) {
				hasInteractedOutsideRef.current = true;
				if (event.detail.originalEvent.type === "pointerdown") hasPointerDownOutsideRef.current = true;
			}
			const target = event.target;
			if (context.triggerRef.current?.contains(target)) event.preventDefault();
			if (event.detail.originalEvent.type === "focusin" && hasPointerDownOutsideRef.current) event.preventDefault();
		}
	});
}, "DialogContentNonModal"));
var DialogContentImpl = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogContentImpl2(props, forwardedRef) {
	const { __scopeDialog, trapFocus, onOpenAutoFocus, onCloseAutoFocus, "aria-describedby": ariaDescribedby, children, ...contentProps } = props;
	const context = useDialogContext(CONTENT_NAME, __scopeDialog);
	useFocusGuards();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FocusScopeBranchProvider, {
		registry: context.branchRegistry,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FocusScope, {
			asChild: true,
			loop: true,
			trapped: trapFocus,
			branches: context.branchNodes,
			onMountAutoFocus: onOpenAutoFocus,
			onUnmountAutoFocus: onCloseAutoFocus,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DismissableLayer, {
				role: "dialog",
				id: context.contentId,
				"aria-labelledby": context.titlePresent ? context.titleId : void 0,
				"aria-describedby": context.descriptionPresent ? concatAriaDescribedby(ariaDescribedby, context.descriptionId) : ariaDescribedby,
				"data-state": getState(context.open),
				...contentProps,
				ref: forwardedRef,
				deferPointerDownOutside: true,
				onDismiss: () => context.onOpenChange(false),
				children
			})
		})
	});
}, "DialogContentImpl"));
var DialogTitle = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogTitle2(props, forwardedRef) {
	const { __scopeDialog, ...titleProps } = props;
	const context = useDialogContext("DialogTitle", __scopeDialog);
	const { setTitleCount } = context;
	useLayoutEffect2(() => {
		setTitleCount((count) => count + 1);
		return () => setTitleCount((count) => count - 1);
	}, [setTitleCount]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.h2, {
		id: context.titleId,
		...titleProps,
		ref: forwardedRef
	});
}, "DialogTitle"));
var DialogDescription = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogDescription2(props, forwardedRef) {
	const { __scopeDialog, ...descriptionProps } = props;
	const context = useDialogContext("DialogDescription", __scopeDialog);
	const { setDescriptionCount } = context;
	useLayoutEffect2(() => {
		setDescriptionCount((count) => count + 1);
		return () => setDescriptionCount((count) => count - 1);
	}, [setDescriptionCount]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.p, {
		id: context.descriptionId,
		...descriptionProps,
		ref: forwardedRef
	});
}, "DialogDescription"));
var CLOSE_NAME = "DialogClose";
var DialogClose = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogClose2(props, forwardedRef) {
	const { __scopeDialog, ...closeProps } = props;
	const context = useDialogContext(CLOSE_NAME, __scopeDialog);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.button, {
		type: "button",
		...closeProps,
		ref: forwardedRef,
		onClick: composeEventHandlers(props.onClick, () => context.onOpenChange(false))
	});
}, "DialogClose"));
var WarningProvider = /* @__PURE__ */ __name((props) => {
	return props.children;
}, "WarningProvider");
function concatAriaDescribedby(...values) {
	const ids = /* @__PURE__ */ new Set();
	for (const value of values) {
		if (typeof value !== "string") continue;
		for (const id of String(value).trim().split(/\s+/)) if (id) ids.add(id);
	}
	return ids.size > 0 ? Array.from(ids).join(" ") : void 0;
}
__name(concatAriaDescribedby, "concatAriaDescribedby");
function getState(open) {
	return open ? "open" : "closed";
}
__name(getState, "getState");
//#endregion
export { DialogClose as Close, DialogClose, DialogContent as Content, DialogContent, DialogDescription as Description, DialogDescription, Dialog, Dialog as Root, DialogOverlay, DialogOverlay as Overlay, DialogPortal, DialogPortal as Portal, DialogTitle, DialogTitle as Title, DialogTrigger, DialogTrigger as Trigger, WarningProvider, createDialogScope };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHJhZGl4LXVpX3JlYWN0LWRpYWxvZy5qcyIsIm5hbWVzIjpbIl9fZGVmUHJvcCIsIl9fbmFtZSIsIl9fZGVmUHJvcCIsIl9fbmFtZSIsIl9fZGVmUHJvcCIsIl9fbmFtZSIsIlJlYWN0IiwiY291bnQiLCJfX2RlZlByb3AiLCJfX25hbWUiLCJSZWFjdCIsInVzZVJlYWN0SW5zZXJ0aW9uRWZmZWN0IiwiX19kZWZQcm9wIiwiX19uYW1lIiwiUmVhY3QiLCJ1c2VMYXlvdXRFZmZlY3QiLCJfX2RlZlByb3AiLCJfX25hbWUiLCJSZWFjdCIsInVzZUNhbGxiYWNrUmVmIiwiX19kZWZQcm9wIiwiX19uYW1lIiwidXNlQ2FsbGJhY2tSZWYiLCJfX2RlZlByb3AiLCJfX25hbWUiLCJ1c2VDYWxsYmFja1JlZiIsIl9fZGVmUHJvcCIsIl9fbmFtZSIsIl9fZGVmUHJvcCIsIl9fbmFtZSIsIl9fZGVmUHJvcCIsIl9fbmFtZSIsInVzZVN0YXRlIiwiU2lkZUNhciIsIlBvcnRhbFByaW1pdGl2ZSIsIlJlbW92ZVNjcm9sbCJdLCJzb3VyY2VzIjpbIi4uLy4uL0ByYWRpeC11aS9wcmltaXRpdmUvZGlzdC9pbmRleC5tanMiLCIuLi8uLi9AcmFkaXgtdWkvcmVhY3QtY29udGV4dC9kaXN0L2luZGV4Lm1qcyIsIi4uLy4uL0ByYWRpeC11aS9yZWFjdC11c2UtbGF5b3V0LWVmZmVjdC9kaXN0L2luZGV4Lm1qcyIsIi4uLy4uL0ByYWRpeC11aS9yZWFjdC1pZC9kaXN0L2luZGV4Lm1qcyIsIi4uLy4uL0ByYWRpeC11aS9yZWFjdC11c2UtZWZmZWN0LWV2ZW50L2Rpc3QvaW5kZXgubWpzIiwiLi4vLi4vQHJhZGl4LXVpL3JlYWN0LXVzZS1jb250cm9sbGFibGUtc3RhdGUvZGlzdC9pbmRleC5tanMiLCIuLi8uLi9AcmFkaXgtdWkvcmVhY3QtdXNlLWNhbGxiYWNrLXJlZi9kaXN0L2luZGV4Lm1qcyIsIi4uLy4uL0ByYWRpeC11aS9yZWFjdC1kaXNtaXNzYWJsZS1sYXllci9kaXN0L2luZGV4Lm1qcyIsIi4uLy4uL0ByYWRpeC11aS9yZWFjdC1mb2N1cy1zY29wZS9kaXN0L2luZGV4Lm1qcyIsIi4uLy4uL0ByYWRpeC11aS9yZWFjdC1wb3J0YWwvZGlzdC9pbmRleC5tanMiLCIuLi8uLi9AcmFkaXgtdWkvcmVhY3QtcHJlc2VuY2UvZGlzdC9pbmRleC5tanMiLCIuLi8uLi9AcmFkaXgtdWkvcmVhY3QtZm9jdXMtZ3VhcmRzL2Rpc3QvaW5kZXgubWpzIiwiLi4vLi4vdHNsaWIvdHNsaWIuZXM2Lm1qcyIsIi4uLy4uL3JlYWN0LXJlbW92ZS1zY3JvbGwtYmFyL2Rpc3QvZXMyMDE1L2NvbnN0YW50cy5qcyIsIi4uLy4uL3VzZS1jYWxsYmFjay1yZWYvZGlzdC9lczIwMTUvYXNzaWduUmVmLmpzIiwiLi4vLi4vdXNlLWNhbGxiYWNrLXJlZi9kaXN0L2VzMjAxNS91c2VSZWYuanMiLCIuLi8uLi91c2UtY2FsbGJhY2stcmVmL2Rpc3QvZXMyMDE1L3VzZU1lcmdlUmVmLmpzIiwiLi4vLi4vdXNlLXNpZGVjYXIvZGlzdC9lczIwMTUvbWVkaXVtLmpzIiwiLi4vLi4vdXNlLXNpZGVjYXIvZGlzdC9lczIwMTUvZXhwb3J0cy5qcyIsIi4uLy4uL3JlYWN0LXJlbW92ZS1zY3JvbGwvZGlzdC9lczIwMTUvbWVkaXVtLmpzIiwiLi4vLi4vcmVhY3QtcmVtb3ZlLXNjcm9sbC9kaXN0L2VzMjAxNS9VSS5qcyIsIi4uLy4uL2dldC1ub25jZS9kaXN0L2VzMjAxNS9pbmRleC5qcyIsIi4uLy4uL3JlYWN0LXN0eWxlLXNpbmdsZXRvbi9kaXN0L2VzMjAxNS9zaW5nbGV0b24uanMiLCIuLi8uLi9yZWFjdC1zdHlsZS1zaW5nbGV0b24vZGlzdC9lczIwMTUvaG9vay5qcyIsIi4uLy4uL3JlYWN0LXN0eWxlLXNpbmdsZXRvbi9kaXN0L2VzMjAxNS9jb21wb25lbnQuanMiLCIuLi8uLi9yZWFjdC1yZW1vdmUtc2Nyb2xsLWJhci9kaXN0L2VzMjAxNS91dGlscy5qcyIsIi4uLy4uL3JlYWN0LXJlbW92ZS1zY3JvbGwtYmFyL2Rpc3QvZXMyMDE1L2NvbXBvbmVudC5qcyIsIi4uLy4uL3JlYWN0LXJlbW92ZS1zY3JvbGwvZGlzdC9lczIwMTUvYWdncmVzaXZlQ2FwdHVyZS5qcyIsIi4uLy4uL3JlYWN0LXJlbW92ZS1zY3JvbGwvZGlzdC9lczIwMTUvaGFuZGxlU2Nyb2xsLmpzIiwiLi4vLi4vcmVhY3QtcmVtb3ZlLXNjcm9sbC9kaXN0L2VzMjAxNS9TaWRlRWZmZWN0LmpzIiwiLi4vLi4vcmVhY3QtcmVtb3ZlLXNjcm9sbC9kaXN0L2VzMjAxNS9zaWRlY2FyLmpzIiwiLi4vLi4vcmVhY3QtcmVtb3ZlLXNjcm9sbC9kaXN0L2VzMjAxNS9Db21iaW5hdGlvbi5qcyIsIi4uLy4uL2FyaWEtaGlkZGVuL2Rpc3QvZXMyMDE1L2luZGV4LmpzIiwiLi4vLi4vQHJhZGl4LXVpL3JlYWN0LWRpYWxvZy9kaXN0L2luZGV4Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fbmFtZSA9ICh0YXJnZXQsIHZhbHVlKSA9PiBfX2RlZlByb3AodGFyZ2V0LCBcIm5hbWVcIiwgeyB2YWx1ZSwgY29uZmlndXJhYmxlOiB0cnVlIH0pO1xuXG4vLyBzcmMvcHJpbWl0aXZlLnRzeFxudmFyIGNhblVzZURPTSA9ICEhKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgJiYgd2luZG93LmRvY3VtZW50ICYmIHdpbmRvdy5kb2N1bWVudC5jcmVhdGVFbGVtZW50KTtcbmZ1bmN0aW9uIGNvbXBvc2VFdmVudEhhbmRsZXJzKG9yaWdpbmFsRXZlbnRIYW5kbGVyLCBvdXJFdmVudEhhbmRsZXIsIHsgY2hlY2tGb3JEZWZhdWx0UHJldmVudGVkID0gdHJ1ZSB9ID0ge30pIHtcbiAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gaGFuZGxlRXZlbnQoZXZlbnQpIHtcbiAgICBvcmlnaW5hbEV2ZW50SGFuZGxlcj8uKGV2ZW50KTtcbiAgICBpZiAoY2hlY2tGb3JEZWZhdWx0UHJldmVudGVkID09PSBmYWxzZSB8fCAhZXZlbnQgfHwgIWV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICAgIHJldHVybiBvdXJFdmVudEhhbmRsZXI/LihldmVudCk7XG4gICAgfVxuICB9LCBcImhhbmRsZUV2ZW50XCIpO1xufVxuX19uYW1lKGNvbXBvc2VFdmVudEhhbmRsZXJzLCBcImNvbXBvc2VFdmVudEhhbmRsZXJzXCIpO1xuZnVuY3Rpb24gZ2V0T3duZXJXaW5kb3coZWxlbWVudCkge1xuICBpZiAoIWNhblVzZURPTSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkNhbm5vdCBhY2Nlc3Mgd2luZG93IG91dHNpZGUgb2YgdGhlIERPTVwiKTtcbiAgfVxuICByZXR1cm4gZWxlbWVudD8ub3duZXJEb2N1bWVudD8uZGVmYXVsdFZpZXcgPz8gd2luZG93O1xufVxuX19uYW1lKGdldE93bmVyV2luZG93LCBcImdldE93bmVyV2luZG93XCIpO1xuZnVuY3Rpb24gZ2V0T3duZXJEb2N1bWVudChlbGVtZW50KSB7XG4gIGlmICghY2FuVXNlRE9NKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGFjY2VzcyBkb2N1bWVudCBvdXRzaWRlIG9mIHRoZSBET01cIik7XG4gIH1cbiAgcmV0dXJuIGVsZW1lbnQ/Lm93bmVyRG9jdW1lbnQgPz8gZG9jdW1lbnQ7XG59XG5fX25hbWUoZ2V0T3duZXJEb2N1bWVudCwgXCJnZXRPd25lckRvY3VtZW50XCIpO1xuZnVuY3Rpb24gZ2V0QWN0aXZlRWxlbWVudChub2RlLCBhY3RpdmVEZXNjZW5kYW50ID0gZmFsc2UpIHtcbiAgY29uc3QgeyBhY3RpdmVFbGVtZW50IH0gPSBnZXRPd25lckRvY3VtZW50KG5vZGUpO1xuICBpZiAoIWFjdGl2ZUVsZW1lbnQ/Lm5vZGVOYW1lKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgaWYgKGlzRnJhbWUoYWN0aXZlRWxlbWVudCkgJiYgYWN0aXZlRWxlbWVudC5jb250ZW50RG9jdW1lbnQpIHtcbiAgICByZXR1cm4gZ2V0QWN0aXZlRWxlbWVudChhY3RpdmVFbGVtZW50LmNvbnRlbnREb2N1bWVudC5ib2R5LCBhY3RpdmVEZXNjZW5kYW50KTtcbiAgfVxuICBpZiAoYWN0aXZlRGVzY2VuZGFudCkge1xuICAgIGNvbnN0IGlkID0gYWN0aXZlRWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWFjdGl2ZWRlc2NlbmRhbnRcIik7XG4gICAgaWYgKGlkKSB7XG4gICAgICBjb25zdCBlbGVtZW50ID0gZ2V0T3duZXJEb2N1bWVudChhY3RpdmVFbGVtZW50KS5nZXRFbGVtZW50QnlJZChpZCk7XG4gICAgICBpZiAoZWxlbWVudCkge1xuICAgICAgICByZXR1cm4gZWxlbWVudDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIGFjdGl2ZUVsZW1lbnQ7XG59XG5fX25hbWUoZ2V0QWN0aXZlRWxlbWVudCwgXCJnZXRBY3RpdmVFbGVtZW50XCIpO1xuZnVuY3Rpb24gaXNGcmFtZShlbGVtZW50KSB7XG4gIHJldHVybiBlbGVtZW50LnRhZ05hbWUgPT09IFwiSUZSQU1FXCI7XG59XG5fX25hbWUoaXNGcmFtZSwgXCJpc0ZyYW1lXCIpO1xuZXhwb3J0IHtcbiAgY2FuVXNlRE9NLFxuICBjb21wb3NlRXZlbnRIYW5kbGVycyxcbiAgZ2V0QWN0aXZlRWxlbWVudCxcbiAgZ2V0T3duZXJEb2N1bWVudCxcbiAgZ2V0T3duZXJXaW5kb3csXG4gIGlzRnJhbWVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tanMubWFwXG4iLCJ2YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fbmFtZSA9ICh0YXJnZXQsIHZhbHVlKSA9PiBfX2RlZlByb3AodGFyZ2V0LCBcIm5hbWVcIiwgeyB2YWx1ZSwgY29uZmlndXJhYmxlOiB0cnVlIH0pO1xuXG4vLyBzcmMvY3JlYXRlLWNvbnRleHQudHN4XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIGNyZWF0ZUNvbnRleHQyKHJvb3RDb21wb25lbnROYW1lLCBkZWZhdWx0Q29udGV4dCkge1xuICBjb25zdCBDb250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChkZWZhdWx0Q29udGV4dCk7XG4gIENvbnRleHQuZGlzcGxheU5hbWUgPSByb290Q29tcG9uZW50TmFtZSArIFwiQ29udGV4dFwiO1xuICBjb25zdCBQcm92aWRlciA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKHByb3BzKSA9PiB7XG4gICAgY29uc3QgeyBjaGlsZHJlbiwgLi4uY29udGV4dCB9ID0gcHJvcHM7XG4gICAgY29uc3QgdmFsdWUgPSBSZWFjdC51c2VNZW1vKCgpID0+IGNvbnRleHQsIE9iamVjdC52YWx1ZXMoY29udGV4dCkpO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KENvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWUsIGNoaWxkcmVuIH0pO1xuICB9LCBcIlByb3ZpZGVyXCIpO1xuICBQcm92aWRlci5kaXNwbGF5TmFtZSA9IHJvb3RDb21wb25lbnROYW1lICsgXCJQcm92aWRlclwiO1xuICBmdW5jdGlvbiB1c2VDb250ZXh0Mihjb25zdW1lck5hbWUsIG9wdGlvbnMgPSB7fSkge1xuICAgIGNvbnN0IHsgb3B0aW9uYWwgPSBmYWxzZSB9ID0gb3B0aW9ucztcbiAgICBjb25zdCBjb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChDb250ZXh0KTtcbiAgICBpZiAoY29udGV4dCkgcmV0dXJuIGNvbnRleHQ7XG4gICAgaWYgKGRlZmF1bHRDb250ZXh0ICE9PSB2b2lkIDApIHJldHVybiBkZWZhdWx0Q29udGV4dDtcbiAgICBpZiAob3B0aW9uYWwpIHJldHVybiB2b2lkIDA7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBcXGAke2NvbnN1bWVyTmFtZX1cXGAgbXVzdCBiZSB1c2VkIHdpdGhpbiBcXGAke3Jvb3RDb21wb25lbnROYW1lfVxcYGApO1xuICB9XG4gIF9fbmFtZSh1c2VDb250ZXh0MiwgXCJ1c2VDb250ZXh0XCIpO1xuICByZXR1cm4gW1Byb3ZpZGVyLCB1c2VDb250ZXh0Ml07XG59XG5fX25hbWUoY3JlYXRlQ29udGV4dDIsIFwiY3JlYXRlQ29udGV4dFwiKTtcbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiBjcmVhdGVDb250ZXh0U2NvcGUoc2NvcGVOYW1lLCBjcmVhdGVDb250ZXh0U2NvcGVEZXBzID0gW10pIHtcbiAgbGV0IGRlZmF1bHRDb250ZXh0cyA9IFtdO1xuICBmdW5jdGlvbiBjcmVhdGVDb250ZXh0Myhyb290Q29tcG9uZW50TmFtZSwgZGVmYXVsdENvbnRleHQpIHtcbiAgICBjb25zdCBCYXNlQ29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQoZGVmYXVsdENvbnRleHQpO1xuICAgIEJhc2VDb250ZXh0LmRpc3BsYXlOYW1lID0gcm9vdENvbXBvbmVudE5hbWUgKyBcIkNvbnRleHRcIjtcbiAgICBjb25zdCBpbmRleCA9IGRlZmF1bHRDb250ZXh0cy5sZW5ndGg7XG4gICAgZGVmYXVsdENvbnRleHRzID0gWy4uLmRlZmF1bHRDb250ZXh0cywgZGVmYXVsdENvbnRleHRdO1xuICAgIGNvbnN0IFByb3ZpZGVyID0gLyogQF9fUFVSRV9fICovIF9fbmFtZSgocHJvcHMpID0+IHtcbiAgICAgIGNvbnN0IHsgc2NvcGUsIGNoaWxkcmVuLCAuLi5jb250ZXh0IH0gPSBwcm9wcztcbiAgICAgIGNvbnN0IENvbnRleHQgPSBzY29wZT8uW3Njb3BlTmFtZV0/LltpbmRleF0gfHwgQmFzZUNvbnRleHQ7XG4gICAgICBjb25zdCB2YWx1ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gY29udGV4dCwgT2JqZWN0LnZhbHVlcyhjb250ZXh0KSk7XG4gICAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChDb250ZXh0LlByb3ZpZGVyLCB7IHZhbHVlLCBjaGlsZHJlbiB9KTtcbiAgICB9LCBcIlByb3ZpZGVyXCIpO1xuICAgIFByb3ZpZGVyLmRpc3BsYXlOYW1lID0gcm9vdENvbXBvbmVudE5hbWUgKyBcIlByb3ZpZGVyXCI7XG4gICAgZnVuY3Rpb24gdXNlQ29udGV4dDIoY29uc3VtZXJOYW1lLCBzY29wZSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgICBjb25zdCB7IG9wdGlvbmFsID0gZmFsc2UgfSA9IG9wdGlvbnM7XG4gICAgICBjb25zdCBDb250ZXh0ID0gc2NvcGU/LltzY29wZU5hbWVdPy5baW5kZXhdIHx8IEJhc2VDb250ZXh0O1xuICAgICAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoQ29udGV4dCk7XG4gICAgICBpZiAoY29udGV4dCkgcmV0dXJuIGNvbnRleHQ7XG4gICAgICBpZiAoZGVmYXVsdENvbnRleHQgIT09IHZvaWQgMCkgcmV0dXJuIGRlZmF1bHRDb250ZXh0O1xuICAgICAgaWYgKG9wdGlvbmFsKSByZXR1cm4gdm9pZCAwO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBcXGAke2NvbnN1bWVyTmFtZX1cXGAgbXVzdCBiZSB1c2VkIHdpdGhpbiBcXGAke3Jvb3RDb21wb25lbnROYW1lfVxcYGApO1xuICAgIH1cbiAgICBfX25hbWUodXNlQ29udGV4dDIsIFwidXNlQ29udGV4dFwiKTtcbiAgICByZXR1cm4gW1Byb3ZpZGVyLCB1c2VDb250ZXh0Ml07XG4gIH1cbiAgX19uYW1lKGNyZWF0ZUNvbnRleHQzLCBcImNyZWF0ZUNvbnRleHRcIik7XG4gIGNvbnN0IGNyZWF0ZVNjb3BlID0gLyogQF9fUFVSRV9fICovIF9fbmFtZSgoKSA9PiB7XG4gICAgY29uc3Qgc2NvcGVDb250ZXh0cyA9IGRlZmF1bHRDb250ZXh0cy5tYXAoKGRlZmF1bHRDb250ZXh0KSA9PiB7XG4gICAgICByZXR1cm4gUmVhY3QuY3JlYXRlQ29udGV4dChkZWZhdWx0Q29udGV4dCk7XG4gICAgfSk7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gdXNlU2NvcGUoc2NvcGUpIHtcbiAgICAgIGNvbnN0IGNvbnRleHRzID0gc2NvcGU/LltzY29wZU5hbWVdIHx8IHNjb3BlQ29udGV4dHM7XG4gICAgICByZXR1cm4gUmVhY3QudXNlTWVtbyhcbiAgICAgICAgKCkgPT4gKHsgW2BfX3Njb3BlJHtzY29wZU5hbWV9YF06IHsgLi4uc2NvcGUsIFtzY29wZU5hbWVdOiBjb250ZXh0cyB9IH0pLFxuICAgICAgICBbc2NvcGUsIGNvbnRleHRzXVxuICAgICAgKTtcbiAgICB9LCBcInVzZVNjb3BlXCIpO1xuICB9LCBcImNyZWF0ZVNjb3BlXCIpO1xuICBjcmVhdGVTY29wZS5zY29wZU5hbWUgPSBzY29wZU5hbWU7XG4gIHJldHVybiBbY3JlYXRlQ29udGV4dDMsIGNvbXBvc2VDb250ZXh0U2NvcGVzKGNyZWF0ZVNjb3BlLCAuLi5jcmVhdGVDb250ZXh0U2NvcGVEZXBzKV07XG59XG5fX25hbWUoY3JlYXRlQ29udGV4dFNjb3BlLCBcImNyZWF0ZUNvbnRleHRTY29wZVwiKTtcbmZ1bmN0aW9uIGNvbXBvc2VDb250ZXh0U2NvcGVzKC4uLnNjb3Blcykge1xuICBjb25zdCBiYXNlU2NvcGUgPSBzY29wZXNbMF07XG4gIGlmIChzY29wZXMubGVuZ3RoID09PSAxKSByZXR1cm4gYmFzZVNjb3BlO1xuICBjb25zdCBjcmVhdGVTY29wZSA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKCkgPT4ge1xuICAgIGNvbnN0IHNjb3BlSG9va3MgPSBzY29wZXMubWFwKChjcmVhdGVTY29wZTIpID0+ICh7XG4gICAgICB1c2VTY29wZTogY3JlYXRlU2NvcGUyKCksXG4gICAgICBzY29wZU5hbWU6IGNyZWF0ZVNjb3BlMi5zY29wZU5hbWVcbiAgICB9KSk7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gdXNlQ29tcG9zZWRTY29wZXMob3ZlcnJpZGVTY29wZXMpIHtcbiAgICAgIGNvbnN0IG5leHRTY29wZXMgPSBzY29wZUhvb2tzLnJlZHVjZSgobmV4dFNjb3BlczIsIHsgdXNlU2NvcGUsIHNjb3BlTmFtZSB9KSA9PiB7XG4gICAgICAgIGNvbnN0IHNjb3BlUHJvcHMgPSB1c2VTY29wZShvdmVycmlkZVNjb3Blcyk7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRTY29wZSA9IHNjb3BlUHJvcHNbYF9fc2NvcGUke3Njb3BlTmFtZX1gXTtcbiAgICAgICAgcmV0dXJuIHsgLi4ubmV4dFNjb3BlczIsIC4uLmN1cnJlbnRTY29wZSB9O1xuICAgICAgfSwge30pO1xuICAgICAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gKHsgW2BfX3Njb3BlJHtiYXNlU2NvcGUuc2NvcGVOYW1lfWBdOiBuZXh0U2NvcGVzIH0pLCBbbmV4dFNjb3Blc10pO1xuICAgIH0sIFwidXNlQ29tcG9zZWRTY29wZXNcIik7XG4gIH0sIFwiY3JlYXRlU2NvcGVcIik7XG4gIGNyZWF0ZVNjb3BlLnNjb3BlTmFtZSA9IGJhc2VTY29wZS5zY29wZU5hbWU7XG4gIHJldHVybiBjcmVhdGVTY29wZTtcbn1cbl9fbmFtZShjb21wb3NlQ29udGV4dFNjb3BlcywgXCJjb21wb3NlQ29udGV4dFNjb3Blc1wiKTtcbmV4cG9ydCB7XG4gIGNyZWF0ZUNvbnRleHQyIGFzIGNyZWF0ZUNvbnRleHQsXG4gIGNyZWF0ZUNvbnRleHRTY29wZVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXBcbiIsIi8vIHNyYy91c2UtbGF5b3V0LWVmZmVjdC50c3hcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xudmFyIHVzZUxheW91dEVmZmVjdDIgPSBnbG9iYWxUaGlzPy5kb2N1bWVudCA/IFJlYWN0LnVzZUxheW91dEVmZmVjdCA6ICgpID0+IHtcbn07XG5leHBvcnQge1xuICB1c2VMYXlvdXRFZmZlY3QyIGFzIHVzZUxheW91dEVmZmVjdFxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXBcbiIsInZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy9pZC50c3hcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlTGF5b3V0RWZmZWN0IH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC11c2UtbGF5b3V0LWVmZmVjdFwiO1xudmFyIHVzZVJlYWN0SWQgPSBSZWFjdFtcIiB1c2VJZCBcIi50cmltKCkudG9TdHJpbmcoKV0gfHwgKCgpID0+IHZvaWQgMCk7XG52YXIgY291bnQgPSAwO1xuZnVuY3Rpb24gdXNlSWQoZGV0ZXJtaW5pc3RpY0lkKSB7XG4gIGNvbnN0IFtpZCwgc2V0SWRdID0gUmVhY3QudXNlU3RhdGUodXNlUmVhY3RJZCgpKTtcbiAgdXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWRldGVybWluaXN0aWNJZCkgc2V0SWQoKHJlYWN0SWQpID0+IHJlYWN0SWQgPz8gU3RyaW5nKGNvdW50KyspKTtcbiAgfSwgW2RldGVybWluaXN0aWNJZF0pO1xuICByZXR1cm4gZGV0ZXJtaW5pc3RpY0lkIHx8IChpZCA/IGByYWRpeC0ke2lkfWAgOiBcIlwiKTtcbn1cbl9fbmFtZSh1c2VJZCwgXCJ1c2VJZFwiKTtcbmV4cG9ydCB7XG4gIHVzZUlkXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcFxuIiwidmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX25hbWUgPSAodGFyZ2V0LCB2YWx1ZSkgPT4gX19kZWZQcm9wKHRhcmdldCwgXCJuYW1lXCIsIHsgdmFsdWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSB9KTtcblxuLy8gc3JjL3VzZS1lZmZlY3QtZXZlbnQudHN4XG5pbXBvcnQgeyB1c2VMYXlvdXRFZmZlY3QgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXVzZS1sYXlvdXQtZWZmZWN0XCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbnZhciB1c2VSZWFjdEVmZmVjdEV2ZW50ID0gUmVhY3RbXCIgdXNlRWZmZWN0RXZlbnQgXCIudHJpbSgpLnRvU3RyaW5nKCldO1xudmFyIHVzZVJlYWN0SW5zZXJ0aW9uRWZmZWN0ID0gUmVhY3RbXCIgdXNlSW5zZXJ0aW9uRWZmZWN0IFwiLnRyaW0oKS50b1N0cmluZygpXTtcbmZ1bmN0aW9uIHVzZUVmZmVjdEV2ZW50KGNhbGxiYWNrKSB7XG4gIGlmICh0eXBlb2YgdXNlUmVhY3RFZmZlY3RFdmVudCA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgcmV0dXJuIHVzZVJlYWN0RWZmZWN0RXZlbnQoY2FsbGJhY2spO1xuICB9XG4gIGNvbnN0IHJlZiA9IFJlYWN0LnVzZVJlZigoKSA9PiB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGNhbGwgYW4gZXZlbnQgaGFuZGxlciB3aGlsZSByZW5kZXJpbmcuXCIpO1xuICB9KTtcbiAgaWYgKHR5cGVvZiB1c2VSZWFjdEluc2VydGlvbkVmZmVjdCA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgdXNlUmVhY3RJbnNlcnRpb25FZmZlY3QoKCkgPT4ge1xuICAgICAgcmVmLmN1cnJlbnQgPSBjYWxsYmFjaztcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICB1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgcmVmLmN1cnJlbnQgPSBjYWxsYmFjaztcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiAoKC4uLmFyZ3MpID0+IHJlZi5jdXJyZW50Py4oLi4uYXJncykpLCBbXSk7XG59XG5fX25hbWUodXNlRWZmZWN0RXZlbnQsIFwidXNlRWZmZWN0RXZlbnRcIik7XG5leHBvcnQge1xuICB1c2VFZmZlY3RFdmVudFxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXBcbiIsInZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy91c2UtY29udHJvbGxhYmxlLXN0YXRlLnRzeFxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBJU19ERVZFTE9QTUVOVCB9IGZyb20gXCJAcmFkaXgtdWkvcHJpbWl0aXZlL2lzLWRldmVsb3BtZW50XCI7XG5pbXBvcnQgeyB1c2VMYXlvdXRFZmZlY3QgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXVzZS1sYXlvdXQtZWZmZWN0XCI7XG52YXIgdXNlSW5zZXJ0aW9uRWZmZWN0ID0gUmVhY3RbXCIgdXNlSW5zZXJ0aW9uRWZmZWN0IFwiLnRyaW0oKS50b1N0cmluZygpXSB8fCB1c2VMYXlvdXRFZmZlY3Q7XG5mdW5jdGlvbiB1c2VDb250cm9sbGFibGVTdGF0ZSh7XG4gIHByb3AsXG4gIGRlZmF1bHRQcm9wLFxuICBvbkNoYW5nZSA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKCkgPT4ge1xuICB9LCBcIm9uQ2hhbmdlXCIpLFxuICBjYWxsZXJcbn0pIHtcbiAgY29uc3QgW3VuY29udHJvbGxlZFByb3AsIHNldFVuY29udHJvbGxlZFByb3AsIG9uQ2hhbmdlUmVmXSA9IHVzZVVuY29udHJvbGxlZFN0YXRlKHtcbiAgICBkZWZhdWx0UHJvcCxcbiAgICBvbkNoYW5nZVxuICB9KTtcbiAgY29uc3QgaXNDb250cm9sbGVkID0gcHJvcCAhPT0gdm9pZCAwO1xuICBjb25zdCB2YWx1ZSA9IGlzQ29udHJvbGxlZCA/IHByb3AgOiB1bmNvbnRyb2xsZWRQcm9wO1xuICBpZiAoSVNfREVWRUxPUE1FTlQpIHtcbiAgICBjb25zdCBpc0NvbnRyb2xsZWRSZWYgPSBSZWFjdC51c2VSZWYocHJvcCAhPT0gdm9pZCAwKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgY29uc3Qgd2FzQ29udHJvbGxlZCA9IGlzQ29udHJvbGxlZFJlZi5jdXJyZW50O1xuICAgICAgaWYgKHdhc0NvbnRyb2xsZWQgIT09IGlzQ29udHJvbGxlZCkge1xuICAgICAgICBjb25zdCBmcm9tID0gd2FzQ29udHJvbGxlZCA/IFwiY29udHJvbGxlZFwiIDogXCJ1bmNvbnRyb2xsZWRcIjtcbiAgICAgICAgY29uc3QgdG8gPSBpc0NvbnRyb2xsZWQgPyBcImNvbnRyb2xsZWRcIiA6IFwidW5jb250cm9sbGVkXCI7XG4gICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICBgJHtjYWxsZXJ9IGlzIGNoYW5naW5nIGZyb20gJHtmcm9tfSB0byAke3RvfS4gQ29tcG9uZW50cyBzaG91bGQgbm90IHN3aXRjaCBmcm9tIGNvbnRyb2xsZWQgdG8gdW5jb250cm9sbGVkIChvciB2aWNlIHZlcnNhKS4gRGVjaWRlIGJldHdlZW4gdXNpbmcgYSBjb250cm9sbGVkIG9yIHVuY29udHJvbGxlZCB2YWx1ZSBmb3IgdGhlIGxpZmV0aW1lIG9mIHRoZSBjb21wb25lbnQuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgaXNDb250cm9sbGVkUmVmLmN1cnJlbnQgPSBpc0NvbnRyb2xsZWQ7XG4gICAgfSwgW2lzQ29udHJvbGxlZCwgY2FsbGVyXSk7XG4gIH1cbiAgY29uc3Qgc2V0VmFsdWUgPSBSZWFjdC51c2VDYWxsYmFjayhcbiAgICAobmV4dFZhbHVlKSA9PiB7XG4gICAgICBpZiAoaXNDb250cm9sbGVkKSB7XG4gICAgICAgIGNvbnN0IHZhbHVlMiA9IGlzRnVuY3Rpb24obmV4dFZhbHVlKSA/IG5leHRWYWx1ZShwcm9wKSA6IG5leHRWYWx1ZTtcbiAgICAgICAgaWYgKHZhbHVlMiAhPT0gcHJvcCkge1xuICAgICAgICAgIG9uQ2hhbmdlUmVmLmN1cnJlbnQ/Lih2YWx1ZTIpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRVbmNvbnRyb2xsZWRQcm9wKG5leHRWYWx1ZSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBbaXNDb250cm9sbGVkLCBwcm9wLCBzZXRVbmNvbnRyb2xsZWRQcm9wLCBvbkNoYW5nZVJlZl1cbiAgKTtcbiAgcmV0dXJuIFt2YWx1ZSwgc2V0VmFsdWVdO1xufVxuX19uYW1lKHVzZUNvbnRyb2xsYWJsZVN0YXRlLCBcInVzZUNvbnRyb2xsYWJsZVN0YXRlXCIpO1xuZnVuY3Rpb24gdXNlVW5jb250cm9sbGVkU3RhdGUoe1xuICBkZWZhdWx0UHJvcCxcbiAgb25DaGFuZ2Vcbn0pIHtcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSBSZWFjdC51c2VTdGF0ZShkZWZhdWx0UHJvcCk7XG4gIGNvbnN0IHByZXZWYWx1ZVJlZiA9IFJlYWN0LnVzZVJlZih2YWx1ZSk7XG4gIGNvbnN0IG9uQ2hhbmdlUmVmID0gUmVhY3QudXNlUmVmKG9uQ2hhbmdlKTtcbiAgdXNlSW5zZXJ0aW9uRWZmZWN0KCgpID0+IHtcbiAgICBvbkNoYW5nZVJlZi5jdXJyZW50ID0gb25DaGFuZ2U7XG4gIH0sIFtvbkNoYW5nZV0pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChwcmV2VmFsdWVSZWYuY3VycmVudCAhPT0gdmFsdWUpIHtcbiAgICAgIG9uQ2hhbmdlUmVmLmN1cnJlbnQ/Lih2YWx1ZSk7XG4gICAgICBwcmV2VmFsdWVSZWYuY3VycmVudCA9IHZhbHVlO1xuICAgIH1cbiAgfSwgW3ZhbHVlLCBwcmV2VmFsdWVSZWZdKTtcbiAgcmV0dXJuIFt2YWx1ZSwgc2V0VmFsdWUsIG9uQ2hhbmdlUmVmXTtcbn1cbl9fbmFtZSh1c2VVbmNvbnRyb2xsZWRTdGF0ZSwgXCJ1c2VVbmNvbnRyb2xsZWRTdGF0ZVwiKTtcbmZ1bmN0aW9uIGlzRnVuY3Rpb24odmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiO1xufVxuX19uYW1lKGlzRnVuY3Rpb24sIFwiaXNGdW5jdGlvblwiKTtcblxuLy8gc3JjL3VzZS1jb250cm9sbGFibGUtc3RhdGUtcmVkdWNlci50c3hcbmltcG9ydCAqIGFzIFJlYWN0MiBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IElTX0RFVkVMT1BNRU5UIGFzIElTX0RFVkVMT1BNRU5UMiB9IGZyb20gXCJAcmFkaXgtdWkvcHJpbWl0aXZlL2lzLWRldmVsb3BtZW50XCI7XG5pbXBvcnQgeyB1c2VFZmZlY3RFdmVudCB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtdXNlLWVmZmVjdC1ldmVudFwiO1xudmFyIFNZTkNfU1RBVEUgPSBTeW1ib2woXCJSQURJWDpTWU5DX1NUQVRFXCIpO1xuZnVuY3Rpb24gdXNlQ29udHJvbGxhYmxlU3RhdGVSZWR1Y2VyKHJlZHVjZXIsIHVzZXJBcmdzLCBpbml0aWFsQXJnLCBpbml0KSB7XG4gIGNvbnN0IHsgcHJvcDogY29udHJvbGxlZFN0YXRlLCBkZWZhdWx0UHJvcCwgb25DaGFuZ2U6IG9uQ2hhbmdlUHJvcCwgY2FsbGVyIH0gPSB1c2VyQXJncztcbiAgY29uc3QgaXNDb250cm9sbGVkID0gY29udHJvbGxlZFN0YXRlICE9PSB2b2lkIDA7XG4gIGNvbnN0IG9uQ2hhbmdlID0gdXNlRWZmZWN0RXZlbnQob25DaGFuZ2VQcm9wKTtcbiAgaWYgKElTX0RFVkVMT1BNRU5UMikge1xuICAgIGNvbnN0IGlzQ29udHJvbGxlZFJlZiA9IFJlYWN0Mi51c2VSZWYoY29udHJvbGxlZFN0YXRlICE9PSB2b2lkIDApO1xuICAgIFJlYWN0Mi51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgY29uc3Qgd2FzQ29udHJvbGxlZCA9IGlzQ29udHJvbGxlZFJlZi5jdXJyZW50O1xuICAgICAgaWYgKHdhc0NvbnRyb2xsZWQgIT09IGlzQ29udHJvbGxlZCkge1xuICAgICAgICBjb25zdCBmcm9tID0gd2FzQ29udHJvbGxlZCA/IFwiY29udHJvbGxlZFwiIDogXCJ1bmNvbnRyb2xsZWRcIjtcbiAgICAgICAgY29uc3QgdG8gPSBpc0NvbnRyb2xsZWQgPyBcImNvbnRyb2xsZWRcIiA6IFwidW5jb250cm9sbGVkXCI7XG4gICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICBgJHtjYWxsZXJ9IGlzIGNoYW5naW5nIGZyb20gJHtmcm9tfSB0byAke3RvfS4gQ29tcG9uZW50cyBzaG91bGQgbm90IHN3aXRjaCBmcm9tIGNvbnRyb2xsZWQgdG8gdW5jb250cm9sbGVkIChvciB2aWNlIHZlcnNhKS4gRGVjaWRlIGJldHdlZW4gdXNpbmcgYSBjb250cm9sbGVkIG9yIHVuY29udHJvbGxlZCB2YWx1ZSBmb3IgdGhlIGxpZmV0aW1lIG9mIHRoZSBjb21wb25lbnQuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgaXNDb250cm9sbGVkUmVmLmN1cnJlbnQgPSBpc0NvbnRyb2xsZWQ7XG4gICAgfSwgW2lzQ29udHJvbGxlZCwgY2FsbGVyXSk7XG4gIH1cbiAgY29uc3QgYXJncyA9IFt7IC4uLmluaXRpYWxBcmcsIHN0YXRlOiBkZWZhdWx0UHJvcCB9XTtcbiAgaWYgKGluaXQpIHtcbiAgICBhcmdzLnB1c2goaW5pdCk7XG4gIH1cbiAgY29uc3QgW2ludGVybmFsU3RhdGUsIGRpc3BhdGNoXSA9IFJlYWN0Mi51c2VSZWR1Y2VyKFxuICAgIChzdGF0ZTIsIGFjdGlvbikgPT4ge1xuICAgICAgaWYgKGFjdGlvbi50eXBlID09PSBTWU5DX1NUQVRFKSB7XG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlMiwgc3RhdGU6IGFjdGlvbi5zdGF0ZSB9O1xuICAgICAgfVxuICAgICAgY29uc3QgbmV4dCA9IHJlZHVjZXIoc3RhdGUyLCBhY3Rpb24pO1xuICAgICAgaWYgKGlzQ29udHJvbGxlZCAmJiAhT2JqZWN0LmlzKG5leHQuc3RhdGUsIHN0YXRlMi5zdGF0ZSkpIHtcbiAgICAgICAgb25DaGFuZ2UobmV4dC5zdGF0ZSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gbmV4dDtcbiAgICB9LFxuICAgIC4uLmFyZ3NcbiAgKTtcbiAgY29uc3QgdW5jb250cm9sbGVkU3RhdGUgPSBpbnRlcm5hbFN0YXRlLnN0YXRlO1xuICBjb25zdCBwcmV2VmFsdWVSZWYgPSBSZWFjdDIudXNlUmVmKHVuY29udHJvbGxlZFN0YXRlKTtcbiAgUmVhY3QyLnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHByZXZWYWx1ZVJlZi5jdXJyZW50ICE9PSB1bmNvbnRyb2xsZWRTdGF0ZSkge1xuICAgICAgcHJldlZhbHVlUmVmLmN1cnJlbnQgPSB1bmNvbnRyb2xsZWRTdGF0ZTtcbiAgICAgIGlmICghaXNDb250cm9sbGVkKSB7XG4gICAgICAgIG9uQ2hhbmdlKHVuY29udHJvbGxlZFN0YXRlKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIFt1bmNvbnRyb2xsZWRTdGF0ZSwgcHJldlZhbHVlUmVmLCBpc0NvbnRyb2xsZWRdKTtcbiAgY29uc3Qgc3RhdGUgPSBSZWFjdDIudXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3QgaXNDb250cm9sbGVkMiA9IGNvbnRyb2xsZWRTdGF0ZSAhPT0gdm9pZCAwO1xuICAgIGlmIChpc0NvbnRyb2xsZWQyKSB7XG4gICAgICByZXR1cm4geyAuLi5pbnRlcm5hbFN0YXRlLCBzdGF0ZTogY29udHJvbGxlZFN0YXRlIH07XG4gICAgfVxuICAgIHJldHVybiBpbnRlcm5hbFN0YXRlO1xuICB9LCBbaW50ZXJuYWxTdGF0ZSwgY29udHJvbGxlZFN0YXRlXSk7XG4gIFJlYWN0Mi51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc0NvbnRyb2xsZWQgJiYgIU9iamVjdC5pcyhjb250cm9sbGVkU3RhdGUsIGludGVybmFsU3RhdGUuc3RhdGUpKSB7XG4gICAgICBkaXNwYXRjaCh7IHR5cGU6IFNZTkNfU1RBVEUsIHN0YXRlOiBjb250cm9sbGVkU3RhdGUgfSk7XG4gICAgfVxuICB9LCBbY29udHJvbGxlZFN0YXRlLCBpbnRlcm5hbFN0YXRlLnN0YXRlLCBpc0NvbnRyb2xsZWRdKTtcbiAgcmV0dXJuIFtzdGF0ZSwgZGlzcGF0Y2hdO1xufVxuX19uYW1lKHVzZUNvbnRyb2xsYWJsZVN0YXRlUmVkdWNlciwgXCJ1c2VDb250cm9sbGFibGVTdGF0ZVJlZHVjZXJcIik7XG5leHBvcnQge1xuICB1c2VDb250cm9sbGFibGVTdGF0ZSxcbiAgdXNlQ29udHJvbGxhYmxlU3RhdGVSZWR1Y2VyXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcFxuIiwidmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX25hbWUgPSAodGFyZ2V0LCB2YWx1ZSkgPT4gX19kZWZQcm9wKHRhcmdldCwgXCJuYW1lXCIsIHsgdmFsdWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSB9KTtcblxuLy8gc3JjL3VzZS1jYWxsYmFjay1yZWYudHN4XG5pbXBvcnQgeyB1c2VMYXlvdXRFZmZlY3QgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXVzZS1sYXlvdXQtZWZmZWN0XCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbnZhciB1c2VSZWFjdEluc2VydGlvbkVmZmVjdCA9IFJlYWN0W1wiIHVzZUluc2VydGlvbkVmZmVjdCBcIi50cmltKCkudG9TdHJpbmcoKV07XG5mdW5jdGlvbiB1c2VDYWxsYmFja1JlZihjYWxsYmFjaykge1xuICBjb25zdCBjYWxsYmFja1JlZiA9IFJlYWN0LnVzZVJlZihjYWxsYmFjayk7XG4gIGlmICh0eXBlb2YgdXNlUmVhY3RJbnNlcnRpb25FZmZlY3QgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIHVzZVJlYWN0SW5zZXJ0aW9uRWZmZWN0KCgpID0+IHtcbiAgICAgIGNhbGxiYWNrUmVmLmN1cnJlbnQgPSBjYWxsYmFjaztcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICB1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgY2FsbGJhY2tSZWYuY3VycmVudCA9IGNhbGxiYWNrO1xuICAgIH0pO1xuICB9XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+ICgoLi4uYXJncykgPT4gY2FsbGJhY2tSZWYuY3VycmVudD8uKC4uLmFyZ3MpKSwgW10pO1xufVxuX19uYW1lKHVzZUNhbGxiYWNrUmVmLCBcInVzZUNhbGxiYWNrUmVmXCIpO1xuZXhwb3J0IHtcbiAgdXNlQ2FsbGJhY2tSZWZcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tanMubWFwXG4iLCJcInVzZSBjbGllbnRcIjtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy9kaXNtaXNzYWJsZS1sYXllci50c3hcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY29tcG9zZUV2ZW50SGFuZGxlcnMgfSBmcm9tIFwiQHJhZGl4LXVpL3ByaW1pdGl2ZVwiO1xuaW1wb3J0IHsgUHJpbWl0aXZlLCBkaXNwYXRjaERpc2NyZXRlQ3VzdG9tRXZlbnQgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXByaW1pdGl2ZVwiO1xuaW1wb3J0IHsgdXNlQ29tcG9zZWRSZWZzIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1jb21wb3NlLXJlZnNcIjtcbmltcG9ydCB7IHVzZUNhbGxiYWNrUmVmIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC11c2UtY2FsbGJhY2stcmVmXCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbnZhciBDT05URVhUX1VQREFURSA9IFwiZGlzbWlzc2FibGVMYXllci51cGRhdGVcIjtcbnZhciBQT0lOVEVSX0RPV05fT1VUU0lERSA9IFwiZGlzbWlzc2FibGVMYXllci5wb2ludGVyRG93bk91dHNpZGVcIjtcbnZhciBGT0NVU19PVVRTSURFID0gXCJkaXNtaXNzYWJsZUxheWVyLmZvY3VzT3V0c2lkZVwiO1xudmFyIG9yaWdpbmFsQm9keVBvaW50ZXJFdmVudHM7XG52YXIgRGlzbWlzc2FibGVMYXllckNvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KHtcbiAgbGF5ZXJzOiAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpLFxuICBsYXllcnNXaXRoT3V0c2lkZVBvaW50ZXJFdmVudHNEaXNhYmxlZDogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSxcbiAgYnJhbmNoZXM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG4gIC8vIE91dHNpZGUgZWxlbWVudHMgdGhhdCBiZWxvbmcgdG8gYSBsYXllcidzIG93biBkaXNtaXNzIGFmZm9yZGFuY2UgKGVnLCBhXG4gIC8vIGRpYWxvZyBvdmVybGF5KS4gUHJlc3NpbmcgdGhlbSBzaG91bGQgZGlzbWlzcyB0aGUgbGF5ZXIgcmVnYXJkbGVzcyBvZlxuICAvLyB3aGV0aGVyIG9yIG5vdCB0aGV5IHN0b3AgcHJvcGFnYXRpb24uXG4gIC8vXG4gIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vcmFkaXgtdWkvcHJpbWl0aXZlcy9pc3N1ZXMvMzM0NlxuICBkaXNtaXNzYWJsZVN1cmZhY2VzOiAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpXG59KTtcbnZhciBEaXNtaXNzYWJsZUxheWVyID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8vIGJsYW5rIGxpbmUgdG8gcmVkdWNlIGRpZmYgbm9pc2VcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBEaXNtaXNzYWJsZUxheWVyMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3Qge1xuICAgICAgZGlzYWJsZU91dHNpZGVQb2ludGVyRXZlbnRzID0gZmFsc2UsXG4gICAgICBkZWZlclBvaW50ZXJEb3duT3V0c2lkZSA9IGZhbHNlLFxuICAgICAgb25Fc2NhcGVLZXlEb3duLFxuICAgICAgb25Qb2ludGVyRG93bk91dHNpZGUsXG4gICAgICBvbkZvY3VzT3V0c2lkZSxcbiAgICAgIG9uSW50ZXJhY3RPdXRzaWRlLFxuICAgICAgb25EaXNtaXNzLFxuICAgICAgLi4ubGF5ZXJQcm9wc1xuICAgIH0gPSBwcm9wcztcbiAgICBjb25zdCBjb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChEaXNtaXNzYWJsZUxheWVyQ29udGV4dCk7XG4gICAgY29uc3QgW25vZGUsIHNldE5vZGVdID0gUmVhY3QudXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3Qgb3duZXJEb2N1bWVudCA9IG5vZGU/Lm93bmVyRG9jdW1lbnQgPz8gZ2xvYmFsVGhpcz8uZG9jdW1lbnQ7XG4gICAgY29uc3QgWywgZm9yY2VdID0gUmVhY3QudXNlU3RhdGUoe30pO1xuICAgIGNvbnN0IGNvbXBvc2VkUmVmcyA9IHVzZUNvbXBvc2VkUmVmcyhmb3J3YXJkZWRSZWYsIHNldE5vZGUpO1xuICAgIGNvbnN0IGxheWVycyA9IEFycmF5LmZyb20oY29udGV4dC5sYXllcnMpO1xuICAgIGNvbnN0IFtoaWdoZXN0TGF5ZXJXaXRoT3V0c2lkZVBvaW50ZXJFdmVudHNEaXNhYmxlZF0gPSBbXG4gICAgICAuLi5jb250ZXh0LmxheWVyc1dpdGhPdXRzaWRlUG9pbnRlckV2ZW50c0Rpc2FibGVkXG4gICAgXS5zbGljZSgtMSk7XG4gICAgY29uc3QgaGlnaGVzdExheWVyV2l0aE91dHNpZGVQb2ludGVyRXZlbnRzRGlzYWJsZWRJbmRleCA9IGhpZ2hlc3RMYXllcldpdGhPdXRzaWRlUG9pbnRlckV2ZW50c0Rpc2FibGVkID8gbGF5ZXJzLmluZGV4T2YoaGlnaGVzdExheWVyV2l0aE91dHNpZGVQb2ludGVyRXZlbnRzRGlzYWJsZWQpIDogLTE7XG4gICAgY29uc3QgaW5kZXggPSBub2RlID8gbGF5ZXJzLmluZGV4T2Yobm9kZSkgOiAtMTtcbiAgICBjb25zdCBpc0JvZHlQb2ludGVyRXZlbnRzRGlzYWJsZWQgPSBjb250ZXh0LmxheWVyc1dpdGhPdXRzaWRlUG9pbnRlckV2ZW50c0Rpc2FibGVkLnNpemUgPiAwO1xuICAgIGNvbnN0IGlzUG9pbnRlckV2ZW50c0VuYWJsZWQgPSBpbmRleCA+PSBoaWdoZXN0TGF5ZXJXaXRoT3V0c2lkZVBvaW50ZXJFdmVudHNEaXNhYmxlZEluZGV4O1xuICAgIGNvbnN0IGlzRGVmZXJyZWRQb2ludGVyRG93bk91dHNpZGVSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IHBvaW50ZXJEb3duT3V0c2lkZSA9IHVzZVBvaW50ZXJEb3duT3V0c2lkZShcbiAgICAgIChldmVudCkgPT4ge1xuICAgICAgICBvblBvaW50ZXJEb3duT3V0c2lkZT8uKGV2ZW50KTtcbiAgICAgICAgb25JbnRlcmFjdE91dHNpZGU/LihldmVudCk7XG4gICAgICAgIGlmICghZXZlbnQuZGVmYXVsdFByZXZlbnRlZCkgb25EaXNtaXNzPy4oKTtcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG93bmVyRG9jdW1lbnQsXG4gICAgICAgIGRlZmVyUG9pbnRlckRvd25PdXRzaWRlLFxuICAgICAgICBpc0RlZmVycmVkUG9pbnRlckRvd25PdXRzaWRlUmVmLFxuICAgICAgICBkaXNtaXNzYWJsZVN1cmZhY2VzOiBjb250ZXh0LmRpc21pc3NhYmxlU3VyZmFjZXMsXG4gICAgICAgIHNob3VsZEhhbmRsZVBvaW50ZXJEb3duT3V0c2lkZTogUmVhY3QudXNlQ2FsbGJhY2soXG4gICAgICAgICAgKHRhcmdldCkgPT4ge1xuICAgICAgICAgICAgaWYgKCEodGFyZ2V0IGluc3RhbmNlb2YgTm9kZSkpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgaXNQb2ludGVyRG93bk9uQnJhbmNoID0gWy4uLmNvbnRleHQuYnJhbmNoZXNdLnNvbWUoXG4gICAgICAgICAgICAgIChicmFuY2gpID0+IGJyYW5jaC5jb250YWlucyh0YXJnZXQpXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgcmV0dXJuIGlzUG9pbnRlckV2ZW50c0VuYWJsZWQgJiYgIWlzUG9pbnRlckRvd25PbkJyYW5jaDtcbiAgICAgICAgICB9LFxuICAgICAgICAgIFtjb250ZXh0LmJyYW5jaGVzLCBpc1BvaW50ZXJFdmVudHNFbmFibGVkXVxuICAgICAgICApXG4gICAgICB9XG4gICAgKTtcbiAgICBjb25zdCBmb2N1c091dHNpZGUgPSB1c2VGb2N1c091dHNpZGUoKGV2ZW50KSA9PiB7XG4gICAgICBpZiAoZGVmZXJQb2ludGVyRG93bk91dHNpZGUgJiYgaXNEZWZlcnJlZFBvaW50ZXJEb3duT3V0c2lkZVJlZi5jdXJyZW50KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LnRhcmdldDtcbiAgICAgIGNvbnN0IGlzRm9jdXNJbkJyYW5jaCA9IFsuLi5jb250ZXh0LmJyYW5jaGVzXS5zb21lKChicmFuY2gpID0+IGJyYW5jaC5jb250YWlucyh0YXJnZXQpKTtcbiAgICAgIGlmIChpc0ZvY3VzSW5CcmFuY2gpIHJldHVybjtcbiAgICAgIG9uRm9jdXNPdXRzaWRlPy4oZXZlbnQpO1xuICAgICAgb25JbnRlcmFjdE91dHNpZGU/LihldmVudCk7XG4gICAgICBpZiAoIWV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIG9uRGlzbWlzcz8uKCk7XG4gICAgfSwgb3duZXJEb2N1bWVudCk7XG4gICAgY29uc3QgaXNIaWdoZXN0TGF5ZXIgPSBub2RlID8gaW5kZXggPT09IGxheWVycy5sZW5ndGggLSAxIDogZmFsc2U7XG4gICAgY29uc3QgaGFuZGxlS2V5RG93biA9IHVzZUNhbGxiYWNrUmVmKChldmVudCkgPT4ge1xuICAgICAgaWYgKGV2ZW50LmtleSAhPT0gXCJFc2NhcGVcIikge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBvbkVzY2FwZUtleURvd24/LihldmVudCk7XG4gICAgICBpZiAoIWV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQgJiYgb25EaXNtaXNzKSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIG9uRGlzbWlzcygpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBpZiAoIWlzSGlnaGVzdExheWVyKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIG93bmVyRG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgaGFuZGxlS2V5RG93biwgeyBjYXB0dXJlOiB0cnVlIH0pO1xuICAgICAgcmV0dXJuICgpID0+IG93bmVyRG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgaGFuZGxlS2V5RG93biwgeyBjYXB0dXJlOiB0cnVlIH0pO1xuICAgIH0sIFtvd25lckRvY3VtZW50LCBpc0hpZ2hlc3RMYXllciwgaGFuZGxlS2V5RG93bl0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBpZiAoIW5vZGUpIHJldHVybjtcbiAgICAgIGlmIChkaXNhYmxlT3V0c2lkZVBvaW50ZXJFdmVudHMpIHtcbiAgICAgICAgaWYgKGNvbnRleHQubGF5ZXJzV2l0aE91dHNpZGVQb2ludGVyRXZlbnRzRGlzYWJsZWQuc2l6ZSA9PT0gMCkge1xuICAgICAgICAgIG9yaWdpbmFsQm9keVBvaW50ZXJFdmVudHMgPSBvd25lckRvY3VtZW50LmJvZHkuc3R5bGUucG9pbnRlckV2ZW50cztcbiAgICAgICAgICBvd25lckRvY3VtZW50LmJvZHkuc3R5bGUucG9pbnRlckV2ZW50cyA9IFwibm9uZVwiO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRleHQubGF5ZXJzV2l0aE91dHNpZGVQb2ludGVyRXZlbnRzRGlzYWJsZWQuYWRkKG5vZGUpO1xuICAgICAgfVxuICAgICAgY29udGV4dC5sYXllcnMuYWRkKG5vZGUpO1xuICAgICAgZGlzcGF0Y2hVcGRhdGUoKTtcbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlT3V0c2lkZVBvaW50ZXJFdmVudHMpIHtcbiAgICAgICAgICBjb250ZXh0LmxheWVyc1dpdGhPdXRzaWRlUG9pbnRlckV2ZW50c0Rpc2FibGVkLmRlbGV0ZShub2RlKTtcbiAgICAgICAgICBpZiAoY29udGV4dC5sYXllcnNXaXRoT3V0c2lkZVBvaW50ZXJFdmVudHNEaXNhYmxlZC5zaXplID09PSAwKSB7XG4gICAgICAgICAgICBvd25lckRvY3VtZW50LmJvZHkuc3R5bGUucG9pbnRlckV2ZW50cyA9IG9yaWdpbmFsQm9keVBvaW50ZXJFdmVudHM7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH0sIFtub2RlLCBvd25lckRvY3VtZW50LCBkaXNhYmxlT3V0c2lkZVBvaW50ZXJFdmVudHMsIGNvbnRleHRdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgaWYgKCFub2RlKSByZXR1cm47XG4gICAgICAgIGNvbnRleHQubGF5ZXJzLmRlbGV0ZShub2RlKTtcbiAgICAgICAgY29udGV4dC5sYXllcnNXaXRoT3V0c2lkZVBvaW50ZXJFdmVudHNEaXNhYmxlZC5kZWxldGUobm9kZSk7XG4gICAgICAgIGRpc3BhdGNoVXBkYXRlKCk7XG4gICAgICB9O1xuICAgIH0sIFtub2RlLCBjb250ZXh0XSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKCkgPT4gZm9yY2Uoe30pLCBcImhhbmRsZVVwZGF0ZVwiKTtcbiAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoQ09OVEVYVF9VUERBVEUsIGhhbmRsZVVwZGF0ZSk7XG4gICAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihDT05URVhUX1VQREFURSwgaGFuZGxlVXBkYXRlKTtcbiAgICB9LCBbXSk7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICBQcmltaXRpdmUuZGl2LFxuICAgICAge1xuICAgICAgICAuLi5sYXllclByb3BzLFxuICAgICAgICByZWY6IGNvbXBvc2VkUmVmcyxcbiAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICBwb2ludGVyRXZlbnRzOiBpc0JvZHlQb2ludGVyRXZlbnRzRGlzYWJsZWQgPyBpc1BvaW50ZXJFdmVudHNFbmFibGVkID8gXCJhdXRvXCIgOiBcIm5vbmVcIiA6IHZvaWQgMCxcbiAgICAgICAgICAuLi5wcm9wcy5zdHlsZVxuICAgICAgICB9LFxuICAgICAgICBvbkZvY3VzQ2FwdHVyZTogY29tcG9zZUV2ZW50SGFuZGxlcnMocHJvcHMub25Gb2N1c0NhcHR1cmUsIGZvY3VzT3V0c2lkZS5vbkZvY3VzQ2FwdHVyZSksXG4gICAgICAgIG9uQmx1ckNhcHR1cmU6IGNvbXBvc2VFdmVudEhhbmRsZXJzKHByb3BzLm9uQmx1ckNhcHR1cmUsIGZvY3VzT3V0c2lkZS5vbkJsdXJDYXB0dXJlKSxcbiAgICAgICAgb25Qb2ludGVyRG93bkNhcHR1cmU6IGNvbXBvc2VFdmVudEhhbmRsZXJzKFxuICAgICAgICAgIHByb3BzLm9uUG9pbnRlckRvd25DYXB0dXJlLFxuICAgICAgICAgIHBvaW50ZXJEb3duT3V0c2lkZS5vblBvaW50ZXJEb3duQ2FwdHVyZVxuICAgICAgICApXG4gICAgICB9XG4gICAgKTtcbiAgfSwgXCJEaXNtaXNzYWJsZUxheWVyXCIpXG4pO1xudmFyIERpc21pc3NhYmxlTGF5ZXJCcmFuY2ggPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZigvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIERpc21pc3NhYmxlTGF5ZXJCcmFuY2gyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoRGlzbWlzc2FibGVMYXllckNvbnRleHQpO1xuICBjb25zdCByZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGNvbXBvc2VkUmVmcyA9IHVzZUNvbXBvc2VkUmVmcyhmb3J3YXJkZWRSZWYsIHJlZik7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgbm9kZSA9IHJlZi5jdXJyZW50O1xuICAgIGlmIChub2RlKSB7XG4gICAgICBjb250ZXh0LmJyYW5jaGVzLmFkZChub2RlKTtcbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIGNvbnRleHQuYnJhbmNoZXMuZGVsZXRlKG5vZGUpO1xuICAgICAgfTtcbiAgICB9XG4gIH0sIFtjb250ZXh0LmJyYW5jaGVzXSk7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFByaW1pdGl2ZS5kaXYsIHsgLi4ucHJvcHMsIHJlZjogY29tcG9zZWRSZWZzIH0pO1xufSwgXCJEaXNtaXNzYWJsZUxheWVyQnJhbmNoXCIpKTtcbmZ1bmN0aW9uIHVzZURpc21pc3NhYmxlTGF5ZXJTdXJmYWNlKCkge1xuICBjb25zdCBjb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChEaXNtaXNzYWJsZUxheWVyQ29udGV4dCk7XG4gIGNvbnN0IFtub2RlLCBzZXROb2RlXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghbm9kZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb250ZXh0LmRpc21pc3NhYmxlU3VyZmFjZXMuYWRkKG5vZGUpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjb250ZXh0LmRpc21pc3NhYmxlU3VyZmFjZXMuZGVsZXRlKG5vZGUpO1xuICAgIH07XG4gIH0sIFtub2RlLCBjb250ZXh0LmRpc21pc3NhYmxlU3VyZmFjZXNdKTtcbiAgcmV0dXJuIHNldE5vZGU7XG59XG5fX25hbWUodXNlRGlzbWlzc2FibGVMYXllclN1cmZhY2UsIFwidXNlRGlzbWlzc2FibGVMYXllclN1cmZhY2VcIik7XG52YXIgSVNfVFJVRSA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKCkgPT4gdHJ1ZSwgXCJJU19UUlVFXCIpO1xuZnVuY3Rpb24gdXNlUG9pbnRlckRvd25PdXRzaWRlKG9uUG9pbnRlckRvd25PdXRzaWRlLCBhcmdzKSB7XG4gIGNvbnN0IHtcbiAgICBvd25lckRvY3VtZW50ID0gZ2xvYmFsVGhpcz8uZG9jdW1lbnQsXG4gICAgZGVmZXJQb2ludGVyRG93bk91dHNpZGUgPSBmYWxzZSxcbiAgICBpc0RlZmVycmVkUG9pbnRlckRvd25PdXRzaWRlUmVmLFxuICAgIGRpc21pc3NhYmxlU3VyZmFjZXMsXG4gICAgc2hvdWxkSGFuZGxlUG9pbnRlckRvd25PdXRzaWRlID0gSVNfVFJVRVxuICB9ID0gYXJncztcbiAgY29uc3QgaGFuZGxlUG9pbnRlckRvd25PdXRzaWRlID0gdXNlQ2FsbGJhY2tSZWYob25Qb2ludGVyRG93bk91dHNpZGUpO1xuICBjb25zdCBpc1BvaW50ZXJJbnNpZGVSZWFjdFRyZWVSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBpc1BvaW50ZXJEb3duT3V0c2lkZVJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IGludGVyY2VwdGVkT3V0c2lkZUludGVyYWN0aW9uRXZlbnRzUmVmID0gUmVhY3QudXNlUmVmKC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpO1xuICBjb25zdCBoYW5kbGVDbGlja1JlZiA9IFJlYWN0LnVzZVJlZigoKSA9PiB7XG4gIH0pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGZ1bmN0aW9uIHJlc2V0T3V0c2lkZUludGVyYWN0aW9uKCkge1xuICAgICAgaXNQb2ludGVyRG93bk91dHNpZGVSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgaXNEZWZlcnJlZFBvaW50ZXJEb3duT3V0c2lkZVJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICBpbnRlcmNlcHRlZE91dHNpZGVJbnRlcmFjdGlvbkV2ZW50c1JlZi5jdXJyZW50LmNsZWFyKCk7XG4gICAgfVxuICAgIF9fbmFtZShyZXNldE91dHNpZGVJbnRlcmFjdGlvbiwgXCJyZXNldE91dHNpZGVJbnRlcmFjdGlvblwiKTtcbiAgICBmdW5jdGlvbiBpc091dHNpZGVJbnRlcmFjdGlvbkludGVyY2VwdGVkKCkge1xuICAgICAgcmV0dXJuIEFycmF5LmZyb20oaW50ZXJjZXB0ZWRPdXRzaWRlSW50ZXJhY3Rpb25FdmVudHNSZWYuY3VycmVudC52YWx1ZXMoKSkuc29tZShCb29sZWFuKTtcbiAgICB9XG4gICAgX19uYW1lKGlzT3V0c2lkZUludGVyYWN0aW9uSW50ZXJjZXB0ZWQsIFwiaXNPdXRzaWRlSW50ZXJhY3Rpb25JbnRlcmNlcHRlZFwiKTtcbiAgICBmdW5jdGlvbiBoYW5kbGVJbnRlcmFjdGlvbkNhcHR1cmUoZXZlbnQpIHtcbiAgICAgIGlmICghaXNQb2ludGVyRG93bk91dHNpZGVSZWYuY3VycmVudCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgICBjb25zdCBpc0Rpc21pc3NhYmxlU3VyZmFjZSA9IHRhcmdldCBpbnN0YW5jZW9mIE5vZGUgJiYgWy4uLmRpc21pc3NhYmxlU3VyZmFjZXNdLnNvbWUoKHN1cmZhY2UpID0+IHN1cmZhY2UuY29udGFpbnModGFyZ2V0KSk7XG4gICAgICBpZiAoIWlzRGlzbWlzc2FibGVTdXJmYWNlKSB7XG4gICAgICAgIGludGVyY2VwdGVkT3V0c2lkZUludGVyYWN0aW9uRXZlbnRzUmVmLmN1cnJlbnQuc2V0KGV2ZW50LnR5cGUsIHRydWUpO1xuICAgICAgfVxuICAgICAgaWYgKGV2ZW50LnR5cGUgPT09IFwiY2xpY2tcIikge1xuICAgICAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgaWYgKGlzUG9pbnRlckRvd25PdXRzaWRlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIGhhbmRsZUNsaWNrUmVmLmN1cnJlbnQoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sIDApO1xuICAgICAgfVxuICAgIH1cbiAgICBfX25hbWUoaGFuZGxlSW50ZXJhY3Rpb25DYXB0dXJlLCBcImhhbmRsZUludGVyYWN0aW9uQ2FwdHVyZVwiKTtcbiAgICBmdW5jdGlvbiBoYW5kbGVJbnRlcmFjdGlvbkJ1YmJsZShldmVudCkge1xuICAgICAgaWYgKGlzUG9pbnRlckRvd25PdXRzaWRlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgaW50ZXJjZXB0ZWRPdXRzaWRlSW50ZXJhY3Rpb25FdmVudHNSZWYuY3VycmVudC5zZXQoZXZlbnQudHlwZSwgZmFsc2UpO1xuICAgICAgfVxuICAgIH1cbiAgICBfX25hbWUoaGFuZGxlSW50ZXJhY3Rpb25CdWJibGUsIFwiaGFuZGxlSW50ZXJhY3Rpb25CdWJibGVcIik7XG4gICAgY29uc3QgaGFuZGxlUG9pbnRlckRvd24gPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKChldmVudCkgPT4ge1xuICAgICAgaWYgKGV2ZW50LnRhcmdldCAmJiAhaXNQb2ludGVySW5zaWRlUmVhY3RUcmVlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgbGV0IGhhbmRsZUFuZERpc3BhdGNoUG9pbnRlckRvd25PdXRzaWRlRXZlbnQyID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgb3duZXJEb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgaGFuZGxlQ2xpY2tSZWYuY3VycmVudCk7XG4gICAgICAgICAgY29uc3Qgd2FzT3V0c2lkZUludGVyYWN0aW9uSW50ZXJjZXB0ZWQgPSBpc091dHNpZGVJbnRlcmFjdGlvbkludGVyY2VwdGVkKCk7XG4gICAgICAgICAgcmVzZXRPdXRzaWRlSW50ZXJhY3Rpb24oKTtcbiAgICAgICAgICBpZiAoIXdhc091dHNpZGVJbnRlcmFjdGlvbkludGVyY2VwdGVkKSB7XG4gICAgICAgICAgICBoYW5kbGVBbmREaXNwYXRjaEN1c3RvbUV2ZW50KFxuICAgICAgICAgICAgICBQT0lOVEVSX0RPV05fT1VUU0lERSxcbiAgICAgICAgICAgICAgaGFuZGxlUG9pbnRlckRvd25PdXRzaWRlLFxuICAgICAgICAgICAgICBldmVudERldGFpbCxcbiAgICAgICAgICAgICAgeyBkaXNjcmV0ZTogdHJ1ZSB9XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgdmFyIGhhbmRsZUFuZERpc3BhdGNoUG9pbnRlckRvd25PdXRzaWRlRXZlbnQgPSBoYW5kbGVBbmREaXNwYXRjaFBvaW50ZXJEb3duT3V0c2lkZUV2ZW50MjtcbiAgICAgICAgX19uYW1lKGhhbmRsZUFuZERpc3BhdGNoUG9pbnRlckRvd25PdXRzaWRlRXZlbnQyLCBcImhhbmRsZUFuZERpc3BhdGNoUG9pbnRlckRvd25PdXRzaWRlRXZlbnRcIik7XG4gICAgICAgIGlmICghc2hvdWxkSGFuZGxlUG9pbnRlckRvd25PdXRzaWRlKGV2ZW50LnRhcmdldCkpIHtcbiAgICAgICAgICBvd25lckRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBoYW5kbGVDbGlja1JlZi5jdXJyZW50KTtcbiAgICAgICAgICByZXNldE91dHNpZGVJbnRlcmFjdGlvbigpO1xuICAgICAgICAgIGlzUG9pbnRlckluc2lkZVJlYWN0VHJlZVJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGV2ZW50RGV0YWlsID0geyBvcmlnaW5hbEV2ZW50OiBldmVudCB9O1xuICAgICAgICBpc1BvaW50ZXJEb3duT3V0c2lkZVJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgaXNEZWZlcnJlZFBvaW50ZXJEb3duT3V0c2lkZVJlZi5jdXJyZW50ID0gZGVmZXJQb2ludGVyRG93bk91dHNpZGUgJiYgZXZlbnQuYnV0dG9uID09PSAwO1xuICAgICAgICBpbnRlcmNlcHRlZE91dHNpZGVJbnRlcmFjdGlvbkV2ZW50c1JlZi5jdXJyZW50LmNsZWFyKCk7XG4gICAgICAgIGlmICghZGVmZXJQb2ludGVyRG93bk91dHNpZGUgfHwgZXZlbnQuYnV0dG9uICE9PSAwKSB7XG4gICAgICAgICAgaGFuZGxlQW5kRGlzcGF0Y2hQb2ludGVyRG93bk91dHNpZGVFdmVudDIoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBvd25lckRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBoYW5kbGVDbGlja1JlZi5jdXJyZW50KTtcbiAgICAgICAgICBoYW5kbGVDbGlja1JlZi5jdXJyZW50ID0gaGFuZGxlQW5kRGlzcGF0Y2hQb2ludGVyRG93bk91dHNpZGVFdmVudDI7XG4gICAgICAgICAgb3duZXJEb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgaGFuZGxlQ2xpY2tSZWYuY3VycmVudCwgeyBvbmNlOiB0cnVlIH0pO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBvd25lckRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBoYW5kbGVDbGlja1JlZi5jdXJyZW50KTtcbiAgICAgICAgcmVzZXRPdXRzaWRlSW50ZXJhY3Rpb24oKTtcbiAgICAgIH1cbiAgICAgIGlzUG9pbnRlckluc2lkZVJlYWN0VHJlZVJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgfSwgXCJoYW5kbGVQb2ludGVyRG93blwiKTtcbiAgICBjb25zdCBvdXRzaWRlSW50ZXJhY3Rpb25FdmVudHMgPSBbXG4gICAgICBcInBvaW50ZXJ1cFwiLFxuICAgICAgXCJtb3VzZWRvd25cIixcbiAgICAgIFwibW91c2V1cFwiLFxuICAgICAgXCJ0b3VjaHN0YXJ0XCIsXG4gICAgICBcInRvdWNoZW5kXCIsXG4gICAgICBcImNsaWNrXCJcbiAgICBdO1xuICAgIGZvciAoY29uc3QgZXZlbnROYW1lIG9mIG91dHNpZGVJbnRlcmFjdGlvbkV2ZW50cykge1xuICAgICAgb3duZXJEb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKGV2ZW50TmFtZSwgaGFuZGxlSW50ZXJhY3Rpb25DYXB0dXJlLCB0cnVlKTtcbiAgICAgIG93bmVyRG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihldmVudE5hbWUsIGhhbmRsZUludGVyYWN0aW9uQnViYmxlKTtcbiAgICB9XG4gICAgY29uc3QgdGltZXJJZCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIG93bmVyRG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJkb3duXCIsIGhhbmRsZVBvaW50ZXJEb3duKTtcbiAgICB9LCAwKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgd2luZG93LmNsZWFyVGltZW91dCh0aW1lcklkKTtcbiAgICAgIG93bmVyRG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJkb3duXCIsIGhhbmRsZVBvaW50ZXJEb3duKTtcbiAgICAgIG93bmVyRG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGhhbmRsZUNsaWNrUmVmLmN1cnJlbnQpO1xuICAgICAgZm9yIChjb25zdCBldmVudE5hbWUgb2Ygb3V0c2lkZUludGVyYWN0aW9uRXZlbnRzKSB7XG4gICAgICAgIG93bmVyRG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihldmVudE5hbWUsIGhhbmRsZUludGVyYWN0aW9uQ2FwdHVyZSwgdHJ1ZSk7XG4gICAgICAgIG93bmVyRG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihldmVudE5hbWUsIGhhbmRsZUludGVyYWN0aW9uQnViYmxlKTtcbiAgICAgIH1cbiAgICB9O1xuICB9LCBbXG4gICAgb3duZXJEb2N1bWVudCxcbiAgICBoYW5kbGVQb2ludGVyRG93bk91dHNpZGUsXG4gICAgZGVmZXJQb2ludGVyRG93bk91dHNpZGUsXG4gICAgaXNEZWZlcnJlZFBvaW50ZXJEb3duT3V0c2lkZVJlZixcbiAgICBkaXNtaXNzYWJsZVN1cmZhY2VzLFxuICAgIHNob3VsZEhhbmRsZVBvaW50ZXJEb3duT3V0c2lkZVxuICBdKTtcbiAgcmV0dXJuIHtcbiAgICAvLyBlbnN1cmVzIHdlIGNoZWNrIFJlYWN0IGNvbXBvbmVudCB0cmVlIChub3QganVzdCBET00gdHJlZSlcbiAgICBvblBvaW50ZXJEb3duQ2FwdHVyZTogLyogQF9fUFVSRV9fICovIF9fbmFtZSgoKSA9PiBpc1BvaW50ZXJJbnNpZGVSZWFjdFRyZWVSZWYuY3VycmVudCA9IHRydWUsIFwib25Qb2ludGVyRG93bkNhcHR1cmVcIilcbiAgfTtcbn1cbl9fbmFtZSh1c2VQb2ludGVyRG93bk91dHNpZGUsIFwidXNlUG9pbnRlckRvd25PdXRzaWRlXCIpO1xuZnVuY3Rpb24gdXNlRm9jdXNPdXRzaWRlKG9uRm9jdXNPdXRzaWRlLCBvd25lckRvY3VtZW50ID0gZ2xvYmFsVGhpcz8uZG9jdW1lbnQpIHtcbiAgY29uc3QgaGFuZGxlRm9jdXNPdXRzaWRlID0gdXNlQ2FsbGJhY2tSZWYob25Gb2N1c091dHNpZGUpO1xuICBjb25zdCBpc0ZvY3VzSW5zaWRlUmVhY3RUcmVlUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBoYW5kbGVGb2N1cyA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKGV2ZW50KSA9PiB7XG4gICAgICBpZiAoZXZlbnQudGFyZ2V0ICYmICFpc0ZvY3VzSW5zaWRlUmVhY3RUcmVlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgY29uc3QgZXZlbnREZXRhaWwgPSB7IG9yaWdpbmFsRXZlbnQ6IGV2ZW50IH07XG4gICAgICAgIGhhbmRsZUFuZERpc3BhdGNoQ3VzdG9tRXZlbnQoRk9DVVNfT1VUU0lERSwgaGFuZGxlRm9jdXNPdXRzaWRlLCBldmVudERldGFpbCwge1xuICAgICAgICAgIGRpc2NyZXRlOiBmYWxzZVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LCBcImhhbmRsZUZvY3VzXCIpO1xuICAgIG93bmVyRG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImZvY3VzaW5cIiwgaGFuZGxlRm9jdXMpO1xuICAgIHJldHVybiAoKSA9PiBvd25lckRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJmb2N1c2luXCIsIGhhbmRsZUZvY3VzKTtcbiAgfSwgW293bmVyRG9jdW1lbnQsIGhhbmRsZUZvY3VzT3V0c2lkZV0pO1xuICByZXR1cm4ge1xuICAgIG9uRm9jdXNDYXB0dXJlOiAvKiBAX19QVVJFX18gKi8gX19uYW1lKCgpID0+IGlzRm9jdXNJbnNpZGVSZWFjdFRyZWVSZWYuY3VycmVudCA9IHRydWUsIFwib25Gb2N1c0NhcHR1cmVcIiksXG4gICAgb25CbHVyQ2FwdHVyZTogLyogQF9fUFVSRV9fICovIF9fbmFtZSgoKSA9PiBpc0ZvY3VzSW5zaWRlUmVhY3RUcmVlUmVmLmN1cnJlbnQgPSBmYWxzZSwgXCJvbkJsdXJDYXB0dXJlXCIpXG4gIH07XG59XG5fX25hbWUodXNlRm9jdXNPdXRzaWRlLCBcInVzZUZvY3VzT3V0c2lkZVwiKTtcbmZ1bmN0aW9uIGRpc3BhdGNoVXBkYXRlKCkge1xuICBjb25zdCBldmVudCA9IG5ldyBDdXN0b21FdmVudChDT05URVhUX1VQREFURSk7XG4gIGRvY3VtZW50LmRpc3BhdGNoRXZlbnQoZXZlbnQpO1xufVxuX19uYW1lKGRpc3BhdGNoVXBkYXRlLCBcImRpc3BhdGNoVXBkYXRlXCIpO1xuZnVuY3Rpb24gaGFuZGxlQW5kRGlzcGF0Y2hDdXN0b21FdmVudChuYW1lLCBoYW5kbGVyLCBkZXRhaWwsIHsgZGlzY3JldGUgfSkge1xuICBjb25zdCB0YXJnZXQgPSBkZXRhaWwub3JpZ2luYWxFdmVudC50YXJnZXQ7XG4gIGNvbnN0IGV2ZW50ID0gbmV3IEN1c3RvbUV2ZW50KG5hbWUsIHsgYnViYmxlczogZmFsc2UsIGNhbmNlbGFibGU6IHRydWUsIGRldGFpbCB9KTtcbiAgaWYgKGhhbmRsZXIpIHRhcmdldC5hZGRFdmVudExpc3RlbmVyKG5hbWUsIGhhbmRsZXIsIHsgb25jZTogdHJ1ZSB9KTtcbiAgaWYgKGRpc2NyZXRlKSB7XG4gICAgZGlzcGF0Y2hEaXNjcmV0ZUN1c3RvbUV2ZW50KHRhcmdldCwgZXZlbnQpO1xuICB9IGVsc2Uge1xuICAgIHRhcmdldC5kaXNwYXRjaEV2ZW50KGV2ZW50KTtcbiAgfVxufVxuX19uYW1lKGhhbmRsZUFuZERpc3BhdGNoQ3VzdG9tRXZlbnQsIFwiaGFuZGxlQW5kRGlzcGF0Y2hDdXN0b21FdmVudFwiKTtcbmV4cG9ydCB7XG4gIERpc21pc3NhYmxlTGF5ZXJCcmFuY2ggYXMgQnJhbmNoLFxuICBEaXNtaXNzYWJsZUxheWVyLFxuICBEaXNtaXNzYWJsZUxheWVyQnJhbmNoLFxuICBEaXNtaXNzYWJsZUxheWVyIGFzIFJvb3QsXG4gIHVzZURpc21pc3NhYmxlTGF5ZXJTdXJmYWNlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcFxuIiwiXCJ1c2UgY2xpZW50XCI7XG52YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fbmFtZSA9ICh0YXJnZXQsIHZhbHVlKSA9PiBfX2RlZlByb3AodGFyZ2V0LCBcIm5hbWVcIiwgeyB2YWx1ZSwgY29uZmlndXJhYmxlOiB0cnVlIH0pO1xuXG4vLyBzcmMvZm9jdXMtc2NvcGUudHN4XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZUNvbXBvc2VkUmVmcyB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtY29tcG9zZS1yZWZzXCI7XG5pbXBvcnQgeyBQcmltaXRpdmUgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXByaW1pdGl2ZVwiO1xuaW1wb3J0IHsgdXNlQ2FsbGJhY2tSZWYgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXVzZS1jYWxsYmFjay1yZWZcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xudmFyIEFVVE9GT0NVU19PTl9NT1VOVCA9IFwiZm9jdXNTY29wZS5hdXRvRm9jdXNPbk1vdW50XCI7XG52YXIgQVVUT0ZPQ1VTX09OX1VOTU9VTlQgPSBcImZvY3VzU2NvcGUuYXV0b0ZvY3VzT25Vbm1vdW50XCI7XG52YXIgRVZFTlRfT1BUSU9OUyA9IHsgYnViYmxlczogZmFsc2UsIGNhbmNlbGFibGU6IHRydWUgfTtcbnZhciBGb2N1c1Njb3BlID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gRm9jdXNTY29wZTIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHtcbiAgICAgIGxvb3AgPSBmYWxzZSxcbiAgICAgIHRyYXBwZWQgPSBmYWxzZSxcbiAgICAgIGJyYW5jaGVzLFxuICAgICAgb25Nb3VudEF1dG9Gb2N1czogb25Nb3VudEF1dG9Gb2N1c1Byb3AsXG4gICAgICBvblVubW91bnRBdXRvRm9jdXM6IG9uVW5tb3VudEF1dG9Gb2N1c1Byb3AsXG4gICAgICAuLi5zY29wZVByb3BzXG4gICAgfSA9IHByb3BzO1xuICAgIGNvbnN0IFtjb250YWluZXIsIHNldENvbnRhaW5lcl0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBvbk1vdW50QXV0b0ZvY3VzID0gdXNlQ2FsbGJhY2tSZWYob25Nb3VudEF1dG9Gb2N1c1Byb3ApO1xuICAgIGNvbnN0IG9uVW5tb3VudEF1dG9Gb2N1cyA9IHVzZUNhbGxiYWNrUmVmKG9uVW5tb3VudEF1dG9Gb2N1c1Byb3ApO1xuICAgIGNvbnN0IGxhc3RGb2N1c2VkRWxlbWVudFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMoZm9yd2FyZGVkUmVmLCBzZXRDb250YWluZXIpO1xuICAgIGNvbnN0IGJyYW5jaGVzUmVmID0gUmVhY3QudXNlUmVmKGJyYW5jaGVzKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgYnJhbmNoZXNSZWYuY3VycmVudCA9IGJyYW5jaGVzO1xuICAgIH0pO1xuICAgIGNvbnN0IGlzVGFyZ2V0SW5TY29wZSA9IFJlYWN0LnVzZUNhbGxiYWNrKFxuICAgICAgKHRhcmdldCkgPT4ge1xuICAgICAgICBpZiAoIXRhcmdldCkgcmV0dXJuIGZhbHNlO1xuICAgICAgICBpZiAoY29udGFpbmVyPy5jb250YWlucyh0YXJnZXQpKSByZXR1cm4gdHJ1ZTtcbiAgICAgICAgcmV0dXJuIEJvb2xlYW4oYnJhbmNoZXNSZWYuY3VycmVudD8uc29tZSgoYnJhbmNoKSA9PiBicmFuY2guY29udGFpbnModGFyZ2V0KSkpO1xuICAgICAgfSxcbiAgICAgIFtjb250YWluZXJdXG4gICAgKTtcbiAgICBjb25zdCBmb2N1c1Njb3BlID0gUmVhY3QudXNlUmVmKHtcbiAgICAgIHBhdXNlZDogZmFsc2UsXG4gICAgICBwYXVzZSgpIHtcbiAgICAgICAgdGhpcy5wYXVzZWQgPSB0cnVlO1xuICAgICAgfSxcbiAgICAgIHJlc3VtZSgpIHtcbiAgICAgICAgdGhpcy5wYXVzZWQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9KS5jdXJyZW50O1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBpZiAodHJhcHBlZCkge1xuICAgICAgICBsZXQgaGFuZGxlRm9jdXNJbjIgPSBmdW5jdGlvbihldmVudCkge1xuICAgICAgICAgIGlmIChmb2N1c1Njb3BlLnBhdXNlZCB8fCAhY29udGFpbmVyKSByZXR1cm47XG4gICAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQudGFyZ2V0O1xuICAgICAgICAgIGlmIChpc1RhcmdldEluU2NvcGUodGFyZ2V0KSkge1xuICAgICAgICAgICAgbGFzdEZvY3VzZWRFbGVtZW50UmVmLmN1cnJlbnQgPSB0YXJnZXQ7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGZvY3VzKGxhc3RGb2N1c2VkRWxlbWVudFJlZi5jdXJyZW50LCB7IHNlbGVjdDogdHJ1ZSB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sIGhhbmRsZUZvY3VzT3V0MiA9IGZ1bmN0aW9uKGV2ZW50KSB7XG4gICAgICAgICAgaWYgKGZvY3VzU2NvcGUucGF1c2VkIHx8ICFjb250YWluZXIpIHJldHVybjtcbiAgICAgICAgICBjb25zdCByZWxhdGVkVGFyZ2V0ID0gZXZlbnQucmVsYXRlZFRhcmdldDtcbiAgICAgICAgICBpZiAocmVsYXRlZFRhcmdldCA9PT0gbnVsbCkgcmV0dXJuO1xuICAgICAgICAgIGlmICghaXNUYXJnZXRJblNjb3BlKHJlbGF0ZWRUYXJnZXQpKSB7XG4gICAgICAgICAgICBmb2N1cyhsYXN0Rm9jdXNlZEVsZW1lbnRSZWYuY3VycmVudCwgeyBzZWxlY3Q6IHRydWUgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9LCBoYW5kbGVNdXRhdGlvbnMyID0gZnVuY3Rpb24obXV0YXRpb25zKSB7XG4gICAgICAgICAgY29uc3QgZm9jdXNlZEVsZW1lbnQgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50O1xuICAgICAgICAgIGlmIChmb2N1c2VkRWxlbWVudCAhPT0gZG9jdW1lbnQuYm9keSkgcmV0dXJuO1xuICAgICAgICAgIGZvciAoY29uc3QgbXV0YXRpb24gb2YgbXV0YXRpb25zKSB7XG4gICAgICAgICAgICBpZiAobXV0YXRpb24ucmVtb3ZlZE5vZGVzLmxlbmd0aCA+IDApIGZvY3VzKGNvbnRhaW5lcik7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB2YXIgaGFuZGxlRm9jdXNJbiA9IGhhbmRsZUZvY3VzSW4yLCBoYW5kbGVGb2N1c091dCA9IGhhbmRsZUZvY3VzT3V0MiwgaGFuZGxlTXV0YXRpb25zID0gaGFuZGxlTXV0YXRpb25zMjtcbiAgICAgICAgX19uYW1lKGhhbmRsZUZvY3VzSW4yLCBcImhhbmRsZUZvY3VzSW5cIik7XG4gICAgICAgIF9fbmFtZShoYW5kbGVGb2N1c091dDIsIFwiaGFuZGxlRm9jdXNPdXRcIik7XG4gICAgICAgIF9fbmFtZShoYW5kbGVNdXRhdGlvbnMyLCBcImhhbmRsZU11dGF0aW9uc1wiKTtcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImZvY3VzaW5cIiwgaGFuZGxlRm9jdXNJbjIpO1xuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiZm9jdXNvdXRcIiwgaGFuZGxlRm9jdXNPdXQyKTtcbiAgICAgICAgY29uc3QgbXV0YXRpb25PYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKGhhbmRsZU11dGF0aW9uczIpO1xuICAgICAgICBpZiAoY29udGFpbmVyKSBtdXRhdGlvbk9ic2VydmVyLm9ic2VydmUoY29udGFpbmVyLCB7IGNoaWxkTGlzdDogdHJ1ZSwgc3VidHJlZTogdHJ1ZSB9KTtcbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwiZm9jdXNpblwiLCBoYW5kbGVGb2N1c0luMik7XG4gICAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImZvY3Vzb3V0XCIsIGhhbmRsZUZvY3VzT3V0Mik7XG4gICAgICAgICAgbXV0YXRpb25PYnNlcnZlci5kaXNjb25uZWN0KCk7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSwgW3RyYXBwZWQsIGNvbnRhaW5lciwgZm9jdXNTY29wZS5wYXVzZWQsIGlzVGFyZ2V0SW5TY29wZV0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBpZiAoY29udGFpbmVyKSB7XG4gICAgICAgIGZvY3VzU2NvcGVzU3RhY2suYWRkKGZvY3VzU2NvcGUpO1xuICAgICAgICBjb25zdCBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50O1xuICAgICAgICBjb25zdCBoYXNGb2N1c2VkQ2FuZGlkYXRlID0gY29udGFpbmVyLmNvbnRhaW5zKHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCk7XG4gICAgICAgIGlmICghaGFzRm9jdXNlZENhbmRpZGF0ZSkge1xuICAgICAgICAgIGNvbnN0IG1vdW50RXZlbnQgPSBuZXcgQ3VzdG9tRXZlbnQoQVVUT0ZPQ1VTX09OX01PVU5ULCBFVkVOVF9PUFRJT05TKTtcbiAgICAgICAgICBjb250YWluZXIuYWRkRXZlbnRMaXN0ZW5lcihBVVRPRk9DVVNfT05fTU9VTlQsIG9uTW91bnRBdXRvRm9jdXMpO1xuICAgICAgICAgIGNvbnRhaW5lci5kaXNwYXRjaEV2ZW50KG1vdW50RXZlbnQpO1xuICAgICAgICAgIGlmICghbW91bnRFdmVudC5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgICAgICBmb2N1c0ZpcnN0KHJlbW92ZUxpbmtzKGdldFRhYmJhYmxlQ2FuZGlkYXRlcyhjb250YWluZXIpKSwgeyBzZWxlY3Q6IHRydWUgfSk7XG4gICAgICAgICAgICBpZiAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA9PT0gcHJldmlvdXNseUZvY3VzZWRFbGVtZW50KSB7XG4gICAgICAgICAgICAgIGZvY3VzKGNvbnRhaW5lcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgY29udGFpbmVyLnJlbW92ZUV2ZW50TGlzdGVuZXIoQVVUT0ZPQ1VTX09OX01PVU5ULCBvbk1vdW50QXV0b0ZvY3VzKTtcbiAgICAgICAgICBjb25zdCBvd25lckRvY3VtZW50ID0gY29udGFpbmVyLm93bmVyRG9jdW1lbnQ7XG4gICAgICAgICAgY29uc3QgVW5tb3VudEV2ZW50ID0gQ3VzdG9tRXZlbnQ7XG4gICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB1bm1vdW50RXZlbnQgPSBuZXcgVW5tb3VudEV2ZW50KEFVVE9GT0NVU19PTl9VTk1PVU5ULCBFVkVOVF9PUFRJT05TKTtcbiAgICAgICAgICAgIGNvbnRhaW5lci5hZGRFdmVudExpc3RlbmVyKEFVVE9GT0NVU19PTl9VTk1PVU5ULCBvblVubW91bnRBdXRvRm9jdXMpO1xuICAgICAgICAgICAgY29udGFpbmVyLmRpc3BhdGNoRXZlbnQodW5tb3VudEV2ZW50KTtcbiAgICAgICAgICAgIGlmICghdW5tb3VudEV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICAgICAgICAgICAgZm9jdXMocHJldmlvdXNseUZvY3VzZWRFbGVtZW50ID8/IG93bmVyRG9jdW1lbnQuYm9keSwgeyBzZWxlY3Q6IHRydWUgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb250YWluZXIucmVtb3ZlRXZlbnRMaXN0ZW5lcihBVVRPRk9DVVNfT05fVU5NT1VOVCwgb25Vbm1vdW50QXV0b0ZvY3VzKTtcbiAgICAgICAgICAgIGZvY3VzU2NvcGVzU3RhY2sucmVtb3ZlKGZvY3VzU2NvcGUpO1xuICAgICAgICAgIH0sIDApO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgIH0sIFtjb250YWluZXIsIG9uTW91bnRBdXRvRm9jdXMsIG9uVW5tb3VudEF1dG9Gb2N1cywgZm9jdXNTY29wZV0pO1xuICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSBSZWFjdC51c2VDYWxsYmFjayhcbiAgICAgIChldmVudCkgPT4ge1xuICAgICAgICBpZiAoIWxvb3AgJiYgIXRyYXBwZWQpIHJldHVybjtcbiAgICAgICAgaWYgKGZvY3VzU2NvcGUucGF1c2VkKSByZXR1cm47XG4gICAgICAgIGNvbnN0IGlzVGFiS2V5ID0gZXZlbnQua2V5ID09PSBcIlRhYlwiICYmICFldmVudC5hbHRLZXkgJiYgIWV2ZW50LmN0cmxLZXkgJiYgIWV2ZW50Lm1ldGFLZXk7XG4gICAgICAgIGNvbnN0IGZvY3VzZWRFbGVtZW50ID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudDtcbiAgICAgICAgaWYgKGlzVGFiS2V5ICYmIGZvY3VzZWRFbGVtZW50KSB7XG4gICAgICAgICAgY29uc3QgY29udGFpbmVyMiA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgICAgICAgY29uc3QgW2ZpcnN0LCBsYXN0XSA9IGdldFRhYmJhYmxlRWRnZXMoY29udGFpbmVyMik7XG4gICAgICAgICAgY29uc3QgaGFzVGFiYmFibGVFbGVtZW50c0luc2lkZSA9IGZpcnN0ICYmIGxhc3Q7XG4gICAgICAgICAgaWYgKCFoYXNUYWJiYWJsZUVsZW1lbnRzSW5zaWRlKSB7XG4gICAgICAgICAgICBpZiAoZm9jdXNlZEVsZW1lbnQgPT09IGNvbnRhaW5lcjIpIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmICghZXZlbnQuc2hpZnRLZXkgJiYgZm9jdXNlZEVsZW1lbnQgPT09IGxhc3QpIHtcbiAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgaWYgKGxvb3ApIGZvY3VzKGZpcnN0LCB7IHNlbGVjdDogdHJ1ZSB9KTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoZXZlbnQuc2hpZnRLZXkgJiYgZm9jdXNlZEVsZW1lbnQgPT09IGZpcnN0KSB7XG4gICAgICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICAgIGlmIChsb29wKSBmb2N1cyhsYXN0LCB7IHNlbGVjdDogdHJ1ZSB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBbbG9vcCwgdHJhcHBlZCwgZm9jdXNTY29wZS5wYXVzZWRdXG4gICAgKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChQcmltaXRpdmUuZGl2LCB7IHRhYkluZGV4OiAtMSwgLi4uc2NvcGVQcm9wcywgcmVmOiBjb21wb3NlZFJlZnMsIG9uS2V5RG93bjogaGFuZGxlS2V5RG93biB9KTtcbiAgfSwgXCJGb2N1c1Njb3BlXCIpXG4pO1xudmFyIEZvY3VzU2NvcGVCcmFuY2hDb250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKTtcbmZ1bmN0aW9uIEZvY3VzU2NvcGVCcmFuY2hQcm92aWRlcih7IHJlZ2lzdHJ5LCBjaGlsZHJlbiB9KSB7XG4gIGlmICghcmVnaXN0cnkpIHtcbiAgICByZXR1cm4gY2hpbGRyZW47XG4gIH1cbiAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goRm9jdXNTY29wZUJyYW5jaENvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWU6IHJlZ2lzdHJ5LCBjaGlsZHJlbiB9KTtcbn1cbl9fbmFtZShGb2N1c1Njb3BlQnJhbmNoUHJvdmlkZXIsIFwiRm9jdXNTY29wZUJyYW5jaFByb3ZpZGVyXCIpO1xuZnVuY3Rpb24gdXNlRm9jdXNTY29wZUJyYW5jaFJlZ2lzdHJ5KCkge1xuICBjb25zdCBbbm9kZXMsIHNldE5vZGVzXSA9IFJlYWN0LnVzZVN0YXRlKFtdKTtcbiAgY29uc3QgcmVnaXN0cnkgPSBSZWFjdC51c2VNZW1vKFxuICAgICgpID0+ICh7XG4gICAgICBhZGQ6IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKG5vZGUpID0+IHNldE5vZGVzKChwcmV2KSA9PiBwcmV2LmluY2x1ZGVzKG5vZGUpID8gcHJldiA6IFsuLi5wcmV2LCBub2RlXSksIFwiYWRkXCIpLFxuICAgICAgcmVtb3ZlOiAvKiBAX19QVVJFX18gKi8gX19uYW1lKChub2RlKSA9PiBzZXROb2RlcygocHJldikgPT4gcHJldi5maWx0ZXIoKGN1cnJlbnQpID0+IGN1cnJlbnQgIT09IG5vZGUpKSwgXCJyZW1vdmVcIilcbiAgICB9KSxcbiAgICBbXVxuICApO1xuICByZXR1cm4geyBub2RlcywgcmVnaXN0cnkgfTtcbn1cbl9fbmFtZSh1c2VGb2N1c1Njb3BlQnJhbmNoUmVnaXN0cnksIFwidXNlRm9jdXNTY29wZUJyYW5jaFJlZ2lzdHJ5XCIpO1xuZnVuY3Rpb24gdXNlRm9jdXNTY29wZUJyYW5jaChub2RlKSB7XG4gIGNvbnN0IHJlZ2lzdHJ5ID0gUmVhY3QudXNlQ29udGV4dChGb2N1c1Njb3BlQnJhbmNoQ29udGV4dCk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFub2RlIHx8ICFyZWdpc3RyeSkgcmV0dXJuO1xuICAgIHJlZ2lzdHJ5LmFkZChub2RlKTtcbiAgICByZXR1cm4gKCkgPT4gcmVnaXN0cnkucmVtb3ZlKG5vZGUpO1xuICB9LCBbbm9kZSwgcmVnaXN0cnldKTtcbn1cbl9fbmFtZSh1c2VGb2N1c1Njb3BlQnJhbmNoLCBcInVzZUZvY3VzU2NvcGVCcmFuY2hcIik7XG5mdW5jdGlvbiBmb2N1c0ZpcnN0KGNhbmRpZGF0ZXMsIHsgc2VsZWN0ID0gZmFsc2UgfSA9IHt9KSB7XG4gIGNvbnN0IHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQ7XG4gIGZvciAoY29uc3QgY2FuZGlkYXRlIG9mIGNhbmRpZGF0ZXMpIHtcbiAgICBmb2N1cyhjYW5kaWRhdGUsIHsgc2VsZWN0IH0pO1xuICAgIGlmIChkb2N1bWVudC5hY3RpdmVFbGVtZW50ICE9PSBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQpIHJldHVybjtcbiAgfVxufVxuX19uYW1lKGZvY3VzRmlyc3QsIFwiZm9jdXNGaXJzdFwiKTtcbmZ1bmN0aW9uIGdldFRhYmJhYmxlRWRnZXMoY29udGFpbmVyKSB7XG4gIGNvbnN0IGNhbmRpZGF0ZXMgPSBnZXRUYWJiYWJsZUNhbmRpZGF0ZXMoY29udGFpbmVyKTtcbiAgY29uc3QgZmlyc3QgPSBmaW5kVmlzaWJsZShjYW5kaWRhdGVzLCBjb250YWluZXIpO1xuICBjb25zdCBsYXN0ID0gZmluZFZpc2libGUoY2FuZGlkYXRlcy5yZXZlcnNlKCksIGNvbnRhaW5lcik7XG4gIHJldHVybiBbZmlyc3QsIGxhc3RdO1xufVxuX19uYW1lKGdldFRhYmJhYmxlRWRnZXMsIFwiZ2V0VGFiYmFibGVFZGdlc1wiKTtcbmZ1bmN0aW9uIGdldFRhYmJhYmxlQ2FuZGlkYXRlcyhjb250YWluZXIpIHtcbiAgY29uc3Qgbm9kZXMgPSBbXTtcbiAgY29uc3QgZG9jdW1lbnQyID0gY29udGFpbmVyLm93bmVyRG9jdW1lbnQ7XG4gIGNvbnN0IHdhbGtlciA9IGRvY3VtZW50Mi5jcmVhdGVUcmVlV2Fsa2VyKGNvbnRhaW5lciwgTm9kZUZpbHRlci5TSE9XX0VMRU1FTlQsIHtcbiAgICBhY2NlcHROb2RlOiAvKiBAX19QVVJFX18gKi8gX19uYW1lKChub2RlKSA9PiB7XG4gICAgICBjb25zdCBpc0hpZGRlbklucHV0ID0gbm9kZS50YWdOYW1lID09PSBcIklOUFVUXCIgJiYgbm9kZS50eXBlID09PSBcImhpZGRlblwiO1xuICAgICAgaWYgKG5vZGUuZGlzYWJsZWQgfHwgbm9kZS5oaWRkZW4gfHwgaXNIaWRkZW5JbnB1dCkge1xuICAgICAgICByZXR1cm4gTm9kZUZpbHRlci5GSUxURVJfU0tJUDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBub2RlLnRhYkluZGV4ID49IDAgPyBOb2RlRmlsdGVyLkZJTFRFUl9BQ0NFUFQgOiBOb2RlRmlsdGVyLkZJTFRFUl9TS0lQO1xuICAgIH0sIFwiYWNjZXB0Tm9kZVwiKVxuICB9KTtcbiAgd2hpbGUgKHdhbGtlci5uZXh0Tm9kZSgpKSB7XG4gICAgbm9kZXMucHVzaCh3YWxrZXIuY3VycmVudE5vZGUpO1xuICB9XG4gIHJldHVybiBub2Rlcztcbn1cbl9fbmFtZShnZXRUYWJiYWJsZUNhbmRpZGF0ZXMsIFwiZ2V0VGFiYmFibGVDYW5kaWRhdGVzXCIpO1xuZnVuY3Rpb24gZmluZFZpc2libGUoZWxlbWVudHMsIGNvbnRhaW5lcikge1xuICBjb25zdCBjYW5Vc2VDaGVja1Zpc2liaWxpdHkgPSB0eXBlb2YgY29udGFpbmVyLmNoZWNrVmlzaWJpbGl0eSA9PT0gXCJmdW5jdGlvblwiICYmIGNvbnRhaW5lci5jaGVja1Zpc2liaWxpdHkoeyBjaGVja1Zpc2liaWxpdHlDU1M6IHRydWUgfSk7XG4gIGZvciAoY29uc3QgZWxlbWVudCBvZiBlbGVtZW50cykge1xuICAgIGNvbnN0IGhpZGRlbiA9IGNhblVzZUNoZWNrVmlzaWJpbGl0eSA/ICFlbGVtZW50LmNoZWNrVmlzaWJpbGl0eSh7IGNoZWNrVmlzaWJpbGl0eUNTUzogdHJ1ZSB9KSA6IGlzSGlkZGVuKGVsZW1lbnQsIHsgdXBUbzogY29udGFpbmVyIH0pO1xuICAgIGlmICghaGlkZGVuKSB7XG4gICAgICByZXR1cm4gZWxlbWVudDtcbiAgICB9XG4gIH1cbn1cbl9fbmFtZShmaW5kVmlzaWJsZSwgXCJmaW5kVmlzaWJsZVwiKTtcbmZ1bmN0aW9uIGlzSGlkZGVuKG5vZGUsIHsgdXBUbyB9KSB7XG4gIGlmIChnZXRDb21wdXRlZFN0eWxlKG5vZGUpLnZpc2liaWxpdHkgPT09IFwiaGlkZGVuXCIpIHJldHVybiB0cnVlO1xuICB3aGlsZSAobm9kZSkge1xuICAgIGlmICh1cFRvICE9PSB2b2lkIDAgJiYgbm9kZSA9PT0gdXBUbykgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChnZXRDb21wdXRlZFN0eWxlKG5vZGUpLmRpc3BsYXkgPT09IFwibm9uZVwiKSByZXR1cm4gdHJ1ZTtcbiAgICBub2RlID0gbm9kZS5wYXJlbnRFbGVtZW50O1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbl9fbmFtZShpc0hpZGRlbiwgXCJpc0hpZGRlblwiKTtcbmZ1bmN0aW9uIGlzU2VsZWN0YWJsZUlucHV0KGVsZW1lbnQpIHtcbiAgcmV0dXJuIGVsZW1lbnQudGFnTmFtZSA9PT0gXCJJTlBVVFwiICYmIHR5cGVvZiBlbGVtZW50LnNlbGVjdCA9PT0gXCJmdW5jdGlvblwiO1xufVxuX19uYW1lKGlzU2VsZWN0YWJsZUlucHV0LCBcImlzU2VsZWN0YWJsZUlucHV0XCIpO1xuZnVuY3Rpb24gZm9jdXMoZWxlbWVudCwgeyBzZWxlY3QgPSBmYWxzZSB9ID0ge30pIHtcbiAgaWYgKGVsZW1lbnQgJiYgZWxlbWVudC5mb2N1cykge1xuICAgIGNvbnN0IG93bmVyRG9jdW1lbnQgPSBlbGVtZW50Lm93bmVyRG9jdW1lbnQgPz8gZG9jdW1lbnQ7XG4gICAgY29uc3QgcHJldmlvdXNseUZvY3VzZWRFbGVtZW50ID0gb3duZXJEb2N1bWVudC5hY3RpdmVFbGVtZW50O1xuICAgIGVsZW1lbnQuZm9jdXMoeyBwcmV2ZW50U2Nyb2xsOiB0cnVlIH0pO1xuICAgIGlmIChlbGVtZW50ICE9PSBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQgJiYgaXNTZWxlY3RhYmxlSW5wdXQoZWxlbWVudCkgJiYgc2VsZWN0KVxuICAgICAgZWxlbWVudC5zZWxlY3QoKTtcbiAgfVxufVxuX19uYW1lKGZvY3VzLCBcImZvY3VzXCIpO1xudmFyIGZvY3VzU2NvcGVzU3RhY2sgPSBjcmVhdGVGb2N1c1Njb3Blc1N0YWNrKCk7XG5mdW5jdGlvbiBjcmVhdGVGb2N1c1Njb3Blc1N0YWNrKCkge1xuICBsZXQgc3RhY2sgPSBbXTtcbiAgcmV0dXJuIHtcbiAgICBhZGQoZm9jdXNTY29wZSkge1xuICAgICAgY29uc3QgYWN0aXZlRm9jdXNTY29wZSA9IHN0YWNrWzBdO1xuICAgICAgaWYgKGZvY3VzU2NvcGUgIT09IGFjdGl2ZUZvY3VzU2NvcGUpIHtcbiAgICAgICAgYWN0aXZlRm9jdXNTY29wZT8ucGF1c2UoKTtcbiAgICAgIH1cbiAgICAgIHN0YWNrID0gYXJyYXlSZW1vdmUoc3RhY2ssIGZvY3VzU2NvcGUpO1xuICAgICAgc3RhY2sudW5zaGlmdChmb2N1c1Njb3BlKTtcbiAgICB9LFxuICAgIHJlbW92ZShmb2N1c1Njb3BlKSB7XG4gICAgICBzdGFjayA9IGFycmF5UmVtb3ZlKHN0YWNrLCBmb2N1c1Njb3BlKTtcbiAgICAgIHN0YWNrWzBdPy5yZXN1bWUoKTtcbiAgICB9XG4gIH07XG59XG5fX25hbWUoY3JlYXRlRm9jdXNTY29wZXNTdGFjaywgXCJjcmVhdGVGb2N1c1Njb3Blc1N0YWNrXCIpO1xuZnVuY3Rpb24gYXJyYXlSZW1vdmUoYXJyYXksIGl0ZW0pIHtcbiAgY29uc3QgdXBkYXRlZEFycmF5ID0gWy4uLmFycmF5XTtcbiAgY29uc3QgaW5kZXggPSB1cGRhdGVkQXJyYXkuaW5kZXhPZihpdGVtKTtcbiAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgIHVwZGF0ZWRBcnJheS5zcGxpY2UoaW5kZXgsIDEpO1xuICB9XG4gIHJldHVybiB1cGRhdGVkQXJyYXk7XG59XG5fX25hbWUoYXJyYXlSZW1vdmUsIFwiYXJyYXlSZW1vdmVcIik7XG5mdW5jdGlvbiByZW1vdmVMaW5rcyhpdGVtcykge1xuICByZXR1cm4gaXRlbXMuZmlsdGVyKChpdGVtKSA9PiBpdGVtLnRhZ05hbWUgIT09IFwiQVwiKTtcbn1cbl9fbmFtZShyZW1vdmVMaW5rcywgXCJyZW1vdmVMaW5rc1wiKTtcbmV4cG9ydCB7XG4gIEZvY3VzU2NvcGUsXG4gIEZvY3VzU2NvcGVCcmFuY2hQcm92aWRlcixcbiAgRm9jdXNTY29wZSBhcyBSb290LFxuICB1c2VGb2N1c1Njb3BlQnJhbmNoLFxuICB1c2VGb2N1c1Njb3BlQnJhbmNoUmVnaXN0cnlcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tanMubWFwXG4iLCJcInVzZSBjbGllbnRcIjtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy9wb3J0YWwudHN4XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCAqIGFzIFJlYWN0RE9NIGZyb20gXCJyZWFjdC1kb21cIjtcbmltcG9ydCB7IFByaW1pdGl2ZSB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtcHJpbWl0aXZlXCI7XG5pbXBvcnQgeyB1c2VMYXlvdXRFZmZlY3QgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXVzZS1sYXlvdXQtZWZmZWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbnZhciBQb3J0YWwgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBQb3J0YWwyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IGNvbnRhaW5lcjogY29udGFpbmVyUHJvcCwgLi4ucG9ydGFsUHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IFttb3VudGVkLCBzZXRNb3VudGVkXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcbiAgICB1c2VMYXlvdXRFZmZlY3QoKCkgPT4gc2V0TW91bnRlZCh0cnVlKSwgW10pO1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IGNvbnRhaW5lclByb3AgfHwgbW91bnRlZCAmJiBnbG9iYWxUaGlzPy5kb2N1bWVudD8uYm9keTtcbiAgICByZXR1cm4gY29udGFpbmVyID8gUmVhY3RET00uY3JlYXRlUG9ydGFsKC8qIEBfX1BVUkVfXyAqLyBqc3goUHJpbWl0aXZlLmRpdiwgeyAuLi5wb3J0YWxQcm9wcywgcmVmOiBmb3J3YXJkZWRSZWYgfSksIGNvbnRhaW5lcikgOiBudWxsO1xuICB9LCBcIlBvcnRhbFwiKVxuKTtcbmV4cG9ydCB7XG4gIFBvcnRhbCxcbiAgUG9ydGFsIGFzIFJvb3Rcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tanMubWFwXG4iLCJcInVzZSBjbGllbnRcIjtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy9wcmVzZW5jZS50c3hcbmltcG9ydCAqIGFzIFJlYWN0MiBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZUxheW91dEVmZmVjdCB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtdXNlLWxheW91dC1lZmZlY3RcIjtcblxuLy8gc3JjL3VzZS1zdGF0ZS1tYWNoaW5lLnRzeFxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5mdW5jdGlvbiB1c2VTdGF0ZU1hY2hpbmUoaW5pdGlhbFN0YXRlLCBtYWNoaW5lKSB7XG4gIHJldHVybiBSZWFjdC51c2VSZWR1Y2VyKChzdGF0ZSwgZXZlbnQpID0+IHtcbiAgICBjb25zdCBuZXh0U3RhdGUgPSBtYWNoaW5lW3N0YXRlXVtldmVudF07XG4gICAgcmV0dXJuIG5leHRTdGF0ZSA/PyBzdGF0ZTtcbiAgfSwgaW5pdGlhbFN0YXRlKTtcbn1cbl9fbmFtZSh1c2VTdGF0ZU1hY2hpbmUsIFwidXNlU3RhdGVNYWNoaW5lXCIpO1xuXG4vLyBzcmMvcHJlc2VuY2UudHN4XG52YXIgUHJlc2VuY2UgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKChwcm9wcykgPT4ge1xuICBjb25zdCB7IHByZXNlbnQsIGNoaWxkcmVuIH0gPSBwcm9wcztcbiAgY29uc3QgcHJlc2VuY2UgPSB1c2VQcmVzZW5jZShwcmVzZW50KTtcbiAgY29uc3QgY2hpbGQgPSB0eXBlb2YgY2hpbGRyZW4gPT09IFwiZnVuY3Rpb25cIiA/IGNoaWxkcmVuKHsgcHJlc2VudDogcHJlc2VuY2UuaXNQcmVzZW50IH0pIDogUmVhY3QyLkNoaWxkcmVuLm9ubHkoY2hpbGRyZW4pO1xuICBjb25zdCByZWYgPSB1c2VTdGFibGVDb21wb3NlZFJlZnMocHJlc2VuY2UucmVmLCBnZXRFbGVtZW50UmVmKGNoaWxkKSk7XG4gIGNvbnN0IGZvcmNlTW91bnQgPSB0eXBlb2YgY2hpbGRyZW4gPT09IFwiZnVuY3Rpb25cIjtcbiAgcmV0dXJuIGZvcmNlTW91bnQgfHwgcHJlc2VuY2UuaXNQcmVzZW50ID8gUmVhY3QyLmNsb25lRWxlbWVudChjaGlsZCwgeyByZWYgfSkgOiBudWxsO1xufSwgXCJQcmVzZW5jZVwiKTtcbmZ1bmN0aW9uIHVzZVByZXNlbmNlKHByZXNlbnQpIHtcbiAgY29uc3QgW25vZGUsIHNldE5vZGVdID0gUmVhY3QyLnVzZVN0YXRlKCk7XG4gIGNvbnN0IHN0eWxlc1JlZiA9IFJlYWN0Mi51c2VSZWYobnVsbCk7XG4gIGNvbnN0IHByZXZQcmVzZW50UmVmID0gUmVhY3QyLnVzZVJlZihwcmVzZW50KTtcbiAgY29uc3QgcHJldkFuaW1hdGlvbk5hbWVSZWYgPSBSZWFjdDIudXNlUmVmKFwibm9uZVwiKTtcbiAgY29uc3QgbW91bnRBbmltYXRpb25OYW1lUmVmID0gUmVhY3QyLnVzZVJlZih2b2lkIDApO1xuICBjb25zdCBpbml0aWFsU3RhdGUgPSBwcmVzZW50ID8gXCJtb3VudGVkXCIgOiBcInVubW91bnRlZFwiO1xuICBjb25zdCBbc3RhdGUsIHNlbmRdID0gdXNlU3RhdGVNYWNoaW5lKGluaXRpYWxTdGF0ZSwge1xuICAgIG1vdW50ZWQ6IHtcbiAgICAgIFVOTU9VTlQ6IFwidW5tb3VudGVkXCIsXG4gICAgICBBTklNQVRJT05fT1VUOiBcInVubW91bnRTdXNwZW5kZWRcIlxuICAgIH0sXG4gICAgdW5tb3VudFN1c3BlbmRlZDoge1xuICAgICAgTU9VTlQ6IFwibW91bnRlZFwiLFxuICAgICAgQU5JTUFUSU9OX0VORDogXCJ1bm1vdW50ZWRcIlxuICAgIH0sXG4gICAgdW5tb3VudGVkOiB7XG4gICAgICBNT1VOVDogXCJtb3VudGVkXCJcbiAgICB9XG4gIH0pO1xuICBSZWFjdDIudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoc3RhdGUgPT09IFwibW91bnRlZFwiKSB7XG4gICAgICBwcmV2QW5pbWF0aW9uTmFtZVJlZi5jdXJyZW50ID0gbW91bnRBbmltYXRpb25OYW1lUmVmLmN1cnJlbnQgPz8gZ2V0QW5pbWF0aW9uTmFtZShzdHlsZXNSZWYuY3VycmVudCk7XG4gICAgICBtb3VudEFuaW1hdGlvbk5hbWVSZWYuY3VycmVudCA9IHZvaWQgMDtcbiAgICB9IGVsc2Uge1xuICAgICAgcHJldkFuaW1hdGlvbk5hbWVSZWYuY3VycmVudCA9IFwibm9uZVwiO1xuICAgIH1cbiAgfSwgW3N0YXRlXSk7XG4gIHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgc3R5bGVzID0gc3R5bGVzUmVmLmN1cnJlbnQ7XG4gICAgY29uc3Qgd2FzUHJlc2VudCA9IHByZXZQcmVzZW50UmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgaGFzUHJlc2VudENoYW5nZWQgPSB3YXNQcmVzZW50ICE9PSBwcmVzZW50O1xuICAgIGlmIChoYXNQcmVzZW50Q2hhbmdlZCkge1xuICAgICAgY29uc3QgcHJldkFuaW1hdGlvbk5hbWUgPSBwcmV2QW5pbWF0aW9uTmFtZVJlZi5jdXJyZW50O1xuICAgICAgY29uc3QgY3VycmVudEFuaW1hdGlvbk5hbWUgPSBnZXRBbmltYXRpb25OYW1lKHN0eWxlcyk7XG4gICAgICBpZiAocHJlc2VudCkge1xuICAgICAgICBtb3VudEFuaW1hdGlvbk5hbWVSZWYuY3VycmVudCA9IGN1cnJlbnRBbmltYXRpb25OYW1lO1xuICAgICAgICBzZW5kKFwiTU9VTlRcIik7XG4gICAgICB9IGVsc2UgaWYgKGN1cnJlbnRBbmltYXRpb25OYW1lID09PSBcIm5vbmVcIiB8fCBzdHlsZXM/LmRpc3BsYXkgPT09IFwibm9uZVwiKSB7XG4gICAgICAgIHNlbmQoXCJVTk1PVU5UXCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgaXNBbmltYXRpbmcgPSBwcmV2QW5pbWF0aW9uTmFtZSAhPT0gY3VycmVudEFuaW1hdGlvbk5hbWU7XG4gICAgICAgIGlmICh3YXNQcmVzZW50ICYmIGlzQW5pbWF0aW5nKSB7XG4gICAgICAgICAgc2VuZChcIkFOSU1BVElPTl9PVVRcIik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2VuZChcIlVOTU9VTlRcIik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHByZXZQcmVzZW50UmVmLmN1cnJlbnQgPSBwcmVzZW50O1xuICAgIH1cbiAgfSwgW3ByZXNlbnQsIHNlbmRdKTtcbiAgdXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAobm9kZSkge1xuICAgICAgbGV0IHRpbWVvdXRJZDtcbiAgICAgIGNvbnN0IG93bmVyV2luZG93ID0gbm9kZS5vd25lckRvY3VtZW50LmRlZmF1bHRWaWV3ID8/IHdpbmRvdztcbiAgICAgIGNvbnN0IGhhbmRsZUFuaW1hdGlvbkVuZCA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKGV2ZW50KSA9PiB7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRBbmltYXRpb25OYW1lID0gZ2V0QW5pbWF0aW9uTmFtZShzdHlsZXNSZWYuY3VycmVudCk7XG4gICAgICAgIGNvbnN0IGlzQ3VycmVudEFuaW1hdGlvbiA9IGN1cnJlbnRBbmltYXRpb25OYW1lLmluY2x1ZGVzKENTUy5lc2NhcGUoZXZlbnQuYW5pbWF0aW9uTmFtZSkpO1xuICAgICAgICBpZiAoZXZlbnQudGFyZ2V0ID09PSBub2RlICYmIGlzQ3VycmVudEFuaW1hdGlvbikge1xuICAgICAgICAgIHNlbmQoXCJBTklNQVRJT05fRU5EXCIpO1xuICAgICAgICAgIGlmICghcHJldlByZXNlbnRSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgY29uc3QgY3VycmVudEZpbGxNb2RlID0gbm9kZS5zdHlsZS5hbmltYXRpb25GaWxsTW9kZTtcbiAgICAgICAgICAgIG5vZGUuc3R5bGUuYW5pbWF0aW9uRmlsbE1vZGUgPSBcImZvcndhcmRzXCI7XG4gICAgICAgICAgICB0aW1lb3V0SWQgPSBvd25lcldpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgaWYgKG5vZGUuc3R5bGUuYW5pbWF0aW9uRmlsbE1vZGUgPT09IFwiZm9yd2FyZHNcIikge1xuICAgICAgICAgICAgICAgIG5vZGUuc3R5bGUuYW5pbWF0aW9uRmlsbE1vZGUgPSBjdXJyZW50RmlsbE1vZGU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSwgXCJoYW5kbGVBbmltYXRpb25FbmRcIik7XG4gICAgICBjb25zdCBoYW5kbGVBbmltYXRpb25TdGFydCA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKGV2ZW50KSA9PiB7XG4gICAgICAgIGlmIChldmVudC50YXJnZXQgPT09IG5vZGUpIHtcbiAgICAgICAgICBwcmV2QW5pbWF0aW9uTmFtZVJlZi5jdXJyZW50ID0gZ2V0QW5pbWF0aW9uTmFtZShzdHlsZXNSZWYuY3VycmVudCk7XG4gICAgICAgIH1cbiAgICAgIH0sIFwiaGFuZGxlQW5pbWF0aW9uU3RhcnRcIik7XG4gICAgICBub2RlLmFkZEV2ZW50TGlzdGVuZXIoXCJhbmltYXRpb25zdGFydFwiLCBoYW5kbGVBbmltYXRpb25TdGFydCk7XG4gICAgICBub2RlLmFkZEV2ZW50TGlzdGVuZXIoXCJhbmltYXRpb25jYW5jZWxcIiwgaGFuZGxlQW5pbWF0aW9uRW5kKTtcbiAgICAgIG5vZGUuYWRkRXZlbnRMaXN0ZW5lcihcImFuaW1hdGlvbmVuZFwiLCBoYW5kbGVBbmltYXRpb25FbmQpO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgb3duZXJXaW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG4gICAgICAgIG5vZGUucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFuaW1hdGlvbnN0YXJ0XCIsIGhhbmRsZUFuaW1hdGlvblN0YXJ0KTtcbiAgICAgICAgbm9kZS5yZW1vdmVFdmVudExpc3RlbmVyKFwiYW5pbWF0aW9uY2FuY2VsXCIsIGhhbmRsZUFuaW1hdGlvbkVuZCk7XG4gICAgICAgIG5vZGUucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFuaW1hdGlvbmVuZFwiLCBoYW5kbGVBbmltYXRpb25FbmQpO1xuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2VuZChcIkFOSU1BVElPTl9FTkRcIik7XG4gICAgfVxuICB9LCBbbm9kZSwgc2VuZF0pO1xuICByZXR1cm4ge1xuICAgIGlzUHJlc2VudDogW1wibW91bnRlZFwiLCBcInVubW91bnRTdXNwZW5kZWRcIl0uaW5jbHVkZXMoc3RhdGUpLFxuICAgIHJlZjogUmVhY3QyLnVzZUNhbGxiYWNrKChub2RlMikgPT4ge1xuICAgICAgaWYgKG5vZGUyKSB7XG4gICAgICAgIGNvbnN0IHN0eWxlcyA9IGdldENvbXB1dGVkU3R5bGUobm9kZTIpO1xuICAgICAgICBzdHlsZXNSZWYuY3VycmVudCA9IHN0eWxlcztcbiAgICAgICAgbW91bnRBbmltYXRpb25OYW1lUmVmLmN1cnJlbnQgPSBnZXRBbmltYXRpb25OYW1lKHN0eWxlcyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzdHlsZXNSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgICBzZXROb2RlKG5vZGUyKTtcbiAgICB9LCBbXSlcbiAgfTtcbn1cbl9fbmFtZSh1c2VQcmVzZW5jZSwgXCJ1c2VQcmVzZW5jZVwiKTtcbmZ1bmN0aW9uIHNldFJlZihyZWYsIHZhbHVlKSB7XG4gIGlmICh0eXBlb2YgcmVmID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICByZXR1cm4gcmVmKHZhbHVlKTtcbiAgfSBlbHNlIGlmIChyZWYgIT09IG51bGwgJiYgcmVmICE9PSB2b2lkIDApIHtcbiAgICByZWYuY3VycmVudCA9IHZhbHVlO1xuICB9XG59XG5fX25hbWUoc2V0UmVmLCBcInNldFJlZlwiKTtcbmZ1bmN0aW9uIHVzZVN0YWJsZUNvbXBvc2VkUmVmcyguLi5yZWZzKSB7XG4gIGNvbnN0IHJlZnNSZWYgPSBSZWFjdDIudXNlUmVmKHJlZnMpO1xuICByZWZzUmVmLmN1cnJlbnQgPSByZWZzO1xuICByZXR1cm4gUmVhY3QyLnVzZUNhbGxiYWNrKChub2RlKSA9PiB7XG4gICAgY29uc3QgY3VycmVudFJlZnMgPSByZWZzUmVmLmN1cnJlbnQ7XG4gICAgbGV0IGhhc0NsZWFudXAgPSBmYWxzZTtcbiAgICBjb25zdCBjbGVhbnVwcyA9IGN1cnJlbnRSZWZzLm1hcCgocmVmKSA9PiB7XG4gICAgICBjb25zdCBjbGVhbnVwID0gc2V0UmVmKHJlZiwgbm9kZSk7XG4gICAgICBpZiAoIWhhc0NsZWFudXAgJiYgdHlwZW9mIGNsZWFudXAgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICBoYXNDbGVhbnVwID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjbGVhbnVwO1xuICAgIH0pO1xuICAgIGlmIChoYXNDbGVhbnVwKSB7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNsZWFudXBzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgY29uc3QgY2xlYW51cCA9IGNsZWFudXBzW2ldO1xuICAgICAgICAgIGlmICh0eXBlb2YgY2xlYW51cCA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICBjbGVhbnVwKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldFJlZihjdXJyZW50UmVmc1tpXSwgbnVsbCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgfSwgW10pO1xufVxuX19uYW1lKHVzZVN0YWJsZUNvbXBvc2VkUmVmcywgXCJ1c2VTdGFibGVDb21wb3NlZFJlZnNcIik7XG5mdW5jdGlvbiBnZXRBbmltYXRpb25OYW1lKHN0eWxlcykge1xuICByZXR1cm4gc3R5bGVzPy5hbmltYXRpb25OYW1lIHx8IFwibm9uZVwiO1xufVxuX19uYW1lKGdldEFuaW1hdGlvbk5hbWUsIFwiZ2V0QW5pbWF0aW9uTmFtZVwiKTtcbmZ1bmN0aW9uIGdldEVsZW1lbnRSZWYoZWxlbWVudCkge1xuICBsZXQgZ2V0dGVyID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihlbGVtZW50LnByb3BzLCBcInJlZlwiKT8uZ2V0O1xuICBsZXQgbWF5V2FybiA9IGdldHRlciAmJiBcImlzUmVhY3RXYXJuaW5nXCIgaW4gZ2V0dGVyICYmIGdldHRlci5pc1JlYWN0V2FybmluZztcbiAgaWYgKG1heVdhcm4pIHtcbiAgICByZXR1cm4gZWxlbWVudC5yZWY7XG4gIH1cbiAgZ2V0dGVyID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihlbGVtZW50LCBcInJlZlwiKT8uZ2V0O1xuICBtYXlXYXJuID0gZ2V0dGVyICYmIFwiaXNSZWFjdFdhcm5pbmdcIiBpbiBnZXR0ZXIgJiYgZ2V0dGVyLmlzUmVhY3RXYXJuaW5nO1xuICBpZiAobWF5V2Fybikge1xuICAgIHJldHVybiBlbGVtZW50LnByb3BzLnJlZjtcbiAgfVxuICByZXR1cm4gZWxlbWVudC5wcm9wcy5yZWYgfHwgZWxlbWVudC5yZWY7XG59XG5fX25hbWUoZ2V0RWxlbWVudFJlZiwgXCJnZXRFbGVtZW50UmVmXCIpO1xuZXhwb3J0IHtcbiAgUHJlc2VuY2UsXG4gIFByZXNlbmNlIGFzIFJvb3Rcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tanMubWFwXG4iLCJcInVzZSBjbGllbnRcIjtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy9mb2N1cy1ndWFyZHMudHN4XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbnZhciBjb3VudCA9IDA7XG52YXIgZ3VhcmRzID0gbnVsbDtcbmZ1bmN0aW9uIEZvY3VzR3VhcmRzKHByb3BzKSB7XG4gIHVzZUZvY3VzR3VhcmRzKCk7XG4gIHJldHVybiBwcm9wcy5jaGlsZHJlbjtcbn1cbl9fbmFtZShGb2N1c0d1YXJkcywgXCJGb2N1c0d1YXJkc1wiKTtcbmZ1bmN0aW9uIHVzZUZvY3VzR3VhcmRzKCkge1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZ3VhcmRzKSB7XG4gICAgICBndWFyZHMgPSB7IHN0YXJ0OiBjcmVhdGVGb2N1c0d1YXJkKCksIGVuZDogY3JlYXRlRm9jdXNHdWFyZCgpIH07XG4gICAgfVxuICAgIGNvbnN0IHsgc3RhcnQsIGVuZCB9ID0gZ3VhcmRzO1xuICAgIGlmIChkb2N1bWVudC5ib2R5LmZpcnN0RWxlbWVudENoaWxkICE9PSBzdGFydCkge1xuICAgICAgZG9jdW1lbnQuYm9keS5pbnNlcnRBZGphY2VudEVsZW1lbnQoXCJhZnRlcmJlZ2luXCIsIHN0YXJ0KTtcbiAgICB9XG4gICAgaWYgKGRvY3VtZW50LmJvZHkubGFzdEVsZW1lbnRDaGlsZCAhPT0gZW5kKSB7XG4gICAgICBkb2N1bWVudC5ib2R5Lmluc2VydEFkamFjZW50RWxlbWVudChcImJlZm9yZWVuZFwiLCBlbmQpO1xuICAgIH1cbiAgICBjb3VudCsrO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBpZiAoY291bnQgPT09IDEpIHtcbiAgICAgICAgZ3VhcmRzPy5zdGFydC5yZW1vdmUoKTtcbiAgICAgICAgZ3VhcmRzPy5lbmQucmVtb3ZlKCk7XG4gICAgICAgIGd1YXJkcyA9IG51bGw7XG4gICAgICB9XG4gICAgICBjb3VudCA9IE1hdGgubWF4KDAsIGNvdW50IC0gMSk7XG4gICAgfTtcbiAgfSwgW10pO1xufVxuX19uYW1lKHVzZUZvY3VzR3VhcmRzLCBcInVzZUZvY3VzR3VhcmRzXCIpO1xuZnVuY3Rpb24gY3JlYXRlRm9jdXNHdWFyZCgpIHtcbiAgY29uc3QgZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICBlbGVtZW50LnNldEF0dHJpYnV0ZShcImRhdGEtcmFkaXgtZm9jdXMtZ3VhcmRcIiwgXCJcIik7XG4gIGVsZW1lbnQudGFiSW5kZXggPSAwO1xuICBlbGVtZW50LnN0eWxlLm91dGxpbmUgPSBcIm5vbmVcIjtcbiAgZWxlbWVudC5zdHlsZS5vcGFjaXR5ID0gXCIwXCI7XG4gIGVsZW1lbnQuc3R5bGUucG9zaXRpb24gPSBcImZpeGVkXCI7XG4gIGVsZW1lbnQuc3R5bGUucG9pbnRlckV2ZW50cyA9IFwibm9uZVwiO1xuICByZXR1cm4gZWxlbWVudDtcbn1cbl9fbmFtZShjcmVhdGVGb2N1c0d1YXJkLCBcImNyZWF0ZUZvY3VzR3VhcmRcIik7XG5leHBvcnQge1xuICBGb2N1c0d1YXJkcyxcbiAgRm9jdXNHdWFyZHMgYXMgUm9vdCxcbiAgdXNlRm9jdXNHdWFyZHNcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tanMubWFwXG4iLCIvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG5Db3B5cmlnaHQgKGMpIE1pY3Jvc29mdCBDb3Jwb3JhdGlvbi5cblxuUGVybWlzc2lvbiB0byB1c2UsIGNvcHksIG1vZGlmeSwgYW5kL29yIGRpc3RyaWJ1dGUgdGhpcyBzb2Z0d2FyZSBmb3IgYW55XG5wdXJwb3NlIHdpdGggb3Igd2l0aG91dCBmZWUgaXMgaGVyZWJ5IGdyYW50ZWQuXG5cblRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIgQU5EIFRIRSBBVVRIT1IgRElTQ0xBSU1TIEFMTCBXQVJSQU5USUVTIFdJVEhcblJFR0FSRCBUTyBUSElTIFNPRlRXQVJFIElOQ0xVRElORyBBTEwgSU1QTElFRCBXQVJSQU5USUVTIE9GIE1FUkNIQU5UQUJJTElUWVxuQU5EIEZJVE5FU1MuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1IgQkUgTElBQkxFIEZPUiBBTlkgU1BFQ0lBTCwgRElSRUNULFxuSU5ESVJFQ1QsIE9SIENPTlNFUVVFTlRJQUwgREFNQUdFUyBPUiBBTlkgREFNQUdFUyBXSEFUU09FVkVSIFJFU1VMVElORyBGUk9NXG5MT1NTIE9GIFVTRSwgREFUQSBPUiBQUk9GSVRTLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgTkVHTElHRU5DRSBPUlxuT1RIRVIgVE9SVElPVVMgQUNUSU9OLCBBUklTSU5HIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFVTRSBPUlxuUEVSRk9STUFOQ0UgT0YgVEhJUyBTT0ZUV0FSRS5cbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqICovXG4vKiBnbG9iYWwgUmVmbGVjdCwgUHJvbWlzZSwgU3VwcHJlc3NlZEVycm9yLCBTeW1ib2wsIEl0ZXJhdG9yICovXG5cbnZhciBleHRlbmRTdGF0aWNzID0gZnVuY3Rpb24oZCwgYikge1xuICBleHRlbmRTdGF0aWNzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8XG4gICAgICAoeyBfX3Byb3RvX186IFtdIH0gaW5zdGFuY2VvZiBBcnJheSAmJiBmdW5jdGlvbiAoZCwgYikgeyBkLl9fcHJvdG9fXyA9IGI7IH0pIHx8XG4gICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYiwgcCkpIGRbcF0gPSBiW3BdOyB9O1xuICByZXR1cm4gZXh0ZW5kU3RhdGljcyhkLCBiKTtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2V4dGVuZHMoZCwgYikge1xuICBpZiAodHlwZW9mIGIgIT09IFwiZnVuY3Rpb25cIiAmJiBiICE9PSBudWxsKVxuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNsYXNzIGV4dGVuZHMgdmFsdWUgXCIgKyBTdHJpbmcoYikgKyBcIiBpcyBub3QgYSBjb25zdHJ1Y3RvciBvciBudWxsXCIpO1xuICBleHRlbmRTdGF0aWNzKGQsIGIpO1xuICBmdW5jdGlvbiBfXygpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7IH1cbiAgZC5wcm90b3R5cGUgPSBiID09PSBudWxsID8gT2JqZWN0LmNyZWF0ZShiKSA6IChfXy5wcm90b3R5cGUgPSBiLnByb3RvdHlwZSwgbmV3IF9fKCkpO1xufVxuXG5leHBvcnQgdmFyIF9fYXNzaWduID0gZnVuY3Rpb24oKSB7XG4gIF9fYXNzaWduID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbiBfX2Fzc2lnbih0KSB7XG4gICAgICBmb3IgKHZhciBzLCBpID0gMSwgbiA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICBzID0gYXJndW1lbnRzW2ldO1xuICAgICAgICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSkgdFtwXSA9IHNbcF07XG4gICAgICB9XG4gICAgICByZXR1cm4gdDtcbiAgfVxuICByZXR1cm4gX19hc3NpZ24uYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fcmVzdChzLCBlKSB7XG4gIHZhciB0ID0ge307XG4gIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxuICAgICAgdFtwXSA9IHNbcF07XG4gIGlmIChzICE9IG51bGwgJiYgdHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgPT09IFwiZnVuY3Rpb25cIilcbiAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBpZiAoZS5pbmRleE9mKHBbaV0pIDwgMCAmJiBPYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwocywgcFtpXSkpXG4gICAgICAgICAgICAgIHRbcFtpXV0gPSBzW3BbaV1dO1xuICAgICAgfVxuICByZXR1cm4gdDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fZGVjb3JhdGUoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpIHtcbiAgdmFyIGMgPSBhcmd1bWVudHMubGVuZ3RoLCByID0gYyA8IDMgPyB0YXJnZXQgOiBkZXNjID09PSBudWxsID8gZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodGFyZ2V0LCBrZXkpIDogZGVzYywgZDtcbiAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0LmRlY29yYXRlID09PSBcImZ1bmN0aW9uXCIpIHIgPSBSZWZsZWN0LmRlY29yYXRlKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKTtcbiAgZWxzZSBmb3IgKHZhciBpID0gZGVjb3JhdG9ycy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgaWYgKGQgPSBkZWNvcmF0b3JzW2ldKSByID0gKGMgPCAzID8gZChyKSA6IGMgPiAzID8gZCh0YXJnZXQsIGtleSwgcikgOiBkKHRhcmdldCwga2V5KSkgfHwgcjtcbiAgcmV0dXJuIGMgPiAzICYmIHIgJiYgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCByKSwgcjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fcGFyYW0ocGFyYW1JbmRleCwgZGVjb3JhdG9yKSB7XG4gIHJldHVybiBmdW5jdGlvbiAodGFyZ2V0LCBrZXkpIHsgZGVjb3JhdG9yKHRhcmdldCwga2V5LCBwYXJhbUluZGV4KTsgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gX19lc0RlY29yYXRlKGN0b3IsIGRlc2NyaXB0b3JJbiwgZGVjb3JhdG9ycywgY29udGV4dEluLCBpbml0aWFsaXplcnMsIGV4dHJhSW5pdGlhbGl6ZXJzKSB7XG4gIGZ1bmN0aW9uIGFjY2VwdChmKSB7IGlmIChmICE9PSB2b2lkIDAgJiYgdHlwZW9mIGYgIT09IFwiZnVuY3Rpb25cIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkZ1bmN0aW9uIGV4cGVjdGVkXCIpOyByZXR1cm4gZjsgfVxuICB2YXIga2luZCA9IGNvbnRleHRJbi5raW5kLCBrZXkgPSBraW5kID09PSBcImdldHRlclwiID8gXCJnZXRcIiA6IGtpbmQgPT09IFwic2V0dGVyXCIgPyBcInNldFwiIDogXCJ2YWx1ZVwiO1xuICB2YXIgdGFyZ2V0ID0gIWRlc2NyaXB0b3JJbiAmJiBjdG9yID8gY29udGV4dEluW1wic3RhdGljXCJdID8gY3RvciA6IGN0b3IucHJvdG90eXBlIDogbnVsbDtcbiAgdmFyIGRlc2NyaXB0b3IgPSBkZXNjcmlwdG9ySW4gfHwgKHRhcmdldCA/IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodGFyZ2V0LCBjb250ZXh0SW4ubmFtZSkgOiB7fSk7XG4gIHZhciBfLCBkb25lID0gZmFsc2U7XG4gIGZvciAodmFyIGkgPSBkZWNvcmF0b3JzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICB2YXIgY29udGV4dCA9IHt9O1xuICAgICAgZm9yICh2YXIgcCBpbiBjb250ZXh0SW4pIGNvbnRleHRbcF0gPSBwID09PSBcImFjY2Vzc1wiID8ge30gOiBjb250ZXh0SW5bcF07XG4gICAgICBmb3IgKHZhciBwIGluIGNvbnRleHRJbi5hY2Nlc3MpIGNvbnRleHQuYWNjZXNzW3BdID0gY29udGV4dEluLmFjY2Vzc1twXTtcbiAgICAgIGNvbnRleHQuYWRkSW5pdGlhbGl6ZXIgPSBmdW5jdGlvbiAoZikgeyBpZiAoZG9uZSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBhZGQgaW5pdGlhbGl6ZXJzIGFmdGVyIGRlY29yYXRpb24gaGFzIGNvbXBsZXRlZFwiKTsgZXh0cmFJbml0aWFsaXplcnMucHVzaChhY2NlcHQoZiB8fCBudWxsKSk7IH07XG4gICAgICB2YXIgcmVzdWx0ID0gKDAsIGRlY29yYXRvcnNbaV0pKGtpbmQgPT09IFwiYWNjZXNzb3JcIiA/IHsgZ2V0OiBkZXNjcmlwdG9yLmdldCwgc2V0OiBkZXNjcmlwdG9yLnNldCB9IDogZGVzY3JpcHRvcltrZXldLCBjb250ZXh0KTtcbiAgICAgIGlmIChraW5kID09PSBcImFjY2Vzc29yXCIpIHtcbiAgICAgICAgICBpZiAocmVzdWx0ID09PSB2b2lkIDApIGNvbnRpbnVlO1xuICAgICAgICAgIGlmIChyZXN1bHQgPT09IG51bGwgfHwgdHlwZW9mIHJlc3VsdCAhPT0gXCJvYmplY3RcIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIk9iamVjdCBleHBlY3RlZFwiKTtcbiAgICAgICAgICBpZiAoXyA9IGFjY2VwdChyZXN1bHQuZ2V0KSkgZGVzY3JpcHRvci5nZXQgPSBfO1xuICAgICAgICAgIGlmIChfID0gYWNjZXB0KHJlc3VsdC5zZXQpKSBkZXNjcmlwdG9yLnNldCA9IF87XG4gICAgICAgICAgaWYgKF8gPSBhY2NlcHQocmVzdWx0LmluaXQpKSBpbml0aWFsaXplcnMudW5zaGlmdChfKTtcbiAgICAgIH1cbiAgICAgIGVsc2UgaWYgKF8gPSBhY2NlcHQocmVzdWx0KSkge1xuICAgICAgICAgIGlmIChraW5kID09PSBcImZpZWxkXCIpIGluaXRpYWxpemVycy51bnNoaWZ0KF8pO1xuICAgICAgICAgIGVsc2UgZGVzY3JpcHRvcltrZXldID0gXztcbiAgICAgIH1cbiAgfVxuICBpZiAodGFyZ2V0KSBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBjb250ZXh0SW4ubmFtZSwgZGVzY3JpcHRvcik7XG4gIGRvbmUgPSB0cnVlO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIF9fcnVuSW5pdGlhbGl6ZXJzKHRoaXNBcmcsIGluaXRpYWxpemVycywgdmFsdWUpIHtcbiAgdmFyIHVzZVZhbHVlID0gYXJndW1lbnRzLmxlbmd0aCA+IDI7XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgaW5pdGlhbGl6ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YWx1ZSA9IHVzZVZhbHVlID8gaW5pdGlhbGl6ZXJzW2ldLmNhbGwodGhpc0FyZywgdmFsdWUpIDogaW5pdGlhbGl6ZXJzW2ldLmNhbGwodGhpc0FyZyk7XG4gIH1cbiAgcmV0dXJuIHVzZVZhbHVlID8gdmFsdWUgOiB2b2lkIDA7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gX19wcm9wS2V5KHgpIHtcbiAgcmV0dXJuIHR5cGVvZiB4ID09PSBcInN5bWJvbFwiID8geCA6IFwiXCIuY29uY2F0KHgpO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIF9fc2V0RnVuY3Rpb25OYW1lKGYsIG5hbWUsIHByZWZpeCkge1xuICBpZiAodHlwZW9mIG5hbWUgPT09IFwic3ltYm9sXCIpIG5hbWUgPSBuYW1lLmRlc2NyaXB0aW9uID8gXCJbXCIuY29uY2F0KG5hbWUuZGVzY3JpcHRpb24sIFwiXVwiKSA6IFwiXCI7XG4gIHJldHVybiBPYmplY3QuZGVmaW5lUHJvcGVydHkoZiwgXCJuYW1lXCIsIHsgY29uZmlndXJhYmxlOiB0cnVlLCB2YWx1ZTogcHJlZml4ID8gXCJcIi5jb25jYXQocHJlZml4LCBcIiBcIiwgbmFtZSkgOiBuYW1lIH0pO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIF9fbWV0YWRhdGEobWV0YWRhdGFLZXksIG1ldGFkYXRhVmFsdWUpIHtcbiAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0Lm1ldGFkYXRhID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBSZWZsZWN0Lm1ldGFkYXRhKG1ldGFkYXRhS2V5LCBtZXRhZGF0YVZhbHVlKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXRlcih0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XG4gIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxuICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICB9KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fZ2VuZXJhdG9yKHRoaXNBcmcsIGJvZHkpIHtcbiAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbigpIHsgaWYgKHRbMF0gJiAxKSB0aHJvdyB0WzFdOyByZXR1cm4gdFsxXTsgfSwgdHJ5czogW10sIG9wczogW10gfSwgZiwgeSwgdCwgZyA9IE9iamVjdC5jcmVhdGUoKHR5cGVvZiBJdGVyYXRvciA9PT0gXCJmdW5jdGlvblwiID8gSXRlcmF0b3IgOiBPYmplY3QpLnByb3RvdHlwZSk7XG4gIHJldHVybiBnLm5leHQgPSB2ZXJiKDApLCBnW1widGhyb3dcIl0gPSB2ZXJiKDEpLCBnW1wicmV0dXJuXCJdID0gdmVyYigyKSwgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIChnW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbigpIHsgcmV0dXJuIHRoaXM7IH0pLCBnO1xuICBmdW5jdGlvbiB2ZXJiKG4pIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBzdGVwKFtuLCB2XSk7IH07IH1cbiAgZnVuY3Rpb24gc3RlcChvcCkge1xuICAgICAgaWYgKGYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJHZW5lcmF0b3IgaXMgYWxyZWFkeSBleGVjdXRpbmcuXCIpO1xuICAgICAgd2hpbGUgKGcgJiYgKGcgPSAwLCBvcFswXSAmJiAoXyA9IDApKSwgXykgdHJ5IHtcbiAgICAgICAgICBpZiAoZiA9IDEsIHkgJiYgKHQgPSBvcFswXSAmIDIgPyB5W1wicmV0dXJuXCJdIDogb3BbMF0gPyB5W1widGhyb3dcIl0gfHwgKCh0ID0geVtcInJldHVyblwiXSkgJiYgdC5jYWxsKHkpLCAwKSA6IHkubmV4dCkgJiYgISh0ID0gdC5jYWxsKHksIG9wWzFdKSkuZG9uZSkgcmV0dXJuIHQ7XG4gICAgICAgICAgaWYgKHkgPSAwLCB0KSBvcCA9IFtvcFswXSAmIDIsIHQudmFsdWVdO1xuICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcbiAgICAgICAgICAgICAgY2FzZSAwOiBjYXNlIDE6IHQgPSBvcDsgYnJlYWs7XG4gICAgICAgICAgICAgIGNhc2UgNDogXy5sYWJlbCsrOyByZXR1cm4geyB2YWx1ZTogb3BbMV0sIGRvbmU6IGZhbHNlIH07XG4gICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcbiAgICAgICAgICAgICAgY2FzZSA3OiBvcCA9IF8ub3BzLnBvcCgpOyBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xuICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XG4gICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDMgJiYgKCF0IHx8IChvcFsxXSA+IHRbMF0gJiYgb3BbMV0gPCB0WzNdKSkpIHsgXy5sYWJlbCA9IG9wWzFdOyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSA2ICYmIF8ubGFiZWwgPCB0WzFdKSB7IF8ubGFiZWwgPSB0WzFdOyB0ID0gb3A7IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICBpZiAodFsyXSkgXy5vcHMucG9wKCk7XG4gICAgICAgICAgICAgICAgICBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBvcCA9IGJvZHkuY2FsbCh0aGlzQXJnLCBfKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHsgb3AgPSBbNiwgZV07IHkgPSAwOyB9IGZpbmFsbHkgeyBmID0gdCA9IDA7IH1cbiAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xuICB9XG59XG5cbmV4cG9ydCB2YXIgX19jcmVhdGVCaW5kaW5nID0gT2JqZWN0LmNyZWF0ZSA/IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xuICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICB2YXIgZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IobSwgayk7XG4gIGlmICghZGVzYyB8fCAoXCJnZXRcIiBpbiBkZXNjID8gIW0uX19lc01vZHVsZSA6IGRlc2Mud3JpdGFibGUgfHwgZGVzYy5jb25maWd1cmFibGUpKSB7XG4gICAgICBkZXNjID0geyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGZ1bmN0aW9uKCkgeyByZXR1cm4gbVtrXTsgfSB9O1xuICB9XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvLCBrMiwgZGVzYyk7XG59KSA6IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xuICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICBvW2syXSA9IG1ba107XG59KTtcblxuZXhwb3J0IGZ1bmN0aW9uIF9fZXhwb3J0U3RhcihtLCBvKSB7XG4gIGZvciAodmFyIHAgaW4gbSkgaWYgKHAgIT09IFwiZGVmYXVsdFwiICYmICFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwobywgcCkpIF9fY3JlYXRlQmluZGluZyhvLCBtLCBwKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fdmFsdWVzKG8pIHtcbiAgdmFyIHMgPSB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgU3ltYm9sLml0ZXJhdG9yLCBtID0gcyAmJiBvW3NdLCBpID0gMDtcbiAgaWYgKG0pIHJldHVybiBtLmNhbGwobyk7XG4gIGlmIChvICYmIHR5cGVvZiBvLmxlbmd0aCA9PT0gXCJudW1iZXJcIikgcmV0dXJuIHtcbiAgICAgIG5leHQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpZiAobyAmJiBpID49IG8ubGVuZ3RoKSBvID0gdm9pZCAwO1xuICAgICAgICAgIHJldHVybiB7IHZhbHVlOiBvICYmIG9baSsrXSwgZG9uZTogIW8gfTtcbiAgICAgIH1cbiAgfTtcbiAgdGhyb3cgbmV3IFR5cGVFcnJvcihzID8gXCJPYmplY3QgaXMgbm90IGl0ZXJhYmxlLlwiIDogXCJTeW1ib2wuaXRlcmF0b3IgaXMgbm90IGRlZmluZWQuXCIpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gX19yZWFkKG8sIG4pIHtcbiAgdmFyIG0gPSB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgb1tTeW1ib2wuaXRlcmF0b3JdO1xuICBpZiAoIW0pIHJldHVybiBvO1xuICB2YXIgaSA9IG0uY2FsbChvKSwgciwgYXIgPSBbXSwgZTtcbiAgdHJ5IHtcbiAgICAgIHdoaWxlICgobiA9PT0gdm9pZCAwIHx8IG4tLSA+IDApICYmICEociA9IGkubmV4dCgpKS5kb25lKSBhci5wdXNoKHIudmFsdWUpO1xuICB9XG4gIGNhdGNoIChlcnJvcikgeyBlID0geyBlcnJvcjogZXJyb3IgfTsgfVxuICBmaW5hbGx5IHtcbiAgICAgIHRyeSB7XG4gICAgICAgICAgaWYgKHIgJiYgIXIuZG9uZSAmJiAobSA9IGlbXCJyZXR1cm5cIl0pKSBtLmNhbGwoaSk7XG4gICAgICB9XG4gICAgICBmaW5hbGx5IHsgaWYgKGUpIHRocm93IGUuZXJyb3I7IH1cbiAgfVxuICByZXR1cm4gYXI7XG59XG5cbi8qKiBAZGVwcmVjYXRlZCAqL1xuZXhwb3J0IGZ1bmN0aW9uIF9fc3ByZWFkKCkge1xuICBmb3IgKHZhciBhciA9IFtdLCBpID0gMDsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKylcbiAgICAgIGFyID0gYXIuY29uY2F0KF9fcmVhZChhcmd1bWVudHNbaV0pKTtcbiAgcmV0dXJuIGFyO1xufVxuXG4vKiogQGRlcHJlY2F0ZWQgKi9cbmV4cG9ydCBmdW5jdGlvbiBfX3NwcmVhZEFycmF5cygpIHtcbiAgZm9yICh2YXIgcyA9IDAsIGkgPSAwLCBpbCA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBpbDsgaSsrKSBzICs9IGFyZ3VtZW50c1tpXS5sZW5ndGg7XG4gIGZvciAodmFyIHIgPSBBcnJheShzKSwgayA9IDAsIGkgPSAwOyBpIDwgaWw7IGkrKylcbiAgICAgIGZvciAodmFyIGEgPSBhcmd1bWVudHNbaV0sIGogPSAwLCBqbCA9IGEubGVuZ3RoOyBqIDwgamw7IGorKywgaysrKVxuICAgICAgICAgIHJba10gPSBhW2pdO1xuICByZXR1cm4gcjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fc3ByZWFkQXJyYXkodG8sIGZyb20sIHBhY2spIHtcbiAgaWYgKHBhY2sgfHwgYXJndW1lbnRzLmxlbmd0aCA9PT0gMikgZm9yICh2YXIgaSA9IDAsIGwgPSBmcm9tLmxlbmd0aCwgYXI7IGkgPCBsOyBpKyspIHtcbiAgICAgIGlmIChhciB8fCAhKGkgaW4gZnJvbSkpIHtcbiAgICAgICAgICBpZiAoIWFyKSBhciA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGZyb20sIDAsIGkpO1xuICAgICAgICAgIGFyW2ldID0gZnJvbVtpXTtcbiAgICAgIH1cbiAgfVxuICByZXR1cm4gdG8uY29uY2F0KGFyIHx8IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGZyb20pKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXQodikge1xuICByZXR1cm4gdGhpcyBpbnN0YW5jZW9mIF9fYXdhaXQgPyAodGhpcy52ID0gdiwgdGhpcykgOiBuZXcgX19hd2FpdCh2KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fYXN5bmNHZW5lcmF0b3IodGhpc0FyZywgX2FyZ3VtZW50cywgZ2VuZXJhdG9yKSB7XG4gIGlmICghU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNJdGVyYXRvciBpcyBub3QgZGVmaW5lZC5cIik7XG4gIHZhciBnID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pLCBpLCBxID0gW107XG4gIHJldHVybiBpID0gT2JqZWN0LmNyZWF0ZSgodHlwZW9mIEFzeW5jSXRlcmF0b3IgPT09IFwiZnVuY3Rpb25cIiA/IEFzeW5jSXRlcmF0b3IgOiBPYmplY3QpLnByb3RvdHlwZSksIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiksIHZlcmIoXCJyZXR1cm5cIiwgYXdhaXRSZXR1cm4pLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XG4gIGZ1bmN0aW9uIGF3YWl0UmV0dXJuKGYpIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBQcm9taXNlLnJlc29sdmUodikudGhlbihmLCByZWplY3QpOyB9OyB9XG4gIGZ1bmN0aW9uIHZlcmIobiwgZikgeyBpZiAoZ1tuXSkgeyBpW25dID0gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChhLCBiKSB7IHEucHVzaChbbiwgdiwgYSwgYl0pID4gMSB8fCByZXN1bWUobiwgdik7IH0pOyB9OyBpZiAoZikgaVtuXSA9IGYoaVtuXSk7IH0gfVxuICBmdW5jdGlvbiByZXN1bWUobiwgdikgeyB0cnkgeyBzdGVwKGdbbl0odikpOyB9IGNhdGNoIChlKSB7IHNldHRsZShxWzBdWzNdLCBlKTsgfSB9XG4gIGZ1bmN0aW9uIHN0ZXAocikgeyByLnZhbHVlIGluc3RhbmNlb2YgX19hd2FpdCA/IFByb21pc2UucmVzb2x2ZShyLnZhbHVlLnYpLnRoZW4oZnVsZmlsbCwgcmVqZWN0KSA6IHNldHRsZShxWzBdWzJdLCByKTsgfVxuICBmdW5jdGlvbiBmdWxmaWxsKHZhbHVlKSB7IHJlc3VtZShcIm5leHRcIiwgdmFsdWUpOyB9XG4gIGZ1bmN0aW9uIHJlamVjdCh2YWx1ZSkgeyByZXN1bWUoXCJ0aHJvd1wiLCB2YWx1ZSk7IH1cbiAgZnVuY3Rpb24gc2V0dGxlKGYsIHYpIHsgaWYgKGYodiksIHEuc2hpZnQoKSwgcS5sZW5ndGgpIHJlc3VtZShxWzBdWzBdLCBxWzBdWzFdKTsgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY0RlbGVnYXRvcihvKSB7XG4gIHZhciBpLCBwO1xuICByZXR1cm4gaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIsIGZ1bmN0aW9uIChlKSB7IHRocm93IGU7IH0pLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbiAoKSB7IHJldHVybiB0aGlzOyB9LCBpO1xuICBmdW5jdGlvbiB2ZXJiKG4sIGYpIHsgaVtuXSA9IG9bbl0gPyBmdW5jdGlvbiAodikgeyByZXR1cm4gKHAgPSAhcCkgPyB7IHZhbHVlOiBfX2F3YWl0KG9bbl0odikpLCBkb25lOiBmYWxzZSB9IDogZiA/IGYodikgOiB2OyB9IDogZjsgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY1ZhbHVlcyhvKSB7XG4gIGlmICghU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNJdGVyYXRvciBpcyBub3QgZGVmaW5lZC5cIik7XG4gIHZhciBtID0gb1tTeW1ib2wuYXN5bmNJdGVyYXRvcl0sIGk7XG4gIHJldHVybiBtID8gbS5jYWxsKG8pIDogKG8gPSB0eXBlb2YgX192YWx1ZXMgPT09IFwiZnVuY3Rpb25cIiA/IF9fdmFsdWVzKG8pIDogb1tTeW1ib2wuaXRlcmF0b3JdKCksIGkgPSB7fSwgdmVyYihcIm5leHRcIiksIHZlcmIoXCJ0aHJvd1wiKSwgdmVyYihcInJldHVyblwiKSwgaVtTeW1ib2wuYXN5bmNJdGVyYXRvcl0gPSBmdW5jdGlvbiAoKSB7IHJldHVybiB0aGlzOyB9LCBpKTtcbiAgZnVuY3Rpb24gdmVyYihuKSB7IGlbbl0gPSBvW25dICYmIGZ1bmN0aW9uICh2KSB7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7IHYgPSBvW25dKHYpLCBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCB2LmRvbmUsIHYudmFsdWUpOyB9KTsgfTsgfVxuICBmdW5jdGlvbiBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCBkLCB2KSB7IFByb21pc2UucmVzb2x2ZSh2KS50aGVuKGZ1bmN0aW9uKHYpIHsgcmVzb2x2ZSh7IHZhbHVlOiB2LCBkb25lOiBkIH0pOyB9LCByZWplY3QpOyB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX21ha2VUZW1wbGF0ZU9iamVjdChjb29rZWQsIHJhdykge1xuICBpZiAoT2JqZWN0LmRlZmluZVByb3BlcnR5KSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjb29rZWQsIFwicmF3XCIsIHsgdmFsdWU6IHJhdyB9KTsgfSBlbHNlIHsgY29va2VkLnJhdyA9IHJhdzsgfVxuICByZXR1cm4gY29va2VkO1xufTtcblxudmFyIF9fc2V0TW9kdWxlRGVmYXVsdCA9IE9iamVjdC5jcmVhdGUgPyAoZnVuY3Rpb24obywgdikge1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkobywgXCJkZWZhdWx0XCIsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHYgfSk7XG59KSA6IGZ1bmN0aW9uKG8sIHYpIHtcbiAgb1tcImRlZmF1bHRcIl0gPSB2O1xufTtcblxudmFyIG93bktleXMgPSBmdW5jdGlvbihvKSB7XG4gIG93bktleXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyB8fCBmdW5jdGlvbiAobykge1xuICAgIHZhciBhciA9IFtdO1xuICAgIGZvciAodmFyIGsgaW4gbykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvLCBrKSkgYXJbYXIubGVuZ3RoXSA9IGs7XG4gICAgcmV0dXJuIGFyO1xuICB9O1xuICByZXR1cm4gb3duS2V5cyhvKTtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2ltcG9ydFN0YXIobW9kKSB7XG4gIGlmIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpIHJldHVybiBtb2Q7XG4gIHZhciByZXN1bHQgPSB7fTtcbiAgaWYgKG1vZCAhPSBudWxsKSBmb3IgKHZhciBrID0gb3duS2V5cyhtb2QpLCBpID0gMDsgaSA8IGsubGVuZ3RoOyBpKyspIGlmIChrW2ldICE9PSBcImRlZmF1bHRcIikgX19jcmVhdGVCaW5kaW5nKHJlc3VsdCwgbW9kLCBrW2ldKTtcbiAgX19zZXRNb2R1bGVEZWZhdWx0KHJlc3VsdCwgbW9kKTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9faW1wb3J0RGVmYXVsdChtb2QpIHtcbiAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBkZWZhdWx0OiBtb2QgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fY2xhc3NQcml2YXRlRmllbGRHZXQocmVjZWl2ZXIsIHN0YXRlLCBraW5kLCBmKSB7XG4gIGlmIChraW5kID09PSBcImFcIiAmJiAhZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgYWNjZXNzb3Igd2FzIGRlZmluZWQgd2l0aG91dCBhIGdldHRlclwiKTtcbiAgaWYgKHR5cGVvZiBzdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gcmVjZWl2ZXIgIT09IHN0YXRlIHx8ICFmIDogIXN0YXRlLmhhcyhyZWNlaXZlcikpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgcmVhZCBwcml2YXRlIG1lbWJlciBmcm9tIGFuIG9iamVjdCB3aG9zZSBjbGFzcyBkaWQgbm90IGRlY2xhcmUgaXRcIik7XG4gIHJldHVybiBraW5kID09PSBcIm1cIiA/IGYgOiBraW5kID09PSBcImFcIiA/IGYuY2FsbChyZWNlaXZlcikgOiBmID8gZi52YWx1ZSA6IHN0YXRlLmdldChyZWNlaXZlcik7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHJlY2VpdmVyLCBzdGF0ZSwgdmFsdWUsIGtpbmQsIGYpIHtcbiAgaWYgKGtpbmQgPT09IFwibVwiKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiUHJpdmF0ZSBtZXRob2QgaXMgbm90IHdyaXRhYmxlXCIpO1xuICBpZiAoa2luZCA9PT0gXCJhXCIgJiYgIWYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJQcml2YXRlIGFjY2Vzc29yIHdhcyBkZWZpbmVkIHdpdGhvdXQgYSBzZXR0ZXJcIik7XG4gIGlmICh0eXBlb2Ygc3RhdGUgPT09IFwiZnVuY3Rpb25cIiA/IHJlY2VpdmVyICE9PSBzdGF0ZSB8fCAhZiA6ICFzdGF0ZS5oYXMocmVjZWl2ZXIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IHdyaXRlIHByaXZhdGUgbWVtYmVyIHRvIGFuIG9iamVjdCB3aG9zZSBjbGFzcyBkaWQgbm90IGRlY2xhcmUgaXRcIik7XG4gIHJldHVybiAoa2luZCA9PT0gXCJhXCIgPyBmLmNhbGwocmVjZWl2ZXIsIHZhbHVlKSA6IGYgPyBmLnZhbHVlID0gdmFsdWUgOiBzdGF0ZS5zZXQocmVjZWl2ZXIsIHZhbHVlKSksIHZhbHVlO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gX19jbGFzc1ByaXZhdGVGaWVsZEluKHN0YXRlLCByZWNlaXZlcikge1xuICBpZiAocmVjZWl2ZXIgPT09IG51bGwgfHwgKHR5cGVvZiByZWNlaXZlciAhPT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgcmVjZWl2ZXIgIT09IFwiZnVuY3Rpb25cIikpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgdXNlICdpbicgb3BlcmF0b3Igb24gbm9uLW9iamVjdFwiKTtcbiAgcmV0dXJuIHR5cGVvZiBzdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gcmVjZWl2ZXIgPT09IHN0YXRlIDogc3RhdGUuaGFzKHJlY2VpdmVyKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fYWRkRGlzcG9zYWJsZVJlc291cmNlKGVudiwgdmFsdWUsIGFzeW5jKSB7XG4gIGlmICh2YWx1ZSAhPT0gbnVsbCAmJiB2YWx1ZSAhPT0gdm9pZCAwKSB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgdmFsdWUgIT09IFwiZnVuY3Rpb25cIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIk9iamVjdCBleHBlY3RlZC5cIik7XG4gICAgdmFyIGRpc3Bvc2UsIGlubmVyO1xuICAgIGlmIChhc3luYykge1xuICAgICAgaWYgKCFTeW1ib2wuYXN5bmNEaXNwb3NlKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiU3ltYm9sLmFzeW5jRGlzcG9zZSBpcyBub3QgZGVmaW5lZC5cIik7XG4gICAgICBkaXNwb3NlID0gdmFsdWVbU3ltYm9sLmFzeW5jRGlzcG9zZV07XG4gICAgfVxuICAgIGlmIChkaXNwb3NlID09PSB2b2lkIDApIHtcbiAgICAgIGlmICghU3ltYm9sLmRpc3Bvc2UpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuZGlzcG9zZSBpcyBub3QgZGVmaW5lZC5cIik7XG4gICAgICBkaXNwb3NlID0gdmFsdWVbU3ltYm9sLmRpc3Bvc2VdO1xuICAgICAgaWYgKGFzeW5jKSBpbm5lciA9IGRpc3Bvc2U7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgZGlzcG9zZSAhPT0gXCJmdW5jdGlvblwiKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiT2JqZWN0IG5vdCBkaXNwb3NhYmxlLlwiKTtcbiAgICBpZiAoaW5uZXIpIGRpc3Bvc2UgPSBmdW5jdGlvbigpIHsgdHJ5IHsgaW5uZXIuY2FsbCh0aGlzKTsgfSBjYXRjaCAoZSkgeyByZXR1cm4gUHJvbWlzZS5yZWplY3QoZSk7IH0gfTtcbiAgICBlbnYuc3RhY2sucHVzaCh7IHZhbHVlOiB2YWx1ZSwgZGlzcG9zZTogZGlzcG9zZSwgYXN5bmM6IGFzeW5jIH0pO1xuICB9XG4gIGVsc2UgaWYgKGFzeW5jKSB7XG4gICAgZW52LnN0YWNrLnB1c2goeyBhc3luYzogdHJ1ZSB9KTtcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59XG5cbnZhciBfU3VwcHJlc3NlZEVycm9yID0gdHlwZW9mIFN1cHByZXNzZWRFcnJvciA9PT0gXCJmdW5jdGlvblwiID8gU3VwcHJlc3NlZEVycm9yIDogZnVuY3Rpb24gKGVycm9yLCBzdXBwcmVzc2VkLCBtZXNzYWdlKSB7XG4gIHZhciBlID0gbmV3IEVycm9yKG1lc3NhZ2UpO1xuICByZXR1cm4gZS5uYW1lID0gXCJTdXBwcmVzc2VkRXJyb3JcIiwgZS5lcnJvciA9IGVycm9yLCBlLnN1cHByZXNzZWQgPSBzdXBwcmVzc2VkLCBlO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIF9fZGlzcG9zZVJlc291cmNlcyhlbnYpIHtcbiAgZnVuY3Rpb24gZmFpbChlKSB7XG4gICAgZW52LmVycm9yID0gZW52Lmhhc0Vycm9yID8gbmV3IF9TdXBwcmVzc2VkRXJyb3IoZSwgZW52LmVycm9yLCBcIkFuIGVycm9yIHdhcyBzdXBwcmVzc2VkIGR1cmluZyBkaXNwb3NhbC5cIikgOiBlO1xuICAgIGVudi5oYXNFcnJvciA9IHRydWU7XG4gIH1cbiAgdmFyIHIsIHMgPSAwO1xuICBmdW5jdGlvbiBuZXh0KCkge1xuICAgIHdoaWxlIChyID0gZW52LnN0YWNrLnBvcCgpKSB7XG4gICAgICB0cnkge1xuICAgICAgICBpZiAoIXIuYXN5bmMgJiYgcyA9PT0gMSkgcmV0dXJuIHMgPSAwLCBlbnYuc3RhY2sucHVzaChyKSwgUHJvbWlzZS5yZXNvbHZlKCkudGhlbihuZXh0KTtcbiAgICAgICAgaWYgKHIuZGlzcG9zZSkge1xuICAgICAgICAgIHZhciByZXN1bHQgPSByLmRpc3Bvc2UuY2FsbChyLnZhbHVlKTtcbiAgICAgICAgICBpZiAoci5hc3luYykgcmV0dXJuIHMgfD0gMiwgUHJvbWlzZS5yZXNvbHZlKHJlc3VsdCkudGhlbihuZXh0LCBmdW5jdGlvbihlKSB7IGZhaWwoZSk7IHJldHVybiBuZXh0KCk7IH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgcyB8PSAxO1xuICAgICAgfVxuICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgZmFpbChlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHMgPT09IDEpIHJldHVybiBlbnYuaGFzRXJyb3IgPyBQcm9taXNlLnJlamVjdChlbnYuZXJyb3IpIDogUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgaWYgKGVudi5oYXNFcnJvcikgdGhyb3cgZW52LmVycm9yO1xuICB9XG4gIHJldHVybiBuZXh0KCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX3Jld3JpdGVSZWxhdGl2ZUltcG9ydEV4dGVuc2lvbihwYXRoLCBwcmVzZXJ2ZUpzeCkge1xuICBpZiAodHlwZW9mIHBhdGggPT09IFwic3RyaW5nXCIgJiYgL15cXC5cXC4/XFwvLy50ZXN0KHBhdGgpKSB7XG4gICAgICByZXR1cm4gcGF0aC5yZXBsYWNlKC9cXC4odHN4KSR8KCg/OlxcLmQpPykoKD86XFwuW14uL10rPyk/KVxcLihbY21dPyl0cyQvaSwgZnVuY3Rpb24gKG0sIHRzeCwgZCwgZXh0LCBjbSkge1xuICAgICAgICAgIHJldHVybiB0c3ggPyBwcmVzZXJ2ZUpzeCA/IFwiLmpzeFwiIDogXCIuanNcIiA6IGQgJiYgKCFleHQgfHwgIWNtKSA/IG0gOiAoZCArIGV4dCArIFwiLlwiICsgY20udG9Mb3dlckNhc2UoKSArIFwianNcIik7XG4gICAgICB9KTtcbiAgfVxuICByZXR1cm4gcGF0aDtcbn1cblxuZXhwb3J0IGRlZmF1bHQge1xuICBfX2V4dGVuZHMsXG4gIF9fYXNzaWduLFxuICBfX3Jlc3QsXG4gIF9fZGVjb3JhdGUsXG4gIF9fcGFyYW0sXG4gIF9fZXNEZWNvcmF0ZSxcbiAgX19ydW5Jbml0aWFsaXplcnMsXG4gIF9fcHJvcEtleSxcbiAgX19zZXRGdW5jdGlvbk5hbWUsXG4gIF9fbWV0YWRhdGEsXG4gIF9fYXdhaXRlcixcbiAgX19nZW5lcmF0b3IsXG4gIF9fY3JlYXRlQmluZGluZyxcbiAgX19leHBvcnRTdGFyLFxuICBfX3ZhbHVlcyxcbiAgX19yZWFkLFxuICBfX3NwcmVhZCxcbiAgX19zcHJlYWRBcnJheXMsXG4gIF9fc3ByZWFkQXJyYXksXG4gIF9fYXdhaXQsXG4gIF9fYXN5bmNHZW5lcmF0b3IsXG4gIF9fYXN5bmNEZWxlZ2F0b3IsXG4gIF9fYXN5bmNWYWx1ZXMsXG4gIF9fbWFrZVRlbXBsYXRlT2JqZWN0LFxuICBfX2ltcG9ydFN0YXIsXG4gIF9faW1wb3J0RGVmYXVsdCxcbiAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCxcbiAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCxcbiAgX19jbGFzc1ByaXZhdGVGaWVsZEluLFxuICBfX2FkZERpc3Bvc2FibGVSZXNvdXJjZSxcbiAgX19kaXNwb3NlUmVzb3VyY2VzLFxuICBfX3Jld3JpdGVSZWxhdGl2ZUltcG9ydEV4dGVuc2lvbixcbn07XG4iLCJleHBvcnQgdmFyIHplcm9SaWdodENsYXNzTmFtZSA9ICdyaWdodC1zY3JvbGwtYmFyLXBvc2l0aW9uJztcbmV4cG9ydCB2YXIgZnVsbFdpZHRoQ2xhc3NOYW1lID0gJ3dpZHRoLWJlZm9yZS1zY3JvbGwtYmFyJztcbmV4cG9ydCB2YXIgbm9TY3JvbGxiYXJzQ2xhc3NOYW1lID0gJ3dpdGgtc2Nyb2xsLWJhcnMtaGlkZGVuJztcbi8qKlxuICogTmFtZSBvZiBhIENTUyB2YXJpYWJsZSBjb250YWluaW5nIHRoZSBhbW91bnQgb2YgXCJoaWRkZW5cIiBzY3JvbGxiYXJcbiAqICEgbWlnaHQgYmUgdW5kZWZpbmVkICEgdXNlIHdpbGwgZmFsbGJhY2shXG4gKi9cbmV4cG9ydCB2YXIgcmVtb3ZlZEJhclNpemVWYXJpYWJsZSA9ICctLXJlbW92ZWQtYm9keS1zY3JvbGwtYmFyLXNpemUnO1xuIiwiLyoqXG4gKiBBc3NpZ25zIGEgdmFsdWUgZm9yIGEgZ2l2ZW4gcmVmLCBubyBtYXR0ZXIgb2YgdGhlIHJlZiBmb3JtYXRcbiAqIEBwYXJhbSB7UmVmT2JqZWN0fSByZWYgLSBhIGNhbGxiYWNrIGZ1bmN0aW9uIG9yIHJlZiBvYmplY3RcbiAqIEBwYXJhbSB2YWx1ZSAtIGEgbmV3IHZhbHVlXG4gKlxuICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vdGhlS2FzaGV5L3VzZS1jYWxsYmFjay1yZWYjYXNzaWducmVmXG4gKiBAZXhhbXBsZVxuICogY29uc3QgcmVmT2JqZWN0ID0gdXNlUmVmKCk7XG4gKiBjb25zdCByZWZGbiA9IChyZWYpID0+IHsuLi4ufVxuICpcbiAqIGFzc2lnblJlZihyZWZPYmplY3QsIFwicmVmVmFsdWVcIik7XG4gKiBhc3NpZ25SZWYocmVmRm4sIFwicmVmVmFsdWVcIik7XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhc3NpZ25SZWYocmVmLCB2YWx1ZSkge1xuICAgIGlmICh0eXBlb2YgcmVmID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIHJlZih2YWx1ZSk7XG4gICAgfVxuICAgIGVsc2UgaWYgKHJlZikge1xuICAgICAgICByZWYuY3VycmVudCA9IHZhbHVlO1xuICAgIH1cbiAgICByZXR1cm4gcmVmO1xufVxuIiwiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG4vKipcbiAqIGNyZWF0ZXMgYSBNdXRhYmxlUmVmIHdpdGggcmVmIGNoYW5nZSBjYWxsYmFja1xuICogQHBhcmFtIGluaXRpYWxWYWx1ZSAtIGluaXRpYWwgcmVmIHZhbHVlXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayAtIGEgY2FsbGJhY2sgdG8gcnVuIHdoZW4gdmFsdWUgY2hhbmdlc1xuICpcbiAqIEBleGFtcGxlXG4gKiBjb25zdCByZWYgPSB1c2VDYWxsYmFja1JlZigwLCAobmV3VmFsdWUsIG9sZFZhbHVlKSA9PiBjb25zb2xlLmxvZyhvbGRWYWx1ZSwgJy0+JywgbmV3VmFsdWUpO1xuICogcmVmLmN1cnJlbnQgPSAxO1xuICogLy8gcHJpbnRzIDAgLT4gMVxuICpcbiAqIEBzZWUgaHR0cHM6Ly9yZWFjdGpzLm9yZy9kb2NzL2hvb2tzLXJlZmVyZW5jZS5odG1sI3VzZXJlZlxuICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vdGhlS2FzaGV5L3VzZS1jYWxsYmFjay1yZWYjdXNlY2FsbGJhY2tyZWYtLS10by1yZXBsYWNlLXJlYWN0dXNlcmVmXG4gKiBAcmV0dXJucyB7TXV0YWJsZVJlZk9iamVjdH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUNhbGxiYWNrUmVmKGluaXRpYWxWYWx1ZSwgY2FsbGJhY2spIHtcbiAgICB2YXIgcmVmID0gdXNlU3RhdGUoZnVuY3Rpb24gKCkgeyByZXR1cm4gKHtcbiAgICAgICAgLy8gdmFsdWVcbiAgICAgICAgdmFsdWU6IGluaXRpYWxWYWx1ZSxcbiAgICAgICAgLy8gbGFzdCBjYWxsYmFja1xuICAgICAgICBjYWxsYmFjazogY2FsbGJhY2ssXG4gICAgICAgIC8vIFwibWVtb2l6ZWRcIiBwdWJsaWMgaW50ZXJmYWNlXG4gICAgICAgIGZhY2FkZToge1xuICAgICAgICAgICAgZ2V0IGN1cnJlbnQoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlZi52YWx1ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzZXQgY3VycmVudCh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIHZhciBsYXN0ID0gcmVmLnZhbHVlO1xuICAgICAgICAgICAgICAgIGlmIChsYXN0ICE9PSB2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICByZWYudmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgcmVmLmNhbGxiYWNrKHZhbHVlLCBsYXN0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgIH0pOyB9KVswXTtcbiAgICAvLyB1cGRhdGUgY2FsbGJhY2tcbiAgICByZWYuY2FsbGJhY2sgPSBjYWxsYmFjaztcbiAgICByZXR1cm4gcmVmLmZhY2FkZTtcbn1cbiIsImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGFzc2lnblJlZiB9IGZyb20gJy4vYXNzaWduUmVmJztcbmltcG9ydCB7IHVzZUNhbGxiYWNrUmVmIH0gZnJvbSAnLi91c2VSZWYnO1xudmFyIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IFJlYWN0LnVzZUxheW91dEVmZmVjdCA6IFJlYWN0LnVzZUVmZmVjdDtcbnZhciBjdXJyZW50VmFsdWVzID0gbmV3IFdlYWtNYXAoKTtcbi8qKlxuICogTWVyZ2VzIHR3byBvciBtb3JlIHJlZnMgdG9nZXRoZXIgcHJvdmlkaW5nIGEgc2luZ2xlIGludGVyZmFjZSB0byBzZXQgdGhlaXIgdmFsdWVcbiAqIEBwYXJhbSB7UmVmT2JqZWN0fFJlZn0gcmVmc1xuICogQHJldHVybnMge011dGFibGVSZWZPYmplY3R9IC0gYSBuZXcgcmVmLCB3aGljaCB0cmFuc2xhdGVzIGFsbCBjaGFuZ2VzIHRvIHtyZWZzfVxuICpcbiAqIEBzZWUge0BsaW5rIG1lcmdlUmVmc30gYSB2ZXJzaW9uIHdpdGhvdXQgYnVpdC1pbiBtZW1vaXphdGlvblxuICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vdGhlS2FzaGV5L3VzZS1jYWxsYmFjay1yZWYjdXNlbWVyZ2VyZWZzXG4gKiBAZXhhbXBsZVxuICogY29uc3QgQ29tcG9uZW50ID0gUmVhY3QuZm9yd2FyZFJlZigocHJvcHMsIHJlZikgPT4ge1xuICogICBjb25zdCBvd25SZWYgPSB1c2VSZWYoKTtcbiAqICAgY29uc3QgZG9tUmVmID0gdXNlTWVyZ2VSZWZzKFtyZWYsIG93blJlZl0pOyAvLyDwn5GIIG1lcmdlIHRvZ2V0aGVyXG4gKiAgIHJldHVybiA8ZGl2IHJlZj17ZG9tUmVmfT4uLi48L2Rpdj5cbiAqIH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZU1lcmdlUmVmcyhyZWZzLCBkZWZhdWx0VmFsdWUpIHtcbiAgICB2YXIgY2FsbGJhY2tSZWYgPSB1c2VDYWxsYmFja1JlZihkZWZhdWx0VmFsdWUgfHwgbnVsbCwgZnVuY3Rpb24gKG5ld1ZhbHVlKSB7XG4gICAgICAgIHJldHVybiByZWZzLmZvckVhY2goZnVuY3Rpb24gKHJlZikgeyByZXR1cm4gYXNzaWduUmVmKHJlZiwgbmV3VmFsdWUpOyB9KTtcbiAgICB9KTtcbiAgICAvLyBoYW5kbGUgcmVmcyBjaGFuZ2VzIC0gYWRkZWQgb3IgcmVtb3ZlZFxuICAgIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgb2xkVmFsdWUgPSBjdXJyZW50VmFsdWVzLmdldChjYWxsYmFja1JlZik7XG4gICAgICAgIGlmIChvbGRWYWx1ZSkge1xuICAgICAgICAgICAgdmFyIHByZXZSZWZzXzEgPSBuZXcgU2V0KG9sZFZhbHVlKTtcbiAgICAgICAgICAgIHZhciBuZXh0UmVmc18xID0gbmV3IFNldChyZWZzKTtcbiAgICAgICAgICAgIHZhciBjdXJyZW50XzEgPSBjYWxsYmFja1JlZi5jdXJyZW50O1xuICAgICAgICAgICAgcHJldlJlZnNfMS5mb3JFYWNoKGZ1bmN0aW9uIChyZWYpIHtcbiAgICAgICAgICAgICAgICBpZiAoIW5leHRSZWZzXzEuaGFzKHJlZikpIHtcbiAgICAgICAgICAgICAgICAgICAgYXNzaWduUmVmKHJlZiwgbnVsbCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBuZXh0UmVmc18xLmZvckVhY2goZnVuY3Rpb24gKHJlZikge1xuICAgICAgICAgICAgICAgIGlmICghcHJldlJlZnNfMS5oYXMocmVmKSkge1xuICAgICAgICAgICAgICAgICAgICBhc3NpZ25SZWYocmVmLCBjdXJyZW50XzEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGN1cnJlbnRWYWx1ZXMuc2V0KGNhbGxiYWNrUmVmLCByZWZzKTtcbiAgICB9LCBbcmVmc10pO1xuICAgIHJldHVybiBjYWxsYmFja1JlZjtcbn1cbiIsImltcG9ydCB7IF9fYXNzaWduIH0gZnJvbSBcInRzbGliXCI7XG5mdW5jdGlvbiBJdG9JKGEpIHtcbiAgICByZXR1cm4gYTtcbn1cbmZ1bmN0aW9uIGlubmVyQ3JlYXRlTWVkaXVtKGRlZmF1bHRzLCBtaWRkbGV3YXJlKSB7XG4gICAgaWYgKG1pZGRsZXdhcmUgPT09IHZvaWQgMCkgeyBtaWRkbGV3YXJlID0gSXRvSTsgfVxuICAgIHZhciBidWZmZXIgPSBbXTtcbiAgICB2YXIgYXNzaWduZWQgPSBmYWxzZTtcbiAgICB2YXIgbWVkaXVtID0ge1xuICAgICAgICByZWFkOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoYXNzaWduZWQpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1NpZGVjYXI6IGNvdWxkIG5vdCBgcmVhZGAgZnJvbSBhbiBgYXNzaWduZWRgIG1lZGl1bS4gYHJlYWRgIGNvdWxkIGJlIHVzZWQgb25seSB3aXRoIGB1c2VNZWRpdW1gLicpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGJ1ZmZlci5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYnVmZmVyW2J1ZmZlci5sZW5ndGggLSAxXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBkZWZhdWx0cztcbiAgICAgICAgfSxcbiAgICAgICAgdXNlTWVkaXVtOiBmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgdmFyIGl0ZW0gPSBtaWRkbGV3YXJlKGRhdGEsIGFzc2lnbmVkKTtcbiAgICAgICAgICAgIGJ1ZmZlci5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBidWZmZXIgPSBidWZmZXIuZmlsdGVyKGZ1bmN0aW9uICh4KSB7IHJldHVybiB4ICE9PSBpdGVtOyB9KTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0sXG4gICAgICAgIGFzc2lnblN5bmNNZWRpdW06IGZ1bmN0aW9uIChjYikge1xuICAgICAgICAgICAgYXNzaWduZWQgPSB0cnVlO1xuICAgICAgICAgICAgd2hpbGUgKGJ1ZmZlci5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICB2YXIgY2JzID0gYnVmZmVyO1xuICAgICAgICAgICAgICAgIGJ1ZmZlciA9IFtdO1xuICAgICAgICAgICAgICAgIGNicy5mb3JFYWNoKGNiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJ1ZmZlciA9IHtcbiAgICAgICAgICAgICAgICBwdXNoOiBmdW5jdGlvbiAoeCkgeyByZXR1cm4gY2IoeCk7IH0sXG4gICAgICAgICAgICAgICAgZmlsdGVyOiBmdW5jdGlvbiAoKSB7IHJldHVybiBidWZmZXI7IH0sXG4gICAgICAgICAgICB9O1xuICAgICAgICB9LFxuICAgICAgICBhc3NpZ25NZWRpdW06IGZ1bmN0aW9uIChjYikge1xuICAgICAgICAgICAgYXNzaWduZWQgPSB0cnVlO1xuICAgICAgICAgICAgdmFyIHBlbmRpbmdRdWV1ZSA9IFtdO1xuICAgICAgICAgICAgaWYgKGJ1ZmZlci5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICB2YXIgY2JzID0gYnVmZmVyO1xuICAgICAgICAgICAgICAgIGJ1ZmZlciA9IFtdO1xuICAgICAgICAgICAgICAgIGNicy5mb3JFYWNoKGNiKTtcbiAgICAgICAgICAgICAgICBwZW5kaW5nUXVldWUgPSBidWZmZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgZXhlY3V0ZVF1ZXVlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHZhciBjYnMgPSBwZW5kaW5nUXVldWU7XG4gICAgICAgICAgICAgICAgcGVuZGluZ1F1ZXVlID0gW107XG4gICAgICAgICAgICAgICAgY2JzLmZvckVhY2goY2IpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHZhciBjeWNsZSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpLnRoZW4oZXhlY3V0ZVF1ZXVlKTsgfTtcbiAgICAgICAgICAgIGN5Y2xlKCk7XG4gICAgICAgICAgICBidWZmZXIgPSB7XG4gICAgICAgICAgICAgICAgcHVzaDogZnVuY3Rpb24gKHgpIHtcbiAgICAgICAgICAgICAgICAgICAgcGVuZGluZ1F1ZXVlLnB1c2goeCk7XG4gICAgICAgICAgICAgICAgICAgIGN5Y2xlKCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBmaWx0ZXI6IGZ1bmN0aW9uIChmaWx0ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgcGVuZGluZ1F1ZXVlID0gcGVuZGluZ1F1ZXVlLmZpbHRlcihmaWx0ZXIpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYnVmZmVyO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9O1xuICAgICAgICB9LFxuICAgIH07XG4gICAgcmV0dXJuIG1lZGl1bTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVNZWRpdW0oZGVmYXVsdHMsIG1pZGRsZXdhcmUpIHtcbiAgICBpZiAobWlkZGxld2FyZSA9PT0gdm9pZCAwKSB7IG1pZGRsZXdhcmUgPSBJdG9JOyB9XG4gICAgcmV0dXJuIGlubmVyQ3JlYXRlTWVkaXVtKGRlZmF1bHRzLCBtaWRkbGV3YXJlKTtcbn1cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXR5cGVzXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlU2lkZWNhck1lZGl1bShvcHRpb25zKSB7XG4gICAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkgeyBvcHRpb25zID0ge307IH1cbiAgICB2YXIgbWVkaXVtID0gaW5uZXJDcmVhdGVNZWRpdW0obnVsbCk7XG4gICAgbWVkaXVtLm9wdGlvbnMgPSBfX2Fzc2lnbih7IGFzeW5jOiB0cnVlLCBzc3I6IGZhbHNlIH0sIG9wdGlvbnMpO1xuICAgIHJldHVybiBtZWRpdW07XG59XG4iLCJpbXBvcnQgeyBfX2Fzc2lnbiwgX19yZXN0IH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG52YXIgU2lkZUNhciA9IGZ1bmN0aW9uIChfYSkge1xuICAgIHZhciBzaWRlQ2FyID0gX2Euc2lkZUNhciwgcmVzdCA9IF9fcmVzdChfYSwgW1wic2lkZUNhclwiXSk7XG4gICAgaWYgKCFzaWRlQ2FyKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignU2lkZWNhcjogcGxlYXNlIHByb3ZpZGUgYHNpZGVDYXJgIHByb3BlcnR5IHRvIGltcG9ydCB0aGUgcmlnaHQgY2FyJyk7XG4gICAgfVxuICAgIHZhciBUYXJnZXQgPSBzaWRlQ2FyLnJlYWQoKTtcbiAgICBpZiAoIVRhcmdldCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1NpZGVjYXIgbWVkaXVtIG5vdCBmb3VuZCcpO1xuICAgIH1cbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChUYXJnZXQsIF9fYXNzaWduKHt9LCByZXN0KSk7XG59O1xuU2lkZUNhci5pc1NpZGVDYXJFeHBvcnQgPSB0cnVlO1xuZXhwb3J0IGZ1bmN0aW9uIGV4cG9ydFNpZGVjYXIobWVkaXVtLCBleHBvcnRlZCkge1xuICAgIG1lZGl1bS51c2VNZWRpdW0oZXhwb3J0ZWQpO1xuICAgIHJldHVybiBTaWRlQ2FyO1xufVxuIiwiaW1wb3J0IHsgY3JlYXRlU2lkZWNhck1lZGl1bSB9IGZyb20gJ3VzZS1zaWRlY2FyJztcbmV4cG9ydCB2YXIgZWZmZWN0Q2FyID0gY3JlYXRlU2lkZWNhck1lZGl1bSgpO1xuIiwiaW1wb3J0IHsgX19hc3NpZ24sIF9fcmVzdCB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZnVsbFdpZHRoQ2xhc3NOYW1lLCB6ZXJvUmlnaHRDbGFzc05hbWUgfSBmcm9tICdyZWFjdC1yZW1vdmUtc2Nyb2xsLWJhci9jb25zdGFudHMnO1xuaW1wb3J0IHsgdXNlTWVyZ2VSZWZzIH0gZnJvbSAndXNlLWNhbGxiYWNrLXJlZic7XG5pbXBvcnQgeyBlZmZlY3RDYXIgfSBmcm9tICcuL21lZGl1bSc7XG52YXIgbm90aGluZyA9IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm47XG59O1xuLyoqXG4gKiBSZW1vdmVzIHNjcm9sbGJhciBmcm9tIHRoZSBwYWdlIGFuZCBjb250YWluIHRoZSBzY3JvbGwgd2l0aGluIHRoZSBMb2NrXG4gKi9cbnZhciBSZW1vdmVTY3JvbGwgPSBSZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIChwcm9wcywgcGFyZW50UmVmKSB7XG4gICAgdmFyIHJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgICB2YXIgX2EgPSBSZWFjdC51c2VTdGF0ZSh7XG4gICAgICAgIG9uU2Nyb2xsQ2FwdHVyZTogbm90aGluZyxcbiAgICAgICAgb25XaGVlbENhcHR1cmU6IG5vdGhpbmcsXG4gICAgICAgIG9uVG91Y2hNb3ZlQ2FwdHVyZTogbm90aGluZyxcbiAgICB9KSwgY2FsbGJhY2tzID0gX2FbMF0sIHNldENhbGxiYWNrcyA9IF9hWzFdO1xuICAgIHZhciBmb3J3YXJkUHJvcHMgPSBwcm9wcy5mb3J3YXJkUHJvcHMsIGNoaWxkcmVuID0gcHJvcHMuY2hpbGRyZW4sIGNsYXNzTmFtZSA9IHByb3BzLmNsYXNzTmFtZSwgcmVtb3ZlU2Nyb2xsQmFyID0gcHJvcHMucmVtb3ZlU2Nyb2xsQmFyLCBlbmFibGVkID0gcHJvcHMuZW5hYmxlZCwgc2hhcmRzID0gcHJvcHMuc2hhcmRzLCBzaWRlQ2FyID0gcHJvcHMuc2lkZUNhciwgbm9SZWxhdGl2ZSA9IHByb3BzLm5vUmVsYXRpdmUsIG5vSXNvbGF0aW9uID0gcHJvcHMubm9Jc29sYXRpb24sIGluZXJ0ID0gcHJvcHMuaW5lcnQsIGFsbG93UGluY2hab29tID0gcHJvcHMuYWxsb3dQaW5jaFpvb20sIF9iID0gcHJvcHMuYXMsIENvbnRhaW5lciA9IF9iID09PSB2b2lkIDAgPyAnZGl2JyA6IF9iLCBnYXBNb2RlID0gcHJvcHMuZ2FwTW9kZSwgcmVzdCA9IF9fcmVzdChwcm9wcywgW1wiZm9yd2FyZFByb3BzXCIsIFwiY2hpbGRyZW5cIiwgXCJjbGFzc05hbWVcIiwgXCJyZW1vdmVTY3JvbGxCYXJcIiwgXCJlbmFibGVkXCIsIFwic2hhcmRzXCIsIFwic2lkZUNhclwiLCBcIm5vUmVsYXRpdmVcIiwgXCJub0lzb2xhdGlvblwiLCBcImluZXJ0XCIsIFwiYWxsb3dQaW5jaFpvb21cIiwgXCJhc1wiLCBcImdhcE1vZGVcIl0pO1xuICAgIHZhciBTaWRlQ2FyID0gc2lkZUNhcjtcbiAgICB2YXIgY29udGFpbmVyUmVmID0gdXNlTWVyZ2VSZWZzKFtyZWYsIHBhcmVudFJlZl0pO1xuICAgIHZhciBjb250YWluZXJQcm9wcyA9IF9fYXNzaWduKF9fYXNzaWduKHt9LCByZXN0KSwgY2FsbGJhY2tzKTtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsXG4gICAgICAgIGVuYWJsZWQgJiYgKFJlYWN0LmNyZWF0ZUVsZW1lbnQoU2lkZUNhciwgeyBzaWRlQ2FyOiBlZmZlY3RDYXIsIHJlbW92ZVNjcm9sbEJhcjogcmVtb3ZlU2Nyb2xsQmFyLCBzaGFyZHM6IHNoYXJkcywgbm9SZWxhdGl2ZTogbm9SZWxhdGl2ZSwgbm9Jc29sYXRpb246IG5vSXNvbGF0aW9uLCBpbmVydDogaW5lcnQsIHNldENhbGxiYWNrczogc2V0Q2FsbGJhY2tzLCBhbGxvd1BpbmNoWm9vbTogISFhbGxvd1BpbmNoWm9vbSwgbG9ja1JlZjogcmVmLCBnYXBNb2RlOiBnYXBNb2RlIH0pKSxcbiAgICAgICAgZm9yd2FyZFByb3BzID8gKFJlYWN0LmNsb25lRWxlbWVudChSZWFjdC5DaGlsZHJlbi5vbmx5KGNoaWxkcmVuKSwgX19hc3NpZ24oX19hc3NpZ24oe30sIGNvbnRhaW5lclByb3BzKSwgeyByZWY6IGNvbnRhaW5lclJlZiB9KSkpIDogKFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29udGFpbmVyLCBfX2Fzc2lnbih7fSwgY29udGFpbmVyUHJvcHMsIHsgY2xhc3NOYW1lOiBjbGFzc05hbWUsIHJlZjogY29udGFpbmVyUmVmIH0pLCBjaGlsZHJlbikpKSk7XG59KTtcblJlbW92ZVNjcm9sbC5kZWZhdWx0UHJvcHMgPSB7XG4gICAgZW5hYmxlZDogdHJ1ZSxcbiAgICByZW1vdmVTY3JvbGxCYXI6IHRydWUsXG4gICAgaW5lcnQ6IGZhbHNlLFxufTtcblJlbW92ZVNjcm9sbC5jbGFzc05hbWVzID0ge1xuICAgIGZ1bGxXaWR0aDogZnVsbFdpZHRoQ2xhc3NOYW1lLFxuICAgIHplcm9SaWdodDogemVyb1JpZ2h0Q2xhc3NOYW1lLFxufTtcbmV4cG9ydCB7IFJlbW92ZVNjcm9sbCB9O1xuIiwidmFyIGN1cnJlbnROb25jZTtcbmV4cG9ydCB2YXIgc2V0Tm9uY2UgPSBmdW5jdGlvbiAobm9uY2UpIHtcbiAgICBjdXJyZW50Tm9uY2UgPSBub25jZTtcbn07XG5leHBvcnQgdmFyIGdldE5vbmNlID0gZnVuY3Rpb24gKCkge1xuICAgIGlmIChjdXJyZW50Tm9uY2UpIHtcbiAgICAgICAgcmV0dXJuIGN1cnJlbnROb25jZTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBfX3dlYnBhY2tfbm9uY2VfXyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgcmV0dXJuIF9fd2VicGFja19ub25jZV9fO1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xufTtcbiIsImltcG9ydCB7IGdldE5vbmNlIH0gZnJvbSAnZ2V0LW5vbmNlJztcbmZ1bmN0aW9uIG1ha2VTdHlsZVRhZygpIHtcbiAgICBpZiAoIWRvY3VtZW50KVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB2YXIgdGFnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTtcbiAgICB0YWcudHlwZSA9ICd0ZXh0L2Nzcyc7XG4gICAgdmFyIG5vbmNlID0gZ2V0Tm9uY2UoKTtcbiAgICBpZiAobm9uY2UpIHtcbiAgICAgICAgdGFnLnNldEF0dHJpYnV0ZSgnbm9uY2UnLCBub25jZSk7XG4gICAgfVxuICAgIHJldHVybiB0YWc7XG59XG5mdW5jdGlvbiBpbmplY3RTdHlsZXModGFnLCBjc3MpIHtcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgaWYgKHRhZy5zdHlsZVNoZWV0KSB7XG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgdGFnLnN0eWxlU2hlZXQuY3NzVGV4dCA9IGNzcztcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHRhZy5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjc3MpKTtcbiAgICB9XG59XG5mdW5jdGlvbiBpbnNlcnRTdHlsZVRhZyh0YWcpIHtcbiAgICB2YXIgaGVhZCA9IGRvY3VtZW50LmhlYWQgfHwgZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2hlYWQnKVswXTtcbiAgICBoZWFkLmFwcGVuZENoaWxkKHRhZyk7XG59XG5leHBvcnQgdmFyIHN0eWxlc2hlZXRTaW5nbGV0b24gPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGNvdW50ZXIgPSAwO1xuICAgIHZhciBzdHlsZXNoZWV0ID0gbnVsbDtcbiAgICByZXR1cm4ge1xuICAgICAgICBhZGQ6IGZ1bmN0aW9uIChzdHlsZSkge1xuICAgICAgICAgICAgaWYgKGNvdW50ZXIgPT0gMCkge1xuICAgICAgICAgICAgICAgIGlmICgoc3R5bGVzaGVldCA9IG1ha2VTdHlsZVRhZygpKSkge1xuICAgICAgICAgICAgICAgICAgICBpbmplY3RTdHlsZXMoc3R5bGVzaGVldCwgc3R5bGUpO1xuICAgICAgICAgICAgICAgICAgICBpbnNlcnRTdHlsZVRhZyhzdHlsZXNoZWV0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb3VudGVyKys7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbW92ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY291bnRlci0tO1xuICAgICAgICAgICAgaWYgKCFjb3VudGVyICYmIHN0eWxlc2hlZXQpIHtcbiAgICAgICAgICAgICAgICBzdHlsZXNoZWV0LnBhcmVudE5vZGUgJiYgc3R5bGVzaGVldC5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHN0eWxlc2hlZXQpO1xuICAgICAgICAgICAgICAgIHN0eWxlc2hlZXQgPSBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgIH07XG59O1xuIiwiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgc3R5bGVzaGVldFNpbmdsZXRvbiB9IGZyb20gJy4vc2luZ2xldG9uJztcbi8qKlxuICogY3JlYXRlcyBhIGhvb2sgdG8gY29udHJvbCBzdHlsZSBzaW5nbGV0b25cbiAqIEBzZWUge0BsaW5rIHN0eWxlU2luZ2xldG9ufSBmb3IgYSBzYWZlciBjb21wb25lbnQgdmVyc2lvblxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogY29uc3QgdXNlU3R5bGUgPSBzdHlsZUhvb2tTaW5nbGV0b24oKTtcbiAqIC8vL1xuICogdXNlU3R5bGUoJ2JvZHkgeyBvdmVyZmxvdzogaGlkZGVufScpO1xuICovXG5leHBvcnQgdmFyIHN0eWxlSG9va1NpbmdsZXRvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2hlZXQgPSBzdHlsZXNoZWV0U2luZ2xldG9uKCk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIChzdHlsZXMsIGlzRHluYW1pYykge1xuICAgICAgICBSZWFjdC51c2VFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgc2hlZXQuYWRkKHN0eWxlcyk7XG4gICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHNoZWV0LnJlbW92ZSgpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfSwgW3N0eWxlcyAmJiBpc0R5bmFtaWNdKTtcbiAgICB9O1xufTtcbiIsImltcG9ydCB7IHN0eWxlSG9va1NpbmdsZXRvbiB9IGZyb20gJy4vaG9vayc7XG4vKipcbiAqIGNyZWF0ZSBhIENvbXBvbmVudCB0byBhZGQgc3R5bGVzIG9uIGRlbWFuZFxuICogLSBzdHlsZXMgYXJlIGFkZGVkIHdoZW4gZmlyc3QgaW5zdGFuY2UgaXMgbW91bnRlZFxuICogLSBzdHlsZXMgYXJlIHJlbW92ZWQgd2hlbiB0aGUgbGFzdCBpbnN0YW5jZSBpcyB1bm1vdW50ZWRcbiAqIC0gY2hhbmdpbmcgc3R5bGVzIGluIHJ1bnRpbWUgZG9lcyBub3RoaW5nIHVubGVzcyBkeW5hbWljIGlzIHNldC4gQnV0IHdpdGggbXVsdGlwbGUgY29tcG9uZW50cyB0aGF0IGNhbiBsZWFkIHRvIHRoZSB1bmRlZmluZWQgYmVoYXZpb3JcbiAqL1xuZXhwb3J0IHZhciBzdHlsZVNpbmdsZXRvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgdXNlU3R5bGUgPSBzdHlsZUhvb2tTaW5nbGV0b24oKTtcbiAgICB2YXIgU2hlZXQgPSBmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgdmFyIHN0eWxlcyA9IF9hLnN0eWxlcywgZHluYW1pYyA9IF9hLmR5bmFtaWM7XG4gICAgICAgIHVzZVN0eWxlKHN0eWxlcywgZHluYW1pYyk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH07XG4gICAgcmV0dXJuIFNoZWV0O1xufTtcbiIsImV4cG9ydCB2YXIgemVyb0dhcCA9IHtcbiAgICBsZWZ0OiAwLFxuICAgIHRvcDogMCxcbiAgICByaWdodDogMCxcbiAgICBnYXA6IDAsXG59O1xudmFyIHBhcnNlID0gZnVuY3Rpb24gKHgpIHsgcmV0dXJuIHBhcnNlSW50KHggfHwgJycsIDEwKSB8fCAwOyB9O1xudmFyIGdldE9mZnNldCA9IGZ1bmN0aW9uIChnYXBNb2RlKSB7XG4gICAgdmFyIGNzID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZG9jdW1lbnQuYm9keSk7XG4gICAgdmFyIGxlZnQgPSBjc1tnYXBNb2RlID09PSAncGFkZGluZycgPyAncGFkZGluZ0xlZnQnIDogJ21hcmdpbkxlZnQnXTtcbiAgICB2YXIgdG9wID0gY3NbZ2FwTW9kZSA9PT0gJ3BhZGRpbmcnID8gJ3BhZGRpbmdUb3AnIDogJ21hcmdpblRvcCddO1xuICAgIHZhciByaWdodCA9IGNzW2dhcE1vZGUgPT09ICdwYWRkaW5nJyA/ICdwYWRkaW5nUmlnaHQnIDogJ21hcmdpblJpZ2h0J107XG4gICAgcmV0dXJuIFtwYXJzZShsZWZ0KSwgcGFyc2UodG9wKSwgcGFyc2UocmlnaHQpXTtcbn07XG5leHBvcnQgdmFyIGdldEdhcFdpZHRoID0gZnVuY3Rpb24gKGdhcE1vZGUpIHtcbiAgICBpZiAoZ2FwTW9kZSA9PT0gdm9pZCAwKSB7IGdhcE1vZGUgPSAnbWFyZ2luJzsgfVxuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICByZXR1cm4gemVyb0dhcDtcbiAgICB9XG4gICAgdmFyIG9mZnNldHMgPSBnZXRPZmZzZXQoZ2FwTW9kZSk7XG4gICAgdmFyIGRvY3VtZW50V2lkdGggPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGg7XG4gICAgdmFyIHdpbmRvd1dpZHRoID0gd2luZG93LmlubmVyV2lkdGg7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogb2Zmc2V0c1swXSxcbiAgICAgICAgdG9wOiBvZmZzZXRzWzFdLFxuICAgICAgICByaWdodDogb2Zmc2V0c1syXSxcbiAgICAgICAgZ2FwOiBNYXRoLm1heCgwLCB3aW5kb3dXaWR0aCAtIGRvY3VtZW50V2lkdGggKyBvZmZzZXRzWzJdIC0gb2Zmc2V0c1swXSksXG4gICAgfTtcbn07XG4iLCJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBzdHlsZVNpbmdsZXRvbiB9IGZyb20gJ3JlYWN0LXN0eWxlLXNpbmdsZXRvbic7XG5pbXBvcnQgeyBmdWxsV2lkdGhDbGFzc05hbWUsIHplcm9SaWdodENsYXNzTmFtZSwgbm9TY3JvbGxiYXJzQ2xhc3NOYW1lLCByZW1vdmVkQmFyU2l6ZVZhcmlhYmxlIH0gZnJvbSAnLi9jb25zdGFudHMnO1xuaW1wb3J0IHsgZ2V0R2FwV2lkdGggfSBmcm9tICcuL3V0aWxzJztcbnZhciBTdHlsZSA9IHN0eWxlU2luZ2xldG9uKCk7XG5leHBvcnQgdmFyIGxvY2tBdHRyaWJ1dGUgPSAnZGF0YS1zY3JvbGwtbG9ja2VkJztcbi8vIGltcG9ydGFudCB0aXAgLSBvbmNlIHdlIG1lYXN1cmUgc2Nyb2xsQmFyIHdpZHRoIGFuZCByZW1vdmUgdGhlbVxuLy8gd2UgY291bGQgbm90IHJlcGVhdCB0aGlzIG9wZXJhdGlvblxuLy8gdGh1cyB3ZSBhcmUgdXNpbmcgc3R5bGUtc2luZ2xldG9uIC0gb25seSB0aGUgZmlyc3QgXCJ5ZXQgY29ycmVjdFwiIHN0eWxlIHdpbGwgYmUgYXBwbGllZC5cbnZhciBnZXRTdHlsZXMgPSBmdW5jdGlvbiAoX2EsIGFsbG93UmVsYXRpdmUsIGdhcE1vZGUsIGltcG9ydGFudCkge1xuICAgIHZhciBsZWZ0ID0gX2EubGVmdCwgdG9wID0gX2EudG9wLCByaWdodCA9IF9hLnJpZ2h0LCBnYXAgPSBfYS5nYXA7XG4gICAgaWYgKGdhcE1vZGUgPT09IHZvaWQgMCkgeyBnYXBNb2RlID0gJ21hcmdpbic7IH1cbiAgICByZXR1cm4gXCJcXG4gIC5cIi5jb25jYXQobm9TY3JvbGxiYXJzQ2xhc3NOYW1lLCBcIiB7XFxuICAgb3ZlcmZsb3c6IGhpZGRlbiBcIikuY29uY2F0KGltcG9ydGFudCwgXCI7XFxuICAgcGFkZGluZy1yaWdodDogXCIpLmNvbmNhdChnYXAsIFwicHggXCIpLmNvbmNhdChpbXBvcnRhbnQsIFwiO1xcbiAgfVxcbiAgYm9keVtcIikuY29uY2F0KGxvY2tBdHRyaWJ1dGUsIFwiXSB7XFxuICAgIG92ZXJmbG93OiBoaWRkZW4gXCIpLmNvbmNhdChpbXBvcnRhbnQsIFwiO1xcbiAgICBvdmVyc2Nyb2xsLWJlaGF2aW9yOiBjb250YWluO1xcbiAgICBcIikuY29uY2F0KFtcbiAgICAgICAgYWxsb3dSZWxhdGl2ZSAmJiBcInBvc2l0aW9uOiByZWxhdGl2ZSBcIi5jb25jYXQoaW1wb3J0YW50LCBcIjtcIiksXG4gICAgICAgIGdhcE1vZGUgPT09ICdtYXJnaW4nICYmXG4gICAgICAgICAgICBcIlxcbiAgICBwYWRkaW5nLWxlZnQ6IFwiLmNvbmNhdChsZWZ0LCBcInB4O1xcbiAgICBwYWRkaW5nLXRvcDogXCIpLmNvbmNhdCh0b3AsIFwicHg7XFxuICAgIHBhZGRpbmctcmlnaHQ6IFwiKS5jb25jYXQocmlnaHQsIFwicHg7XFxuICAgIG1hcmdpbi1sZWZ0OjA7XFxuICAgIG1hcmdpbi10b3A6MDtcXG4gICAgbWFyZ2luLXJpZ2h0OiBcIikuY29uY2F0KGdhcCwgXCJweCBcIikuY29uY2F0KGltcG9ydGFudCwgXCI7XFxuICAgIFwiKSxcbiAgICAgICAgZ2FwTW9kZSA9PT0gJ3BhZGRpbmcnICYmIFwicGFkZGluZy1yaWdodDogXCIuY29uY2F0KGdhcCwgXCJweCBcIikuY29uY2F0KGltcG9ydGFudCwgXCI7XCIpLFxuICAgIF1cbiAgICAgICAgLmZpbHRlcihCb29sZWFuKVxuICAgICAgICAuam9pbignJyksIFwiXFxuICB9XFxuICBcXG4gIC5cIikuY29uY2F0KHplcm9SaWdodENsYXNzTmFtZSwgXCIge1xcbiAgICByaWdodDogXCIpLmNvbmNhdChnYXAsIFwicHggXCIpLmNvbmNhdChpbXBvcnRhbnQsIFwiO1xcbiAgfVxcbiAgXFxuICAuXCIpLmNvbmNhdChmdWxsV2lkdGhDbGFzc05hbWUsIFwiIHtcXG4gICAgbWFyZ2luLXJpZ2h0OiBcIikuY29uY2F0KGdhcCwgXCJweCBcIikuY29uY2F0KGltcG9ydGFudCwgXCI7XFxuICB9XFxuICBcXG4gIC5cIikuY29uY2F0KHplcm9SaWdodENsYXNzTmFtZSwgXCIgLlwiKS5jb25jYXQoemVyb1JpZ2h0Q2xhc3NOYW1lLCBcIiB7XFxuICAgIHJpZ2h0OiAwIFwiKS5jb25jYXQoaW1wb3J0YW50LCBcIjtcXG4gIH1cXG4gIFxcbiAgLlwiKS5jb25jYXQoZnVsbFdpZHRoQ2xhc3NOYW1lLCBcIiAuXCIpLmNvbmNhdChmdWxsV2lkdGhDbGFzc05hbWUsIFwiIHtcXG4gICAgbWFyZ2luLXJpZ2h0OiAwIFwiKS5jb25jYXQoaW1wb3J0YW50LCBcIjtcXG4gIH1cXG4gIFxcbiAgYm9keVtcIikuY29uY2F0KGxvY2tBdHRyaWJ1dGUsIFwiXSB7XFxuICAgIFwiKS5jb25jYXQocmVtb3ZlZEJhclNpemVWYXJpYWJsZSwgXCI6IFwiKS5jb25jYXQoZ2FwLCBcInB4O1xcbiAgfVxcblwiKTtcbn07XG52YXIgZ2V0Q3VycmVudFVzZUNvdW50ZXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGNvdW50ZXIgPSBwYXJzZUludChkb2N1bWVudC5ib2R5LmdldEF0dHJpYnV0ZShsb2NrQXR0cmlidXRlKSB8fCAnMCcsIDEwKTtcbiAgICByZXR1cm4gaXNGaW5pdGUoY291bnRlcikgPyBjb3VudGVyIDogMDtcbn07XG5leHBvcnQgdmFyIHVzZUxvY2tBdHRyaWJ1dGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgUmVhY3QudXNlRWZmZWN0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgZG9jdW1lbnQuYm9keS5zZXRBdHRyaWJ1dGUobG9ja0F0dHJpYnV0ZSwgKGdldEN1cnJlbnRVc2VDb3VudGVyKCkgKyAxKS50b1N0cmluZygpKTtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBuZXdDb3VudGVyID0gZ2V0Q3VycmVudFVzZUNvdW50ZXIoKSAtIDE7XG4gICAgICAgICAgICBpZiAobmV3Q291bnRlciA8PSAwKSB7XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVBdHRyaWJ1dGUobG9ja0F0dHJpYnV0ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LnNldEF0dHJpYnV0ZShsb2NrQXR0cmlidXRlLCBuZXdDb3VudGVyLnRvU3RyaW5nKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0sIFtdKTtcbn07XG4vKipcbiAqIFJlbW92ZXMgcGFnZSBzY3JvbGxiYXIgYW5kIGJsb2NrcyBwYWdlIHNjcm9sbCB3aGVuIG1vdW50ZWRcbiAqL1xuZXhwb3J0IHZhciBSZW1vdmVTY3JvbGxCYXIgPSBmdW5jdGlvbiAoX2EpIHtcbiAgICB2YXIgbm9SZWxhdGl2ZSA9IF9hLm5vUmVsYXRpdmUsIG5vSW1wb3J0YW50ID0gX2Eubm9JbXBvcnRhbnQsIF9iID0gX2EuZ2FwTW9kZSwgZ2FwTW9kZSA9IF9iID09PSB2b2lkIDAgPyAnbWFyZ2luJyA6IF9iO1xuICAgIHVzZUxvY2tBdHRyaWJ1dGUoKTtcbiAgICAvKlxuICAgICBnYXAgd2lsbCBiZSBtZWFzdXJlZCBvbiBldmVyeSBjb21wb25lbnQgbW91bnRcbiAgICAgaG93ZXZlciBpdCB3aWxsIGJlIHVzZWQgb25seSBieSB0aGUgXCJmaXJzdFwiIGludm9jYXRpb25cbiAgICAgZHVlIHRvIHNpbmdsZXRvbiBuYXR1cmUgb2YgPFN0eWxlXG4gICAgICovXG4gICAgdmFyIGdhcCA9IFJlYWN0LnVzZU1lbW8oZnVuY3Rpb24gKCkgeyByZXR1cm4gZ2V0R2FwV2lkdGgoZ2FwTW9kZSk7IH0sIFtnYXBNb2RlXSk7XG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3R5bGUsIHsgc3R5bGVzOiBnZXRTdHlsZXMoZ2FwLCAhbm9SZWxhdGl2ZSwgZ2FwTW9kZSwgIW5vSW1wb3J0YW50ID8gJyFpbXBvcnRhbnQnIDogJycpIH0pO1xufTtcbiIsInZhciBwYXNzaXZlU3VwcG9ydGVkID0gZmFsc2U7XG5pZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICB0cnkge1xuICAgICAgICB2YXIgb3B0aW9ucyA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh7fSwgJ3Bhc3NpdmUnLCB7XG4gICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBwYXNzaXZlU3VwcG9ydGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCd0ZXN0Jywgb3B0aW9ucywgb3B0aW9ucyk7XG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Rlc3QnLCBvcHRpb25zLCBvcHRpb25zKTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycikge1xuICAgICAgICBwYXNzaXZlU3VwcG9ydGVkID0gZmFsc2U7XG4gICAgfVxufVxuZXhwb3J0IHZhciBub25QYXNzaXZlID0gcGFzc2l2ZVN1cHBvcnRlZCA/IHsgcGFzc2l2ZTogZmFsc2UgfSA6IGZhbHNlO1xuIiwidmFyIGFsd2F5c0NvbnRhaW5zU2Nyb2xsID0gZnVuY3Rpb24gKG5vZGUpIHtcbiAgICAvLyB0ZXh0YXJlYSB3aWxsIGFsd2F5cyBfY29udGFpbl8gc2Nyb2xsIGluc2lkZSBzZWxmLiBJdCBvbmx5IGNhbiBiZSBoaWRkZW5cbiAgICByZXR1cm4gbm9kZS50YWdOYW1lID09PSAnVEVYVEFSRUEnO1xufTtcbnZhciBlbGVtZW50Q2FuQmVTY3JvbGxlZCA9IGZ1bmN0aW9uIChub2RlLCBvdmVyZmxvdykge1xuICAgIGlmICghKG5vZGUgaW5zdGFuY2VvZiBFbGVtZW50KSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHZhciBzdHlsZXMgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShub2RlKTtcbiAgICByZXR1cm4gKFxuICAgIC8vIG5vdC1ub3Qtc2Nyb2xsYWJsZVxuICAgIHN0eWxlc1tvdmVyZmxvd10gIT09ICdoaWRkZW4nICYmXG4gICAgICAgIC8vIGNvbnRhaW5zIHNjcm9sbCBpbnNpZGUgc2VsZlxuICAgICAgICAhKHN0eWxlcy5vdmVyZmxvd1kgPT09IHN0eWxlcy5vdmVyZmxvd1ggJiYgIWFsd2F5c0NvbnRhaW5zU2Nyb2xsKG5vZGUpICYmIHN0eWxlc1tvdmVyZmxvd10gPT09ICd2aXNpYmxlJykpO1xufTtcbnZhciBlbGVtZW50Q291bGRCZVZTY3JvbGxlZCA9IGZ1bmN0aW9uIChub2RlKSB7IHJldHVybiBlbGVtZW50Q2FuQmVTY3JvbGxlZChub2RlLCAnb3ZlcmZsb3dZJyk7IH07XG52YXIgZWxlbWVudENvdWxkQmVIU2Nyb2xsZWQgPSBmdW5jdGlvbiAobm9kZSkgeyByZXR1cm4gZWxlbWVudENhbkJlU2Nyb2xsZWQobm9kZSwgJ292ZXJmbG93WCcpOyB9O1xuZXhwb3J0IHZhciBsb2NhdGlvbkNvdWxkQmVTY3JvbGxlZCA9IGZ1bmN0aW9uIChheGlzLCBub2RlKSB7XG4gICAgdmFyIG93bmVyRG9jdW1lbnQgPSBub2RlLm93bmVyRG9jdW1lbnQ7XG4gICAgdmFyIGN1cnJlbnQgPSBub2RlO1xuICAgIGRvIHtcbiAgICAgICAgLy8gU2tpcCBvdmVyIHNoYWRvdyByb290XG4gICAgICAgIGlmICh0eXBlb2YgU2hhZG93Um9vdCAhPT0gJ3VuZGVmaW5lZCcgJiYgY3VycmVudCBpbnN0YW5jZW9mIFNoYWRvd1Jvb3QpIHtcbiAgICAgICAgICAgIGN1cnJlbnQgPSBjdXJyZW50Lmhvc3Q7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGlzU2Nyb2xsYWJsZSA9IGVsZW1lbnRDb3VsZEJlU2Nyb2xsZWQoYXhpcywgY3VycmVudCk7XG4gICAgICAgIGlmIChpc1Njcm9sbGFibGUpIHtcbiAgICAgICAgICAgIHZhciBfYSA9IGdldFNjcm9sbFZhcmlhYmxlcyhheGlzLCBjdXJyZW50KSwgc2Nyb2xsSGVpZ2h0ID0gX2FbMV0sIGNsaWVudEhlaWdodCA9IF9hWzJdO1xuICAgICAgICAgICAgaWYgKHNjcm9sbEhlaWdodCA+IGNsaWVudEhlaWdodCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGN1cnJlbnQgPSBjdXJyZW50LnBhcmVudE5vZGU7XG4gICAgfSB3aGlsZSAoY3VycmVudCAmJiBjdXJyZW50ICE9PSBvd25lckRvY3VtZW50LmJvZHkpO1xuICAgIHJldHVybiBmYWxzZTtcbn07XG52YXIgZ2V0VlNjcm9sbFZhcmlhYmxlcyA9IGZ1bmN0aW9uIChfYSkge1xuICAgIHZhciBzY3JvbGxUb3AgPSBfYS5zY3JvbGxUb3AsIHNjcm9sbEhlaWdodCA9IF9hLnNjcm9sbEhlaWdodCwgY2xpZW50SGVpZ2h0ID0gX2EuY2xpZW50SGVpZ2h0O1xuICAgIHJldHVybiBbXG4gICAgICAgIHNjcm9sbFRvcCxcbiAgICAgICAgc2Nyb2xsSGVpZ2h0LFxuICAgICAgICBjbGllbnRIZWlnaHQsXG4gICAgXTtcbn07XG52YXIgZ2V0SFNjcm9sbFZhcmlhYmxlcyA9IGZ1bmN0aW9uIChfYSkge1xuICAgIHZhciBzY3JvbGxMZWZ0ID0gX2Euc2Nyb2xsTGVmdCwgc2Nyb2xsV2lkdGggPSBfYS5zY3JvbGxXaWR0aCwgY2xpZW50V2lkdGggPSBfYS5jbGllbnRXaWR0aDtcbiAgICByZXR1cm4gW1xuICAgICAgICBzY3JvbGxMZWZ0LFxuICAgICAgICBzY3JvbGxXaWR0aCxcbiAgICAgICAgY2xpZW50V2lkdGgsXG4gICAgXTtcbn07XG52YXIgZWxlbWVudENvdWxkQmVTY3JvbGxlZCA9IGZ1bmN0aW9uIChheGlzLCBub2RlKSB7XG4gICAgcmV0dXJuIGF4aXMgPT09ICd2JyA/IGVsZW1lbnRDb3VsZEJlVlNjcm9sbGVkKG5vZGUpIDogZWxlbWVudENvdWxkQmVIU2Nyb2xsZWQobm9kZSk7XG59O1xudmFyIGdldFNjcm9sbFZhcmlhYmxlcyA9IGZ1bmN0aW9uIChheGlzLCBub2RlKSB7XG4gICAgcmV0dXJuIGF4aXMgPT09ICd2JyA/IGdldFZTY3JvbGxWYXJpYWJsZXMobm9kZSkgOiBnZXRIU2Nyb2xsVmFyaWFibGVzKG5vZGUpO1xufTtcbnZhciBnZXREaXJlY3Rpb25GYWN0b3IgPSBmdW5jdGlvbiAoYXhpcywgZGlyZWN0aW9uKSB7XG4gICAgLyoqXG4gICAgICogSWYgdGhlIGVsZW1lbnQncyBkaXJlY3Rpb24gaXMgcnRsIChyaWdodC10by1sZWZ0KSwgdGhlbiBzY3JvbGxMZWZ0IGlzIDAgd2hlbiB0aGUgc2Nyb2xsYmFyIGlzIGF0IGl0cyByaWdodG1vc3QgcG9zaXRpb24sXG4gICAgICogYW5kIHRoZW4gaW5jcmVhc2luZ2x5IG5lZ2F0aXZlIGFzIHlvdSBzY3JvbGwgdG93YXJkcyB0aGUgZW5kIG9mIHRoZSBjb250ZW50LlxuICAgICAqIEBzZWUgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0VsZW1lbnQvc2Nyb2xsTGVmdFxuICAgICAqL1xuICAgIHJldHVybiBheGlzID09PSAnaCcgJiYgZGlyZWN0aW9uID09PSAncnRsJyA/IC0xIDogMTtcbn07XG5leHBvcnQgdmFyIGhhbmRsZVNjcm9sbCA9IGZ1bmN0aW9uIChheGlzLCBlbmRUYXJnZXQsIGV2ZW50LCBzb3VyY2VEZWx0YSwgbm9PdmVyc2Nyb2xsKSB7XG4gICAgdmFyIGRpcmVjdGlvbkZhY3RvciA9IGdldERpcmVjdGlvbkZhY3RvcihheGlzLCB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbmRUYXJnZXQpLmRpcmVjdGlvbik7XG4gICAgdmFyIGRlbHRhID0gZGlyZWN0aW9uRmFjdG9yICogc291cmNlRGVsdGE7XG4gICAgLy8gZmluZCBzY3JvbGxhYmxlIHRhcmdldFxuICAgIHZhciB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgdmFyIHRhcmdldEluTG9jayA9IGVuZFRhcmdldC5jb250YWlucyh0YXJnZXQpO1xuICAgIHZhciBzaG91bGRDYW5jZWxTY3JvbGwgPSBmYWxzZTtcbiAgICB2YXIgaXNEZWx0YVBvc2l0aXZlID0gZGVsdGEgPiAwO1xuICAgIHZhciBhdmFpbGFibGVTY3JvbGwgPSAwO1xuICAgIHZhciBhdmFpbGFibGVTY3JvbGxUb3AgPSAwO1xuICAgIGRvIHtcbiAgICAgICAgaWYgKCF0YXJnZXQpIHtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIHZhciBfYSA9IGdldFNjcm9sbFZhcmlhYmxlcyhheGlzLCB0YXJnZXQpLCBwb3NpdGlvbiA9IF9hWzBdLCBzY3JvbGxfMSA9IF9hWzFdLCBjYXBhY2l0eSA9IF9hWzJdO1xuICAgICAgICB2YXIgZWxlbWVudFNjcm9sbCA9IHNjcm9sbF8xIC0gY2FwYWNpdHkgLSBkaXJlY3Rpb25GYWN0b3IgKiBwb3NpdGlvbjtcbiAgICAgICAgaWYgKHBvc2l0aW9uIHx8IGVsZW1lbnRTY3JvbGwpIHtcbiAgICAgICAgICAgIGlmIChlbGVtZW50Q291bGRCZVNjcm9sbGVkKGF4aXMsIHRhcmdldCkpIHtcbiAgICAgICAgICAgICAgICBhdmFpbGFibGVTY3JvbGwgKz0gZWxlbWVudFNjcm9sbDtcbiAgICAgICAgICAgICAgICBhdmFpbGFibGVTY3JvbGxUb3AgKz0gcG9zaXRpb247XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHBhcmVudF8xID0gdGFyZ2V0LnBhcmVudE5vZGU7XG4gICAgICAgIC8vIHdlIHdpbGwgXCJidWJibGVcIiBmcm9tIFNoYWRvd0RvbSBpbiBjYXNlIHdlIGFyZSwgb3IganVzdCB0byB0aGUgcGFyZW50IGluIG5vcm1hbCBjYXNlXG4gICAgICAgIC8vIHRoaXMgaXMgdGhlIHNhbWUgbG9naWMgdXNlZCBpbiBmb2N1cy1sb2NrXG4gICAgICAgIHRhcmdldCA9IChwYXJlbnRfMSAmJiBwYXJlbnRfMS5ub2RlVHlwZSA9PT0gTm9kZS5ET0NVTUVOVF9GUkFHTUVOVF9OT0RFID8gcGFyZW50XzEuaG9zdCA6IHBhcmVudF8xKTtcbiAgICB9IHdoaWxlIChcbiAgICAvLyBwb3J0YWxlZCBjb250ZW50XG4gICAgKCF0YXJnZXRJbkxvY2sgJiYgdGFyZ2V0ICE9PSBkb2N1bWVudC5ib2R5KSB8fFxuICAgICAgICAvLyBzZWxmIGNvbnRlbnRcbiAgICAgICAgKHRhcmdldEluTG9jayAmJiAoZW5kVGFyZ2V0LmNvbnRhaW5zKHRhcmdldCkgfHwgZW5kVGFyZ2V0ID09PSB0YXJnZXQpKSk7XG4gICAgLy8gaGFuZGxlIGVwc2lsb24gYXJvdW5kIDAgKG5vbiBzdGFuZGFyZCB6b29tIGxldmVscylcbiAgICBpZiAoaXNEZWx0YVBvc2l0aXZlICYmXG4gICAgICAgICgobm9PdmVyc2Nyb2xsICYmIE1hdGguYWJzKGF2YWlsYWJsZVNjcm9sbCkgPCAxKSB8fCAoIW5vT3ZlcnNjcm9sbCAmJiBkZWx0YSA+IGF2YWlsYWJsZVNjcm9sbCkpKSB7XG4gICAgICAgIHNob3VsZENhbmNlbFNjcm9sbCA9IHRydWU7XG4gICAgfVxuICAgIGVsc2UgaWYgKCFpc0RlbHRhUG9zaXRpdmUgJiZcbiAgICAgICAgKChub092ZXJzY3JvbGwgJiYgTWF0aC5hYnMoYXZhaWxhYmxlU2Nyb2xsVG9wKSA8IDEpIHx8ICghbm9PdmVyc2Nyb2xsICYmIC1kZWx0YSA+IGF2YWlsYWJsZVNjcm9sbFRvcCkpKSB7XG4gICAgICAgIHNob3VsZENhbmNlbFNjcm9sbCA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiBzaG91bGRDYW5jZWxTY3JvbGw7XG59O1xuIiwiaW1wb3J0IHsgX19zcHJlYWRBcnJheSB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgUmVtb3ZlU2Nyb2xsQmFyIH0gZnJvbSAncmVhY3QtcmVtb3ZlLXNjcm9sbC1iYXInO1xuaW1wb3J0IHsgc3R5bGVTaW5nbGV0b24gfSBmcm9tICdyZWFjdC1zdHlsZS1zaW5nbGV0b24nO1xuaW1wb3J0IHsgbm9uUGFzc2l2ZSB9IGZyb20gJy4vYWdncmVzaXZlQ2FwdHVyZSc7XG5pbXBvcnQgeyBoYW5kbGVTY3JvbGwsIGxvY2F0aW9uQ291bGRCZVNjcm9sbGVkIH0gZnJvbSAnLi9oYW5kbGVTY3JvbGwnO1xuZXhwb3J0IHZhciBnZXRUb3VjaFhZID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgcmV0dXJuICdjaGFuZ2VkVG91Y2hlcycgaW4gZXZlbnQgPyBbZXZlbnQuY2hhbmdlZFRvdWNoZXNbMF0uY2xpZW50WCwgZXZlbnQuY2hhbmdlZFRvdWNoZXNbMF0uY2xpZW50WV0gOiBbMCwgMF07XG59O1xuZXhwb3J0IHZhciBnZXREZWx0YVhZID0gZnVuY3Rpb24gKGV2ZW50KSB7IHJldHVybiBbZXZlbnQuZGVsdGFYLCBldmVudC5kZWx0YVldOyB9O1xudmFyIGV4dHJhY3RSZWYgPSBmdW5jdGlvbiAocmVmKSB7XG4gICAgcmV0dXJuIHJlZiAmJiAnY3VycmVudCcgaW4gcmVmID8gcmVmLmN1cnJlbnQgOiByZWY7XG59O1xudmFyIGRlbHRhQ29tcGFyZSA9IGZ1bmN0aW9uICh4LCB5KSB7IHJldHVybiB4WzBdID09PSB5WzBdICYmIHhbMV0gPT09IHlbMV07IH07XG52YXIgZ2VuZXJhdGVTdHlsZSA9IGZ1bmN0aW9uIChpZCkgeyByZXR1cm4gXCJcXG4gIC5ibG9jay1pbnRlcmFjdGl2aXR5LVwiLmNvbmNhdChpZCwgXCIge3BvaW50ZXItZXZlbnRzOiBub25lO31cXG4gIC5hbGxvdy1pbnRlcmFjdGl2aXR5LVwiKS5jb25jYXQoaWQsIFwiIHtwb2ludGVyLWV2ZW50czogYWxsO31cXG5cIik7IH07XG52YXIgaWRDb3VudGVyID0gMDtcbnZhciBsb2NrU3RhY2sgPSBbXTtcbmV4cG9ydCBmdW5jdGlvbiBSZW1vdmVTY3JvbGxTaWRlQ2FyKHByb3BzKSB7XG4gICAgdmFyIHNob3VsZFByZXZlbnRRdWV1ZSA9IFJlYWN0LnVzZVJlZihbXSk7XG4gICAgdmFyIHRvdWNoU3RhcnRSZWYgPSBSZWFjdC51c2VSZWYoWzAsIDBdKTtcbiAgICB2YXIgYWN0aXZlQXhpcyA9IFJlYWN0LnVzZVJlZigpO1xuICAgIHZhciBpZCA9IFJlYWN0LnVzZVN0YXRlKGlkQ291bnRlcisrKVswXTtcbiAgICB2YXIgU3R5bGUgPSBSZWFjdC51c2VTdGF0ZShzdHlsZVNpbmdsZXRvbilbMF07XG4gICAgdmFyIGxhc3RQcm9wcyA9IFJlYWN0LnVzZVJlZihwcm9wcyk7XG4gICAgUmVhY3QudXNlRWZmZWN0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgbGFzdFByb3BzLmN1cnJlbnQgPSBwcm9wcztcbiAgICB9LCBbcHJvcHNdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAocHJvcHMuaW5lcnQpIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LmFkZChcImJsb2NrLWludGVyYWN0aXZpdHktXCIuY29uY2F0KGlkKSk7XG4gICAgICAgICAgICB2YXIgYWxsb3dfMSA9IF9fc3ByZWFkQXJyYXkoW3Byb3BzLmxvY2tSZWYuY3VycmVudF0sIChwcm9wcy5zaGFyZHMgfHwgW10pLm1hcChleHRyYWN0UmVmKSwgdHJ1ZSkuZmlsdGVyKEJvb2xlYW4pO1xuICAgICAgICAgICAgYWxsb3dfMS5mb3JFYWNoKGZ1bmN0aW9uIChlbCkgeyByZXR1cm4gZWwuY2xhc3NMaXN0LmFkZChcImFsbG93LWludGVyYWN0aXZpdHktXCIuY29uY2F0KGlkKSk7IH0pO1xuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5yZW1vdmUoXCJibG9jay1pbnRlcmFjdGl2aXR5LVwiLmNvbmNhdChpZCkpO1xuICAgICAgICAgICAgICAgIGFsbG93XzEuZm9yRWFjaChmdW5jdGlvbiAoZWwpIHsgcmV0dXJuIGVsLmNsYXNzTGlzdC5yZW1vdmUoXCJhbGxvdy1pbnRlcmFjdGl2aXR5LVwiLmNvbmNhdChpZCkpOyB9KTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgIH0sIFtwcm9wcy5pbmVydCwgcHJvcHMubG9ja1JlZi5jdXJyZW50LCBwcm9wcy5zaGFyZHNdKTtcbiAgICB2YXIgc2hvdWxkQ2FuY2VsRXZlbnQgPSBSZWFjdC51c2VDYWxsYmFjayhmdW5jdGlvbiAoZXZlbnQsIHBhcmVudCkge1xuICAgICAgICBpZiAoKCd0b3VjaGVzJyBpbiBldmVudCAmJiBldmVudC50b3VjaGVzLmxlbmd0aCA9PT0gMikgfHwgKGV2ZW50LnR5cGUgPT09ICd3aGVlbCcgJiYgZXZlbnQuY3RybEtleSkpIHtcbiAgICAgICAgICAgIHJldHVybiAhbGFzdFByb3BzLmN1cnJlbnQuYWxsb3dQaW5jaFpvb207XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHRvdWNoID0gZ2V0VG91Y2hYWShldmVudCk7XG4gICAgICAgIHZhciB0b3VjaFN0YXJ0ID0gdG91Y2hTdGFydFJlZi5jdXJyZW50O1xuICAgICAgICB2YXIgZGVsdGFYID0gJ2RlbHRhWCcgaW4gZXZlbnQgPyBldmVudC5kZWx0YVggOiB0b3VjaFN0YXJ0WzBdIC0gdG91Y2hbMF07XG4gICAgICAgIHZhciBkZWx0YVkgPSAnZGVsdGFZJyBpbiBldmVudCA/IGV2ZW50LmRlbHRhWSA6IHRvdWNoU3RhcnRbMV0gLSB0b3VjaFsxXTtcbiAgICAgICAgdmFyIGN1cnJlbnRBeGlzO1xuICAgICAgICB2YXIgdGFyZ2V0ID0gZXZlbnQudGFyZ2V0O1xuICAgICAgICB2YXIgbW92ZURpcmVjdGlvbiA9IE1hdGguYWJzKGRlbHRhWCkgPiBNYXRoLmFicyhkZWx0YVkpID8gJ2gnIDogJ3YnO1xuICAgICAgICAvLyBhbGxvdyBob3Jpem9udGFsIHRvdWNoIG1vdmUgb24gUmFuZ2UgaW5wdXRzLiBUaGV5IHdpbGwgbm90IGNhdXNlIGFueSBzY3JvbGxcbiAgICAgICAgaWYgKCd0b3VjaGVzJyBpbiBldmVudCAmJiBtb3ZlRGlyZWN0aW9uID09PSAnaCcgJiYgdGFyZ2V0LnR5cGUgPT09ICdyYW5nZScpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBhbGxvdyBkcmFnIHNlbGVjdGlvbiAoaU9TKTsgY2hlY2sgaWYgc2VsZWN0aW9uJ3MgYW5jaG9yTm9kZSBpcyB0aGUgc2FtZSBhcyB0YXJnZXQgb3IgY29udGFpbnMgdGFyZ2V0XG4gICAgICAgIHZhciBzZWxlY3Rpb24gPSB3aW5kb3cuZ2V0U2VsZWN0aW9uKCk7XG4gICAgICAgIHZhciBhbmNob3JOb2RlID0gc2VsZWN0aW9uICYmIHNlbGVjdGlvbi5hbmNob3JOb2RlO1xuICAgICAgICB2YXIgaXNUb3VjaGluZ1NlbGVjdGlvbiA9IGFuY2hvck5vZGUgPyBhbmNob3JOb2RlID09PSB0YXJnZXQgfHwgYW5jaG9yTm9kZS5jb250YWlucyh0YXJnZXQpIDogZmFsc2U7XG4gICAgICAgIGlmIChpc1RvdWNoaW5nU2VsZWN0aW9uKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGNhbkJlU2Nyb2xsZWRJbk1haW5EaXJlY3Rpb24gPSBsb2NhdGlvbkNvdWxkQmVTY3JvbGxlZChtb3ZlRGlyZWN0aW9uLCB0YXJnZXQpO1xuICAgICAgICBpZiAoIWNhbkJlU2Nyb2xsZWRJbk1haW5EaXJlY3Rpb24pIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjYW5CZVNjcm9sbGVkSW5NYWluRGlyZWN0aW9uKSB7XG4gICAgICAgICAgICBjdXJyZW50QXhpcyA9IG1vdmVEaXJlY3Rpb247XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjdXJyZW50QXhpcyA9IG1vdmVEaXJlY3Rpb24gPT09ICd2JyA/ICdoJyA6ICd2JztcbiAgICAgICAgICAgIGNhbkJlU2Nyb2xsZWRJbk1haW5EaXJlY3Rpb24gPSBsb2NhdGlvbkNvdWxkQmVTY3JvbGxlZChtb3ZlRGlyZWN0aW9uLCB0YXJnZXQpO1xuICAgICAgICAgICAgLy8gb3RoZXIgYXhpcyBtaWdodCBiZSBub3Qgc2Nyb2xsYWJsZVxuICAgICAgICB9XG4gICAgICAgIGlmICghY2FuQmVTY3JvbGxlZEluTWFpbkRpcmVjdGlvbikge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmICghYWN0aXZlQXhpcy5jdXJyZW50ICYmICdjaGFuZ2VkVG91Y2hlcycgaW4gZXZlbnQgJiYgKGRlbHRhWCB8fCBkZWx0YVkpKSB7XG4gICAgICAgICAgICBhY3RpdmVBeGlzLmN1cnJlbnQgPSBjdXJyZW50QXhpcztcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWN1cnJlbnRBeGlzKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgY2FuY2VsaW5nQXhpcyA9IGFjdGl2ZUF4aXMuY3VycmVudCB8fCBjdXJyZW50QXhpcztcbiAgICAgICAgcmV0dXJuIGhhbmRsZVNjcm9sbChjYW5jZWxpbmdBeGlzLCBwYXJlbnQsIGV2ZW50LCBjYW5jZWxpbmdBeGlzID09PSAnaCcgPyBkZWx0YVggOiBkZWx0YVksIHRydWUpO1xuICAgIH0sIFtdKTtcbiAgICB2YXIgc2hvdWxkUHJldmVudCA9IFJlYWN0LnVzZUNhbGxiYWNrKGZ1bmN0aW9uIChfZXZlbnQpIHtcbiAgICAgICAgdmFyIGV2ZW50ID0gX2V2ZW50O1xuICAgICAgICBpZiAoIWxvY2tTdGFjay5sZW5ndGggfHwgbG9ja1N0YWNrW2xvY2tTdGFjay5sZW5ndGggLSAxXSAhPT0gU3R5bGUpIHtcbiAgICAgICAgICAgIC8vIG5vdCB0aGUgbGFzdCBhY3RpdmVcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgZGVsdGEgPSAnZGVsdGFZJyBpbiBldmVudCA/IGdldERlbHRhWFkoZXZlbnQpIDogZ2V0VG91Y2hYWShldmVudCk7XG4gICAgICAgIHZhciBzb3VyY2VFdmVudCA9IHNob3VsZFByZXZlbnRRdWV1ZS5jdXJyZW50LmZpbHRlcihmdW5jdGlvbiAoZSkgeyByZXR1cm4gZS5uYW1lID09PSBldmVudC50eXBlICYmIChlLnRhcmdldCA9PT0gZXZlbnQudGFyZ2V0IHx8IGV2ZW50LnRhcmdldCA9PT0gZS5zaGFkb3dQYXJlbnQpICYmIGRlbHRhQ29tcGFyZShlLmRlbHRhLCBkZWx0YSk7IH0pWzBdO1xuICAgICAgICAvLyBzZWxmIGV2ZW50LCBhbmQgc2hvdWxkIGJlIGNhbmNlbGVkXG4gICAgICAgIGlmIChzb3VyY2VFdmVudCAmJiBzb3VyY2VFdmVudC5zaG91bGQpIHtcbiAgICAgICAgICAgIGlmIChldmVudC5jYW5jZWxhYmxlKSB7XG4gICAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBvdXRzaWRlIG9yIHNoYXJkIGV2ZW50XG4gICAgICAgIGlmICghc291cmNlRXZlbnQpIHtcbiAgICAgICAgICAgIHZhciBzaGFyZE5vZGVzID0gKGxhc3RQcm9wcy5jdXJyZW50LnNoYXJkcyB8fCBbXSlcbiAgICAgICAgICAgICAgICAubWFwKGV4dHJhY3RSZWYpXG4gICAgICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKVxuICAgICAgICAgICAgICAgIC5maWx0ZXIoZnVuY3Rpb24gKG5vZGUpIHsgcmV0dXJuIG5vZGUuY29udGFpbnMoZXZlbnQudGFyZ2V0KTsgfSk7XG4gICAgICAgICAgICB2YXIgc2hvdWxkU3RvcCA9IHNoYXJkTm9kZXMubGVuZ3RoID4gMCA/IHNob3VsZENhbmNlbEV2ZW50KGV2ZW50LCBzaGFyZE5vZGVzWzBdKSA6ICFsYXN0UHJvcHMuY3VycmVudC5ub0lzb2xhdGlvbjtcbiAgICAgICAgICAgIGlmIChzaG91bGRTdG9wKSB7XG4gICAgICAgICAgICAgICAgaWYgKGV2ZW50LmNhbmNlbGFibGUpIHtcbiAgICAgICAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbXSk7XG4gICAgdmFyIHNob3VsZENhbmNlbCA9IFJlYWN0LnVzZUNhbGxiYWNrKGZ1bmN0aW9uIChuYW1lLCBkZWx0YSwgdGFyZ2V0LCBzaG91bGQpIHtcbiAgICAgICAgdmFyIGV2ZW50ID0geyBuYW1lOiBuYW1lLCBkZWx0YTogZGVsdGEsIHRhcmdldDogdGFyZ2V0LCBzaG91bGQ6IHNob3VsZCwgc2hhZG93UGFyZW50OiBnZXRPdXRlcm1vc3RTaGFkb3dQYXJlbnQodGFyZ2V0KSB9O1xuICAgICAgICBzaG91bGRQcmV2ZW50UXVldWUuY3VycmVudC5wdXNoKGV2ZW50KTtcbiAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBzaG91bGRQcmV2ZW50UXVldWUuY3VycmVudCA9IHNob3VsZFByZXZlbnRRdWV1ZS5jdXJyZW50LmZpbHRlcihmdW5jdGlvbiAoZSkgeyByZXR1cm4gZSAhPT0gZXZlbnQ7IH0pO1xuICAgICAgICB9LCAxKTtcbiAgICB9LCBbXSk7XG4gICAgdmFyIHNjcm9sbFRvdWNoU3RhcnQgPSBSZWFjdC51c2VDYWxsYmFjayhmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgdG91Y2hTdGFydFJlZi5jdXJyZW50ID0gZ2V0VG91Y2hYWShldmVudCk7XG4gICAgICAgIGFjdGl2ZUF4aXMuY3VycmVudCA9IHVuZGVmaW5lZDtcbiAgICB9LCBbXSk7XG4gICAgdmFyIHNjcm9sbFdoZWVsID0gUmVhY3QudXNlQ2FsbGJhY2soZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgIHNob3VsZENhbmNlbChldmVudC50eXBlLCBnZXREZWx0YVhZKGV2ZW50KSwgZXZlbnQudGFyZ2V0LCBzaG91bGRDYW5jZWxFdmVudChldmVudCwgcHJvcHMubG9ja1JlZi5jdXJyZW50KSk7XG4gICAgfSwgW10pO1xuICAgIHZhciBzY3JvbGxUb3VjaE1vdmUgPSBSZWFjdC51c2VDYWxsYmFjayhmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgc2hvdWxkQ2FuY2VsKGV2ZW50LnR5cGUsIGdldFRvdWNoWFkoZXZlbnQpLCBldmVudC50YXJnZXQsIHNob3VsZENhbmNlbEV2ZW50KGV2ZW50LCBwcm9wcy5sb2NrUmVmLmN1cnJlbnQpKTtcbiAgICB9LCBbXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgbG9ja1N0YWNrLnB1c2goU3R5bGUpO1xuICAgICAgICBwcm9wcy5zZXRDYWxsYmFja3Moe1xuICAgICAgICAgICAgb25TY3JvbGxDYXB0dXJlOiBzY3JvbGxXaGVlbCxcbiAgICAgICAgICAgIG9uV2hlZWxDYXB0dXJlOiBzY3JvbGxXaGVlbCxcbiAgICAgICAgICAgIG9uVG91Y2hNb3ZlQ2FwdHVyZTogc2Nyb2xsVG91Y2hNb3ZlLFxuICAgICAgICB9KTtcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignd2hlZWwnLCBzaG91bGRQcmV2ZW50LCBub25QYXNzaXZlKTtcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigndG91Y2htb3ZlJywgc2hvdWxkUHJldmVudCwgbm9uUGFzc2l2ZSk7XG4gICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3RvdWNoc3RhcnQnLCBzY3JvbGxUb3VjaFN0YXJ0LCBub25QYXNzaXZlKTtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGxvY2tTdGFjayA9IGxvY2tTdGFjay5maWx0ZXIoZnVuY3Rpb24gKGluc3QpIHsgcmV0dXJuIGluc3QgIT09IFN0eWxlOyB9KTtcbiAgICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3doZWVsJywgc2hvdWxkUHJldmVudCwgbm9uUGFzc2l2ZSk7XG4gICAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCd0b3VjaG1vdmUnLCBzaG91bGRQcmV2ZW50LCBub25QYXNzaXZlKTtcbiAgICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3RvdWNoc3RhcnQnLCBzY3JvbGxUb3VjaFN0YXJ0LCBub25QYXNzaXZlKTtcbiAgICAgICAgfTtcbiAgICB9LCBbXSk7XG4gICAgdmFyIHJlbW92ZVNjcm9sbEJhciA9IHByb3BzLnJlbW92ZVNjcm9sbEJhciwgaW5lcnQgPSBwcm9wcy5pbmVydDtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsXG4gICAgICAgIGluZXJ0ID8gUmVhY3QuY3JlYXRlRWxlbWVudChTdHlsZSwgeyBzdHlsZXM6IGdlbmVyYXRlU3R5bGUoaWQpIH0pIDogbnVsbCxcbiAgICAgICAgcmVtb3ZlU2Nyb2xsQmFyID8gUmVhY3QuY3JlYXRlRWxlbWVudChSZW1vdmVTY3JvbGxCYXIsIHsgbm9SZWxhdGl2ZTogcHJvcHMubm9SZWxhdGl2ZSwgZ2FwTW9kZTogcHJvcHMuZ2FwTW9kZSB9KSA6IG51bGwpKTtcbn1cbmZ1bmN0aW9uIGdldE91dGVybW9zdFNoYWRvd1BhcmVudChub2RlKSB7XG4gICAgdmFyIHNoYWRvd1BhcmVudCA9IG51bGw7XG4gICAgd2hpbGUgKG5vZGUgIT09IG51bGwpIHtcbiAgICAgICAgaWYgKG5vZGUgaW5zdGFuY2VvZiBTaGFkb3dSb290KSB7XG4gICAgICAgICAgICBzaGFkb3dQYXJlbnQgPSBub2RlLmhvc3Q7XG4gICAgICAgICAgICBub2RlID0gbm9kZS5ob3N0O1xuICAgICAgICB9XG4gICAgICAgIG5vZGUgPSBub2RlLnBhcmVudE5vZGU7XG4gICAgfVxuICAgIHJldHVybiBzaGFkb3dQYXJlbnQ7XG59XG4iLCJpbXBvcnQgeyBleHBvcnRTaWRlY2FyIH0gZnJvbSAndXNlLXNpZGVjYXInO1xuaW1wb3J0IHsgUmVtb3ZlU2Nyb2xsU2lkZUNhciB9IGZyb20gJy4vU2lkZUVmZmVjdCc7XG5pbXBvcnQgeyBlZmZlY3RDYXIgfSBmcm9tICcuL21lZGl1bSc7XG5leHBvcnQgZGVmYXVsdCBleHBvcnRTaWRlY2FyKGVmZmVjdENhciwgUmVtb3ZlU2Nyb2xsU2lkZUNhcik7XG4iLCJpbXBvcnQgeyBfX2Fzc2lnbiB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgUmVtb3ZlU2Nyb2xsIH0gZnJvbSAnLi9VSSc7XG5pbXBvcnQgU2lkZUNhciBmcm9tICcuL3NpZGVjYXInO1xudmFyIFJlYWN0UmVtb3ZlU2Nyb2xsID0gUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiAocHJvcHMsIHJlZikgeyByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVtb3ZlU2Nyb2xsLCBfX2Fzc2lnbih7fSwgcHJvcHMsIHsgcmVmOiByZWYsIHNpZGVDYXI6IFNpZGVDYXIgfSkpKTsgfSk7XG5SZWFjdFJlbW92ZVNjcm9sbC5jbGFzc05hbWVzID0gUmVtb3ZlU2Nyb2xsLmNsYXNzTmFtZXM7XG5leHBvcnQgZGVmYXVsdCBSZWFjdFJlbW92ZVNjcm9sbDtcbiIsInZhciBnZXREZWZhdWx0UGFyZW50ID0gZnVuY3Rpb24gKG9yaWdpbmFsVGFyZ2V0KSB7XG4gICAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHZhciBzYW1wbGVUYXJnZXQgPSBBcnJheS5pc0FycmF5KG9yaWdpbmFsVGFyZ2V0KSA/IG9yaWdpbmFsVGFyZ2V0WzBdIDogb3JpZ2luYWxUYXJnZXQ7XG4gICAgcmV0dXJuIHNhbXBsZVRhcmdldC5vd25lckRvY3VtZW50LmJvZHk7XG59O1xudmFyIGNvdW50ZXJNYXAgPSBuZXcgV2Vha01hcCgpO1xudmFyIHVuY29udHJvbGxlZE5vZGVzID0gbmV3IFdlYWtNYXAoKTtcbnZhciBtYXJrZXJNYXAgPSB7fTtcbnZhciBsb2NrQ291bnQgPSAwO1xudmFyIHVud3JhcEhvc3QgPSBmdW5jdGlvbiAobm9kZSkge1xuICAgIHJldHVybiBub2RlICYmIChub2RlLmhvc3QgfHwgdW53cmFwSG9zdChub2RlLnBhcmVudE5vZGUpKTtcbn07XG52YXIgY29ycmVjdFRhcmdldHMgPSBmdW5jdGlvbiAocGFyZW50LCB0YXJnZXRzKSB7XG4gICAgcmV0dXJuIHRhcmdldHNcbiAgICAgICAgLm1hcChmdW5jdGlvbiAodGFyZ2V0KSB7XG4gICAgICAgIGlmIChwYXJlbnQuY29udGFpbnModGFyZ2V0KSkge1xuICAgICAgICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICAgICAgfVxuICAgICAgICB2YXIgY29ycmVjdGVkVGFyZ2V0ID0gdW53cmFwSG9zdCh0YXJnZXQpO1xuICAgICAgICBpZiAoY29ycmVjdGVkVGFyZ2V0ICYmIHBhcmVudC5jb250YWlucyhjb3JyZWN0ZWRUYXJnZXQpKSB7XG4gICAgICAgICAgICByZXR1cm4gY29ycmVjdGVkVGFyZ2V0O1xuICAgICAgICB9XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ2FyaWEtaGlkZGVuJywgdGFyZ2V0LCAnaW4gbm90IGNvbnRhaW5lZCBpbnNpZGUnLCBwYXJlbnQsICcuIERvaW5nIG5vdGhpbmcnKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfSlcbiAgICAgICAgLmZpbHRlcihmdW5jdGlvbiAoeCkgeyByZXR1cm4gQm9vbGVhbih4KTsgfSk7XG59O1xuLyoqXG4gKiBNYXJrcyBldmVyeXRoaW5nIGV4Y2VwdCBnaXZlbiBub2RlKG9yIG5vZGVzKSBhcyBhcmlhLWhpZGRlblxuICogQHBhcmFtIHtFbGVtZW50IHwgRWxlbWVudFtdfSBvcmlnaW5hbFRhcmdldCAtIGVsZW1lbnRzIHRvIGtlZXAgb24gdGhlIHBhZ2VcbiAqIEBwYXJhbSBbcGFyZW50Tm9kZV0gLSB0b3AgZWxlbWVudCwgZGVmYXVsdHMgdG8gZG9jdW1lbnQuYm9keVxuICogQHBhcmFtIHtTdHJpbmd9IFttYXJrZXJOYW1lXSAtIGEgc3BlY2lhbCBhdHRyaWJ1dGUgdG8gbWFyayBldmVyeSBub2RlXG4gKiBAcGFyYW0ge1N0cmluZ30gW2NvbnRyb2xBdHRyaWJ1dGVdIC0gaHRtbCBBdHRyaWJ1dGUgdG8gY29udHJvbFxuICogQHJldHVybiB7VW5kb30gdW5kbyBjb21tYW5kXG4gKi9cbnZhciBhcHBseUF0dHJpYnV0ZVRvT3RoZXJzID0gZnVuY3Rpb24gKG9yaWdpbmFsVGFyZ2V0LCBwYXJlbnROb2RlLCBtYXJrZXJOYW1lLCBjb250cm9sQXR0cmlidXRlKSB7XG4gICAgdmFyIHRhcmdldHMgPSBjb3JyZWN0VGFyZ2V0cyhwYXJlbnROb2RlLCBBcnJheS5pc0FycmF5KG9yaWdpbmFsVGFyZ2V0KSA/IG9yaWdpbmFsVGFyZ2V0IDogW29yaWdpbmFsVGFyZ2V0XSk7XG4gICAgaWYgKCFtYXJrZXJNYXBbbWFya2VyTmFtZV0pIHtcbiAgICAgICAgbWFya2VyTWFwW21hcmtlck5hbWVdID0gbmV3IFdlYWtNYXAoKTtcbiAgICB9XG4gICAgdmFyIG1hcmtlckNvdW50ZXIgPSBtYXJrZXJNYXBbbWFya2VyTmFtZV07XG4gICAgdmFyIGhpZGRlbk5vZGVzID0gW107XG4gICAgdmFyIGVsZW1lbnRzVG9LZWVwID0gbmV3IFNldCgpO1xuICAgIHZhciBlbGVtZW50c1RvU3RvcCA9IG5ldyBTZXQodGFyZ2V0cyk7XG4gICAgdmFyIGtlZXAgPSBmdW5jdGlvbiAoZWwpIHtcbiAgICAgICAgaWYgKCFlbCB8fCBlbGVtZW50c1RvS2VlcC5oYXMoZWwpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgZWxlbWVudHNUb0tlZXAuYWRkKGVsKTtcbiAgICAgICAga2VlcChlbC5wYXJlbnROb2RlKTtcbiAgICB9O1xuICAgIHRhcmdldHMuZm9yRWFjaChrZWVwKTtcbiAgICB2YXIgZGVlcCA9IGZ1bmN0aW9uIChwYXJlbnQpIHtcbiAgICAgICAgaWYgKCFwYXJlbnQgfHwgZWxlbWVudHNUb1N0b3AuaGFzKHBhcmVudCkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBBcnJheS5wcm90b3R5cGUuZm9yRWFjaC5jYWxsKHBhcmVudC5jaGlsZHJlbiwgZnVuY3Rpb24gKG5vZGUpIHtcbiAgICAgICAgICAgIGlmIChlbGVtZW50c1RvS2VlcC5oYXMobm9kZSkpIHtcbiAgICAgICAgICAgICAgICBkZWVwKG5vZGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGF0dHIgPSBub2RlLmdldEF0dHJpYnV0ZShjb250cm9sQXR0cmlidXRlKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFscmVhZHlIaWRkZW4gPSBhdHRyICE9PSBudWxsICYmIGF0dHIgIT09ICdmYWxzZSc7XG4gICAgICAgICAgICAgICAgICAgIHZhciBjb3VudGVyVmFsdWUgPSAoY291bnRlck1hcC5nZXQobm9kZSkgfHwgMCkgKyAxO1xuICAgICAgICAgICAgICAgICAgICB2YXIgbWFya2VyVmFsdWUgPSAobWFya2VyQ291bnRlci5nZXQobm9kZSkgfHwgMCkgKyAxO1xuICAgICAgICAgICAgICAgICAgICBjb3VudGVyTWFwLnNldChub2RlLCBjb3VudGVyVmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBtYXJrZXJDb3VudGVyLnNldChub2RlLCBtYXJrZXJWYWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIGhpZGRlbk5vZGVzLnB1c2gobm9kZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb3VudGVyVmFsdWUgPT09IDEgJiYgYWxyZWFkeUhpZGRlbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdW5jb250cm9sbGVkTm9kZXMuc2V0KG5vZGUsIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChtYXJrZXJWYWx1ZSA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUobWFya2VyTmFtZSwgJ3RydWUnKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoIWFscmVhZHlIaWRkZW4pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vZGUuc2V0QXR0cmlidXRlKGNvbnRyb2xBdHRyaWJ1dGUsICd0cnVlJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignYXJpYS1oaWRkZW46IGNhbm5vdCBvcGVyYXRlIG9uICcsIG5vZGUsIGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBkZWVwKHBhcmVudE5vZGUpO1xuICAgIGVsZW1lbnRzVG9LZWVwLmNsZWFyKCk7XG4gICAgbG9ja0NvdW50Kys7XG4gICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaGlkZGVuTm9kZXMuZm9yRWFjaChmdW5jdGlvbiAobm9kZSkge1xuICAgICAgICAgICAgdmFyIGNvdW50ZXJWYWx1ZSA9IGNvdW50ZXJNYXAuZ2V0KG5vZGUpIC0gMTtcbiAgICAgICAgICAgIHZhciBtYXJrZXJWYWx1ZSA9IG1hcmtlckNvdW50ZXIuZ2V0KG5vZGUpIC0gMTtcbiAgICAgICAgICAgIGNvdW50ZXJNYXAuc2V0KG5vZGUsIGNvdW50ZXJWYWx1ZSk7XG4gICAgICAgICAgICBtYXJrZXJDb3VudGVyLnNldChub2RlLCBtYXJrZXJWYWx1ZSk7XG4gICAgICAgICAgICBpZiAoIWNvdW50ZXJWYWx1ZSkge1xuICAgICAgICAgICAgICAgIGlmICghdW5jb250cm9sbGVkTm9kZXMuaGFzKG5vZGUpKSB7XG4gICAgICAgICAgICAgICAgICAgIG5vZGUucmVtb3ZlQXR0cmlidXRlKGNvbnRyb2xBdHRyaWJ1dGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB1bmNvbnRyb2xsZWROb2Rlcy5kZWxldGUobm9kZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIW1hcmtlclZhbHVlKSB7XG4gICAgICAgICAgICAgICAgbm9kZS5yZW1vdmVBdHRyaWJ1dGUobWFya2VyTmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBsb2NrQ291bnQtLTtcbiAgICAgICAgaWYgKCFsb2NrQ291bnQpIHtcbiAgICAgICAgICAgIC8vIGNsZWFyXG4gICAgICAgICAgICBjb3VudGVyTWFwID0gbmV3IFdlYWtNYXAoKTtcbiAgICAgICAgICAgIGNvdW50ZXJNYXAgPSBuZXcgV2Vha01hcCgpO1xuICAgICAgICAgICAgdW5jb250cm9sbGVkTm9kZXMgPSBuZXcgV2Vha01hcCgpO1xuICAgICAgICAgICAgbWFya2VyTWFwID0ge307XG4gICAgICAgIH1cbiAgICB9O1xufTtcbi8qKlxuICogTWFya3MgZXZlcnl0aGluZyBleGNlcHQgZ2l2ZW4gbm9kZShvciBub2RlcykgYXMgYXJpYS1oaWRkZW5cbiAqIEBwYXJhbSB7RWxlbWVudCB8IEVsZW1lbnRbXX0gb3JpZ2luYWxUYXJnZXQgLSBlbGVtZW50cyB0byBrZWVwIG9uIHRoZSBwYWdlXG4gKiBAcGFyYW0gW3BhcmVudE5vZGVdIC0gdG9wIGVsZW1lbnQsIGRlZmF1bHRzIHRvIGRvY3VtZW50LmJvZHlcbiAqIEBwYXJhbSB7U3RyaW5nfSBbbWFya2VyTmFtZV0gLSBhIHNwZWNpYWwgYXR0cmlidXRlIHRvIG1hcmsgZXZlcnkgbm9kZVxuICogQHJldHVybiB7VW5kb30gdW5kbyBjb21tYW5kXG4gKi9cbmV4cG9ydCB2YXIgaGlkZU90aGVycyA9IGZ1bmN0aW9uIChvcmlnaW5hbFRhcmdldCwgcGFyZW50Tm9kZSwgbWFya2VyTmFtZSkge1xuICAgIGlmIChtYXJrZXJOYW1lID09PSB2b2lkIDApIHsgbWFya2VyTmFtZSA9ICdkYXRhLWFyaWEtaGlkZGVuJzsgfVxuICAgIHZhciB0YXJnZXRzID0gQXJyYXkuZnJvbShBcnJheS5pc0FycmF5KG9yaWdpbmFsVGFyZ2V0KSA/IG9yaWdpbmFsVGFyZ2V0IDogW29yaWdpbmFsVGFyZ2V0XSk7XG4gICAgdmFyIGFjdGl2ZVBhcmVudE5vZGUgPSBwYXJlbnROb2RlIHx8IGdldERlZmF1bHRQYXJlbnQob3JpZ2luYWxUYXJnZXQpO1xuICAgIGlmICghYWN0aXZlUGFyZW50Tm9kZSkge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKCkgeyByZXR1cm4gbnVsbDsgfTtcbiAgICB9XG4gICAgLy8gd2Ugc2hvdWxkIG5vdCBoaWRlIGFyaWEtbGl2ZSBlbGVtZW50cyAtIGh0dHBzOi8vZ2l0aHViLmNvbS90aGVLYXNoZXkvYXJpYS1oaWRkZW4vaXNzdWVzLzEwXG4gICAgLy8gYW5kIHNjcmlwdCBlbGVtZW50cywgYXMgdGhleSBoYXZlIG5vIGltcGFjdCBvbiBhY2Nlc3NpYmlsaXR5LlxuICAgIHRhcmdldHMucHVzaC5hcHBseSh0YXJnZXRzLCBBcnJheS5mcm9tKGFjdGl2ZVBhcmVudE5vZGUucXVlcnlTZWxlY3RvckFsbCgnW2FyaWEtbGl2ZV0sIHNjcmlwdCcpKSk7XG4gICAgcmV0dXJuIGFwcGx5QXR0cmlidXRlVG9PdGhlcnModGFyZ2V0cywgYWN0aXZlUGFyZW50Tm9kZSwgbWFya2VyTmFtZSwgJ2FyaWEtaGlkZGVuJyk7XG59O1xuLyoqXG4gKiBNYXJrcyBldmVyeXRoaW5nIGV4Y2VwdCBnaXZlbiBub2RlKG9yIG5vZGVzKSBhcyBpbmVydFxuICogQHBhcmFtIHtFbGVtZW50IHwgRWxlbWVudFtdfSBvcmlnaW5hbFRhcmdldCAtIGVsZW1lbnRzIHRvIGtlZXAgb24gdGhlIHBhZ2VcbiAqIEBwYXJhbSBbcGFyZW50Tm9kZV0gLSB0b3AgZWxlbWVudCwgZGVmYXVsdHMgdG8gZG9jdW1lbnQuYm9keVxuICogQHBhcmFtIHtTdHJpbmd9IFttYXJrZXJOYW1lXSAtIGEgc3BlY2lhbCBhdHRyaWJ1dGUgdG8gbWFyayBldmVyeSBub2RlXG4gKiBAcmV0dXJuIHtVbmRvfSB1bmRvIGNvbW1hbmRcbiAqL1xuZXhwb3J0IHZhciBpbmVydE90aGVycyA9IGZ1bmN0aW9uIChvcmlnaW5hbFRhcmdldCwgcGFyZW50Tm9kZSwgbWFya2VyTmFtZSkge1xuICAgIGlmIChtYXJrZXJOYW1lID09PSB2b2lkIDApIHsgbWFya2VyTmFtZSA9ICdkYXRhLWluZXJ0LWVkJzsgfVxuICAgIHZhciBhY3RpdmVQYXJlbnROb2RlID0gcGFyZW50Tm9kZSB8fCBnZXREZWZhdWx0UGFyZW50KG9yaWdpbmFsVGFyZ2V0KTtcbiAgICBpZiAoIWFjdGl2ZVBhcmVudE5vZGUpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHsgcmV0dXJuIG51bGw7IH07XG4gICAgfVxuICAgIHJldHVybiBhcHBseUF0dHJpYnV0ZVRvT3RoZXJzKG9yaWdpbmFsVGFyZ2V0LCBhY3RpdmVQYXJlbnROb2RlLCBtYXJrZXJOYW1lLCAnaW5lcnQnKTtcbn07XG4vKipcbiAqIEByZXR1cm5zIGlmIGN1cnJlbnQgYnJvd3NlciBzdXBwb3J0cyBpbmVydFxuICovXG5leHBvcnQgdmFyIHN1cHBvcnRzSW5lcnQgPSBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHR5cGVvZiBIVE1MRWxlbWVudCAhPT0gJ3VuZGVmaW5lZCcgJiYgSFRNTEVsZW1lbnQucHJvdG90eXBlLmhhc093blByb3BlcnR5KCdpbmVydCcpO1xufTtcbi8qKlxuICogQXV0b21hdGljIGZ1bmN0aW9uIHRvIFwic3VwcHJlc3NcIiBET00gZWxlbWVudHMgLSBfaGlkZV8gb3IgX2luZXJ0XyBpbiB0aGUgYmVzdCBwb3NzaWJsZSB3YXlcbiAqIEBwYXJhbSB7RWxlbWVudCB8IEVsZW1lbnRbXX0gb3JpZ2luYWxUYXJnZXQgLSBlbGVtZW50cyB0byBrZWVwIG9uIHRoZSBwYWdlXG4gKiBAcGFyYW0gW3BhcmVudE5vZGVdIC0gdG9wIGVsZW1lbnQsIGRlZmF1bHRzIHRvIGRvY3VtZW50LmJvZHlcbiAqIEBwYXJhbSB7U3RyaW5nfSBbbWFya2VyTmFtZV0gLSBhIHNwZWNpYWwgYXR0cmlidXRlIHRvIG1hcmsgZXZlcnkgbm9kZVxuICogQHJldHVybiB7VW5kb30gdW5kbyBjb21tYW5kXG4gKi9cbmV4cG9ydCB2YXIgc3VwcHJlc3NPdGhlcnMgPSBmdW5jdGlvbiAob3JpZ2luYWxUYXJnZXQsIHBhcmVudE5vZGUsIG1hcmtlck5hbWUpIHtcbiAgICBpZiAobWFya2VyTmFtZSA9PT0gdm9pZCAwKSB7IG1hcmtlck5hbWUgPSAnZGF0YS1zdXBwcmVzc2VkJzsgfVxuICAgIHJldHVybiAoc3VwcG9ydHNJbmVydCgpID8gaW5lcnRPdGhlcnMgOiBoaWRlT3RoZXJzKShvcmlnaW5hbFRhcmdldCwgcGFyZW50Tm9kZSwgbWFya2VyTmFtZSk7XG59O1xuIiwiXCJ1c2UgY2xpZW50XCI7XG52YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fbmFtZSA9ICh0YXJnZXQsIHZhbHVlKSA9PiBfX2RlZlByb3AodGFyZ2V0LCBcIm5hbWVcIiwgeyB2YWx1ZSwgY29uZmlndXJhYmxlOiB0cnVlIH0pO1xuXG4vLyBzcmMvZGlhbG9nLnRzeFxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjb21wb3NlRXZlbnRIYW5kbGVycyB9IGZyb20gXCJAcmFkaXgtdWkvcHJpbWl0aXZlXCI7XG5pbXBvcnQgeyB1c2VDb21wb3NlZFJlZnMgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LWNvbXBvc2UtcmVmc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ29udGV4dFNjb3BlIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1jb250ZXh0XCI7XG5pbXBvcnQgeyB1c2VJZCB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtaWRcIjtcbmltcG9ydCB7IHVzZUNvbnRyb2xsYWJsZVN0YXRlIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC11c2UtY29udHJvbGxhYmxlLXN0YXRlXCI7XG5pbXBvcnQgeyBEaXNtaXNzYWJsZUxheWVyLCB1c2VEaXNtaXNzYWJsZUxheWVyU3VyZmFjZSB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtZGlzbWlzc2FibGUtbGF5ZXJcIjtcbmltcG9ydCB7XG4gIEZvY3VzU2NvcGUsXG4gIEZvY3VzU2NvcGVCcmFuY2hQcm92aWRlcixcbiAgdXNlRm9jdXNTY29wZUJyYW5jaFJlZ2lzdHJ5XG59IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtZm9jdXMtc2NvcGVcIjtcbmltcG9ydCB7IFBvcnRhbCBhcyBQb3J0YWxQcmltaXRpdmUgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXBvcnRhbFwiO1xuaW1wb3J0IHsgUHJlc2VuY2UgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXByZXNlbmNlXCI7XG5pbXBvcnQgeyBQcmltaXRpdmUgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXByaW1pdGl2ZVwiO1xuaW1wb3J0IHsgdXNlRm9jdXNHdWFyZHMgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LWZvY3VzLWd1YXJkc1wiO1xuaW1wb3J0IHsgdXNlTGF5b3V0RWZmZWN0IH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC11c2UtbGF5b3V0LWVmZmVjdFwiO1xuaW1wb3J0IHsgUmVtb3ZlU2Nyb2xsIH0gZnJvbSBcInJlYWN0LXJlbW92ZS1zY3JvbGxcIjtcbmltcG9ydCB7IGhpZGVPdGhlcnMgfSBmcm9tIFwiYXJpYS1oaWRkZW5cIjtcbmltcG9ydCB7IGNyZWF0ZVNsb3QgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXNsb3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xudmFyIERJQUxPR19OQU1FID0gXCJEaWFsb2dcIjtcbnZhciBbY3JlYXRlRGlhbG9nQ29udGV4dCwgY3JlYXRlRGlhbG9nU2NvcGVdID0gY3JlYXRlQ29udGV4dFNjb3BlKERJQUxPR19OQU1FKTtcbnZhciBbRGlhbG9nUHJvdmlkZXIsIHVzZURpYWxvZ0NvbnRleHRdID0gY3JlYXRlRGlhbG9nQ29udGV4dChESUFMT0dfTkFNRSk7XG52YXIgRGlhbG9nID0gLyogQF9fUFVSRV9fICovIF9fbmFtZSgocHJvcHMpID0+IHtcbiAgY29uc3Qge1xuICAgIF9fc2NvcGVEaWFsb2csXG4gICAgY2hpbGRyZW4sXG4gICAgb3Blbjogb3BlblByb3AsXG4gICAgZGVmYXVsdE9wZW4sXG4gICAgb25PcGVuQ2hhbmdlLFxuICAgIG1vZGFsID0gdHJ1ZVxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHRyaWdnZXJSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGNvbnRlbnRSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IHsgbm9kZXM6IGJyYW5jaE5vZGVzLCByZWdpc3RyeTogYnJhbmNoUmVnaXN0cnkgfSA9IHVzZUZvY3VzU2NvcGVCcmFuY2hSZWdpc3RyeSgpO1xuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VDb250cm9sbGFibGVTdGF0ZSh7XG4gICAgcHJvcDogb3BlblByb3AsXG4gICAgZGVmYXVsdFByb3A6IGRlZmF1bHRPcGVuID8/IGZhbHNlLFxuICAgIG9uQ2hhbmdlOiBvbk9wZW5DaGFuZ2UsXG4gICAgY2FsbGVyOiBESUFMT0dfTkFNRVxuICB9KTtcbiAgY29uc3QgW3RpdGxlQ291bnQsIHNldFRpdGxlQ291bnRdID0gUmVhY3QudXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtkZXNjcmlwdGlvbkNvdW50LCBzZXREZXNjcmlwdGlvbkNvdW50XSA9IFJlYWN0LnVzZVN0YXRlKDApO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcbiAgICBEaWFsb2dQcm92aWRlcixcbiAgICB7XG4gICAgICBzY29wZTogX19zY29wZURpYWxvZyxcbiAgICAgIHRyaWdnZXJSZWYsXG4gICAgICBjb250ZW50UmVmLFxuICAgICAgY29udGVudElkOiB1c2VJZCgpLFxuICAgICAgdGl0bGVJZDogdXNlSWQoKSxcbiAgICAgIGRlc2NyaXB0aW9uSWQ6IHVzZUlkKCksXG4gICAgICB0aXRsZVByZXNlbnQ6IHRpdGxlQ291bnQgPiAwLFxuICAgICAgZGVzY3JpcHRpb25QcmVzZW50OiBkZXNjcmlwdGlvbkNvdW50ID4gMCxcbiAgICAgIHNldFRpdGxlQ291bnQsXG4gICAgICBzZXREZXNjcmlwdGlvbkNvdW50LFxuICAgICAgb3BlbixcbiAgICAgIG9uT3BlbkNoYW5nZTogc2V0T3BlbixcbiAgICAgIG9uT3BlblRvZ2dsZTogUmVhY3QudXNlQ2FsbGJhY2soKCkgPT4gc2V0T3BlbigocHJldk9wZW4pID0+ICFwcmV2T3BlbiksIFtzZXRPcGVuXSksXG4gICAgICBtb2RhbCxcbiAgICAgIGJyYW5jaE5vZGVzLFxuICAgICAgYnJhbmNoUmVnaXN0cnksXG4gICAgICBjaGlsZHJlblxuICAgIH1cbiAgKTtcbn0sIFwiRGlhbG9nXCIpO1xudmFyIFRSSUdHRVJfTkFNRSA9IFwiRGlhbG9nVHJpZ2dlclwiO1xudmFyIERpYWxvZ1RyaWdnZXIgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBEaWFsb2dUcmlnZ2VyMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3QgeyBfX3Njb3BlRGlhbG9nLCAuLi50cmlnZ2VyUHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VEaWFsb2dDb250ZXh0KFRSSUdHRVJfTkFNRSwgX19zY29wZURpYWxvZyk7XG4gICAgY29uc3QgY29tcG9zZWRUcmlnZ2VyUmVmID0gdXNlQ29tcG9zZWRSZWZzKGZvcndhcmRlZFJlZiwgY29udGV4dC50cmlnZ2VyUmVmKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgIFByaW1pdGl2ZS5idXR0b24sXG4gICAgICB7XG4gICAgICAgIHR5cGU6IFwiYnV0dG9uXCIsXG4gICAgICAgIFwiYXJpYS1oYXNwb3B1cFwiOiBcImRpYWxvZ1wiLFxuICAgICAgICBcImFyaWEtZXhwYW5kZWRcIjogY29udGV4dC5vcGVuLFxuICAgICAgICBcImFyaWEtY29udHJvbHNcIjogY29udGV4dC5vcGVuID8gY29udGV4dC5jb250ZW50SWQgOiB2b2lkIDAsXG4gICAgICAgIFwiZGF0YS1zdGF0ZVwiOiBnZXRTdGF0ZShjb250ZXh0Lm9wZW4pLFxuICAgICAgICAuLi50cmlnZ2VyUHJvcHMsXG4gICAgICAgIHJlZjogY29tcG9zZWRUcmlnZ2VyUmVmLFxuICAgICAgICBvbkNsaWNrOiBjb21wb3NlRXZlbnRIYW5kbGVycyhwcm9wcy5vbkNsaWNrLCBjb250ZXh0Lm9uT3BlblRvZ2dsZSlcbiAgICAgIH1cbiAgICApO1xuICB9LCBcIkRpYWxvZ1RyaWdnZXJcIilcbik7XG52YXIgUE9SVEFMX05BTUUgPSBcIkRpYWxvZ1BvcnRhbFwiO1xudmFyIFtQb3J0YWxQcm92aWRlciwgdXNlUG9ydGFsQ29udGV4dF0gPSBjcmVhdGVEaWFsb2dDb250ZXh0KFBPUlRBTF9OQU1FLCB7XG4gIGZvcmNlTW91bnQ6IHZvaWQgMFxufSk7XG52YXIgRGlhbG9nUG9ydGFsID0gLyogQF9fUFVSRV9fICovIF9fbmFtZSgocHJvcHMpID0+IHtcbiAgY29uc3QgeyBfX3Njb3BlRGlhbG9nLCBmb3JjZU1vdW50LCBjaGlsZHJlbiwgY29udGFpbmVyIH0gPSBwcm9wcztcbiAgY29uc3QgY29udGV4dCA9IHVzZURpYWxvZ0NvbnRleHQoUE9SVEFMX05BTUUsIF9fc2NvcGVEaWFsb2cpO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChQb3J0YWxQcm92aWRlciwgeyBzY29wZTogX19zY29wZURpYWxvZywgZm9yY2VNb3VudCwgY2hpbGRyZW46IFJlYWN0LkNoaWxkcmVuLm1hcChjaGlsZHJlbiwgKGNoaWxkKSA9PiAvKiBAX19QVVJFX18gKi8ganN4KFByZXNlbmNlLCB7IHByZXNlbnQ6IGZvcmNlTW91bnQgfHwgY29udGV4dC5vcGVuLCBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChQb3J0YWxQcmltaXRpdmUsIHsgYXNDaGlsZDogdHJ1ZSwgY29udGFpbmVyLCBjaGlsZHJlbjogY2hpbGQgfSkgfSkpIH0pO1xufSwgXCJEaWFsb2dQb3J0YWxcIik7XG52YXIgT1ZFUkxBWV9OQU1FID0gXCJEaWFsb2dPdmVybGF5XCI7XG52YXIgRGlhbG9nT3ZlcmxheSA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIERpYWxvZ092ZXJsYXkyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCBwb3J0YWxDb250ZXh0ID0gdXNlUG9ydGFsQ29udGV4dChPVkVSTEFZX05BTUUsIHByb3BzLl9fc2NvcGVEaWFsb2cpO1xuICAgIGNvbnN0IHsgZm9yY2VNb3VudCA9IHBvcnRhbENvbnRleHQuZm9yY2VNb3VudCwgLi4ub3ZlcmxheVByb3BzIH0gPSBwcm9wcztcbiAgICBjb25zdCBjb250ZXh0ID0gdXNlRGlhbG9nQ29udGV4dChPVkVSTEFZX05BTUUsIHByb3BzLl9fc2NvcGVEaWFsb2cpO1xuICAgIHJldHVybiBjb250ZXh0Lm1vZGFsID8gLyogQF9fUFVSRV9fICovIGpzeChQcmVzZW5jZSwgeyBwcmVzZW50OiBmb3JjZU1vdW50IHx8IGNvbnRleHQub3BlbiwgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goRGlhbG9nT3ZlcmxheUltcGwsIHsgLi4ub3ZlcmxheVByb3BzLCByZWY6IGZvcndhcmRlZFJlZiB9KSB9KSA6IG51bGw7XG4gIH0sIFwiRGlhbG9nT3ZlcmxheVwiKVxuKTtcbnZhciBTbG90ID0gY3JlYXRlU2xvdChcIkRpYWxvZ092ZXJsYXkuUmVtb3ZlU2Nyb2xsXCIpO1xudmFyIERpYWxvZ092ZXJsYXlJbXBsID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8vIGJsYW5rIGxpbmUgdG8gcmVkdWNlIGRpZmYgbm9pc2VcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBEaWFsb2dPdmVybGF5SW1wbDIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHsgX19zY29wZURpYWxvZywgLi4ub3ZlcmxheVByb3BzIH0gPSBwcm9wcztcbiAgICBjb25zdCBjb250ZXh0ID0gdXNlRGlhbG9nQ29udGV4dChPVkVSTEFZX05BTUUsIF9fc2NvcGVEaWFsb2cpO1xuICAgIGNvbnN0IHJlZ2lzdGVyRGlzbWlzc2FibGVTdXJmYWNlID0gdXNlRGlzbWlzc2FibGVMYXllclN1cmZhY2UoKTtcbiAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMoZm9yd2FyZGVkUmVmLCByZWdpc3RlckRpc21pc3NhYmxlU3VyZmFjZSk7XG4gICAgcmV0dXJuIChcbiAgICAgIC8vIE1ha2Ugc3VyZSBgQ29udGVudGAgaXMgc2Nyb2xsYWJsZSBldmVuIHdoZW4gaXQgZG9lc24ndCBsaXZlIGluc2lkZVxuICAgICAgLy8gYFJlbW92ZVNjcm9sbGAgKGVnLiB3aGVuIGBPdmVybGF5YCBhbmQgYENvbnRlbnRgIGFyZSBzaWJsaW5ncykuIE5lc3RlZFxuICAgICAgLy8gbGF5ZXJzIGFyZSByZWdpc3RlcmVkIGFzIGJyYW5jaGVzIGFuZCBhZGRlZCBhcyBzaGFyZHMgc28gdGhleSByZW1haW5cbiAgICAgIC8vIHNjcm9sbGFibGUgdG9vLiBTZWUgaHR0cHM6Ly9naXRodWIuY29tL3JhZGl4LXVpL3ByaW1pdGl2ZXMvaXNzdWVzLzM0MjNcbiAgICAgIC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICAgIFJlbW92ZVNjcm9sbCxcbiAgICAgICAge1xuICAgICAgICAgIGFzOiBTbG90LFxuICAgICAgICAgIGFsbG93UGluY2hab29tOiB0cnVlLFxuICAgICAgICAgIHNoYXJkczogUmVhY3QudXNlTWVtbyhcbiAgICAgICAgICAgICgpID0+IFtjb250ZXh0LmNvbnRlbnRSZWYsIC4uLmNvbnRleHQuYnJhbmNoTm9kZXMubWFwKChub2RlKSA9PiAoeyBjdXJyZW50OiBub2RlIH0pKV0sXG4gICAgICAgICAgICBbY29udGV4dC5jb250ZW50UmVmLCBjb250ZXh0LmJyYW5jaE5vZGVzXVxuICAgICAgICAgICksXG4gICAgICAgICAgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICAgICAgICBQcmltaXRpdmUuZGl2LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBcImRhdGEtc3RhdGVcIjogZ2V0U3RhdGUoY29udGV4dC5vcGVuKSxcbiAgICAgICAgICAgICAgLi4ub3ZlcmxheVByb3BzLFxuICAgICAgICAgICAgICByZWY6IGNvbXBvc2VkUmVmcyxcbiAgICAgICAgICAgICAgc3R5bGU6IHsgcG9pbnRlckV2ZW50czogXCJhdXRvXCIsIC4uLm92ZXJsYXlQcm9wcy5zdHlsZSB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICB9XG4gICAgICApXG4gICAgKTtcbiAgfSwgXCJEaWFsb2dPdmVybGF5SW1wbFwiKVxuKTtcbnZhciBDT05URU5UX05BTUUgPSBcIkRpYWxvZ0NvbnRlbnRcIjtcbnZhciBEaWFsb2dDb250ZW50ID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gRGlhbG9nQ29udGVudDIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHBvcnRhbENvbnRleHQgPSB1c2VQb3J0YWxDb250ZXh0KENPTlRFTlRfTkFNRSwgcHJvcHMuX19zY29wZURpYWxvZyk7XG4gICAgY29uc3QgeyBmb3JjZU1vdW50ID0gcG9ydGFsQ29udGV4dC5mb3JjZU1vdW50LCAuLi5jb250ZW50UHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VEaWFsb2dDb250ZXh0KENPTlRFTlRfTkFNRSwgcHJvcHMuX19zY29wZURpYWxvZyk7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUHJlc2VuY2UsIHsgcHJlc2VudDogZm9yY2VNb3VudCB8fCBjb250ZXh0Lm9wZW4sIGNoaWxkcmVuOiBjb250ZXh0Lm1vZGFsID8gLyogQF9fUFVSRV9fICovIGpzeChEaWFsb2dDb250ZW50TW9kYWwsIHsgLi4uY29udGVudFByb3BzLCByZWY6IGZvcndhcmRlZFJlZiB9KSA6IC8qIEBfX1BVUkVfXyAqLyBqc3goRGlhbG9nQ29udGVudE5vbk1vZGFsLCB7IC4uLmNvbnRlbnRQcm9wcywgcmVmOiBmb3J3YXJkZWRSZWYgfSkgfSk7XG4gIH0sIFwiRGlhbG9nQ29udGVudFwiKVxuKTtcbnZhciBEaWFsb2dDb250ZW50TW9kYWwgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLy8gYmxhbmsgbGluZSB0byByZWR1Y2UgZGlmZiBub2lzZVxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIERpYWxvZ0NvbnRlbnRNb2RhbDIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VEaWFsb2dDb250ZXh0KENPTlRFTlRfTkFNRSwgcHJvcHMuX19zY29wZURpYWxvZyk7XG4gICAgY29uc3QgY29udGVudFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMoZm9yd2FyZGVkUmVmLCBjb250ZXh0LmNvbnRlbnRSZWYsIGNvbnRlbnRSZWYpO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBjb25zdCBjb250ZW50ID0gY29udGVudFJlZi5jdXJyZW50O1xuICAgICAgaWYgKGNvbnRlbnQpIHJldHVybiBoaWRlT3RoZXJzKGNvbnRlbnQpO1xuICAgIH0sIFtdKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgIERpYWxvZ0NvbnRlbnRJbXBsLFxuICAgICAge1xuICAgICAgICAuLi5wcm9wcyxcbiAgICAgICAgcmVmOiBjb21wb3NlZFJlZnMsXG4gICAgICAgIHRyYXBGb2N1czogY29udGV4dC5vcGVuLFxuICAgICAgICBkaXNhYmxlT3V0c2lkZVBvaW50ZXJFdmVudHM6IGNvbnRleHQub3BlbixcbiAgICAgICAgb25DbG9zZUF1dG9Gb2N1czogY29tcG9zZUV2ZW50SGFuZGxlcnMocHJvcHMub25DbG9zZUF1dG9Gb2N1cywgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICBjb250ZXh0LnRyaWdnZXJSZWYuY3VycmVudD8uZm9jdXMoKTtcbiAgICAgICAgfSksXG4gICAgICAgIG9uUG9pbnRlckRvd25PdXRzaWRlOiBjb21wb3NlRXZlbnRIYW5kbGVycyhwcm9wcy5vblBvaW50ZXJEb3duT3V0c2lkZSwgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgY29uc3Qgb3JpZ2luYWxFdmVudCA9IGV2ZW50LmRldGFpbC5vcmlnaW5hbEV2ZW50O1xuICAgICAgICAgIGNvbnN0IGN0cmxMZWZ0Q2xpY2sgPSBvcmlnaW5hbEV2ZW50LmJ1dHRvbiA9PT0gMCAmJiBvcmlnaW5hbEV2ZW50LmN0cmxLZXkgPT09IHRydWU7XG4gICAgICAgICAgY29uc3QgaXNSaWdodENsaWNrID0gb3JpZ2luYWxFdmVudC5idXR0b24gPT09IDIgfHwgY3RybExlZnRDbGljaztcbiAgICAgICAgICBpZiAoaXNSaWdodENsaWNrKSBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB9KSxcbiAgICAgICAgb25Gb2N1c091dHNpZGU6IGNvbXBvc2VFdmVudEhhbmRsZXJzKFxuICAgICAgICAgIHByb3BzLm9uRm9jdXNPdXRzaWRlLFxuICAgICAgICAgIChldmVudCkgPT4gZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgICAgICApXG4gICAgICB9XG4gICAgKTtcbiAgfSwgXCJEaWFsb2dDb250ZW50TW9kYWxcIilcbik7XG52YXIgRGlhbG9nQ29udGVudE5vbk1vZGFsID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8vIGJsYW5rIGxpbmUgdG8gcmVkdWNlIGRpZmYgbm9pc2VcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBEaWFsb2dDb250ZW50Tm9uTW9kYWwyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCBjb250ZXh0ID0gdXNlRGlhbG9nQ29udGV4dChDT05URU5UX05BTUUsIHByb3BzLl9fc2NvcGVEaWFsb2cpO1xuICAgIGNvbnN0IGhhc0ludGVyYWN0ZWRPdXRzaWRlUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCBoYXNQb2ludGVyRG93bk91dHNpZGVSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgRGlhbG9nQ29udGVudEltcGwsXG4gICAgICB7XG4gICAgICAgIC4uLnByb3BzLFxuICAgICAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICAgICAgdHJhcEZvY3VzOiBmYWxzZSxcbiAgICAgICAgZGlzYWJsZU91dHNpZGVQb2ludGVyRXZlbnRzOiBmYWxzZSxcbiAgICAgICAgb25DbG9zZUF1dG9Gb2N1czogKGV2ZW50KSA9PiB7XG4gICAgICAgICAgcHJvcHMub25DbG9zZUF1dG9Gb2N1cz8uKGV2ZW50KTtcbiAgICAgICAgICBpZiAoIWV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICAgICAgICAgIGlmICghaGFzSW50ZXJhY3RlZE91dHNpZGVSZWYuY3VycmVudCkgY29udGV4dC50cmlnZ2VyUmVmLmN1cnJlbnQ/LmZvY3VzKCk7XG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBoYXNJbnRlcmFjdGVkT3V0c2lkZVJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgICAgaGFzUG9pbnRlckRvd25PdXRzaWRlUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgfSxcbiAgICAgICAgb25JbnRlcmFjdE91dHNpZGU6IChldmVudCkgPT4ge1xuICAgICAgICAgIHByb3BzLm9uSW50ZXJhY3RPdXRzaWRlPy4oZXZlbnQpO1xuICAgICAgICAgIGlmICghZXZlbnQuZGVmYXVsdFByZXZlbnRlZCkge1xuICAgICAgICAgICAgaGFzSW50ZXJhY3RlZE91dHNpZGVSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgICAgICBpZiAoZXZlbnQuZGV0YWlsLm9yaWdpbmFsRXZlbnQudHlwZSA9PT0gXCJwb2ludGVyZG93blwiKSB7XG4gICAgICAgICAgICAgIGhhc1BvaW50ZXJEb3duT3V0c2lkZVJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQudGFyZ2V0O1xuICAgICAgICAgIGNvbnN0IHRhcmdldElzVHJpZ2dlciA9IGNvbnRleHQudHJpZ2dlclJlZi5jdXJyZW50Py5jb250YWlucyh0YXJnZXQpO1xuICAgICAgICAgIGlmICh0YXJnZXRJc1RyaWdnZXIpIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgaWYgKGV2ZW50LmRldGFpbC5vcmlnaW5hbEV2ZW50LnR5cGUgPT09IFwiZm9jdXNpblwiICYmIGhhc1BvaW50ZXJEb3duT3V0c2lkZVJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICk7XG4gIH0sIFwiRGlhbG9nQ29udGVudE5vbk1vZGFsXCIpXG4pO1xudmFyIERpYWxvZ0NvbnRlbnRJbXBsID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8vIGJsYW5rIGxpbmUgdG8gcmVkdWNlIGRpZmYgbm9pc2VcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBEaWFsb2dDb250ZW50SW1wbDIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHtcbiAgICAgIF9fc2NvcGVEaWFsb2csXG4gICAgICB0cmFwRm9jdXMsXG4gICAgICBvbk9wZW5BdXRvRm9jdXMsXG4gICAgICBvbkNsb3NlQXV0b0ZvY3VzLFxuICAgICAgXCJhcmlhLWRlc2NyaWJlZGJ5XCI6IGFyaWFEZXNjcmliZWRieSxcbiAgICAgIGNoaWxkcmVuLFxuICAgICAgLi4uY29udGVudFByb3BzXG4gICAgfSA9IHByb3BzO1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VEaWFsb2dDb250ZXh0KENPTlRFTlRfTkFNRSwgX19zY29wZURpYWxvZyk7XG4gICAgdXNlRm9jdXNHdWFyZHMoKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChGb2N1c1Njb3BlQnJhbmNoUHJvdmlkZXIsIHsgcmVnaXN0cnk6IGNvbnRleHQuYnJhbmNoUmVnaXN0cnksIGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgRm9jdXNTY29wZSxcbiAgICAgIHtcbiAgICAgICAgYXNDaGlsZDogdHJ1ZSxcbiAgICAgICAgbG9vcDogdHJ1ZSxcbiAgICAgICAgdHJhcHBlZDogdHJhcEZvY3VzLFxuICAgICAgICBicmFuY2hlczogY29udGV4dC5icmFuY2hOb2RlcyxcbiAgICAgICAgb25Nb3VudEF1dG9Gb2N1czogb25PcGVuQXV0b0ZvY3VzLFxuICAgICAgICBvblVubW91bnRBdXRvRm9jdXM6IG9uQ2xvc2VBdXRvRm9jdXMsXG4gICAgICAgIGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgICAgIERpc21pc3NhYmxlTGF5ZXIsXG4gICAgICAgICAge1xuICAgICAgICAgICAgcm9sZTogXCJkaWFsb2dcIixcbiAgICAgICAgICAgIGlkOiBjb250ZXh0LmNvbnRlbnRJZCxcbiAgICAgICAgICAgIFwiYXJpYS1sYWJlbGxlZGJ5XCI6IGNvbnRleHQudGl0bGVQcmVzZW50ID8gY29udGV4dC50aXRsZUlkIDogdm9pZCAwLFxuICAgICAgICAgICAgXCJhcmlhLWRlc2NyaWJlZGJ5XCI6IGNvbnRleHQuZGVzY3JpcHRpb25QcmVzZW50ID8gY29uY2F0QXJpYURlc2NyaWJlZGJ5KGFyaWFEZXNjcmliZWRieSwgY29udGV4dC5kZXNjcmlwdGlvbklkKSA6IGFyaWFEZXNjcmliZWRieSxcbiAgICAgICAgICAgIFwiZGF0YS1zdGF0ZVwiOiBnZXRTdGF0ZShjb250ZXh0Lm9wZW4pLFxuICAgICAgICAgICAgLi4uY29udGVudFByb3BzLFxuICAgICAgICAgICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgICAgICAgICBkZWZlclBvaW50ZXJEb3duT3V0c2lkZTogdHJ1ZSxcbiAgICAgICAgICAgIG9uRGlzbWlzczogKCkgPT4gY29udGV4dC5vbk9wZW5DaGFuZ2UoZmFsc2UpLFxuICAgICAgICAgICAgY2hpbGRyZW5cbiAgICAgICAgICB9XG4gICAgICAgIClcbiAgICAgIH1cbiAgICApIH0pO1xuICB9LCBcIkRpYWxvZ0NvbnRlbnRJbXBsXCIpXG4pO1xudmFyIERpYWxvZ1RpdGxlID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gRGlhbG9nVGl0bGUyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IF9fc2NvcGVEaWFsb2csIC4uLnRpdGxlUHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VEaWFsb2dDb250ZXh0KFwiRGlhbG9nVGl0bGVcIiwgX19zY29wZURpYWxvZyk7XG4gICAgY29uc3QgeyBzZXRUaXRsZUNvdW50IH0gPSBjb250ZXh0O1xuICAgIHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICBzZXRUaXRsZUNvdW50KChjb3VudCkgPT4gY291bnQgKyAxKTtcbiAgICAgIHJldHVybiAoKSA9PiBzZXRUaXRsZUNvdW50KChjb3VudCkgPT4gY291bnQgLSAxKTtcbiAgICB9LCBbc2V0VGl0bGVDb3VudF0pO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFByaW1pdGl2ZS5oMiwgeyBpZDogY29udGV4dC50aXRsZUlkLCAuLi50aXRsZVByb3BzLCByZWY6IGZvcndhcmRlZFJlZiB9KTtcbiAgfSwgXCJEaWFsb2dUaXRsZVwiKVxuKTtcbnZhciBEaWFsb2dEZXNjcmlwdGlvbiA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvLyBibGFuayBsaW5lIHRvIHJlZHVjZSBkaWZmIG5vaXNlXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gRGlhbG9nRGVzY3JpcHRpb24yKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IF9fc2NvcGVEaWFsb2csIC4uLmRlc2NyaXB0aW9uUHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VEaWFsb2dDb250ZXh0KFwiRGlhbG9nRGVzY3JpcHRpb25cIiwgX19zY29wZURpYWxvZyk7XG4gICAgY29uc3QgeyBzZXREZXNjcmlwdGlvbkNvdW50IH0gPSBjb250ZXh0O1xuICAgIHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICBzZXREZXNjcmlwdGlvbkNvdW50KChjb3VudCkgPT4gY291bnQgKyAxKTtcbiAgICAgIHJldHVybiAoKSA9PiBzZXREZXNjcmlwdGlvbkNvdW50KChjb3VudCkgPT4gY291bnQgLSAxKTtcbiAgICB9LCBbc2V0RGVzY3JpcHRpb25Db3VudF0pO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFByaW1pdGl2ZS5wLCB7IGlkOiBjb250ZXh0LmRlc2NyaXB0aW9uSWQsIC4uLmRlc2NyaXB0aW9uUHJvcHMsIHJlZjogZm9yd2FyZGVkUmVmIH0pO1xuICB9LCBcIkRpYWxvZ0Rlc2NyaXB0aW9uXCIpXG4pO1xudmFyIENMT1NFX05BTUUgPSBcIkRpYWxvZ0Nsb3NlXCI7XG52YXIgRGlhbG9nQ2xvc2UgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBEaWFsb2dDbG9zZTIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHsgX19zY29wZURpYWxvZywgLi4uY2xvc2VQcm9wcyB9ID0gcHJvcHM7XG4gICAgY29uc3QgY29udGV4dCA9IHVzZURpYWxvZ0NvbnRleHQoQ0xPU0VfTkFNRSwgX19zY29wZURpYWxvZyk7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICBQcmltaXRpdmUuYnV0dG9uLFxuICAgICAge1xuICAgICAgICB0eXBlOiBcImJ1dHRvblwiLFxuICAgICAgICAuLi5jbG9zZVByb3BzLFxuICAgICAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICAgICAgb25DbGljazogY29tcG9zZUV2ZW50SGFuZGxlcnMocHJvcHMub25DbGljaywgKCkgPT4gY29udGV4dC5vbk9wZW5DaGFuZ2UoZmFsc2UpKVxuICAgICAgfVxuICAgICk7XG4gIH0sIFwiRGlhbG9nQ2xvc2VcIilcbik7XG52YXIgV2FybmluZ1Byb3ZpZGVyID0gLyogQF9fUFVSRV9fICovIF9fbmFtZSgocHJvcHMpID0+IHtcbiAgcmV0dXJuIHByb3BzLmNoaWxkcmVuO1xufSwgXCJXYXJuaW5nUHJvdmlkZXJcIik7XG5mdW5jdGlvbiBjb25jYXRBcmlhRGVzY3JpYmVkYnkoLi4udmFsdWVzKSB7XG4gIGNvbnN0IGlkcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gIGZvciAoY29uc3QgdmFsdWUgb2YgdmFsdWVzKSB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJzdHJpbmdcIikgY29udGludWU7XG4gICAgZm9yIChjb25zdCBpZCBvZiBTdHJpbmcodmFsdWUpLnRyaW0oKS5zcGxpdCgvXFxzKy8pKSB7XG4gICAgICBpZiAoaWQpIGlkcy5hZGQoaWQpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gaWRzLnNpemUgPiAwID8gQXJyYXkuZnJvbShpZHMpLmpvaW4oXCIgXCIpIDogdm9pZCAwO1xufVxuX19uYW1lKGNvbmNhdEFyaWFEZXNjcmliZWRieSwgXCJjb25jYXRBcmlhRGVzY3JpYmVkYnlcIik7XG5mdW5jdGlvbiBnZXRTdGF0ZShvcGVuKSB7XG4gIHJldHVybiBvcGVuID8gXCJvcGVuXCIgOiBcImNsb3NlZFwiO1xufVxuX19uYW1lKGdldFN0YXRlLCBcImdldFN0YXRlXCIpO1xuZXhwb3J0IHtcbiAgRGlhbG9nQ2xvc2UgYXMgQ2xvc2UsXG4gIERpYWxvZ0NvbnRlbnQgYXMgQ29udGVudCxcbiAgRGlhbG9nRGVzY3JpcHRpb24gYXMgRGVzY3JpcHRpb24sXG4gIERpYWxvZyxcbiAgRGlhbG9nQ2xvc2UsXG4gIERpYWxvZ0NvbnRlbnQsXG4gIERpYWxvZ0Rlc2NyaXB0aW9uLFxuICBEaWFsb2dPdmVybGF5LFxuICBEaWFsb2dQb3J0YWwsXG4gIERpYWxvZ1RpdGxlLFxuICBEaWFsb2dUcmlnZ2VyLFxuICBEaWFsb2dPdmVybGF5IGFzIE92ZXJsYXksXG4gIERpYWxvZ1BvcnRhbCBhcyBQb3J0YWwsXG4gIERpYWxvZyBhcyBSb290LFxuICBEaWFsb2dUaXRsZSBhcyBUaXRsZSxcbiAgRGlhbG9nVHJpZ2dlciBhcyBUcmlnZ2VyLFxuICBXYXJuaW5nUHJvdmlkZXIsXG4gIGNyZWF0ZURpYWxvZ1Njb3BlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxJQUFJQSxlQUFZLE9BQU87QUFDdkIsSUFBSUMsYUFBVSxRQUFRLFVBQVVELGFBQVUsUUFBUSxRQUFRO0NBQUU7Q0FBTyxjQUFjO0FBQUssQ0FBQztBQUd2RixJQUFJLFlBQVksQ0FBQyxFQUFFLE9BQU8sV0FBVyxlQUFlLE9BQU8sWUFBWSxPQUFPLFNBQVM7QUFDdkYsU0FBUyxxQkFBcUIsc0JBQXNCLGlCQUFpQixFQUFFLDJCQUEyQixTQUFTLENBQUMsR0FBRztDQUM3RyxPQUF1QiwwQkFBTyxTQUFTLFlBQVksT0FBTztFQUN4RCx1QkFBdUIsS0FBSztFQUM1QixJQUFJLDZCQUE2QixTQUFTLENBQUMsU0FBUyxDQUFDLE1BQU0sa0JBQ3pELE9BQU8sa0JBQWtCLEtBQUs7Q0FFbEMsR0FBRyxhQUFhO0FBQ2xCO0FBQ0FDLFVBQU8sc0JBQXNCLHNCQUFzQjtBQUNuRCxTQUFTLGVBQWUsU0FBUztDQUMvQixJQUFJLENBQUMsV0FDSCxNQUFNLElBQUksTUFBTSx5Q0FBeUM7Q0FFM0QsT0FBTyxTQUFTLGVBQWUsZUFBZTtBQUNoRDtBQUNBQSxVQUFPLGdCQUFnQixnQkFBZ0I7QUFDdkMsU0FBUyxpQkFBaUIsU0FBUztDQUNqQyxJQUFJLENBQUMsV0FDSCxNQUFNLElBQUksTUFBTSwyQ0FBMkM7Q0FFN0QsT0FBTyxTQUFTLGlCQUFpQjtBQUNuQztBQUNBQSxVQUFPLGtCQUFrQixrQkFBa0I7QUFDM0MsU0FBUyxpQkFBaUIsTUFBTSxtQkFBbUIsT0FBTztDQUN4RCxNQUFNLEVBQUUsa0JBQWtCLGlCQUFpQixJQUFJO0NBQy9DLElBQUksQ0FBQyxlQUFlLFVBQ2xCLE9BQU87Q0FFVCxJQUFJLFFBQVEsYUFBYSxLQUFLLGNBQWMsaUJBQzFDLE9BQU8saUJBQWlCLGNBQWMsZ0JBQWdCLE1BQU0sZ0JBQWdCO0NBRTlFLElBQUksa0JBQWtCO0VBQ3BCLE1BQU0sS0FBSyxjQUFjLGFBQWEsdUJBQXVCO0VBQzdELElBQUksSUFBSTtHQUNOLE1BQU0sVUFBVSxpQkFBaUIsYUFBYSxDQUFDLENBQUMsZUFBZSxFQUFFO0dBQ2pFLElBQUksU0FDRixPQUFPO0VBRVg7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBQSxVQUFPLGtCQUFrQixrQkFBa0I7QUFDM0MsU0FBUyxRQUFRLFNBQVM7Q0FDeEIsT0FBTyxRQUFRLFlBQVk7QUFDN0I7QUFDQUEsVUFBTyxTQUFTLFNBQVM7Ozs7QUNuRHpCLElBQUlDLGVBQVksT0FBTztBQUN2QixJQUFJQyxhQUFVLFFBQVEsVUFBVUQsYUFBVSxRQUFRLFFBQVE7Q0FBRTtDQUFPLGNBQWM7QUFBSyxDQUFDOztBQU12RixTQUFTLGVBQWUsbUJBQW1CLGdCQUFnQjtDQUN6RCxNQUFNLFVBQUEsYUFBZ0IsY0FBYyxjQUFjO0NBQ2xELFFBQVEsY0FBYyxvQkFBb0I7Q0FDMUMsTUFBTSxXQUEyQiwyQkFBUSxVQUFVO0VBQ2pELE1BQU0sRUFBRSxVQUFVLEdBQUcsWUFBWTtFQUNqQyxNQUFNLFFBQUEsYUFBYyxjQUFjLFNBQVMsT0FBTyxPQUFPLE9BQU8sQ0FBQztFQUNqRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxRQUFRLFVBQVU7R0FBRTtHQUFPO0VBQVMsQ0FBQztDQUNsRSxHQUFHLFVBQVU7Q0FDYixTQUFTLGNBQWMsb0JBQW9CO0NBQzNDLFNBQVMsWUFBWSxjQUFjLFVBQVUsQ0FBQyxHQUFHO0VBQy9DLE1BQU0sRUFBRSxXQUFXLFVBQVU7RUFDN0IsTUFBTSxVQUFBLGFBQWdCLFdBQVcsT0FBTztFQUN4QyxJQUFJLFNBQVMsT0FBTztFQUNwQixJQUFJLG1CQUFtQixLQUFLLEdBQUcsT0FBTztFQUN0QyxJQUFJLFVBQVUsT0FBTyxLQUFLO0VBQzFCLE1BQU0sSUFBSSxNQUFNLEtBQUssYUFBYSwyQkFBMkIsa0JBQWtCLEdBQUc7Q0FDcEY7Q0FDQSxVQUFPLGFBQWEsWUFBWTtDQUNoQyxPQUFPLENBQUMsVUFBVSxXQUFXO0FBQy9CO0FBQ0FDLFVBQU8sZ0JBQWdCLGVBQWU7O0FBRXRDLFNBQVMsbUJBQW1CLFdBQVcseUJBQXlCLENBQUMsR0FBRztDQUNsRSxJQUFJLGtCQUFrQixDQUFDO0NBQ3ZCLFNBQVMsZUFBZSxtQkFBbUIsZ0JBQWdCO0VBQ3pELE1BQU0sY0FBQSxhQUFvQixjQUFjLGNBQWM7RUFDdEQsWUFBWSxjQUFjLG9CQUFvQjtFQUM5QyxNQUFNLFFBQVEsZ0JBQWdCO0VBQzlCLGtCQUFrQixDQUFDLEdBQUcsaUJBQWlCLGNBQWM7RUFDckQsTUFBTSxXQUEyQiwyQkFBUSxVQUFVO0dBQ2pELE1BQU0sRUFBRSxPQUFPLFVBQVUsR0FBRyxZQUFZO0dBQ3hDLE1BQU0sVUFBVSxRQUFRLFVBQVUsR0FBRyxVQUFVO0dBQy9DLE1BQU0sUUFBQSxhQUFjLGNBQWMsU0FBUyxPQUFPLE9BQU8sT0FBTyxDQUFDO0dBQ2pFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFFBQVEsVUFBVTtJQUFFO0lBQU87R0FBUyxDQUFDO0VBQ2xFLEdBQUcsVUFBVTtFQUNiLFNBQVMsY0FBYyxvQkFBb0I7RUFDM0MsU0FBUyxZQUFZLGNBQWMsT0FBTyxVQUFVLENBQUMsR0FBRztHQUN0RCxNQUFNLEVBQUUsV0FBVyxVQUFVO0dBQzdCLE1BQU0sVUFBVSxRQUFRLFVBQVUsR0FBRyxVQUFVO0dBQy9DLE1BQU0sVUFBQSxhQUFnQixXQUFXLE9BQU87R0FDeEMsSUFBSSxTQUFTLE9BQU87R0FDcEIsSUFBSSxtQkFBbUIsS0FBSyxHQUFHLE9BQU87R0FDdEMsSUFBSSxVQUFVLE9BQU8sS0FBSztHQUMxQixNQUFNLElBQUksTUFBTSxLQUFLLGFBQWEsMkJBQTJCLGtCQUFrQixHQUFHO0VBQ3BGO0VBQ0EsVUFBTyxhQUFhLFlBQVk7RUFDaEMsT0FBTyxDQUFDLFVBQVUsV0FBVztDQUMvQjtDQUNBLFVBQU8sZ0JBQWdCLGVBQWU7Q0FDdEMsTUFBTSxjQUE4QixnQ0FBYTtFQUMvQyxNQUFNLGdCQUFnQixnQkFBZ0IsS0FBSyxtQkFBbUI7R0FDNUQsT0FBQSxhQUFhLGNBQWMsY0FBYztFQUMzQyxDQUFDO0VBQ0QsT0FBdUIsMEJBQU8sU0FBUyxTQUFTLE9BQU87R0FDckQsTUFBTSxXQUFXLFFBQVEsY0FBYztHQUN2QyxPQUFBLGFBQWEsZUFDSixHQUFHLFVBQVUsY0FBYztJQUFFLEdBQUc7S0FBUSxZQUFZO0dBQVMsRUFBRSxJQUN0RSxDQUFDLE9BQU8sUUFBUSxDQUNsQjtFQUNGLEdBQUcsVUFBVTtDQUNmLEdBQUcsYUFBYTtDQUNoQixZQUFZLFlBQVk7Q0FDeEIsT0FBTyxDQUFDLGdCQUFnQixxQkFBcUIsYUFBYSxHQUFHLHNCQUFzQixDQUFDO0FBQ3RGO0FBQ0FBLFVBQU8sb0JBQW9CLG9CQUFvQjtBQUMvQyxTQUFTLHFCQUFxQixHQUFHLFFBQVE7Q0FDdkMsTUFBTSxZQUFZLE9BQU87Q0FDekIsSUFBSSxPQUFPLFdBQVcsR0FBRyxPQUFPO0NBQ2hDLE1BQU0sY0FBOEIsZ0NBQWE7RUFDL0MsTUFBTSxhQUFhLE9BQU8sS0FBSyxrQkFBa0I7R0FDL0MsVUFBVSxhQUFhO0dBQ3ZCLFdBQVcsYUFBYTtFQUMxQixFQUFFO0VBQ0YsT0FBdUIsMEJBQU8sU0FBUyxrQkFBa0IsZ0JBQWdCO0dBQ3ZFLE1BQU0sYUFBYSxXQUFXLFFBQVEsYUFBYSxFQUFFLFVBQVUsZ0JBQWdCO0lBRTdFLE1BQU0sZUFEYSxTQUFTLGNBQ0UsQ0FBQyxDQUFDLFVBQVU7SUFDMUMsT0FBTztLQUFFLEdBQUc7S0FBYSxHQUFHO0lBQWE7R0FDM0MsR0FBRyxDQUFDLENBQUM7R0FDTCxPQUFBLGFBQWEsZUFBZSxHQUFHLFVBQVUsVUFBVSxjQUFjLFdBQVcsSUFBSSxDQUFDLFVBQVUsQ0FBQztFQUM5RixHQUFHLG1CQUFtQjtDQUN4QixHQUFHLGFBQWE7Q0FDaEIsWUFBWSxZQUFZLFVBQVU7Q0FDbEMsT0FBTztBQUNUO0FBQ0FBLFVBQU8sc0JBQXNCLHNCQUFzQjs7O0FDMUZuRCxJQUFJLG1CQUFtQixZQUFZLFdBQUEsYUFBaUIsd0JBQXdCLENBQzVFOzs7QUNIQSxJQUFJQyxjQUFZLE9BQU87QUFDdkIsSUFBSUMsWUFBVSxRQUFRLFVBQVVELFlBQVUsUUFBUSxRQUFRO0NBQUU7Q0FBTyxjQUFjO0FBQUssQ0FBQztBQUt2RixJQUFJLGFBQWFFLGFBQU0sVUFBVSxLQUFLLENBQUMsQ0FBQyxTQUFTLGFBQWEsS0FBSztBQUNuRSxJQUFJQyxVQUFRO0FBQ1osU0FBUyxNQUFNLGlCQUFpQjtDQUM5QixNQUFNLENBQUMsSUFBSSxTQUFBLGFBQWUsU0FBUyxXQUFXLENBQUM7Q0FDL0MsdUJBQXNCO0VBQ3BCLElBQUksQ0FBQyxpQkFBaUIsT0FBTyxZQUFZLFdBQVcsT0FBTyxTQUFPLENBQUM7Q0FDckUsR0FBRyxDQUFDLGVBQWUsQ0FBQztDQUNwQixPQUFPLG9CQUFvQixLQUFLLFNBQVMsT0FBTztBQUNsRDtBQUNBRixTQUFPLE9BQU8sT0FBTzs7O0FDZnJCLElBQUlHLGNBQVksT0FBTztBQUN2QixJQUFJQyxZQUFVLFFBQVEsVUFBVUQsWUFBVSxRQUFRLFFBQVE7Q0FBRTtDQUFPLGNBQWM7QUFBSyxDQUFDO0FBS3ZGLElBQUksc0JBQXNCRSxhQUFNLG1CQUFtQixLQUFLLENBQUMsQ0FBQyxTQUFTO0FBQ25FLElBQUlDLDRCQUEwQkQsYUFBTSx1QkFBdUIsS0FBSyxDQUFDLENBQUMsU0FBUztBQUMzRSxTQUFTLGVBQWUsVUFBVTtDQUNoQyxJQUFJLE9BQU8sd0JBQXdCLFlBQ2pDLE9BQU8sb0JBQW9CLFFBQVE7Q0FFckMsTUFBTSxNQUFBLGFBQVksYUFBYTtFQUM3QixNQUFNLElBQUksTUFBTSwrQ0FBK0M7Q0FDakUsQ0FBQztDQUNELElBQUksT0FBT0MsOEJBQTRCLFlBQ3JDLGdDQUE4QjtFQUM1QixJQUFJLFVBQVU7Q0FDaEIsQ0FBQztNQUVELHVCQUFzQjtFQUNwQixJQUFJLFVBQVU7Q0FDaEIsQ0FBQztDQUVILE9BQUEsYUFBYSxnQkFBZ0IsR0FBRyxTQUFTLElBQUksVUFBVSxHQUFHLElBQUksSUFBSSxDQUFDLENBQUM7QUFDdEU7QUFDQUYsU0FBTyxnQkFBZ0IsZ0JBQWdCOzs7QUMxQnZDLElBQUlHLGNBQVksT0FBTztBQUN2QixJQUFJQyxZQUFVLFFBQVEsVUFBVUQsWUFBVSxRQUFRLFFBQVE7Q0FBRTtDQUFPLGNBQWM7QUFBSyxDQUFDO0FBTXZGLElBQUkscUJBQXFCRSxhQUFNLHVCQUF1QixLQUFLLENBQUMsQ0FBQyxTQUFTLE1BQU1DO0FBQzVFLFNBQVMscUJBQXFCLEVBQzVCLE1BQ0EsYUFDQSxXQUEyQiwrQkFBYSxDQUN4QyxHQUFHLFVBQVUsR0FDYixVQUNDO0NBQ0QsTUFBTSxDQUFDLGtCQUFrQixxQkFBcUIsZUFBZSxxQkFBcUI7RUFDaEY7RUFDQTtDQUNGLENBQUM7Q0FDRCxNQUFNLGVBQWUsU0FBUyxLQUFLO0NBQ25DLE1BQU0sUUFBUSxlQUFlLE9BQU87Q0FDaEI7RUFDbEIsTUFBTSxrQkFBQSxhQUF3QixPQUFPLFNBQVMsS0FBSyxDQUFDO0VBQ3BELGFBQU0sZ0JBQWdCO0dBQ3BCLE1BQU0sZ0JBQWdCLGdCQUFnQjtHQUN0QyxJQUFJLGtCQUFrQixjQUdwQixRQUFRLEtBQ04sR0FBRyxPQUFPLG9CQUhDLGdCQUFnQixlQUFlLGVBR1AsTUFGMUIsZUFBZSxlQUFlLGVBRUssMktBQzlDO0dBRUYsZ0JBQWdCLFVBQVU7RUFDNUIsR0FBRyxDQUFDLGNBQWMsTUFBTSxDQUFDO0NBQzNCO0NBY0EsT0FBTyxDQUFDLE9BQUEsYUFiZSxhQUNwQixjQUFjO0VBQ2IsSUFBSSxjQUFjO0dBQ2hCLE1BQU0sU0FBUyxXQUFXLFNBQVMsSUFBSSxVQUFVLElBQUksSUFBSTtHQUN6RCxJQUFJLFdBQVcsTUFDYixZQUFZLFVBQVUsTUFBTTtFQUVoQyxPQUNFLG9CQUFvQixTQUFTO0NBRWpDLEdBQ0E7RUFBQztFQUFjO0VBQU07RUFBcUI7Q0FBVyxDQUVqQyxDQUFDO0FBQ3pCO0FBQ0FGLFNBQU8sc0JBQXNCLHNCQUFzQjtBQUNuRCxTQUFTLHFCQUFxQixFQUM1QixhQUNBLFlBQ0M7Q0FDRCxNQUFNLENBQUMsT0FBTyxZQUFBLGFBQWtCLFNBQVMsV0FBVztDQUNwRCxNQUFNLGVBQUEsYUFBcUIsT0FBTyxLQUFLO0NBQ3ZDLE1BQU0sY0FBQSxhQUFvQixPQUFPLFFBQVE7Q0FDekMseUJBQXlCO0VBQ3ZCLFlBQVksVUFBVTtDQUN4QixHQUFHLENBQUMsUUFBUSxDQUFDO0NBQ2IsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxhQUFhLFlBQVksT0FBTztHQUNsQyxZQUFZLFVBQVUsS0FBSztHQUMzQixhQUFhLFVBQVU7RUFDekI7Q0FDRixHQUFHLENBQUMsT0FBTyxZQUFZLENBQUM7Q0FDeEIsT0FBTztFQUFDO0VBQU87RUFBVTtDQUFXO0FBQ3RDO0FBQ0FBLFNBQU8sc0JBQXNCLHNCQUFzQjtBQUNuRCxTQUFTLFdBQVcsT0FBTztDQUN6QixPQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBQSxTQUFPLFlBQVksWUFBWTtBQU0vQixJQUFJLGFBQWEsT0FBTyxrQkFBa0I7QUFDMUMsU0FBUyw0QkFBNEIsU0FBUyxVQUFVLFlBQVksTUFBTTtDQUN4RSxNQUFNLEVBQUUsTUFBTSxpQkFBaUIsYUFBYSxVQUFVLGNBQWMsV0FBVztDQUMvRSxNQUFNLGVBQWUsb0JBQW9CLEtBQUs7Q0FDOUMsTUFBTSxXQUFXLGVBQWUsWUFBWTtDQUN2QjtFQUNuQixNQUFNLGtCQUFBLGFBQXlCLE9BQU8sb0JBQW9CLEtBQUssQ0FBQztFQUNoRSxhQUFPLGdCQUFnQjtHQUNyQixNQUFNLGdCQUFnQixnQkFBZ0I7R0FDdEMsSUFBSSxrQkFBa0IsY0FHcEIsUUFBUSxLQUNOLEdBQUcsT0FBTyxvQkFIQyxnQkFBZ0IsZUFBZSxlQUdQLE1BRjFCLGVBQWUsZUFBZSxlQUVLLDJLQUM5QztHQUVGLGdCQUFnQixVQUFVO0VBQzVCLEdBQUcsQ0FBQyxjQUFjLE1BQU0sQ0FBQztDQUMzQjtDQUNBLE1BQU0sT0FBTyxDQUFDO0VBQUUsR0FBRztFQUFZLE9BQU87Q0FBWSxDQUFDO0NBQ25ELElBQUksTUFDRixLQUFLLEtBQUssSUFBSTtDQUVoQixNQUFNLENBQUMsZUFBZSxZQUFBLGFBQW1CLFlBQ3RDLFFBQVEsV0FBVztFQUNsQixJQUFJLE9BQU8sU0FBUyxZQUNsQixPQUFPO0dBQUUsR0FBRztHQUFRLE9BQU8sT0FBTztFQUFNO0VBRTFDLE1BQU0sT0FBTyxRQUFRLFFBQVEsTUFBTTtFQUNuQyxJQUFJLGdCQUFnQixDQUFDLE9BQU8sR0FBRyxLQUFLLE9BQU8sT0FBTyxLQUFLLEdBQ3JELFNBQVMsS0FBSyxLQUFLO0VBRXJCLE9BQU87Q0FDVCxHQUNBLEdBQUcsSUFDTDtDQUNBLE1BQU0sb0JBQW9CLGNBQWM7Q0FDeEMsTUFBTSxlQUFBLGFBQXNCLE9BQU8saUJBQWlCO0NBQ3BELGFBQU8sZ0JBQWdCO0VBQ3JCLElBQUksYUFBYSxZQUFZLG1CQUFtQjtHQUM5QyxhQUFhLFVBQVU7R0FDdkIsSUFBSSxDQUFDLGNBQ0gsU0FBUyxpQkFBaUI7RUFFOUI7Q0FDRixHQUFHO0VBQUM7RUFBbUI7RUFBYztDQUFZLENBQUM7Q0FDbEQsTUFBTSxRQUFBLGFBQWUsY0FBYztFQUVqQyxJQURzQixvQkFBb0IsS0FBSyxHQUU3QyxPQUFPO0dBQUUsR0FBRztHQUFlLE9BQU87RUFBZ0I7RUFFcEQsT0FBTztDQUNULEdBQUcsQ0FBQyxlQUFlLGVBQWUsQ0FBQztDQUNuQyxhQUFPLGdCQUFnQjtFQUNyQixJQUFJLGdCQUFnQixDQUFDLE9BQU8sR0FBRyxpQkFBaUIsY0FBYyxLQUFLLEdBQ2pFLFNBQVM7R0FBRSxNQUFNO0dBQVksT0FBTztFQUFnQixDQUFDO0NBRXpELEdBQUc7RUFBQztFQUFpQixjQUFjO0VBQU87Q0FBWSxDQUFDO0NBQ3ZELE9BQU8sQ0FBQyxPQUFPLFFBQVE7QUFDekI7QUFDQUEsU0FBTyw2QkFBNkIsNkJBQTZCOzs7QUMzSWpFLElBQUlHLGNBQVksT0FBTztBQUN2QixJQUFJQyxZQUFVLFFBQVEsVUFBVUQsWUFBVSxRQUFRLFFBQVE7Q0FBRTtDQUFPLGNBQWM7QUFBSyxDQUFDO0FBS3ZGLElBQUksMEJBQTBCRSxhQUFNLHVCQUF1QixLQUFLLENBQUMsQ0FBQyxTQUFTO0FBQzNFLFNBQVNDLGlCQUFlLFVBQVU7Q0FDaEMsTUFBTSxjQUFBLGFBQW9CLE9BQU8sUUFBUTtDQUN6QyxJQUFJLE9BQU8sNEJBQTRCLFlBQ3JDLDhCQUE4QjtFQUM1QixZQUFZLFVBQVU7Q0FDeEIsQ0FBQztNQUVELHVCQUFzQjtFQUNwQixZQUFZLFVBQVU7Q0FDeEIsQ0FBQztDQUVILE9BQUEsYUFBYSxnQkFBZ0IsR0FBRyxTQUFTLFlBQVksVUFBVSxHQUFHLElBQUksSUFBSSxDQUFDLENBQUM7QUFDOUU7QUFDQUYsU0FBT0Usa0JBQWdCLGdCQUFnQjs7O0FDbkJ2QyxJQUFJQyxjQUFZLE9BQU87QUFDdkIsSUFBSUMsWUFBVSxRQUFRLFVBQVVELFlBQVUsUUFBUSxRQUFRO0NBQUU7Q0FBTyxjQUFjO0FBQUssQ0FBQztBQVN2RixJQUFJLGlCQUFpQjtBQUNyQixJQUFJLHVCQUF1QjtBQUMzQixJQUFJLGdCQUFnQjtBQUNwQixJQUFJO0FBQ0osSUFBSSwwQkFBQSxhQUFnQyxjQUFjO0NBQ2hELHdCQUF3QixJQUFJLElBQUk7Q0FDaEMsd0RBQXdELElBQUksSUFBSTtDQUNoRSwwQkFBMEIsSUFBSSxJQUFJO0NBTWxDLHFDQUFxQyxJQUFJLElBQUk7QUFDL0MsQ0FBQztBQUNELElBQUksbUJBQW1DLDZCQUFNLFdBRTNCLHlCQUFPLFNBQVMsa0JBQWtCLE9BQU8sY0FBYztDQUNyRSxNQUFNLEVBQ0osOEJBQThCLE9BQzlCLDBCQUEwQixPQUMxQixpQkFDQSxzQkFDQSxnQkFDQSxtQkFDQSxXQUNBLEdBQUcsZUFDRDtDQUNKLE1BQU0sVUFBQSxhQUFnQixXQUFXLHVCQUF1QjtDQUN4RCxNQUFNLENBQUMsTUFBTSxXQUFBLGFBQWlCLFNBQVMsSUFBSTtDQUMzQyxNQUFNLGdCQUFnQixNQUFNLGlCQUFpQixZQUFZO0NBQ3pELE1BQU0sR0FBRyxTQUFBLGFBQWUsU0FBUyxDQUFDLENBQUM7Q0FDbkMsTUFBTSxlQUFlLGdCQUFnQixjQUFjLE9BQU87Q0FDMUQsTUFBTSxTQUFTLE1BQU0sS0FBSyxRQUFRLE1BQU07Q0FDeEMsTUFBTSxDQUFDLGdEQUFnRCxDQUNyRCxHQUFHLFFBQVEsc0NBQ2IsQ0FBQyxDQUFDLE1BQU0sRUFBRTtDQUNWLE1BQU0sb0RBQW9ELCtDQUErQyxPQUFPLFFBQVEsNENBQTRDLElBQUk7Q0FDeEssTUFBTSxRQUFRLE9BQU8sT0FBTyxRQUFRLElBQUksSUFBSTtDQUM1QyxNQUFNLDhCQUE4QixRQUFRLHVDQUF1QyxPQUFPO0NBQzFGLE1BQU0seUJBQXlCLFNBQVM7Q0FDeEMsTUFBTSxrQ0FBQSxhQUF3QyxPQUFPLEtBQUs7Q0FDMUQsTUFBTSxxQkFBcUIsdUJBQ3hCLFVBQVU7RUFDVCx1QkFBdUIsS0FBSztFQUM1QixvQkFBb0IsS0FBSztFQUN6QixJQUFJLENBQUMsTUFBTSxrQkFBa0IsWUFBWTtDQUMzQyxHQUNBO0VBQ0U7RUFDQTtFQUNBO0VBQ0EscUJBQXFCLFFBQVE7RUFDN0IsZ0NBQUEsYUFBc0MsYUFDbkMsV0FBVztHQUNWLElBQUksRUFBRSxrQkFBa0IsT0FDdEIsT0FBTztHQUVULE1BQU0sd0JBQXdCLENBQUMsR0FBRyxRQUFRLFFBQVEsQ0FBQyxDQUFDLE1BQ2pELFdBQVcsT0FBTyxTQUFTLE1BQU0sQ0FDcEM7R0FDQSxPQUFPLDBCQUEwQixDQUFDO0VBQ3BDLEdBQ0EsQ0FBQyxRQUFRLFVBQVUsc0JBQXNCLENBQzNDO0NBQ0YsQ0FDRjtDQUNBLE1BQU0sZUFBZSxpQkFBaUIsVUFBVTtFQUM5QyxJQUFJLDJCQUEyQixnQ0FBZ0MsU0FDN0Q7RUFFRixNQUFNLFNBQVMsTUFBTTtFQUVyQixJQUR3QixDQUFDLEdBQUcsUUFBUSxRQUFRLENBQUMsQ0FBQyxNQUFNLFdBQVcsT0FBTyxTQUFTLE1BQU0sQ0FDbkUsR0FBRztFQUNyQixpQkFBaUIsS0FBSztFQUN0QixvQkFBb0IsS0FBSztFQUN6QixJQUFJLENBQUMsTUFBTSxrQkFBa0IsWUFBWTtDQUMzQyxHQUFHLGFBQWE7Q0FDaEIsTUFBTSxpQkFBaUIsT0FBTyxVQUFVLE9BQU8sU0FBUyxJQUFJO0NBQzVELE1BQU0sZ0JBQWdCRSxrQkFBZ0IsVUFBVTtFQUM5QyxJQUFJLE1BQU0sUUFBUSxVQUNoQjtFQUVGLGtCQUFrQixLQUFLO0VBQ3ZCLElBQUksQ0FBQyxNQUFNLG9CQUFvQixXQUFXO0dBQ3hDLE1BQU0sZUFBZTtHQUNyQixVQUFVO0VBQ1o7Q0FDRixDQUFDO0NBQ0QsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLGdCQUNIO0VBRUYsY0FBYyxpQkFBaUIsV0FBVyxlQUFlLEVBQUUsU0FBUyxLQUFLLENBQUM7RUFDMUUsYUFBYSxjQUFjLG9CQUFvQixXQUFXLGVBQWUsRUFBRSxTQUFTLEtBQUssQ0FBQztDQUM1RixHQUFHO0VBQUM7RUFBZTtFQUFnQjtDQUFhLENBQUM7Q0FDakQsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLE1BQU07RUFDWCxJQUFJLDZCQUE2QjtHQUMvQixJQUFJLFFBQVEsdUNBQXVDLFNBQVMsR0FBRztJQUM3RCw0QkFBNEIsY0FBYyxLQUFLLE1BQU07SUFDckQsY0FBYyxLQUFLLE1BQU0sZ0JBQWdCO0dBQzNDO0dBQ0EsUUFBUSx1Q0FBdUMsSUFBSSxJQUFJO0VBQ3pEO0VBQ0EsUUFBUSxPQUFPLElBQUksSUFBSTtFQUN2QixlQUFlO0VBQ2YsYUFBYTtHQUNYLElBQUksNkJBQTZCO0lBQy9CLFFBQVEsdUNBQXVDLE9BQU8sSUFBSTtJQUMxRCxJQUFJLFFBQVEsdUNBQXVDLFNBQVMsR0FDMUQsY0FBYyxLQUFLLE1BQU0sZ0JBQWdCO0dBRTdDO0VBQ0Y7Q0FDRixHQUFHO0VBQUM7RUFBTTtFQUFlO0VBQTZCO0NBQU8sQ0FBQztDQUM5RCxhQUFNLGdCQUFnQjtFQUNwQixhQUFhO0dBQ1gsSUFBSSxDQUFDLE1BQU07R0FDWCxRQUFRLE9BQU8sT0FBTyxJQUFJO0dBQzFCLFFBQVEsdUNBQXVDLE9BQU8sSUFBSTtHQUMxRCxlQUFlO0VBQ2pCO0NBQ0YsR0FBRyxDQUFDLE1BQU0sT0FBTyxDQUFDO0NBQ2xCLGFBQU0sZ0JBQWdCO0VBQ3BCLE1BQU0sZUFBK0IsK0JBQWEsTUFBTSxDQUFDLENBQUMsR0FBRyxjQUFjO0VBQzNFLFNBQVMsaUJBQWlCLGdCQUFnQixZQUFZO0VBQ3RELGFBQWEsU0FBUyxvQkFBb0IsZ0JBQWdCLFlBQVk7Q0FDeEUsR0FBRyxDQUFDLENBQUM7Q0FDTCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsVUFBVSxLQUNWO0VBQ0UsR0FBRztFQUNILEtBQUs7RUFDTCxPQUFPO0dBQ0wsZUFBZSw4QkFBOEIseUJBQXlCLFNBQVMsU0FBUyxLQUFLO0dBQzdGLEdBQUcsTUFBTTtFQUNYO0VBQ0EsZ0JBQWdCLHFCQUFxQixNQUFNLGdCQUFnQixhQUFhLGNBQWM7RUFDdEYsZUFBZSxxQkFBcUIsTUFBTSxlQUFlLGFBQWEsYUFBYTtFQUNuRixzQkFBc0IscUJBQ3BCLE1BQU0sc0JBQ04sbUJBQW1CLG9CQUNyQjtDQUNGLENBQ0Y7QUFDRixHQUFHLGtCQUFrQixDQUN2QjtBQWdCQSxTQUFTLDZCQUE2QjtDQUNwQyxNQUFNLFVBQUEsYUFBZ0IsV0FBVyx1QkFBdUI7Q0FDeEQsTUFBTSxDQUFDLE1BQU0sV0FBQSxhQUFpQixTQUFTLElBQUk7Q0FDM0MsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLE1BQ0g7RUFFRixRQUFRLG9CQUFvQixJQUFJLElBQUk7RUFDcEMsYUFBYTtHQUNYLFFBQVEsb0JBQW9CLE9BQU8sSUFBSTtFQUN6QztDQUNGLEdBQUcsQ0FBQyxNQUFNLFFBQVEsbUJBQW1CLENBQUM7Q0FDdEMsT0FBTztBQUNUO0FBQ0FELFNBQU8sNEJBQTRCLDRCQUE0QjtBQUMvRCxJQUFJLFVBQTBCLCtCQUFhLE1BQU0sU0FBUztBQUMxRCxTQUFTLHNCQUFzQixzQkFBc0IsTUFBTTtDQUN6RCxNQUFNLEVBQ0osZ0JBQWdCLFlBQVksVUFDNUIsMEJBQTBCLE9BQzFCLGlDQUNBLHFCQUNBLGlDQUFpQyxZQUMvQjtDQUNKLE1BQU0sMkJBQTJCQyxpQkFBZSxvQkFBb0I7Q0FDcEUsTUFBTSw4QkFBQSxhQUFvQyxPQUFPLEtBQUs7Q0FDdEQsTUFBTSwwQkFBQSxhQUFnQyxPQUFPLEtBQUs7Q0FDbEQsTUFBTSx5Q0FBQSxhQUErQyx1QkFBdUIsSUFBSSxJQUFJLENBQUM7Q0FDckYsTUFBTSxpQkFBQSxhQUF1QixhQUFhLENBQzFDLENBQUM7Q0FDRCxhQUFNLGdCQUFnQjtFQUNwQixTQUFTLDBCQUEwQjtHQUNqQyx3QkFBd0IsVUFBVTtHQUNsQyxnQ0FBZ0MsVUFBVTtHQUMxQyx1Q0FBdUMsUUFBUSxNQUFNO0VBQ3ZEO0VBQ0EsU0FBTyx5QkFBeUIseUJBQXlCO0VBQ3pELFNBQVMsa0NBQWtDO0dBQ3pDLE9BQU8sTUFBTSxLQUFLLHVDQUF1QyxRQUFRLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPO0VBQ3pGO0VBQ0EsU0FBTyxpQ0FBaUMsaUNBQWlDO0VBQ3pFLFNBQVMseUJBQXlCLE9BQU87R0FDdkMsSUFBSSxDQUFDLHdCQUF3QixTQUMzQjtHQUVGLE1BQU0sU0FBUyxNQUFNO0dBRXJCLElBQUksRUFEeUIsa0JBQWtCLFFBQVEsQ0FBQyxHQUFHLG1CQUFtQixDQUFDLENBQUMsTUFBTSxZQUFZLFFBQVEsU0FBUyxNQUFNLENBQUMsSUFFeEgsdUNBQXVDLFFBQVEsSUFBSSxNQUFNLE1BQU0sSUFBSTtHQUVyRSxJQUFJLE1BQU0sU0FBUyxTQUNqQixPQUFPLGlCQUFpQjtJQUN0QixJQUFJLHdCQUF3QixTQUMxQixlQUFlLFFBQVE7R0FFM0IsR0FBRyxDQUFDO0VBRVI7RUFDQSxTQUFPLDBCQUEwQiwwQkFBMEI7RUFDM0QsU0FBUyx3QkFBd0IsT0FBTztHQUN0QyxJQUFJLHdCQUF3QixTQUMxQix1Q0FBdUMsUUFBUSxJQUFJLE1BQU0sTUFBTSxLQUFLO0VBRXhFO0VBQ0EsU0FBTyx5QkFBeUIseUJBQXlCO0VBQ3pELE1BQU0sb0JBQW9DLDBCQUFRLFVBQVU7R0FDMUQsSUFBSSxNQUFNLFVBQVUsQ0FBQyw0QkFBNEIsU0FBUztJQUN4RCxJQUFJLDRDQUE0QyxXQUFXO0tBQ3pELGNBQWMsb0JBQW9CLFNBQVMsZUFBZSxPQUFPO0tBQ2pFLE1BQU0sbUNBQW1DLGdDQUFnQztLQUN6RSx3QkFBd0I7S0FDeEIsSUFBSSxDQUFDLGtDQUNILDZCQUNFLHNCQUNBLDBCQUNBLGFBQ0EsRUFBRSxVQUFVLEtBQUssQ0FDbkI7SUFFSjtJQUVBLFNBQU8sMkNBQTJDLDBDQUEwQztJQUM1RixJQUFJLENBQUMsK0JBQStCLE1BQU0sTUFBTSxHQUFHO0tBQ2pELGNBQWMsb0JBQW9CLFNBQVMsZUFBZSxPQUFPO0tBQ2pFLHdCQUF3QjtLQUN4Qiw0QkFBNEIsVUFBVTtLQUN0QztJQUNGO0lBQ0EsTUFBTSxjQUFjLEVBQUUsZUFBZSxNQUFNO0lBQzNDLHdCQUF3QixVQUFVO0lBQ2xDLGdDQUFnQyxVQUFVLDJCQUEyQixNQUFNLFdBQVc7SUFDdEYsdUNBQXVDLFFBQVEsTUFBTTtJQUNyRCxJQUFJLENBQUMsMkJBQTJCLE1BQU0sV0FBVyxHQUMvQywwQ0FBMEM7U0FDckM7S0FDTCxjQUFjLG9CQUFvQixTQUFTLGVBQWUsT0FBTztLQUNqRSxlQUFlLFVBQVU7S0FDekIsY0FBYyxpQkFBaUIsU0FBUyxlQUFlLFNBQVMsRUFBRSxNQUFNLEtBQUssQ0FBQztJQUNoRjtHQUNGLE9BQU87SUFDTCxjQUFjLG9CQUFvQixTQUFTLGVBQWUsT0FBTztJQUNqRSx3QkFBd0I7R0FDMUI7R0FDQSw0QkFBNEIsVUFBVTtFQUN4QyxHQUFHLG1CQUFtQjtFQUN0QixNQUFNLDJCQUEyQjtHQUMvQjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLEtBQUssTUFBTSxhQUFhLDBCQUEwQjtHQUNoRCxjQUFjLGlCQUFpQixXQUFXLDBCQUEwQixJQUFJO0dBQ3hFLGNBQWMsaUJBQWlCLFdBQVcsdUJBQXVCO0VBQ25FO0VBQ0EsTUFBTSxVQUFVLE9BQU8saUJBQWlCO0dBQ3RDLGNBQWMsaUJBQWlCLGVBQWUsaUJBQWlCO0VBQ2pFLEdBQUcsQ0FBQztFQUNKLGFBQWE7R0FDWCxPQUFPLGFBQWEsT0FBTztHQUMzQixjQUFjLG9CQUFvQixlQUFlLGlCQUFpQjtHQUNsRSxjQUFjLG9CQUFvQixTQUFTLGVBQWUsT0FBTztHQUNqRSxLQUFLLE1BQU0sYUFBYSwwQkFBMEI7SUFDaEQsY0FBYyxvQkFBb0IsV0FBVywwQkFBMEIsSUFBSTtJQUMzRSxjQUFjLG9CQUFvQixXQUFXLHVCQUF1QjtHQUN0RTtFQUNGO0NBQ0YsR0FBRztFQUNEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLENBQUM7Q0FDRCxPQUFPLEVBRUwsc0JBQXNDLCtCQUFhLDRCQUE0QixVQUFVLE1BQU0sc0JBQXNCLEVBQ3ZIO0FBQ0Y7QUFDQUQsU0FBTyx1QkFBdUIsdUJBQXVCO0FBQ3JELFNBQVMsZ0JBQWdCLGdCQUFnQixnQkFBZ0IsWUFBWSxVQUFVO0NBQzdFLE1BQU0scUJBQXFCQyxpQkFBZSxjQUFjO0NBQ3hELE1BQU0sNEJBQUEsYUFBa0MsT0FBTyxLQUFLO0NBQ3BELGFBQU0sZ0JBQWdCO0VBQ3BCLE1BQU0sY0FBOEIsMEJBQVEsVUFBVTtHQUNwRCxJQUFJLE1BQU0sVUFBVSxDQUFDLDBCQUEwQixTQUU3Qyw2QkFBNkIsZUFBZSxvQkFBb0IsRUFEMUMsZUFBZSxNQUNxQyxHQUFHLEVBQzNFLFVBQVUsTUFDWixDQUFDO0VBRUwsR0FBRyxhQUFhO0VBQ2hCLGNBQWMsaUJBQWlCLFdBQVcsV0FBVztFQUNyRCxhQUFhLGNBQWMsb0JBQW9CLFdBQVcsV0FBVztDQUN2RSxHQUFHLENBQUMsZUFBZSxrQkFBa0IsQ0FBQztDQUN0QyxPQUFPO0VBQ0wsZ0JBQWdDLCtCQUFhLDBCQUEwQixVQUFVLE1BQU0sZ0JBQWdCO0VBQ3ZHLGVBQStCLCtCQUFhLDBCQUEwQixVQUFVLE9BQU8sZUFBZTtDQUN4RztBQUNGO0FBQ0FELFNBQU8saUJBQWlCLGlCQUFpQjtBQUN6QyxTQUFTLGlCQUFpQjtDQUN4QixNQUFNLFFBQVEsSUFBSSxZQUFZLGNBQWM7Q0FDNUMsU0FBUyxjQUFjLEtBQUs7QUFDOUI7QUFDQUEsU0FBTyxnQkFBZ0IsZ0JBQWdCO0FBQ3ZDLFNBQVMsNkJBQTZCLE1BQU0sU0FBUyxRQUFRLEVBQUUsWUFBWTtDQUN6RSxNQUFNLFNBQVMsT0FBTyxjQUFjO0NBQ3BDLE1BQU0sUUFBUSxJQUFJLFlBQVksTUFBTTtFQUFFLFNBQVM7RUFBTyxZQUFZO0VBQU07Q0FBTyxDQUFDO0NBQ2hGLElBQUksU0FBUyxPQUFPLGlCQUFpQixNQUFNLFNBQVMsRUFBRSxNQUFNLEtBQUssQ0FBQztDQUNsRSxJQUFJLFVBQ0YsNEJBQTRCLFFBQVEsS0FBSztNQUV6QyxPQUFPLGNBQWMsS0FBSztBQUU5QjtBQUNBQSxTQUFPLDhCQUE4Qiw4QkFBOEI7OztBQ2hXbkUsSUFBSUUsY0FBWSxPQUFPO0FBQ3ZCLElBQUlDLFlBQVUsUUFBUSxVQUFVRCxZQUFVLFFBQVEsUUFBUTtDQUFFO0NBQU8sY0FBYztBQUFLLENBQUM7QUFRdkYsSUFBSSxxQkFBcUI7QUFDekIsSUFBSSx1QkFBdUI7QUFDM0IsSUFBSSxnQkFBZ0I7Q0FBRSxTQUFTO0NBQU8sWUFBWTtBQUFLO0FBQ3ZELElBQUksYUFBNkIsNkJBQU0sV0FDckIseUJBQU8sU0FBUyxZQUFZLE9BQU8sY0FBYztDQUMvRCxNQUFNLEVBQ0osT0FBTyxPQUNQLFVBQVUsT0FDVixVQUNBLGtCQUFrQixzQkFDbEIsb0JBQW9CLHdCQUNwQixHQUFHLGVBQ0Q7Q0FDSixNQUFNLENBQUMsV0FBVyxnQkFBQSxhQUFzQixTQUFTLElBQUk7Q0FDckQsTUFBTSxtQkFBbUJFLGlCQUFlLG9CQUFvQjtDQUM1RCxNQUFNLHFCQUFxQkEsaUJBQWUsc0JBQXNCO0NBQ2hFLE1BQU0sd0JBQUEsYUFBOEIsT0FBTyxJQUFJO0NBQy9DLE1BQU0sZUFBZSxnQkFBZ0IsY0FBYyxZQUFZO0NBQy9ELE1BQU0sY0FBQSxhQUFvQixPQUFPLFFBQVE7Q0FDekMsYUFBTSxnQkFBZ0I7RUFDcEIsWUFBWSxVQUFVO0NBQ3hCLENBQUM7Q0FDRCxNQUFNLGtCQUFBLGFBQXdCLGFBQzNCLFdBQVc7RUFDVixJQUFJLENBQUMsUUFBUSxPQUFPO0VBQ3BCLElBQUksV0FBVyxTQUFTLE1BQU0sR0FBRyxPQUFPO0VBQ3hDLE9BQU8sUUFBUSxZQUFZLFNBQVMsTUFBTSxXQUFXLE9BQU8sU0FBUyxNQUFNLENBQUMsQ0FBQztDQUMvRSxHQUNBLENBQUMsU0FBUyxDQUNaO0NBQ0EsTUFBTSxhQUFBLGFBQW1CLE9BQU87RUFDOUIsUUFBUTtFQUNSLFFBQVE7R0FDTixLQUFLLFNBQVM7RUFDaEI7RUFDQSxTQUFTO0dBQ1AsS0FBSyxTQUFTO0VBQ2hCO0NBQ0YsQ0FBQyxDQUFDLENBQUM7Q0FDSCxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLFNBQVM7R0FDWCxJQUFJLGlCQUFpQixTQUFTLE9BQU87SUFDbkMsSUFBSSxXQUFXLFVBQVUsQ0FBQyxXQUFXO0lBQ3JDLE1BQU0sU0FBUyxNQUFNO0lBQ3JCLElBQUksZ0JBQWdCLE1BQU0sR0FDeEIsc0JBQXNCLFVBQVU7U0FFaEMsTUFBTSxzQkFBc0IsU0FBUyxFQUFFLFFBQVEsS0FBSyxDQUFDO0dBRXpELEdBQUcsa0JBQWtCLFNBQVMsT0FBTztJQUNuQyxJQUFJLFdBQVcsVUFBVSxDQUFDLFdBQVc7SUFDckMsTUFBTSxnQkFBZ0IsTUFBTTtJQUM1QixJQUFJLGtCQUFrQixNQUFNO0lBQzVCLElBQUksQ0FBQyxnQkFBZ0IsYUFBYSxHQUNoQyxNQUFNLHNCQUFzQixTQUFTLEVBQUUsUUFBUSxLQUFLLENBQUM7R0FFekQsR0FBRyxtQkFBbUIsU0FBUyxXQUFXO0lBRXhDLElBRHVCLFNBQVMsa0JBQ1QsU0FBUyxNQUFNO0lBQ3RDLEtBQUssTUFBTSxZQUFZLFdBQ3JCLElBQUksU0FBUyxhQUFhLFNBQVMsR0FBRyxNQUFNLFNBQVM7R0FFekQ7R0FFQSxTQUFPLGdCQUFnQixlQUFlO0dBQ3RDLFNBQU8saUJBQWlCLGdCQUFnQjtHQUN4QyxTQUFPLGtCQUFrQixpQkFBaUI7R0FDMUMsU0FBUyxpQkFBaUIsV0FBVyxjQUFjO0dBQ25ELFNBQVMsaUJBQWlCLFlBQVksZUFBZTtHQUNyRCxNQUFNLG1CQUFtQixJQUFJLGlCQUFpQixnQkFBZ0I7R0FDOUQsSUFBSSxXQUFXLGlCQUFpQixRQUFRLFdBQVc7SUFBRSxXQUFXO0lBQU0sU0FBUztHQUFLLENBQUM7R0FDckYsYUFBYTtJQUNYLFNBQVMsb0JBQW9CLFdBQVcsY0FBYztJQUN0RCxTQUFTLG9CQUFvQixZQUFZLGVBQWU7SUFDeEQsaUJBQWlCLFdBQVc7R0FDOUI7RUFDRjtDQUNGLEdBQUc7RUFBQztFQUFTO0VBQVcsV0FBVztFQUFRO0NBQWUsQ0FBQztDQUMzRCxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLFdBQVc7R0FDYixpQkFBaUIsSUFBSSxVQUFVO0dBQy9CLE1BQU0sMkJBQTJCLFNBQVM7R0FFMUMsSUFBSSxDQUR3QixVQUFVLFNBQVMsd0JBQ3hCLEdBQUc7SUFDeEIsTUFBTSxhQUFhLElBQUksWUFBWSxvQkFBb0IsYUFBYTtJQUNwRSxVQUFVLGlCQUFpQixvQkFBb0IsZ0JBQWdCO0lBQy9ELFVBQVUsY0FBYyxVQUFVO0lBQ2xDLElBQUksQ0FBQyxXQUFXLGtCQUFrQjtLQUNoQyxXQUFXLFlBQVksc0JBQXNCLFNBQVMsQ0FBQyxHQUFHLEVBQUUsUUFBUSxLQUFLLENBQUM7S0FDMUUsSUFBSSxTQUFTLGtCQUFrQiwwQkFDN0IsTUFBTSxTQUFTO0lBRW5CO0dBQ0Y7R0FDQSxhQUFhO0lBQ1gsVUFBVSxvQkFBb0Isb0JBQW9CLGdCQUFnQjtJQUNsRSxNQUFNLGdCQUFnQixVQUFVO0lBQ2hDLE1BQU0sZUFBZTtJQUNyQixpQkFBaUI7S0FDZixNQUFNLGVBQWUsSUFBSSxhQUFhLHNCQUFzQixhQUFhO0tBQ3pFLFVBQVUsaUJBQWlCLHNCQUFzQixrQkFBa0I7S0FDbkUsVUFBVSxjQUFjLFlBQVk7S0FDcEMsSUFBSSxDQUFDLGFBQWEsa0JBQ2hCLE1BQU0sNEJBQTRCLGNBQWMsTUFBTSxFQUFFLFFBQVEsS0FBSyxDQUFDO0tBRXhFLFVBQVUsb0JBQW9CLHNCQUFzQixrQkFBa0I7S0FDdEUsaUJBQWlCLE9BQU8sVUFBVTtJQUNwQyxHQUFHLENBQUM7R0FDTjtFQUNGO0NBQ0YsR0FBRztFQUFDO0VBQVc7RUFBa0I7RUFBb0I7Q0FBVSxDQUFDO0NBQ2hFLE1BQU0sZ0JBQUEsYUFBc0IsYUFDekIsVUFBVTtFQUNULElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUztFQUN2QixJQUFJLFdBQVcsUUFBUTtFQUN2QixNQUFNLFdBQVcsTUFBTSxRQUFRLFNBQVMsQ0FBQyxNQUFNLFVBQVUsQ0FBQyxNQUFNLFdBQVcsQ0FBQyxNQUFNO0VBQ2xGLE1BQU0saUJBQWlCLFNBQVM7RUFDaEMsSUFBSSxZQUFZLGdCQUFnQjtHQUM5QixNQUFNLGFBQWEsTUFBTTtHQUN6QixNQUFNLENBQUMsT0FBTyxRQUFRLGlCQUFpQixVQUFVO0dBRWpELElBQUksRUFEOEIsU0FBUyxPQUVyQztRQUFBLG1CQUFtQixZQUFZLE1BQU0sZUFBZTtHQUFBLE9BRXhELElBQUksQ0FBQyxNQUFNLFlBQVksbUJBQW1CLE1BQU07SUFDOUMsTUFBTSxlQUFlO0lBQ3JCLElBQUksTUFBTSxNQUFNLE9BQU8sRUFBRSxRQUFRLEtBQUssQ0FBQztHQUN6QyxPQUFPLElBQUksTUFBTSxZQUFZLG1CQUFtQixPQUFPO0lBQ3JELE1BQU0sZUFBZTtJQUNyQixJQUFJLE1BQU0sTUFBTSxNQUFNLEVBQUUsUUFBUSxLQUFLLENBQUM7R0FDeEM7RUFFSjtDQUNGLEdBQ0E7RUFBQztFQUFNO0VBQVMsV0FBVztDQUFNLENBQ25DO0NBQ0EsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksVUFBVSxLQUFLO0VBQUUsVUFBVTtFQUFJLEdBQUc7RUFBWSxLQUFLO0VBQWMsV0FBVztDQUFjLENBQUM7QUFDeEgsR0FBRyxZQUFZLENBQ2pCO0FBQ0EsSUFBSSwwQkFBQSxhQUFnQyxjQUFjLElBQUk7QUFDdEQsU0FBUyx5QkFBeUIsRUFBRSxVQUFVLFlBQVk7Q0FDeEQsSUFBSSxDQUFDLFVBQ0gsT0FBTztDQUVULE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLHdCQUF3QixVQUFVO0VBQUUsT0FBTztFQUFVO0NBQVMsQ0FBQztBQUM1RjtBQUNBRCxTQUFPLDBCQUEwQiwwQkFBMEI7QUFDM0QsU0FBUyw4QkFBOEI7Q0FDckMsTUFBTSxDQUFDLE9BQU8sWUFBQSxhQUFrQixTQUFTLENBQUMsQ0FBQztDQVEzQyxPQUFPO0VBQUU7RUFBTyxVQUFBLGFBUE8sZUFDZDtHQUNMLEtBQXFCLDBCQUFRLFNBQVMsVUFBVSxTQUFTLEtBQUssU0FBUyxJQUFJLElBQUksT0FBTyxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsR0FBRyxLQUFLO0dBQzdHLFFBQXdCLDBCQUFRLFNBQVMsVUFBVSxTQUFTLEtBQUssUUFBUSxZQUFZLFlBQVksSUFBSSxDQUFDLEdBQUcsUUFBUTtFQUNuSCxJQUNBLENBQUMsQ0FFb0I7Q0FBRTtBQUMzQjtBQUNBQSxTQUFPLDZCQUE2Qiw2QkFBNkI7QUFDakUsU0FBUyxvQkFBb0IsTUFBTTtDQUNqQyxNQUFNLFdBQUEsYUFBaUIsV0FBVyx1QkFBdUI7Q0FDekQsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVO0VBQ3hCLFNBQVMsSUFBSSxJQUFJO0VBQ2pCLGFBQWEsU0FBUyxPQUFPLElBQUk7Q0FDbkMsR0FBRyxDQUFDLE1BQU0sUUFBUSxDQUFDO0FBQ3JCO0FBQ0FBLFNBQU8scUJBQXFCLHFCQUFxQjtBQUNqRCxTQUFTLFdBQVcsWUFBWSxFQUFFLFNBQVMsVUFBVSxDQUFDLEdBQUc7Q0FDdkQsTUFBTSwyQkFBMkIsU0FBUztDQUMxQyxLQUFLLE1BQU0sYUFBYSxZQUFZO0VBQ2xDLE1BQU0sV0FBVyxFQUFFLE9BQU8sQ0FBQztFQUMzQixJQUFJLFNBQVMsa0JBQWtCLDBCQUEwQjtDQUMzRDtBQUNGO0FBQ0FBLFNBQU8sWUFBWSxZQUFZO0FBQy9CLFNBQVMsaUJBQWlCLFdBQVc7Q0FDbkMsTUFBTSxhQUFhLHNCQUFzQixTQUFTO0NBR2xELE9BQU8sQ0FGTyxZQUFZLFlBQVksU0FFMUIsR0FEQyxZQUFZLFdBQVcsUUFBUSxHQUFHLFNBQzdCLENBQUM7QUFDckI7QUFDQUEsU0FBTyxrQkFBa0Isa0JBQWtCO0FBQzNDLFNBQVMsc0JBQXNCLFdBQVc7Q0FDeEMsTUFBTSxRQUFRLENBQUM7Q0FFZixNQUFNLFNBRFksVUFBVSxjQUNILGlCQUFpQixXQUFXLFdBQVcsY0FBYyxFQUM1RSxZQUE0QiwwQkFBUSxTQUFTO0VBQzNDLE1BQU0sZ0JBQWdCLEtBQUssWUFBWSxXQUFXLEtBQUssU0FBUztFQUNoRSxJQUFJLEtBQUssWUFBWSxLQUFLLFVBQVUsZUFDbEMsT0FBTyxXQUFXO0VBRXBCLE9BQU8sS0FBSyxZQUFZLElBQUksV0FBVyxnQkFBZ0IsV0FBVztDQUNwRSxHQUFHLFlBQVksRUFDakIsQ0FBQztDQUNELE9BQU8sT0FBTyxTQUFTLEdBQ3JCLE1BQU0sS0FBSyxPQUFPLFdBQVc7Q0FFL0IsT0FBTztBQUNUO0FBQ0FBLFNBQU8sdUJBQXVCLHVCQUF1QjtBQUNyRCxTQUFTLFlBQVksVUFBVSxXQUFXO0NBQ3hDLE1BQU0sd0JBQXdCLE9BQU8sVUFBVSxvQkFBb0IsY0FBYyxVQUFVLGdCQUFnQixFQUFFLG9CQUFvQixLQUFLLENBQUM7Q0FDdkksS0FBSyxNQUFNLFdBQVcsVUFFcEIsSUFBSSxFQURXLHdCQUF3QixDQUFDLFFBQVEsZ0JBQWdCLEVBQUUsb0JBQW9CLEtBQUssQ0FBQyxJQUFJLFNBQVMsU0FBUyxFQUFFLE1BQU0sVUFBVSxDQUFDLElBRW5JLE9BQU87QUFHYjtBQUNBQSxTQUFPLGFBQWEsYUFBYTtBQUNqQyxTQUFTLFNBQVMsTUFBTSxFQUFFLFFBQVE7Q0FDaEMsSUFBSSxpQkFBaUIsSUFBSSxDQUFDLENBQUMsZUFBZSxVQUFVLE9BQU87Q0FDM0QsT0FBTyxNQUFNO0VBQ1gsSUFBSSxTQUFTLEtBQUssS0FBSyxTQUFTLE1BQU0sT0FBTztFQUM3QyxJQUFJLGlCQUFpQixJQUFJLENBQUMsQ0FBQyxZQUFZLFFBQVEsT0FBTztFQUN0RCxPQUFPLEtBQUs7Q0FDZDtDQUNBLE9BQU87QUFDVDtBQUNBQSxTQUFPLFVBQVUsVUFBVTtBQUMzQixTQUFTLGtCQUFrQixTQUFTO0NBQ2xDLE9BQU8sUUFBUSxZQUFZLFdBQVcsT0FBTyxRQUFRLFdBQVc7QUFDbEU7QUFDQUEsU0FBTyxtQkFBbUIsbUJBQW1CO0FBQzdDLFNBQVMsTUFBTSxTQUFTLEVBQUUsU0FBUyxVQUFVLENBQUMsR0FBRztDQUMvQyxJQUFJLFdBQVcsUUFBUSxPQUFPO0VBRTVCLE1BQU0sNEJBRGdCLFFBQVEsaUJBQWlCLFNBQUEsQ0FDQTtFQUMvQyxRQUFRLE1BQU0sRUFBRSxlQUFlLEtBQUssQ0FBQztFQUNyQyxJQUFJLFlBQVksNEJBQTRCLGtCQUFrQixPQUFPLEtBQUssUUFDeEUsUUFBUSxPQUFPO0NBQ25CO0FBQ0Y7QUFDQUEsU0FBTyxPQUFPLE9BQU87QUFDckIsSUFBSSxtQkFBbUIsdUJBQXVCO0FBQzlDLFNBQVMseUJBQXlCO0NBQ2hDLElBQUksUUFBUSxDQUFDO0NBQ2IsT0FBTztFQUNMLElBQUksWUFBWTtHQUNkLE1BQU0sbUJBQW1CLE1BQU07R0FDL0IsSUFBSSxlQUFlLGtCQUNqQixrQkFBa0IsTUFBTTtHQUUxQixRQUFRLFlBQVksT0FBTyxVQUFVO0dBQ3JDLE1BQU0sUUFBUSxVQUFVO0VBQzFCO0VBQ0EsT0FBTyxZQUFZO0dBQ2pCLFFBQVEsWUFBWSxPQUFPLFVBQVU7R0FDckMsTUFBTSxFQUFFLEVBQUUsT0FBTztFQUNuQjtDQUNGO0FBQ0Y7QUFDQUEsU0FBTyx3QkFBd0Isd0JBQXdCO0FBQ3ZELFNBQVMsWUFBWSxPQUFPLE1BQU07Q0FDaEMsTUFBTSxlQUFlLENBQUMsR0FBRyxLQUFLO0NBQzlCLE1BQU0sUUFBUSxhQUFhLFFBQVEsSUFBSTtDQUN2QyxJQUFJLFVBQVUsSUFDWixhQUFhLE9BQU8sT0FBTyxDQUFDO0NBRTlCLE9BQU87QUFDVDtBQUNBQSxTQUFPLGFBQWEsYUFBYTtBQUNqQyxTQUFTLFlBQVksT0FBTztDQUMxQixPQUFPLE1BQU0sUUFBUSxTQUFTLEtBQUssWUFBWSxHQUFHO0FBQ3BEO0FBQ0FBLFNBQU8sYUFBYSxhQUFhOzs7O0FDblJqQyxJQUFJRSxjQUFZLE9BQU87QUFDdkIsSUFBSUMsWUFBVSxRQUFRLFVBQVVELFlBQVUsUUFBUSxRQUFRO0NBQUU7Q0FBTyxjQUFjO0FBQUssQ0FBQztBQVF2RixJQUFJLFNBQXlCLDZCQUFNLFdBQ2pCLHlCQUFPLFNBQVMsUUFBUSxPQUFPLGNBQWM7Q0FDM0QsTUFBTSxFQUFFLFdBQVcsZUFBZSxHQUFHLGdCQUFnQjtDQUNyRCxNQUFNLENBQUMsU0FBUyxjQUFBLGFBQW9CLFNBQVMsS0FBSztDQUNsRCx1QkFBc0IsV0FBVyxJQUFJLEdBQUcsQ0FBQyxDQUFDO0NBQzFDLE1BQU0sWUFBWSxpQkFBaUIsV0FBVyxZQUFZLFVBQVU7Q0FDcEUsT0FBTyxZQUFBLGlCQUFxQixhQUE2QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVLEtBQUs7RUFBRSxHQUFHO0VBQWEsS0FBSztDQUFhLENBQUMsR0FBRyxTQUFTLElBQUk7QUFDbkksR0FBRyxRQUFRLENBQ2I7OztBQ2pCQSxJQUFJRSxjQUFZLE9BQU87QUFDdkIsSUFBSUMsWUFBVSxRQUFRLFVBQVVELFlBQVUsUUFBUSxRQUFRO0NBQUU7Q0FBTyxjQUFjO0FBQUssQ0FBQztBQVF2RixTQUFTLGdCQUFnQixjQUFjLFNBQVM7Q0FDOUMsT0FBQSxhQUFhLFlBQVksT0FBTyxVQUFVO0VBRXhDLE9BRGtCLFFBQVEsTUFBTSxDQUFDLFVBQ2I7Q0FDdEIsR0FBRyxZQUFZO0FBQ2pCO0FBQ0FDLFNBQU8saUJBQWlCLGlCQUFpQjtBQUd6QyxJQUFJLFdBQTJCLDBCQUFRLFVBQVU7Q0FDL0MsTUFBTSxFQUFFLFNBQVMsYUFBYTtDQUM5QixNQUFNLFdBQVcsWUFBWSxPQUFPO0NBQ3BDLE1BQU0sUUFBUSxPQUFPLGFBQWEsYUFBYSxTQUFTLEVBQUUsU0FBUyxTQUFTLFVBQVUsQ0FBQyxJQUFBLGFBQVcsU0FBUyxLQUFLLFFBQVE7Q0FDeEgsTUFBTSxNQUFNLHNCQUFzQixTQUFTLEtBQUssY0FBYyxLQUFLLENBQUM7Q0FFcEUsT0FEbUIsT0FBTyxhQUFhLGNBQ2xCLFNBQVMsWUFBQSxhQUFtQixhQUFhLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSTtBQUNsRixHQUFHLFVBQVU7QUFDYixTQUFTLFlBQVksU0FBUztDQUM1QixNQUFNLENBQUMsTUFBTSxXQUFBLGFBQWtCLFNBQVM7Q0FDeEMsTUFBTSxZQUFBLGFBQW1CLE9BQU8sSUFBSTtDQUNwQyxNQUFNLGlCQUFBLGFBQXdCLE9BQU8sT0FBTztDQUM1QyxNQUFNLHVCQUFBLGFBQThCLE9BQU8sTUFBTTtDQUNqRCxNQUFNLHdCQUFBLGFBQStCLE9BQU8sS0FBSyxDQUFDO0NBRWxELE1BQU0sQ0FBQyxPQUFPLFFBQVEsZ0JBREQsVUFBVSxZQUFZLGFBQ1M7RUFDbEQsU0FBUztHQUNQLFNBQVM7R0FDVCxlQUFlO0VBQ2pCO0VBQ0Esa0JBQWtCO0dBQ2hCLE9BQU87R0FDUCxlQUFlO0VBQ2pCO0VBQ0EsV0FBVyxFQUNULE9BQU8sVUFDVDtDQUNGLENBQUM7Q0FDRCxhQUFPLGdCQUFnQjtFQUNyQixJQUFJLFVBQVUsV0FBVztHQUN2QixxQkFBcUIsVUFBVSxzQkFBc0IsV0FBVyxpQkFBaUIsVUFBVSxPQUFPO0dBQ2xHLHNCQUFzQixVQUFVLEtBQUs7RUFDdkMsT0FDRSxxQkFBcUIsVUFBVTtDQUVuQyxHQUFHLENBQUMsS0FBSyxDQUFDO0NBQ1YsdUJBQXNCO0VBQ3BCLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLE1BQU0sYUFBYSxlQUFlO0VBRWxDLElBRDBCLGVBQWUsU0FDbEI7R0FDckIsTUFBTSxvQkFBb0IscUJBQXFCO0dBQy9DLE1BQU0sdUJBQXVCLGlCQUFpQixNQUFNO0dBQ3BELElBQUksU0FBUztJQUNYLHNCQUFzQixVQUFVO0lBQ2hDLEtBQUssT0FBTztHQUNkLE9BQU8sSUFBSSx5QkFBeUIsVUFBVSxRQUFRLFlBQVksUUFDaEUsS0FBSyxTQUFTO1FBR2QsSUFBSSxjQURnQixzQkFBc0Isc0JBRXhDLEtBQUssZUFBZTtRQUVwQixLQUFLLFNBQVM7R0FHbEIsZUFBZSxVQUFVO0VBQzNCO0NBQ0YsR0FBRyxDQUFDLFNBQVMsSUFBSSxDQUFDO0NBQ2xCLHVCQUFzQjtFQUNwQixJQUFJLE1BQU07R0FDUixJQUFJO0dBQ0osTUFBTSxjQUFjLEtBQUssY0FBYyxlQUFlO0dBQ3RELE1BQU0scUJBQXFDLDBCQUFRLFVBQVU7SUFFM0QsTUFBTSxxQkFEdUIsaUJBQWlCLFVBQVUsT0FDVixDQUFDLENBQUMsU0FBUyxJQUFJLE9BQU8sTUFBTSxhQUFhLENBQUM7SUFDeEYsSUFBSSxNQUFNLFdBQVcsUUFBUSxvQkFBb0I7S0FDL0MsS0FBSyxlQUFlO0tBQ3BCLElBQUksQ0FBQyxlQUFlLFNBQVM7TUFDM0IsTUFBTSxrQkFBa0IsS0FBSyxNQUFNO01BQ25DLEtBQUssTUFBTSxvQkFBb0I7TUFDL0IsWUFBWSxZQUFZLGlCQUFpQjtPQUN2QyxJQUFJLEtBQUssTUFBTSxzQkFBc0IsWUFDbkMsS0FBSyxNQUFNLG9CQUFvQjtNQUVuQyxDQUFDO0tBQ0g7SUFDRjtHQUNGLEdBQUcsb0JBQW9CO0dBQ3ZCLE1BQU0sdUJBQXVDLDBCQUFRLFVBQVU7SUFDN0QsSUFBSSxNQUFNLFdBQVcsTUFDbkIscUJBQXFCLFVBQVUsaUJBQWlCLFVBQVUsT0FBTztHQUVyRSxHQUFHLHNCQUFzQjtHQUN6QixLQUFLLGlCQUFpQixrQkFBa0Isb0JBQW9CO0dBQzVELEtBQUssaUJBQWlCLG1CQUFtQixrQkFBa0I7R0FDM0QsS0FBSyxpQkFBaUIsZ0JBQWdCLGtCQUFrQjtHQUN4RCxhQUFhO0lBQ1gsWUFBWSxhQUFhLFNBQVM7SUFDbEMsS0FBSyxvQkFBb0Isa0JBQWtCLG9CQUFvQjtJQUMvRCxLQUFLLG9CQUFvQixtQkFBbUIsa0JBQWtCO0lBQzlELEtBQUssb0JBQW9CLGdCQUFnQixrQkFBa0I7R0FDN0Q7RUFDRixPQUNFLEtBQUssZUFBZTtDQUV4QixHQUFHLENBQUMsTUFBTSxJQUFJLENBQUM7Q0FDZixPQUFPO0VBQ0wsV0FBVyxDQUFDLFdBQVcsa0JBQWtCLENBQUMsQ0FBQyxTQUFTLEtBQUs7RUFDekQsS0FBQSxhQUFZLGFBQWEsVUFBVTtHQUNqQyxJQUFJLE9BQU87SUFDVCxNQUFNLFNBQVMsaUJBQWlCLEtBQUs7SUFDckMsVUFBVSxVQUFVO0lBQ3BCLHNCQUFzQixVQUFVLGlCQUFpQixNQUFNO0dBQ3pELE9BQ0UsVUFBVSxVQUFVO0dBRXRCLFFBQVEsS0FBSztFQUNmLEdBQUcsQ0FBQyxDQUFDO0NBQ1A7QUFDRjtBQUNBQSxTQUFPLGFBQWEsYUFBYTtBQUNqQyxTQUFTLE9BQU8sS0FBSyxPQUFPO0NBQzFCLElBQUksT0FBTyxRQUFRLFlBQ2pCLE9BQU8sSUFBSSxLQUFLO01BQ1gsSUFBSSxRQUFRLFFBQVEsUUFBUSxLQUFLLEdBQ3RDLElBQUksVUFBVTtBQUVsQjtBQUNBQSxTQUFPLFFBQVEsUUFBUTtBQUN2QixTQUFTLHNCQUFzQixHQUFHLE1BQU07Q0FDdEMsTUFBTSxVQUFBLGFBQWlCLE9BQU8sSUFBSTtDQUNsQyxRQUFRLFVBQVU7Q0FDbEIsT0FBQSxhQUFjLGFBQWEsU0FBUztFQUNsQyxNQUFNLGNBQWMsUUFBUTtFQUM1QixJQUFJLGFBQWE7RUFDakIsTUFBTSxXQUFXLFlBQVksS0FBSyxRQUFRO0dBQ3hDLE1BQU0sVUFBVSxPQUFPLEtBQUssSUFBSTtHQUNoQyxJQUFJLENBQUMsY0FBYyxPQUFPLFlBQVksWUFDcEMsYUFBYTtHQUVmLE9BQU87RUFDVCxDQUFDO0VBQ0QsSUFBSSxZQUNGLGFBQWE7R0FDWCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7SUFDeEMsTUFBTSxVQUFVLFNBQVM7SUFDekIsSUFBSSxPQUFPLFlBQVksWUFDckIsUUFBUTtTQUVSLE9BQU8sWUFBWSxJQUFJLElBQUk7R0FFL0I7RUFDRjtDQUVKLEdBQUcsQ0FBQyxDQUFDO0FBQ1A7QUFDQUEsU0FBTyx1QkFBdUIsdUJBQXVCO0FBQ3JELFNBQVMsaUJBQWlCLFFBQVE7Q0FDaEMsT0FBTyxRQUFRLGlCQUFpQjtBQUNsQztBQUNBQSxTQUFPLGtCQUFrQixrQkFBa0I7QUFDM0MsU0FBUyxjQUFjLFNBQVM7Q0FDOUIsSUFBSSxTQUFTLE9BQU8seUJBQXlCLFFBQVEsT0FBTyxLQUFLLENBQUMsRUFBRTtDQUNwRSxJQUFJLFVBQVUsVUFBVSxvQkFBb0IsVUFBVSxPQUFPO0NBQzdELElBQUksU0FDRixPQUFPLFFBQVE7Q0FFakIsU0FBUyxPQUFPLHlCQUF5QixTQUFTLEtBQUssQ0FBQyxFQUFFO0NBQzFELFVBQVUsVUFBVSxvQkFBb0IsVUFBVSxPQUFPO0NBQ3pELElBQUksU0FDRixPQUFPLFFBQVEsTUFBTTtDQUV2QixPQUFPLFFBQVEsTUFBTSxPQUFPLFFBQVE7QUFDdEM7QUFDQUEsU0FBTyxlQUFlLGVBQWU7OztBQ3ZMckMsSUFBSUMsY0FBWSxPQUFPO0FBQ3ZCLElBQUlDLFlBQVUsUUFBUSxVQUFVRCxZQUFVLFFBQVEsUUFBUTtDQUFFO0NBQU8sY0FBYztBQUFLLENBQUM7QUFJdkYsSUFBSSxRQUFRO0FBQ1osSUFBSSxTQUFTO0FBQ2IsU0FBUyxZQUFZLE9BQU87Q0FDMUIsZUFBZTtDQUNmLE9BQU8sTUFBTTtBQUNmO0FBQ0FDLFNBQU8sYUFBYSxhQUFhO0FBQ2pDLFNBQVMsaUJBQWlCO0NBQ3hCLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyxRQUNILFNBQVM7R0FBRSxPQUFPLGlCQUFpQjtHQUFHLEtBQUssaUJBQWlCO0VBQUU7RUFFaEUsTUFBTSxFQUFFLE9BQU8sUUFBUTtFQUN2QixJQUFJLFNBQVMsS0FBSyxzQkFBc0IsT0FDdEMsU0FBUyxLQUFLLHNCQUFzQixjQUFjLEtBQUs7RUFFekQsSUFBSSxTQUFTLEtBQUsscUJBQXFCLEtBQ3JDLFNBQVMsS0FBSyxzQkFBc0IsYUFBYSxHQUFHO0VBRXREO0VBQ0EsYUFBYTtHQUNYLElBQUksVUFBVSxHQUFHO0lBQ2YsUUFBUSxNQUFNLE9BQU87SUFDckIsUUFBUSxJQUFJLE9BQU87SUFDbkIsU0FBUztHQUNYO0dBQ0EsUUFBUSxLQUFLLElBQUksR0FBRyxRQUFRLENBQUM7RUFDL0I7Q0FDRixHQUFHLENBQUMsQ0FBQztBQUNQO0FBQ0FBLFNBQU8sZ0JBQWdCLGdCQUFnQjtBQUN2QyxTQUFTLG1CQUFtQjtDQUMxQixNQUFNLFVBQVUsU0FBUyxjQUFjLE1BQU07Q0FDN0MsUUFBUSxhQUFhLDBCQUEwQixFQUFFO0NBQ2pELFFBQVEsV0FBVztDQUNuQixRQUFRLE1BQU0sVUFBVTtDQUN4QixRQUFRLE1BQU0sVUFBVTtDQUN4QixRQUFRLE1BQU0sV0FBVztDQUN6QixRQUFRLE1BQU0sZ0JBQWdCO0NBQzlCLE9BQU87QUFDVDtBQUNBQSxTQUFPLGtCQUFrQixrQkFBa0I7OztBQ2hCM0MsSUFBVyxXQUFXLFdBQVc7Q0FDL0IsV0FBVyxPQUFPLFVBQVUsU0FBUyxTQUFTLEdBQUc7RUFDN0MsS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLElBQUksR0FBRyxLQUFLO0dBQ2pELElBQUksVUFBVTtHQUNkLEtBQUssSUFBSSxLQUFLLEdBQUcsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFO0VBQzlFO0VBQ0EsT0FBTztDQUNYO0NBQ0EsT0FBTyxTQUFTLE1BQU0sTUFBTSxTQUFTO0FBQ3ZDO0FBRUEsU0FBZ0IsT0FBTyxHQUFHLEdBQUc7Q0FDM0IsSUFBSSxJQUFJLENBQUM7Q0FDVCxLQUFLLElBQUksS0FBSyxHQUFHLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxHQUFHLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLEdBQzlFLEVBQUUsS0FBSyxFQUFFO0NBQ2IsSUFBSSxLQUFLLFFBQVEsT0FBTyxPQUFPLDBCQUEwQixZQUNoRDtPQUFBLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxzQkFBc0IsQ0FBQyxHQUFHLElBQUksRUFBRSxRQUFRLEtBQy9ELElBQUksRUFBRSxRQUFRLEVBQUUsRUFBRSxJQUFJLEtBQUssT0FBTyxVQUFVLHFCQUFxQixLQUFLLEdBQUcsRUFBRSxFQUFFLEdBQ3pFLEVBQUUsRUFBRSxNQUFNLEVBQUUsRUFBRTtDQUFBO0NBRTFCLE9BQU87QUFDVDtBQWlLQSxTQUFnQixjQUFjLElBQUksTUFBTSxNQUFNO0NBQzVDLElBQUksUUFBUSxVQUFVLFdBQVcsR0FBUTtPQUFBLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLElBQUksSUFBSSxHQUFHLEtBQzVFLElBQUksTUFBTSxFQUFFLEtBQUssT0FBTztHQUNwQixJQUFJLENBQUMsSUFBSSxLQUFLLE1BQU0sVUFBVSxNQUFNLEtBQUssTUFBTSxHQUFHLENBQUM7R0FDbkQsR0FBRyxLQUFLLEtBQUs7RUFDakI7O0NBRUosT0FBTyxHQUFHLE9BQU8sTUFBTSxNQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksQ0FBQztBQUN6RDs7O0FDN05BLElBQVcscUJBQXFCO0FBQ2hDLElBQVcscUJBQXFCO0FBQ2hDLElBQVcsd0JBQXdCOzs7OztBQUtuQyxJQUFXLHlCQUF5Qjs7Ozs7Ozs7Ozs7Ozs7OztBQ01wQyxTQUFnQixVQUFVLEtBQUssT0FBTztDQUNsQyxJQUFJLE9BQU8sUUFBUSxZQUNmLElBQUksS0FBSztNQUVSLElBQUksS0FDTCxJQUFJLFVBQVU7Q0FFbEIsT0FBTztBQUNYOzs7Ozs7Ozs7Ozs7Ozs7OztBQ05BLFNBQWdCLGVBQWUsY0FBYyxVQUFVO0NBQ25ELElBQUksT0FBQSxHQUFNQyxhQUFBQSxTQUFBQSxDQUFTLFdBQVk7RUFBRSxPQUFRO0dBRXJDLE9BQU87R0FFRztHQUVWLFFBQVE7SUFDSixJQUFJLFVBQVU7S0FDVixPQUFPLElBQUk7SUFDZjtJQUNBLElBQUksUUFBUSxPQUFPO0tBQ2YsSUFBSSxPQUFPLElBQUk7S0FDZixJQUFJLFNBQVMsT0FBTztNQUNoQixJQUFJLFFBQVE7TUFDWixJQUFJLFNBQVMsT0FBTyxJQUFJO0tBQzVCO0lBQ0o7R0FDSjtFQUNKO0NBQUksQ0FBQyxDQUFDLENBQUM7Q0FFUCxJQUFJLFdBQVc7Q0FDZixPQUFPLElBQUk7QUFDZjs7O0FDbkNBLElBQUksNEJBQTRCLE9BQU8sV0FBVyxjQUFBLGFBQW9CLGtCQUFBLGFBQXdCO0FBQzlGLElBQUksZ0NBQWdCLElBQUksUUFBUTs7Ozs7Ozs7Ozs7Ozs7O0FBZWhDLFNBQWdCLGFBQWEsTUFBTSxjQUFjO0NBQzdDLElBQUksY0FBYyxlQUFlLGdCQUFnQixNQUFNLFNBQVUsVUFBVTtFQUN2RSxPQUFPLEtBQUssUUFBUSxTQUFVLEtBQUs7R0FBRSxPQUFPLFVBQVUsS0FBSyxRQUFRO0VBQUcsQ0FBQztDQUMzRSxDQUFDO0NBRUQsMEJBQTBCLFdBQVk7RUFDbEMsSUFBSSxXQUFXLGNBQWMsSUFBSSxXQUFXO0VBQzVDLElBQUksVUFBVTtHQUNWLElBQUksYUFBYSxJQUFJLElBQUksUUFBUTtHQUNqQyxJQUFJLGFBQWEsSUFBSSxJQUFJLElBQUk7R0FDN0IsSUFBSSxZQUFZLFlBQVk7R0FDNUIsV0FBVyxRQUFRLFNBQVUsS0FBSztJQUM5QixJQUFJLENBQUMsV0FBVyxJQUFJLEdBQUcsR0FDbkIsVUFBVSxLQUFLLElBQUk7R0FFM0IsQ0FBQztHQUNELFdBQVcsUUFBUSxTQUFVLEtBQUs7SUFDOUIsSUFBSSxDQUFDLFdBQVcsSUFBSSxHQUFHLEdBQ25CLFVBQVUsS0FBSyxTQUFTO0dBRWhDLENBQUM7RUFDTDtFQUNBLGNBQWMsSUFBSSxhQUFhLElBQUk7Q0FDdkMsR0FBRyxDQUFDLElBQUksQ0FBQztDQUNULE9BQU87QUFDWDs7O0FDM0NBLFNBQVMsS0FBSyxHQUFHO0NBQ2IsT0FBTztBQUNYO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVSxZQUFZO0NBQzdDLElBQUksZUFBZSxLQUFLLEdBQUssYUFBYTtDQUMxQyxJQUFJLFNBQVMsQ0FBQztDQUNkLElBQUksV0FBVztDQTBEZixPQUFPO0VBeERILE1BQU0sV0FBWTtHQUNkLElBQUksVUFDQSxNQUFNLElBQUksTUFBTSxrR0FBa0c7R0FFdEgsSUFBSSxPQUFPLFFBQ1AsT0FBTyxPQUFPLE9BQU8sU0FBUztHQUVsQyxPQUFPO0VBQ1g7RUFDQSxXQUFXLFNBQVUsTUFBTTtHQUN2QixJQUFJLE9BQU8sV0FBVyxNQUFNLFFBQVE7R0FDcEMsT0FBTyxLQUFLLElBQUk7R0FDaEIsT0FBTyxXQUFZO0lBQ2YsU0FBUyxPQUFPLE9BQU8sU0FBVSxHQUFHO0tBQUUsT0FBTyxNQUFNO0lBQU0sQ0FBQztHQUM5RDtFQUNKO0VBQ0Esa0JBQWtCLFNBQVUsSUFBSTtHQUM1QixXQUFXO0dBQ1gsT0FBTyxPQUFPLFFBQVE7SUFDbEIsSUFBSSxNQUFNO0lBQ1YsU0FBUyxDQUFDO0lBQ1YsSUFBSSxRQUFRLEVBQUU7R0FDbEI7R0FDQSxTQUFTO0lBQ0wsTUFBTSxTQUFVLEdBQUc7S0FBRSxPQUFPLEdBQUcsQ0FBQztJQUFHO0lBQ25DLFFBQVEsV0FBWTtLQUFFLE9BQU87SUFBUTtHQUN6QztFQUNKO0VBQ0EsY0FBYyxTQUFVLElBQUk7R0FDeEIsV0FBVztHQUNYLElBQUksZUFBZSxDQUFDO0dBQ3BCLElBQUksT0FBTyxRQUFRO0lBQ2YsSUFBSSxNQUFNO0lBQ1YsU0FBUyxDQUFDO0lBQ1YsSUFBSSxRQUFRLEVBQUU7SUFDZCxlQUFlO0dBQ25CO0dBQ0EsSUFBSSxlQUFlLFdBQVk7SUFDM0IsSUFBSSxNQUFNO0lBQ1YsZUFBZSxDQUFDO0lBQ2hCLElBQUksUUFBUSxFQUFFO0dBQ2xCO0dBQ0EsSUFBSSxRQUFRLFdBQVk7SUFBRSxPQUFPLFFBQVEsUUFBUSxDQUFDLENBQUMsS0FBSyxZQUFZO0dBQUc7R0FDdkUsTUFBTTtHQUNOLFNBQVM7SUFDTCxNQUFNLFNBQVUsR0FBRztLQUNmLGFBQWEsS0FBSyxDQUFDO0tBQ25CLE1BQU07SUFDVjtJQUNBLFFBQVEsU0FBVSxRQUFRO0tBQ3RCLGVBQWUsYUFBYSxPQUFPLE1BQU07S0FDekMsT0FBTztJQUNYO0dBQ0o7RUFDSjtDQUVRO0FBQ2hCO0FBTUEsU0FBZ0Isb0JBQW9CLFNBQVM7Q0FDekMsSUFBSSxZQUFZLEtBQUssR0FBSyxVQUFVLENBQUM7Q0FDckMsSUFBSSxTQUFTLGtCQUFrQixJQUFJO0NBQ25DLE9BQU8sVUFBVSxTQUFTO0VBQUUsT0FBTztFQUFNLEtBQUs7Q0FBTSxHQUFHLE9BQU87Q0FDOUQsT0FBTztBQUNYOzs7QUMzRUEsSUFBSSxVQUFVLFNBQVUsSUFBSTtDQUN4QixJQUFJLFVBQVUsR0FBRyxTQUFTLE9BQU8sT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO0NBQ3ZELElBQUksQ0FBQyxTQUNELE1BQU0sSUFBSSxNQUFNLG9FQUFvRTtDQUV4RixJQUFJLFNBQVMsUUFBUSxLQUFLO0NBQzFCLElBQUksQ0FBQyxRQUNELE1BQU0sSUFBSSxNQUFNLDBCQUEwQjtDQUU5QyxPQUFBLGFBQWEsY0FBYyxRQUFRLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQztBQUN6RDtBQUNBLFFBQVEsa0JBQWtCO0FBQzFCLFNBQWdCLGNBQWMsUUFBUSxVQUFVO0NBQzVDLE9BQU8sVUFBVSxRQUFRO0NBQ3pCLE9BQU87QUFDWDs7O0FDaEJBLElBQVcsWUFBWSxvQkFBb0I7OztBQ0kzQyxJQUFJLFVBQVUsV0FBWSxDQUUxQjs7OztBQUlBLElBQUksZUFBQSxhQUFxQixXQUFXLFNBQVUsT0FBTyxXQUFXO0NBQzVELElBQUksTUFBQSxhQUFZLE9BQU8sSUFBSTtDQUMzQixJQUFJLEtBQUEsYUFBVyxTQUFTO0VBQ3BCLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIsb0JBQW9CO0NBQ3hCLENBQUMsR0FBRyxZQUFZLEdBQUcsSUFBSSxlQUFlLEdBQUc7Q0FDekMsSUFBSSxlQUFlLE1BQU0sY0FBYyxXQUFXLE1BQU0sVUFBVSxZQUFZLE1BQU0sV0FBVyxrQkFBa0IsTUFBTSxpQkFBaUIsVUFBVSxNQUFNLFNBQVMsU0FBUyxNQUFNLFFBQVEsVUFBVSxNQUFNLFNBQVMsYUFBYSxNQUFNLFlBQVksY0FBYyxNQUFNLGFBQWEsUUFBUSxNQUFNLE9BQU8saUJBQWlCLE1BQU0sZ0JBQWdCLEtBQUssTUFBTSxJQUFJLFlBQVksT0FBTyxLQUFLLElBQUksUUFBUSxJQUFJLFVBQVUsTUFBTSxTQUFTLE9BQU8sT0FBTyxPQUFPO0VBQUM7RUFBZ0I7RUFBWTtFQUFhO0VBQW1CO0VBQVc7RUFBVTtFQUFXO0VBQWM7RUFBZTtFQUFTO0VBQWtCO0VBQU07Q0FBUyxDQUFDO0NBQ3ZsQixJQUFJLFVBQVU7Q0FDZCxJQUFJLGVBQWUsYUFBYSxDQUFDLEtBQUssU0FBUyxDQUFDO0NBQ2hELElBQUksaUJBQWlCLFNBQVMsU0FBUyxDQUFDLEdBQUcsSUFBSSxHQUFHLFNBQVM7Q0FDM0QsT0FBQSxhQUFjLGNBQUEsYUFBb0IsVUFBVSxNQUN4QyxXQUFBLGFBQWtCLGNBQWMsU0FBUztFQUFFLFNBQVM7RUFBNEI7RUFBeUI7RUFBb0I7RUFBeUI7RUFBb0I7RUFBcUI7RUFBYyxnQkFBZ0IsQ0FBQyxDQUFDO0VBQWdCLFNBQVM7RUFBYztDQUFRLENBQUMsR0FDL1EsZUFBQSxhQUFzQixhQUFBLGFBQW1CLFNBQVMsS0FBSyxRQUFRLEdBQUcsU0FBUyxTQUFTLENBQUMsR0FBRyxjQUFjLEdBQUcsRUFBRSxLQUFLLGFBQWEsQ0FBQyxDQUFDLElBQUEsYUFBWSxjQUFjLFdBQVcsU0FBUyxDQUFDLEdBQUcsZ0JBQWdCO0VBQWE7RUFBVyxLQUFLO0NBQWEsQ0FBQyxHQUFHLFFBQVEsQ0FBRTtBQUNqUSxDQUFDO0FBQ0QsYUFBYSxlQUFlO0NBQ3hCLFNBQVM7Q0FDVCxpQkFBaUI7Q0FDakIsT0FBTztBQUNYO0FBQ0EsYUFBYSxhQUFhO0NBQ3RCLFdBQVc7Q0FDWCxXQUFXO0FBQ2Y7QUM5QkEsSUFBVyxXQUFXLFdBQVk7Q0FJOUIsSUFBSSxPQUFPLHNCQUFzQixhQUM3QixPQUFPO0FBR2Y7OztBQ1hBLFNBQVMsZUFBZTtDQUNwQixJQUFJLENBQUMsVUFDRCxPQUFPO0NBQ1gsSUFBSSxNQUFNLFNBQVMsY0FBYyxPQUFPO0NBQ3hDLElBQUksT0FBTztDQUNYLElBQUksUUFBUSxTQUFTO0NBQ3JCLElBQUksT0FDQSxJQUFJLGFBQWEsU0FBUyxLQUFLO0NBRW5DLE9BQU87QUFDWDtBQUNBLFNBQVMsYUFBYSxLQUFLLEtBQUs7Q0FFNUIsSUFBSSxJQUFJLFlBRUosSUFBSSxXQUFXLFVBQVU7TUFHekIsSUFBSSxZQUFZLFNBQVMsZUFBZSxHQUFHLENBQUM7QUFFcEQ7QUFDQSxTQUFTLGVBQWUsS0FBSztDQUV6QixDQURXLFNBQVMsUUFBUSxTQUFTLHFCQUFxQixNQUFNLENBQUMsQ0FBQyxHQUFBLENBQzdELFlBQVksR0FBRztBQUN4QjtBQUNBLElBQVcsc0JBQXNCLFdBQVk7Q0FDekMsSUFBSSxVQUFVO0NBQ2QsSUFBSSxhQUFhO0NBQ2pCLE9BQU87RUFDSCxLQUFLLFNBQVUsT0FBTztHQUNsQixJQUFJLFdBQVcsR0FDTjtRQUFBLGFBQWEsYUFBYSxHQUFJO0tBQy9CLGFBQWEsWUFBWSxLQUFLO0tBQzlCLGVBQWUsVUFBVTtJQUM3Qjs7R0FFSjtFQUNKO0VBQ0EsUUFBUSxXQUFZO0dBQ2hCO0dBQ0EsSUFBSSxDQUFDLFdBQVcsWUFBWTtJQUN4QixXQUFXLGNBQWMsV0FBVyxXQUFXLFlBQVksVUFBVTtJQUNyRSxhQUFhO0dBQ2pCO0VBQ0o7Q0FDSjtBQUNKOzs7Ozs7Ozs7Ozs7QUNwQ0EsSUFBVyxxQkFBcUIsV0FBWTtDQUN4QyxJQUFJLFFBQVEsb0JBQW9CO0NBQ2hDLE9BQU8sU0FBVSxRQUFRLFdBQVc7RUFDaEMsYUFBTSxVQUFVLFdBQVk7R0FDeEIsTUFBTSxJQUFJLE1BQU07R0FDaEIsT0FBTyxXQUFZO0lBQ2YsTUFBTSxPQUFPO0dBQ2pCO0VBQ0osR0FBRyxDQUFDLFVBQVUsU0FBUyxDQUFDO0NBQzVCO0FBQ0o7Ozs7Ozs7OztBQ2RBLElBQVcsaUJBQWlCLFdBQVk7Q0FDcEMsSUFBSSxXQUFXLG1CQUFtQjtDQUNsQyxJQUFJLFFBQVEsU0FBVSxJQUFJO0VBQ3RCLElBQUksU0FBUyxHQUFHLFFBQVEsVUFBVSxHQUFHO0VBQ3JDLFNBQVMsUUFBUSxPQUFPO0VBQ3hCLE9BQU87Q0FDWDtDQUNBLE9BQU87QUFDWDs7O0FDZkEsSUFBVyxVQUFVO0NBQ2pCLE1BQU07Q0FDTixLQUFLO0NBQ0wsT0FBTztDQUNQLEtBQUs7QUFDVDtBQUNBLElBQUksUUFBUSxTQUFVLEdBQUc7Q0FBRSxPQUFPLFNBQVMsS0FBSyxJQUFJLEVBQUUsS0FBSztBQUFHO0FBQzlELElBQUksWUFBWSxTQUFVLFNBQVM7Q0FDL0IsSUFBSSxLQUFLLE9BQU8saUJBQWlCLFNBQVMsSUFBSTtDQUM5QyxJQUFJLE9BQU8sR0FBRyxZQUFZLFlBQVksZ0JBQWdCO0NBQ3RELElBQUksTUFBTSxHQUFHLFlBQVksWUFBWSxlQUFlO0NBQ3BELElBQUksUUFBUSxHQUFHLFlBQVksWUFBWSxpQkFBaUI7Q0FDeEQsT0FBTztFQUFDLE1BQU0sSUFBSTtFQUFHLE1BQU0sR0FBRztFQUFHLE1BQU0sS0FBSztDQUFDO0FBQ2pEO0FBQ0EsSUFBVyxjQUFjLFNBQVUsU0FBUztDQUN4QyxJQUFJLFlBQVksS0FBSyxHQUFLLFVBQVU7Q0FDcEMsSUFBSSxPQUFPLFdBQVcsYUFDbEIsT0FBTztDQUVYLElBQUksVUFBVSxVQUFVLE9BQU87Q0FDL0IsSUFBSSxnQkFBZ0IsU0FBUyxnQkFBZ0I7Q0FDN0MsSUFBSSxjQUFjLE9BQU87Q0FDekIsT0FBTztFQUNILE1BQU0sUUFBUTtFQUNkLEtBQUssUUFBUTtFQUNiLE9BQU8sUUFBUTtFQUNmLEtBQUssS0FBSyxJQUFJLEdBQUcsY0FBYyxnQkFBZ0IsUUFBUSxLQUFLLFFBQVEsRUFBRTtDQUMxRTtBQUNKOzs7QUN4QkEsSUFBSSxRQUFRLGVBQWU7QUFDM0IsSUFBVyxnQkFBZ0I7QUFJM0IsSUFBSSxZQUFZLFNBQVUsSUFBSSxlQUFlLFNBQVMsV0FBVztDQUM3RCxJQUFJLE9BQU8sR0FBRyxNQUFNLE1BQU0sR0FBRyxLQUFLLFFBQVEsR0FBRyxPQUFPLE1BQU0sR0FBRztDQUM3RCxJQUFJLFlBQVksS0FBSyxHQUFLLFVBQVU7Q0FDcEMsT0FBTyxRQUFRLE9BQU8sdUJBQXVCLDBCQUEwQixDQUFDLENBQUMsT0FBTyxXQUFXLHVCQUF1QixDQUFDLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLE9BQU8sV0FBVyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sZUFBZSw0QkFBNEIsQ0FBQyxDQUFDLE9BQU8sV0FBVyw0Q0FBNEMsQ0FBQyxDQUFDLE9BQU87RUFDblMsaUJBQWlCLHNCQUFzQixPQUFPLFdBQVcsR0FBRztFQUM1RCxZQUFZLFlBQ1IsdUJBQXVCLE9BQU8sTUFBTSx3QkFBd0IsQ0FBQyxDQUFDLE9BQU8sS0FBSywwQkFBMEIsQ0FBQyxDQUFDLE9BQU8sT0FBTyxnRUFBZ0UsQ0FBQyxDQUFDLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxPQUFPLFdBQVcsU0FBUztFQUN4TyxZQUFZLGFBQWEsa0JBQWtCLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxPQUFPLFdBQVcsR0FBRztDQUN2RixDQUFDLENBQ0ksT0FBTyxPQUFPLENBQUMsQ0FDZixLQUFLLEVBQUUsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLGlCQUFpQixDQUFDLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLE9BQU8sV0FBVyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLHdCQUF3QixDQUFDLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLE9BQU8sV0FBVyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLElBQUksQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLG1CQUFtQixDQUFDLENBQUMsT0FBTyxXQUFXLGlCQUFpQixDQUFDLENBQUMsT0FBTyxvQkFBb0IsSUFBSSxDQUFDLENBQUMsT0FBTyxvQkFBb0IsMEJBQTBCLENBQUMsQ0FBQyxPQUFPLFdBQVcscUJBQXFCLENBQUMsQ0FBQyxPQUFPLGVBQWUsV0FBVyxDQUFDLENBQUMsT0FBTyx3QkFBd0IsSUFBSSxDQUFDLENBQUMsT0FBTyxLQUFLLFlBQVk7QUFDL2tCO0FBQ0EsSUFBSSx1QkFBdUIsV0FBWTtDQUNuQyxJQUFJLFVBQVUsU0FBUyxTQUFTLEtBQUssYUFBQSxvQkFBMEIsS0FBSyxLQUFLLEVBQUU7Q0FDM0UsT0FBTyxTQUFTLE9BQU8sSUFBSSxVQUFVO0FBQ3pDO0FBQ0EsSUFBVyxtQkFBbUIsV0FBWTtDQUN0QyxhQUFNLFVBQVUsV0FBWTtFQUN4QixTQUFTLEtBQUssYUFBYSxnQkFBZ0IscUJBQXFCLElBQUksRUFBQSxDQUFHLFNBQVMsQ0FBQztFQUNqRixPQUFPLFdBQVk7R0FDZixJQUFJLGFBQWEscUJBQXFCLElBQUk7R0FDMUMsSUFBSSxjQUFjLEdBQ2QsU0FBUyxLQUFLLGdCQUFnQixhQUFhO1FBRzNDLFNBQVMsS0FBSyxhQUFhLGVBQWUsV0FBVyxTQUFTLENBQUM7RUFFdkU7Q0FDSixHQUFHLENBQUMsQ0FBQztBQUNUOzs7O0FBSUEsSUFBVyxrQkFBa0IsU0FBVSxJQUFJO0NBQ3ZDLElBQUksYUFBYSxHQUFHLFlBQVksY0FBYyxHQUFHLGFBQWEsS0FBSyxHQUFHLFNBQVMsVUFBVSxPQUFPLEtBQUssSUFBSSxXQUFXO0NBQ3BILGlCQUFpQjtDQU1qQixJQUFJLE1BQUEsYUFBWSxRQUFRLFdBQVk7RUFBRSxPQUFPLFlBQVksT0FBTztDQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUM7Q0FDL0UsT0FBQSxhQUFhLGNBQWMsT0FBTyxFQUFFLFFBQVEsVUFBVSxLQUFLLENBQUMsWUFBWSxTQUFTLENBQUMsY0FBYyxlQUFlLEVBQUUsRUFBRSxDQUFDO0FBQ3hIOzs7QUNwREEsSUFBSSxtQkFBbUI7QUFDdkIsSUFBSSxPQUFPLFdBQVcsYUFDbEIsSUFBSTtDQUNBLElBQUksVUFBVSxPQUFPLGVBQWUsQ0FBQyxHQUFHLFdBQVcsRUFDL0MsS0FBSyxXQUFZO0VBQ2IsbUJBQW1CO0VBQ25CLE9BQU87Q0FDWCxFQUNKLENBQUM7Q0FFRCxPQUFPLGlCQUFpQixRQUFRLFNBQVMsT0FBTztDQUVoRCxPQUFPLG9CQUFvQixRQUFRLFNBQVMsT0FBTztBQUN2RCxTQUNPLEtBQUs7Q0FDUixtQkFBbUI7QUFDdkI7QUFFSixJQUFXLGFBQWEsbUJBQW1CLEVBQUUsU0FBUyxNQUFNLElBQUk7OztBQ2xCaEUsSUFBSSx1QkFBdUIsU0FBVSxNQUFNO0NBRXZDLE9BQU8sS0FBSyxZQUFZO0FBQzVCO0FBQ0EsSUFBSSx1QkFBdUIsU0FBVSxNQUFNLFVBQVU7Q0FDakQsSUFBSSxFQUFFLGdCQUFnQixVQUNsQixPQUFPO0NBRVgsSUFBSSxTQUFTLE9BQU8saUJBQWlCLElBQUk7Q0FDekMsT0FFQSxPQUFPLGNBQWMsWUFFakIsRUFBRSxPQUFPLGNBQWMsT0FBTyxhQUFhLENBQUMscUJBQXFCLElBQUksS0FBSyxPQUFPLGNBQWM7QUFDdkc7QUFDQSxJQUFJLDBCQUEwQixTQUFVLE1BQU07Q0FBRSxPQUFPLHFCQUFxQixNQUFNLFdBQVc7QUFBRztBQUNoRyxJQUFJLDBCQUEwQixTQUFVLE1BQU07Q0FBRSxPQUFPLHFCQUFxQixNQUFNLFdBQVc7QUFBRztBQUNoRyxJQUFXLDBCQUEwQixTQUFVLE1BQU0sTUFBTTtDQUN2RCxJQUFJLGdCQUFnQixLQUFLO0NBQ3pCLElBQUksVUFBVTtDQUNkLEdBQUc7RUFFQyxJQUFJLE9BQU8sZUFBZSxlQUFlLG1CQUFtQixZQUN4RCxVQUFVLFFBQVE7RUFHdEIsSUFEbUIsdUJBQXVCLE1BQU0sT0FDakMsR0FBRztHQUNkLElBQUksS0FBSyxtQkFBbUIsTUFBTSxPQUFPO0dBQ3pDLElBRDJELEdBQUcsS0FBbUIsR0FBRyxJQUVoRixPQUFPO0VBRWY7RUFDQSxVQUFVLFFBQVE7Q0FDdEIsU0FBUyxXQUFXLFlBQVksY0FBYztDQUM5QyxPQUFPO0FBQ1g7QUFDQSxJQUFJLHNCQUFzQixTQUFVLElBQUk7Q0FFcEMsT0FBTztFQURTLEdBQUc7RUFBMEIsR0FBRztFQUE2QixHQUFHO0NBS2hGO0FBQ0o7QUFDQSxJQUFJLHNCQUFzQixTQUFVLElBQUk7Q0FFcEMsT0FBTztFQURVLEdBQUc7RUFBMEIsR0FBRztFQUEyQixHQUFHO0NBSy9FO0FBQ0o7QUFDQSxJQUFJLHlCQUF5QixTQUFVLE1BQU0sTUFBTTtDQUMvQyxPQUFPLFNBQVMsTUFBTSx3QkFBd0IsSUFBSSxJQUFJLHdCQUF3QixJQUFJO0FBQ3RGO0FBQ0EsSUFBSSxxQkFBcUIsU0FBVSxNQUFNLE1BQU07Q0FDM0MsT0FBTyxTQUFTLE1BQU0sb0JBQW9CLElBQUksSUFBSSxvQkFBb0IsSUFBSTtBQUM5RTtBQUNBLElBQUkscUJBQXFCLFNBQVUsTUFBTSxXQUFXOzs7Ozs7Q0FNaEQsT0FBTyxTQUFTLE9BQU8sY0FBYyxRQUFRLEtBQUs7QUFDdEQ7QUFDQSxJQUFXLGVBQWUsU0FBVSxNQUFNLFdBQVcsT0FBTyxhQUFhLGNBQWM7Q0FDbkYsSUFBSSxrQkFBa0IsbUJBQW1CLE1BQU0sT0FBTyxpQkFBaUIsU0FBUyxDQUFDLENBQUMsU0FBUztDQUMzRixJQUFJLFFBQVEsa0JBQWtCO0NBRTlCLElBQUksU0FBUyxNQUFNO0NBQ25CLElBQUksZUFBZSxVQUFVLFNBQVMsTUFBTTtDQUM1QyxJQUFJLHFCQUFxQjtDQUN6QixJQUFJLGtCQUFrQixRQUFRO0NBQzlCLElBQUksa0JBQWtCO0NBQ3RCLElBQUkscUJBQXFCO0NBQ3pCLEdBQUc7RUFDQyxJQUFJLENBQUMsUUFDRDtFQUVKLElBQUksS0FBSyxtQkFBbUIsTUFBTSxNQUFNLEdBQUcsV0FBVyxHQUFHO0VBQ3pELElBQUksZ0JBRG9FLEdBQUcsS0FBZSxHQUFHLEtBQ25ELGtCQUFrQjtFQUM1RCxJQUFJLFlBQVksZUFDUjtPQUFBLHVCQUF1QixNQUFNLE1BQU0sR0FBRztJQUN0QyxtQkFBbUI7SUFDbkIsc0JBQXNCO0dBQzFCOztFQUVKLElBQUksV0FBVyxPQUFPO0VBR3RCLFNBQVUsWUFBWSxTQUFTLGFBQWEsS0FBSyx5QkFBeUIsU0FBUyxPQUFPO0NBQzlGLFNBRUMsQ0FBQyxnQkFBZ0IsV0FBVyxTQUFTLFFBRWpDLGlCQUFpQixVQUFVLFNBQVMsTUFBTSxLQUFLLGNBQWM7Q0FFbEUsSUFBSSxvQkFDRSxnQkFBZ0IsS0FBSyxJQUFJLGVBQWUsSUFBSSxLQUFPLENBQUMsZ0JBQWdCLFFBQVEsa0JBQzlFLHFCQUFxQjtNQUVwQixJQUFJLENBQUMsb0JBQ0osZ0JBQWdCLEtBQUssSUFBSSxrQkFBa0IsSUFBSSxLQUFPLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxxQkFDbEYscUJBQXFCO0NBRXpCLE9BQU87QUFDWDs7O0FDckdBLElBQVcsYUFBYSxTQUFVLE9BQU87Q0FDckMsT0FBTyxvQkFBb0IsUUFBUSxDQUFDLE1BQU0sZUFBZSxFQUFFLENBQUMsU0FBUyxNQUFNLGVBQWUsRUFBRSxDQUFDLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUNqSDtBQUNBLElBQVcsYUFBYSxTQUFVLE9BQU87Q0FBRSxPQUFPLENBQUMsTUFBTSxRQUFRLE1BQU0sTUFBTTtBQUFHO0FBQ2hGLElBQUksYUFBYSxTQUFVLEtBQUs7Q0FDNUIsT0FBTyxPQUFPLGFBQWEsTUFBTSxJQUFJLFVBQVU7QUFDbkQ7QUFDQSxJQUFJLGVBQWUsU0FBVSxHQUFHLEdBQUc7Q0FBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUU7QUFBSTtBQUM1RSxJQUFJLGdCQUFnQixTQUFVLElBQUk7Q0FBRSxPQUFPLDRCQUE0QixPQUFPLElBQUksbURBQW1ELENBQUMsQ0FBQyxPQUFPLElBQUksMkJBQTJCO0FBQUc7QUFDaEwsSUFBSSxZQUFZO0FBQ2hCLElBQUksWUFBWSxDQUFDO0FBQ2pCLFNBQWdCLG9CQUFvQixPQUFPO0NBQ3ZDLElBQUkscUJBQUEsYUFBMkIsT0FBTyxDQUFDLENBQUM7Q0FDeEMsSUFBSSxnQkFBQSxhQUFzQixPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7Q0FDdkMsSUFBSSxhQUFBLGFBQW1CLE9BQU87Q0FDOUIsSUFBSSxLQUFBLGFBQVcsU0FBUyxXQUFXLENBQUMsQ0FBQztDQUNyQyxJQUFJLFFBQUEsYUFBYyxTQUFTLGNBQWMsQ0FBQyxDQUFDO0NBQzNDLElBQUksWUFBQSxhQUFrQixPQUFPLEtBQUs7Q0FDbEMsYUFBTSxVQUFVLFdBQVk7RUFDeEIsVUFBVSxVQUFVO0NBQ3hCLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FDVixhQUFNLFVBQVUsV0FBWTtFQUN4QixJQUFJLE1BQU0sT0FBTztHQUNiLFNBQVMsS0FBSyxVQUFVLElBQUksdUJBQXVCLE9BQU8sRUFBRSxDQUFDO0dBQzdELElBQUksVUFBVSxjQUFjLENBQUMsTUFBTSxRQUFRLE9BQU8sSUFBSSxNQUFNLFVBQVUsQ0FBQyxFQUFBLENBQUcsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLENBQUMsT0FBTyxPQUFPO0dBQy9HLFFBQVEsUUFBUSxTQUFVLElBQUk7SUFBRSxPQUFPLEdBQUcsVUFBVSxJQUFJLHVCQUF1QixPQUFPLEVBQUUsQ0FBQztHQUFHLENBQUM7R0FDN0YsT0FBTyxXQUFZO0lBQ2YsU0FBUyxLQUFLLFVBQVUsT0FBTyx1QkFBdUIsT0FBTyxFQUFFLENBQUM7SUFDaEUsUUFBUSxRQUFRLFNBQVUsSUFBSTtLQUFFLE9BQU8sR0FBRyxVQUFVLE9BQU8sdUJBQXVCLE9BQU8sRUFBRSxDQUFDO0lBQUcsQ0FBQztHQUNwRztFQUNKO0NBRUosR0FBRztFQUFDLE1BQU07RUFBTyxNQUFNLFFBQVE7RUFBUyxNQUFNO0NBQU0sQ0FBQztDQUNyRCxJQUFJLG9CQUFBLGFBQTBCLFlBQVksU0FBVSxPQUFPLFFBQVE7RUFDL0QsSUFBSyxhQUFhLFNBQVMsTUFBTSxRQUFRLFdBQVcsS0FBTyxNQUFNLFNBQVMsV0FBVyxNQUFNLFNBQ3ZGLE9BQU8sQ0FBQyxVQUFVLFFBQVE7RUFFOUIsSUFBSSxRQUFRLFdBQVcsS0FBSztFQUM1QixJQUFJLGFBQWEsY0FBYztFQUMvQixJQUFJLFNBQVMsWUFBWSxRQUFRLE1BQU0sU0FBUyxXQUFXLEtBQUssTUFBTTtFQUN0RSxJQUFJLFNBQVMsWUFBWSxRQUFRLE1BQU0sU0FBUyxXQUFXLEtBQUssTUFBTTtFQUN0RSxJQUFJO0VBQ0osSUFBSSxTQUFTLE1BQU07RUFDbkIsSUFBSSxnQkFBZ0IsS0FBSyxJQUFJLE1BQU0sSUFBSSxLQUFLLElBQUksTUFBTSxJQUFJLE1BQU07RUFFaEUsSUFBSSxhQUFhLFNBQVMsa0JBQWtCLE9BQU8sT0FBTyxTQUFTLFNBQy9ELE9BQU87RUFHWCxJQUFJLFlBQVksT0FBTyxhQUFhO0VBQ3BDLElBQUksYUFBYSxhQUFhLFVBQVU7RUFFeEMsSUFEMEIsYUFBYSxlQUFlLFVBQVUsV0FBVyxTQUFTLE1BQU0sSUFBSSxPQUUxRixPQUFPO0VBRVgsSUFBSSwrQkFBK0Isd0JBQXdCLGVBQWUsTUFBTTtFQUNoRixJQUFJLENBQUMsOEJBQ0QsT0FBTztFQUVYLElBQUksOEJBQ0EsY0FBYztPQUViO0dBQ0QsY0FBYyxrQkFBa0IsTUFBTSxNQUFNO0dBQzVDLCtCQUErQix3QkFBd0IsZUFBZSxNQUFNO0VBRWhGO0VBQ0EsSUFBSSxDQUFDLDhCQUNELE9BQU87RUFFWCxJQUFJLENBQUMsV0FBVyxXQUFXLG9CQUFvQixVQUFVLFVBQVUsU0FDL0QsV0FBVyxVQUFVO0VBRXpCLElBQUksQ0FBQyxhQUNELE9BQU87RUFFWCxJQUFJLGdCQUFnQixXQUFXLFdBQVc7RUFDMUMsT0FBTyxhQUFhLGVBQWUsUUFBUSxPQUFPLGtCQUFrQixNQUFNLFNBQVMsUUFBUSxJQUFJO0NBQ25HLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsSUFBSSxnQkFBQSxhQUFzQixZQUFZLFNBQVUsUUFBUTtFQUNwRCxJQUFJLFFBQVE7RUFDWixJQUFJLENBQUMsVUFBVSxVQUFVLFVBQVUsVUFBVSxTQUFTLE9BQU8sT0FFekQ7RUFFSixJQUFJLFFBQVEsWUFBWSxRQUFRLFdBQVcsS0FBSyxJQUFJLFdBQVcsS0FBSztFQUNwRSxJQUFJLGNBQWMsbUJBQW1CLFFBQVEsT0FBTyxTQUFVLEdBQUc7R0FBRSxPQUFPLEVBQUUsU0FBUyxNQUFNLFNBQVMsRUFBRSxXQUFXLE1BQU0sVUFBVSxNQUFNLFdBQVcsRUFBRSxpQkFBaUIsYUFBYSxFQUFFLE9BQU8sS0FBSztFQUFHLENBQUMsQ0FBQyxDQUFDO0VBRXRNLElBQUksZUFBZSxZQUFZLFFBQVE7R0FDbkMsSUFBSSxNQUFNLFlBQ04sTUFBTSxlQUFlO0dBRXpCO0VBQ0o7RUFFQSxJQUFJLENBQUMsYUFBYTtHQUNkLElBQUksY0FBYyxVQUFVLFFBQVEsVUFBVSxDQUFDLEVBQUEsQ0FDMUMsSUFBSSxVQUFVLENBQUMsQ0FDZixPQUFPLE9BQU8sQ0FBQyxDQUNmLE9BQU8sU0FBVSxNQUFNO0lBQUUsT0FBTyxLQUFLLFNBQVMsTUFBTSxNQUFNO0dBQUcsQ0FBQztHQUVuRSxJQURpQixXQUFXLFNBQVMsSUFBSSxrQkFBa0IsT0FBTyxXQUFXLEVBQUUsSUFBSSxDQUFDLFVBQVUsUUFBUSxhQUU5RjtRQUFBLE1BQU0sWUFDTixNQUFNLGVBQWU7R0FBQTtFQUdqQztDQUNKLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsSUFBSSxlQUFBLGFBQXFCLFlBQVksU0FBVSxNQUFNLE9BQU8sUUFBUSxRQUFRO0VBQ3hFLElBQUksUUFBUTtHQUFRO0dBQWE7R0FBZTtHQUFnQjtHQUFRLGNBQWMseUJBQXlCLE1BQU07RUFBRTtFQUN2SCxtQkFBbUIsUUFBUSxLQUFLLEtBQUs7RUFDckMsV0FBVyxXQUFZO0dBQ25CLG1CQUFtQixVQUFVLG1CQUFtQixRQUFRLE9BQU8sU0FBVSxHQUFHO0lBQUUsT0FBTyxNQUFNO0dBQU8sQ0FBQztFQUN2RyxHQUFHLENBQUM7Q0FDUixHQUFHLENBQUMsQ0FBQztDQUNMLElBQUksbUJBQUEsYUFBeUIsWUFBWSxTQUFVLE9BQU87RUFDdEQsY0FBYyxVQUFVLFdBQVcsS0FBSztFQUN4QyxXQUFXLFVBQVUsS0FBQTtDQUN6QixHQUFHLENBQUMsQ0FBQztDQUNMLElBQUksY0FBQSxhQUFvQixZQUFZLFNBQVUsT0FBTztFQUNqRCxhQUFhLE1BQU0sTUFBTSxXQUFXLEtBQUssR0FBRyxNQUFNLFFBQVEsa0JBQWtCLE9BQU8sTUFBTSxRQUFRLE9BQU8sQ0FBQztDQUM3RyxHQUFHLENBQUMsQ0FBQztDQUNMLElBQUksa0JBQUEsYUFBd0IsWUFBWSxTQUFVLE9BQU87RUFDckQsYUFBYSxNQUFNLE1BQU0sV0FBVyxLQUFLLEdBQUcsTUFBTSxRQUFRLGtCQUFrQixPQUFPLE1BQU0sUUFBUSxPQUFPLENBQUM7Q0FDN0csR0FBRyxDQUFDLENBQUM7Q0FDTCxhQUFNLFVBQVUsV0FBWTtFQUN4QixVQUFVLEtBQUssS0FBSztFQUNwQixNQUFNLGFBQWE7R0FDZixpQkFBaUI7R0FDakIsZ0JBQWdCO0dBQ2hCLG9CQUFvQjtFQUN4QixDQUFDO0VBQ0QsU0FBUyxpQkFBaUIsU0FBUyxlQUFlLFVBQVU7RUFDNUQsU0FBUyxpQkFBaUIsYUFBYSxlQUFlLFVBQVU7RUFDaEUsU0FBUyxpQkFBaUIsY0FBYyxrQkFBa0IsVUFBVTtFQUNwRSxPQUFPLFdBQVk7R0FDZixZQUFZLFVBQVUsT0FBTyxTQUFVLE1BQU07SUFBRSxPQUFPLFNBQVM7R0FBTyxDQUFDO0dBQ3ZFLFNBQVMsb0JBQW9CLFNBQVMsZUFBZSxVQUFVO0dBQy9ELFNBQVMsb0JBQW9CLGFBQWEsZUFBZSxVQUFVO0dBQ25FLFNBQVMsb0JBQW9CLGNBQWMsa0JBQWtCLFVBQVU7RUFDM0U7Q0FDSixHQUFHLENBQUMsQ0FBQztDQUNMLElBQUksa0JBQWtCLE1BQU0saUJBQWlCLFFBQVEsTUFBTTtDQUMzRCxPQUFBLGFBQWMsY0FBQSxhQUFvQixVQUFVLE1BQ3hDLFFBQUEsYUFBYyxjQUFjLE9BQU8sRUFBRSxRQUFRLGNBQWMsRUFBRSxFQUFFLENBQUMsSUFBSSxNQUNwRSxrQkFBQSxhQUF3QixjQUFjLGlCQUFpQjtFQUFFLFlBQVksTUFBTTtFQUFZLFNBQVMsTUFBTTtDQUFRLENBQUMsSUFBSSxJQUFJO0FBQy9IO0FBQ0EsU0FBUyx5QkFBeUIsTUFBTTtDQUNwQyxJQUFJLGVBQWU7Q0FDbkIsT0FBTyxTQUFTLE1BQU07RUFDbEIsSUFBSSxnQkFBZ0IsWUFBWTtHQUM1QixlQUFlLEtBQUs7R0FDcEIsT0FBTyxLQUFLO0VBQ2hCO0VBQ0EsT0FBTyxLQUFLO0NBQ2hCO0NBQ0EsT0FBTztBQUNYOzs7QUNoS0EsSUFBQSxrQkFBZSxjQUFjLFdBQVcsbUJBQW1COzs7QUNDM0QsSUFBSSxvQkFBQSxhQUEwQixXQUFXLFNBQVUsT0FBTyxLQUFLO0NBQUUsT0FBQSxhQUFjLGNBQWMsY0FBYyxTQUFTLENBQUMsR0FBRyxPQUFPO0VBQU87RUFBSyxTQUFTQztDQUFRLENBQUMsQ0FBQztBQUFJLENBQUM7QUFDbkssa0JBQWtCLGFBQWEsYUFBYTs7O0FDTDVDLElBQUksbUJBQW1CLFNBQVUsZ0JBQWdCO0NBQzdDLElBQUksT0FBTyxhQUFhLGFBQ3BCLE9BQU87Q0FHWCxRQURtQixNQUFNLFFBQVEsY0FBYyxJQUFJLGVBQWUsS0FBSyxlQUFBLENBQ25ELGNBQWM7QUFDdEM7QUFDQSxJQUFJLDZCQUFhLElBQUksUUFBUTtBQUM3QixJQUFJLG9DQUFvQixJQUFJLFFBQVE7QUFDcEMsSUFBSSxZQUFZLENBQUM7QUFDakIsSUFBSSxZQUFZO0FBQ2hCLElBQUksYUFBYSxTQUFVLE1BQU07Q0FDN0IsT0FBTyxTQUFTLEtBQUssUUFBUSxXQUFXLEtBQUssVUFBVTtBQUMzRDtBQUNBLElBQUksaUJBQWlCLFNBQVUsUUFBUSxTQUFTO0NBQzVDLE9BQU8sUUFDRixJQUFJLFNBQVUsUUFBUTtFQUN2QixJQUFJLE9BQU8sU0FBUyxNQUFNLEdBQ3RCLE9BQU87RUFFWCxJQUFJLGtCQUFrQixXQUFXLE1BQU07RUFDdkMsSUFBSSxtQkFBbUIsT0FBTyxTQUFTLGVBQWUsR0FDbEQsT0FBTztFQUVYLFFBQVEsTUFBTSxlQUFlLFFBQVEsMkJBQTJCLFFBQVEsaUJBQWlCO0VBQ3pGLE9BQU87Q0FDWCxDQUFDLENBQUMsQ0FDRyxPQUFPLFNBQVUsR0FBRztFQUFFLE9BQU8sUUFBUSxDQUFDO0NBQUcsQ0FBQztBQUNuRDs7Ozs7Ozs7O0FBU0EsSUFBSSx5QkFBeUIsU0FBVSxnQkFBZ0IsWUFBWSxZQUFZLGtCQUFrQjtDQUM3RixJQUFJLFVBQVUsZUFBZSxZQUFZLE1BQU0sUUFBUSxjQUFjLElBQUksaUJBQWlCLENBQUMsY0FBYyxDQUFDO0NBQzFHLElBQUksQ0FBQyxVQUFVLGFBQ1gsVUFBVSw4QkFBYyxJQUFJLFFBQVE7Q0FFeEMsSUFBSSxnQkFBZ0IsVUFBVTtDQUM5QixJQUFJLGNBQWMsQ0FBQztDQUNuQixJQUFJLGlDQUFpQixJQUFJLElBQUk7Q0FDN0IsSUFBSSxpQkFBaUIsSUFBSSxJQUFJLE9BQU87Q0FDcEMsSUFBSSxPQUFPLFNBQVUsSUFBSTtFQUNyQixJQUFJLENBQUMsTUFBTSxlQUFlLElBQUksRUFBRSxHQUM1QjtFQUVKLGVBQWUsSUFBSSxFQUFFO0VBQ3JCLEtBQUssR0FBRyxVQUFVO0NBQ3RCO0NBQ0EsUUFBUSxRQUFRLElBQUk7Q0FDcEIsSUFBSSxPQUFPLFNBQVUsUUFBUTtFQUN6QixJQUFJLENBQUMsVUFBVSxlQUFlLElBQUksTUFBTSxHQUNwQztFQUVKLE1BQU0sVUFBVSxRQUFRLEtBQUssT0FBTyxVQUFVLFNBQVUsTUFBTTtHQUMxRCxJQUFJLGVBQWUsSUFBSSxJQUFJLEdBQ3ZCLEtBQUssSUFBSTtRQUdULElBQUk7SUFDQSxJQUFJLE9BQU8sS0FBSyxhQUFhLGdCQUFnQjtJQUM3QyxJQUFJLGdCQUFnQixTQUFTLFFBQVEsU0FBUztJQUM5QyxJQUFJLGdCQUFnQixXQUFXLElBQUksSUFBSSxLQUFLLEtBQUs7SUFDakQsSUFBSSxlQUFlLGNBQWMsSUFBSSxJQUFJLEtBQUssS0FBSztJQUNuRCxXQUFXLElBQUksTUFBTSxZQUFZO0lBQ2pDLGNBQWMsSUFBSSxNQUFNLFdBQVc7SUFDbkMsWUFBWSxLQUFLLElBQUk7SUFDckIsSUFBSSxpQkFBaUIsS0FBSyxlQUN0QixrQkFBa0IsSUFBSSxNQUFNLElBQUk7SUFFcEMsSUFBSSxnQkFBZ0IsR0FDaEIsS0FBSyxhQUFhLFlBQVksTUFBTTtJQUV4QyxJQUFJLENBQUMsZUFDRCxLQUFLLGFBQWEsa0JBQWtCLE1BQU07R0FFbEQsU0FDTyxHQUFHO0lBQ04sUUFBUSxNQUFNLG1DQUFtQyxNQUFNLENBQUM7R0FDNUQ7RUFFUixDQUFDO0NBQ0w7Q0FDQSxLQUFLLFVBQVU7Q0FDZixlQUFlLE1BQU07Q0FDckI7Q0FDQSxPQUFPLFdBQVk7RUFDZixZQUFZLFFBQVEsU0FBVSxNQUFNO0dBQ2hDLElBQUksZUFBZSxXQUFXLElBQUksSUFBSSxJQUFJO0dBQzFDLElBQUksY0FBYyxjQUFjLElBQUksSUFBSSxJQUFJO0dBQzVDLFdBQVcsSUFBSSxNQUFNLFlBQVk7R0FDakMsY0FBYyxJQUFJLE1BQU0sV0FBVztHQUNuQyxJQUFJLENBQUMsY0FBYztJQUNmLElBQUksQ0FBQyxrQkFBa0IsSUFBSSxJQUFJLEdBQzNCLEtBQUssZ0JBQWdCLGdCQUFnQjtJQUV6QyxrQkFBa0IsT0FBTyxJQUFJO0dBQ2pDO0dBQ0EsSUFBSSxDQUFDLGFBQ0QsS0FBSyxnQkFBZ0IsVUFBVTtFQUV2QyxDQUFDO0VBQ0Q7RUFDQSxJQUFJLENBQUMsV0FBVztHQUVaLDZCQUFhLElBQUksUUFBUTtHQUN6Qiw2QkFBYSxJQUFJLFFBQVE7R0FDekIsb0NBQW9CLElBQUksUUFBUTtHQUNoQyxZQUFZLENBQUM7RUFDakI7Q0FDSjtBQUNKOzs7Ozs7OztBQVFBLElBQVcsYUFBYSxTQUFVLGdCQUFnQixZQUFZLFlBQVk7Q0FDdEUsSUFBSSxlQUFlLEtBQUssR0FBSyxhQUFhO0NBQzFDLElBQUksVUFBVSxNQUFNLEtBQUssTUFBTSxRQUFRLGNBQWMsSUFBSSxpQkFBaUIsQ0FBQyxjQUFjLENBQUM7Q0FDMUYsSUFBSSxtQkFBbUIsY0FBYyxpQkFBaUIsY0FBYztDQUNwRSxJQUFJLENBQUMsa0JBQ0QsT0FBTyxXQUFZO0VBQUUsT0FBTztDQUFNO0NBSXRDLFFBQVEsS0FBSyxNQUFNLFNBQVMsTUFBTSxLQUFLLGlCQUFpQixpQkFBaUIscUJBQXFCLENBQUMsQ0FBQztDQUNoRyxPQUFPLHVCQUF1QixTQUFTLGtCQUFrQixZQUFZLGFBQWE7QUFDdEY7OztBQ3JJQSxJQUFJLFlBQVksT0FBTztBQUN2QixJQUFJLFVBQVUsUUFBUSxVQUFVLFVBQVUsUUFBUSxRQUFRO0NBQUU7Q0FBTyxjQUFjO0FBQUssQ0FBQztBQXdCdkYsSUFBSSxjQUFjO0FBQ2xCLElBQUksQ0FBQyxxQkFBcUIscUJBQXFCLG1DQUFtQixXQUFXO0FBQzdFLElBQUksQ0FBQyxnQkFBZ0Isb0JBQW9CLG9CQUFvQixXQUFXO0FBQ3hFLElBQUksU0FBeUIsd0JBQVEsVUFBVTtDQUM3QyxNQUFNLEVBQ0osZUFDQSxVQUNBLE1BQU0sVUFDTixhQUNBLGNBQ0EsUUFBUSxTQUNOO0NBQ0osTUFBTSxhQUFBLGFBQW1CLE9BQU8sSUFBSTtDQUNwQyxNQUFNLGFBQUEsYUFBbUIsT0FBTyxJQUFJO0NBQ3BDLE1BQU0sRUFBRSxPQUFPLGFBQWEsVUFBVSxtQkFBbUIsNEJBQTRCO0NBQ3JGLE1BQU0sQ0FBQyxNQUFNLFdBQVcscUJBQXFCO0VBQzNDLE1BQU07RUFDTixhQUFhLGVBQWU7RUFDNUIsVUFBVTtFQUNWLFFBQVE7Q0FDVixDQUFDO0NBQ0QsTUFBTSxDQUFDLFlBQVksaUJBQUEsYUFBdUIsU0FBUyxDQUFDO0NBQ3BELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQUEsYUFBNkIsU0FBUyxDQUFDO0NBQ2hFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUNyQixnQkFDQTtFQUNFLE9BQU87RUFDUDtFQUNBO0VBQ0EsV0FBVyxNQUFNO0VBQ2pCLFNBQVMsTUFBTTtFQUNmLGVBQWUsTUFBTTtFQUNyQixjQUFjLGFBQWE7RUFDM0Isb0JBQW9CLG1CQUFtQjtFQUN2QztFQUNBO0VBQ0E7RUFDQSxjQUFjO0VBQ2QsY0FBQSxhQUFvQixrQkFBa0IsU0FBUyxhQUFhLENBQUMsUUFBUSxHQUFHLENBQUMsT0FBTyxDQUFDO0VBQ2pGO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FDRjtBQUNGLEdBQUcsUUFBUTtBQUNYLElBQUksZUFBZTtBQUNuQixJQUFJLGdCQUFnQyw2QkFBTSxXQUN4Qix1QkFBTyxTQUFTLGVBQWUsT0FBTyxjQUFjO0NBQ2xFLE1BQU0sRUFBRSxlQUFlLEdBQUcsaUJBQWlCO0NBQzNDLE1BQU0sVUFBVSxpQkFBaUIsY0FBYyxhQUFhO0NBQzVELE1BQU0scUJBQXFCLGdCQUFnQixjQUFjLFFBQVEsVUFBVTtDQUMzRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsVUFBVSxRQUNWO0VBQ0UsTUFBTTtFQUNOLGlCQUFpQjtFQUNqQixpQkFBaUIsUUFBUTtFQUN6QixpQkFBaUIsUUFBUSxPQUFPLFFBQVEsWUFBWSxLQUFLO0VBQ3pELGNBQWMsU0FBUyxRQUFRLElBQUk7RUFDbkMsR0FBRztFQUNILEtBQUs7RUFDTCxTQUFTLHFCQUFxQixNQUFNLFNBQVMsUUFBUSxZQUFZO0NBQ25FLENBQ0Y7QUFDRixHQUFHLGVBQWUsQ0FDcEI7QUFDQSxJQUFJLGNBQWM7QUFDbEIsSUFBSSxDQUFDLGdCQUFnQixvQkFBb0Isb0JBQW9CLGFBQWEsRUFDeEUsWUFBWSxLQUFLLEVBQ25CLENBQUM7QUFDRCxJQUFJLGVBQStCLHdCQUFRLFVBQVU7Q0FDbkQsTUFBTSxFQUFFLGVBQWUsWUFBWSxVQUFVLGNBQWM7Q0FDM0QsTUFBTSxVQUFVLGlCQUFpQixhQUFhLGFBQWE7Q0FDM0QsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksZ0JBQWdCO0VBQUUsT0FBTztFQUFlO0VBQVksVUFBQSxhQUFnQixTQUFTLElBQUksV0FBVyxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0dBQUUsU0FBUyxjQUFjLFFBQVE7R0FBTSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSUMsUUFBaUI7SUFBRSxTQUFTO0lBQU07SUFBVyxVQUFVO0dBQU0sQ0FBQztFQUFFLENBQUMsQ0FBQztDQUFFLENBQUM7QUFDM1MsR0FBRyxjQUFjO0FBQ2pCLElBQUksZUFBZTtBQUNuQixJQUFJLGdCQUFnQyw2QkFBTSxXQUN4Qix1QkFBTyxTQUFTLGVBQWUsT0FBTyxjQUFjO0NBQ2xFLE1BQU0sZ0JBQWdCLGlCQUFpQixjQUFjLE1BQU0sYUFBYTtDQUN4RSxNQUFNLEVBQUUsYUFBYSxjQUFjLFlBQVksR0FBRyxpQkFBaUI7Q0FDbkUsTUFBTSxVQUFVLGlCQUFpQixjQUFjLE1BQU0sYUFBYTtDQUNsRSxPQUFPLFFBQVEsUUFBd0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksVUFBVTtFQUFFLFNBQVMsY0FBYyxRQUFRO0VBQU0sVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksbUJBQW1CO0dBQUUsR0FBRztHQUFjLEtBQUs7RUFBYSxDQUFDO0NBQUUsQ0FBQyxJQUFJO0FBQzVMLEdBQUcsZUFBZSxDQUNwQjtBQUNBLElBQUksT0FBTyxXQUFXLDRCQUE0QjtBQUNsRCxJQUFJLG9CQUFvQyw2QkFBTSxXQUU1Qix1QkFBTyxTQUFTLG1CQUFtQixPQUFPLGNBQWM7Q0FDdEUsTUFBTSxFQUFFLGVBQWUsR0FBRyxpQkFBaUI7Q0FDM0MsTUFBTSxVQUFVLGlCQUFpQixjQUFjLGFBQWE7Q0FDNUQsTUFBTSw2QkFBNkIsMkJBQTJCO0NBQzlELE1BQU0sZUFBZSxnQkFBZ0IsY0FBYywwQkFBMEI7Q0FDN0UsT0FLa0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ2RDLG1CQUNBO0VBQ0UsSUFBSTtFQUNKLGdCQUFnQjtFQUNoQixRQUFBLGFBQWMsY0FDTixDQUFDLFFBQVEsWUFBWSxHQUFHLFFBQVEsWUFBWSxLQUFLLFVBQVUsRUFBRSxTQUFTLEtBQUssRUFBRSxDQUFDLEdBQ3BGLENBQUMsUUFBUSxZQUFZLFFBQVEsV0FBVyxDQUMxQztFQUNBLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUN4QixVQUFVLEtBQ1Y7R0FDRSxjQUFjLFNBQVMsUUFBUSxJQUFJO0dBQ25DLEdBQUc7R0FDSCxLQUFLO0dBQ0wsT0FBTztJQUFFLGVBQWU7SUFBUSxHQUFHLGFBQWE7R0FBTTtFQUN4RCxDQUNGO0NBQ0YsQ0FDRjtBQUVKLEdBQUcsbUJBQW1CLENBQ3hCO0FBQ0EsSUFBSSxlQUFlO0FBQ25CLElBQUksZ0JBQWdDLDZCQUFNLFdBQ3hCLHVCQUFPLFNBQVMsZUFBZSxPQUFPLGNBQWM7Q0FDbEUsTUFBTSxnQkFBZ0IsaUJBQWlCLGNBQWMsTUFBTSxhQUFhO0NBQ3hFLE1BQU0sRUFBRSxhQUFhLGNBQWMsWUFBWSxHQUFHLGlCQUFpQjtDQUNuRSxNQUFNLFVBQVUsaUJBQWlCLGNBQWMsTUFBTSxhQUFhO0NBQ2xFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVU7RUFBRSxTQUFTLGNBQWMsUUFBUTtFQUFNLFVBQVUsUUFBUSxRQUF3QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxvQkFBb0I7R0FBRSxHQUFHO0dBQWMsS0FBSztFQUFhLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksdUJBQXVCO0dBQUUsR0FBRztHQUFjLEtBQUs7RUFBYSxDQUFDO0NBQUUsQ0FBQztBQUM5USxHQUFHLGVBQWUsQ0FDcEI7QUFDQSxJQUFJLHFCQUFxQyw2QkFBTSxXQUU3Qix1QkFBTyxTQUFTLG9CQUFvQixPQUFPLGNBQWM7Q0FDdkUsTUFBTSxVQUFVLGlCQUFpQixjQUFjLE1BQU0sYUFBYTtDQUNsRSxNQUFNLGFBQUEsYUFBbUIsT0FBTyxJQUFJO0NBQ3BDLE1BQU0sZUFBZSxnQkFBZ0IsY0FBYyxRQUFRLFlBQVksVUFBVTtDQUNqRixhQUFNLGdCQUFnQjtFQUNwQixNQUFNLFVBQVUsV0FBVztFQUMzQixJQUFJLFNBQVMsT0FBTyxXQUFXLE9BQU87Q0FDeEMsR0FBRyxDQUFDLENBQUM7Q0FDTCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsbUJBQ0E7RUFDRSxHQUFHO0VBQ0gsS0FBSztFQUNMLFdBQVcsUUFBUTtFQUNuQiw2QkFBNkIsUUFBUTtFQUNyQyxrQkFBa0IscUJBQXFCLE1BQU0sbUJBQW1CLFVBQVU7R0FDeEUsTUFBTSxlQUFlO0dBQ3JCLFFBQVEsV0FBVyxTQUFTLE1BQU07RUFDcEMsQ0FBQztFQUNELHNCQUFzQixxQkFBcUIsTUFBTSx1QkFBdUIsVUFBVTtHQUNoRixNQUFNLGdCQUFnQixNQUFNLE9BQU87R0FDbkMsTUFBTSxnQkFBZ0IsY0FBYyxXQUFXLEtBQUssY0FBYyxZQUFZO0dBRTlFLElBRHFCLGNBQWMsV0FBVyxLQUFLLGVBQ2pDLE1BQU0sZUFBZTtFQUN6QyxDQUFDO0VBQ0QsZ0JBQWdCLHFCQUNkLE1BQU0saUJBQ0wsVUFBVSxNQUFNLGVBQWUsQ0FDbEM7Q0FDRixDQUNGO0FBQ0YsR0FBRyxvQkFBb0IsQ0FDekI7QUFDQSxJQUFJLHdCQUF3Qyw2QkFBTSxXQUVoQyx1QkFBTyxTQUFTLHVCQUF1QixPQUFPLGNBQWM7Q0FDMUUsTUFBTSxVQUFVLGlCQUFpQixjQUFjLE1BQU0sYUFBYTtDQUNsRSxNQUFNLDBCQUFBLGFBQWdDLE9BQU8sS0FBSztDQUNsRCxNQUFNLDJCQUFBLGFBQWlDLE9BQU8sS0FBSztDQUNuRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsbUJBQ0E7RUFDRSxHQUFHO0VBQ0gsS0FBSztFQUNMLFdBQVc7RUFDWCw2QkFBNkI7RUFDN0IsbUJBQW1CLFVBQVU7R0FDM0IsTUFBTSxtQkFBbUIsS0FBSztHQUM5QixJQUFJLENBQUMsTUFBTSxrQkFBa0I7SUFDM0IsSUFBSSxDQUFDLHdCQUF3QixTQUFTLFFBQVEsV0FBVyxTQUFTLE1BQU07SUFDeEUsTUFBTSxlQUFlO0dBQ3ZCO0dBQ0Esd0JBQXdCLFVBQVU7R0FDbEMseUJBQXlCLFVBQVU7RUFDckM7RUFDQSxvQkFBb0IsVUFBVTtHQUM1QixNQUFNLG9CQUFvQixLQUFLO0dBQy9CLElBQUksQ0FBQyxNQUFNLGtCQUFrQjtJQUMzQix3QkFBd0IsVUFBVTtJQUNsQyxJQUFJLE1BQU0sT0FBTyxjQUFjLFNBQVMsZUFDdEMseUJBQXlCLFVBQVU7R0FFdkM7R0FDQSxNQUFNLFNBQVMsTUFBTTtHQUVyQixJQUR3QixRQUFRLFdBQVcsU0FBUyxTQUFTLE1BQU0sR0FDOUMsTUFBTSxlQUFlO0dBQzFDLElBQUksTUFBTSxPQUFPLGNBQWMsU0FBUyxhQUFhLHlCQUF5QixTQUM1RSxNQUFNLGVBQWU7RUFFekI7Q0FDRixDQUNGO0FBQ0YsR0FBRyx1QkFBdUIsQ0FDNUI7QUFDQSxJQUFJLG9CQUFvQyw2QkFBTSxXQUU1Qix1QkFBTyxTQUFTLG1CQUFtQixPQUFPLGNBQWM7Q0FDdEUsTUFBTSxFQUNKLGVBQ0EsV0FDQSxpQkFDQSxrQkFDQSxvQkFBb0IsaUJBQ3BCLFVBQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sVUFBVSxpQkFBaUIsY0FBYyxhQUFhO0NBQzVELGVBQWU7Q0FDZixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSwwQkFBMEI7RUFBRSxVQUFVLFFBQVE7RUFBZ0IsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ2pILFlBQ0E7R0FDRSxTQUFTO0dBQ1QsTUFBTTtHQUNOLFNBQVM7R0FDVCxVQUFVLFFBQVE7R0FDbEIsa0JBQWtCO0dBQ2xCLG9CQUFvQjtHQUNwQixVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDeEIsa0JBQ0E7SUFDRSxNQUFNO0lBQ04sSUFBSSxRQUFRO0lBQ1osbUJBQW1CLFFBQVEsZUFBZSxRQUFRLFVBQVUsS0FBSztJQUNqRSxvQkFBb0IsUUFBUSxxQkFBcUIsc0JBQXNCLGlCQUFpQixRQUFRLGFBQWEsSUFBSTtJQUNqSCxjQUFjLFNBQVMsUUFBUSxJQUFJO0lBQ25DLEdBQUc7SUFDSCxLQUFLO0lBQ0wseUJBQXlCO0lBQ3pCLGlCQUFpQixRQUFRLGFBQWEsS0FBSztJQUMzQztHQUNGLENBQ0Y7RUFDRixDQUNGO0NBQUUsQ0FBQztBQUNMLEdBQUcsbUJBQW1CLENBQ3hCO0FBQ0EsSUFBSSxjQUE4Qiw2QkFBTSxXQUN0Qix1QkFBTyxTQUFTLGFBQWEsT0FBTyxjQUFjO0NBQ2hFLE1BQU0sRUFBRSxlQUFlLEdBQUcsZUFBZTtDQUN6QyxNQUFNLFVBQVUsaUJBQWlCLGVBQWUsYUFBYTtDQUM3RCxNQUFNLEVBQUUsa0JBQWtCO0NBQzFCLHVCQUFzQjtFQUNwQixlQUFlLFVBQVUsUUFBUSxDQUFDO0VBQ2xDLGFBQWEsZUFBZSxVQUFVLFFBQVEsQ0FBQztDQUNqRCxHQUFHLENBQUMsYUFBYSxDQUFDO0NBQ2xCLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVUsSUFBSTtFQUFFLElBQUksUUFBUTtFQUFTLEdBQUc7RUFBWSxLQUFLO0NBQWEsQ0FBQztBQUNwRyxHQUFHLGFBQWEsQ0FDbEI7QUFDQSxJQUFJLG9CQUFvQyw2QkFBTSxXQUU1Qix1QkFBTyxTQUFTLG1CQUFtQixPQUFPLGNBQWM7Q0FDdEUsTUFBTSxFQUFFLGVBQWUsR0FBRyxxQkFBcUI7Q0FDL0MsTUFBTSxVQUFVLGlCQUFpQixxQkFBcUIsYUFBYTtDQUNuRSxNQUFNLEVBQUUsd0JBQXdCO0NBQ2hDLHVCQUFzQjtFQUNwQixxQkFBcUIsVUFBVSxRQUFRLENBQUM7RUFDeEMsYUFBYSxxQkFBcUIsVUFBVSxRQUFRLENBQUM7Q0FDdkQsR0FBRyxDQUFDLG1CQUFtQixDQUFDO0NBQ3hCLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVUsR0FBRztFQUFFLElBQUksUUFBUTtFQUFlLEdBQUc7RUFBa0IsS0FBSztDQUFhLENBQUM7QUFDL0csR0FBRyxtQkFBbUIsQ0FDeEI7QUFDQSxJQUFJLGFBQWE7QUFDakIsSUFBSSxjQUE4Qiw2QkFBTSxXQUN0Qix1QkFBTyxTQUFTLGFBQWEsT0FBTyxjQUFjO0NBQ2hFLE1BQU0sRUFBRSxlQUFlLEdBQUcsZUFBZTtDQUN6QyxNQUFNLFVBQVUsaUJBQWlCLFlBQVksYUFBYTtDQUMxRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsVUFBVSxRQUNWO0VBQ0UsTUFBTTtFQUNOLEdBQUc7RUFDSCxLQUFLO0VBQ0wsU0FBUyxxQkFBcUIsTUFBTSxlQUFlLFFBQVEsYUFBYSxLQUFLLENBQUM7Q0FDaEYsQ0FDRjtBQUNGLEdBQUcsYUFBYSxDQUNsQjtBQUNBLElBQUksa0JBQWtDLHdCQUFRLFVBQVU7Q0FDdEQsT0FBTyxNQUFNO0FBQ2YsR0FBRyxpQkFBaUI7QUFDcEIsU0FBUyxzQkFBc0IsR0FBRyxRQUFRO0NBQ3hDLE1BQU0sc0JBQXNCLElBQUksSUFBSTtDQUNwQyxLQUFLLE1BQU0sU0FBUyxRQUFRO0VBQzFCLElBQUksT0FBTyxVQUFVLFVBQVU7RUFDL0IsS0FBSyxNQUFNLE1BQU0sT0FBTyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEtBQUssR0FDL0MsSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFO0NBRXRCO0NBQ0EsT0FBTyxJQUFJLE9BQU8sSUFBSSxNQUFNLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksS0FBSztBQUN6RDtBQUNBLE9BQU8sdUJBQXVCLHVCQUF1QjtBQUNyRCxTQUFTLFNBQVMsTUFBTTtDQUN0QixPQUFPLE9BQU8sU0FBUztBQUN6QjtBQUNBLE9BQU8sVUFBVSxVQUFVIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTUsMTYsMTcsMTgsMTksMjAsMjEsMjIsMjMsMjQsMjUsMjYsMjcsMjgsMjksMzAsMzEsMzIsMzNdfQ==