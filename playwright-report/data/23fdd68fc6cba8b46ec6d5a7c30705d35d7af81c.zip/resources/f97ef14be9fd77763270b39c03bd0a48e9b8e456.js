import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/mobile-nav.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Link, useRouter, useRouterState } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import { FigmaIcon } from "/src/components/ui/figma-icon.tsx";
import { cn } from "/src/lib/utils.ts";
import { useCartCount } from "/src/components/layout/header.tsx";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/mobile-nav.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
/** Tab bar inferior do layout mobile (fundo com recorte para o botão central). */
export function MobileTabBar() {
	_s();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const search = useRouterState({ select: (s) => s.location.search });
	const count = useCartCount();
	const favorites = pathname === "/profile" && search.section === "interesse";
	const tab = favorites ? "favorites" : pathname === "/cart" || pathname === "/checkout" ? "cart" : pathname === "/profile" || pathname === "/wallets" ? "profile" : pathname === "/" ? "home" : null;
	return /* @__PURE__ */ _jsxDEV("nav", {
		"aria-label": "Navegação principal",
		className: "fixed inset-x-0 bottom-0 z-40 h-[126px] md:hidden",
		children: [
			/* @__PURE__ */ _jsxDEV("img", {
				src: "/figma/m-tabbar-bg.svg",
				alt: "",
				"aria-hidden": true,
				className: "pointer-events-none absolute left-[-7.25%] top-[-9px] h-[155px] w-[114.5%] max-w-none"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Link, {
				to: "/",
				hash: "catalogo",
				"aria-label": "Explorar coleções",
				className: "absolute left-1/2 top-0 grid size-[65px] -translate-x-1/2 place-items-center rounded-full bg-[linear-gradient(180deg,rgba(210,138,76,0.4)_-17%,#d28a4c_109%)] text-foreground",
				children: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
					name: "m-tab-scan",
					width: 27,
					height: 24,
					original: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("ul", {
				className: "absolute inset-x-0 top-[61px] h-10",
				children: [
					/* @__PURE__ */ _jsxDEV(TabItem, {
						to: "/",
						label: "Início",
						active: tab === "home",
						icon: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
							name: "m-tab-home",
							width: 16,
							height: 17
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 40,
							columnNumber: 70
						}, this),
						className: "left-[calc(8.7%-10px)]"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(TabItem, {
						to: "/profile",
						search: { section: "interesse" },
						label: "Lista de interesse",
						active: tab === "favorites",
						icon: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
							name: "m-tab-heart",
							width: 20,
							height: 18
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 17
						}, this),
						className: "left-[calc(26.09%-10px)]"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(TabItem, {
						to: "/cart",
						label: count ? `Carrinho, ${count} ${count === 1 ? "item" : "itens"}` : "Carrinho",
						active: tab === "cart",
						icon: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
							name: "m-tab-shop",
							width: 20
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 17
						}, this),
						badge: count,
						className: "left-[calc(70.53%-10px)]"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(TabItem, {
						to: "/profile",
						label: "Perfil",
						active: tab === "profile",
						icon: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
							name: "m-tab-user",
							width: 20
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 80
						}, this),
						className: "left-[calc(85.51%-10px)]"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 5
	}, this);
}
_s(MobileTabBar, "IlzO9/DsT41KfqJQbmgKNi0VLck=", false, function() {
	return [
		useRouterState,
		useRouterState,
		useCartCount
	];
});
_c = MobileTabBar;
function TabItem({ to, search, label, icon, active, badge, className }) {
	return /* @__PURE__ */ _jsxDEV("li", {
		className: cn("absolute top-0", className),
		children: /* @__PURE__ */ _jsxDEV(Link, {
			to,
			search: search ?? {},
			"aria-label": label,
			"aria-current": active ? "page" : undefined,
			className: cn("relative grid size-10 place-items-center", active ? "text-accent" : "text-muted-foreground"),
			children: [icon, badge ? /* @__PURE__ */ _jsxDEV("span", {
				"data-testid": "cart-count",
				"aria-hidden": true,
				className: "absolute right-0.5 top-1 grid size-4 place-items-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground",
				children: badge > 99 ? "99+" : badge
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 91,
				columnNumber: 11
			}, this) : null]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 81,
		columnNumber: 5
	}, this);
}
_c2 = TabItem;
/** Cabeçalho das telas internas no mobile: voltar + título (Carrinho, Pagamento…). */
export function MobileScreenHeader({ title, className }) {
	_s2();
	const router = useRouter();
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn("flex h-11 items-start gap-3 md:hidden", className),
		children: [/* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			"aria-label": "Voltar",
			onClick: () => window.history.length > 1 ? router.history.back() : void router.navigate({ to: "/" }),
			className: "grid size-[35px] shrink-0 place-items-center rounded-full border border-border bg-surface-raised text-subtle",
			children: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
				name: "m-back-arrow",
				width: 13,
				height: 7,
				className: "rotate-90"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 115,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 109,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("h1", {
			className: "min-w-0 flex-1 whitespace-nowrap pr-2 pt-[9px] text-center text-xl font-bold leading-4 text-foreground",
			children: title
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 117,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 108,
		columnNumber: 5
	}, this);
}
_s2(MobileScreenHeader, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
	return [useRouter];
});
_c3 = MobileScreenHeader;
var _c, _c2, _c3;
$RefreshReg$(_c, "MobileTabBar");
$RefreshReg$(_c2, "TabItem");
$RefreshReg$(_c3, "MobileScreenHeader");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/mobile-nav.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/mobile-nav.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/mobile-nav.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/mobile-nav.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLFdBQVcsc0JBQXNCO0FBRWhELFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsVUFBVTtBQUNuQixTQUFTLG9CQUFvQjs7Ozs7QUFHN0IsT0FBTyxTQUFTLGVBQWU7O0NBQzdCLE1BQU0sV0FBVyxlQUFlLEVBQUUsU0FBUyxNQUFNLEVBQUUsU0FBUyxTQUFTLENBQUM7Q0FDdEUsTUFBTSxTQUFTLGVBQWUsRUFBRSxTQUFTLE1BQU0sRUFBRSxTQUFTLE9BQStCLENBQUM7Q0FDMUYsTUFBTSxRQUFRLGFBQWE7Q0FDM0IsTUFBTSxZQUFZLGFBQWEsY0FBYyxPQUFPLFlBQVk7Q0FDaEUsTUFBTSxNQUFNLFlBQ1IsY0FDQSxhQUFhLFdBQVcsYUFBYSxjQUNuQyxTQUNBLGFBQWEsY0FBYyxhQUFhLGFBQ3RDLFlBQ0EsYUFBYSxNQUNYLFNBQ0E7Q0FFVixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxjQUFXO0VBQXNCLFdBQVU7WUFBaEQ7R0FDRSx3QkFBQyxPQUFEO0lBQ0UsS0FBSTtJQUNKLEtBQUk7SUFDSjtJQUNBLFdBQVU7R0FDWDs7Ozs7R0FDRCx3QkFBQyxNQUFEO0lBQ0UsSUFBRztJQUNILE1BQUs7SUFDTCxjQUFXO0lBQ1gsV0FBVTtjQUVWLHdCQUFDLFdBQUQ7S0FBVyxNQUFLO0tBQWEsT0FBTztLQUFJLFFBQVE7S0FBSTtJQUFVOzs7OztHQUMxRDs7Ozs7R0FDTix3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFkO0tBQ0Usd0JBQUMsU0FBRDtNQUFTLElBQUc7TUFBSSxPQUFNO01BQVMsUUFBUSxRQUFRO01BQVEsTUFBTSx3QkFBQyxXQUFEO09BQVcsTUFBSztPQUFhLE9BQU87T0FBSSxRQUFRO01BQUs7Ozs7O01BQUcsV0FBVTtLQUEwQjs7Ozs7S0FDekosd0JBQUMsU0FBRDtNQUNFLElBQUc7TUFDSCxRQUFRLEVBQUUsU0FBUyxZQUFZO01BQy9CLE9BQU07TUFDTixRQUFRLFFBQVE7TUFDaEIsTUFBTSx3QkFBQyxXQUFEO09BQVcsTUFBSztPQUFjLE9BQU87T0FBSSxRQUFRO01BQUs7Ozs7O01BQzVELFdBQVU7S0FDWDs7Ozs7S0FDRCx3QkFBQyxTQUFEO01BQ0UsSUFBRztNQUNILE9BQU8sUUFBUSxhQUFhLE1BQU0sR0FBRyxVQUFVLElBQUksU0FBUyxZQUFZO01BQ3hFLFFBQVEsUUFBUTtNQUNoQixNQUFNLHdCQUFDLFdBQUQ7T0FBVyxNQUFLO09BQWEsT0FBTztNQUFLOzs7OztNQUMvQyxPQUFPO01BQ1AsV0FBVTtLQUNYOzs7OztLQUNELHdCQUFDLFNBQUQ7TUFBUyxJQUFHO01BQVcsT0FBTTtNQUFTLFFBQVEsUUFBUTtNQUFXLE1BQU0sd0JBQUMsV0FBRDtPQUFXLE1BQUs7T0FBYSxPQUFPO01BQUs7Ozs7O01BQUcsV0FBVTtLQUE0Qjs7Ozs7SUFDdko7Ozs7OztFQUNEOzs7Ozs7QUFFVDs7Ozs7Ozs7O0FBRUEsU0FBUyxRQUFRLEVBQ2YsSUFDQSxRQUNBLE9BQ0EsTUFDQSxRQUNBLE9BQ0EsYUFTQztDQUNELE9BQ0Usd0JBQUMsTUFBRDtFQUFJLFdBQVcsR0FBRyxrQkFBa0IsU0FBUztZQUMzQyx3QkFBQyxNQUFEO0dBQ007R0FDSixRQUFRLFVBQVUsQ0FBQztHQUNuQixjQUFZO0dBQ1osZ0JBQWMsU0FBUyxTQUFTO0dBQ2hDLFdBQVcsR0FBRyw0Q0FBNEMsU0FBUyxnQkFBZ0IsdUJBQXVCO2FBTDVHLENBT0csTUFDQSxRQUNDLHdCQUFDLFFBQUQ7SUFDRSxlQUFZO0lBQ1o7SUFDQSxXQUFVO2NBRVQsUUFBUSxLQUFLLFFBQVE7R0FDbEI7Ozs7Y0FDSixJQUNBOzs7Ozs7Q0FDSjs7Ozs7QUFFUjs7O0FBR0EsT0FBTyxTQUFTLG1CQUFtQixFQUFFLE9BQU8sYUFBb0Q7O0NBQzlGLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVcsR0FBRyx5Q0FBeUMsU0FBUztZQUFyRSxDQUNFLHdCQUFDLFVBQUQ7R0FDRSxNQUFLO0dBQ0wsY0FBVztHQUNYLGVBQWdCLE9BQU8sUUFBUSxTQUFTLElBQUksT0FBTyxRQUFRLEtBQUssSUFBSSxLQUFLLE9BQU8sU0FBUyxFQUFFLElBQUksSUFBSSxDQUFDO0dBQ3BHLFdBQVU7YUFFVix3QkFBQyxXQUFEO0lBQVcsTUFBSztJQUFlLE9BQU87SUFBSSxRQUFRO0lBQUcsV0FBVTtHQUFhOzs7OztFQUN0RTs7OztZQUNSLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQTBHO0VBQVU7Ozs7VUFDL0g7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm1vYmlsZS1uYXYudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIHVzZVJvdXRlciwgdXNlUm91dGVyU3RhdGUgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHR5cGUgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCB7IEZpZ21hSWNvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9maWdtYS1pY29uJ1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcbmltcG9ydCB7IHVzZUNhcnRDb3VudCB9IGZyb20gJy4vaGVhZGVyJ1xuXG4vKiogVGFiIGJhciBpbmZlcmlvciBkbyBsYXlvdXQgbW9iaWxlIChmdW5kbyBjb20gcmVjb3J0ZSBwYXJhIG8gYm90w6NvIGNlbnRyYWwpLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIE1vYmlsZVRhYkJhcigpIHtcbiAgY29uc3QgcGF0aG5hbWUgPSB1c2VSb3V0ZXJTdGF0ZSh7IHNlbGVjdDogKHMpID0+IHMubG9jYXRpb24ucGF0aG5hbWUgfSlcbiAgY29uc3Qgc2VhcmNoID0gdXNlUm91dGVyU3RhdGUoeyBzZWxlY3Q6IChzKSA9PiBzLmxvY2F0aW9uLnNlYXJjaCBhcyB7IHNlY3Rpb24/OiBzdHJpbmcgfSB9KVxuICBjb25zdCBjb3VudCA9IHVzZUNhcnRDb3VudCgpXG4gIGNvbnN0IGZhdm9yaXRlcyA9IHBhdGhuYW1lID09PSAnL3Byb2ZpbGUnICYmIHNlYXJjaC5zZWN0aW9uID09PSAnaW50ZXJlc3NlJ1xuICBjb25zdCB0YWIgPSBmYXZvcml0ZXNcbiAgICA/ICdmYXZvcml0ZXMnXG4gICAgOiBwYXRobmFtZSA9PT0gJy9jYXJ0JyB8fCBwYXRobmFtZSA9PT0gJy9jaGVja291dCdcbiAgICAgID8gJ2NhcnQnXG4gICAgICA6IHBhdGhuYW1lID09PSAnL3Byb2ZpbGUnIHx8IHBhdGhuYW1lID09PSAnL3dhbGxldHMnXG4gICAgICAgID8gJ3Byb2ZpbGUnXG4gICAgICAgIDogcGF0aG5hbWUgPT09ICcvJ1xuICAgICAgICAgID8gJ2hvbWUnXG4gICAgICAgICAgOiBudWxsXG5cbiAgcmV0dXJuIChcbiAgICA8bmF2IGFyaWEtbGFiZWw9XCJOYXZlZ2HDp8OjbyBwcmluY2lwYWxcIiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC14LTAgYm90dG9tLTAgei00MCBoLVsxMjZweF0gbWQ6aGlkZGVuXCI+XG4gICAgICA8aW1nXG4gICAgICAgIHNyYz1cIi9maWdtYS9tLXRhYmJhci1iZy5zdmdcIlxuICAgICAgICBhbHQ9XCJcIlxuICAgICAgICBhcmlhLWhpZGRlblxuICAgICAgICBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGxlZnQtWy03LjI1JV0gdG9wLVstOXB4XSBoLVsxNTVweF0gdy1bMTE0LjUlXSBtYXgtdy1ub25lXCJcbiAgICAgIC8+XG4gICAgICA8TGlua1xuICAgICAgICB0bz1cIi9cIlxuICAgICAgICBoYXNoPVwiY2F0YWxvZ29cIlxuICAgICAgICBhcmlhLWxhYmVsPVwiRXhwbG9yYXIgY29sZcOnw7Vlc1wiXG4gICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMS8yIHRvcC0wIGdyaWQgc2l6ZS1bNjVweF0gLXRyYW5zbGF0ZS14LTEvMiBwbGFjZS1pdGVtcy1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLVtsaW5lYXItZ3JhZGllbnQoMTgwZGVnLHJnYmEoMjEwLDEzOCw3NiwwLjQpXy0xNyUsI2QyOGE0Y18xMDklKV0gdGV4dC1mb3JlZ3JvdW5kXCJcbiAgICAgID5cbiAgICAgICAgPEZpZ21hSWNvbiBuYW1lPVwibS10YWItc2NhblwiIHdpZHRoPXsyN30gaGVpZ2h0PXsyNH0gb3JpZ2luYWwgLz5cbiAgICAgIDwvTGluaz5cbiAgICAgIDx1bCBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC14LTAgdG9wLVs2MXB4XSBoLTEwXCI+XG4gICAgICAgIDxUYWJJdGVtIHRvPVwiL1wiIGxhYmVsPVwiSW7DrWNpb1wiIGFjdGl2ZT17dGFiID09PSAnaG9tZSd9IGljb249ezxGaWdtYUljb24gbmFtZT1cIm0tdGFiLWhvbWVcIiB3aWR0aD17MTZ9IGhlaWdodD17MTd9IC8+fSBjbGFzc05hbWU9XCJsZWZ0LVtjYWxjKDguNyUtMTBweCldXCIgLz5cbiAgICAgICAgPFRhYkl0ZW1cbiAgICAgICAgICB0bz1cIi9wcm9maWxlXCJcbiAgICAgICAgICBzZWFyY2g9e3sgc2VjdGlvbjogJ2ludGVyZXNzZScgfX1cbiAgICAgICAgICBsYWJlbD1cIkxpc3RhIGRlIGludGVyZXNzZVwiXG4gICAgICAgICAgYWN0aXZlPXt0YWIgPT09ICdmYXZvcml0ZXMnfVxuICAgICAgICAgIGljb249ezxGaWdtYUljb24gbmFtZT1cIm0tdGFiLWhlYXJ0XCIgd2lkdGg9ezIwfSBoZWlnaHQ9ezE4fSAvPn1cbiAgICAgICAgICBjbGFzc05hbWU9XCJsZWZ0LVtjYWxjKDI2LjA5JS0xMHB4KV1cIlxuICAgICAgICAvPlxuICAgICAgICA8VGFiSXRlbVxuICAgICAgICAgIHRvPVwiL2NhcnRcIlxuICAgICAgICAgIGxhYmVsPXtjb3VudCA/IGBDYXJyaW5obywgJHtjb3VudH0gJHtjb3VudCA9PT0gMSA/ICdpdGVtJyA6ICdpdGVucyd9YCA6ICdDYXJyaW5obyd9XG4gICAgICAgICAgYWN0aXZlPXt0YWIgPT09ICdjYXJ0J31cbiAgICAgICAgICBpY29uPXs8RmlnbWFJY29uIG5hbWU9XCJtLXRhYi1zaG9wXCIgd2lkdGg9ezIwfSAvPn1cbiAgICAgICAgICBiYWRnZT17Y291bnR9XG4gICAgICAgICAgY2xhc3NOYW1lPVwibGVmdC1bY2FsYyg3MC41MyUtMTBweCldXCJcbiAgICAgICAgLz5cbiAgICAgICAgPFRhYkl0ZW0gdG89XCIvcHJvZmlsZVwiIGxhYmVsPVwiUGVyZmlsXCIgYWN0aXZlPXt0YWIgPT09ICdwcm9maWxlJ30gaWNvbj17PEZpZ21hSWNvbiBuYW1lPVwibS10YWItdXNlclwiIHdpZHRoPXsyMH0gLz59IGNsYXNzTmFtZT1cImxlZnQtW2NhbGMoODUuNTElLTEwcHgpXVwiIC8+XG4gICAgICA8L3VsPlxuICAgIDwvbmF2PlxuICApXG59XG5cbmZ1bmN0aW9uIFRhYkl0ZW0oe1xuICB0byxcbiAgc2VhcmNoLFxuICBsYWJlbCxcbiAgaWNvbixcbiAgYWN0aXZlLFxuICBiYWRnZSxcbiAgY2xhc3NOYW1lLFxufToge1xuICB0bzogJy8nIHwgJy9jYXJ0JyB8ICcvcHJvZmlsZSdcbiAgc2VhcmNoPzogeyBzZWN0aW9uOiAnaW50ZXJlc3NlJyB9XG4gIGxhYmVsOiBzdHJpbmdcbiAgaWNvbjogUmVhY3QuUmVhY3ROb2RlXG4gIGFjdGl2ZTogYm9vbGVhblxuICBiYWRnZT86IG51bWJlclxuICBjbGFzc05hbWU/OiBzdHJpbmdcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8bGkgY2xhc3NOYW1lPXtjbignYWJzb2x1dGUgdG9wLTAnLCBjbGFzc05hbWUpfT5cbiAgICAgIDxMaW5rXG4gICAgICAgIHRvPXt0b31cbiAgICAgICAgc2VhcmNoPXtzZWFyY2ggPz8ge319XG4gICAgICAgIGFyaWEtbGFiZWw9e2xhYmVsfVxuICAgICAgICBhcmlhLWN1cnJlbnQ9e2FjdGl2ZSA/ICdwYWdlJyA6IHVuZGVmaW5lZH1cbiAgICAgICAgY2xhc3NOYW1lPXtjbigncmVsYXRpdmUgZ3JpZCBzaXplLTEwIHBsYWNlLWl0ZW1zLWNlbnRlcicsIGFjdGl2ZSA/ICd0ZXh0LWFjY2VudCcgOiAndGV4dC1tdXRlZC1mb3JlZ3JvdW5kJyl9XG4gICAgICA+XG4gICAgICAgIHtpY29ufVxuICAgICAgICB7YmFkZ2UgPyAoXG4gICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiY2FydC1jb3VudFwiXG4gICAgICAgICAgICBhcmlhLWhpZGRlblxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMC41IHRvcC0xIGdyaWQgc2l6ZS00IHBsYWNlLWl0ZW1zLWNlbnRlciByb3VuZGVkLWZ1bGwgYmctcHJpbWFyeSB0ZXh0LVsxMHB4XSBmb250LW1lZGl1bSB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge2JhZGdlID4gOTkgPyAnOTkrJyA6IGJhZGdlfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKSA6IG51bGx9XG4gICAgICA8L0xpbms+XG4gICAgPC9saT5cbiAgKVxufVxuXG4vKiogQ2FiZcOnYWxobyBkYXMgdGVsYXMgaW50ZXJuYXMgbm8gbW9iaWxlOiB2b2x0YXIgKyB0w610dWxvIChDYXJyaW5obywgUGFnYW1lbnRv4oCmKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBNb2JpbGVTY3JlZW5IZWFkZXIoeyB0aXRsZSwgY2xhc3NOYW1lIH06IHsgdGl0bGU6IHN0cmluZzsgY2xhc3NOYW1lPzogc3RyaW5nIH0pIHtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17Y24oJ2ZsZXggaC0xMSBpdGVtcy1zdGFydCBnYXAtMyBtZDpoaWRkZW4nLCBjbGFzc05hbWUpfT5cbiAgICAgIDxidXR0b25cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIGFyaWEtbGFiZWw9XCJWb2x0YXJcIlxuICAgICAgICBvbkNsaWNrPXsoKSA9PiAod2luZG93Lmhpc3RvcnkubGVuZ3RoID4gMSA/IHJvdXRlci5oaXN0b3J5LmJhY2soKSA6IHZvaWQgcm91dGVyLm5hdmlnYXRlKHsgdG86ICcvJyB9KSl9XG4gICAgICAgIGNsYXNzTmFtZT1cImdyaWQgc2l6ZS1bMzVweF0gc2hyaW5rLTAgcGxhY2UtaXRlbXMtY2VudGVyIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1zdXJmYWNlLXJhaXNlZCB0ZXh0LXN1YnRsZVwiXG4gICAgICA+XG4gICAgICAgIDxGaWdtYUljb24gbmFtZT1cIm0tYmFjay1hcnJvd1wiIHdpZHRoPXsxM30gaGVpZ2h0PXs3fSBjbGFzc05hbWU9XCJyb3RhdGUtOTBcIiAvPlxuICAgICAgPC9idXR0b24+XG4gICAgICA8aDEgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTEgd2hpdGVzcGFjZS1ub3dyYXAgcHItMiBwdC1bOXB4XSB0ZXh0LWNlbnRlciB0ZXh0LXhsIGZvbnQtYm9sZCBsZWFkaW5nLTQgdGV4dC1mb3JlZ3JvdW5kXCI+e3RpdGxlfTwvaDE+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==