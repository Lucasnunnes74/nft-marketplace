import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/figma-icon.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/figma-icon.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
/**
* Ícone exportado do Figma (public/figma). Por padrão usa o SVG como máscara,
* então a cor vem de `currentColor` (estados ativo/hover sem duplicar arquivos).
* `original` mantém as cores do arquivo (logos multicoloridos, ilustrações).
*/
export function FigmaIcon({ name, width, height = width, original, className, style }) {
	const src = `/figma/${name}.svg`;
	if (original) {
		return /* @__PURE__ */ _jsxDEV("img", {
			src,
			alt: "",
			"aria-hidden": true,
			width,
			height,
			className: cn("shrink-0", className),
			style
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("span", {
		"aria-hidden": true,
		className: cn("inline-block shrink-0 bg-current", className),
		style: {
			width,
			height,
			maskImage: `url(${src})`,
			WebkitMaskImage: `url(${src})`,
			maskRepeat: "no-repeat",
			WebkitMaskRepeat: "no-repeat",
			maskSize: "100% 100%",
			WebkitMaskSize: "100% 100%",
			...style
		}
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 5
	}, this);
}
_c = FigmaIcon;
var _c;
$RefreshReg$(_c, "FigmaIcon");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/figma-icon.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/figma-icon.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/figma-icon.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/figma-icon.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxVQUFVOzs7Ozs7OztBQU9uQixPQUFPLFNBQVMsVUFBVSxFQUN4QixNQUNBLE9BQ0EsU0FBUyxPQUNULFVBQ0EsV0FDQSxTQVFDO0NBQ0QsTUFBTSxNQUFNLFVBQVUsS0FBSztDQUMzQixJQUFJLFVBQVU7RUFDWixPQUFPLHdCQUFDLE9BQUQ7R0FBVTtHQUFLLEtBQUk7R0FBRztHQUFtQjtHQUFlO0dBQVEsV0FBVyxHQUFHLFlBQVksU0FBUztHQUFVO0VBQVE7Ozs7O0NBQzlIO0NBQ0EsT0FDRSx3QkFBQyxRQUFEO0VBQ0U7RUFDQSxXQUFXLEdBQUcsb0NBQW9DLFNBQVM7RUFDM0QsT0FBTztHQUNMO0dBQ0E7R0FDQSxXQUFXLE9BQU8sSUFBSTtHQUN0QixpQkFBaUIsT0FBTyxJQUFJO0dBQzVCLFlBQVk7R0FDWixrQkFBa0I7R0FDbEIsVUFBVTtHQUNWLGdCQUFnQjtHQUNoQixHQUFHO0VBQ0w7Q0FDRDs7Ozs7QUFFTCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJmaWdtYS1pY29uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcblxuLyoqXG4gKiDDjWNvbmUgZXhwb3J0YWRvIGRvIEZpZ21hIChwdWJsaWMvZmlnbWEpLiBQb3IgcGFkcsOjbyB1c2EgbyBTVkcgY29tbyBtw6FzY2FyYSxcbiAqIGVudMOjbyBhIGNvciB2ZW0gZGUgYGN1cnJlbnRDb2xvcmAgKGVzdGFkb3MgYXRpdm8vaG92ZXIgc2VtIGR1cGxpY2FyIGFycXVpdm9zKS5cbiAqIGBvcmlnaW5hbGAgbWFudMOpbSBhcyBjb3JlcyBkbyBhcnF1aXZvIChsb2dvcyBtdWx0aWNvbG9yaWRvcywgaWx1c3RyYcOnw7VlcykuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBGaWdtYUljb24oe1xuICBuYW1lLFxuICB3aWR0aCxcbiAgaGVpZ2h0ID0gd2lkdGgsXG4gIG9yaWdpbmFsLFxuICBjbGFzc05hbWUsXG4gIHN0eWxlLFxufToge1xuICBuYW1lOiBzdHJpbmdcbiAgd2lkdGg6IG51bWJlclxuICBoZWlnaHQ/OiBudW1iZXJcbiAgb3JpZ2luYWw/OiBib29sZWFuXG4gIGNsYXNzTmFtZT86IHN0cmluZ1xuICBzdHlsZT86IFJlYWN0LkNTU1Byb3BlcnRpZXNcbn0pIHtcbiAgY29uc3Qgc3JjID0gYC9maWdtYS8ke25hbWV9LnN2Z2BcbiAgaWYgKG9yaWdpbmFsKSB7XG4gICAgcmV0dXJuIDxpbWcgc3JjPXtzcmN9IGFsdD1cIlwiIGFyaWEtaGlkZGVuIHdpZHRoPXt3aWR0aH0gaGVpZ2h0PXtoZWlnaHR9IGNsYXNzTmFtZT17Y24oJ3Nocmluay0wJywgY2xhc3NOYW1lKX0gc3R5bGU9e3N0eWxlfSAvPlxuICB9XG4gIHJldHVybiAoXG4gICAgPHNwYW5cbiAgICAgIGFyaWEtaGlkZGVuXG4gICAgICBjbGFzc05hbWU9e2NuKCdpbmxpbmUtYmxvY2sgc2hyaW5rLTAgYmctY3VycmVudCcsIGNsYXNzTmFtZSl9XG4gICAgICBzdHlsZT17e1xuICAgICAgICB3aWR0aCxcbiAgICAgICAgaGVpZ2h0LFxuICAgICAgICBtYXNrSW1hZ2U6IGB1cmwoJHtzcmN9KWAsXG4gICAgICAgIFdlYmtpdE1hc2tJbWFnZTogYHVybCgke3NyY30pYCxcbiAgICAgICAgbWFza1JlcGVhdDogJ25vLXJlcGVhdCcsXG4gICAgICAgIFdlYmtpdE1hc2tSZXBlYXQ6ICduby1yZXBlYXQnLFxuICAgICAgICBtYXNrU2l6ZTogJzEwMCUgMTAwJScsXG4gICAgICAgIFdlYmtpdE1hc2tTaXplOiAnMTAwJSAxMDAlJyxcbiAgICAgICAgLi4uc3R5bGUsXG4gICAgICB9fVxuICAgIC8+XG4gIClcbn1cbiJdfQ==