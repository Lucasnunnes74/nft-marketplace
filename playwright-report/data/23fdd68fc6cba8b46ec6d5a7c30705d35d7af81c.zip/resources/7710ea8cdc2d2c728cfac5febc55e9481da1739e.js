import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/realtime-bridge.tsx");const useEffect = __vite__cjsImport1_react["useEffect"];import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=5d4ac5a9";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { useSessionState } from "/src/auth/use-session.ts";
import { connectRealtime } from "/src/realtime/socket.ts";
var _s = $RefreshSig$();
/** Mantém uma única conexão Socket.IO por sessão; encerra listeners ao trocar de sessão/desmontar. */
export function RealtimeBridge() {
	_s();
	const qc = useQueryClient();
	const { session } = useSessionState();
	const token = session?.token ?? null;
	const userId = session?.userId ?? null;
	useEffect(() => {
		const dispose = connectRealtime(qc, {
			token,
			userId
		});
		return dispose;
	}, [
		qc,
		token,
		userId
	]);
	return null;
}
_s(RealtimeBridge, "cImNVHgwtf+8tZbZsDVVIJJboFE=", false, function() {
	return [useQueryClient, useSessionState];
});
_c = RealtimeBridge;
var _c;
$RefreshReg$(_c, "RealtimeBridge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/app/realtime-bridge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/app/realtime-bridge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/app/realtime-bridge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/app/realtime-bridge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyx1QkFBdUI7OztBQUdoQyxPQUFPLFNBQVMsaUJBQWlCOztDQUMvQixNQUFNLEtBQUssZUFBZTtDQUMxQixNQUFNLEVBQUUsWUFBWSxnQkFBZ0I7Q0FDcEMsTUFBTSxRQUFRLFNBQVMsU0FBUztDQUNoQyxNQUFNLFNBQVMsU0FBUyxVQUFVO0NBRWxDLGdCQUFnQjtFQUNkLE1BQU0sVUFBVSxnQkFBZ0IsSUFBSTtHQUFFO0dBQU87RUFBTyxDQUFDO0VBQ3JELE9BQU87Q0FDVCxHQUFHO0VBQUM7RUFBSTtFQUFPO0NBQU0sQ0FBQztDQUV0QixPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicmVhbHRpbWUtYnJpZGdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlU2Vzc2lvblN0YXRlIH0gZnJvbSAnQC9hdXRoL3VzZS1zZXNzaW9uJ1xuaW1wb3J0IHsgY29ubmVjdFJlYWx0aW1lIH0gZnJvbSAnQC9yZWFsdGltZS9zb2NrZXQnXG5cbi8qKiBNYW50w6ltIHVtYSDDum5pY2EgY29uZXjDo28gU29ja2V0LklPIHBvciBzZXNzw6NvOyBlbmNlcnJhIGxpc3RlbmVycyBhbyB0cm9jYXIgZGUgc2Vzc8Ojby9kZXNtb250YXIuICovXG5leHBvcnQgZnVuY3Rpb24gUmVhbHRpbWVCcmlkZ2UoKSB7XG4gIGNvbnN0IHFjID0gdXNlUXVlcnlDbGllbnQoKVxuICBjb25zdCB7IHNlc3Npb24gfSA9IHVzZVNlc3Npb25TdGF0ZSgpXG4gIGNvbnN0IHRva2VuID0gc2Vzc2lvbj8udG9rZW4gPz8gbnVsbFxuICBjb25zdCB1c2VySWQgPSBzZXNzaW9uPy51c2VySWQgPz8gbnVsbFxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgZGlzcG9zZSA9IGNvbm5lY3RSZWFsdGltZShxYywgeyB0b2tlbiwgdXNlcklkIH0pXG4gICAgcmV0dXJuIGRpc3Bvc2VcbiAgfSwgW3FjLCB0b2tlbiwgdXNlcklkXSlcblxuICByZXR1cm4gbnVsbFxufVxuIl19