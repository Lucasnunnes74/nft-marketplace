import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/select.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport1_react, 1);const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { ChevronDown } from "/node_modules/.vite/deps/lucide-react.js?v=b07c072a";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/select.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
/** Select nativo estilizado: acessível por padrão, teclado e leitores de tela sem custo extra. */
const Select = React.forwardRef(_c = ({ className, children, ...props }, ref) => /* @__PURE__ */ _jsxDEV("div", {
	className: "relative",
	children: [/* @__PURE__ */ _jsxDEV("select", {
		ref,
		className: cn("h-10 w-full appearance-none rounded-md border border-input bg-card pl-3 pr-9 text-sm disabled:opacity-50 aria-[invalid=true]:border-destructive", className),
		...props,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(ChevronDown, {
		"aria-hidden": true,
		className: "pointer-events-none absolute right-3 top-3 size-4 text-muted-foreground"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 7
	}, this)]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 8,
	columnNumber: 5
}, this));
_c2 = Select;
Select.displayName = "Select";
export { Select };
var _c, _c2;
$RefreshReg$(_c, "Select$React.forwardRef");
$RefreshReg$(_c2, "Select");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/select.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/select.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/select.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/select.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsWUFBWSxXQUFXO0FBQ3ZCLFNBQVMsVUFBVTs7OztBQUduQixNQUFNLFNBQVMsTUFBTSxpQkFDbEIsRUFBRSxXQUFXLFVBQVUsR0FBRyxTQUFTLFFBQ2xDLHdCQUFDLE9BQUQ7Q0FBSyxXQUFVO1dBQWYsQ0FDRSx3QkFBQyxVQUFEO0VBQ087RUFDTCxXQUFXLEdBQ1QsbUpBQ0EsU0FDRjtFQUNBLEdBQUk7RUFFSDtDQUNLOzs7O1dBQ1Isd0JBQUMsYUFBRDtFQUFhO0VBQVksV0FBVTtDQUEyRTs7OztTQUMzRzs7Ozs7UUFFVDs7QUFDQSxPQUFPLGNBQWM7QUFDckIsU0FBUyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzZWxlY3QudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENoZXZyb25Eb3duIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL3V0aWxzJ1xuXG4vKiogU2VsZWN0IG5hdGl2byBlc3RpbGl6YWRvOiBhY2Vzc8OtdmVsIHBvciBwYWRyw6NvLCB0ZWNsYWRvIGUgbGVpdG9yZXMgZGUgdGVsYSBzZW0gY3VzdG8gZXh0cmEuICovXG5jb25zdCBTZWxlY3QgPSBSZWFjdC5mb3J3YXJkUmVmPEhUTUxTZWxlY3RFbGVtZW50LCBSZWFjdC5TZWxlY3RIVE1MQXR0cmlidXRlczxIVE1MU2VsZWN0RWxlbWVudD4+KFxuICAoeyBjbGFzc05hbWUsIGNoaWxkcmVuLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICA8c2VsZWN0XG4gICAgICAgIHJlZj17cmVmfVxuICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICdoLTEwIHctZnVsbCBhcHBlYXJhbmNlLW5vbmUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWlucHV0IGJnLWNhcmQgcGwtMyBwci05IHRleHQtc20gZGlzYWJsZWQ6b3BhY2l0eS01MCBhcmlhLVtpbnZhbGlkPXRydWVdOmJvcmRlci1kZXN0cnVjdGl2ZScsXG4gICAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgICApfVxuICAgICAgICB7Li4ucHJvcHN9XG4gICAgICA+XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDwvc2VsZWN0PlxuICAgICAgPENoZXZyb25Eb3duIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgYWJzb2x1dGUgcmlnaHQtMyB0b3AtMyBzaXplLTQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICA8L2Rpdj5cbiAgKSxcbilcblNlbGVjdC5kaXNwbGF5TmFtZSA9ICdTZWxlY3QnXG5leHBvcnQgeyBTZWxlY3QgfVxuIl19