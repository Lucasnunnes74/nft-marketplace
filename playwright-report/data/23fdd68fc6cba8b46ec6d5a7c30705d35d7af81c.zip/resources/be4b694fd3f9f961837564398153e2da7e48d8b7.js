import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/nft/quantity-stepper.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { FigmaIcon } from "/src/components/ui/figma-icon.tsx";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/quantity-stepper.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
const variants = {
	/** Detalhe desktop: círculos de 33px, número 20px. */
	round: {
		gap: "gap-3",
		button: "size-[33px] rounded-full border border-background bg-primary shadow-[0_6.6px_9.9px_rgba(20,13,10,0.15)]",
		icon: 26,
		value: "min-w-3 text-xl leading-7"
	},
	/** Carrinho desktop e detalhe mobile: pílula 20×30. */
	pill: {
		gap: "gap-3",
		button: "h-[30px] w-5 rounded-[20px] border border-background bg-primary shadow-[0_4px_6px_rgba(20,13,10,0.15)]",
		icon: 16,
		value: "min-w-3 text-[17px] leading-6"
	},
	/** Carrinho mobile: círculos de 24px com contorno. */
	outline: {
		gap: "gap-3",
		button: "size-6 rounded-full border border-border bg-surface-raised text-foreground",
		icon: 0,
		value: "min-w-3 text-base leading-[22px]"
	}
};
export function QuantityStepper({ value, min = 1, max, onChange, disabled, label, variant = "pill", className }) {
	const v = variants[variant];
	const decDisabled = disabled || value <= min;
	const incDisabled = disabled || value >= max;
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "group",
		"aria-label": label,
		className: cn("inline-flex items-center", v.gap, className),
		children: [
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				"aria-label": "Diminuir quantidade",
				disabled: decDisabled,
				onClick: () => onChange(value - 1),
				className: cn("grid shrink-0 cursor-pointer place-items-center text-primary-foreground transition-opacity disabled:cursor-not-allowed disabled:opacity-40", v.button),
				children: variant === "outline" ? /* @__PURE__ */ _jsxDEV("span", {
					"aria-hidden": true,
					className: cn("h-0.5 w-[9px] rounded", decDisabled ? "bg-border-soft" : "bg-foreground")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV(FigmaIcon, {
					name: variant === "round" ? "icon-minus" : "icon-minus-sm",
					width: v.icon
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("output", {
				"aria-live": "polite",
				"aria-label": `${label}: ${value}`,
				className: cn("text-center tabular-nums text-foreground", v.value),
				children: value
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				"aria-label": "Aumentar quantidade",
				disabled: incDisabled,
				onClick: () => onChange(value + 1),
				className: cn("grid shrink-0 cursor-pointer place-items-center text-primary-foreground transition-opacity disabled:cursor-not-allowed disabled:opacity-40", v.button),
				children: variant === "outline" ? /* @__PURE__ */ _jsxDEV("span", {
					"aria-hidden": true,
					className: "text-[21px] leading-4",
					children: "+"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV(FigmaIcon, {
					name: variant === "round" ? "icon-plus" : "icon-plus-sm",
					width: v.icon
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 51,
		columnNumber: 5
	}, this);
}
_c = QuantityStepper;
var _c;
$RefreshReg$(_c, "QuantityStepper");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/nft/quantity-stepper.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/quantity-stepper.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/quantity-stepper.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/quantity-stepper.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxVQUFVOzs7QUFFbkIsTUFBTSxXQUFXOztDQUVmLE9BQU87RUFDTCxLQUFLO0VBQ0wsUUFBUTtFQUNSLE1BQU07RUFDTixPQUFPO0NBQ1Q7O0NBRUEsTUFBTTtFQUNKLEtBQUs7RUFDTCxRQUFRO0VBQ1IsTUFBTTtFQUNOLE9BQU87Q0FDVDs7Q0FFQSxTQUFTO0VBQ1AsS0FBSztFQUNMLFFBQVE7RUFDUixNQUFNO0VBQ04sT0FBTztDQUNUO0FBQ0Y7QUFFQSxPQUFPLFNBQVMsZ0JBQWdCLEVBQzlCLE9BQ0EsTUFBTSxHQUNOLEtBQ0EsVUFDQSxVQUNBLE9BQ0EsVUFBVSxRQUNWLGFBVUM7Q0FDRCxNQUFNLElBQUksU0FBUztDQUNuQixNQUFNLGNBQWMsWUFBWSxTQUFTO0NBQ3pDLE1BQU0sY0FBYyxZQUFZLFNBQVM7Q0FDekMsT0FDRSx3QkFBQyxPQUFEO0VBQUssTUFBSztFQUFRLGNBQVk7RUFBTyxXQUFXLEdBQUcsNEJBQTRCLEVBQUUsS0FBSyxTQUFTO1lBQS9GO0dBQ0Usd0JBQUMsVUFBRDtJQUNFLE1BQUs7SUFDTCxjQUFXO0lBQ1gsVUFBVTtJQUNWLGVBQWUsU0FBUyxRQUFRLENBQUM7SUFDakMsV0FBVyxHQUFHLDhJQUE4SSxFQUFFLE1BQU07Y0FFbkssWUFBWSxZQUNYLHdCQUFDLFFBQUQ7S0FBTTtLQUFZLFdBQVcsR0FBRyx5QkFBeUIsY0FBYyxtQkFBbUIsZUFBZTtJQUFJOzs7O2VBRTdHLHdCQUFDLFdBQUQ7S0FBVyxNQUFNLFlBQVksVUFBVSxlQUFlO0tBQWlCLE9BQU8sRUFBRTtJQUFPOzs7OztHQUVuRjs7Ozs7R0FDUix3QkFBQyxVQUFEO0lBQVEsYUFBVTtJQUFTLGNBQVksR0FBRyxNQUFNLElBQUk7SUFBUyxXQUFXLEdBQUcsNENBQTRDLEVBQUUsS0FBSztjQUMzSDtHQUNLOzs7OztHQUNSLHdCQUFDLFVBQUQ7SUFDRSxNQUFLO0lBQ0wsY0FBVztJQUNYLFVBQVU7SUFDVixlQUFlLFNBQVMsUUFBUSxDQUFDO0lBQ2pDLFdBQVcsR0FBRyw4SUFBOEksRUFBRSxNQUFNO2NBRW5LLFlBQVksWUFDWCx3QkFBQyxRQUFEO0tBQU07S0FBWSxXQUFVO2VBQXdCO0lBRTlDOzs7O2VBRU4sd0JBQUMsV0FBRDtLQUFXLE1BQU0sWUFBWSxVQUFVLGNBQWM7S0FBZ0IsT0FBTyxFQUFFO0lBQU87Ozs7O0dBRWpGOzs7OztFQUNMOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJxdWFudGl0eS1zdGVwcGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGaWdtYUljb24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvZmlnbWEtaWNvbidcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnXG5cbmNvbnN0IHZhcmlhbnRzID0ge1xuICAvKiogRGV0YWxoZSBkZXNrdG9wOiBjw61yY3Vsb3MgZGUgMzNweCwgbsO6bWVybyAyMHB4LiAqL1xuICByb3VuZDoge1xuICAgIGdhcDogJ2dhcC0zJyxcbiAgICBidXR0b246ICdzaXplLVszM3B4XSByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1iYWNrZ3JvdW5kIGJnLXByaW1hcnkgc2hhZG93LVswXzYuNnB4XzkuOXB4X3JnYmEoMjAsMTMsMTAsMC4xNSldJyxcbiAgICBpY29uOiAyNixcbiAgICB2YWx1ZTogJ21pbi13LTMgdGV4dC14bCBsZWFkaW5nLTcnLFxuICB9LFxuICAvKiogQ2FycmluaG8gZGVza3RvcCBlIGRldGFsaGUgbW9iaWxlOiBww61sdWxhIDIww5czMC4gKi9cbiAgcGlsbDoge1xuICAgIGdhcDogJ2dhcC0zJyxcbiAgICBidXR0b246ICdoLVszMHB4XSB3LTUgcm91bmRlZC1bMjBweF0gYm9yZGVyIGJvcmRlci1iYWNrZ3JvdW5kIGJnLXByaW1hcnkgc2hhZG93LVswXzRweF82cHhfcmdiYSgyMCwxMywxMCwwLjE1KV0nLFxuICAgIGljb246IDE2LFxuICAgIHZhbHVlOiAnbWluLXctMyB0ZXh0LVsxN3B4XSBsZWFkaW5nLTYnLFxuICB9LFxuICAvKiogQ2FycmluaG8gbW9iaWxlOiBjw61yY3Vsb3MgZGUgMjRweCBjb20gY29udG9ybm8uICovXG4gIG91dGxpbmU6IHtcbiAgICBnYXA6ICdnYXAtMycsXG4gICAgYnV0dG9uOiAnc2l6ZS02IHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1zdXJmYWNlLXJhaXNlZCB0ZXh0LWZvcmVncm91bmQnLFxuICAgIGljb246IDAsXG4gICAgdmFsdWU6ICdtaW4tdy0zIHRleHQtYmFzZSBsZWFkaW5nLVsyMnB4XScsXG4gIH0sXG59IGFzIGNvbnN0XG5cbmV4cG9ydCBmdW5jdGlvbiBRdWFudGl0eVN0ZXBwZXIoe1xuICB2YWx1ZSxcbiAgbWluID0gMSxcbiAgbWF4LFxuICBvbkNoYW5nZSxcbiAgZGlzYWJsZWQsXG4gIGxhYmVsLFxuICB2YXJpYW50ID0gJ3BpbGwnLFxuICBjbGFzc05hbWUsXG59OiB7XG4gIHZhbHVlOiBudW1iZXJcbiAgbWluPzogbnVtYmVyXG4gIG1heDogbnVtYmVyXG4gIG9uQ2hhbmdlOiAobmV4dDogbnVtYmVyKSA9PiB2b2lkXG4gIGRpc2FibGVkPzogYm9vbGVhblxuICBsYWJlbDogc3RyaW5nXG4gIHZhcmlhbnQ/OiBrZXlvZiB0eXBlb2YgdmFyaWFudHNcbiAgY2xhc3NOYW1lPzogc3RyaW5nXG59KSB7XG4gIGNvbnN0IHYgPSB2YXJpYW50c1t2YXJpYW50XVxuICBjb25zdCBkZWNEaXNhYmxlZCA9IGRpc2FibGVkIHx8IHZhbHVlIDw9IG1pblxuICBjb25zdCBpbmNEaXNhYmxlZCA9IGRpc2FibGVkIHx8IHZhbHVlID49IG1heFxuICByZXR1cm4gKFxuICAgIDxkaXYgcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD17bGFiZWx9IGNsYXNzTmFtZT17Y24oJ2lubGluZS1mbGV4IGl0ZW1zLWNlbnRlcicsIHYuZ2FwLCBjbGFzc05hbWUpfT5cbiAgICAgIDxidXR0b25cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIGFyaWEtbGFiZWw9XCJEaW1pbnVpciBxdWFudGlkYWRlXCJcbiAgICAgICAgZGlzYWJsZWQ9e2RlY0Rpc2FibGVkfVxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkNoYW5nZSh2YWx1ZSAtIDEpfVxuICAgICAgICBjbGFzc05hbWU9e2NuKCdncmlkIHNocmluay0wIGN1cnNvci1wb2ludGVyIHBsYWNlLWl0ZW1zLWNlbnRlciB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCB0cmFuc2l0aW9uLW9wYWNpdHkgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIGRpc2FibGVkOm9wYWNpdHktNDAnLCB2LmJ1dHRvbil9XG4gICAgICA+XG4gICAgICAgIHt2YXJpYW50ID09PSAnb3V0bGluZScgPyAoXG4gICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW4gY2xhc3NOYW1lPXtjbignaC0wLjUgdy1bOXB4XSByb3VuZGVkJywgZGVjRGlzYWJsZWQgPyAnYmctYm9yZGVyLXNvZnQnIDogJ2JnLWZvcmVncm91bmQnKX0gLz5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8RmlnbWFJY29uIG5hbWU9e3ZhcmlhbnQgPT09ICdyb3VuZCcgPyAnaWNvbi1taW51cycgOiAnaWNvbi1taW51cy1zbSd9IHdpZHRoPXt2Lmljb259IC8+XG4gICAgICAgICl9XG4gICAgICA8L2J1dHRvbj5cbiAgICAgIDxvdXRwdXQgYXJpYS1saXZlPVwicG9saXRlXCIgYXJpYS1sYWJlbD17YCR7bGFiZWx9OiAke3ZhbHVlfWB9IGNsYXNzTmFtZT17Y24oJ3RleHQtY2VudGVyIHRhYnVsYXItbnVtcyB0ZXh0LWZvcmVncm91bmQnLCB2LnZhbHVlKX0+XG4gICAgICAgIHt2YWx1ZX1cbiAgICAgIDwvb3V0cHV0PlxuICAgICAgPGJ1dHRvblxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgYXJpYS1sYWJlbD1cIkF1bWVudGFyIHF1YW50aWRhZGVcIlxuICAgICAgICBkaXNhYmxlZD17aW5jRGlzYWJsZWR9XG4gICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKHZhbHVlICsgMSl9XG4gICAgICAgIGNsYXNzTmFtZT17Y24oJ2dyaWQgc2hyaW5rLTAgY3Vyc29yLXBvaW50ZXIgcGxhY2UtaXRlbXMtY2VudGVyIHRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kIHRyYW5zaXRpb24tb3BhY2l0eSBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6b3BhY2l0eS00MCcsIHYuYnV0dG9uKX1cbiAgICAgID5cbiAgICAgICAge3ZhcmlhbnQgPT09ICdvdXRsaW5lJyA/IChcbiAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbiBjbGFzc05hbWU9XCJ0ZXh0LVsyMXB4XSBsZWFkaW5nLTRcIj5cbiAgICAgICAgICAgICtcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPEZpZ21hSWNvbiBuYW1lPXt2YXJpYW50ID09PSAncm91bmQnID8gJ2ljb24tcGx1cycgOiAnaWNvbi1wbHVzLXNtJ30gd2lkdGg9e3YuaWNvbn0gLz5cbiAgICAgICAgKX1cbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=