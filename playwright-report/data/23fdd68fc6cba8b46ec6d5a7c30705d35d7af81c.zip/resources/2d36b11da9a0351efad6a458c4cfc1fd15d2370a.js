import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/form-field.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport0_react, 1);const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { cn } from "/src/lib/utils.ts";
import { FigmaIcon } from "/src/components/ui/figma-icon.tsx";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/form-field.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$();
function Label({ id, label, required, hideLabel }) {
	return /* @__PURE__ */ _jsxDEV("label", {
		htmlFor: id,
		className: cn("k-label min-h-[29px] gap-0.5", hideLabel && "sr-only"),
		children: [
			label,
			required ? /* @__PURE__ */ _jsxDEV("span", {
				className: "k-required",
				"aria-hidden": true,
				children: "*"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 9
			}, this) : null,
			required ? /* @__PURE__ */ _jsxDEV("span", {
				className: "sr-only",
				children: " (obrigatório)"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 19
			}, this) : null
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
}
_c = Label;
function Message({ id, error, hint }) {
	if (error) {
		return /* @__PURE__ */ _jsxDEV("p", {
			id: `${id}-error`,
			role: "alert",
			className: "mt-1 text-xs text-coral",
			children: error
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this);
	}
	if (hint) {
		return /* @__PURE__ */ _jsxDEV("p", {
			id: `${id}-hint`,
			className: "mt-1 text-xs text-subtle",
			children: hint
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this);
	}
	return null;
}
_c2 = Message;
const describedBy = (id, error, hint) => error ? `${id}-error` : hint ? `${id}-hint` : undefined;
/** Campo de formulário do layout: rótulo 15px com asterisco coral, caixa 40px com borda #3F2319. */
export const FormField = React.forwardRef(_c3 = ({ id, label, required, error, hint, hideLabel, className, ...input }, ref) => /* @__PURE__ */ _jsxDEV("div", {
	className: cn("flex flex-col", hideLabel && "justify-end"),
	children: [
		/* @__PURE__ */ _jsxDEV(Label, {
			id,
			label,
			required,
			hideLabel
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 54,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("input", {
			ref,
			id,
			"aria-invalid": Boolean(error),
			"aria-required": required || undefined,
			"aria-describedby": describedBy(id, error, hint),
			className: cn("k-input", className),
			...input
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Message, {
			id,
			error,
			hint
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 7
		}, this)
	]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 53,
	columnNumber: 5
}, this));
_c4 = FormField;
FormField.displayName = "FormField";
export const SelectField = React.forwardRef(_c5 = ({ id, label, required, error, hint, hideLabel, className, children, ...select }, ref) => /* @__PURE__ */ _jsxDEV("div", {
	className: "flex flex-col",
	children: [
		/* @__PURE__ */ _jsxDEV(Label, {
			id,
			label,
			required,
			hideLabel
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 73,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "relative",
			children: [/* @__PURE__ */ _jsxDEV("select", {
				ref,
				id,
				"aria-invalid": Boolean(error),
				"aria-required": required || undefined,
				"aria-describedby": describedBy(id, error, hint),
				className: cn("k-input cursor-pointer appearance-none pr-9 [&>option]:bg-card", className),
				...select,
				children
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(FigmaIcon, {
				name: "icon-select-arrow",
				width: 18,
				className: "pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-subtle"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Message, {
			id,
			error,
			hint
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 88,
			columnNumber: 7
		}, this)
	]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 72,
	columnNumber: 5
}, this));
_c6 = SelectField;
SelectField.displayName = "SelectField";
/** Senha com botão de mostrar/ocultar (ícone "Hide" do layout). */
export const PasswordField = _s(React.forwardRef(_c7 = _s(({ id, label, required, error, hint, hideLabel, className, inputClassName, ...input }, ref) => {
	_s();
	const [visible, setVisible] = React.useState(false);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn("flex flex-col", className),
		children: [
			/* @__PURE__ */ _jsxDEV(Label, {
				id,
				label,
				required,
				hideLabel
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "relative",
				children: [/* @__PURE__ */ _jsxDEV("input", {
					ref,
					id,
					type: visible ? "text" : "password",
					"aria-invalid": Boolean(error),
					"aria-required": required || undefined,
					"aria-describedby": describedBy(id, error, hint),
					className: cn("k-input pr-11", inputClassName),
					...input
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					"aria-pressed": visible,
					"aria-controls": id,
					title: visible ? "Ocultar caracteres" : "Mostrar caracteres",
					onClick: () => setVisible((v) => !v),
					className: "absolute right-3 top-1/2 grid size-7 -translate-y-1/2 place-items-center text-subtle hover:text-accent",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "sr-only",
						children: visible ? "Ocultar caracteres" : "Mostrar caracteres"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 122,
						columnNumber: 11
					}, this), visible ? /* @__PURE__ */ _jsxDEV(EyeOpen, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 22
					}, this) : /* @__PURE__ */ _jsxDEV(FigmaIcon, {
						name: "icon-hide-outline",
						width: 17,
						height: 14
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 36
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 114,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 103,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Message, {
				id,
				error,
				hint
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 126,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 101,
		columnNumber: 5
	}, this);
}, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=")), "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c8 = PasswordField;
PasswordField.displayName = "PasswordField";
function EyeOpen() {
	return /* @__PURE__ */ _jsxDEV("svg", {
		"aria-hidden": true,
		width: "18",
		height: "14",
		viewBox: "0 0 18 14",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.4",
		children: [/* @__PURE__ */ _jsxDEV("path", { d: "M1 7s3-5.5 8-5.5S17 7 17 7s-3 5.5-8 5.5S1 7 1 7Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 135,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("circle", {
			cx: "9",
			cy: "7",
			r: "2.4"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 136,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 134,
		columnNumber: 5
	}, this);
}
_c9 = EyeOpen;
/** "Nome ENS": domínio .eth (78px) + nome. */
export const EnsField = React.forwardRef(_c10 = ({ id, error, ...input }, ref) => /* @__PURE__ */ _jsxDEV("div", {
	className: "flex flex-col",
	children: [
		/* @__PURE__ */ _jsxDEV("label", {
			htmlFor: id,
			className: "k-label min-h-[29px]",
			children: "Nome ENS"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 145,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "flex gap-2.5",
			children: [
				/* @__PURE__ */ _jsxDEV("span", {
					"aria-hidden": true,
					className: "flex h-10 w-[78px] shrink-0 items-center gap-1.5 rounded-[3px] border border-border pl-2.5 text-[15px] text-foreground",
					children: [".eth", /* @__PURE__ */ _jsxDEV(FigmaIcon, {
						name: "icon-arrow-down",
						width: 20
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					ref,
					id,
					"aria-invalid": Boolean(error),
					"aria-describedby": error ? `${id}-error` : `${id}-suffix`,
					className: "k-input",
					placeholder: "seu-nome",
					...input
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 153,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					id: `${id}-suffix`,
					className: "sr-only",
					children: "Domínio .eth"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 162,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 148,
			columnNumber: 7
		}, this),
		error ? /* @__PURE__ */ _jsxDEV("p", {
			id: `${id}-error`,
			role: "alert",
			className: "mt-1 text-xs text-coral",
			children: error
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 167,
			columnNumber: 9
		}, this) : null
	]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 144,
	columnNumber: 5
}, this));
_c11 = EnsField;
EnsField.displayName = "EnsField";
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
$RefreshReg$(_c, "Label");
$RefreshReg$(_c2, "Message");
$RefreshReg$(_c3, "FormField$React.forwardRef");
$RefreshReg$(_c4, "FormField");
$RefreshReg$(_c5, "SelectField$React.forwardRef");
$RefreshReg$(_c6, "SelectField");
$RefreshReg$(_c7, "PasswordField$React.forwardRef");
$RefreshReg$(_c8, "PasswordField");
$RefreshReg$(_c9, "EyeOpen");
$RefreshReg$(_c10, "EnsField$React.forwardRef");
$RefreshReg$(_c11, "EnsField");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/form-field.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/form-field.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/form-field.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/form-field.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsWUFBWSxXQUFXO0FBQ3ZCLFNBQVMsVUFBVTtBQUNuQixTQUFTLGlCQUFpQjs7OztBQWExQixTQUFTLE1BQU0sRUFBRSxJQUFJLE9BQU8sVUFBVSxhQUFzRTtDQUMxRyxPQUNFLHdCQUFDLFNBQUQ7RUFBTyxTQUFTO0VBQUksV0FBVyxHQUFHLGdDQUFnQyxhQUFhLFNBQVM7WUFBeEY7R0FDRztHQUNBLFdBQ0Msd0JBQUMsUUFBRDtJQUFNLFdBQVU7SUFBYTtjQUFZO0dBRW5DOzs7O2NBQ0o7R0FDSCxXQUFXLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQVU7R0FBb0I7Ozs7Y0FBSTtFQUN6RDs7Ozs7O0FBRVg7O0FBRUEsU0FBUyxRQUFRLEVBQUUsSUFBSSxPQUFPLFFBQStDO0NBQzNFLElBQUksT0FBTztFQUNULE9BQ0Usd0JBQUMsS0FBRDtHQUFHLElBQUksR0FBRyxHQUFHO0dBQVMsTUFBSztHQUFRLFdBQVU7YUFDMUM7RUFDQTs7Ozs7Q0FFUDtDQUNBLElBQUksTUFBTTtFQUNSLE9BQ0Usd0JBQUMsS0FBRDtHQUFHLElBQUksR0FBRyxHQUFHO0dBQVEsV0FBVTthQUM1QjtFQUNBOzs7OztDQUVQO0NBQ0EsT0FBTztBQUNUOztBQUVBLE1BQU0sZUFBZSxJQUFZLE9BQWdCLFNBQW1CLFFBQVEsR0FBRyxHQUFHLFVBQVUsT0FBTyxHQUFHLEdBQUcsU0FBUzs7QUFHbEgsT0FBTyxNQUFNLFlBQVksTUFBTSxrQkFDNUIsRUFBRSxJQUFJLE9BQU8sVUFBVSxPQUFPLE1BQU0sV0FBVyxXQUFXLEdBQUcsU0FBUyxRQUNyRSx3QkFBQyxPQUFEO0NBQUssV0FBVyxHQUFHLGlCQUFpQixhQUFhLGFBQWE7V0FBOUQ7RUFDRSx3QkFBQyxPQUFEO0dBQVc7R0FBVztHQUFpQjtHQUFxQjtFQUFZOzs7OztFQUN4RSx3QkFBQyxTQUFEO0dBQ087R0FDRDtHQUNKLGdCQUFjLFFBQVEsS0FBSztHQUMzQixpQkFBZSxZQUFZO0dBQzNCLG9CQUFrQixZQUFZLElBQUksT0FBTyxJQUFJO0dBQzdDLFdBQVcsR0FBRyxXQUFXLFNBQVM7R0FDbEMsR0FBSTtFQUNMOzs7OztFQUNELHdCQUFDLFNBQUQ7R0FBYTtHQUFXO0dBQWE7RUFBTzs7Ozs7Q0FDekM7Ozs7O1FBRVQ7O0FBQ0EsVUFBVSxjQUFjO0FBRXhCLE9BQU8sTUFBTSxjQUFjLE1BQU0sa0JBQzlCLEVBQUUsSUFBSSxPQUFPLFVBQVUsT0FBTyxNQUFNLFdBQVcsV0FBVyxVQUFVLEdBQUcsVUFBVSxRQUNoRix3QkFBQyxPQUFEO0NBQUssV0FBVTtXQUFmO0VBQ0Usd0JBQUMsT0FBRDtHQUFXO0dBQVc7R0FBaUI7R0FBcUI7RUFBWTs7Ozs7RUFDeEUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLFVBQUQ7SUFDTztJQUNEO0lBQ0osZ0JBQWMsUUFBUSxLQUFLO0lBQzNCLGlCQUFlLFlBQVk7SUFDM0Isb0JBQWtCLFlBQVksSUFBSSxPQUFPLElBQUk7SUFDN0MsV0FBVyxHQUFHLGtFQUFrRSxTQUFTO0lBQ3pGLEdBQUk7SUFFSDtHQUNLOzs7O2FBQ1Isd0JBQUMsV0FBRDtJQUFXLE1BQUs7SUFBb0IsT0FBTztJQUFJLFdBQVU7R0FBNkU7Ozs7V0FDbkk7Ozs7OztFQUNMLHdCQUFDLFNBQUQ7R0FBYTtHQUFXO0dBQWE7RUFBTzs7Ozs7Q0FDekM7Ozs7O1FBRVQ7O0FBQ0EsWUFBWSxjQUFjOztBQUcxQixPQUFPLE1BQU0sbUJBQWdCLE1BQU0scUJBR2hDLEVBQUUsSUFBSSxPQUFPLFVBQVUsT0FBTyxNQUFNLFdBQVcsV0FBVyxnQkFBZ0IsR0FBRyxTQUFTLFFBQVE7O0NBQy9GLE1BQU0sQ0FBQyxTQUFTLGNBQWMsTUFBTSxTQUFTLEtBQUs7Q0FDbEQsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVyxHQUFHLGlCQUFpQixTQUFTO1lBQTdDO0dBQ0Usd0JBQUMsT0FBRDtJQUFXO0lBQVc7SUFBaUI7SUFBcUI7R0FBWTs7Ozs7R0FDeEUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFNBQUQ7S0FDTztLQUNEO0tBQ0osTUFBTSxVQUFVLFNBQVM7S0FDekIsZ0JBQWMsUUFBUSxLQUFLO0tBQzNCLGlCQUFlLFlBQVk7S0FDM0Isb0JBQWtCLFlBQVksSUFBSSxPQUFPLElBQUk7S0FDN0MsV0FBVyxHQUFHLGlCQUFpQixjQUFjO0tBQzdDLEdBQUk7SUFDTDs7OztjQUNELHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsZ0JBQWM7S0FDZCxpQkFBZTtLQUNmLE9BQU8sVUFBVSx1QkFBdUI7S0FDeEMsZUFBZSxZQUFZLE1BQU0sQ0FBQyxDQUFDO0tBQ25DLFdBQVU7ZUFOWixDQVFFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFXLFVBQVUsdUJBQXVCO0tBQTJCOzs7O2VBQ3RGLFVBQVUsd0JBQUMsU0FBRCxDQUFVOzs7O2dCQUFJLHdCQUFDLFdBQUQ7TUFBVyxNQUFLO01BQW9CLE9BQU87TUFBSSxRQUFRO0tBQUs7Ozs7YUFDL0U7Ozs7O1lBQ0w7Ozs7OztHQUNMLHdCQUFDLFNBQUQ7SUFBYTtJQUFXO0lBQWE7R0FBTzs7Ozs7RUFDekM7Ozs7OztBQUVULGtDQUFDOztBQUNELGNBQWMsY0FBYztBQUU1QixTQUFTLFVBQVU7Q0FDakIsT0FDRSx3QkFBQyxPQUFEO0VBQUs7RUFBWSxPQUFNO0VBQUssUUFBTztFQUFLLFNBQVE7RUFBWSxNQUFLO0VBQU8sUUFBTztFQUFlLGFBQVk7WUFBMUcsQ0FDRSx3QkFBQyxRQUFELEVBQU0sR0FBRSxtREFBb0Q7Ozs7WUFDNUQsd0JBQUMsVUFBRDtHQUFRLElBQUc7R0FBSSxJQUFHO0dBQUksR0FBRTtFQUFPOzs7O1VBQzVCOzs7Ozs7QUFFVDs7O0FBR0EsT0FBTyxNQUFNLFdBQVcsTUFBTSxtQkFDM0IsRUFBRSxJQUFJLE9BQU8sR0FBRyxTQUFTLFFBQ3hCLHdCQUFDLE9BQUQ7Q0FBSyxXQUFVO1dBQWY7RUFDRSx3QkFBQyxTQUFEO0dBQU8sU0FBUztHQUFJLFdBQVU7YUFBdUI7RUFFOUM7Ozs7O0VBQ1Asd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLFFBQUQ7S0FBTTtLQUFZLFdBQVU7ZUFBNUIsQ0FBcUosUUFFbkosd0JBQUMsV0FBRDtNQUFXLE1BQUs7TUFBa0IsT0FBTztLQUFLOzs7O2FBQzFDOzs7Ozs7SUFDTix3QkFBQyxTQUFEO0tBQ087S0FDRDtLQUNKLGdCQUFjLFFBQVEsS0FBSztLQUMzQixvQkFBa0IsUUFBUSxHQUFHLEdBQUcsVUFBVSxHQUFHLEdBQUc7S0FDaEQsV0FBVTtLQUNWLGFBQVk7S0FDWixHQUFJO0lBQ0w7Ozs7O0lBQ0Qsd0JBQUMsUUFBRDtLQUFNLElBQUksR0FBRyxHQUFHO0tBQVUsV0FBVTtlQUFVO0lBRXhDOzs7OztHQUNIOzs7Ozs7RUFDSixRQUNDLHdCQUFDLEtBQUQ7R0FBRyxJQUFJLEdBQUcsR0FBRztHQUFTLE1BQUs7R0FBUSxXQUFVO2FBQzFDO0VBQ0E7Ozs7YUFDRDtDQUNEOzs7OztRQUVUOztBQUNBLFNBQVMsY0FBYyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJmb3JtLWZpZWxkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnXG5pbXBvcnQgeyBGaWdtYUljb24gfSBmcm9tICcuL2ZpZ21hLWljb24nXG5cbnR5cGUgQ29tbW9uID0ge1xuICBpZDogc3RyaW5nXG4gIGxhYmVsOiBzdHJpbmdcbiAgcmVxdWlyZWQ/OiBib29sZWFuXG4gIGVycm9yPzogc3RyaW5nXG4gIGhpbnQ/OiBzdHJpbmdcbiAgLyoqIFLDs3R1bG8gc8OzIHBhcmEgbGVpdG9yZXMgZGUgdGVsYSAoY2FtcG9zIHF1ZSBubyBsYXlvdXQgdXNhbSBhcGVuYXMgcGxhY2Vob2xkZXIpLiAqL1xuICBoaWRlTGFiZWw/OiBib29sZWFuXG4gIGNsYXNzTmFtZT86IHN0cmluZ1xufVxuXG5mdW5jdGlvbiBMYWJlbCh7IGlkLCBsYWJlbCwgcmVxdWlyZWQsIGhpZGVMYWJlbCB9OiBQaWNrPENvbW1vbiwgJ2lkJyB8ICdsYWJlbCcgfCAncmVxdWlyZWQnIHwgJ2hpZGVMYWJlbCc+KSB7XG4gIHJldHVybiAoXG4gICAgPGxhYmVsIGh0bWxGb3I9e2lkfSBjbGFzc05hbWU9e2NuKCdrLWxhYmVsIG1pbi1oLVsyOXB4XSBnYXAtMC41JywgaGlkZUxhYmVsICYmICdzci1vbmx5Jyl9PlxuICAgICAge2xhYmVsfVxuICAgICAge3JlcXVpcmVkID8gKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJrLXJlcXVpcmVkXCIgYXJpYS1oaWRkZW4+XG4gICAgICAgICAgKlxuICAgICAgICA8L3NwYW4+XG4gICAgICApIDogbnVsbH1cbiAgICAgIHtyZXF1aXJlZCA/IDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj4gKG9icmlnYXTDs3Jpbyk8L3NwYW4+IDogbnVsbH1cbiAgICA8L2xhYmVsPlxuICApXG59XG5cbmZ1bmN0aW9uIE1lc3NhZ2UoeyBpZCwgZXJyb3IsIGhpbnQgfTogUGljazxDb21tb24sICdpZCcgfCAnZXJyb3InIHwgJ2hpbnQnPikge1xuICBpZiAoZXJyb3IpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPHAgaWQ9e2Ake2lkfS1lcnJvcmB9IHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWNvcmFsXCI+XG4gICAgICAgIHtlcnJvcn1cbiAgICAgIDwvcD5cbiAgICApXG4gIH1cbiAgaWYgKGhpbnQpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPHAgaWQ9e2Ake2lkfS1oaW50YH0gY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtc3VidGxlXCI+XG4gICAgICAgIHtoaW50fVxuICAgICAgPC9wPlxuICAgIClcbiAgfVxuICByZXR1cm4gbnVsbFxufVxuXG5jb25zdCBkZXNjcmliZWRCeSA9IChpZDogc3RyaW5nLCBlcnJvcj86IHN0cmluZywgaGludD86IHN0cmluZykgPT4gKGVycm9yID8gYCR7aWR9LWVycm9yYCA6IGhpbnQgPyBgJHtpZH0taGludGAgOiB1bmRlZmluZWQpXG5cbi8qKiBDYW1wbyBkZSBmb3JtdWzDoXJpbyBkbyBsYXlvdXQ6IHLDs3R1bG8gMTVweCBjb20gYXN0ZXJpc2NvIGNvcmFsLCBjYWl4YSA0MHB4IGNvbSBib3JkYSAjM0YyMzE5LiAqL1xuZXhwb3J0IGNvbnN0IEZvcm1GaWVsZCA9IFJlYWN0LmZvcndhcmRSZWY8SFRNTElucHV0RWxlbWVudCwgQ29tbW9uICYgUmVhY3QuSW5wdXRIVE1MQXR0cmlidXRlczxIVE1MSW5wdXRFbGVtZW50Pj4oXG4gICh7IGlkLCBsYWJlbCwgcmVxdWlyZWQsIGVycm9yLCBoaW50LCBoaWRlTGFiZWwsIGNsYXNzTmFtZSwgLi4uaW5wdXQgfSwgcmVmKSA9PiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2NuKCdmbGV4IGZsZXgtY29sJywgaGlkZUxhYmVsICYmICdqdXN0aWZ5LWVuZCcpfT5cbiAgICAgIDxMYWJlbCBpZD17aWR9IGxhYmVsPXtsYWJlbH0gcmVxdWlyZWQ9e3JlcXVpcmVkfSBoaWRlTGFiZWw9e2hpZGVMYWJlbH0gLz5cbiAgICAgIDxpbnB1dFxuICAgICAgICByZWY9e3JlZn1cbiAgICAgICAgaWQ9e2lkfVxuICAgICAgICBhcmlhLWludmFsaWQ9e0Jvb2xlYW4oZXJyb3IpfVxuICAgICAgICBhcmlhLXJlcXVpcmVkPXtyZXF1aXJlZCB8fCB1bmRlZmluZWR9XG4gICAgICAgIGFyaWEtZGVzY3JpYmVkYnk9e2Rlc2NyaWJlZEJ5KGlkLCBlcnJvciwgaGludCl9XG4gICAgICAgIGNsYXNzTmFtZT17Y24oJ2staW5wdXQnLCBjbGFzc05hbWUpfVxuICAgICAgICB7Li4uaW5wdXR9XG4gICAgICAvPlxuICAgICAgPE1lc3NhZ2UgaWQ9e2lkfSBlcnJvcj17ZXJyb3J9IGhpbnQ9e2hpbnR9IC8+XG4gICAgPC9kaXY+XG4gICksXG4pXG5Gb3JtRmllbGQuZGlzcGxheU5hbWUgPSAnRm9ybUZpZWxkJ1xuXG5leHBvcnQgY29uc3QgU2VsZWN0RmllbGQgPSBSZWFjdC5mb3J3YXJkUmVmPEhUTUxTZWxlY3RFbGVtZW50LCBDb21tb24gJiBSZWFjdC5TZWxlY3RIVE1MQXR0cmlidXRlczxIVE1MU2VsZWN0RWxlbWVudD4+KFxuICAoeyBpZCwgbGFiZWwsIHJlcXVpcmVkLCBlcnJvciwgaGludCwgaGlkZUxhYmVsLCBjbGFzc05hbWUsIGNoaWxkcmVuLCAuLi5zZWxlY3QgfSwgcmVmKSA9PiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XG4gICAgICA8TGFiZWwgaWQ9e2lkfSBsYWJlbD17bGFiZWx9IHJlcXVpcmVkPXtyZXF1aXJlZH0gaGlkZUxhYmVsPXtoaWRlTGFiZWx9IC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgIDxzZWxlY3RcbiAgICAgICAgICByZWY9e3JlZn1cbiAgICAgICAgICBpZD17aWR9XG4gICAgICAgICAgYXJpYS1pbnZhbGlkPXtCb29sZWFuKGVycm9yKX1cbiAgICAgICAgICBhcmlhLXJlcXVpcmVkPXtyZXF1aXJlZCB8fCB1bmRlZmluZWR9XG4gICAgICAgICAgYXJpYS1kZXNjcmliZWRieT17ZGVzY3JpYmVkQnkoaWQsIGVycm9yLCBoaW50KX1cbiAgICAgICAgICBjbGFzc05hbWU9e2NuKCdrLWlucHV0IGN1cnNvci1wb2ludGVyIGFwcGVhcmFuY2Utbm9uZSBwci05IFsmPm9wdGlvbl06YmctY2FyZCcsIGNsYXNzTmFtZSl9XG4gICAgICAgICAgey4uLnNlbGVjdH1cbiAgICAgICAgPlxuICAgICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgIDxGaWdtYUljb24gbmFtZT1cImljb24tc2VsZWN0LWFycm93XCIgd2lkdGg9ezE4fSBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIHJpZ2h0LTIgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtc3VidGxlXCIgLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPE1lc3NhZ2UgaWQ9e2lkfSBlcnJvcj17ZXJyb3J9IGhpbnQ9e2hpbnR9IC8+XG4gICAgPC9kaXY+XG4gICksXG4pXG5TZWxlY3RGaWVsZC5kaXNwbGF5TmFtZSA9ICdTZWxlY3RGaWVsZCdcblxuLyoqIFNlbmhhIGNvbSBib3TDo28gZGUgbW9zdHJhci9vY3VsdGFyICjDrWNvbmUgXCJIaWRlXCIgZG8gbGF5b3V0KS4gKi9cbmV4cG9ydCBjb25zdCBQYXNzd29yZEZpZWxkID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgSFRNTElucHV0RWxlbWVudCxcbiAgQ29tbW9uICYgUmVhY3QuSW5wdXRIVE1MQXR0cmlidXRlczxIVE1MSW5wdXRFbGVtZW50PiAmIHsgaW5wdXRDbGFzc05hbWU/OiBzdHJpbmcgfVxuPigoeyBpZCwgbGFiZWwsIHJlcXVpcmVkLCBlcnJvciwgaGludCwgaGlkZUxhYmVsLCBjbGFzc05hbWUsIGlucHV0Q2xhc3NOYW1lLCAuLi5pbnB1dCB9LCByZWYpID0+IHtcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gUmVhY3QudXNlU3RhdGUoZmFsc2UpXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2NuKCdmbGV4IGZsZXgtY29sJywgY2xhc3NOYW1lKX0+XG4gICAgICA8TGFiZWwgaWQ9e2lkfSBsYWJlbD17bGFiZWx9IHJlcXVpcmVkPXtyZXF1aXJlZH0gaGlkZUxhYmVsPXtoaWRlTGFiZWx9IC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHJlZj17cmVmfVxuICAgICAgICAgIGlkPXtpZH1cbiAgICAgICAgICB0eXBlPXt2aXNpYmxlID8gJ3RleHQnIDogJ3Bhc3N3b3JkJ31cbiAgICAgICAgICBhcmlhLWludmFsaWQ9e0Jvb2xlYW4oZXJyb3IpfVxuICAgICAgICAgIGFyaWEtcmVxdWlyZWQ9e3JlcXVpcmVkIHx8IHVuZGVmaW5lZH1cbiAgICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PXtkZXNjcmliZWRCeShpZCwgZXJyb3IsIGhpbnQpfVxuICAgICAgICAgIGNsYXNzTmFtZT17Y24oJ2staW5wdXQgcHItMTEnLCBpbnB1dENsYXNzTmFtZSl9XG4gICAgICAgICAgey4uLmlucHV0fVxuICAgICAgICAvPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgYXJpYS1wcmVzc2VkPXt2aXNpYmxlfVxuICAgICAgICAgIGFyaWEtY29udHJvbHM9e2lkfVxuICAgICAgICAgIHRpdGxlPXt2aXNpYmxlID8gJ09jdWx0YXIgY2FyYWN0ZXJlcycgOiAnTW9zdHJhciBjYXJhY3RlcmVzJ31cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaXNpYmxlKCh2KSA9PiAhdil9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMyB0b3AtMS8yIGdyaWQgc2l6ZS03IC10cmFuc2xhdGUteS0xLzIgcGxhY2UtaXRlbXMtY2VudGVyIHRleHQtc3VidGxlIGhvdmVyOnRleHQtYWNjZW50XCJcbiAgICAgICAgPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj57dmlzaWJsZSA/ICdPY3VsdGFyIGNhcmFjdGVyZXMnIDogJ01vc3RyYXIgY2FyYWN0ZXJlcyd9PC9zcGFuPlxuICAgICAgICAgIHt2aXNpYmxlID8gPEV5ZU9wZW4gLz4gOiA8RmlnbWFJY29uIG5hbWU9XCJpY29uLWhpZGUtb3V0bGluZVwiIHdpZHRoPXsxN30gaGVpZ2h0PXsxNH0gLz59XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgICA8TWVzc2FnZSBpZD17aWR9IGVycm9yPXtlcnJvcn0gaGludD17aGludH0gLz5cbiAgICA8L2Rpdj5cbiAgKVxufSlcblBhc3N3b3JkRmllbGQuZGlzcGxheU5hbWUgPSAnUGFzc3dvcmRGaWVsZCdcblxuZnVuY3Rpb24gRXllT3BlbigpIHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnIGFyaWEtaGlkZGVuIHdpZHRoPVwiMThcIiBoZWlnaHQ9XCIxNFwiIHZpZXdCb3g9XCIwIDAgMTggMTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMS40XCI+XG4gICAgICA8cGF0aCBkPVwiTTEgN3MzLTUuNSA4LTUuNVMxNyA3IDE3IDdzLTMgNS41LTggNS41UzEgNyAxIDdaXCIgLz5cbiAgICAgIDxjaXJjbGUgY3g9XCI5XCIgY3k9XCI3XCIgcj1cIjIuNFwiIC8+XG4gICAgPC9zdmc+XG4gIClcbn1cblxuLyoqIFwiTm9tZSBFTlNcIjogZG9tw61uaW8gLmV0aCAoNzhweCkgKyBub21lLiAqL1xuZXhwb3J0IGNvbnN0IEVuc0ZpZWxkID0gUmVhY3QuZm9yd2FyZFJlZjxIVE1MSW5wdXRFbGVtZW50LCB7IGlkOiBzdHJpbmc7IGVycm9yPzogc3RyaW5nIH0gJiBSZWFjdC5JbnB1dEhUTUxBdHRyaWJ1dGVzPEhUTUxJbnB1dEVsZW1lbnQ+PihcbiAgKHsgaWQsIGVycm9yLCAuLi5pbnB1dCB9LCByZWYpID0+IChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cbiAgICAgIDxsYWJlbCBodG1sRm9yPXtpZH0gY2xhc3NOYW1lPVwiay1sYWJlbCBtaW4taC1bMjlweF1cIj5cbiAgICAgICAgTm9tZSBFTlNcbiAgICAgIDwvbGFiZWw+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIuNVwiPlxuICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbiBjbGFzc05hbWU9XCJmbGV4IGgtMTAgdy1bNzhweF0gc2hyaW5rLTAgaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1bM3B4XSBib3JkZXIgYm9yZGVyLWJvcmRlciBwbC0yLjUgdGV4dC1bMTVweF0gdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgLmV0aFxuICAgICAgICAgIDxGaWdtYUljb24gbmFtZT1cImljb24tYXJyb3ctZG93blwiIHdpZHRoPXsyMH0gLz5cbiAgICAgICAgPC9zcGFuPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICByZWY9e3JlZn1cbiAgICAgICAgICBpZD17aWR9XG4gICAgICAgICAgYXJpYS1pbnZhbGlkPXtCb29sZWFuKGVycm9yKX1cbiAgICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PXtlcnJvciA/IGAke2lkfS1lcnJvcmAgOiBgJHtpZH0tc3VmZml4YH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJrLWlucHV0XCJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cInNldS1ub21lXCJcbiAgICAgICAgICB7Li4uaW5wdXR9XG4gICAgICAgIC8+XG4gICAgICAgIDxzcGFuIGlkPXtgJHtpZH0tc3VmZml4YH0gY2xhc3NOYW1lPVwic3Itb25seVwiPlxuICAgICAgICAgIERvbcOtbmlvIC5ldGhcbiAgICAgICAgPC9zcGFuPlxuICAgICAgPC9kaXY+XG4gICAgICB7ZXJyb3IgPyAoXG4gICAgICAgIDxwIGlkPXtgJHtpZH0tZXJyb3JgfSByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1jb3JhbFwiPlxuICAgICAgICAgIHtlcnJvcn1cbiAgICAgICAgPC9wPlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9kaXY+XG4gICksXG4pXG5FbnNGaWVsZC5kaXNwbGF5TmFtZSA9ICdFbnNGaWVsZCdcbiJdfQ==