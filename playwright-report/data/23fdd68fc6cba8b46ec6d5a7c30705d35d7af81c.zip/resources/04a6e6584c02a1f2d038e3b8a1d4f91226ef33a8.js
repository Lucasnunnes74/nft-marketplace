"use client";
import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-Bk_YeHJf.js?v=1500aecb";
import { t as require_react } from "/node_modules/.vite/deps/react-Bk9vEtng.js?v=1500aecb";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-XdfVfXhi.js?v=1500aecb";
import { t as Primitive } from "/node_modules/.vite/deps/dist-B-0rLcLG.js?v=1500aecb";
//#region node_modules/@radix-ui/react-label/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var Label = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function Label2(props, forwardedRef) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.label, {
		...props,
		ref: forwardedRef,
		onMouseDown: (event) => {
			if (event.target.closest("button, input, select, textarea")) return;
			props.onMouseDown?.(event);
			if (!event.defaultPrevented && event.detail > 1) event.preventDefault();
		}
	});
}, "Label"));
//#endregion
export { Label, Label as Root };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHJhZGl4LXVpX3JlYWN0LWxhYmVsLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL0ByYWRpeC11aS9yZWFjdC1sYWJlbC9kaXN0L2luZGV4Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBjbGllbnRcIjtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy9sYWJlbC50c3hcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgUHJpbWl0aXZlIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1wcmltaXRpdmVcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xudmFyIExhYmVsID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gTGFiZWwyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgIFByaW1pdGl2ZS5sYWJlbCxcbiAgICAgIHtcbiAgICAgICAgLi4ucHJvcHMsXG4gICAgICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgICAgICBvbk1vdXNlRG93bjogKGV2ZW50KSA9PiB7XG4gICAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQudGFyZ2V0O1xuICAgICAgICAgIGlmICh0YXJnZXQuY2xvc2VzdChcImJ1dHRvbiwgaW5wdXQsIHNlbGVjdCwgdGV4dGFyZWFcIikpIHJldHVybjtcbiAgICAgICAgICBwcm9wcy5vbk1vdXNlRG93bj8uKGV2ZW50KTtcbiAgICAgICAgICBpZiAoIWV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQgJiYgZXZlbnQuZGV0YWlsID4gMSkgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICk7XG4gIH0sIFwiTGFiZWxcIilcbik7XG5leHBvcnQge1xuICBMYWJlbCxcbiAgTGFiZWwgYXMgUm9vdFxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXBcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFDQSxJQUFJLFlBQVksT0FBTztBQUN2QixJQUFJLFVBQVUsUUFBUSxVQUFVLFVBQVUsUUFBUSxRQUFRO0NBQUU7Q0FBTyxjQUFjO0FBQUssQ0FBQztBQU12RixJQUFJLFFBQXdCLDZCQUFNLFdBQ2hCLHVCQUFPLFNBQVMsT0FBTyxPQUFPLGNBQWM7Q0FDMUQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3JCLFVBQVUsT0FDVjtFQUNFLEdBQUc7RUFDSCxLQUFLO0VBQ0wsY0FBYyxVQUFVO0dBRXRCLElBRGUsTUFBTSxPQUNWLFFBQVEsaUNBQWlDLEdBQUc7R0FDdkQsTUFBTSxjQUFjLEtBQUs7R0FDekIsSUFBSSxDQUFDLE1BQU0sb0JBQW9CLE1BQU0sU0FBUyxHQUFHLE1BQU0sZUFBZTtFQUN4RTtDQUNGLENBQ0Y7QUFDRixHQUFHLE9BQU8sQ0FDWiIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=