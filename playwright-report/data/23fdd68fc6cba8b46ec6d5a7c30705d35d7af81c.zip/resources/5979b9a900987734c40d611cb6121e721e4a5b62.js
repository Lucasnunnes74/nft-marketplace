import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=5d4ac5a9";
import { RouterProvider } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import { RealtimeBridge } from "/src/app/realtime-bridge.tsx";
import { queryClient } from "/src/lib/query-client.ts";
import { router } from "/src/router.tsx";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/App.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
export default function App({ appRouter = router }) {
	return /* @__PURE__ */ _jsxDEV(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ _jsxDEV(RealtimeBridge, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(RouterProvider, { router: appRouter }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 5
	}, this);
}
_c = App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUywyQkFBMkI7QUFDcEMsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxjQUFjOzs7QUFFdkIsZUFBZSxTQUFTLElBQUksRUFBRSxZQUFZLFVBQXlDO0NBQ2pGLE9BQ0Usd0JBQUMscUJBQUQ7RUFBcUIsUUFBUTtZQUE3QixDQUNFLHdCQUFDLGdCQUFELENBQWlCOzs7O1lBQ2pCLHdCQUFDLGdCQUFELEVBQWdCLFFBQVEsVUFBWTs7OztVQUNqQjs7Ozs7O0FBRXpCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUXVlcnlDbGllbnRQcm92aWRlciB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IFJvdXRlclByb3ZpZGVyIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IFJlYWx0aW1lQnJpZGdlIH0gZnJvbSAnQC9hcHAvcmVhbHRpbWUtYnJpZGdlJ1xuaW1wb3J0IHsgcXVlcnlDbGllbnQgfSBmcm9tICdAL2xpYi9xdWVyeS1jbGllbnQnXG5pbXBvcnQgeyByb3V0ZXIgfSBmcm9tICdAL3JvdXRlcidcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKHsgYXBwUm91dGVyID0gcm91dGVyIH06IHsgYXBwUm91dGVyPzogdHlwZW9mIHJvdXRlciB9KSB7XG4gIHJldHVybiAoXG4gICAgPFF1ZXJ5Q2xpZW50UHJvdmlkZXIgY2xpZW50PXtxdWVyeUNsaWVudH0+XG4gICAgICA8UmVhbHRpbWVCcmlkZ2UgLz5cbiAgICAgIDxSb3V0ZXJQcm92aWRlciByb3V0ZXI9e2FwcFJvdXRlcn0gLz5cbiAgICA8L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+XG4gIClcbn1cbiJdfQ==