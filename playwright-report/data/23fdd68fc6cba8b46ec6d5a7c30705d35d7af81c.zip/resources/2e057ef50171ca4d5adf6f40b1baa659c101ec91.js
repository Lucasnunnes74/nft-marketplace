import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/alert.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=79ae7cb2";
import { AlertCircle, CheckCircle2, Info, TriangleAlert } from "/node_modules/.vite/deps/lucide-react.js?v=b07c072a";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/alert.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
const alertVariants = cva("flex gap-3 rounded-lg border p-4 text-sm", {
	variants: { variant: {
		info: "border-accent/40 bg-accent/10",
		success: "border-success/40 bg-success/10",
		warning: "border-warning/40 bg-warning/10",
		destructive: "border-destructive/40 bg-destructive/10"
	} },
	defaultVariants: { variant: "info" }
});
const icons = {
	info: Info,
	success: CheckCircle2,
	warning: TriangleAlert,
	destructive: AlertCircle
};
export function Alert({ className, variant = "info", title, children, ...props }) {
	const Icon = icons[variant ?? "info"];
	return /* @__PURE__ */ _jsxDEV("div", {
		role: variant === "destructive" || variant === "warning" ? "alert" : "status",
		className: cn(alertVariants({ variant }), className),
		...props,
		children: [/* @__PURE__ */ _jsxDEV(Icon, {
			"aria-hidden": true,
			className: "mt-0.5 size-4 shrink-0"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex-1 space-y-1",
			children: [title ? /* @__PURE__ */ _jsxDEV("p", {
				className: "font-semibold",
				children: title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 18
			}, this) : null, children ? /* @__PURE__ */ _jsxDEV("div", {
				className: "text-muted-foreground [&_a]:text-foreground",
				children
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 21
			}, this) : null]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 36,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 5
	}, this);
}
_c = Alert;
var _c;
$RefreshReg$(_c, "Alert");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/alert.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/alert.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/alert.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/alert.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUE4QjtBQUN2QyxTQUFTLGFBQWEsY0FBYyxNQUFNLHFCQUFxQjtBQUUvRCxTQUFTLFVBQVU7OztBQUVuQixNQUFNLGdCQUFnQixJQUFJLDRDQUE0QztDQUNwRSxVQUFVLEVBQ1IsU0FBUztFQUNQLE1BQU07RUFDTixTQUFTO0VBQ1QsU0FBUztFQUNULGFBQWE7Q0FDZixFQUNGO0NBQ0EsaUJBQWlCLEVBQUUsU0FBUyxPQUFPO0FBQ3JDLENBQUM7QUFFRCxNQUFNLFFBQVE7Q0FBRSxNQUFNO0NBQU0sU0FBUztDQUFjLFNBQVM7Q0FBZSxhQUFhO0FBQVk7QUFFcEcsT0FBTyxTQUFTLE1BQU0sRUFDcEIsV0FDQSxVQUFVLFFBQ1YsT0FDQSxVQUNBLEdBQUcsU0FFK0Q7Q0FDbEUsTUFBTSxPQUFPLE1BQU0sV0FBVztDQUM5QixPQUNFLHdCQUFDLE9BQUQ7RUFDRSxNQUFNLFlBQVksaUJBQWlCLFlBQVksWUFBWSxVQUFVO0VBQ3JFLFdBQVcsR0FBRyxjQUFjLEVBQUUsUUFBUSxDQUFDLEdBQUcsU0FBUztFQUNuRCxHQUFJO1lBSE4sQ0FLRSx3QkFBQyxNQUFEO0dBQU07R0FBWSxXQUFVO0VBQTBCOzs7O1lBQ3RELHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRyxRQUFRLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWlCO0dBQVM7Ozs7Y0FBSSxNQUNuRCxXQUFXLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQStDO0dBQWM7Ozs7Y0FBSSxJQUN6Rjs7Ozs7VUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYWxlcnQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGN2YSwgdHlwZSBWYXJpYW50UHJvcHMgfSBmcm9tICdjbGFzcy12YXJpYW5jZS1hdXRob3JpdHknXG5pbXBvcnQgeyBBbGVydENpcmNsZSwgQ2hlY2tDaXJjbGUyLCBJbmZvLCBUcmlhbmdsZUFsZXJ0IH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHR5cGUgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnXG5cbmNvbnN0IGFsZXJ0VmFyaWFudHMgPSBjdmEoJ2ZsZXggZ2FwLTMgcm91bmRlZC1sZyBib3JkZXIgcC00IHRleHQtc20nLCB7XG4gIHZhcmlhbnRzOiB7XG4gICAgdmFyaWFudDoge1xuICAgICAgaW5mbzogJ2JvcmRlci1hY2NlbnQvNDAgYmctYWNjZW50LzEwJyxcbiAgICAgIHN1Y2Nlc3M6ICdib3JkZXItc3VjY2Vzcy80MCBiZy1zdWNjZXNzLzEwJyxcbiAgICAgIHdhcm5pbmc6ICdib3JkZXItd2FybmluZy80MCBiZy13YXJuaW5nLzEwJyxcbiAgICAgIGRlc3RydWN0aXZlOiAnYm9yZGVyLWRlc3RydWN0aXZlLzQwIGJnLWRlc3RydWN0aXZlLzEwJyxcbiAgICB9LFxuICB9LFxuICBkZWZhdWx0VmFyaWFudHM6IHsgdmFyaWFudDogJ2luZm8nIH0sXG59KVxuXG5jb25zdCBpY29ucyA9IHsgaW5mbzogSW5mbywgc3VjY2VzczogQ2hlY2tDaXJjbGUyLCB3YXJuaW5nOiBUcmlhbmdsZUFsZXJ0LCBkZXN0cnVjdGl2ZTogQWxlcnRDaXJjbGUgfVxuXG5leHBvcnQgZnVuY3Rpb24gQWxlcnQoe1xuICBjbGFzc05hbWUsXG4gIHZhcmlhbnQgPSAnaW5mbycsXG4gIHRpdGxlLFxuICBjaGlsZHJlbixcbiAgLi4ucHJvcHNcbn06IE9taXQ8UmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTERpdkVsZW1lbnQ+LCAndGl0bGUnPiAmXG4gIFZhcmlhbnRQcm9wczx0eXBlb2YgYWxlcnRWYXJpYW50cz4gJiB7IHRpdGxlPzogUmVhY3QuUmVhY3ROb2RlIH0pIHtcbiAgY29uc3QgSWNvbiA9IGljb25zW3ZhcmlhbnQgPz8gJ2luZm8nXVxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIHJvbGU9e3ZhcmlhbnQgPT09ICdkZXN0cnVjdGl2ZScgfHwgdmFyaWFudCA9PT0gJ3dhcm5pbmcnID8gJ2FsZXJ0JyA6ICdzdGF0dXMnfVxuICAgICAgY2xhc3NOYW1lPXtjbihhbGVydFZhcmlhbnRzKHsgdmFyaWFudCB9KSwgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8SWNvbiBhcmlhLWhpZGRlbiBjbGFzc05hbWU9XCJtdC0wLjUgc2l6ZS00IHNocmluay0wXCIgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHNwYWNlLXktMVwiPlxuICAgICAgICB7dGl0bGUgPyA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e3RpdGxlfTwvcD4gOiBudWxsfVxuICAgICAgICB7Y2hpbGRyZW4gPyA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZCBbJl9hXTp0ZXh0LWZvcmVncm91bmRcIj57Y2hpbGRyZW59PC9kaXY+IDogbnVsbH1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=