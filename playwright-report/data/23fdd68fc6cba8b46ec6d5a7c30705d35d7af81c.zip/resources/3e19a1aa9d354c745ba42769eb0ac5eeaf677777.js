import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/nft/nft-card.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { cn } from "/src/lib/utils.ts";
import { FavoriteButton } from "/src/components/nft/favorite-button.tsx";
import { Price } from "/src/components/nft/price.tsx";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/nft-card.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
/**
* Cartão do catálogo. Desktop: moldura #241612 com a arte (258×300 no layout);
* mobile: cartão com gradiente, cantos 20px e favorito sobre a arte.
*/
export function NftCard({ nft, size = "grid" }) {
	const soldOut = nft.available === 0;
	return /* @__PURE__ */ _jsxDEV("article", {
		className: "group relative flex flex-col gap-2 md:gap-3",
		"data-testid": "nft-card",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: cn("relative overflow-hidden rounded-[20px] bg-[linear-gradient(139.5deg,#241612_12%,#2f1d15_106.6%)] px-1 pb-5 pt-3 md:rounded-none md:bg-card md:bg-none", size === "grid" ? "md:px-1 md:pb-[26px] md:pt-6" : "md:px-1 md:pb-6 md:pt-5"),
			children: [
				/* @__PURE__ */ _jsxDEV("img", {
					src: nft.image,
					alt: "",
					loading: "lazy",
					decoding: "async",
					width: 420,
					height: 420,
					className: cn("aspect-square w-full rounded-2xl object-cover transition-transform duration-300 group-hover:scale-[1.02]", size === "grid" ? "md:rounded-[15px]" : "md:rounded-[13px]")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 9
				}, this),
				soldOut ? /* @__PURE__ */ _jsxDEV("span", {
					className: "absolute left-0 top-4 flex h-8 items-center bg-primary px-2 text-[13px] font-medium leading-4 text-primary-foreground md:top-6",
					children: "ESGOTADO"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 11
				}, this) : null,
				/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute right-3 top-5 z-10 md:hidden",
					children: /* @__PURE__ */ _jsxDEV(FavoriteButton, {
						nftId: nft.id,
						name: nft.name,
						isFavorite: nft.isFavorite,
						variant: "chip"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 16,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col pl-2 md:gap-3 md:pl-0",
			children: [/* @__PURE__ */ _jsxDEV("h3", {
				className: cn("truncate text-[15px] leading-normal text-foreground", size === "grid" ? "md:text-base md:leading-4" : "md:leading-normal"),
				children: /* @__PURE__ */ _jsxDEV(Link, {
					to: "/nft/$nftId",
					params: { nftId: nft.id },
					className: "outline-none after:absolute after:inset-0 focus-visible:underline",
					children: nft.name
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: cn("flex items-center gap-3 leading-4", size === "grid" ? "text-base md:text-lg" : "text-base"),
				children: [
					/* @__PURE__ */ _jsxDEV(Price, {
						value: nft.price,
						className: "font-bold text-accent"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 11
					}, this),
					nft.previousPrice ? /* @__PURE__ */ _jsxDEV("span", {
						className: "font-normal text-subtle",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "sr-only",
							children: "Preço anterior: "
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 54,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(Price, {
							value: nft.previousPrice,
							className: "font-normal"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 55,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 13
					}, this) : null,
					/* @__PURE__ */ _jsxDEV("span", {
						className: "sr-only",
						"data-testid": "nft-availability",
						children: soldOut ? "Sem estoque" : `${nft.available} de ${nft.edition} disponíveis`
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 5
	}, this);
}
_c = NftCard;
export function NftCardSkeleton({ size = "grid" }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-3",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: cn("rounded-[20px] bg-card px-1 pb-5 pt-3 md:rounded-none", size === "grid" ? "md:pb-[26px] md:pt-6" : "md:pb-6 md:pt-5"),
				children: /* @__PURE__ */ _jsxDEV(Skeleton, { className: "aspect-square w-full rounded-2xl bg-surface-raised md:rounded-[15px]" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-3/4 bg-card" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-1/3 bg-card" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 69,
		columnNumber: 5
	}, this);
}
_c2 = NftCardSkeleton;
var _c, _c2;
$RefreshReg$(_c, "NftCard");
$RefreshReg$(_c2, "NftCardSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/nft/nft-card.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/nft-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/nft-card.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/nft-card.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBRXJCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsVUFBVTtBQUNuQixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGFBQWE7Ozs7Ozs7QUFNdEIsT0FBTyxTQUFTLFFBQVEsRUFBRSxLQUFLLE9BQU8sVUFBMEQ7Q0FDOUYsTUFBTSxVQUFVLElBQUksY0FBYztDQUNsQyxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO0VBQThDLGVBQVk7WUFBN0UsQ0FDRSx3QkFBQyxPQUFEO0dBQ0UsV0FBVyxHQUNULDBKQUNBLFNBQVMsU0FBUyxpQ0FBaUMseUJBQ3JEO2FBSkY7SUFNRSx3QkFBQyxPQUFEO0tBQ0UsS0FBSyxJQUFJO0tBQ1QsS0FBSTtLQUNKLFNBQVE7S0FDUixVQUFTO0tBQ1QsT0FBTztLQUNQLFFBQVE7S0FDUixXQUFXLEdBQ1QsNEdBQ0EsU0FBUyxTQUFTLHNCQUFzQixtQkFDMUM7SUFDRDs7Ozs7SUFDQSxVQUNDLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWlJO0lBRTNJOzs7O2VBQ0o7SUFDSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLGdCQUFEO01BQWdCLE9BQU8sSUFBSTtNQUFJLE1BQU0sSUFBSTtNQUFNLFlBQVksSUFBSTtNQUFZLFNBQVE7S0FBUTs7Ozs7SUFDeEY7Ozs7O0dBQ0Y7Ozs7O1lBQ0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFXLEdBQUcsdURBQXVELFNBQVMsU0FBUyw4QkFBOEIsbUJBQW1CO2NBRTFJLHdCQUFDLE1BQUQ7S0FBTSxJQUFHO0tBQWMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0tBQUcsV0FBVTtlQUN6RCxJQUFJO0lBQ0Q7Ozs7O0dBQ0o7Ozs7YUFDSix3QkFBQyxLQUFEO0lBQUcsV0FBVyxHQUFHLHFDQUFxQyxTQUFTLFNBQVMseUJBQXlCLFdBQVc7Y0FBNUc7S0FDRSx3QkFBQyxPQUFEO01BQU8sT0FBTyxJQUFJO01BQU8sV0FBVTtLQUF5Qjs7Ozs7S0FDM0QsSUFBSSxnQkFDSCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBVTtNQUFzQjs7OztnQkFDaEQsd0JBQUMsT0FBRDtPQUFPLE9BQU8sSUFBSTtPQUFlLFdBQVU7TUFBZTs7OztjQUN0RDs7Ozs7Z0JBQ0o7S0FDSix3QkFBQyxRQUFEO01BQU0sV0FBVTtNQUFVLGVBQVk7Z0JBQ25DLFVBQVUsZ0JBQWdCLEdBQUcsSUFBSSxVQUFVLE1BQU0sSUFBSSxRQUFRO0tBQzFEOzs7OztJQUNMOzs7OztXQUNBOzs7OztVQUNFOzs7Ozs7QUFFYjs7QUFFQSxPQUFPLFNBQVMsZ0JBQWdCLEVBQUUsT0FBTyxVQUF5QztDQUNoRixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQXNCO1lBQXJDO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVcsR0FBRyx5REFBeUQsU0FBUyxTQUFTLHlCQUF5QixpQkFBaUI7Y0FDdEksd0JBQUMsVUFBRCxFQUFVLFdBQVUsdUVBQXdFOzs7OztHQUN6Rjs7Ozs7R0FDTCx3QkFBQyxVQUFELEVBQVUsV0FBVSxvQkFBcUI7Ozs7O0dBQ3pDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLG9CQUFxQjs7Ozs7RUFDdEM7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm5mdC1jYXJkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB0eXBlIHsgTmZ0U3VtbWFyeSB9IGZyb20gJ0AvYXBpL2NvbnRyYWN0cydcbmltcG9ydCB7IFNrZWxldG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NrZWxldG9uJ1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcbmltcG9ydCB7IEZhdm9yaXRlQnV0dG9uIH0gZnJvbSAnLi9mYXZvcml0ZS1idXR0b24nXG5pbXBvcnQgeyBQcmljZSB9IGZyb20gJy4vcHJpY2UnXG5cbi8qKlxuICogQ2FydMOjbyBkbyBjYXTDoWxvZ28uIERlc2t0b3A6IG1vbGR1cmEgIzI0MTYxMiBjb20gYSBhcnRlICgyNTjDlzMwMCBubyBsYXlvdXQpO1xuICogbW9iaWxlOiBjYXJ0w6NvIGNvbSBncmFkaWVudGUsIGNhbnRvcyAyMHB4IGUgZmF2b3JpdG8gc29icmUgYSBhcnRlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gTmZ0Q2FyZCh7IG5mdCwgc2l6ZSA9ICdncmlkJyB9OiB7IG5mdDogTmZ0U3VtbWFyeTsgc2l6ZT86ICdncmlkJyB8ICdyZWxhdGVkJyB9KSB7XG4gIGNvbnN0IHNvbGRPdXQgPSBuZnQuYXZhaWxhYmxlID09PSAwXG4gIHJldHVybiAoXG4gICAgPGFydGljbGUgY2xhc3NOYW1lPVwiZ3JvdXAgcmVsYXRpdmUgZmxleCBmbGV4LWNvbCBnYXAtMiBtZDpnYXAtM1wiIGRhdGEtdGVzdGlkPVwibmZ0LWNhcmRcIj5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAncmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtWzIwcHhdIGJnLVtsaW5lYXItZ3JhZGllbnQoMTM5LjVkZWcsIzI0MTYxMl8xMiUsIzJmMWQxNV8xMDYuNiUpXSBweC0xIHBiLTUgcHQtMyBtZDpyb3VuZGVkLW5vbmUgbWQ6YmctY2FyZCBtZDpiZy1ub25lJyxcbiAgICAgICAgICBzaXplID09PSAnZ3JpZCcgPyAnbWQ6cHgtMSBtZDpwYi1bMjZweF0gbWQ6cHQtNicgOiAnbWQ6cHgtMSBtZDpwYi02IG1kOnB0LTUnLFxuICAgICAgICApfVxuICAgICAgPlxuICAgICAgICA8aW1nXG4gICAgICAgICAgc3JjPXtuZnQuaW1hZ2V9XG4gICAgICAgICAgYWx0PVwiXCJcbiAgICAgICAgICBsb2FkaW5nPVwibGF6eVwiXG4gICAgICAgICAgZGVjb2Rpbmc9XCJhc3luY1wiXG4gICAgICAgICAgd2lkdGg9ezQyMH1cbiAgICAgICAgICBoZWlnaHQ9ezQyMH1cbiAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgJ2FzcGVjdC1zcXVhcmUgdy1mdWxsIHJvdW5kZWQtMnhsIG9iamVjdC1jb3ZlciB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDAgZ3JvdXAtaG92ZXI6c2NhbGUtWzEuMDJdJyxcbiAgICAgICAgICAgIHNpemUgPT09ICdncmlkJyA/ICdtZDpyb3VuZGVkLVsxNXB4XScgOiAnbWQ6cm91bmRlZC1bMTNweF0nLFxuICAgICAgICAgICl9XG4gICAgICAgIC8+XG4gICAgICAgIHtzb2xkT3V0ID8gKFxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMCB0b3AtNCBmbGV4IGgtOCBpdGVtcy1jZW50ZXIgYmctcHJpbWFyeSBweC0yIHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIGxlYWRpbmctNCB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBtZDp0b3AtNlwiPlxuICAgICAgICAgICAgRVNHT1RBRE9cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTMgdG9wLTUgei0xMCBtZDpoaWRkZW5cIj5cbiAgICAgICAgICA8RmF2b3JpdGVCdXR0b24gbmZ0SWQ9e25mdC5pZH0gbmFtZT17bmZ0Lm5hbWV9IGlzRmF2b3JpdGU9e25mdC5pc0Zhdm9yaXRlfSB2YXJpYW50PVwiY2hpcFwiIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgcGwtMiBtZDpnYXAtMyBtZDpwbC0wXCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9e2NuKCd0cnVuY2F0ZSB0ZXh0LVsxNXB4XSBsZWFkaW5nLW5vcm1hbCB0ZXh0LWZvcmVncm91bmQnLCBzaXplID09PSAnZ3JpZCcgPyAnbWQ6dGV4dC1iYXNlIG1kOmxlYWRpbmctNCcgOiAnbWQ6bGVhZGluZy1ub3JtYWwnKX0+XG4gICAgICAgICAgey8qIE8gbGluayBjb2JyZSBvIGNhcnTDo28gaW50ZWlybzsgbyBmYXZvcml0byBmaWNhIGFjaW1hICh6LTEwKS4gKi99XG4gICAgICAgICAgPExpbmsgdG89XCIvbmZ0LyRuZnRJZFwiIHBhcmFtcz17eyBuZnRJZDogbmZ0LmlkIH19IGNsYXNzTmFtZT1cIm91dGxpbmUtbm9uZSBhZnRlcjphYnNvbHV0ZSBhZnRlcjppbnNldC0wIGZvY3VzLXZpc2libGU6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICB7bmZ0Lm5hbWV9XG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICA8L2gzPlxuICAgICAgICA8cCBjbGFzc05hbWU9e2NuKCdmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBsZWFkaW5nLTQnLCBzaXplID09PSAnZ3JpZCcgPyAndGV4dC1iYXNlIG1kOnRleHQtbGcnIDogJ3RleHQtYmFzZScpfT5cbiAgICAgICAgICA8UHJpY2UgdmFsdWU9e25mdC5wcmljZX0gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYWNjZW50XCIgLz5cbiAgICAgICAgICB7bmZ0LnByZXZpb3VzUHJpY2UgPyAoXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW5vcm1hbCB0ZXh0LXN1YnRsZVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+UHJlw6dvIGFudGVyaW9yOiA8L3NwYW4+XG4gICAgICAgICAgICAgIDxQcmljZSB2YWx1ZT17bmZ0LnByZXZpb3VzUHJpY2V9IGNsYXNzTmFtZT1cImZvbnQtbm9ybWFsXCIgLz5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCIgZGF0YS10ZXN0aWQ9XCJuZnQtYXZhaWxhYmlsaXR5XCI+XG4gICAgICAgICAgICB7c29sZE91dCA/ICdTZW0gZXN0b3F1ZScgOiBgJHtuZnQuYXZhaWxhYmxlfSBkZSAke25mdC5lZGl0aW9ufSBkaXNwb27DrXZlaXNgfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9wPlxuICAgICAgPC9kaXY+XG4gICAgPC9hcnRpY2xlPlxuICApXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBOZnRDYXJkU2tlbGV0b24oeyBzaXplID0gJ2dyaWQnIH06IHsgc2l6ZT86ICdncmlkJyB8ICdyZWxhdGVkJyB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zXCIgYXJpYS1oaWRkZW4+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17Y24oJ3JvdW5kZWQtWzIwcHhdIGJnLWNhcmQgcHgtMSBwYi01IHB0LTMgbWQ6cm91bmRlZC1ub25lJywgc2l6ZSA9PT0gJ2dyaWQnID8gJ21kOnBiLVsyNnB4XSBtZDpwdC02JyA6ICdtZDpwYi02IG1kOnB0LTUnKX0+XG4gICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJhc3BlY3Qtc3F1YXJlIHctZnVsbCByb3VuZGVkLTJ4bCBiZy1zdXJmYWNlLXJhaXNlZCBtZDpyb3VuZGVkLVsxNXB4XVwiIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy0zLzQgYmctY2FyZFwiIC8+XG4gICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC00IHctMS8zIGJnLWNhcmRcIiAvPlxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=