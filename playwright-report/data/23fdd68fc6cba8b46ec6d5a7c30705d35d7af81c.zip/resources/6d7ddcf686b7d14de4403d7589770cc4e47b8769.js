import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/dialog.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport1_react, 1);const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import * as DialogPrimitive from "/node_modules/.vite/deps/@radix-ui_react-dialog.js?v=cddb5b06";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { cn } from "/src/lib/utils.ts";
import { FigmaIcon } from "/src/components/ui/figma-icon.tsx";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/dialog.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
export const Dialog = DialogPrimitive.Root;
export const DialogTrigger = DialogPrimitive.Trigger;
export const DialogClose = DialogPrimitive.Close;
export const DialogContent = React.forwardRef(_c = ({ className, children, ...props }, ref) => /* @__PURE__ */ _jsxDEV(DialogPrimitive.Portal, { children: [/* @__PURE__ */ _jsxDEV(DialogPrimitive.Overlay, { className: "fixed inset-0 z-50 bg-background/80 backdrop-blur-[2px]" }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 15,
	columnNumber: 5
}, this), /* @__PURE__ */ _jsxDEV(DialogPrimitive.Content, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 grid w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 rounded-lg border border-border bg-card p-6 text-foreground shadow-[0_20px_40px_rgba(10,6,4,0.45)]", className),
	...props,
	children: [children, /* @__PURE__ */ _jsxDEV(DialogPrimitive.Close, {
		"aria-label": "Fechar",
		className: "absolute right-3 top-3 grid size-8 place-items-center rounded-sm text-primary hover:text-accent",
		children: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
			name: "icon-close-modal",
			width: 18
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 7
	}, this)]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 16,
	columnNumber: 5
}, this)] }, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 14,
	columnNumber: 3
}, this));
_c2 = DialogContent;
DialogContent.displayName = "DialogContent";
export const DialogTitle = React.forwardRef(_c3 = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(DialogPrimitive.Title, {
	ref,
	className: cn("text-lg font-bold text-foreground", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 37,
	columnNumber: 3
}, this));
_c4 = DialogTitle;
DialogTitle.displayName = "DialogTitle";
export const DialogDescription = React.forwardRef(_c5 = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(DialogPrimitive.Description, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 45,
	columnNumber: 3
}, this));
_c6 = DialogDescription;
DialogDescription.displayName = "DialogDescription";
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "DialogContent$React.forwardRef");
$RefreshReg$(_c2, "DialogContent");
$RefreshReg$(_c3, "DialogTitle$React.forwardRef");
$RefreshReg$(_c4, "DialogTitle");
$RefreshReg$(_c5, "DialogDescription$React.forwardRef");
$RefreshReg$(_c6, "DialogDescription");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/dialog.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/dialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/dialog.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxXQUFXO0FBQ3ZCLFNBQVMsVUFBVTtBQUNuQixTQUFTLGlCQUFpQjs7O0FBRTFCLE9BQU8sTUFBTSxTQUFTLGdCQUFnQjtBQUN0QyxPQUFPLE1BQU0sZ0JBQWdCLGdCQUFnQjtBQUM3QyxPQUFPLE1BQU0sY0FBYyxnQkFBZ0I7QUFFM0MsT0FBTyxNQUFNLGdCQUFnQixNQUFNLGlCQUdoQyxFQUFFLFdBQVcsVUFBVSxHQUFHLFNBQVMsUUFDcEMsd0JBQUMsZ0JBQWdCLFFBQWpCLGFBQ0Usd0JBQUMsZ0JBQWdCLFNBQWpCLEVBQXlCLFdBQVUsMERBQTJEOzs7O1VBQzlGLHdCQUFDLGdCQUFnQixTQUFqQjtDQUNPO0NBQ0wsV0FBVyxHQUNULDRNQUNBLFNBQ0Y7Q0FDQSxHQUFJO1dBTk4sQ0FRRyxVQUNELHdCQUFDLGdCQUFnQixPQUFqQjtFQUF1QixjQUFXO0VBQVMsV0FBVTtZQUNuRCx3QkFBQyxXQUFEO0dBQVcsTUFBSztHQUFtQixPQUFPO0VBQUs7Ozs7O0NBQzFCOzs7O1NBQ0E7Ozs7O1FBQ0g7Ozs7UUFDekI7O0FBQ0QsY0FBYyxjQUFjO0FBRTVCLE9BQU8sTUFBTSxjQUFjLE1BQU0sa0JBRzlCLEVBQUUsV0FBVyxHQUFHLFNBQVMsUUFDMUIsd0JBQUMsZ0JBQWdCLE9BQWpCO0NBQTRCO0NBQUssV0FBVyxHQUFHLHFDQUFxQyxTQUFTO0NBQUcsR0FBSTtBQUFROzs7O1FBQzdHOztBQUNELFlBQVksY0FBYztBQUUxQixPQUFPLE1BQU0sb0JBQW9CLE1BQU0sa0JBR3BDLEVBQUUsV0FBVyxHQUFHLFNBQVMsUUFDMUIsd0JBQUMsZ0JBQWdCLGFBQWpCO0NBQWtDO0NBQUssV0FBVyxHQUFHLGlDQUFpQyxTQUFTO0NBQUcsR0FBSTtBQUFROzs7O1FBQy9HOztBQUNELGtCQUFrQixjQUFjIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImRpYWxvZy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgRGlhbG9nUHJpbWl0aXZlIGZyb20gJ0ByYWRpeC11aS9yZWFjdC1kaWFsb2cnXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnXG5pbXBvcnQgeyBGaWdtYUljb24gfSBmcm9tICcuL2ZpZ21hLWljb24nXG5cbmV4cG9ydCBjb25zdCBEaWFsb2cgPSBEaWFsb2dQcmltaXRpdmUuUm9vdFxuZXhwb3J0IGNvbnN0IERpYWxvZ1RyaWdnZXIgPSBEaWFsb2dQcmltaXRpdmUuVHJpZ2dlclxuZXhwb3J0IGNvbnN0IERpYWxvZ0Nsb3NlID0gRGlhbG9nUHJpbWl0aXZlLkNsb3NlXG5cbmV4cG9ydCBjb25zdCBEaWFsb2dDb250ZW50ID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuQ29tcG9uZW50UmVmPHR5cGVvZiBEaWFsb2dQcmltaXRpdmUuQ29udGVudD4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgRGlhbG9nUHJpbWl0aXZlLkNvbnRlbnQ+XG4+KCh7IGNsYXNzTmFtZSwgY2hpbGRyZW4sIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8RGlhbG9nUHJpbWl0aXZlLlBvcnRhbD5cbiAgICA8RGlhbG9nUHJpbWl0aXZlLk92ZXJsYXkgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGJnLWJhY2tncm91bmQvODAgYmFja2Ryb3AtYmx1ci1bMnB4XVwiIC8+XG4gICAgPERpYWxvZ1ByaW1pdGl2ZS5Db250ZW50XG4gICAgICByZWY9e3JlZn1cbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICdmaXhlZCBsZWZ0LTEvMiB0b3AtMS8yIHotNTAgZ3JpZCB3LVtjYWxjKDEwMCUtMnJlbSldIG1heC13LWxnIC10cmFuc2xhdGUteC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBnYXAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWNhcmQgcC02IHRleHQtZm9yZWdyb3VuZCBzaGFkb3ctWzBfMjBweF80MHB4X3JnYmEoMTAsNiw0LDAuNDUpXScsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgICAgPERpYWxvZ1ByaW1pdGl2ZS5DbG9zZSBhcmlhLWxhYmVsPVwiRmVjaGFyXCIgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMyB0b3AtMyBncmlkIHNpemUtOCBwbGFjZS1pdGVtcy1jZW50ZXIgcm91bmRlZC1zbSB0ZXh0LXByaW1hcnkgaG92ZXI6dGV4dC1hY2NlbnRcIj5cbiAgICAgICAgPEZpZ21hSWNvbiBuYW1lPVwiaWNvbi1jbG9zZS1tb2RhbFwiIHdpZHRoPXsxOH0gLz5cbiAgICAgIDwvRGlhbG9nUHJpbWl0aXZlLkNsb3NlPlxuICAgIDwvRGlhbG9nUHJpbWl0aXZlLkNvbnRlbnQ+XG4gIDwvRGlhbG9nUHJpbWl0aXZlLlBvcnRhbD5cbikpXG5EaWFsb2dDb250ZW50LmRpc3BsYXlOYW1lID0gJ0RpYWxvZ0NvbnRlbnQnXG5cbmV4cG9ydCBjb25zdCBEaWFsb2dUaXRsZSA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkNvbXBvbmVudFJlZjx0eXBlb2YgRGlhbG9nUHJpbWl0aXZlLlRpdGxlPixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBEaWFsb2dQcmltaXRpdmUuVGl0bGU+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxEaWFsb2dQcmltaXRpdmUuVGl0bGUgcmVmPXtyZWZ9IGNsYXNzTmFtZT17Y24oJ3RleHQtbGcgZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZCcsIGNsYXNzTmFtZSl9IHsuLi5wcm9wc30gLz5cbikpXG5EaWFsb2dUaXRsZS5kaXNwbGF5TmFtZSA9ICdEaWFsb2dUaXRsZSdcblxuZXhwb3J0IGNvbnN0IERpYWxvZ0Rlc2NyaXB0aW9uID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuQ29tcG9uZW50UmVmPHR5cGVvZiBEaWFsb2dQcmltaXRpdmUuRGVzY3JpcHRpb24+LFxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIERpYWxvZ1ByaW1pdGl2ZS5EZXNjcmlwdGlvbj5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPERpYWxvZ1ByaW1pdGl2ZS5EZXNjcmlwdGlvbiByZWY9e3JlZn0gY2xhc3NOYW1lPXtjbigndGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmQnLCBjbGFzc05hbWUpfSB7Li4ucHJvcHN9IC8+XG4pKVxuRGlhbG9nRGVzY3JpcHRpb24uZGlzcGxheU5hbWUgPSAnRGlhbG9nRGVzY3JpcHRpb24nXG4iXX0=