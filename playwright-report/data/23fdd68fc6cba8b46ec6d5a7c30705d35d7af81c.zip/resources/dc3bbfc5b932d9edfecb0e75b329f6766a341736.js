import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/nft/favorite-button.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import { useLocation, useNavigate } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import { Heart } from "/node_modules/.vite/deps/lucide-react.js?v=b07c072a";
import { useSessionState } from "/src/auth/use-session.ts";
import { FigmaIcon } from "/src/components/ui/figma-icon.tsx";
import { useToggleFavorite } from "/src/hooks/use-api.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/favorite-button.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$();
/**
* Favoritar exige sessão: sem login, leva ao login e volta para a mesma tela.
* `button`: botão "Favoritar" do detalhe (desktop). `chip`: círculo de 28/35px do mobile.
*/
export function FavoriteButton({ nftId, name, isFavorite, variant = "button", className }) {
	_s();
	const { isAuthenticated } = useSessionState();
	const navigate = useNavigate();
	const location = useLocation();
	const toggle = useToggleFavorite();
	function onClick() {
		if (!isAuthenticated) {
			void navigate({
				to: "/login",
				search: {
					redirect: location.href,
					reason: "favorite"
				}
			});
			return;
		}
		toggle.mutate({
			nftId,
			next: !isFavorite
		});
	}
	if (variant === "button") {
		return /* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			"aria-pressed": isFavorite,
			onClick,
			className: cn("flex h-10 w-[130px] items-center justify-center gap-2 rounded-[6px] border border-primary text-sm font-medium leading-5 text-accent transition-colors hover:bg-primary/10", isFavorite && "bg-primary/15", className),
			children: [/* @__PURE__ */ _jsxDEV(HeartIcon, {
				filled: isFavorite,
				size: 20
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 9
			}, this), isFavorite ? "Favoritado" : "Favoritar"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this);
	}
	const large = variant === "chip-lg";
	return /* @__PURE__ */ _jsxDEV("button", {
		type: "button",
		"aria-pressed": isFavorite,
		"aria-label": isFavorite ? `Remover ${name} dos favoritos` : `Favoritar ${name}`,
		onClick,
		className: cn("grid place-items-center rounded-full border border-border bg-surface-raised text-accent", large ? "size-[35px]" : "size-7", className),
		children: /* @__PURE__ */ _jsxDEV(HeartIcon, {
			filled: isFavorite,
			size: large ? 16 : 14
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 58,
		columnNumber: 5
	}, this);
}
_s(FavoriteButton, "aUw5bHCfrUQ45DQubP/1Ix0b29o=", false, function() {
	return [
		useSessionState,
		useNavigate,
		useLocation,
		useToggleFavorite
	];
});
_c = FavoriteButton;
/** Coração do layout: contorno quando livre, preenchido quando favoritado (não só cor). */
function HeartIcon({ filled, size }) {
	return filled ? /* @__PURE__ */ _jsxDEV(Heart, {
		"aria-hidden": true,
		fill: "currentColor",
		strokeWidth: 1.5,
		style: {
			width: size,
			height: size
		},
		className: "shrink-0"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 77,
		columnNumber: 5
	}, this) : /* @__PURE__ */ _jsxDEV(FigmaIcon, {
		name: "icon-heart-accent",
		width: size,
		height: size
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 79,
		columnNumber: 5
	}, this);
}
_c2 = HeartIcon;
var _c, _c2;
$RefreshReg$(_c, "FavoriteButton");
$RefreshReg$(_c2, "HeartIcon");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/nft/favorite-button.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/favorite-button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/favorite-button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/favorite-button.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLG1CQUFtQjtBQUN6QyxTQUFTLGFBQWE7QUFDdEIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxVQUFVOzs7Ozs7OztBQU1uQixPQUFPLFNBQVMsZUFBZSxFQUM3QixPQUNBLE1BQ0EsWUFDQSxVQUFVLFVBQ1YsYUFPQzs7Q0FDRCxNQUFNLEVBQUUsb0JBQW9CLGdCQUFnQjtDQUM1QyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFNBQVMsa0JBQWtCO0NBRWpDLFNBQVMsVUFBVTtFQUNqQixJQUFJLENBQUMsaUJBQWlCO0dBQ3BCLEtBQUssU0FBUztJQUFFLElBQUk7SUFBVSxRQUFRO0tBQUUsVUFBVSxTQUFTO0tBQU0sUUFBUTtJQUFXO0dBQUUsQ0FBQztHQUN2RjtFQUNGO0VBQ0EsT0FBTyxPQUFPO0dBQUU7R0FBTyxNQUFNLENBQUM7RUFBVyxDQUFDO0NBQzVDO0NBRUEsSUFBSSxZQUFZLFVBQVU7RUFDeEIsT0FDRSx3QkFBQyxVQUFEO0dBQ0UsTUFBSztHQUNMLGdCQUFjO0dBQ0w7R0FDVCxXQUFXLEdBQ1QsNktBQ0EsY0FBYyxpQkFDZCxTQUNGO2FBUkYsQ0FVRSx3QkFBQyxXQUFEO0lBQVcsUUFBUTtJQUFZLE1BQU07R0FBSzs7OzthQUN6QyxhQUFhLGVBQWUsV0FDdkI7Ozs7OztDQUVaO0NBRUEsTUFBTSxRQUFRLFlBQVk7Q0FDMUIsT0FDRSx3QkFBQyxVQUFEO0VBQ0UsTUFBSztFQUNMLGdCQUFjO0VBQ2QsY0FBWSxhQUFhLFdBQVcsS0FBSyxrQkFBa0IsYUFBYTtFQUMvRDtFQUNULFdBQVcsR0FDVCwyRkFDQSxRQUFRLGdCQUFnQixVQUN4QixTQUNGO1lBRUEsd0JBQUMsV0FBRDtHQUFXLFFBQVE7R0FBWSxNQUFNLFFBQVEsS0FBSztFQUFLOzs7OztDQUNqRDs7Ozs7QUFFWjs7Ozs7Ozs7Ozs7QUFHQSxTQUFTLFVBQVUsRUFBRSxRQUFRLFFBQTJDO0NBQ3RFLE9BQU8sU0FDTCx3QkFBQyxPQUFEO0VBQU87RUFBWSxNQUFLO0VBQWUsYUFBYTtFQUFLLE9BQU87R0FBRSxPQUFPO0dBQU0sUUFBUTtFQUFLO0VBQUcsV0FBVTtDQUFZOzs7O1lBRXJILHdCQUFDLFdBQUQ7RUFBVyxNQUFLO0VBQW9CLE9BQU87RUFBTSxRQUFRO0NBQU87Ozs7O0FBRXBFIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImZhdm9yaXRlLWJ1dHRvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IEhlYXJ0IH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdXNlU2Vzc2lvblN0YXRlIH0gZnJvbSAnQC9hdXRoL3VzZS1zZXNzaW9uJ1xuaW1wb3J0IHsgRmlnbWFJY29uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2ZpZ21hLWljb24nXG5pbXBvcnQgeyB1c2VUb2dnbGVGYXZvcml0ZSB9IGZyb20gJ0AvaG9va3MvdXNlLWFwaSdcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnXG5cbi8qKlxuICogRmF2b3JpdGFyIGV4aWdlIHNlc3PDo286IHNlbSBsb2dpbiwgbGV2YSBhbyBsb2dpbiBlIHZvbHRhIHBhcmEgYSBtZXNtYSB0ZWxhLlxuICogYGJ1dHRvbmA6IGJvdMOjbyBcIkZhdm9yaXRhclwiIGRvIGRldGFsaGUgKGRlc2t0b3ApLiBgY2hpcGA6IGPDrXJjdWxvIGRlIDI4LzM1cHggZG8gbW9iaWxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gRmF2b3JpdGVCdXR0b24oe1xuICBuZnRJZCxcbiAgbmFtZSxcbiAgaXNGYXZvcml0ZSxcbiAgdmFyaWFudCA9ICdidXR0b24nLFxuICBjbGFzc05hbWUsXG59OiB7XG4gIG5mdElkOiBzdHJpbmdcbiAgbmFtZTogc3RyaW5nXG4gIGlzRmF2b3JpdGU6IGJvb2xlYW5cbiAgdmFyaWFudD86ICdidXR0b24nIHwgJ2NoaXAnIHwgJ2NoaXAtbGcnXG4gIGNsYXNzTmFtZT86IHN0cmluZ1xufSkge1xuICBjb25zdCB7IGlzQXV0aGVudGljYXRlZCB9ID0gdXNlU2Vzc2lvblN0YXRlKClcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKVxuICBjb25zdCB0b2dnbGUgPSB1c2VUb2dnbGVGYXZvcml0ZSgpXG5cbiAgZnVuY3Rpb24gb25DbGljaygpIHtcbiAgICBpZiAoIWlzQXV0aGVudGljYXRlZCkge1xuICAgICAgdm9pZCBuYXZpZ2F0ZSh7IHRvOiAnL2xvZ2luJywgc2VhcmNoOiB7IHJlZGlyZWN0OiBsb2NhdGlvbi5ocmVmLCByZWFzb246ICdmYXZvcml0ZScgfSB9KVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIHRvZ2dsZS5tdXRhdGUoeyBuZnRJZCwgbmV4dDogIWlzRmF2b3JpdGUgfSlcbiAgfVxuXG4gIGlmICh2YXJpYW50ID09PSAnYnV0dG9uJykge1xuICAgIHJldHVybiAoXG4gICAgICA8YnV0dG9uXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICBhcmlhLXByZXNzZWQ9e2lzRmF2b3JpdGV9XG4gICAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgJ2ZsZXggaC0xMCB3LVsxMzBweF0gaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQtWzZweF0gYm9yZGVyIGJvcmRlci1wcmltYXJ5IHRleHQtc20gZm9udC1tZWRpdW0gbGVhZGluZy01IHRleHQtYWNjZW50IHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLXByaW1hcnkvMTAnLFxuICAgICAgICAgIGlzRmF2b3JpdGUgJiYgJ2JnLXByaW1hcnkvMTUnLFxuICAgICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICAgKX1cbiAgICAgID5cbiAgICAgICAgPEhlYXJ0SWNvbiBmaWxsZWQ9e2lzRmF2b3JpdGV9IHNpemU9ezIwfSAvPlxuICAgICAgICB7aXNGYXZvcml0ZSA/ICdGYXZvcml0YWRvJyA6ICdGYXZvcml0YXInfVxuICAgICAgPC9idXR0b24+XG4gICAgKVxuICB9XG5cbiAgY29uc3QgbGFyZ2UgPSB2YXJpYW50ID09PSAnY2hpcC1sZydcbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgIGFyaWEtcHJlc3NlZD17aXNGYXZvcml0ZX1cbiAgICAgIGFyaWEtbGFiZWw9e2lzRmF2b3JpdGUgPyBgUmVtb3ZlciAke25hbWV9IGRvcyBmYXZvcml0b3NgIDogYEZhdm9yaXRhciAke25hbWV9YH1cbiAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAnZ3JpZCBwbGFjZS1pdGVtcy1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLXN1cmZhY2UtcmFpc2VkIHRleHQtYWNjZW50JyxcbiAgICAgICAgbGFyZ2UgPyAnc2l6ZS1bMzVweF0nIDogJ3NpemUtNycsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICl9XG4gICAgPlxuICAgICAgPEhlYXJ0SWNvbiBmaWxsZWQ9e2lzRmF2b3JpdGV9IHNpemU9e2xhcmdlID8gMTYgOiAxNH0gLz5cbiAgICA8L2J1dHRvbj5cbiAgKVxufVxuXG4vKiogQ29yYcOnw6NvIGRvIGxheW91dDogY29udG9ybm8gcXVhbmRvIGxpdnJlLCBwcmVlbmNoaWRvIHF1YW5kbyBmYXZvcml0YWRvIChuw6NvIHPDsyBjb3IpLiAqL1xuZnVuY3Rpb24gSGVhcnRJY29uKHsgZmlsbGVkLCBzaXplIH06IHsgZmlsbGVkOiBib29sZWFuOyBzaXplOiBudW1iZXIgfSkge1xuICByZXR1cm4gZmlsbGVkID8gKFxuICAgIDxIZWFydCBhcmlhLWhpZGRlbiBmaWxsPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9ezEuNX0gc3R5bGU9e3sgd2lkdGg6IHNpemUsIGhlaWdodDogc2l6ZSB9fSBjbGFzc05hbWU9XCJzaHJpbmstMFwiIC8+XG4gICkgOiAoXG4gICAgPEZpZ21hSWNvbiBuYW1lPVwiaWNvbi1oZWFydC1hY2NlbnRcIiB3aWR0aD17c2l6ZX0gaGVpZ2h0PXtzaXplfSAvPlxuICApXG59XG4iXX0=