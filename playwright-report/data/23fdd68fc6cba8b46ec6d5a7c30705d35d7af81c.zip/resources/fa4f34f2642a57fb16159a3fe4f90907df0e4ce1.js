import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/marketing/sections.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import { FigmaIcon } from "/src/components/ui/figma-icon.tsx";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/marketing/sections.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
/** Hero da página inicial (desktop 1200×450 / mobile 366×190 no layout). */
export function Hero() {
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-labelledby": "hero-title",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "hidden h-[450px] items-center justify-between pl-10 md:flex",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex w-[600px] max-w-[52%] flex-col items-end gap-11",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex w-full flex-col gap-8",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-1",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-2 text-foreground",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm font-medium leading-4 tracking-[1.4px]",
								children: "Bem-vindo à Kurio"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 14,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("h1", {
								id: "hero-title",
								className: "text-[43px] font-bold leading-[70px] max-lg:text-[34px] max-lg:leading-[52px]",
								children: [
									"SEJA DONO DO FUTURO",
									/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 17,
										columnNumber: 19
									}, this),
									"DA ARTE DIGITAL"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 13,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "max-w-[557px] text-sm leading-6 text-muted-foreground",
							children: "Descubra NFTs selecionados de criadores emergentes e consagrados. Colecione arte digital rara, apoie artistas e tenha uma parte da cultura da internet."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 21,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 12,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						hash: "catalogo",
						className: "flex h-10 w-[140px] items-center justify-center rounded-[6px] bg-primary text-base font-bold leading-5 text-primary-foreground hover:brightness-110",
						children: "EXPLORAR"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 11,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("img", {
					src: "/figma/hero-dots.svg",
					alt: "",
					"aria-hidden": true,
					width: 40,
					height: 8
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("img", {
				src: "/figma/nft-emerald-ape.webp",
				alt: "Emerald Ape #042: macaco de óculos redondos e jaqueta verde",
				width: 450,
				height: 450,
				fetchPriority: "high",
				className: "aspect-square w-[450px] max-w-[45%] rounded-3xl object-cover"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative flex h-[190px] flex-col items-center justify-center gap-4 overflow-hidden rounded-xl p-4 md:hidden",
			children: [
				/* @__PURE__ */ _jsxDEV("img", {
					src: "/figma/m-hero-mask.svg",
					alt: "",
					"aria-hidden": true,
					className: "absolute inset-0 size-full"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative flex w-full items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex min-w-0 flex-1 flex-col",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-medium leading-4 text-foreground",
									children: "Bem-vindo à Kurio"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 52,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h1", {
									id: "hero-title-m",
									className: "w-[190px] text-lg font-bold leading-[29px] text-foreground",
									children: [
										"SEJA DONO DA",
										/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 55,
											columnNumber: 17
										}, this),
										"CULTURA DIGITAL"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 53,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs leading-[18px] text-muted-foreground",
									children: "Descubra NFTs selecionados de criadores do mundo todo."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 58,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(Link, {
							to: "/",
							hash: "catalogo",
							className: "flex items-center gap-2 text-xs font-bold leading-[14px] text-accent",
							children: ["EXPLORAR", /* @__PURE__ */ _jsxDEV(FigmaIcon, {
								name: "m-arrow-right",
								width: 10,
								height: 8,
								className: "-rotate-90"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "relative size-[138px] shrink-0",
						children: [/* @__PURE__ */ _jsxDEV("img", {
							src: "/figma/nft-emerald-ape-sm.webp",
							alt: "",
							width: 138,
							height: 138,
							className: "size-[138px] rounded-2xl object-cover"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("img", {
							src: "/figma/nft-sage-nomad-sm.webp",
							alt: "",
							width: 58,
							height: 58,
							className: "absolute left-[14px] top-[88px] size-[58px] rounded-2xl object-cover"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("img", {
					src: "/figma/m-hero-dots.svg",
					alt: "",
					"aria-hidden": true,
					width: 33,
					height: 7,
					className: "relative"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 5
	}, this);
}
_c = Hero;
const promos = [{
	title: ["Lançamentos gênesis", "de edição limitada"],
	text: "Colecione edições escassas diretamente dos criadores antes da revelação pública.",
	image: "/figma/nft-emerald-ape-sm.webp",
	imageClass: "left-[-5px] w-[292px] rounded-[18px]",
	search: { tab: "new" }
}, {
	title: ["Arte digital selecionada", "e muito mais"],
	text: "Explore novos artistas, coleções verificadas e obras digitais que definem a cultura.",
	image: "/figma/nft-neon-vessel-sm.webp",
	imageClass: "left-[2px] w-[287px] rounded-[17px]",
	search: { category: "art" }
}];
export function Promos() {
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "destaques",
		"aria-label": "Destaques",
		className: "grid scroll-mt-6 gap-7 md:grid-cols-2",
		children: promos.map((p) => /* @__PURE__ */ _jsxDEV("article", {
			className: "relative h-[250px] overflow-hidden rounded-lg bg-card",
			children: [
				/* @__PURE__ */ _jsxDEV("img", {
					src: p.image,
					alt: "",
					loading: "lazy",
					width: 292,
					height: 250,
					className: `absolute top-0 hidden h-[250px] object-cover sm:block ${p.imageClass}`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("img", {
					src: "/figma/promo-mask.svg",
					alt: "",
					"aria-hidden": true,
					className: "pointer-events-none absolute inset-0 size-full"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-y-0 right-[30px] flex w-[min(263px,calc(100%-60px))] flex-col items-end pt-[37px] text-right sm:w-[263px]",
					children: [
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-bold leading-6 text-foreground",
							children: [
								p.title[0],
								/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 15
								}, this),
								p.title[1]
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 text-sm leading-6 text-muted-foreground",
							children: p.text
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/",
							search: p.search,
							hash: "catalogo",
							className: "absolute top-[164px] flex h-10 w-[140px] items-center justify-center gap-1 rounded-[6px] bg-primary text-sm font-medium leading-5 text-primary-foreground hover:brightness-110",
							children: ["Explorar", /* @__PURE__ */ _jsxDEV(FigmaIcon, {
								name: "icon-arrow-right",
								width: 13,
								height: 11,
								className: "-rotate-90"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 113,
					columnNumber: 11
				}, this)
			]
		}, p.title[0], true, {
			fileName: _jsxFileName,
			lineNumber: 103,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 101,
		columnNumber: 5
	}, this);
}
_c2 = Promos;
const posts = [
	{
		date: "12 de setembro",
		read: "6 min",
		title: "Como funciona a propriedade de NFTs",
		text: "Aprenda a colecionar, negociar e verificar ativos digitais.",
		image: "/figma/nft-neon-vessel-sm.webp"
	},
	{
		date: "13 de setembro",
		read: "2 min",
		title: "10 artistas digitais para acompanhar",
		text: "Conheça criadores que moldam a cultura digital.",
		image: "/figma/nft-emerald-ape-sm.webp"
	},
	{
		date: "15 de setembro",
		read: "3 min",
		title: "Raridade, atributos e procedência",
		text: "Entenda raridade, procedência, direitos autorais e utilidade.",
		image: "/figma/nft-sage-nomad-sm.webp"
	},
	{
		date: "15 de setembro",
		read: "2 min",
		title: "Como proteger sua carteira",
		text: "Proteja sua carteira, seus ativos e sua identidade.",
		image: "/figma/nft-golden-beat-sm.webp"
	}
];
export function Blog() {
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "diario",
		"aria-labelledby": "diario-title",
		className: "flex scroll-mt-6 flex-col items-center gap-10",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col items-center gap-3 text-center",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				id: "diario-title",
				className: "text-[28px] font-bold leading-normal text-text-primary",
				children: "Diário da Cunhagem"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 147,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm leading-normal text-muted-foreground",
				children: "Histórias, guias e insights para colecionadores sobre o universo da propriedade digital."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 146,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("ul", {
			className: "grid w-full gap-6 sm:grid-cols-2 lg:flex",
			children: posts.map((p) => /* @__PURE__ */ _jsxDEV("li", {
				className: "flex flex-col overflow-hidden rounded-lg bg-card lg:w-[268px]",
				children: [/* @__PURE__ */ _jsxDEV("img", {
					src: p.image,
					alt: "",
					loading: "lazy",
					width: 268,
					height: 195,
					className: "h-[195px] w-full object-cover"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 157,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("article", {
					className: "flex flex-1 flex-col gap-2 px-4 pb-4 pt-3",
					children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "whitespace-pre-wrap text-xs font-medium leading-4 text-muted-foreground",
							children: `${p.date}  |  Leitura de ${p.read}`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-base font-bold leading-normal text-text-primary",
							children: p.title
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 162,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-medium leading-4 text-muted-foreground",
							children: p.text
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "flex gap-1 text-xs text-accent",
							"aria-hidden": true,
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold leading-[14px]",
								children: "Ler mais"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "→" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 166,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 158,
					columnNumber: 13
				}, this)]
			}, p.title, true, {
				fileName: _jsxFileName,
				lineNumber: 156,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 154,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 145,
		columnNumber: 5
	}, this);
}
_c3 = Blog;
var _c, _c2, _c3;
$RefreshReg$(_c, "Hero");
$RefreshReg$(_c2, "Promos");
$RefreshReg$(_c3, "Blog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/marketing/sections.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/marketing/sections.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/marketing/sections.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/marketing/sections.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsaUJBQWlCOzs7O0FBRzFCLE9BQU8sU0FBUyxPQUFPO0NBQ3JCLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLG1CQUFnQjtZQUF6QixDQUVFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBaUQ7T0FBb0I7Ozs7aUJBQ2xGLHdCQUFDLE1BQUQ7UUFBSSxJQUFHO1FBQWEsV0FBVTtrQkFBOUI7U0FBOEc7U0FFNUcsd0JBQUMsTUFBRCxDQUFLOzs7OztTQUFDO1FBRUo7Ozs7O2VBQ0Q7Ozs7O2dCQUNMLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF3RDtNQUdsRTs7OztjQUNBOzs7OztlQUNMLHdCQUFDLE1BQUQ7TUFDRSxJQUFHO01BQ0gsTUFBSztNQUNMLFdBQVU7Z0JBQ1g7S0FFSzs7OzthQUNIOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxLQUFJO0tBQXVCLEtBQUk7S0FBRztLQUFZLE9BQU87S0FBSSxRQUFRO0lBQUk7Ozs7WUFDdkU7Ozs7O2FBQ0wsd0JBQUMsT0FBRDtJQUNFLEtBQUk7SUFDSixLQUFJO0lBQ0osT0FBTztJQUNQLFFBQVE7SUFDUixlQUFjO0lBQ2QsV0FBVTtHQUNYOzs7O1dBQ0U7Ozs7O1lBR0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxLQUFJO0tBQXlCLEtBQUk7S0FBRztLQUFZLFdBQVU7SUFBOEI7Ozs7O0lBQzdGLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWdEO1FBQW9COzs7OztRQUNqRix3QkFBQyxNQUFEO1NBQUksSUFBRztTQUFlLFdBQVU7bUJBQWhDO1VBQTZGO1VBRTNGLHdCQUFDLE1BQUQsQ0FBSzs7Ozs7VUFBQztTQUVKOzs7Ozs7UUFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBK0M7UUFBeUQ7Ozs7O09BQ2xIOzs7OztnQkFDTCx3QkFBQyxNQUFEO09BQU0sSUFBRztPQUFJLE1BQUs7T0FBVyxXQUFVO2lCQUF2QyxDQUE4RyxZQUU1Ryx3QkFBQyxXQUFEO1FBQVcsTUFBSztRQUFnQixPQUFPO1FBQUksUUFBUTtRQUFHLFdBQVU7T0FBYzs7OztlQUMxRTs7Ozs7Y0FDSDs7Ozs7ZUFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxLQUFJO09BQWlDLEtBQUk7T0FBRyxPQUFPO09BQUssUUFBUTtPQUFLLFdBQVU7TUFBeUM7Ozs7Z0JBQzdILHdCQUFDLE9BQUQ7T0FDRSxLQUFJO09BQ0osS0FBSTtPQUNKLE9BQU87T0FDUCxRQUFRO09BQ1IsV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7O2FBQ0Y7Ozs7OztJQUNMLHdCQUFDLE9BQUQ7S0FBSyxLQUFJO0tBQXlCLEtBQUk7S0FBRztLQUFZLE9BQU87S0FBSSxRQUFRO0tBQUcsV0FBVTtJQUFZOzs7OztHQUM5Rjs7Ozs7VUFDRTs7Ozs7O0FBRWI7O0FBRUEsTUFBTSxTQUFTLENBQ2I7Q0FDRSxPQUFPLENBQUMsdUJBQXVCLG9CQUFvQjtDQUNuRCxNQUFNO0NBQ04sT0FBTztDQUNQLFlBQVk7Q0FDWixRQUFRLEVBQUUsS0FBSyxNQUFlO0FBQ2hDLEdBQ0E7Q0FDRSxPQUFPLENBQUMsNEJBQTRCLGNBQWM7Q0FDbEQsTUFBTTtDQUNOLE9BQU87Q0FDUCxZQUFZO0NBQ1osUUFBUSxFQUFFLFVBQVUsTUFBZTtBQUNyQyxDQUNGO0FBRUEsT0FBTyxTQUFTLFNBQVM7Q0FDdkIsT0FDRSx3QkFBQyxXQUFEO0VBQVMsSUFBRztFQUFZLGNBQVc7RUFBWSxXQUFVO1lBQ3RELE9BQU8sS0FBSyxNQUNYLHdCQUFDLFdBQUQ7R0FBMEIsV0FBVTthQUFwQztJQUNFLHdCQUFDLE9BQUQ7S0FDRSxLQUFLLEVBQUU7S0FDUCxLQUFJO0tBQ0osU0FBUTtLQUNSLE9BQU87S0FDUCxRQUFRO0tBQ1IsV0FBVyx5REFBeUQsRUFBRTtJQUN2RTs7Ozs7SUFDRCx3QkFBQyxPQUFEO0tBQUssS0FBSTtLQUF3QixLQUFJO0tBQUc7S0FBWSxXQUFVO0lBQWtEOzs7OztJQUNoSCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRyxFQUFFLE1BQU07UUFDVCx3QkFBQyxNQUFELENBQUs7Ozs7O1FBQ0osRUFBRSxNQUFNO09BQ1A7Ozs7OztNQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFnRCxFQUFFO01BQVE7Ozs7O01BQ3ZFLHdCQUFDLE1BQUQ7T0FDRSxJQUFHO09BQ0gsUUFBUSxFQUFFO09BQ1YsTUFBSztPQUNMLFdBQVU7aUJBSlosQ0FLQyxZQUVDLHdCQUFDLFdBQUQ7UUFBVyxNQUFLO1FBQW1CLE9BQU87UUFBSSxRQUFRO1FBQUksV0FBVTtPQUFjOzs7O2VBQzlFOzs7Ozs7S0FDSDs7Ozs7O0dBQ0U7S0EzQkssRUFBRSxNQUFNOzs7O1NBMkJiLENBQ1Y7Q0FDTTs7Ozs7QUFFYjs7QUFFQSxNQUFNLFFBQVE7Q0FDWjtFQUFFLE1BQU07RUFBa0IsTUFBTTtFQUFTLE9BQU87RUFBdUMsTUFBTTtFQUErRCxPQUFPO0NBQWlDO0NBQ3BNO0VBQUUsTUFBTTtFQUFrQixNQUFNO0VBQVMsT0FBTztFQUF3QyxNQUFNO0VBQW1ELE9BQU87Q0FBaUM7Q0FDekw7RUFBRSxNQUFNO0VBQWtCLE1BQU07RUFBUyxPQUFPO0VBQXFDLE1BQU07RUFBaUUsT0FBTztDQUFnQztDQUNuTTtFQUFFLE1BQU07RUFBa0IsTUFBTTtFQUFTLE9BQU87RUFBOEIsTUFBTTtFQUF1RCxPQUFPO0NBQWlDO0FBQ3JMO0FBRUEsT0FBTyxTQUFTLE9BQU87Q0FDckIsT0FDRSx3QkFBQyxXQUFEO0VBQVMsSUFBRztFQUFTLG1CQUFnQjtFQUFlLFdBQVU7WUFBOUQsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsTUFBRDtJQUFJLElBQUc7SUFBZSxXQUFVO2NBQXlEO0dBRXJGOzs7O2FBQ0osd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBK0M7R0FFekQ7Ozs7V0FDQTs7Ozs7WUFDTCx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUNYLE1BQU0sS0FBSyxNQUNWLHdCQUFDLE1BQUQ7SUFBa0IsV0FBVTtjQUE1QixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxLQUFLLEVBQUU7S0FBTyxLQUFJO0tBQUcsU0FBUTtLQUFPLE9BQU87S0FBSyxRQUFRO0tBQUssV0FBVTtJQUFpQzs7OztjQUM3Ryx3QkFBQyxXQUFEO0tBQVMsV0FBVTtlQUFuQjtNQUNFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUNWLEdBQUcsRUFBRSxLQUFLLGtCQUFrQixFQUFFO01BQzlCOzs7OztNQUNILHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUF3RCxFQUFFO01BQVU7Ozs7O01BQ2xGLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF1RCxFQUFFO01BQVE7Ozs7O01BQzlFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO09BQWlDO2lCQUE5QyxDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUEyQjtPQUFjOzs7O2lCQUN6RCx3QkFBQyxRQUFELFlBQU0sSUFBTzs7OztlQUNaOzs7Ozs7S0FDSTs7Ozs7WUFDUDtNQWJLLEVBQUU7Ozs7VUFhUCxDQUNMO0VBQ0M7Ozs7VUFDRzs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsic2VjdGlvbnMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgRmlnbWFJY29uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2ZpZ21hLWljb24nXG5cbi8qKiBIZXJvIGRhIHDDoWdpbmEgaW5pY2lhbCAoZGVza3RvcCAxMjAww5c0NTAgLyBtb2JpbGUgMzY2w5cxOTAgbm8gbGF5b3V0KS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBIZXJvKCkge1xuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGFyaWEtbGFiZWxsZWRieT1cImhlcm8tdGl0bGVcIj5cbiAgICAgIHsvKiBEZXNrdG9wICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gaC1bNDUwcHhdIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGwtMTAgbWQ6ZmxleFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1bNjAwcHhdIG1heC13LVs1MiVdIGZsZXgtY29sIGl0ZW1zLWVuZCBnYXAtMTFcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIGZsZXgtY29sIGdhcC04XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0yIHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gbGVhZGluZy00IHRyYWNraW5nLVsxLjRweF1cIj5CZW0tdmluZG8gw6AgS3VyaW88L3A+XG4gICAgICAgICAgICAgICAgPGgxIGlkPVwiaGVyby10aXRsZVwiIGNsYXNzTmFtZT1cInRleHQtWzQzcHhdIGZvbnQtYm9sZCBsZWFkaW5nLVs3MHB4XSBtYXgtbGc6dGV4dC1bMzRweF0gbWF4LWxnOmxlYWRpbmctWzUycHhdXCI+XG4gICAgICAgICAgICAgICAgICBTRUpBIERPTk8gRE8gRlVUVVJPXG4gICAgICAgICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgICAgICAgIERBIEFSVEUgRElHSVRBTFxuICAgICAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYXgtdy1bNTU3cHhdIHRleHQtc20gbGVhZGluZy02IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgIERlc2N1YnJhIE5GVHMgc2VsZWNpb25hZG9zIGRlIGNyaWFkb3JlcyBlbWVyZ2VudGVzIGUgY29uc2FncmFkb3MuIENvbGVjaW9uZSBhcnRlIGRpZ2l0YWwgcmFyYSwgYXBvaWUgYXJ0aXN0YXMgZVxuICAgICAgICAgICAgICAgIHRlbmhhIHVtYSBwYXJ0ZSBkYSBjdWx0dXJhIGRhIGludGVybmV0LlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgIHRvPVwiL1wiXG4gICAgICAgICAgICAgIGhhc2g9XCJjYXRhbG9nb1wiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC0xMCB3LVsxNDBweF0gaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtWzZweF0gYmctcHJpbWFyeSB0ZXh0LWJhc2UgZm9udC1ib2xkIGxlYWRpbmctNSB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBob3ZlcjpicmlnaHRuZXNzLTExMFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEVYUExPUkFSXG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGltZyBzcmM9XCIvZmlnbWEvaGVyby1kb3RzLnN2Z1wiIGFsdD1cIlwiIGFyaWEtaGlkZGVuIHdpZHRoPXs0MH0gaGVpZ2h0PXs4fSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGltZ1xuICAgICAgICAgIHNyYz1cIi9maWdtYS9uZnQtZW1lcmFsZC1hcGUud2VicFwiXG4gICAgICAgICAgYWx0PVwiRW1lcmFsZCBBcGUgIzA0MjogbWFjYWNvIGRlIMOzY3Vsb3MgcmVkb25kb3MgZSBqYXF1ZXRhIHZlcmRlXCJcbiAgICAgICAgICB3aWR0aD17NDUwfVxuICAgICAgICAgIGhlaWdodD17NDUwfVxuICAgICAgICAgIGZldGNoUHJpb3JpdHk9XCJoaWdoXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhc3BlY3Qtc3F1YXJlIHctWzQ1MHB4XSBtYXgtdy1bNDUlXSByb3VuZGVkLTN4bCBvYmplY3QtY292ZXJcIlxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNb2JpbGUgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaC1bMTkwcHhdIGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBwLTQgbWQ6aGlkZGVuXCI+XG4gICAgICAgIDxpbWcgc3JjPVwiL2ZpZ21hL20taGVyby1tYXNrLnN2Z1wiIGFsdD1cIlwiIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgc2l6ZS1mdWxsXCIgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IHctZnVsbCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLXctMCBmbGV4LTEgZmxleC1jb2xcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gbGVhZGluZy00IHRleHQtZm9yZWdyb3VuZFwiPkJlbS12aW5kbyDDoCBLdXJpbzwvcD5cbiAgICAgICAgICAgICAgPGgxIGlkPVwiaGVyby10aXRsZS1tXCIgY2xhc3NOYW1lPVwidy1bMTkwcHhdIHRleHQtbGcgZm9udC1ib2xkIGxlYWRpbmctWzI5cHhdIHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgIFNFSkEgRE9OTyBEQVxuICAgICAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgICAgIENVTFRVUkEgRElHSVRBTFxuICAgICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGxlYWRpbmctWzE4cHhdIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkRlc2N1YnJhIE5GVHMgc2VsZWNpb25hZG9zIGRlIGNyaWFkb3JlcyBkbyBtdW5kbyB0b2RvLjwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPExpbmsgdG89XCIvXCIgaGFzaD1cImNhdGFsb2dvXCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LWJvbGQgbGVhZGluZy1bMTRweF0gdGV4dC1hY2NlbnRcIj5cbiAgICAgICAgICAgICAgRVhQTE9SQVJcbiAgICAgICAgICAgICAgPEZpZ21hSWNvbiBuYW1lPVwibS1hcnJvdy1yaWdodFwiIHdpZHRoPXsxMH0gaGVpZ2h0PXs4fSBjbGFzc05hbWU9XCItcm90YXRlLTkwXCIgLz5cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHNpemUtWzEzOHB4XSBzaHJpbmstMFwiPlxuICAgICAgICAgICAgPGltZyBzcmM9XCIvZmlnbWEvbmZ0LWVtZXJhbGQtYXBlLXNtLndlYnBcIiBhbHQ9XCJcIiB3aWR0aD17MTM4fSBoZWlnaHQ9ezEzOH0gY2xhc3NOYW1lPVwic2l6ZS1bMTM4cHhdIHJvdW5kZWQtMnhsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgIHNyYz1cIi9maWdtYS9uZnQtc2FnZS1ub21hZC1zbS53ZWJwXCJcbiAgICAgICAgICAgICAgYWx0PVwiXCJcbiAgICAgICAgICAgICAgd2lkdGg9ezU4fVxuICAgICAgICAgICAgICBoZWlnaHQ9ezU4fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LVsxNHB4XSB0b3AtWzg4cHhdIHNpemUtWzU4cHhdIHJvdW5kZWQtMnhsIG9iamVjdC1jb3ZlclwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGltZyBzcmM9XCIvZmlnbWEvbS1oZXJvLWRvdHMuc3ZnXCIgYWx0PVwiXCIgYXJpYS1oaWRkZW4gd2lkdGg9ezMzfSBoZWlnaHQ9ezd9IGNsYXNzTmFtZT1cInJlbGF0aXZlXCIgLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKVxufVxuXG5jb25zdCBwcm9tb3MgPSBbXG4gIHtcbiAgICB0aXRsZTogWydMYW7Dp2FtZW50b3MgZ8OqbmVzaXMnLCAnZGUgZWRpw6fDo28gbGltaXRhZGEnXSxcbiAgICB0ZXh0OiAnQ29sZWNpb25lIGVkacOnw7VlcyBlc2Nhc3NhcyBkaXJldGFtZW50ZSBkb3MgY3JpYWRvcmVzIGFudGVzIGRhIHJldmVsYcOnw6NvIHDDumJsaWNhLicsXG4gICAgaW1hZ2U6ICcvZmlnbWEvbmZ0LWVtZXJhbGQtYXBlLXNtLndlYnAnLFxuICAgIGltYWdlQ2xhc3M6ICdsZWZ0LVstNXB4XSB3LVsyOTJweF0gcm91bmRlZC1bMThweF0nLFxuICAgIHNlYXJjaDogeyB0YWI6ICduZXcnIGFzIGNvbnN0IH0sXG4gIH0sXG4gIHtcbiAgICB0aXRsZTogWydBcnRlIGRpZ2l0YWwgc2VsZWNpb25hZGEnLCAnZSBtdWl0byBtYWlzJ10sXG4gICAgdGV4dDogJ0V4cGxvcmUgbm92b3MgYXJ0aXN0YXMsIGNvbGXDp8O1ZXMgdmVyaWZpY2FkYXMgZSBvYnJhcyBkaWdpdGFpcyBxdWUgZGVmaW5lbSBhIGN1bHR1cmEuJyxcbiAgICBpbWFnZTogJy9maWdtYS9uZnQtbmVvbi12ZXNzZWwtc20ud2VicCcsXG4gICAgaW1hZ2VDbGFzczogJ2xlZnQtWzJweF0gdy1bMjg3cHhdIHJvdW5kZWQtWzE3cHhdJyxcbiAgICBzZWFyY2g6IHsgY2F0ZWdvcnk6ICdhcnQnIGFzIGNvbnN0IH0sXG4gIH0sXG5dXG5cbmV4cG9ydCBmdW5jdGlvbiBQcm9tb3MoKSB7XG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gaWQ9XCJkZXN0YXF1ZXNcIiBhcmlhLWxhYmVsPVwiRGVzdGFxdWVzXCIgY2xhc3NOYW1lPVwiZ3JpZCBzY3JvbGwtbXQtNiBnYXAtNyBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAge3Byb21vcy5tYXAoKHApID0+IChcbiAgICAgICAgPGFydGljbGUga2V5PXtwLnRpdGxlWzBdfSBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLVsyNTBweF0gb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtbGcgYmctY2FyZFwiPlxuICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgIHNyYz17cC5pbWFnZX1cbiAgICAgICAgICAgIGFsdD1cIlwiXG4gICAgICAgICAgICBsb2FkaW5nPVwibGF6eVwiXG4gICAgICAgICAgICB3aWR0aD17MjkyfVxuICAgICAgICAgICAgaGVpZ2h0PXsyNTB9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtMCBoaWRkZW4gaC1bMjUwcHhdIG9iamVjdC1jb3ZlciBzbTpibG9jayAke3AuaW1hZ2VDbGFzc31gfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGltZyBzcmM9XCIvZmlnbWEvcHJvbW8tbWFzay5zdmdcIiBhbHQ9XCJcIiBhcmlhLWhpZGRlbiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGluc2V0LTAgc2l6ZS1mdWxsXCIgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCByaWdodC1bMzBweF0gZmxleCB3LVttaW4oMjYzcHgsY2FsYygxMDAlLTYwcHgpKV0gZmxleC1jb2wgaXRlbXMtZW5kIHB0LVszN3B4XSB0ZXh0LXJpZ2h0IHNtOnctWzI2M3B4XVwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIGxlYWRpbmctNiB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAge3AudGl0bGVbMF19XG4gICAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgICB7cC50aXRsZVsxXX1cbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gbGVhZGluZy02IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntwLnRleHR9PC9wPlxuICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgdG89XCIvXCJcbiAgICAgICAgICAgICAgc2VhcmNoPXtwLnNlYXJjaH1cbiAgICAgICAgICAgICAgaGFzaD1cImNhdGFsb2dvXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLVsxNjRweF0gZmxleCBoLTEwIHctWzE0MHB4XSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEgcm91bmRlZC1bNnB4XSBiZy1wcmltYXJ5IHRleHQtc20gZm9udC1tZWRpdW0gbGVhZGluZy01IHRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kIGhvdmVyOmJyaWdodG5lc3MtMTEwXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgRXhwbG9yYXJcbiAgICAgICAgICAgICAgPEZpZ21hSWNvbiBuYW1lPVwiaWNvbi1hcnJvdy1yaWdodFwiIHdpZHRoPXsxM30gaGVpZ2h0PXsxMX0gY2xhc3NOYW1lPVwiLXJvdGF0ZS05MFwiIC8+XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvYXJ0aWNsZT5cbiAgICAgICkpfVxuICAgIDwvc2VjdGlvbj5cbiAgKVxufVxuXG5jb25zdCBwb3N0cyA9IFtcbiAgeyBkYXRlOiAnMTIgZGUgc2V0ZW1icm8nLCByZWFkOiAnNiBtaW4nLCB0aXRsZTogJ0NvbW8gZnVuY2lvbmEgYSBwcm9wcmllZGFkZSBkZSBORlRzJywgdGV4dDogJ0FwcmVuZGEgYSBjb2xlY2lvbmFyLCBuZWdvY2lhciBlIHZlcmlmaWNhciBhdGl2b3MgZGlnaXRhaXMuJywgaW1hZ2U6ICcvZmlnbWEvbmZ0LW5lb24tdmVzc2VsLXNtLndlYnAnIH0sXG4gIHsgZGF0ZTogJzEzIGRlIHNldGVtYnJvJywgcmVhZDogJzIgbWluJywgdGl0bGU6ICcxMCBhcnRpc3RhcyBkaWdpdGFpcyBwYXJhIGFjb21wYW5oYXInLCB0ZXh0OiAnQ29uaGXDp2EgY3JpYWRvcmVzIHF1ZSBtb2xkYW0gYSBjdWx0dXJhIGRpZ2l0YWwuJywgaW1hZ2U6ICcvZmlnbWEvbmZ0LWVtZXJhbGQtYXBlLXNtLndlYnAnIH0sXG4gIHsgZGF0ZTogJzE1IGRlIHNldGVtYnJvJywgcmVhZDogJzMgbWluJywgdGl0bGU6ICdSYXJpZGFkZSwgYXRyaWJ1dG9zIGUgcHJvY2Vkw6puY2lhJywgdGV4dDogJ0VudGVuZGEgcmFyaWRhZGUsIHByb2NlZMOqbmNpYSwgZGlyZWl0b3MgYXV0b3JhaXMgZSB1dGlsaWRhZGUuJywgaW1hZ2U6ICcvZmlnbWEvbmZ0LXNhZ2Utbm9tYWQtc20ud2VicCcgfSxcbiAgeyBkYXRlOiAnMTUgZGUgc2V0ZW1icm8nLCByZWFkOiAnMiBtaW4nLCB0aXRsZTogJ0NvbW8gcHJvdGVnZXIgc3VhIGNhcnRlaXJhJywgdGV4dDogJ1Byb3RlamEgc3VhIGNhcnRlaXJhLCBzZXVzIGF0aXZvcyBlIHN1YSBpZGVudGlkYWRlLicsIGltYWdlOiAnL2ZpZ21hL25mdC1nb2xkZW4tYmVhdC1zbS53ZWJwJyB9LFxuXVxuXG5leHBvcnQgZnVuY3Rpb24gQmxvZygpIHtcbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBpZD1cImRpYXJpb1wiIGFyaWEtbGFiZWxsZWRieT1cImRpYXJpby10aXRsZVwiIGNsYXNzTmFtZT1cImZsZXggc2Nyb2xsLW10LTYgZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0xMFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LWNlbnRlclwiPlxuICAgICAgICA8aDIgaWQ9XCJkaWFyaW8tdGl0bGVcIiBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBmb250LWJvbGQgbGVhZGluZy1ub3JtYWwgdGV4dC10ZXh0LXByaW1hcnlcIj5cbiAgICAgICAgICBEacOhcmlvIGRhIEN1bmhhZ2VtXG4gICAgICAgIDwvaDI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gbGVhZGluZy1ub3JtYWwgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgSGlzdMOzcmlhcywgZ3VpYXMgZSBpbnNpZ2h0cyBwYXJhIGNvbGVjaW9uYWRvcmVzIHNvYnJlIG8gdW5pdmVyc28gZGEgcHJvcHJpZWRhZGUgZGlnaXRhbC5cbiAgICAgICAgPC9wPlxuICAgICAgPC9kaXY+XG4gICAgICA8dWwgY2xhc3NOYW1lPVwiZ3JpZCB3LWZ1bGwgZ2FwLTYgc206Z3JpZC1jb2xzLTIgbGc6ZmxleFwiPlxuICAgICAgICB7cG9zdHMubWFwKChwKSA9PiAoXG4gICAgICAgICAgPGxpIGtleT17cC50aXRsZX0gY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1sZyBiZy1jYXJkIGxnOnctWzI2OHB4XVwiPlxuICAgICAgICAgICAgPGltZyBzcmM9e3AuaW1hZ2V9IGFsdD1cIlwiIGxvYWRpbmc9XCJsYXp5XCIgd2lkdGg9ezI2OH0gaGVpZ2h0PXsxOTV9IGNsYXNzTmFtZT1cImgtWzE5NXB4XSB3LWZ1bGwgb2JqZWN0LWNvdmVyXCIgLz5cbiAgICAgICAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cImZsZXggZmxleC0xIGZsZXgtY29sIGdhcC0yIHB4LTQgcGItNCBwdC0zXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIndoaXRlc3BhY2UtcHJlLXdyYXAgdGV4dC14cyBmb250LW1lZGl1bSBsZWFkaW5nLTQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAge2Ake3AuZGF0ZX0gIHwgIExlaXR1cmEgZGUgJHtwLnJlYWR9YH1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCBsZWFkaW5nLW5vcm1hbCB0ZXh0LXRleHQtcHJpbWFyeVwiPntwLnRpdGxlfTwvaDM+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gbGVhZGluZy00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntwLnRleHR9PC9wPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmbGV4IGdhcC0xIHRleHQteHMgdGV4dC1hY2NlbnRcIiBhcmlhLWhpZGRlbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgbGVhZGluZy1bMTRweF1cIj5MZXIgbWFpczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3Bhbj7ihpI8L3NwYW4+XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvYXJ0aWNsZT5cbiAgICAgICAgICA8L2xpPlxuICAgICAgICApKX1cbiAgICAgIDwvdWw+XG4gICAgPC9zZWN0aW9uPlxuICApXG59XG4iXX0=