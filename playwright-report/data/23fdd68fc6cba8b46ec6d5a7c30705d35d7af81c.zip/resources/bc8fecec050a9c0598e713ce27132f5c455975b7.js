import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/home.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport14_react_jsxDevRuntime["jsxDEV"];import { getRouteApi } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { CatalogGridSkeleton, CatalogTabs, FeaturedBanner, Pagination, SortSelect } from "/src/components/catalog/catalog-parts.tsx";
import { Filters } from "/src/components/catalog/filters.tsx";
import { EmptyState, ErrorState } from "/src/components/common/states.tsx";
import { Blog, Hero, Promos } from "/src/components/marketing/sections.tsx";
import { NftCard } from "/src/components/nft/nft-card.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "/src/components/ui/dialog.tsx";
import { FigmaIcon } from "/src/components/ui/figma-icon.tsx";
import { useNftList } from "/src/hooks/use-api.ts";
import { useIsDesktop } from "/src/hooks/use-media.ts";
import { usePageTitle } from "/src/hooks/use-page.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/pages/home.tsx";
import __vite__cjsImport14_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const route = getRouteApi("/");
const PAGE_SIZE = 9;
function toParams(s) {
	return {
		q: s.q || undefined,
		category: s.category,
		chain: s.chain,
		minPrice: s.minPrice !== undefined ? String(s.minPrice) : undefined,
		maxPrice: s.maxPrice !== undefined ? String(s.maxPrice) : undefined,
		availableOnly: s.available || undefined,
		featuredOnly: s.tab === "trending" || undefined,
		newOnly: s.tab === "new" || undefined,
		sort: s.sort ?? "newest",
		page: s.page ?? 1,
		pageSize: PAGE_SIZE
	};
}
function hasActiveFilters(s) {
	return Boolean(s.q || s.category || s.chain || s.minPrice !== undefined || s.maxPrice !== undefined || s.available || s.tab);
}
export function HomePage() {
	_s();
	usePageTitle("Início");
	const search = route.useSearch();
	const navigate = route.useNavigate();
	const isDesktop = useIsDesktop();
	const list = useNftList(toParams(search));
	const filtersActive = hasActiveFilters(search);
	const [filtersOpen, setFiltersOpen] = useState(false);
	// Mudar qualquer filtro reinicia a paginação; a tela não rola para o topo.
	const update = (patch) => void navigate({
		search: (prev) => ({
			...prev,
			...patch,
			page: undefined
		}),
		replace: true,
		resetScroll: false
	});
	const clearAll = () => void navigate({
		search: { sort: search.sort },
		replace: true,
		resetScroll: false
	});
	// Página fora do intervalo (URL antiga/editada): volta para a última existente.
	const data = list.data;
	useEffect(() => {
		if (!data) return;
		if (data.totalPages > 0 && data.page > data.totalPages) {
			void navigate({
				search: (prev) => ({
					...prev,
					page: data.totalPages > 1 ? data.totalPages : undefined
				}),
				replace: true
			});
		} else if (data.totalPages === 0 && data.page > 1) {
			void navigate({
				search: (prev) => ({
					...prev,
					page: undefined
				}),
				replace: true
			});
		}
	}, [data, navigate]);
	const page = search.page ?? 1;
	const filterValues = {
		category: search.category,
		chain: search.chain,
		minPrice: search.minPrice,
		maxPrice: search.maxPrice
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-4 md:gap-24",
		children: [
			!isDesktop ? /* @__PURE__ */ _jsxDEV(MobileSearchBar, {
				value: search.q ?? "",
				onSearch: (q) => update({ q: q || undefined }),
				onOpenFilters: () => setFiltersOpen(true)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 21
			}, this) : null,
			/* @__PURE__ */ _jsxDEV(Hero, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "catalogo",
				"aria-labelledby": "catalogo-title",
				className: "flex scroll-mt-6 items-start gap-12",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						id: "catalogo-title",
						className: "sr-only",
						children: "Catálogo"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 9
					}, this),
					isDesktop ? /* @__PURE__ */ _jsxDEV("aside", {
						"aria-label": "Filtros do catálogo",
						className: "flex w-[310px] shrink-0 flex-col gap-6",
						children: [/* @__PURE__ */ _jsxDEV(Filters, {
							values: filterValues,
							facets: list.data?.facets,
							onChange: update
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(FeaturedBanner, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV(Dialog, {
						open: filtersOpen,
						onOpenChange: setFiltersOpen,
						children: /* @__PURE__ */ _jsxDEV(DialogContent, {
							className: "max-h-[85dvh] overflow-y-auto p-0",
							children: [
								/* @__PURE__ */ _jsxDEV(DialogTitle, {
									className: "sr-only",
									children: "Filtros do catálogo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 93,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(DialogDescription, {
									className: "sr-only",
									children: "Refine os NFTs por coleção, preço e rede."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Filters, {
									values: filterValues,
									facets: list.data?.facets,
									onChange: (patch) => {
										update(patch);
										setFiltersOpen(false);
									},
									className: "pt-12"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 95,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex min-w-0 flex-1 flex-col items-end gap-10 md:gap-[88px]",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex w-full flex-col gap-4 md:gap-8",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap items-center justify-between gap-4",
									children: [/* @__PURE__ */ _jsxDEV(CatalogTabs, { active: search.tab ?? "all" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 111,
										columnNumber: 15
									}, this), isDesktop ? /* @__PURE__ */ _jsxDEV(SortSelect, {
										value: search.sort ?? "newest",
										onChange: (sort) => update({ sort })
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 112,
										columnNumber: 28
									}, this) : null]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 110,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									"aria-live": "polite",
									className: "sr-only",
									"data-testid": "result-count",
									children: [list.isSuccess ? `${list.data.total} ${list.data.total === 1 ? "resultado" : "resultados"}` : "", list.isFetching && list.isSuccess ? " · atualizando…" : ""]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 13
								}, this),
								filtersActive ? /* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap items-center gap-3 text-sm text-muted-foreground",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: [list.data ? `${list.data.total} ${list.data.total === 1 ? "resultado" : "resultados"}` : "Filtrando…", search.q ? ` para “${search.q}”` : ""] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 122,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: clearAll,
										className: "font-bold text-accent underline-offset-4 hover:underline",
										children: "Limpar filtros"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 126,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 121,
									columnNumber: 15
								}, this) : null,
								list.isError ? /* @__PURE__ */ _jsxDEV(ErrorState, {
									error: list.error,
									onRetry: () => void list.refetch(),
									retrying: list.isFetching
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 15
								}, this) : list.isPending ? /* @__PURE__ */ _jsxDEV("div", {
									className: gridClass,
									"aria-busy": true,
									"aria-label": "Carregando NFTs",
									children: /* @__PURE__ */ _jsxDEV(CatalogGridSkeleton, { count: isDesktop ? 9 : 4 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 136,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 15
								}, this) : list.data.items.length === 0 ? /* @__PURE__ */ _jsxDEV(EmptyState, {
									title: "Nenhum NFT encontrado",
									description: "Tente outros termos ou remova alguns filtros para ver mais resultados.",
									action: filtersActive ? /* @__PURE__ */ _jsxDEV(Button, {
										variant: "outline",
										onClick: clearAll,
										children: "Limpar filtros"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 144,
										columnNumber: 21
									}, this) : undefined
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 139,
									columnNumber: 15
								}, this) : /* @__PURE__ */ _jsxDEV("ul", {
									className: cn(gridClass, "transition-opacity"),
									style: { opacity: list.isPlaceholderData ? .55 : 1 },
									"data-testid": "catalog-grid",
									children: list.data.items.map((n) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(NftCard, { nft: n }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 158,
										columnNumber: 21
									}, this) }, n.id, false, {
										fileName: _jsxFileName,
										lineNumber: 157,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 151,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 11
						}, this), list.data && list.data.totalPages > 1 ? /* @__PURE__ */ _jsxDEV(Pagination, {
							page,
							totalPages: list.data.totalPages
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 52
						}, this) : null]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Promos, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 169,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Blog, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 170,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 76,
		columnNumber: 5
	}, this);
}
_s(HomePage, "i2tfIP4rAy40Hyoy9YI9pHOlGCU=", false, function() {
	return [
		usePageTitle,
		route.useSearch,
		route.useNavigate,
		useIsDesktop,
		useNftList
	];
});
_c = HomePage;
/** Desktop: 3 colunas de 258px; mobile: 2 colunas com a direita deslocada (grade escalonada do layout). */
const gridClass = "grid w-full grid-cols-2 gap-x-4 gap-y-6 max-md:[&>*:nth-child(even)]:pt-8 md:grid-cols-3 md:gap-x-[34px] md:gap-y-[72px]";
function MobileSearchBar({ value, onSearch, onOpenFilters }) {
	_s2();
	const [text, setText] = useState(value);
	const timer = useRef(undefined);
	useEffect(() => setText(value), [value]);
	useEffect(() => () => clearTimeout(timer.current), []);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex h-[45px] gap-2",
		children: [/* @__PURE__ */ _jsxDEV("form", {
			role: "search",
			className: "flex h-full flex-1 items-center gap-2 rounded-[10px] bg-card px-3",
			onSubmit: (e) => {
				e.preventDefault();
				clearTimeout(timer.current);
				onSearch(text.trim());
			},
			children: [
				/* @__PURE__ */ _jsxDEV(FigmaIcon, {
					name: "m-search",
					width: 22,
					className: "text-subtle"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 204,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "m-search",
					className: "sr-only",
					children: "Buscar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 205,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					id: "m-search",
					type: "search",
					autoComplete: "off",
					placeholder: "Explorar coleções",
					value: text,
					onChange: (e) => {
						const next = e.target.value;
						setText(next);
						clearTimeout(timer.current);
						timer.current = setTimeout(() => onSearch(next.trim()), 350);
					},
					className: "h-full min-w-0 flex-1 bg-transparent text-sm font-bold leading-4 text-foreground outline-none placeholder:font-bold"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 208,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 195,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			"aria-label": "Abrir filtros",
			onClick: onOpenFilters,
			className: "grid size-[45px] shrink-0 place-items-center rounded-[14px] bg-[linear-gradient(137deg,rgba(210,138,76,0.45)_24.6%,#d28a4c_100%)] text-primary-foreground",
			children: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
				name: "m-filter",
				width: 16,
				height: 16
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 229,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 223,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 194,
		columnNumber: 5
	}, this);
}
_s2(MobileSearchBar, "OpsFEEglu+4I9srVZgRuM4L0V1U=");
_c2 = MobileSearchBar;
var _c, _c2;
$RefreshReg$(_c, "HomePage");
$RefreshReg$(_c2, "MobileSearchBar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/home.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/pages/home.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/pages/home.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/pages/home.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBRTVDLFNBQVMscUJBQXFCLGFBQWEsZ0JBQWdCLFlBQVksa0JBQWtCO0FBQ3pGLFNBQTRCLGVBQWU7QUFDM0MsU0FBUyxZQUFZLGtCQUFrQjtBQUN2QyxTQUFTLE1BQU0sTUFBTSxjQUFjO0FBQ25DLFNBQVMsZUFBZTtBQUN4QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxRQUFRLGVBQWUsbUJBQW1CLG1CQUFtQjtBQUN0RSxTQUFTLGlCQUFpQjtBQUMxQixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLFVBQVU7Ozs7QUFHbkIsTUFBTSxRQUFRLFlBQVksR0FBRztBQUM3QixNQUFNLFlBQVk7QUFFbEIsU0FBUyxTQUFTLEdBQXVDO0NBQ3ZELE9BQU87RUFDTCxHQUFHLEVBQUUsS0FBSztFQUNWLFVBQVUsRUFBRTtFQUNaLE9BQU8sRUFBRTtFQUNULFVBQVUsRUFBRSxhQUFhLFlBQVksT0FBTyxFQUFFLFFBQVEsSUFBSTtFQUMxRCxVQUFVLEVBQUUsYUFBYSxZQUFZLE9BQU8sRUFBRSxRQUFRLElBQUk7RUFDMUQsZUFBZSxFQUFFLGFBQWE7RUFDOUIsY0FBYyxFQUFFLFFBQVEsY0FBYztFQUN0QyxTQUFTLEVBQUUsUUFBUSxTQUFTO0VBQzVCLE1BQU0sRUFBRSxRQUFRO0VBQ2hCLE1BQU0sRUFBRSxRQUFRO0VBQ2hCLFVBQVU7Q0FDWjtBQUNGO0FBRUEsU0FBUyxpQkFBaUIsR0FBZTtDQUN2QyxPQUFPLFFBQVEsRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxhQUFhLGFBQWEsRUFBRSxhQUFhLGFBQWEsRUFBRSxhQUFhLEVBQUUsR0FBRztBQUM3SDtBQUVBLE9BQU8sU0FBUyxXQUFXOztDQUN6QixhQUFhLFFBQVE7Q0FDckIsTUFBTSxTQUFTLE1BQU0sVUFBVTtDQUMvQixNQUFNLFdBQVcsTUFBTSxZQUFZO0NBQ25DLE1BQU0sWUFBWSxhQUFhO0NBQy9CLE1BQU0sT0FBTyxXQUFXLFNBQVMsTUFBTSxDQUFDO0NBQ3hDLE1BQU0sZ0JBQWdCLGlCQUFpQixNQUFNO0NBQzdDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7O0NBR3BELE1BQU0sVUFBVSxVQUNkLEtBQUssU0FBUztFQUFFLFNBQVMsVUFBVTtHQUFFLEdBQUc7R0FBTSxHQUFHO0dBQU8sTUFBTTtFQUFVO0VBQUksU0FBUztFQUFNLGFBQWE7Q0FBTSxDQUFDO0NBRWpILE1BQU0saUJBQWlCLEtBQUssU0FBUztFQUFFLFFBQVEsRUFBRSxNQUFNLE9BQU8sS0FBSztFQUFHLFNBQVM7RUFBTSxhQUFhO0NBQU0sQ0FBQzs7Q0FHekcsTUFBTSxPQUFPLEtBQUs7Q0FDbEIsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLE1BQU07RUFDWCxJQUFJLEtBQUssYUFBYSxLQUFLLEtBQUssT0FBTyxLQUFLLFlBQVk7R0FDdEQsS0FBSyxTQUFTO0lBQUUsU0FBUyxVQUFVO0tBQUUsR0FBRztLQUFNLE1BQU0sS0FBSyxhQUFhLElBQUksS0FBSyxhQUFhO0lBQVU7SUFBSSxTQUFTO0dBQUssQ0FBQztFQUMzSCxPQUFPLElBQUksS0FBSyxlQUFlLEtBQUssS0FBSyxPQUFPLEdBQUc7R0FDakQsS0FBSyxTQUFTO0lBQUUsU0FBUyxVQUFVO0tBQUUsR0FBRztLQUFNLE1BQU07SUFBVTtJQUFJLFNBQVM7R0FBSyxDQUFDO0VBQ25GO0NBQ0YsR0FBRyxDQUFDLE1BQU0sUUFBUSxDQUFDO0NBRW5CLE1BQU0sT0FBTyxPQUFPLFFBQVE7Q0FDNUIsTUFBTSxlQUE2QjtFQUNqQyxVQUFVLE9BQU87RUFDakIsT0FBTyxPQUFPO0VBQ2QsVUFBVSxPQUFPO0VBQ2pCLFVBQVUsT0FBTztDQUNuQjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNHLENBQUMsWUFBWSx3QkFBQyxpQkFBRDtJQUFpQixPQUFPLE9BQU8sS0FBSztJQUFJLFdBQVcsTUFBTSxPQUFPLEVBQUUsR0FBRyxLQUFLLFVBQVUsQ0FBQztJQUFHLHFCQUFxQixlQUFlLElBQUk7R0FBSTs7OztjQUFJO0dBRXRKLHdCQUFDLE1BQUQsQ0FBTzs7Ozs7R0FFUCx3QkFBQyxXQUFEO0lBQVMsSUFBRztJQUFXLG1CQUFnQjtJQUFpQixXQUFVO2NBQWxFO0tBQ0Usd0JBQUMsTUFBRDtNQUFJLElBQUc7TUFBaUIsV0FBVTtnQkFBVTtLQUV4Qzs7Ozs7S0FDSCxZQUNDLHdCQUFDLFNBQUQ7TUFBTyxjQUFXO01BQXNCLFdBQVU7Z0JBQWxELENBQ0Usd0JBQUMsU0FBRDtPQUFTLFFBQVE7T0FBYyxRQUFRLEtBQUssTUFBTTtPQUFRLFVBQVU7TUFBUzs7OztnQkFDN0Usd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7Y0FDWjs7Ozs7Z0JBRVAsd0JBQUMsUUFBRDtNQUFRLE1BQU07TUFBYSxjQUFjO2dCQUN2Qyx3QkFBQyxlQUFEO09BQWUsV0FBVTtpQkFBekI7UUFDRSx3QkFBQyxhQUFEO1NBQWEsV0FBVTttQkFBVTtRQUFnQzs7Ozs7UUFDakUsd0JBQUMsbUJBQUQ7U0FBbUIsV0FBVTttQkFBVTtRQUE0RDs7Ozs7UUFDbkcsd0JBQUMsU0FBRDtTQUNFLFFBQVE7U0FDUixRQUFRLEtBQUssTUFBTTtTQUNuQixXQUFXLFVBQVU7VUFDbkIsT0FBTyxLQUFLO1VBQ1osZUFBZSxLQUFLO1NBQ3RCO1NBQ0EsV0FBVTtRQUNYOzs7OztPQUNZOzs7Ozs7S0FDVDs7Ozs7S0FHVix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsUUFBUSxPQUFPLE9BQU8sTUFBUTs7OzttQkFDMUMsWUFBWSx3QkFBQyxZQUFEO1VBQVksT0FBTyxPQUFPLFFBQVE7VUFBVSxXQUFXLFNBQVMsT0FBTyxFQUFFLEtBQUssQ0FBQztTQUFJOzs7O29CQUFJLElBQ2pHOzs7Ozs7UUFFTCx3QkFBQyxLQUFEO1NBQUcsYUFBVTtTQUFTLFdBQVU7U0FBVSxlQUFZO21CQUF0RCxDQUNHLEtBQUssWUFBWSxHQUFHLEtBQUssS0FBSyxNQUFNLEdBQUcsS0FBSyxLQUFLLFVBQVUsSUFBSSxjQUFjLGlCQUFpQixJQUM5RixLQUFLLGNBQWMsS0FBSyxZQUFZLG9CQUFvQixFQUN4RDs7Ozs7O1FBRUYsZ0JBQ0Msd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFELGFBQ0csS0FBSyxPQUFPLEdBQUcsS0FBSyxLQUFLLE1BQU0sR0FBRyxLQUFLLEtBQUssVUFBVSxJQUFJLGNBQWMsaUJBQWlCLGNBQ3pGLE9BQU8sSUFBSSxVQUFVLE9BQU8sRUFBRSxLQUFLLEVBQ2hDOzs7O21CQUNOLHdCQUFDLFVBQUQ7VUFBUSxNQUFLO1VBQVMsU0FBUztVQUFVLFdBQVU7b0JBQTJEO1NBRXRHOzs7O2lCQUNMOzs7OzttQkFDSDtRQUVILEtBQUssVUFDSix3QkFBQyxZQUFEO1NBQVksT0FBTyxLQUFLO1NBQU8sZUFBZSxLQUFLLEtBQUssUUFBUTtTQUFHLFVBQVUsS0FBSztRQUFhOzs7O21CQUM3RixLQUFLLFlBQ1Asd0JBQUMsT0FBRDtTQUFLLFdBQVc7U0FBVztTQUFVLGNBQVc7bUJBQzlDLHdCQUFDLHFCQUFELEVBQXFCLE9BQU8sWUFBWSxJQUFJLEVBQUk7Ozs7O1FBQzdDOzs7O21CQUNILEtBQUssS0FBSyxNQUFNLFdBQVcsSUFDN0Isd0JBQUMsWUFBRDtTQUNFLE9BQU07U0FDTixhQUFZO1NBQ1osUUFDRSxnQkFDRSx3QkFBQyxRQUFEO1VBQVEsU0FBUTtVQUFVLFNBQVM7b0JBQVU7U0FFckM7Ozs7b0JBQ047UUFFUDs7OzttQkFFRCx3QkFBQyxNQUFEO1NBQ0UsV0FBVyxHQUFHLFdBQVcsb0JBQW9CO1NBQzdDLE9BQU8sRUFBRSxTQUFTLEtBQUssb0JBQW9CLE1BQU8sRUFBRTtTQUNwRCxlQUFZO21CQUVYLEtBQUssS0FBSyxNQUFNLEtBQUssTUFDcEIsd0JBQUMsTUFBRCxZQUNFLHdCQUFDLFNBQUQsRUFBUyxLQUFLLEVBQUk7Ozs7a0JBQ2hCLEdBRkssRUFBRTs7OztnQkFFUCxDQUNMO1FBQ0M7Ozs7O09BRUg7Ozs7O2dCQUVKLEtBQUssUUFBUSxLQUFLLEtBQUssYUFBYSxJQUFJLHdCQUFDLFlBQUQ7T0FBa0I7T0FBTSxZQUFZLEtBQUssS0FBSztNQUFhOzs7O2lCQUFJLElBQ3JHOzs7Ozs7SUFDRTs7Ozs7O0dBRVQsd0JBQUMsUUFBRCxDQUFTOzs7OztHQUNULHdCQUFDLE1BQUQsQ0FBTzs7Ozs7RUFDSjs7Ozs7O0FBRVQ7Ozs7Ozs7Ozs7OztBQUdBLE1BQU0sWUFDSjtBQUVGLFNBQVMsZ0JBQWdCLEVBQ3ZCLE9BQ0EsVUFDQSxpQkFLQzs7Q0FDRCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsS0FBSztDQUN0QyxNQUFNLFFBQVEsT0FBa0QsU0FBUztDQUN6RSxnQkFBZ0IsUUFBUSxLQUFLLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FDdkMsc0JBQXNCLGFBQWEsTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDO0NBRXJELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLFFBQUQ7R0FDRSxNQUFLO0dBQ0wsV0FBVTtHQUNWLFdBQVcsTUFBTTtJQUNmLEVBQUUsZUFBZTtJQUNqQixhQUFhLE1BQU0sT0FBTztJQUMxQixTQUFTLEtBQUssS0FBSyxDQUFDO0dBQ3RCO2FBUEY7SUFTRSx3QkFBQyxXQUFEO0tBQVcsTUFBSztLQUFXLE9BQU87S0FBSSxXQUFVO0lBQWU7Ozs7O0lBQy9ELHdCQUFDLFNBQUQ7S0FBTyxTQUFRO0tBQVcsV0FBVTtlQUFVO0lBRXZDOzs7OztJQUNQLHdCQUFDLFNBQUQ7S0FDRSxJQUFHO0tBQ0gsTUFBSztLQUNMLGNBQWE7S0FDYixhQUFZO0tBQ1osT0FBTztLQUNQLFdBQVcsTUFBTTtNQUNmLE1BQU0sT0FBTyxFQUFFLE9BQU87TUFDdEIsUUFBUSxJQUFJO01BQ1osYUFBYSxNQUFNLE9BQU87TUFDMUIsTUFBTSxVQUFVLGlCQUFpQixTQUFTLEtBQUssS0FBSyxDQUFDLEdBQUcsR0FBRztLQUM3RDtLQUNBLFdBQVU7SUFDWDs7Ozs7R0FDRzs7Ozs7WUFDTix3QkFBQyxVQUFEO0dBQ0UsTUFBSztHQUNMLGNBQVc7R0FDWCxTQUFTO0dBQ1QsV0FBVTthQUVWLHdCQUFDLFdBQUQ7SUFBVyxNQUFLO0lBQVcsT0FBTztJQUFJLFFBQVE7R0FBSzs7Ozs7RUFDN0M7Ozs7VUFDTDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaG9tZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZ2V0Um91dGVBcGkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgdHlwZSB7IE5mdExpc3RQYXJhbXMgfSBmcm9tICdAL2FwaS9jb250cmFjdHMnXG5pbXBvcnQgeyBDYXRhbG9nR3JpZFNrZWxldG9uLCBDYXRhbG9nVGFicywgRmVhdHVyZWRCYW5uZXIsIFBhZ2luYXRpb24sIFNvcnRTZWxlY3QgfSBmcm9tICdAL2NvbXBvbmVudHMvY2F0YWxvZy9jYXRhbG9nLXBhcnRzJ1xuaW1wb3J0IHsgdHlwZSBGaWx0ZXJWYWx1ZXMsIEZpbHRlcnMgfSBmcm9tICdAL2NvbXBvbmVudHMvY2F0YWxvZy9maWx0ZXJzJ1xuaW1wb3J0IHsgRW1wdHlTdGF0ZSwgRXJyb3JTdGF0ZSB9IGZyb20gJ0AvY29tcG9uZW50cy9jb21tb24vc3RhdGVzJ1xuaW1wb3J0IHsgQmxvZywgSGVybywgUHJvbW9zIH0gZnJvbSAnQC9jb21wb25lbnRzL21hcmtldGluZy9zZWN0aW9ucydcbmltcG9ydCB7IE5mdENhcmQgfSBmcm9tICdAL2NvbXBvbmVudHMvbmZ0L25mdC1jYXJkJ1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IERpYWxvZywgRGlhbG9nQ29udGVudCwgRGlhbG9nRGVzY3JpcHRpb24sIERpYWxvZ1RpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2RpYWxvZydcbmltcG9ydCB7IEZpZ21hSWNvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9maWdtYS1pY29uJ1xuaW1wb3J0IHsgdXNlTmZ0TGlzdCB9IGZyb20gJ0AvaG9va3MvdXNlLWFwaSdcbmltcG9ydCB7IHVzZUlzRGVza3RvcCB9IGZyb20gJ0AvaG9va3MvdXNlLW1lZGlhJ1xuaW1wb3J0IHsgdXNlUGFnZVRpdGxlIH0gZnJvbSAnQC9ob29rcy91c2UtcGFnZSdcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnXG5pbXBvcnQgdHlwZSB7IEhvbWVTZWFyY2ggfSBmcm9tICdAL3NlYXJjaC1zY2hlbWFzJ1xuXG5jb25zdCByb3V0ZSA9IGdldFJvdXRlQXBpKCcvJylcbmNvbnN0IFBBR0VfU0laRSA9IDlcblxuZnVuY3Rpb24gdG9QYXJhbXMoczogSG9tZVNlYXJjaCk6IFBhcnRpYWw8TmZ0TGlzdFBhcmFtcz4ge1xuICByZXR1cm4ge1xuICAgIHE6IHMucSB8fCB1bmRlZmluZWQsXG4gICAgY2F0ZWdvcnk6IHMuY2F0ZWdvcnksXG4gICAgY2hhaW46IHMuY2hhaW4sXG4gICAgbWluUHJpY2U6IHMubWluUHJpY2UgIT09IHVuZGVmaW5lZCA/IFN0cmluZyhzLm1pblByaWNlKSA6IHVuZGVmaW5lZCxcbiAgICBtYXhQcmljZTogcy5tYXhQcmljZSAhPT0gdW5kZWZpbmVkID8gU3RyaW5nKHMubWF4UHJpY2UpIDogdW5kZWZpbmVkLFxuICAgIGF2YWlsYWJsZU9ubHk6IHMuYXZhaWxhYmxlIHx8IHVuZGVmaW5lZCxcbiAgICBmZWF0dXJlZE9ubHk6IHMudGFiID09PSAndHJlbmRpbmcnIHx8IHVuZGVmaW5lZCxcbiAgICBuZXdPbmx5OiBzLnRhYiA9PT0gJ25ldycgfHwgdW5kZWZpbmVkLFxuICAgIHNvcnQ6IHMuc29ydCA/PyAnbmV3ZXN0JyxcbiAgICBwYWdlOiBzLnBhZ2UgPz8gMSxcbiAgICBwYWdlU2l6ZTogUEFHRV9TSVpFLFxuICB9XG59XG5cbmZ1bmN0aW9uIGhhc0FjdGl2ZUZpbHRlcnMoczogSG9tZVNlYXJjaCkge1xuICByZXR1cm4gQm9vbGVhbihzLnEgfHwgcy5jYXRlZ29yeSB8fCBzLmNoYWluIHx8IHMubWluUHJpY2UgIT09IHVuZGVmaW5lZCB8fCBzLm1heFByaWNlICE9PSB1bmRlZmluZWQgfHwgcy5hdmFpbGFibGUgfHwgcy50YWIpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBIb21lUGFnZSgpIHtcbiAgdXNlUGFnZVRpdGxlKCdJbsOtY2lvJylcbiAgY29uc3Qgc2VhcmNoID0gcm91dGUudXNlU2VhcmNoKClcbiAgY29uc3QgbmF2aWdhdGUgPSByb3V0ZS51c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IGlzRGVza3RvcCA9IHVzZUlzRGVza3RvcCgpXG4gIGNvbnN0IGxpc3QgPSB1c2VOZnRMaXN0KHRvUGFyYW1zKHNlYXJjaCkpXG4gIGNvbnN0IGZpbHRlcnNBY3RpdmUgPSBoYXNBY3RpdmVGaWx0ZXJzKHNlYXJjaClcbiAgY29uc3QgW2ZpbHRlcnNPcGVuLCBzZXRGaWx0ZXJzT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICAvLyBNdWRhciBxdWFscXVlciBmaWx0cm8gcmVpbmljaWEgYSBwYWdpbmHDp8OjbzsgYSB0ZWxhIG7Do28gcm9sYSBwYXJhIG8gdG9wby5cbiAgY29uc3QgdXBkYXRlID0gKHBhdGNoOiBQYXJ0aWFsPEhvbWVTZWFyY2g+KSA9PlxuICAgIHZvaWQgbmF2aWdhdGUoeyBzZWFyY2g6IChwcmV2KSA9PiAoeyAuLi5wcmV2LCAuLi5wYXRjaCwgcGFnZTogdW5kZWZpbmVkIH0pLCByZXBsYWNlOiB0cnVlLCByZXNldFNjcm9sbDogZmFsc2UgfSlcblxuICBjb25zdCBjbGVhckFsbCA9ICgpID0+IHZvaWQgbmF2aWdhdGUoeyBzZWFyY2g6IHsgc29ydDogc2VhcmNoLnNvcnQgfSwgcmVwbGFjZTogdHJ1ZSwgcmVzZXRTY3JvbGw6IGZhbHNlIH0pXG5cbiAgLy8gUMOhZ2luYSBmb3JhIGRvIGludGVydmFsbyAoVVJMIGFudGlnYS9lZGl0YWRhKTogdm9sdGEgcGFyYSBhIMO6bHRpbWEgZXhpc3RlbnRlLlxuICBjb25zdCBkYXRhID0gbGlzdC5kYXRhXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFkYXRhKSByZXR1cm5cbiAgICBpZiAoZGF0YS50b3RhbFBhZ2VzID4gMCAmJiBkYXRhLnBhZ2UgPiBkYXRhLnRvdGFsUGFnZXMpIHtcbiAgICAgIHZvaWQgbmF2aWdhdGUoeyBzZWFyY2g6IChwcmV2KSA9PiAoeyAuLi5wcmV2LCBwYWdlOiBkYXRhLnRvdGFsUGFnZXMgPiAxID8gZGF0YS50b3RhbFBhZ2VzIDogdW5kZWZpbmVkIH0pLCByZXBsYWNlOiB0cnVlIH0pXG4gICAgfSBlbHNlIGlmIChkYXRhLnRvdGFsUGFnZXMgPT09IDAgJiYgZGF0YS5wYWdlID4gMSkge1xuICAgICAgdm9pZCBuYXZpZ2F0ZSh7IHNlYXJjaDogKHByZXYpID0+ICh7IC4uLnByZXYsIHBhZ2U6IHVuZGVmaW5lZCB9KSwgcmVwbGFjZTogdHJ1ZSB9KVxuICAgIH1cbiAgfSwgW2RhdGEsIG5hdmlnYXRlXSlcblxuICBjb25zdCBwYWdlID0gc2VhcmNoLnBhZ2UgPz8gMVxuICBjb25zdCBmaWx0ZXJWYWx1ZXM6IEZpbHRlclZhbHVlcyA9IHtcbiAgICBjYXRlZ29yeTogc2VhcmNoLmNhdGVnb3J5LFxuICAgIGNoYWluOiBzZWFyY2guY2hhaW4sXG4gICAgbWluUHJpY2U6IHNlYXJjaC5taW5QcmljZSxcbiAgICBtYXhQcmljZTogc2VhcmNoLm1heFByaWNlLFxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTQgbWQ6Z2FwLTI0XCI+XG4gICAgICB7IWlzRGVza3RvcCA/IDxNb2JpbGVTZWFyY2hCYXIgdmFsdWU9e3NlYXJjaC5xID8/ICcnfSBvblNlYXJjaD17KHEpID0+IHVwZGF0ZSh7IHE6IHEgfHwgdW5kZWZpbmVkIH0pfSBvbk9wZW5GaWx0ZXJzPXsoKSA9PiBzZXRGaWx0ZXJzT3Blbih0cnVlKX0gLz4gOiBudWxsfVxuXG4gICAgICA8SGVybyAvPlxuXG4gICAgICA8c2VjdGlvbiBpZD1cImNhdGFsb2dvXCIgYXJpYS1sYWJlbGxlZGJ5PVwiY2F0YWxvZ28tdGl0bGVcIiBjbGFzc05hbWU9XCJmbGV4IHNjcm9sbC1tdC02IGl0ZW1zLXN0YXJ0IGdhcC0xMlwiPlxuICAgICAgICA8aDIgaWQ9XCJjYXRhbG9nby10aXRsZVwiIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5cbiAgICAgICAgICBDYXTDoWxvZ29cbiAgICAgICAgPC9oMj5cbiAgICAgICAge2lzRGVza3RvcCA/IChcbiAgICAgICAgICA8YXNpZGUgYXJpYS1sYWJlbD1cIkZpbHRyb3MgZG8gY2F0w6Fsb2dvXCIgY2xhc3NOYW1lPVwiZmxleCB3LVszMTBweF0gc2hyaW5rLTAgZmxleC1jb2wgZ2FwLTZcIj5cbiAgICAgICAgICAgIDxGaWx0ZXJzIHZhbHVlcz17ZmlsdGVyVmFsdWVzfSBmYWNldHM9e2xpc3QuZGF0YT8uZmFjZXRzfSBvbkNoYW5nZT17dXBkYXRlfSAvPlxuICAgICAgICAgICAgPEZlYXR1cmVkQmFubmVyIC8+XG4gICAgICAgICAgPC9hc2lkZT5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8RGlhbG9nIG9wZW49e2ZpbHRlcnNPcGVufSBvbk9wZW5DaGFuZ2U9e3NldEZpbHRlcnNPcGVufT5cbiAgICAgICAgICAgIDxEaWFsb2dDb250ZW50IGNsYXNzTmFtZT1cIm1heC1oLVs4NWR2aF0gb3ZlcmZsb3cteS1hdXRvIHAtMFwiPlxuICAgICAgICAgICAgICA8RGlhbG9nVGl0bGUgY2xhc3NOYW1lPVwic3Itb25seVwiPkZpbHRyb3MgZG8gY2F0w6Fsb2dvPC9EaWFsb2dUaXRsZT5cbiAgICAgICAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5SZWZpbmUgb3MgTkZUcyBwb3IgY29sZcOnw6NvLCBwcmXDp28gZSByZWRlLjwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgICAgICAgIDxGaWx0ZXJzXG4gICAgICAgICAgICAgICAgdmFsdWVzPXtmaWx0ZXJWYWx1ZXN9XG4gICAgICAgICAgICAgICAgZmFjZXRzPXtsaXN0LmRhdGE/LmZhY2V0c31cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHBhdGNoKSA9PiB7XG4gICAgICAgICAgICAgICAgICB1cGRhdGUocGF0Y2gpXG4gICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJzT3BlbihmYWxzZSlcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB0LTEyXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvRGlhbG9nQ29udGVudD5cbiAgICAgICAgICA8L0RpYWxvZz5cbiAgICAgICAgKX1cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLXctMCBmbGV4LTEgZmxleC1jb2wgaXRlbXMtZW5kIGdhcC0xMCBtZDpnYXAtWzg4cHhdXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHctZnVsbCBmbGV4LWNvbCBnYXAtNCBtZDpnYXAtOFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgICAgICAgIDxDYXRhbG9nVGFicyBhY3RpdmU9e3NlYXJjaC50YWIgPz8gJ2FsbCd9IC8+XG4gICAgICAgICAgICAgIHtpc0Rlc2t0b3AgPyA8U29ydFNlbGVjdCB2YWx1ZT17c2VhcmNoLnNvcnQgPz8gJ25ld2VzdCd9IG9uQ2hhbmdlPXsoc29ydCkgPT4gdXBkYXRlKHsgc29ydCB9KX0gLz4gOiBudWxsfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxwIGFyaWEtbGl2ZT1cInBvbGl0ZVwiIGNsYXNzTmFtZT1cInNyLW9ubHlcIiBkYXRhLXRlc3RpZD1cInJlc3VsdC1jb3VudFwiPlxuICAgICAgICAgICAgICB7bGlzdC5pc1N1Y2Nlc3MgPyBgJHtsaXN0LmRhdGEudG90YWx9ICR7bGlzdC5kYXRhLnRvdGFsID09PSAxID8gJ3Jlc3VsdGFkbycgOiAncmVzdWx0YWRvcyd9YCA6ICcnfVxuICAgICAgICAgICAgICB7bGlzdC5pc0ZldGNoaW5nICYmIGxpc3QuaXNTdWNjZXNzID8gJyDCtyBhdHVhbGl6YW5kb+KApicgOiAnJ31cbiAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAge2ZpbHRlcnNBY3RpdmUgPyAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICB7bGlzdC5kYXRhID8gYCR7bGlzdC5kYXRhLnRvdGFsfSAke2xpc3QuZGF0YS50b3RhbCA9PT0gMSA/ICdyZXN1bHRhZG8nIDogJ3Jlc3VsdGFkb3MnfWAgOiAnRmlsdHJhbmRv4oCmJ31cbiAgICAgICAgICAgICAgICAgIHtzZWFyY2gucSA/IGAgcGFyYSDigJwke3NlYXJjaC5xfeKAnWAgOiAnJ31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17Y2xlYXJBbGx9IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWFjY2VudCB1bmRlcmxpbmUtb2Zmc2V0LTQgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgICAgICBMaW1wYXIgZmlsdHJvc1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiBudWxsfVxuXG4gICAgICAgICAgICB7bGlzdC5pc0Vycm9yID8gKFxuICAgICAgICAgICAgICA8RXJyb3JTdGF0ZSBlcnJvcj17bGlzdC5lcnJvcn0gb25SZXRyeT17KCkgPT4gdm9pZCBsaXN0LnJlZmV0Y2goKX0gcmV0cnlpbmc9e2xpc3QuaXNGZXRjaGluZ30gLz5cbiAgICAgICAgICAgICkgOiBsaXN0LmlzUGVuZGluZyA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2dyaWRDbGFzc30gYXJpYS1idXN5IGFyaWEtbGFiZWw9XCJDYXJyZWdhbmRvIE5GVHNcIj5cbiAgICAgICAgICAgICAgICA8Q2F0YWxvZ0dyaWRTa2VsZXRvbiBjb3VudD17aXNEZXNrdG9wID8gOSA6IDR9IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IGxpc3QuZGF0YS5pdGVtcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgIDxFbXB0eVN0YXRlXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJOZW5odW0gTkZUIGVuY29udHJhZG9cIlxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uPVwiVGVudGUgb3V0cm9zIHRlcm1vcyBvdSByZW1vdmEgYWxndW5zIGZpbHRyb3MgcGFyYSB2ZXIgbWFpcyByZXN1bHRhZG9zLlwiXG4gICAgICAgICAgICAgICAgYWN0aW9uPXtcbiAgICAgICAgICAgICAgICAgIGZpbHRlcnNBY3RpdmUgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBvbkNsaWNrPXtjbGVhckFsbH0+XG4gICAgICAgICAgICAgICAgICAgICAgTGltcGFyIGZpbHRyb3NcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICApIDogdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPHVsXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihncmlkQ2xhc3MsICd0cmFuc2l0aW9uLW9wYWNpdHknKX1cbiAgICAgICAgICAgICAgICBzdHlsZT17eyBvcGFjaXR5OiBsaXN0LmlzUGxhY2Vob2xkZXJEYXRhID8gMC41NSA6IDEgfX1cbiAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImNhdGFsb2ctZ3JpZFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7bGlzdC5kYXRhLml0ZW1zLm1hcCgobikgPT4gKFxuICAgICAgICAgICAgICAgICAgPGxpIGtleT17bi5pZH0+XG4gICAgICAgICAgICAgICAgICAgIDxOZnRDYXJkIG5mdD17bn0gLz5cbiAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAge2xpc3QuZGF0YSAmJiBsaXN0LmRhdGEudG90YWxQYWdlcyA+IDEgPyA8UGFnaW5hdGlvbiBwYWdlPXtwYWdlfSB0b3RhbFBhZ2VzPXtsaXN0LmRhdGEudG90YWxQYWdlc30gLz4gOiBudWxsfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgPFByb21vcyAvPlxuICAgICAgPEJsb2cgLz5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG4vKiogRGVza3RvcDogMyBjb2x1bmFzIGRlIDI1OHB4OyBtb2JpbGU6IDIgY29sdW5hcyBjb20gYSBkaXJlaXRhIGRlc2xvY2FkYSAoZ3JhZGUgZXNjYWxvbmFkYSBkbyBsYXlvdXQpLiAqL1xuY29uc3QgZ3JpZENsYXNzID1cbiAgJ2dyaWQgdy1mdWxsIGdyaWQtY29scy0yIGdhcC14LTQgZ2FwLXktNiBtYXgtbWQ6WyY+KjpudGgtY2hpbGQoZXZlbildOnB0LTggbWQ6Z3JpZC1jb2xzLTMgbWQ6Z2FwLXgtWzM0cHhdIG1kOmdhcC15LVs3MnB4XSdcblxuZnVuY3Rpb24gTW9iaWxlU2VhcmNoQmFyKHtcbiAgdmFsdWUsXG4gIG9uU2VhcmNoLFxuICBvbk9wZW5GaWx0ZXJzLFxufToge1xuICB2YWx1ZTogc3RyaW5nXG4gIG9uU2VhcmNoOiAocTogc3RyaW5nKSA9PiB2b2lkXG4gIG9uT3BlbkZpbHRlcnM6ICgpID0+IHZvaWRcbn0pIHtcbiAgY29uc3QgW3RleHQsIHNldFRleHRdID0gdXNlU3RhdGUodmFsdWUpXG4gIGNvbnN0IHRpbWVyID0gdXNlUmVmPFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgdW5kZWZpbmVkPih1bmRlZmluZWQpXG4gIHVzZUVmZmVjdCgoKSA9PiBzZXRUZXh0KHZhbHVlKSwgW3ZhbHVlXSlcbiAgdXNlRWZmZWN0KCgpID0+ICgpID0+IGNsZWFyVGltZW91dCh0aW1lci5jdXJyZW50KSwgW10pXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1bNDVweF0gZ2FwLTJcIj5cbiAgICAgIDxmb3JtXG4gICAgICAgIHJvbGU9XCJzZWFyY2hcIlxuICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGgtZnVsbCBmbGV4LTEgaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQtWzEwcHhdIGJnLWNhcmQgcHgtM1wiXG4gICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xuICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lci5jdXJyZW50KVxuICAgICAgICAgIG9uU2VhcmNoKHRleHQudHJpbSgpKVxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8RmlnbWFJY29uIG5hbWU9XCJtLXNlYXJjaFwiIHdpZHRoPXsyMn0gY2xhc3NOYW1lPVwidGV4dC1zdWJ0bGVcIiAvPlxuICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm0tc2VhcmNoXCIgY2xhc3NOYW1lPVwic3Itb25seVwiPlxuICAgICAgICAgIEJ1c2NhclxuICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICBpZD1cIm0tc2VhcmNoXCJcbiAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcbiAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXhwbG9yYXIgY29sZcOnw7Vlc1wiXG4gICAgICAgICAgdmFsdWU9e3RleHR9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gZS50YXJnZXQudmFsdWVcbiAgICAgICAgICAgIHNldFRleHQobmV4dClcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lci5jdXJyZW50KVxuICAgICAgICAgICAgdGltZXIuY3VycmVudCA9IHNldFRpbWVvdXQoKCkgPT4gb25TZWFyY2gobmV4dC50cmltKCkpLCAzNTApXG4gICAgICAgICAgfX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgbWluLXctMCBmbGV4LTEgYmctdHJhbnNwYXJlbnQgdGV4dC1zbSBmb250LWJvbGQgbGVhZGluZy00IHRleHQtZm9yZWdyb3VuZCBvdXRsaW5lLW5vbmUgcGxhY2Vob2xkZXI6Zm9udC1ib2xkXCJcbiAgICAgICAgLz5cbiAgICAgIDwvZm9ybT5cbiAgICAgIDxidXR0b25cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIGFyaWEtbGFiZWw9XCJBYnJpciBmaWx0cm9zXCJcbiAgICAgICAgb25DbGljaz17b25PcGVuRmlsdGVyc31cbiAgICAgICAgY2xhc3NOYW1lPVwiZ3JpZCBzaXplLVs0NXB4XSBzaHJpbmstMCBwbGFjZS1pdGVtcy1jZW50ZXIgcm91bmRlZC1bMTRweF0gYmctW2xpbmVhci1ncmFkaWVudCgxMzdkZWcscmdiYSgyMTAsMTM4LDc2LDAuNDUpXzI0LjYlLCNkMjhhNGNfMTAwJSldIHRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kXCJcbiAgICAgID5cbiAgICAgICAgPEZpZ21hSWNvbiBuYW1lPVwibS1maWx0ZXJcIiB3aWR0aD17MTZ9IGhlaWdodD17MTZ9IC8+XG4gICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl19