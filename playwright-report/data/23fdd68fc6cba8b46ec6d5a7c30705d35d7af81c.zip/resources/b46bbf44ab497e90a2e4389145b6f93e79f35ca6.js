import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/nft/price.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { formatEth } from "/src/lib/eth.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/price.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
/** Preço em ETH. Mantém o valor exato visível via title (sem arredondar silenciosamente). */
export function Price({ value, className }) {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: cn("tabular-nums", className),
		title: `${value} ETH`,
		children: formatEth(value)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 5
	}, this);
}
_c = Price;
var _c;
$RefreshReg$(_c, "Price");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/nft/price.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/price.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/price.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/nft/price.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxVQUFVOzs7O0FBR25CLE9BQU8sU0FBUyxNQUFNLEVBQUUsT0FBTyxhQUFvRDtDQUNqRixPQUNFLHdCQUFDLFFBQUQ7RUFBTSxXQUFXLEdBQUcsZ0JBQWdCLFNBQVM7RUFBRyxPQUFPLEdBQUcsTUFBTTtZQUM3RCxVQUFVLEtBQUs7Q0FDWjs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJwcmljZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZm9ybWF0RXRoIH0gZnJvbSAnQC9saWIvZXRoJ1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcblxuLyoqIFByZcOnbyBlbSBFVEguIE1hbnTDqW0gbyB2YWxvciBleGF0byB2aXPDrXZlbCB2aWEgdGl0bGUgKHNlbSBhcnJlZG9uZGFyIHNpbGVuY2lvc2FtZW50ZSkuICovXG5leHBvcnQgZnVuY3Rpb24gUHJpY2UoeyB2YWx1ZSwgY2xhc3NOYW1lIH06IHsgdmFsdWU6IHN0cmluZzsgY2xhc3NOYW1lPzogc3RyaW5nIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8c3BhbiBjbGFzc05hbWU9e2NuKCd0YWJ1bGFyLW51bXMnLCBjbGFzc05hbWUpfSB0aXRsZT17YCR7dmFsdWV9IEVUSGB9PlxuICAgICAge2Zvcm1hdEV0aCh2YWx1ZSl9XG4gICAgPC9zcGFuPlxuICApXG59XG4iXX0=