import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/catalog/filters.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { categories, categoryLabels, chainLabels, chains } from "/src/api/contracts.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/catalog/filters.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$();
const formatBr = (n) => n.toLocaleString("pt-BR", {
	minimumFractionDigits: 2,
	maximumFractionDigits: 2
});
/** Painel "Filters" do layout (310px, fundo #241612): coleções, faixa de preço e rede. */
export function Filters({ values, facets, onChange, className }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn("flex flex-col gap-10 bg-card p-5", className),
		children: [
			/* @__PURE__ */ _jsxDEV("fieldset", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ _jsxDEV("legend", {
					className: "mb-3 text-lg font-bold leading-4 text-foreground",
					children: "Coleções"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("ul", {
					className: "px-3",
					children: categories.map((c) => {
						const active = values.category === c;
						const count = facets?.categories[c];
						return /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							"aria-pressed": active,
							onClick: () => onChange({ category: active ? undefined : c }),
							className: cn("flex w-full items-start justify-between text-[15px] leading-10 hover:text-accent", active ? "text-accent" : "text-muted-foreground"),
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: cn(active && "underline decoration-1 underline-offset-4"),
								children: categoryLabels[c]
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 53,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold",
								children: count !== undefined ? `(${count})` : ""
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 44,
							columnNumber: 17
						}, this) }, c, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(PriceRange, {
				bounds: facets ? {
					min: Number(facets.price.min),
					max: Number(facets.price.max)
				} : undefined,
				value: {
					min: values.minPrice,
					max: values.maxPrice
				},
				onApply: (min, max) => onChange({
					minPrice: min,
					maxPrice: max
				})
			}, `${values.minPrice ?? ""}-${values.maxPrice ?? ""}-${facets?.price.min ?? ""}-${facets?.price.max ?? ""}`, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("fieldset", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ _jsxDEV("legend", {
					className: "mb-3 text-lg font-bold leading-4 text-foreground",
					children: "Rede"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("ul", {
					className: "pl-3",
					children: chains.map((c) => {
						const active = values.chain === c;
						const count = facets?.chains[c];
						return /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							"aria-pressed": active,
							onClick: () => onChange({ chain: active ? undefined : c }),
							className: cn("flex w-full items-start justify-between text-[15px] leading-10 hover:text-accent", active ? "text-accent" : "text-muted-foreground"),
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: cn(active && "underline decoration-1 underline-offset-4"),
								children: chainLabels[c]
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 88,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: count !== undefined ? `(${count})` : "" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 17
						}, this) }, c, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 5
	}, this);
}
_c = Filters;
/** Controle de faixa com dois cursores; só altera a busca ao clicar em "Aplicar". */
function PriceRange({ bounds, value, onApply }) {
	_s();
	const lo = bounds?.min ?? 0;
	const hi = bounds?.max ?? 0;
	const [min, setMin] = useState(value.min ?? lo);
	const [max, setMax] = useState(value.max ?? hi);
	useEffect(() => {
		setMin(value.min ?? lo);
		setMax(value.max ?? hi);
	}, [
		value.min,
		value.max,
		lo,
		hi
	]);
	const disabled = !bounds || hi <= lo;
	const span = hi - lo || 1;
	const left = (Math.min(min, max) - lo) / span * 100;
	const right = (Math.max(min, max) - lo) / span * 100;
	return /* @__PURE__ */ _jsxDEV("fieldset", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ _jsxDEV("legend", {
			className: "mb-3 text-lg font-bold leading-4 text-foreground",
			children: "Faixa de preço"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 125,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col gap-3 pl-3",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative h-[15px]",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							"aria-hidden": true,
							className: "absolute inset-x-0 top-1/2 h-1 -translate-y-1/2 rounded-full bg-primary/35"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							"aria-hidden": true,
							className: "absolute top-1/2 h-1 -translate-y-1/2 bg-primary",
							style: {
								left: `${left}%`,
								right: `${100 - right}%`
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							type: "range",
							"aria-label": "Preço mínimo (ETH)",
							className: "k-range",
							min: lo,
							max: hi,
							step: .01,
							disabled,
							value: min,
							onChange: (e) => setMin(Math.min(Number(e.target.value), max))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							type: "range",
							"aria-label": "Preço máximo (ETH)",
							className: "k-range",
							min: lo,
							max: hi,
							step: .01,
							disabled,
							value: max,
							onChange: (e) => setMax(Math.max(Number(e.target.value), min))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 127,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-[15px] leading-normal text-foreground",
					"aria-live": "polite",
					children: [
						"Preço: ",
						formatBr(Math.min(min, max)),
						" - ",
						formatBr(Math.max(min, max)),
						" ETH"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 157,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					disabled,
					onClick: () => onApply(min <= lo ? undefined : round(min), max >= hi ? undefined : round(max)),
					className: "self-start rounded-[6px] bg-primary px-3 py-2 text-base font-bold leading-5 text-primary-foreground hover:brightness-110 disabled:opacity-50",
					children: "Aplicar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 160,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 126,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 124,
		columnNumber: 5
	}, this);
}
_s(PriceRange, "jsWNvouqCthmJRSX2tyRmIath9E=");
_c2 = PriceRange;
const round = (n) => Math.round(n * 100) / 100;
var _c, _c2;
$RefreshReg$(_c, "Filters");
$RefreshReg$(_c2, "PriceRange");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/catalog/filters.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/catalog/filters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/catalog/filters.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/catalog/filters.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUVFLFlBQ0EsZ0JBRUEsYUFDQSxjQUVLO0FBQ1AsU0FBUyxVQUFVOzs7O0FBRW5CLE1BQU0sWUFBWSxNQUFjLEVBQUUsZUFBZSxTQUFTO0NBQUUsdUJBQXVCO0NBQUcsdUJBQXVCO0FBQUUsQ0FBQzs7QUFVaEgsT0FBTyxTQUFTLFFBQVEsRUFDdEIsUUFDQSxRQUNBLFVBQ0EsYUFNQztDQUNELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVcsR0FBRyxvQ0FBb0MsU0FBUztZQUFoRTtHQUNFLHdCQUFDLFlBQUQ7SUFBVSxXQUFVO2NBQXBCLENBQ0Usd0JBQUMsVUFBRDtLQUFRLFdBQVU7ZUFBbUQ7SUFBZ0I7Ozs7Y0FDckYsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFDWCxXQUFXLEtBQUssTUFBTTtNQUNyQixNQUFNLFNBQVMsT0FBTyxhQUFhO01BQ25DLE1BQU0sUUFBUSxRQUFRLFdBQVc7TUFDakMsT0FDRSx3QkFBQyxNQUFELFlBQ0Usd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxnQkFBYztPQUNkLGVBQWUsU0FBUyxFQUFFLFVBQVUsU0FBUyxZQUFZLEVBQUUsQ0FBQztPQUM1RCxXQUFXLEdBQ1Qsb0ZBQ0EsU0FBUyxnQkFBZ0IsdUJBQzNCO2lCQVBGLENBU0Usd0JBQUMsUUFBRDtRQUFNLFdBQVcsR0FBRyxVQUFVLDJDQUEyQztrQkFBSSxlQUFlO09BQVM7Ozs7aUJBQ3JHLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLFVBQVUsWUFBWSxJQUFJLE1BQU0sS0FBSztPQUNsQzs7OztlQUNBOzs7OztlQUNOLEdBZks7Ozs7YUFlTDtLQUVSLENBQUM7SUFDQzs7OztZQUNJOzs7Ozs7R0FFVix3QkFBQyxZQUFEO0lBRUUsUUFBUSxTQUFTO0tBQUUsS0FBSyxPQUFPLE9BQU8sTUFBTSxHQUFHO0tBQUcsS0FBSyxPQUFPLE9BQU8sTUFBTSxHQUFHO0lBQUUsSUFBSTtJQUNwRixPQUFPO0tBQUUsS0FBSyxPQUFPO0tBQVUsS0FBSyxPQUFPO0lBQVM7SUFDcEQsVUFBVSxLQUFLLFFBQVEsU0FBUztLQUFFLFVBQVU7S0FBSyxVQUFVO0lBQUksQ0FBQztHQUNqRSxHQUpNLEdBQUcsT0FBTyxZQUFZLEdBQUcsR0FBRyxPQUFPLFlBQVksR0FBRyxHQUFHLFFBQVEsTUFBTSxPQUFPLEdBQUcsR0FBRyxRQUFRLE1BQU0sT0FBTzs7OztVQUkzRztHQUVELHdCQUFDLFlBQUQ7SUFBVSxXQUFVO2NBQXBCLENBQ0Usd0JBQUMsVUFBRDtLQUFRLFdBQVU7ZUFBbUQ7SUFBWTs7OztjQUNqRix3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLE9BQU8sS0FBSyxNQUFNO01BQ2pCLE1BQU0sU0FBUyxPQUFPLFVBQVU7TUFDaEMsTUFBTSxRQUFRLFFBQVEsT0FBTztNQUM3QixPQUNFLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLGdCQUFjO09BQ2QsZUFBZSxTQUFTLEVBQUUsT0FBTyxTQUFTLFlBQVksRUFBRSxDQUFDO09BQ3pELFdBQVcsR0FDVCxvRkFDQSxTQUFTLGdCQUFnQix1QkFDM0I7aUJBUEYsQ0FTRSx3QkFBQyxRQUFEO1FBQU0sV0FBVyxHQUFHLFVBQVUsMkNBQTJDO2tCQUFJLFlBQVk7T0FBUzs7OztpQkFDbEcsd0JBQUMsUUFBRCxZQUFPLFVBQVUsWUFBWSxJQUFJLE1BQU0sS0FBSyxHQUFTOzs7O2VBQy9DOzs7OztlQUNOLEdBYks7Ozs7YUFhTDtLQUVSLENBQUM7SUFDQzs7OztZQUNJOzs7Ozs7RUFDUDs7Ozs7O0FBRVQ7OztBQUdBLFNBQVMsV0FBVyxFQUNsQixRQUNBLE9BQ0EsV0FLQzs7Q0FDRCxNQUFNLEtBQUssUUFBUSxPQUFPO0NBQzFCLE1BQU0sS0FBSyxRQUFRLE9BQU87Q0FDMUIsTUFBTSxDQUFDLEtBQUssVUFBVSxTQUFTLE1BQU0sT0FBTyxFQUFFO0NBQzlDLE1BQU0sQ0FBQyxLQUFLLFVBQVUsU0FBUyxNQUFNLE9BQU8sRUFBRTtDQUM5QyxnQkFBZ0I7RUFDZCxPQUFPLE1BQU0sT0FBTyxFQUFFO0VBQ3RCLE9BQU8sTUFBTSxPQUFPLEVBQUU7Q0FDeEIsR0FBRztFQUFDLE1BQU07RUFBSyxNQUFNO0VBQUs7RUFBSTtDQUFFLENBQUM7Q0FDakMsTUFBTSxXQUFXLENBQUMsVUFBVSxNQUFNO0NBQ2xDLE1BQU0sT0FBTyxLQUFLLE1BQU07Q0FDeEIsTUFBTSxRQUFTLEtBQUssSUFBSSxLQUFLLEdBQUcsSUFBSSxNQUFNLE9BQVE7Q0FDbEQsTUFBTSxTQUFVLEtBQUssSUFBSSxLQUFLLEdBQUcsSUFBSSxNQUFNLE9BQVE7Q0FFbkQsT0FDRSx3QkFBQyxZQUFEO0VBQVUsV0FBVTtZQUFwQixDQUNFLHdCQUFDLFVBQUQ7R0FBUSxXQUFVO2FBQW1EO0VBQXNCOzs7O1lBQzNGLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsUUFBRDtPQUFNO09BQVksV0FBVTtNQUE4RTs7Ozs7TUFDMUcsd0JBQUMsUUFBRDtPQUNFO09BQ0EsV0FBVTtPQUNWLE9BQU87UUFBRSxNQUFNLEdBQUcsS0FBSztRQUFJLE9BQU8sR0FBRyxNQUFNLE1BQU07T0FBRztNQUNyRDs7Ozs7TUFDRCx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLGNBQVc7T0FDWCxXQUFVO09BQ1YsS0FBSztPQUNMLEtBQUs7T0FDTCxNQUFNO09BQ0k7T0FDVixPQUFPO09BQ1AsV0FBVyxNQUFNLE9BQU8sS0FBSyxJQUFJLE9BQU8sRUFBRSxPQUFPLEtBQUssR0FBRyxHQUFHLENBQUM7TUFDOUQ7Ozs7O01BQ0Qsd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxjQUFXO09BQ1gsV0FBVTtPQUNWLEtBQUs7T0FDTCxLQUFLO09BQ0wsTUFBTTtPQUNJO09BQ1YsT0FBTztPQUNQLFdBQVcsTUFBTSxPQUFPLEtBQUssSUFBSSxPQUFPLEVBQUUsT0FBTyxLQUFLLEdBQUcsR0FBRyxDQUFDO01BQzlEOzs7OztLQUNFOzs7Ozs7SUFDTCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtLQUE2QyxhQUFVO2VBQXBFO01BQTZFO01BQ25FLFNBQVMsS0FBSyxJQUFJLEtBQUssR0FBRyxDQUFDO01BQUU7TUFBSSxTQUFTLEtBQUssSUFBSSxLQUFLLEdBQUcsQ0FBQztNQUFFO0tBQ3JFOzs7Ozs7SUFDSCx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNLO0tBQ1YsZUFBZSxRQUFRLE9BQU8sS0FBSyxZQUFZLE1BQU0sR0FBRyxHQUFHLE9BQU8sS0FBSyxZQUFZLE1BQU0sR0FBRyxDQUFDO0tBQzdGLFdBQVU7ZUFDWDtJQUVPOzs7OztHQUNMOzs7OztVQUNHOzs7Ozs7QUFFZDs7O0FBRUEsTUFBTSxTQUFTLE1BQWMsS0FBSyxNQUFNLElBQUksR0FBRyxJQUFJIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImZpbHRlcnMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7XG4gIHR5cGUgQ2F0ZWdvcnksXG4gIGNhdGVnb3JpZXMsXG4gIGNhdGVnb3J5TGFiZWxzLFxuICB0eXBlIENoYWluLFxuICBjaGFpbkxhYmVscyxcbiAgY2hhaW5zLFxuICB0eXBlIE5mdExpc3QsXG59IGZyb20gJ0AvYXBpL2NvbnRyYWN0cydcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnXG5cbmNvbnN0IGZvcm1hdEJyID0gKG46IG51bWJlcikgPT4gbi50b0xvY2FsZVN0cmluZygncHQtQlInLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiwgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pXG5cbmV4cG9ydCB0eXBlIEZpbHRlclZhbHVlcyA9IHtcbiAgY2F0ZWdvcnk/OiBDYXRlZ29yeVxuICBjaGFpbj86IENoYWluXG4gIG1pblByaWNlPzogbnVtYmVyXG4gIG1heFByaWNlPzogbnVtYmVyXG59XG5cbi8qKiBQYWluZWwgXCJGaWx0ZXJzXCIgZG8gbGF5b3V0ICgzMTBweCwgZnVuZG8gIzI0MTYxMik6IGNvbGXDp8O1ZXMsIGZhaXhhIGRlIHByZcOnbyBlIHJlZGUuICovXG5leHBvcnQgZnVuY3Rpb24gRmlsdGVycyh7XG4gIHZhbHVlcyxcbiAgZmFjZXRzLFxuICBvbkNoYW5nZSxcbiAgY2xhc3NOYW1lLFxufToge1xuICB2YWx1ZXM6IEZpbHRlclZhbHVlc1xuICBmYWNldHM6IE5mdExpc3RbJ2ZhY2V0cyddIHwgdW5kZWZpbmVkXG4gIG9uQ2hhbmdlOiAocGF0Y2g6IFBhcnRpYWw8RmlsdGVyVmFsdWVzPikgPT4gdm9pZFxuICBjbGFzc05hbWU/OiBzdHJpbmdcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17Y24oJ2ZsZXggZmxleC1jb2wgZ2FwLTEwIGJnLWNhcmQgcC01JywgY2xhc3NOYW1lKX0+XG4gICAgICA8ZmllbGRzZXQgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgICA8bGVnZW5kIGNsYXNzTmFtZT1cIm1iLTMgdGV4dC1sZyBmb250LWJvbGQgbGVhZGluZy00IHRleHQtZm9yZWdyb3VuZFwiPkNvbGXDp8O1ZXM8L2xlZ2VuZD5cbiAgICAgICAgPHVsIGNsYXNzTmFtZT1cInB4LTNcIj5cbiAgICAgICAgICB7Y2F0ZWdvcmllcy5tYXAoKGMpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZSA9IHZhbHVlcy5jYXRlZ29yeSA9PT0gY1xuICAgICAgICAgICAgY29uc3QgY291bnQgPSBmYWNldHM/LmNhdGVnb3JpZXNbY11cbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxsaSBrZXk9e2N9PlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgYXJpYS1wcmVzc2VkPXthY3RpdmV9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkNoYW5nZSh7IGNhdGVnb3J5OiBhY3RpdmUgPyB1bmRlZmluZWQgOiBjIH0pfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgJ2ZsZXggdy1mdWxsIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxNXB4XSBsZWFkaW5nLTEwIGhvdmVyOnRleHQtYWNjZW50JyxcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlID8gJ3RleHQtYWNjZW50JyA6ICd0ZXh0LW11dGVkLWZvcmVncm91bmQnLFxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2NuKGFjdGl2ZSAmJiAndW5kZXJsaW5lIGRlY29yYXRpb24tMSB1bmRlcmxpbmUtb2Zmc2V0LTQnKX0+e2NhdGVnb3J5TGFiZWxzW2NdfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICB7Y291bnQgIT09IHVuZGVmaW5lZCA/IGAoJHtjb3VudH0pYCA6ICcnfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH0pfVxuICAgICAgICA8L3VsPlxuICAgICAgPC9maWVsZHNldD5cblxuICAgICAgPFByaWNlUmFuZ2VcbiAgICAgICAga2V5PXtgJHt2YWx1ZXMubWluUHJpY2UgPz8gJyd9LSR7dmFsdWVzLm1heFByaWNlID8/ICcnfS0ke2ZhY2V0cz8ucHJpY2UubWluID8/ICcnfS0ke2ZhY2V0cz8ucHJpY2UubWF4ID8/ICcnfWB9XG4gICAgICAgIGJvdW5kcz17ZmFjZXRzID8geyBtaW46IE51bWJlcihmYWNldHMucHJpY2UubWluKSwgbWF4OiBOdW1iZXIoZmFjZXRzLnByaWNlLm1heCkgfSA6IHVuZGVmaW5lZH1cbiAgICAgICAgdmFsdWU9e3sgbWluOiB2YWx1ZXMubWluUHJpY2UsIG1heDogdmFsdWVzLm1heFByaWNlIH19XG4gICAgICAgIG9uQXBwbHk9eyhtaW4sIG1heCkgPT4gb25DaGFuZ2UoeyBtaW5QcmljZTogbWluLCBtYXhQcmljZTogbWF4IH0pfVxuICAgICAgLz5cblxuICAgICAgPGZpZWxkc2V0IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgICAgPGxlZ2VuZCBjbGFzc05hbWU9XCJtYi0zIHRleHQtbGcgZm9udC1ib2xkIGxlYWRpbmctNCB0ZXh0LWZvcmVncm91bmRcIj5SZWRlPC9sZWdlbmQ+XG4gICAgICAgIDx1bCBjbGFzc05hbWU9XCJwbC0zXCI+XG4gICAgICAgICAge2NoYWlucy5tYXAoKGMpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZSA9IHZhbHVlcy5jaGFpbiA9PT0gY1xuICAgICAgICAgICAgY29uc3QgY291bnQgPSBmYWNldHM/LmNoYWluc1tjXVxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGxpIGtleT17Y30+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBhcmlhLXByZXNzZWQ9e2FjdGl2ZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKHsgY2hhaW46IGFjdGl2ZSA/IHVuZGVmaW5lZCA6IGMgfSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAnZmxleCB3LWZ1bGwgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIHRleHQtWzE1cHhdIGxlYWRpbmctMTAgaG92ZXI6dGV4dC1hY2NlbnQnLFxuICAgICAgICAgICAgICAgICAgICBhY3RpdmUgPyAndGV4dC1hY2NlbnQnIDogJ3RleHQtbXV0ZWQtZm9yZWdyb3VuZCcsXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17Y24oYWN0aXZlICYmICd1bmRlcmxpbmUgZGVjb3JhdGlvbi0xIHVuZGVybGluZS1vZmZzZXQtNCcpfT57Y2hhaW5MYWJlbHNbY119PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2NvdW50ICE9PSB1bmRlZmluZWQgPyBgKCR7Y291bnR9KWAgOiAnJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICApXG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvdWw+XG4gICAgICA8L2ZpZWxkc2V0PlxuICAgIDwvZGl2PlxuICApXG59XG5cbi8qKiBDb250cm9sZSBkZSBmYWl4YSBjb20gZG9pcyBjdXJzb3Jlczsgc8OzIGFsdGVyYSBhIGJ1c2NhIGFvIGNsaWNhciBlbSBcIkFwbGljYXJcIi4gKi9cbmZ1bmN0aW9uIFByaWNlUmFuZ2Uoe1xuICBib3VuZHMsXG4gIHZhbHVlLFxuICBvbkFwcGx5LFxufToge1xuICBib3VuZHM6IHsgbWluOiBudW1iZXI7IG1heDogbnVtYmVyIH0gfCB1bmRlZmluZWRcbiAgdmFsdWU6IHsgbWluPzogbnVtYmVyOyBtYXg/OiBudW1iZXIgfVxuICBvbkFwcGx5OiAobWluOiBudW1iZXIgfCB1bmRlZmluZWQsIG1heDogbnVtYmVyIHwgdW5kZWZpbmVkKSA9PiB2b2lkXG59KSB7XG4gIGNvbnN0IGxvID0gYm91bmRzPy5taW4gPz8gMFxuICBjb25zdCBoaSA9IGJvdW5kcz8ubWF4ID8/IDBcbiAgY29uc3QgW21pbiwgc2V0TWluXSA9IHVzZVN0YXRlKHZhbHVlLm1pbiA/PyBsbylcbiAgY29uc3QgW21heCwgc2V0TWF4XSA9IHVzZVN0YXRlKHZhbHVlLm1heCA/PyBoaSlcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRNaW4odmFsdWUubWluID8/IGxvKVxuICAgIHNldE1heCh2YWx1ZS5tYXggPz8gaGkpXG4gIH0sIFt2YWx1ZS5taW4sIHZhbHVlLm1heCwgbG8sIGhpXSlcbiAgY29uc3QgZGlzYWJsZWQgPSAhYm91bmRzIHx8IGhpIDw9IGxvXG4gIGNvbnN0IHNwYW4gPSBoaSAtIGxvIHx8IDFcbiAgY29uc3QgbGVmdCA9ICgoTWF0aC5taW4obWluLCBtYXgpIC0gbG8pIC8gc3BhbikgKiAxMDBcbiAgY29uc3QgcmlnaHQgPSAoKE1hdGgubWF4KG1pbiwgbWF4KSAtIGxvKSAvIHNwYW4pICogMTAwXG5cbiAgcmV0dXJuIChcbiAgICA8ZmllbGRzZXQgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgPGxlZ2VuZCBjbGFzc05hbWU9XCJtYi0zIHRleHQtbGcgZm9udC1ib2xkIGxlYWRpbmctNCB0ZXh0LWZvcmVncm91bmRcIj5GYWl4YSBkZSBwcmXDp288L2xlZ2VuZD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMyBwbC0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgaC1bMTVweF1cIj5cbiAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC14LTAgdG9wLTEvMiBoLTEgLXRyYW5zbGF0ZS15LTEvMiByb3VuZGVkLWZ1bGwgYmctcHJpbWFyeS8zNVwiIC8+XG4gICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgIGFyaWEtaGlkZGVuXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMS8yIGgtMSAtdHJhbnNsYXRlLXktMS8yIGJnLXByaW1hcnlcIlxuICAgICAgICAgICAgc3R5bGU9e3sgbGVmdDogYCR7bGVmdH0lYCwgcmlnaHQ6IGAkezEwMCAtIHJpZ2h0fSVgIH19XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiUHJlw6dvIG3DrW5pbW8gKEVUSClcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiay1yYW5nZVwiXG4gICAgICAgICAgICBtaW49e2xvfVxuICAgICAgICAgICAgbWF4PXtoaX1cbiAgICAgICAgICAgIHN0ZXA9ezAuMDF9XG4gICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICB2YWx1ZT17bWlufVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNaW4oTWF0aC5taW4oTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSwgbWF4KSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiUHJlw6dvIG3DoXhpbW8gKEVUSClcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiay1yYW5nZVwiXG4gICAgICAgICAgICBtaW49e2xvfVxuICAgICAgICAgICAgbWF4PXtoaX1cbiAgICAgICAgICAgIHN0ZXA9ezAuMDF9XG4gICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICB2YWx1ZT17bWF4fVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNYXgoTWF0aC5tYXgoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSwgbWluKSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGxlYWRpbmctbm9ybWFsIHRleHQtZm9yZWdyb3VuZFwiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPlxuICAgICAgICAgIFByZcOnbzoge2Zvcm1hdEJyKE1hdGgubWluKG1pbiwgbWF4KSl9IC0ge2Zvcm1hdEJyKE1hdGgubWF4KG1pbiwgbWF4KSl9IEVUSFxuICAgICAgICA8L3A+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25BcHBseShtaW4gPD0gbG8gPyB1bmRlZmluZWQgOiByb3VuZChtaW4pLCBtYXggPj0gaGkgPyB1bmRlZmluZWQgOiByb3VuZChtYXgpKX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJzZWxmLXN0YXJ0IHJvdW5kZWQtWzZweF0gYmctcHJpbWFyeSBweC0zIHB5LTIgdGV4dC1iYXNlIGZvbnQtYm9sZCBsZWFkaW5nLTUgdGV4dC1wcmltYXJ5LWZvcmVncm91bmQgaG92ZXI6YnJpZ2h0bmVzcy0xMTAgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgID5cbiAgICAgICAgICBBcGxpY2FyXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9maWVsZHNldD5cbiAgKVxufVxuXG5jb25zdCByb3VuZCA9IChuOiBudW1iZXIpID0+IE1hdGgucm91bmQobiAqIDEwMCkgLyAxMDBcbiJdfQ==