import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/auth-shell.tsx");const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import { Link, useNavigate } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { Hero, Promos } from "/src/components/marketing/sections.tsx";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "/src/components/ui/dialog.tsx";
import { FigmaIcon } from "/src/components/ui/figma-icon.tsx";
import { useIsDesktop } from "/src/hooks/use-media.ts";
import { safeRedirect } from "/src/lib/format.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/auth/auth-shell.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
/**
* Desktop: modal 500px sobre a página do mercado (fundo inerte, com scrim), como no layout.
* Mobile: tela cheia com a marca KURIO.
*/
export function AuthShell({ mode, redirect, title, description, mobileTitle, footer, children }) {
	_s();
	const isDesktop = useIsDesktop();
	const navigate = useNavigate();
	const close = () => void navigate({
		to: safeRedirect(redirect),
		replace: true
	});
	if (!isDesktop) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "-mt-10 flex min-h-dvh flex-col gap-10 pb-6 pt-20",
			children: [
				/* @__PURE__ */ _jsxDEV("p", {
					"aria-hidden": true,
					className: "flex h-[136px] items-center justify-center text-[32px] font-bold tracking-[3.2px] text-foreground",
					children: "KURIO"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-center text-xl font-bold leading-6 text-foreground",
					children: mobileTitle
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "sr-only",
					children: description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this),
				children,
				/* @__PURE__ */ _jsxDEV(SocialBlock, { mobile: true }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-center text-[15px] leading-normal text-muted-foreground",
					children: footer
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
		"aria-hidden": true,
		inert: true,
		className: "pointer-events-none flex select-none flex-col gap-24",
		children: [/* @__PURE__ */ _jsxDEV(Hero, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV(Promos, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(Dialog, {
		open: true,
		onOpenChange: (open) => !open && close(),
		children: /* @__PURE__ */ _jsxDEV(DialogContent, {
			className: "top-[max(1rem,min(160px,calc(50dvh-330px)))] max-h-[calc(100dvh-2rem)] max-w-[500px] translate-y-0 gap-0 overflow-y-auto rounded-none border-0 bg-card p-0 pb-[10px]",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col items-center gap-10 px-12 pt-12",
					children: [
						/* @__PURE__ */ _jsxDEV("nav", {
							"aria-label": "Acesso",
							className: "flex items-stretch gap-2 text-xl font-medium leading-4",
							children: [
								/* @__PURE__ */ _jsxDEV(AuthTab, {
									to: "/login",
									active: mode === "login",
									redirect,
									children: "Entrar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 64,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									"aria-hidden": true,
									className: "w-px bg-coral"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(AuthTab, {
									to: "/signup",
									active: mode === "signup",
									redirect,
									children: "Criar conta"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 68,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(DialogTitle, {
							className: "sr-only",
							children: title
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(DialogDescription, {
							className: "text-center text-[13px] font-normal leading-4 text-foreground",
							children: description
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 11
				}, this),
				children,
				/* @__PURE__ */ _jsxDEV(SocialBlock, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-center px-20 pb-8 pt-6 text-[13px] text-muted-foreground",
					children: footer
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					"aria-hidden": true,
					className: "absolute inset-x-0 bottom-0 h-2.5 bg-primary"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 54,
		columnNumber: 5
	}, this);
}
_s(AuthShell, "wxHieHlW5sJDMjpDK+WDvW4mBpM=", false, function() {
	return [useIsDesktop, useNavigate];
});
_c = AuthShell;
function AuthTab({ to, active, redirect, children }) {
	return /* @__PURE__ */ _jsxDEV(Link, {
		to,
		search: { redirect },
		replace: true,
		"aria-current": active ? "page" : undefined,
		className: cn("py-1", active ? "text-accent underline decoration-transparent" : "text-foreground hover:text-accent"),
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 87,
		columnNumber: 5
	}, this);
}
_c2 = AuthTab;
/** "Ou continue com" + Google/Facebook. Login social não existe na simulação: avisa em vez de fingir. */
function SocialBlock({ mobile }) {
	_s2();
	const [message, setMessage] = useState(null);
	const providers = [{
		name: "Google",
		icon: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
			name: "logo-google",
			width: 20,
			original: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 103,
			columnNumber: 29
		}, this)
	}, {
		name: "Facebook",
		icon: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
			name: "logo-facebook",
			width: 20,
			original: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 104,
			columnNumber: 31
		}, this)
	}];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn("flex flex-col", mobile ? "gap-3" : "gap-3 pt-6"),
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: cn("flex items-center", mobile ? "gap-2.5" : "gap-3"),
			children: [
				/* @__PURE__ */ _jsxDEV("span", {
					"aria-hidden": true,
					className: "h-px flex-1 bg-border"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-[13px] leading-4 text-foreground",
					children: "Ou continue com"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					"aria-hidden": true,
					className: "h-px flex-1 bg-border"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 108,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: cn("flex flex-col", mobile ? "gap-4" : "gap-3 px-20"),
			children: [providers.map((p) => /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: () => setMessage(`Entrar com ${p.name} não está disponível nesta demonstração. Use e-mail e senha.`),
				className: "flex h-10 items-center justify-center gap-3 rounded-[5px] border border-border text-[13px] font-medium leading-4 text-muted-foreground hover:border-border-soft hover:text-foreground",
				children: [
					p.icon,
					"Continuar com ",
					p.name
				]
			}, p.name, true, {
				fileName: _jsxFileName,
				lineNumber: 115,
				columnNumber: 11
			}, this)), /* @__PURE__ */ _jsxDEV("p", {
				"aria-live": "polite",
				className: cn("text-center text-xs text-accent", !message && "sr-only"),
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 125,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 113,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 107,
		columnNumber: 5
	}, this);
}
_s2(SocialBlock, "oxT8SEz5FIjvFP5ix50Ku0sapH4=");
_c3 = SocialBlock;
/** Estilos dos campos das telas de acesso (desktop 40px/raio 5; mobile 50px/raio 10). */
export function useAuthFieldClass() {
	_s3();
	const isDesktop = useIsDesktop();
	return isDesktop ? "h-10 rounded-[5px] px-4" : "h-[50px] rounded-[10px] px-4";
}
_s3(useAuthFieldClass, "LPvPO2c3CxR8xrtzm1E56phj+VA=", false, function() {
	return [useIsDesktop];
});
var _c, _c2, _c3;
$RefreshReg$(_c, "AuthShell");
$RefreshReg$(_c2, "AuthTab");
$RefreshReg$(_c3, "SocialBlock");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/auth/auth-shell.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/auth/auth-shell.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/auth/auth-shell.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/auth/auth-shell.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG1CQUFtQjtBQUVsQyxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLE1BQU0sY0FBYztBQUM3QixTQUFTLFFBQVEsZUFBZSxtQkFBbUIsbUJBQW1CO0FBQ3RFLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsVUFBVTs7Ozs7Ozs7QUFRbkIsT0FBTyxTQUFTLFVBQVUsRUFDeEIsTUFDQSxVQUNBLE9BQ0EsYUFDQSxhQUNBLFFBQ0EsWUFTQzs7Q0FDRCxNQUFNLFlBQVksYUFBYTtDQUMvQixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLGNBQWMsS0FBSyxTQUFTO0VBQUUsSUFBSSxhQUFhLFFBQVE7RUFBRyxTQUFTO0NBQUssQ0FBQztDQUUvRSxJQUFJLENBQUMsV0FBVztFQUNkLE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLEtBQUQ7S0FBRztLQUFZLFdBQVU7ZUFBb0c7SUFFMUg7Ozs7O0lBQ0gsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBMkQ7SUFBZ0I7Ozs7O0lBQ3pGLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQVc7SUFBZTs7Ozs7SUFDdEM7SUFDRCx3QkFBQyxhQUFELEVBQWEsYUFBUTs7Ozs7SUFDckIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBd0U7SUFBWTs7Ozs7R0FDaEc7Ozs7OztDQUVUO0NBRUEsT0FDRSxnREFFRSx3QkFBQyxPQUFEO0VBQUs7RUFBWTtFQUFNLFdBQVU7WUFBakMsQ0FDRSx3QkFBQyxNQUFELENBQU87Ozs7WUFDUCx3QkFBQyxRQUFELENBQVM7Ozs7VUFDTjs7Ozs7V0FDTCx3QkFBQyxRQUFEO0VBQVE7RUFBSyxlQUFlLFNBQVMsQ0FBQyxRQUFRLE1BQU07WUFDbEQsd0JBQUMsZUFBRDtHQUFlLFdBQVU7YUFBekI7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLGNBQVc7T0FBUyxXQUFVO2lCQUFuQztRQUNFLHdCQUFDLFNBQUQ7U0FBUyxJQUFHO1NBQVMsUUFBUSxTQUFTO1NBQW1CO21CQUFVO1FBRTFEOzs7OztRQUNULHdCQUFDLFFBQUQ7U0FBTTtTQUFZLFdBQVU7UUFBaUI7Ozs7O1FBQzdDLHdCQUFDLFNBQUQ7U0FBUyxJQUFHO1NBQVUsUUFBUSxTQUFTO1NBQW9CO21CQUFVO1FBRTVEOzs7OztPQUNOOzs7Ozs7TUFDTCx3QkFBQyxhQUFEO09BQWEsV0FBVTtpQkFBVztNQUFtQjs7Ozs7TUFDckQsd0JBQUMsbUJBQUQ7T0FBbUIsV0FBVTtpQkFBaUU7TUFBK0I7Ozs7O0tBQzFIOzs7Ozs7SUFDSjtJQUNELHdCQUFDLGFBQUQsQ0FBYzs7Ozs7SUFDZCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUF5RTtJQUFZOzs7OztJQUNwRyx3QkFBQyxRQUFEO0tBQU07S0FBWSxXQUFVO0lBQWdEOzs7OztHQUMvRDs7Ozs7O0NBQ1Q7Ozs7U0FDUjs7Ozs7QUFFTjs7Ozs7QUFFQSxTQUFTLFFBQVEsRUFBRSxJQUFJLFFBQVEsVUFBVSxZQUF5RztDQUNoSixPQUNFLHdCQUFDLE1BQUQ7RUFDTTtFQUNKLFFBQVEsRUFBRSxTQUFTO0VBQ25CO0VBQ0EsZ0JBQWMsU0FBUyxTQUFTO0VBQ2hDLFdBQVcsR0FBRyxRQUFRLFNBQVMsaURBQWlELG1DQUFtQztFQUVsSDtDQUNHOzs7OztBQUVWOzs7QUFHQSxTQUFTLFlBQVksRUFBRSxVQUFnQzs7Q0FDckQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUF3QixJQUFJO0NBQzFELE1BQU0sWUFBWSxDQUNoQjtFQUFFLE1BQU07RUFBVSxNQUFNLHdCQUFDLFdBQUQ7R0FBVyxNQUFLO0dBQWMsT0FBTztHQUFJO0VBQVU7Ozs7O0NBQUUsR0FDN0U7RUFBRSxNQUFNO0VBQVksTUFBTSx3QkFBQyxXQUFEO0dBQVcsTUFBSztHQUFnQixPQUFPO0dBQUk7RUFBVTs7Ozs7Q0FBRSxDQUNuRjtDQUNBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVcsR0FBRyxpQkFBaUIsU0FBUyxVQUFVLFlBQVk7WUFBbkUsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVyxHQUFHLHFCQUFxQixTQUFTLFlBQVksT0FBTzthQUFwRTtJQUNFLHdCQUFDLFFBQUQ7S0FBTTtLQUFZLFdBQVU7SUFBeUI7Ozs7O0lBQ3JELHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXdDO0lBQWtCOzs7OztJQUN2RSx3QkFBQyxRQUFEO0tBQU07S0FBWSxXQUFVO0lBQXlCOzs7OztHQUNsRDs7Ozs7WUFDTCx3QkFBQyxPQUFEO0dBQUssV0FBVyxHQUFHLGlCQUFpQixTQUFTLFVBQVUsYUFBYTthQUFwRSxDQUNHLFVBQVUsS0FBSyxNQUNkLHdCQUFDLFVBQUQ7SUFFRSxNQUFLO0lBQ0wsZUFBZSxXQUFXLGNBQWMsRUFBRSxLQUFLLDZEQUE2RDtJQUM1RyxXQUFVO2NBSlo7S0FNRyxFQUFFO0tBQUs7S0FDTyxFQUFFO0lBQ1g7TUFQRCxFQUFFOzs7O1VBT0QsQ0FDVCxHQUNELHdCQUFDLEtBQUQ7SUFBRyxhQUFVO0lBQVMsV0FBVyxHQUFHLG1DQUFtQyxDQUFDLFdBQVcsU0FBUztjQUN6RjtHQUNBOzs7O1dBQ0E7Ozs7O1VBQ0Y7Ozs7OztBQUVUOzs7O0FBR0EsT0FBTyxTQUFTLG9CQUFvQjs7Q0FDbEMsTUFBTSxZQUFZLGFBQWE7Q0FDL0IsT0FBTyxZQUFZLDRCQUE0QjtBQUNqRCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJhdXRoLXNoZWxsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgdHlwZSAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IEhlcm8sIFByb21vcyB9IGZyb20gJ0AvY29tcG9uZW50cy9tYXJrZXRpbmcvc2VjdGlvbnMnXG5pbXBvcnQgeyBEaWFsb2csIERpYWxvZ0NvbnRlbnQsIERpYWxvZ0Rlc2NyaXB0aW9uLCBEaWFsb2dUaXRsZSB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9kaWFsb2cnXG5pbXBvcnQgeyBGaWdtYUljb24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvZmlnbWEtaWNvbidcbmltcG9ydCB7IHVzZUlzRGVza3RvcCB9IGZyb20gJ0AvaG9va3MvdXNlLW1lZGlhJ1xuaW1wb3J0IHsgc2FmZVJlZGlyZWN0IH0gZnJvbSAnQC9saWIvZm9ybWF0J1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcblxudHlwZSBNb2RlID0gJ2xvZ2luJyB8ICdzaWdudXAnXG5cbi8qKlxuICogRGVza3RvcDogbW9kYWwgNTAwcHggc29icmUgYSBww6FnaW5hIGRvIG1lcmNhZG8gKGZ1bmRvIGluZXJ0ZSwgY29tIHNjcmltKSwgY29tbyBubyBsYXlvdXQuXG4gKiBNb2JpbGU6IHRlbGEgY2hlaWEgY29tIGEgbWFyY2EgS1VSSU8uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBBdXRoU2hlbGwoe1xuICBtb2RlLFxuICByZWRpcmVjdCxcbiAgdGl0bGUsXG4gIGRlc2NyaXB0aW9uLFxuICBtb2JpbGVUaXRsZSxcbiAgZm9vdGVyLFxuICBjaGlsZHJlbixcbn06IHtcbiAgbW9kZTogTW9kZVxuICByZWRpcmVjdD86IHN0cmluZ1xuICB0aXRsZTogc3RyaW5nXG4gIGRlc2NyaXB0aW9uOiBzdHJpbmdcbiAgbW9iaWxlVGl0bGU6IHN0cmluZ1xuICBmb290ZXI6IFJlYWN0LlJlYWN0Tm9kZVxuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlXG59KSB7XG4gIGNvbnN0IGlzRGVza3RvcCA9IHVzZUlzRGVza3RvcCgpXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCBjbG9zZSA9ICgpID0+IHZvaWQgbmF2aWdhdGUoeyB0bzogc2FmZVJlZGlyZWN0KHJlZGlyZWN0KSwgcmVwbGFjZTogdHJ1ZSB9KVxuXG4gIGlmICghaXNEZXNrdG9wKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiLW10LTEwIGZsZXggbWluLWgtZHZoIGZsZXgtY29sIGdhcC0xMCBwYi02IHB0LTIwXCI+XG4gICAgICAgIDxwIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT1cImZsZXggaC1bMTM2cHhdIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LVszMnB4XSBmb250LWJvbGQgdHJhY2tpbmctWzMuMnB4XSB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICBLVVJJT1xuICAgICAgICA8L3A+XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXhsIGZvbnQtYm9sZCBsZWFkaW5nLTYgdGV4dC1mb3JlZ3JvdW5kXCI+e21vYmlsZVRpdGxlfTwvaDE+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInNyLW9ubHlcIj57ZGVzY3JpcHRpb259PC9wPlxuICAgICAgICB7Y2hpbGRyZW59XG4gICAgICAgIDxTb2NpYWxCbG9jayBtb2JpbGUgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHRleHQtWzE1cHhdIGxlYWRpbmctbm9ybWFsIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntmb290ZXJ9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICB7LyogUMOhZ2luYSBkbyBtZXJjYWRvIGFvIGZ1bmRvLCBjb21vIG5vIGxheW91dDogYXBlbmFzIHZpc3VhbCwgZm9yYSBkYSDDoXJ2b3JlIGRlIGFjZXNzaWJpbGlkYWRlLiAqL31cbiAgICAgIDxkaXYgYXJpYS1oaWRkZW4gaW5lcnQgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBmbGV4IHNlbGVjdC1ub25lIGZsZXgtY29sIGdhcC0yNFwiPlxuICAgICAgICA8SGVybyAvPlxuICAgICAgICA8UHJvbW9zIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxEaWFsb2cgb3BlbiBvbk9wZW5DaGFuZ2U9eyhvcGVuKSA9PiAhb3BlbiAmJiBjbG9zZSgpfT5cbiAgICAgICAgPERpYWxvZ0NvbnRlbnQgY2xhc3NOYW1lPVwidG9wLVttYXgoMXJlbSxtaW4oMTYwcHgsY2FsYyg1MGR2aC0zMzBweCkpKV0gbWF4LWgtW2NhbGMoMTAwZHZoLTJyZW0pXSBtYXgtdy1bNTAwcHhdIHRyYW5zbGF0ZS15LTAgZ2FwLTAgb3ZlcmZsb3cteS1hdXRvIHJvdW5kZWQtbm9uZSBib3JkZXItMCBiZy1jYXJkIHAtMCBwYi1bMTBweF1cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0xMCBweC0xMiBwdC0xMlwiPlxuICAgICAgICAgICAgPG5hdiBhcmlhLWxhYmVsPVwiQWNlc3NvXCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdHJldGNoIGdhcC0yIHRleHQteGwgZm9udC1tZWRpdW0gbGVhZGluZy00XCI+XG4gICAgICAgICAgICAgIDxBdXRoVGFiIHRvPVwiL2xvZ2luXCIgYWN0aXZlPXttb2RlID09PSAnbG9naW4nfSByZWRpcmVjdD17cmVkaXJlY3R9PlxuICAgICAgICAgICAgICAgIEVudHJhclxuICAgICAgICAgICAgICA8L0F1dGhUYWI+XG4gICAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT1cInctcHggYmctY29yYWxcIiAvPlxuICAgICAgICAgICAgICA8QXV0aFRhYiB0bz1cIi9zaWdudXBcIiBhY3RpdmU9e21vZGUgPT09ICdzaWdudXAnfSByZWRpcmVjdD17cmVkaXJlY3R9PlxuICAgICAgICAgICAgICAgIENyaWFyIGNvbnRhXG4gICAgICAgICAgICAgIDwvQXV0aFRhYj5cbiAgICAgICAgICAgIDwvbmF2PlxuICAgICAgICAgICAgPERpYWxvZ1RpdGxlIGNsYXNzTmFtZT1cInNyLW9ubHlcIj57dGl0bGV9PC9EaWFsb2dUaXRsZT5cbiAgICAgICAgICAgIDxEaWFsb2dEZXNjcmlwdGlvbiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LVsxM3B4XSBmb250LW5vcm1hbCBsZWFkaW5nLTQgdGV4dC1mb3JlZ3JvdW5kXCI+e2Rlc2NyaXB0aW9ufTwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge2NoaWxkcmVufVxuICAgICAgICAgIDxTb2NpYWxCbG9jayAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweC0yMCBwYi04IHB0LTYgdGV4dC1bMTNweF0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2Zvb3Rlcn08L2Rpdj5cbiAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC14LTAgYm90dG9tLTAgaC0yLjUgYmctcHJpbWFyeVwiIC8+XG4gICAgICAgIDwvRGlhbG9nQ29udGVudD5cbiAgICAgIDwvRGlhbG9nPlxuICAgIDwvPlxuICApXG59XG5cbmZ1bmN0aW9uIEF1dGhUYWIoeyB0bywgYWN0aXZlLCByZWRpcmVjdCwgY2hpbGRyZW4gfTogeyB0bzogJy9sb2dpbicgfCAnL3NpZ251cCc7IGFjdGl2ZTogYm9vbGVhbjsgcmVkaXJlY3Q/OiBzdHJpbmc7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuICByZXR1cm4gKFxuICAgIDxMaW5rXG4gICAgICB0bz17dG99XG4gICAgICBzZWFyY2g9e3sgcmVkaXJlY3QgfX1cbiAgICAgIHJlcGxhY2VcbiAgICAgIGFyaWEtY3VycmVudD17YWN0aXZlID8gJ3BhZ2UnIDogdW5kZWZpbmVkfVxuICAgICAgY2xhc3NOYW1lPXtjbigncHktMScsIGFjdGl2ZSA/ICd0ZXh0LWFjY2VudCB1bmRlcmxpbmUgZGVjb3JhdGlvbi10cmFuc3BhcmVudCcgOiAndGV4dC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtYWNjZW50Jyl9XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvTGluaz5cbiAgKVxufVxuXG4vKiogXCJPdSBjb250aW51ZSBjb21cIiArIEdvb2dsZS9GYWNlYm9vay4gTG9naW4gc29jaWFsIG7Do28gZXhpc3RlIG5hIHNpbXVsYcOnw6NvOiBhdmlzYSBlbSB2ZXogZGUgZmluZ2lyLiAqL1xuZnVuY3Rpb24gU29jaWFsQmxvY2soeyBtb2JpbGUgfTogeyBtb2JpbGU/OiBib29sZWFuIH0pIHtcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbClcbiAgY29uc3QgcHJvdmlkZXJzID0gW1xuICAgIHsgbmFtZTogJ0dvb2dsZScsIGljb246IDxGaWdtYUljb24gbmFtZT1cImxvZ28tZ29vZ2xlXCIgd2lkdGg9ezIwfSBvcmlnaW5hbCAvPiB9LFxuICAgIHsgbmFtZTogJ0ZhY2Vib29rJywgaWNvbjogPEZpZ21hSWNvbiBuYW1lPVwibG9nby1mYWNlYm9va1wiIHdpZHRoPXsyMH0gb3JpZ2luYWwgLz4gfSxcbiAgXVxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtjbignZmxleCBmbGV4LWNvbCcsIG1vYmlsZSA/ICdnYXAtMycgOiAnZ2FwLTMgcHQtNicpfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtjbignZmxleCBpdGVtcy1jZW50ZXInLCBtb2JpbGUgPyAnZ2FwLTIuNScgOiAnZ2FwLTMnKX0+XG4gICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT1cImgtcHggZmxleC0xIGJnLWJvcmRlclwiIC8+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGxlYWRpbmctNCB0ZXh0LWZvcmVncm91bmRcIj5PdSBjb250aW51ZSBjb208L3A+XG4gICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT1cImgtcHggZmxleC0xIGJnLWJvcmRlclwiIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtjbignZmxleCBmbGV4LWNvbCcsIG1vYmlsZSA/ICdnYXAtNCcgOiAnZ2FwLTMgcHgtMjAnKX0+XG4gICAgICAgIHtwcm92aWRlcnMubWFwKChwKSA9PiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAga2V5PXtwLm5hbWV9XG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1lc3NhZ2UoYEVudHJhciBjb20gJHtwLm5hbWV9IG7Do28gZXN0w6EgZGlzcG9uw612ZWwgbmVzdGEgZGVtb25zdHJhw6fDo28uIFVzZSBlLW1haWwgZSBzZW5oYS5gKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTMgcm91bmRlZC1bNXB4XSBib3JkZXIgYm9yZGVyLWJvcmRlciB0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSBsZWFkaW5nLTQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOmJvcmRlci1ib3JkZXItc29mdCBob3Zlcjp0ZXh0LWZvcmVncm91bmRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtwLmljb259XG4gICAgICAgICAgICBDb250aW51YXIgY29tIHtwLm5hbWV9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICkpfVxuICAgICAgICA8cCBhcmlhLWxpdmU9XCJwb2xpdGVcIiBjbGFzc05hbWU9e2NuKCd0ZXh0LWNlbnRlciB0ZXh0LXhzIHRleHQtYWNjZW50JywgIW1lc3NhZ2UgJiYgJ3NyLW9ubHknKX0+XG4gICAgICAgICAge21lc3NhZ2V9XG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbi8qKiBFc3RpbG9zIGRvcyBjYW1wb3MgZGFzIHRlbGFzIGRlIGFjZXNzbyAoZGVza3RvcCA0MHB4L3JhaW8gNTsgbW9iaWxlIDUwcHgvcmFpbyAxMCkuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlQXV0aEZpZWxkQ2xhc3MoKSB7XG4gIGNvbnN0IGlzRGVza3RvcCA9IHVzZUlzRGVza3RvcCgpXG4gIHJldHVybiBpc0Rlc2t0b3AgPyAnaC0xMCByb3VuZGVkLVs1cHhdIHB4LTQnIDogJ2gtWzUwcHhdIHJvdW5kZWQtWzEwcHhdIHB4LTQnXG59XG4iXX0=