import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/mock/mock-panel.tsx");const useState = __vite__cjsImport1_react["useState"]; const useSyncExternalStore = __vite__cjsImport1_react["useSyncExternalStore"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import { FlaskConical } from "/node_modules/.vite/deps/lucide-react.js?v=b07c072a";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { Button } from "/src/components/ui/button.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Select } from "/src/components/ui/select.tsx";
import "/src/mocks/control.ts";
import { scenarioStore } from "/src/mocks/scenario.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/mock/mock-panel.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$();
/**
* Painel de simulação (somente com mocks ativos): alterna latência, falhas,
* resultado de pagamento e dispara eventos em tempo real para demonstrar
* cada cenário exigido sem editar código.
*/
export default function MockPanel() {
	_s();
	const [open, setOpen] = useState(false);
	const scenario = useSyncExternalStore(scenarioStore.subscribe, scenarioStore.get, scenarioStore.get);
	const [nftId, setNftId] = useState("nft-001");
	const control = window.__mock;
	if (!control) return null;
	const set = (key, value) => control.setScenario({ [key]: value });
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed bottom-4 left-4 z-[55]",
		children: open ? /* @__PURE__ */ _jsxDEV("section", {
			"aria-label": "Painel de simulação",
			className: "w-[min(22rem,calc(100vw-2rem))] space-y-3 rounded-lg border bg-card p-4 text-sm shadow-xl",
			"data-testid": "mock-panel",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "font-semibold",
						children: "Simulação"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setOpen(false),
						children: "Fechar"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ _jsxDEV(Label, {
								htmlFor: "mock-latency",
								children: "Latência"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 40,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Select, {
								id: "mock-latency",
								value: scenario.latency,
								onChange: (e) => set("latency", e.target.value),
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "fast",
										children: "Rápida"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 42,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "slow",
										children: "Lenta"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 43,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "variable",
										children: "Variável (fora de ordem)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 44,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 41,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ _jsxDEV(Label, {
								htmlFor: "mock-failure",
								children: "Falha de rede"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 48,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Select, {
								id: "mock-failure",
								value: scenario.failure,
								onChange: (e) => set("failure", e.target.value),
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "none",
										children: "Nenhuma"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 50,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "network",
										children: "Sem conexão"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 51,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "500",
										children: "HTTP 500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 52,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "503",
										children: "HTTP 503"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 53,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ _jsxDEV(Label, {
								htmlFor: "mock-payment",
								children: "Pagamento"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 57,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Select, {
								id: "mock-payment",
								value: scenario.payment,
								onChange: (e) => set("payment", e.target.value),
								children: [/* @__PURE__ */ _jsxDEV("option", {
									value: "confirmed",
									children: "Confirmado"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 59,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("option", {
									value: "refused",
									children: "Recusado"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 60,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 58,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ _jsxDEV(Label, {
								htmlFor: "mock-wallet",
								children: "Carteira"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Select, {
								id: "mock-wallet",
								value: scenario.wallet,
								onChange: (e) => set("wallet", e.target.value),
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "ok",
										children: "Conecta"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 66,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "refused",
										children: "Recusa conexão"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 67,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "disconnected",
										children: "Desconecta na compra"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 68,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("fieldset", {
					className: "space-y-1.5",
					children: [
						/* @__PURE__ */ _jsxDEV("legend", {
							className: "mb-1 text-xs text-muted-foreground",
							children: "Na próxima compra"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 13
						}, this),
						[
							["priceChangeOnCheckout", "Preço muda durante a compra"],
							["soldOutOnCheckout", "Item esgota durante a compra"],
							["orderTimeout", "Resposta do pedido expira (timeout)"]
						].map(([key, label]) => /* @__PURE__ */ _jsxDEV("label", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "checkbox",
								checked: scenario[key],
								onChange: (e) => set(key, e.target.checked)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 17
							}, this), label]
						}, key, true, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 15
						}, this)),
						/* @__PURE__ */ _jsxDEV("label", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "checkbox",
								checked: scenario.ticker,
								onChange: (e) => set("ticker", e.target.checked)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 88,
								columnNumber: 15
							}, this), "Mercado ativo (eventos periódicos)"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-1.5 border-t pt-3",
					children: [/* @__PURE__ */ _jsxDEV(Label, {
						htmlFor: "mock-nft",
						children: "Emitir nft.updated"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ _jsxDEV("input", {
							id: "mock-nft",
							value: nftId,
							onChange: (e) => setNftId(e.target.value),
							className: "h-9 w-full rounded-md border bg-transparent px-2"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => control.updateNft(nftId, {
								price: "0.2222",
								available: 1
							}),
							children: "Disparar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap gap-2 border-t pt-3",
					children: [
						/* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => control.expireSessions(),
							children: "Expirar sessão"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => control.dropSocket(),
							children: "Derrubar socket"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							variant: "destructive",
							onClick: () => {
								control.reset();
								window.location.assign("/");
							},
							children: "Resetar dados"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV(Button, {
			variant: "secondary",
			size: "sm",
			className: "shadow-lg",
			onClick: () => setOpen(true),
			"aria-label": "Abrir painel de simulação",
			children: [/* @__PURE__ */ _jsxDEV(FlaskConical, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 133,
				columnNumber: 11
			}, this), " Simulação"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 132,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 5
	}, this);
}
_s(MockPanel, "YBK/czq/ky4HjBndgTNLoHEiWSc=");
_c = MockPanel;
var _c;
$RefreshReg$(_c, "MockPanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/mock/mock-panel.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/mock/mock-panel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/mock/mock-panel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/mock/mock-panel.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxVQUFVLDRCQUE0QjtBQUMvQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsY0FBYztBQUN2QixPQUFPO0FBQ1AsU0FBUyxxQkFBb0M7Ozs7Ozs7OztBQU83QyxlQUFlLFNBQVMsWUFBWTs7Q0FDbEMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxXQUFXLHFCQUFxQixjQUFjLFdBQVcsY0FBYyxLQUFLLGNBQWMsR0FBRztDQUNuRyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsU0FBUztDQUM1QyxNQUFNLFVBQVUsT0FBTztDQUN2QixJQUFJLENBQUMsU0FBUyxPQUFPO0NBRXJCLE1BQU0sT0FBaUMsS0FBUSxVQUF1QixRQUFRLFlBQVksR0FBRyxNQUFNLE1BQU0sQ0FBQztDQUUxRyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ1osT0FDQyx3QkFBQyxXQUFEO0dBQ0UsY0FBVztHQUNYLFdBQVU7R0FDVixlQUFZO2FBSGQ7SUFLRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWdCO0tBQWE7Ozs7ZUFDM0Msd0JBQUMsUUFBRDtNQUFRLE1BQUs7TUFBSyxTQUFRO01BQVEsZUFBZSxRQUFRLEtBQUs7Z0JBQUc7S0FFekQ7Ozs7YUFDTDs7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFPLFNBQVE7a0JBQWU7T0FBZTs7OztpQkFDN0Msd0JBQUMsUUFBRDtRQUFRLElBQUc7UUFBZSxPQUFPLFNBQVM7UUFBUyxXQUFXLE1BQU0sSUFBSSxXQUFXLEVBQUUsT0FBTyxLQUE0QjtrQkFBeEg7U0FDRSx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBTztTQUFjOzs7OztTQUNuQyx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBTztTQUFhOzs7OztTQUNsQyx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBVztTQUFnQzs7Ozs7UUFDbkQ7Ozs7O2VBQ0w7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFPLFNBQVE7a0JBQWU7T0FBb0I7Ozs7aUJBQ2xELHdCQUFDLFFBQUQ7UUFBUSxJQUFHO1FBQWUsT0FBTyxTQUFTO1FBQVMsV0FBVyxNQUFNLElBQUksV0FBVyxFQUFFLE9BQU8sS0FBNEI7a0JBQXhIO1NBQ0Usd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQU87U0FBZTs7Ozs7U0FDcEMsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQVU7U0FBbUI7Ozs7O1NBQzNDLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFNO1NBQWdCOzs7OztTQUNwQyx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBTTtTQUFnQjs7Ozs7UUFDOUI7Ozs7O2VBQ0w7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFPLFNBQVE7a0JBQWU7T0FBZ0I7Ozs7aUJBQzlDLHdCQUFDLFFBQUQ7UUFBUSxJQUFHO1FBQWUsT0FBTyxTQUFTO1FBQVMsV0FBVyxNQUFNLElBQUksV0FBVyxFQUFFLE9BQU8sS0FBNEI7a0JBQXhILENBQ0Usd0JBQUMsVUFBRDtTQUFRLE9BQU07bUJBQVk7UUFBa0I7Ozs7a0JBQzVDLHdCQUFDLFVBQUQ7U0FBUSxPQUFNO21CQUFVO1FBQWdCOzs7O2dCQUNsQzs7Ozs7ZUFDTDs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQU8sU0FBUTtrQkFBYztPQUFlOzs7O2lCQUM1Qyx3QkFBQyxRQUFEO1FBQVEsSUFBRztRQUFjLE9BQU8sU0FBUztRQUFRLFdBQVcsTUFBTSxJQUFJLFVBQVUsRUFBRSxPQUFPLEtBQTJCO2tCQUFwSDtTQUNFLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFLO1NBQWU7Ozs7O1NBQ2xDLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFVO1NBQXNCOzs7OztTQUM5Qyx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBZTtTQUE0Qjs7Ozs7UUFDbkQ7Ozs7O2VBQ0w7Ozs7OztLQUNGOzs7Ozs7SUFFTCx3QkFBQyxZQUFEO0tBQVUsV0FBVTtlQUFwQjtNQUNFLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO2lCQUFxQztNQUF5Qjs7Ozs7TUFFOUU7T0FDRSxDQUFDLHlCQUF5Qiw2QkFBNkI7T0FDdkQsQ0FBQyxxQkFBcUIsOEJBQThCO09BQ3BELENBQUMsZ0JBQWdCLHFDQUFxQztNQUN4RCxDQUFDLENBQ0QsS0FBSyxDQUFDLEtBQUssV0FDWCx3QkFBQyxTQUFEO09BQWlCLFdBQVU7aUJBQTNCLENBQ0Usd0JBQUMsU0FBRDtRQUFPLE1BQUs7UUFBVyxTQUFTLFNBQVM7UUFBTSxXQUFXLE1BQU0sSUFBSSxLQUFLLEVBQUUsT0FBTyxPQUFPO09BQUk7Ozs7aUJBQzVGLEtBQ0k7U0FISzs7OzthQUdMLENBQ1I7TUFDRCx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sTUFBSztRQUFXLFNBQVMsU0FBUztRQUFRLFdBQVcsTUFBTSxJQUFJLFVBQVUsRUFBRSxPQUFPLE9BQU87T0FBSTs7OztpQkFBQyxvQ0FFaEc7Ozs7OztLQUNDOzs7Ozs7SUFFVix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFPLFNBQVE7Z0JBQVc7S0FBeUI7Ozs7ZUFDbkQsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxTQUFEO09BQ0UsSUFBRztPQUNILE9BQU87T0FDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztPQUN4QyxXQUFVO01BQ1g7Ozs7Z0JBQ0Qsd0JBQUMsUUFBRDtPQUNFLE1BQUs7T0FDTCxTQUFRO09BQ1IsZUFBZSxRQUFRLFVBQVUsT0FBTztRQUFFLE9BQU87UUFBVSxXQUFXO09BQUUsQ0FBQztpQkFDMUU7TUFFTzs7OztjQUNMOzs7OzthQUNGOzs7Ozs7SUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsUUFBRDtPQUFRLE1BQUs7T0FBSyxTQUFRO09BQVUsZUFBZSxRQUFRLGVBQWU7aUJBQUc7TUFFckU7Ozs7O01BQ1Isd0JBQUMsUUFBRDtPQUFRLE1BQUs7T0FBSyxTQUFRO09BQVUsZUFBZSxRQUFRLFdBQVc7aUJBQUc7TUFFakU7Ozs7O01BQ1Isd0JBQUMsUUFBRDtPQUNFLE1BQUs7T0FDTCxTQUFRO09BQ1IsZUFBZTtRQUNiLFFBQVEsTUFBTTtRQUNkLE9BQU8sU0FBUyxPQUFPLEdBQUc7T0FDNUI7aUJBQ0Q7TUFFTzs7Ozs7S0FDTDs7Ozs7O0dBQ0U7Ozs7O2FBRVQsd0JBQUMsUUFBRDtHQUFRLFNBQVE7R0FBWSxNQUFLO0dBQUssV0FBVTtHQUFZLGVBQWUsUUFBUSxJQUFJO0dBQUcsY0FBVzthQUFyRyxDQUNFLHdCQUFDLGNBQUQsQ0FBZTs7OzthQUFDLFlBQ1Y7Ozs7OztDQUVQOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm1vY2stcGFuZWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZsYXNrQ29uaWNhbCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VTeW5jRXh0ZXJuYWxTdG9yZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IExhYmVsIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2xhYmVsJ1xuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NlbGVjdCdcbmltcG9ydCAnQC9tb2Nrcy9jb250cm9sJ1xuaW1wb3J0IHsgc2NlbmFyaW9TdG9yZSwgdHlwZSBTY2VuYXJpbyB9IGZyb20gJ0AvbW9ja3Mvc2NlbmFyaW8nXG5cbi8qKlxuICogUGFpbmVsIGRlIHNpbXVsYcOnw6NvIChzb21lbnRlIGNvbSBtb2NrcyBhdGl2b3MpOiBhbHRlcm5hIGxhdMOqbmNpYSwgZmFsaGFzLFxuICogcmVzdWx0YWRvIGRlIHBhZ2FtZW50byBlIGRpc3BhcmEgZXZlbnRvcyBlbSB0ZW1wbyByZWFsIHBhcmEgZGVtb25zdHJhclxuICogY2FkYSBjZW7DoXJpbyBleGlnaWRvIHNlbSBlZGl0YXIgY8OzZGlnby5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTW9ja1BhbmVsKCkge1xuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3Qgc2NlbmFyaW8gPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzY2VuYXJpb1N0b3JlLnN1YnNjcmliZSwgc2NlbmFyaW9TdG9yZS5nZXQsIHNjZW5hcmlvU3RvcmUuZ2V0KVxuICBjb25zdCBbbmZ0SWQsIHNldE5mdElkXSA9IHVzZVN0YXRlKCduZnQtMDAxJylcbiAgY29uc3QgY29udHJvbCA9IHdpbmRvdy5fX21vY2tcbiAgaWYgKCFjb250cm9sKSByZXR1cm4gbnVsbFxuXG4gIGNvbnN0IHNldCA9IDxLIGV4dGVuZHMga2V5b2YgU2NlbmFyaW8+KGtleTogSywgdmFsdWU6IFNjZW5hcmlvW0tdKSA9PiBjb250cm9sLnNldFNjZW5hcmlvKHsgW2tleV06IHZhbHVlIH0pXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGJvdHRvbS00IGxlZnQtNCB6LVs1NV1cIj5cbiAgICAgIHtvcGVuID8gKFxuICAgICAgICA8c2VjdGlvblxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJQYWluZWwgZGUgc2ltdWxhw6fDo29cIlxuICAgICAgICAgIGNsYXNzTmFtZT1cInctW21pbigyMnJlbSxjYWxjKDEwMHZ3LTJyZW0pKV0gc3BhY2UteS0zIHJvdW5kZWQtbGcgYm9yZGVyIGJnLWNhcmQgcC00IHRleHQtc20gc2hhZG93LXhsXCJcbiAgICAgICAgICBkYXRhLXRlc3RpZD1cIm1vY2stcGFuZWxcIlxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+U2ltdWxhw6fDo288L2gyPlxuICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX0+XG4gICAgICAgICAgICAgIEZlY2hhclxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwibW9jay1sYXRlbmN5XCI+TGF0w6puY2lhPC9MYWJlbD5cbiAgICAgICAgICAgICAgPFNlbGVjdCBpZD1cIm1vY2stbGF0ZW5jeVwiIHZhbHVlPXtzY2VuYXJpby5sYXRlbmN5fSBvbkNoYW5nZT17KGUpID0+IHNldCgnbGF0ZW5jeScsIGUudGFyZ2V0LnZhbHVlIGFzIFNjZW5hcmlvWydsYXRlbmN5J10pfT5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZmFzdFwiPlLDoXBpZGE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwic2xvd1wiPkxlbnRhPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInZhcmlhYmxlXCI+VmFyacOhdmVsIChmb3JhIGRlIG9yZGVtKTwvb3B0aW9uPlxuICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJtb2NrLWZhaWx1cmVcIj5GYWxoYSBkZSByZWRlPC9MYWJlbD5cbiAgICAgICAgICAgICAgPFNlbGVjdCBpZD1cIm1vY2stZmFpbHVyZVwiIHZhbHVlPXtzY2VuYXJpby5mYWlsdXJlfSBvbkNoYW5nZT17KGUpID0+IHNldCgnZmFpbHVyZScsIGUudGFyZ2V0LnZhbHVlIGFzIFNjZW5hcmlvWydmYWlsdXJlJ10pfT5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibm9uZVwiPk5lbmh1bWE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibmV0d29ya1wiPlNlbSBjb25leMOjbzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCI1MDBcIj5IVFRQIDUwMDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCI1MDNcIj5IVFRQIDUwMzwvb3B0aW9uPlxuICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJtb2NrLXBheW1lbnRcIj5QYWdhbWVudG88L0xhYmVsPlxuICAgICAgICAgICAgICA8U2VsZWN0IGlkPVwibW9jay1wYXltZW50XCIgdmFsdWU9e3NjZW5hcmlvLnBheW1lbnR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0KCdwYXltZW50JywgZS50YXJnZXQudmFsdWUgYXMgU2NlbmFyaW9bJ3BheW1lbnQnXSl9PlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjb25maXJtZWRcIj5Db25maXJtYWRvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInJlZnVzZWRcIj5SZWN1c2Fkbzwvb3B0aW9uPlxuICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJtb2NrLXdhbGxldFwiPkNhcnRlaXJhPC9MYWJlbD5cbiAgICAgICAgICAgICAgPFNlbGVjdCBpZD1cIm1vY2std2FsbGV0XCIgdmFsdWU9e3NjZW5hcmlvLndhbGxldH0gb25DaGFuZ2U9eyhlKSA9PiBzZXQoJ3dhbGxldCcsIGUudGFyZ2V0LnZhbHVlIGFzIFNjZW5hcmlvWyd3YWxsZXQnXSl9PlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJva1wiPkNvbmVjdGE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicmVmdXNlZFwiPlJlY3VzYSBjb25leMOjbzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJkaXNjb25uZWN0ZWRcIj5EZXNjb25lY3RhIG5hIGNvbXByYTwvb3B0aW9uPlxuICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGZpZWxkc2V0IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICA8bGVnZW5kIGNsYXNzTmFtZT1cIm1iLTEgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5OYSBwcsOzeGltYSBjb21wcmE8L2xlZ2VuZD5cbiAgICAgICAgICAgIHsoXG4gICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICBbJ3ByaWNlQ2hhbmdlT25DaGVja291dCcsICdQcmXDp28gbXVkYSBkdXJhbnRlIGEgY29tcHJhJ10sXG4gICAgICAgICAgICAgICAgWydzb2xkT3V0T25DaGVja291dCcsICdJdGVtIGVzZ290YSBkdXJhbnRlIGEgY29tcHJhJ10sXG4gICAgICAgICAgICAgICAgWydvcmRlclRpbWVvdXQnLCAnUmVzcG9zdGEgZG8gcGVkaWRvIGV4cGlyYSAodGltZW91dCknXSxcbiAgICAgICAgICAgICAgXSBhcyBjb25zdFxuICAgICAgICAgICAgKS5tYXAoKFtrZXksIGxhYmVsXSkgPT4gKFxuICAgICAgICAgICAgICA8bGFiZWwga2V5PXtrZXl9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e3NjZW5hcmlvW2tleV19IG9uQ2hhbmdlPXsoZSkgPT4gc2V0KGtleSwgZS50YXJnZXQuY2hlY2tlZCl9IC8+XG4gICAgICAgICAgICAgICAge2xhYmVsfVxuICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e3NjZW5hcmlvLnRpY2tlcn0gb25DaGFuZ2U9eyhlKSA9PiBzZXQoJ3RpY2tlcicsIGUudGFyZ2V0LmNoZWNrZWQpfSAvPlxuICAgICAgICAgICAgICBNZXJjYWRvIGF0aXZvIChldmVudG9zIHBlcmnDs2RpY29zKVxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8L2ZpZWxkc2V0PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNSBib3JkZXItdCBwdC0zXCI+XG4gICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cIm1vY2stbmZ0XCI+RW1pdGlyIG5mdC51cGRhdGVkPC9MYWJlbD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICBpZD1cIm1vY2stbmZ0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bmZ0SWR9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZnRJZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC05IHctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBiZy10cmFuc3BhcmVudCBweC0yXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNvbnRyb2wudXBkYXRlTmZ0KG5mdElkLCB7IHByaWNlOiAnMC4yMjIyJywgYXZhaWxhYmxlOiAxIH0pfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgRGlzcGFyYXJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTIgYm9yZGVyLXQgcHQtM1wiPlxuICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9eygpID0+IGNvbnRyb2wuZXhwaXJlU2Vzc2lvbnMoKX0+XG4gICAgICAgICAgICAgIEV4cGlyYXIgc2Vzc8Ojb1xuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17KCkgPT4gY29udHJvbC5kcm9wU29ja2V0KCl9PlxuICAgICAgICAgICAgICBEZXJydWJhciBzb2NrZXRcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29udHJvbC5yZXNldCgpXG4gICAgICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmFzc2lnbignLycpXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIFJlc2V0YXIgZGFkb3NcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L3NlY3Rpb24+XG4gICAgICApIDogKFxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBzaXplPVwic21cIiBjbGFzc05hbWU9XCJzaGFkb3ctbGdcIiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKHRydWUpfSBhcmlhLWxhYmVsPVwiQWJyaXIgcGFpbmVsIGRlIHNpbXVsYcOnw6NvXCI+XG4gICAgICAgICAgPEZsYXNrQ29uaWNhbCAvPiBTaW11bGHDp8Ojb1xuICAgICAgICA8L0J1dHRvbj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==