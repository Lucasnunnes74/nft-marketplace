import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/label.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport1_react, 1);const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import * as LabelPrimitive from "/node_modules/.vite/deps/@radix-ui_react-label.js?v=794cdd05";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/label.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
const Label = React.forwardRef(_c = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(LabelPrimitive.Root, {
	ref,
	className: cn("text-sm font-medium leading-none", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 9,
	columnNumber: 3
}, this));
_c2 = Label;
Label.displayName = "Label";
export { Label };
var _c, _c2;
$RefreshReg$(_c, "Label$React.forwardRef");
$RefreshReg$(_c2, "Label");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/label.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/label.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/label.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/label.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsWUFBWSxvQkFBb0I7QUFDaEMsWUFBWSxXQUFXO0FBQ3ZCLFNBQVMsVUFBVTs7O0FBRW5CLE1BQU0sUUFBUSxNQUFNLGlCQUdqQixFQUFFLFdBQVcsR0FBRyxTQUFTLFFBQzFCLHdCQUFDLGVBQWUsTUFBaEI7Q0FBMEI7Q0FBSyxXQUFXLEdBQUcsb0NBQW9DLFNBQVM7Q0FBRyxHQUFJO0FBQVE7Ozs7UUFDMUc7O0FBQ0QsTUFBTSxjQUFjO0FBQ3BCLFNBQVMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibGFiZWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIExhYmVsUHJpbWl0aXZlIGZyb20gJ0ByYWRpeC11aS9yZWFjdC1sYWJlbCdcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcblxuY29uc3QgTGFiZWwgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBSZWFjdC5Db21wb25lbnRSZWY8dHlwZW9mIExhYmVsUHJpbWl0aXZlLlJvb3Q+LFxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIExhYmVsUHJpbWl0aXZlLlJvb3Q+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxMYWJlbFByaW1pdGl2ZS5Sb290IHJlZj17cmVmfSBjbGFzc05hbWU9e2NuKCd0ZXh0LXNtIGZvbnQtbWVkaXVtIGxlYWRpbmctbm9uZScsIGNsYXNzTmFtZSl9IHsuLi5wcm9wc30gLz5cbikpXG5MYWJlbC5kaXNwbGF5TmFtZSA9ICdMYWJlbCdcbmV4cG9ydCB7IExhYmVsIH1cbiJdfQ==