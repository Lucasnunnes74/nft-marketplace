import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-Bk_YeHJf.js?v=1500aecb";
import { t as require_react } from "/node_modules/.vite/deps/react-Bk9vEtng.js?v=1500aecb";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom-f6U-7Wx1.js?v=1500aecb";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-XdfVfXhi.js?v=1500aecb";
import { r as createSlot } from "/node_modules/.vite/deps/dist-CqoI-OJ1.js?v=1500aecb";
//#region node_modules/@radix-ui/react-primitive/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var Primitive = [
	"a",
	"button",
	"div",
	"form",
	"h2",
	"h3",
	"img",
	"input",
	"label",
	"li",
	"nav",
	"ol",
	"p",
	"select",
	"span",
	"svg",
	"ul"
].reduce((primitive, node) => {
	const Slot = createSlot(`Primitive.${node}`);
	const Node = import_react.forwardRef((props, forwardedRef) => {
		const { asChild, ...primitiveProps } = props;
		const Comp = asChild ? Slot : node;
		if (typeof window !== "undefined") window[Symbol.for("radix-ui")] = true;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comp, {
			...primitiveProps,
			ref: forwardedRef
		});
	});
	Node.displayName = `Primitive.${node}`;
	return {
		...primitive,
		[node]: Node
	};
}, {});
function dispatchDiscreteCustomEvent(target, event) {
	if (target) import_react_dom.flushSync(() => target.dispatchEvent(event));
}
__name(dispatchDiscreteCustomEvent, "dispatchDiscreteCustomEvent");
//#endregion
export { dispatchDiscreteCustomEvent as n, Primitive as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlzdC1CLTByTGNMRy5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi9AcmFkaXgtdWkvcmVhY3QtcHJpbWl0aXZlL2Rpc3QvaW5kZXgubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIGNsaWVudFwiO1xudmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX25hbWUgPSAodGFyZ2V0LCB2YWx1ZSkgPT4gX19kZWZQcm9wKHRhcmdldCwgXCJuYW1lXCIsIHsgdmFsdWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSB9KTtcblxuLy8gc3JjL3ByaW1pdGl2ZS50c3hcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0ICogYXMgUmVhY3RET00gZnJvbSBcInJlYWN0LWRvbVwiO1xuaW1wb3J0IHsgY3JlYXRlU2xvdCB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3Qtc2xvdFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG52YXIgTk9ERVMgPSBbXG4gIFwiYVwiLFxuICBcImJ1dHRvblwiLFxuICBcImRpdlwiLFxuICBcImZvcm1cIixcbiAgXCJoMlwiLFxuICBcImgzXCIsXG4gIFwiaW1nXCIsXG4gIFwiaW5wdXRcIixcbiAgXCJsYWJlbFwiLFxuICBcImxpXCIsXG4gIFwibmF2XCIsXG4gIFwib2xcIixcbiAgXCJwXCIsXG4gIFwic2VsZWN0XCIsXG4gIFwic3BhblwiLFxuICBcInN2Z1wiLFxuICBcInVsXCJcbl07XG52YXIgUHJpbWl0aXZlID0gTk9ERVMucmVkdWNlKChwcmltaXRpdmUsIG5vZGUpID0+IHtcbiAgY29uc3QgU2xvdCA9IGNyZWF0ZVNsb3QoYFByaW1pdGl2ZS4ke25vZGV9YCk7XG4gIGNvbnN0IE5vZGUgPSBSZWFjdC5mb3J3YXJkUmVmKChwcm9wcywgZm9yd2FyZGVkUmVmKSA9PiB7XG4gICAgY29uc3QgeyBhc0NoaWxkLCAuLi5wcmltaXRpdmVQcm9wcyB9ID0gcHJvcHM7XG4gICAgY29uc3QgQ29tcCA9IGFzQ2hpbGQgPyBTbG90IDogbm9kZTtcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgd2luZG93W1N5bWJvbC5mb3IoXCJyYWRpeC11aVwiKV0gPSB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChDb21wLCB7IC4uLnByaW1pdGl2ZVByb3BzLCByZWY6IGZvcndhcmRlZFJlZiB9KTtcbiAgfSk7XG4gIE5vZGUuZGlzcGxheU5hbWUgPSBgUHJpbWl0aXZlLiR7bm9kZX1gO1xuICByZXR1cm4geyAuLi5wcmltaXRpdmUsIFtub2RlXTogTm9kZSB9O1xufSwge30pO1xuZnVuY3Rpb24gZGlzcGF0Y2hEaXNjcmV0ZUN1c3RvbUV2ZW50KHRhcmdldCwgZXZlbnQpIHtcbiAgaWYgKHRhcmdldCkgUmVhY3RET00uZmx1c2hTeW5jKCgpID0+IHRhcmdldC5kaXNwYXRjaEV2ZW50KGV2ZW50KSk7XG59XG5fX25hbWUoZGlzcGF0Y2hEaXNjcmV0ZUN1c3RvbUV2ZW50LCBcImRpc3BhdGNoRGlzY3JldGVDdXN0b21FdmVudFwiKTtcbmV4cG9ydCB7XG4gIFByaW1pdGl2ZSxcbiAgUHJpbWl0aXZlIGFzIFJvb3QsXG4gIGRpc3BhdGNoRGlzY3JldGVDdXN0b21FdmVudFxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXBcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0EsSUFBSSxZQUFZLE9BQU87QUFDdkIsSUFBSSxVQUFVLFFBQVEsVUFBVSxVQUFVLFFBQVEsUUFBUTtDQUFFO0NBQU8sY0FBYztBQUFLLENBQUM7QUEwQnZGLElBQUksWUFBWTtDQWxCZDtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBRWtCLENBQUMsQ0FBQyxRQUFRLFdBQVcsU0FBUztDQUNoRCxNQUFNLE9BQU8sV0FBVyxhQUFhLE1BQU07Q0FDM0MsTUFBTSxPQUFBLGFBQWEsWUFBWSxPQUFPLGlCQUFpQjtFQUNyRCxNQUFNLEVBQUUsU0FBUyxHQUFHLG1CQUFtQjtFQUN2QyxNQUFNLE9BQU8sVUFBVSxPQUFPO0VBQzlCLElBQUksT0FBTyxXQUFXLGFBQ3BCLE9BQU8sT0FBTyxJQUFJLFVBQVUsS0FBSztFQUVuQyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxNQUFNO0dBQUUsR0FBRztHQUFnQixLQUFLO0VBQWEsQ0FBQztDQUMzRSxDQUFDO0NBQ0QsS0FBSyxjQUFjLGFBQWE7Q0FDaEMsT0FBTztFQUFFLEdBQUc7R0FBWSxPQUFPO0NBQUs7QUFDdEMsR0FBRyxDQUFDLENBQUM7QUFDTCxTQUFTLDRCQUE0QixRQUFRLE9BQU87Q0FDbEQsSUFBSSxRQUFRLGlCQUFTLGdCQUFnQixPQUFPLGNBQWMsS0FBSyxDQUFDO0FBQ2xFO0FBQ0EsT0FBTyw2QkFBNkIsNkJBQTZCIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==