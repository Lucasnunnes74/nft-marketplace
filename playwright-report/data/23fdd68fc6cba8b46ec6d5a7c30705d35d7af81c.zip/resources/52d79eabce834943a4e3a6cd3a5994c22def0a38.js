/** Chaves de cache centralizadas: invalidação coerente após mutations e eventos. */
export const qk = {
	session: ["session"],
	nfts: {
		all: ["nfts"],
		list: (params) => [
			"nfts",
			"list",
			params
		],
		featured: ["nfts", "featured"],
		detail: (id) => [
			"nfts",
			"detail",
			id
		]
	},
	favorites: ["favorites"],
	cart: ["cart"],
	quote: (coupon, network) => ["quote", {
		coupon,
		network
	}],
	wallets: ["wallets"],
	order: (id) => ["orders", id]
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IjtBQUdBLE9BQU8sTUFBTSxLQUFLO0NBQ2hCLFNBQVMsQ0FBQyxTQUFTO0NBQ25CLE1BQU07RUFDSixLQUFLLENBQUMsTUFBTTtFQUNaLE9BQU8sV0FBbUM7R0FBQztHQUFRO0dBQVE7RUFBTTtFQUNqRSxVQUFVLENBQUMsUUFBUSxVQUFVO0VBQzdCLFNBQVMsT0FBZTtHQUFDO0dBQVE7R0FBVTtFQUFFO0NBQy9DO0NBQ0EsV0FBVyxDQUFDLFdBQVc7Q0FDdkIsTUFBTSxDQUFDLE1BQU07Q0FDYixRQUFRLFFBQWdCLFlBQW9CLENBQUMsU0FBUztFQUFFO0VBQVE7Q0FBUSxDQUFDO0NBQ3pFLFNBQVMsQ0FBQyxTQUFTO0NBQ25CLFFBQVEsT0FBZSxDQUFDLFVBQVUsRUFBRTtBQUN0QyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJrZXlzLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTmZ0TGlzdFBhcmFtcyB9IGZyb20gJy4vY29udHJhY3RzJ1xuXG4vKiogQ2hhdmVzIGRlIGNhY2hlIGNlbnRyYWxpemFkYXM6IGludmFsaWRhw6fDo28gY29lcmVudGUgYXDDs3MgbXV0YXRpb25zIGUgZXZlbnRvcy4gKi9cbmV4cG9ydCBjb25zdCBxayA9IHtcbiAgc2Vzc2lvbjogWydzZXNzaW9uJ10gYXMgY29uc3QsXG4gIG5mdHM6IHtcbiAgICBhbGw6IFsnbmZ0cyddIGFzIGNvbnN0LFxuICAgIGxpc3Q6IChwYXJhbXM6IFBhcnRpYWw8TmZ0TGlzdFBhcmFtcz4pID0+IFsnbmZ0cycsICdsaXN0JywgcGFyYW1zXSBhcyBjb25zdCxcbiAgICBmZWF0dXJlZDogWyduZnRzJywgJ2ZlYXR1cmVkJ10gYXMgY29uc3QsXG4gICAgZGV0YWlsOiAoaWQ6IHN0cmluZykgPT4gWyduZnRzJywgJ2RldGFpbCcsIGlkXSBhcyBjb25zdCxcbiAgfSxcbiAgZmF2b3JpdGVzOiBbJ2Zhdm9yaXRlcyddIGFzIGNvbnN0LFxuICBjYXJ0OiBbJ2NhcnQnXSBhcyBjb25zdCxcbiAgcXVvdGU6IChjb3Vwb246IHN0cmluZywgbmV0d29yazogc3RyaW5nKSA9PiBbJ3F1b3RlJywgeyBjb3Vwb24sIG5ldHdvcmsgfV0gYXMgY29uc3QsXG4gIHdhbGxldHM6IFsnd2FsbGV0cyddIGFzIGNvbnN0LFxuICBvcmRlcjogKGlkOiBzdHJpbmcpID0+IFsnb3JkZXJzJywgaWRdIGFzIGNvbnN0LFxufVxuIl19