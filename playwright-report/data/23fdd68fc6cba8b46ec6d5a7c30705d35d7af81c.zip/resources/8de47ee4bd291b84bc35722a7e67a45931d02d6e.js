import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/states.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import { AlertTriangle, PackageSearch, RefreshCw } from "/node_modules/.vite/deps/lucide-react.js?v=b07c072a";
import { ApiError } from "/src/api/errors.ts";
import { Button } from "/src/components/ui/button.tsx";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/common/states.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
export function EmptyState({ title, description, action, icon, className }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn("flex flex-col items-center gap-3 rounded-lg border border-dashed border-border-soft bg-card/40 px-6 py-14 text-center", className),
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "text-accent",
				children: icon ?? /* @__PURE__ */ _jsxDEV(PackageSearch, {
					"aria-hidden": true,
					className: "size-10"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 45
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-lg font-bold text-foreground",
				children: title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 7
			}, this),
			description ? /* @__PURE__ */ _jsxDEV("p", {
				className: "max-w-md text-sm leading-6 text-muted-foreground",
				children: description
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 22
			}, this) : null,
			action
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 5
	}, this);
}
_c = EmptyState;
export function errorMessage(error) {
	if (error instanceof ApiError) return error.message;
	return "Algo deu errado. Tente novamente.";
}
export function ErrorState({ error, onRetry, title = "Não foi possível carregar", retrying, compact, className }) {
	const offline = error instanceof ApiError && (error.code === "NETWORK" || error.code === "TIMEOUT");
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "alert",
		className: cn("flex flex-col items-center gap-3 rounded-lg border border-coral/40 bg-coral/5 text-center", compact ? "px-4 py-6" : "px-6 py-12", className),
		children: [
			/* @__PURE__ */ _jsxDEV(AlertTriangle, {
				"aria-hidden": true,
				className: cn("text-coral", compact ? "size-6" : "size-9")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h2", {
				className: cn("font-bold text-foreground", compact ? "text-sm" : "text-lg"),
				children: offline ? "Problema de conexão" : title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "max-w-md text-sm leading-6 text-muted-foreground",
				children: errorMessage(error)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 7
			}, this),
			onRetry ? /* @__PURE__ */ _jsxDEV(Button, {
				variant: "outline",
				size: compact ? "sm" : "default",
				onClick: onRetry,
				disabled: retrying,
				children: [/* @__PURE__ */ _jsxDEV(RefreshCw, {
					"aria-hidden": true,
					className: retrying ? "animate-spin" : ""
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 11
				}, this), " Tentar novamente"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 9
			}, this) : null
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 53,
		columnNumber: 5
	}, this);
}
_c2 = ErrorState;
export function NotFoundState({ title = "Página não encontrada", description }) {
	return /* @__PURE__ */ _jsxDEV(EmptyState, {
		title,
		description: description ?? "O endereço pode estar incorreto ou o conteúdo foi removido.",
		action: /* @__PURE__ */ _jsxDEV(Button, {
			asChild: true,
			children: /* @__PURE__ */ _jsxDEV(Link, {
				to: "/",
				children: "Voltar ao início"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 75,
		columnNumber: 5
	}, this);
}
_c3 = NotFoundState;
export function Spinner({ label }) {
	return /* @__PURE__ */ _jsxDEV("span", {
		role: "status",
		className: "inline-flex items-center gap-2 text-sm text-muted-foreground",
		children: [/* @__PURE__ */ _jsxDEV("span", {
			"aria-hidden": true,
			className: "size-4 animate-spin rounded-full border-2 border-accent border-t-transparent"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 7
		}, this), label]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 89,
		columnNumber: 5
	}, this);
}
_c4 = Spinner;
/** Trilha "Início / Mercado / …" das telas de mercado (15px, negrito). */
export function Breadcrumb({ items }) {
	return /* @__PURE__ */ _jsxDEV("nav", {
		"aria-label": "Trilha de navegação",
		className: "hidden md:block",
		children: /* @__PURE__ */ _jsxDEV("ol", {
			className: "flex flex-wrap items-center text-[15px] font-bold leading-4 text-foreground",
			children: items.map((item, i) => {
				const last = i === items.length - 1;
				return /* @__PURE__ */ _jsxDEV("li", {
					className: "flex items-center",
					children: [item.to && !last ? /* @__PURE__ */ _jsxDEV(Link, {
						to: item.to,
						hash: item.hash,
						className: "hover:text-accent",
						children: item.label
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 17
					}, this) : /* @__PURE__ */ _jsxDEV("span", {
						"aria-current": last ? "page" : undefined,
						children: item.label
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 17
					}, this), !last ? /* @__PURE__ */ _jsxDEV("span", {
						"aria-hidden": true,
						className: "whitespace-pre",
						children: " / "
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 17
					}, this) : null]
				}, item.label, true, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 13
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 100,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 99,
		columnNumber: 5
	}, this);
}
_c5 = Breadcrumb;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "EmptyState");
$RefreshReg$(_c2, "ErrorState");
$RefreshReg$(_c3, "NotFoundState");
$RefreshReg$(_c4, "Spinner");
$RefreshReg$(_c5, "Breadcrumb");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/states.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/common/states.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/common/states.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/common/states.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsZUFBZSxlQUFlLGlCQUFpQjtBQUV4RCxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxVQUFVOzs7QUFFbkIsT0FBTyxTQUFTLFdBQVcsRUFDekIsT0FDQSxhQUNBLFFBQ0EsTUFDQSxhQU9DO0NBQ0QsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVyxHQUFHLHlIQUF5SCxTQUFTO1lBQXJKO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZSxRQUFRLHdCQUFDLGVBQUQ7S0FBZTtLQUFZLFdBQVU7SUFBVzs7Ozs7R0FBTzs7Ozs7R0FDN0Ysd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBcUM7R0FBVTs7Ozs7R0FDNUQsY0FBYyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFvRDtHQUFlOzs7O2NBQUk7R0FDbEc7RUFDRTs7Ozs7O0FBRVQ7O0FBRUEsT0FBTyxTQUFTLGFBQWEsT0FBZ0I7Q0FDM0MsSUFBSSxpQkFBaUIsVUFBVSxPQUFPLE1BQU07Q0FDNUMsT0FBTztBQUNUO0FBRUEsT0FBTyxTQUFTLFdBQVcsRUFDekIsT0FDQSxTQUNBLFFBQVEsNkJBQ1IsVUFDQSxTQUNBLGFBUUM7Q0FDRCxNQUFNLFVBQVUsaUJBQWlCLGFBQWEsTUFBTSxTQUFTLGFBQWEsTUFBTSxTQUFTO0NBQ3pGLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLE1BQUs7RUFDTCxXQUFXLEdBQ1QsNkZBQ0EsVUFBVSxjQUFjLGNBQ3hCLFNBQ0Y7WUFORjtHQVFFLHdCQUFDLGVBQUQ7SUFBZTtJQUFZLFdBQVcsR0FBRyxjQUFjLFVBQVUsV0FBVyxRQUFRO0dBQUk7Ozs7O0dBQ3hGLHdCQUFDLE1BQUQ7SUFBSSxXQUFXLEdBQUcsNkJBQTZCLFVBQVUsWUFBWSxTQUFTO2NBQUksVUFBVSx3QkFBd0I7R0FBVTs7Ozs7R0FDOUgsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBb0QsYUFBYSxLQUFLO0dBQUs7Ozs7O0dBQ3ZGLFVBQ0Msd0JBQUMsUUFBRDtJQUFRLFNBQVE7SUFBVSxNQUFNLFVBQVUsT0FBTztJQUFXLFNBQVM7SUFBUyxVQUFVO2NBQXhGLENBQ0Usd0JBQUMsV0FBRDtLQUFXO0tBQVksV0FBVyxXQUFXLGlCQUFpQjtJQUFLOzs7O2NBQUMsbUJBQzlEOzs7OztjQUNOO0VBQ0Q7Ozs7OztBQUVUOztBQUVBLE9BQU8sU0FBUyxjQUFjLEVBQUUsUUFBUSx5QkFBeUIsZUFBeUQ7Q0FDeEgsT0FDRSx3QkFBQyxZQUFEO0VBQ1M7RUFDUCxhQUFhLGVBQWU7RUFDNUIsUUFDRSx3QkFBQyxRQUFEO0dBQVE7YUFDTix3QkFBQyxNQUFEO0lBQU0sSUFBRztjQUFJO0dBQXNCOzs7OztFQUM3Qjs7Ozs7Q0FFWDs7Ozs7QUFFTDs7QUFFQSxPQUFPLFNBQVMsUUFBUSxFQUFFLFNBQTRCO0NBQ3BELE9BQ0Usd0JBQUMsUUFBRDtFQUFNLE1BQUs7RUFBUyxXQUFVO1lBQTlCLENBQ0Usd0JBQUMsUUFBRDtHQUFNO0dBQVksV0FBVTtFQUFnRjs7OztZQUMzRyxLQUNHOzs7Ozs7QUFFVjs7O0FBR0EsT0FBTyxTQUFTLFdBQVcsRUFBRSxTQUE0RTtDQUN2RyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxjQUFXO0VBQXNCLFdBQVU7WUFDOUMsd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFDWCxNQUFNLEtBQUssTUFBTSxNQUFNO0lBQ3RCLE1BQU0sT0FBTyxNQUFNLE1BQU0sU0FBUztJQUNsQyxPQUNFLHdCQUFDLE1BQUQ7S0FBcUIsV0FBVTtlQUEvQixDQUNHLEtBQUssTUFBTSxDQUFDLE9BQ1gsd0JBQUMsTUFBRDtNQUFNLElBQUksS0FBSztNQUFJLE1BQU0sS0FBSztNQUFNLFdBQVU7Z0JBQzNDLEtBQUs7S0FDRjs7OztnQkFFTix3QkFBQyxRQUFEO01BQU0sZ0JBQWMsT0FBTyxTQUFTO2dCQUFZLEtBQUs7S0FBWTs7OztlQUVsRSxDQUFDLE9BQ0Esd0JBQUMsUUFBRDtNQUFNO01BQVksV0FBVTtnQkFDekI7S0FDRzs7OztnQkFDSixJQUNGO09BYkssS0FBSzs7OztXQWFWO0dBRVIsQ0FBQztFQUNDOzs7OztDQUNEOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInN0YXRlcy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBBbGVydFRyaWFuZ2xlLCBQYWNrYWdlU2VhcmNoLCBSZWZyZXNoQ3cgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgdHlwZSAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICdAL2FwaS9lcnJvcnMnXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcblxuZXhwb3J0IGZ1bmN0aW9uIEVtcHR5U3RhdGUoe1xuICB0aXRsZSxcbiAgZGVzY3JpcHRpb24sXG4gIGFjdGlvbixcbiAgaWNvbixcbiAgY2xhc3NOYW1lLFxufToge1xuICB0aXRsZTogc3RyaW5nXG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nXG4gIGFjdGlvbj86IFJlYWN0LlJlYWN0Tm9kZVxuICBpY29uPzogUmVhY3QuUmVhY3ROb2RlXG4gIGNsYXNzTmFtZT86IHN0cmluZ1xufSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtjbignZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWRhc2hlZCBib3JkZXItYm9yZGVyLXNvZnQgYmctY2FyZC80MCBweC02IHB5LTE0IHRleHQtY2VudGVyJywgY2xhc3NOYW1lKX0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtYWNjZW50XCI+e2ljb24gPz8gPFBhY2thZ2VTZWFyY2ggYXJpYS1oaWRkZW4gY2xhc3NOYW1lPVwic2l6ZS0xMFwiIC8+fTwvZGl2PlxuICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZFwiPnt0aXRsZX08L2gyPlxuICAgICAge2Rlc2NyaXB0aW9uID8gPHAgY2xhc3NOYW1lPVwibWF4LXctbWQgdGV4dC1zbSBsZWFkaW5nLTYgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2Rlc2NyaXB0aW9ufTwvcD4gOiBudWxsfVxuICAgICAge2FjdGlvbn1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZXJyb3JNZXNzYWdlKGVycm9yOiB1bmtub3duKSB7XG4gIGlmIChlcnJvciBpbnN0YW5jZW9mIEFwaUVycm9yKSByZXR1cm4gZXJyb3IubWVzc2FnZVxuICByZXR1cm4gJ0FsZ28gZGV1IGVycmFkby4gVGVudGUgbm92YW1lbnRlLidcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEVycm9yU3RhdGUoe1xuICBlcnJvcixcbiAgb25SZXRyeSxcbiAgdGl0bGUgPSAnTsOjbyBmb2kgcG9zc8OtdmVsIGNhcnJlZ2FyJyxcbiAgcmV0cnlpbmcsXG4gIGNvbXBhY3QsXG4gIGNsYXNzTmFtZSxcbn06IHtcbiAgZXJyb3I6IHVua25vd25cbiAgb25SZXRyeT86ICgpID0+IHZvaWRcbiAgdGl0bGU/OiBzdHJpbmdcbiAgcmV0cnlpbmc/OiBib29sZWFuXG4gIGNvbXBhY3Q/OiBib29sZWFuXG4gIGNsYXNzTmFtZT86IHN0cmluZ1xufSkge1xuICBjb25zdCBvZmZsaW5lID0gZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvciAmJiAoZXJyb3IuY29kZSA9PT0gJ05FVFdPUksnIHx8IGVycm9yLmNvZGUgPT09ICdUSU1FT1VUJylcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICByb2xlPVwiYWxlcnRcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgJ2ZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0zIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1jb3JhbC80MCBiZy1jb3JhbC81IHRleHQtY2VudGVyJyxcbiAgICAgICAgY29tcGFjdCA/ICdweC00IHB5LTYnIDogJ3B4LTYgcHktMTInLFxuICAgICAgICBjbGFzc05hbWUsXG4gICAgICApfVxuICAgID5cbiAgICAgIDxBbGVydFRyaWFuZ2xlIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT17Y24oJ3RleHQtY29yYWwnLCBjb21wYWN0ID8gJ3NpemUtNicgOiAnc2l6ZS05Jyl9IC8+XG4gICAgICA8aDIgY2xhc3NOYW1lPXtjbignZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZCcsIGNvbXBhY3QgPyAndGV4dC1zbScgOiAndGV4dC1sZycpfT57b2ZmbGluZSA/ICdQcm9ibGVtYSBkZSBjb25leMOjbycgOiB0aXRsZX08L2gyPlxuICAgICAgPHAgY2xhc3NOYW1lPVwibWF4LXctbWQgdGV4dC1zbSBsZWFkaW5nLTYgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2Vycm9yTWVzc2FnZShlcnJvcil9PC9wPlxuICAgICAge29uUmV0cnkgPyAoXG4gICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBzaXplPXtjb21wYWN0ID8gJ3NtJyA6ICdkZWZhdWx0J30gb25DbGljaz17b25SZXRyeX0gZGlzYWJsZWQ9e3JldHJ5aW5nfT5cbiAgICAgICAgICA8UmVmcmVzaEN3IGFyaWEtaGlkZGVuIGNsYXNzTmFtZT17cmV0cnlpbmcgPyAnYW5pbWF0ZS1zcGluJyA6ICcnfSAvPiBUZW50YXIgbm92YW1lbnRlXG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIE5vdEZvdW5kU3RhdGUoeyB0aXRsZSA9ICdQw6FnaW5hIG7Do28gZW5jb250cmFkYScsIGRlc2NyaXB0aW9uIH06IHsgdGl0bGU/OiBzdHJpbmc7IGRlc2NyaXB0aW9uPzogc3RyaW5nIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8RW1wdHlTdGF0ZVxuICAgICAgdGl0bGU9e3RpdGxlfVxuICAgICAgZGVzY3JpcHRpb249e2Rlc2NyaXB0aW9uID8/ICdPIGVuZGVyZcOnbyBwb2RlIGVzdGFyIGluY29ycmV0byBvdSBvIGNvbnRlw7pkbyBmb2kgcmVtb3ZpZG8uJ31cbiAgICAgIGFjdGlvbj17XG4gICAgICAgIDxCdXR0b24gYXNDaGlsZD5cbiAgICAgICAgICA8TGluayB0bz1cIi9cIj5Wb2x0YXIgYW8gaW7DrWNpbzwvTGluaz5cbiAgICAgICAgPC9CdXR0b24+XG4gICAgICB9XG4gICAgLz5cbiAgKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gU3Bpbm5lcih7IGxhYmVsIH06IHsgbGFiZWw6IHN0cmluZyB9KSB7XG4gIHJldHVybiAoXG4gICAgPHNwYW4gcm9sZT1cInN0YXR1c1wiIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgPHNwYW4gYXJpYS1oaWRkZW4gY2xhc3NOYW1lPVwic2l6ZS00IGFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgYm9yZGVyLWFjY2VudCBib3JkZXItdC10cmFuc3BhcmVudFwiIC8+XG4gICAgICB7bGFiZWx9XG4gICAgPC9zcGFuPlxuICApXG59XG5cbi8qKiBUcmlsaGEgXCJJbsOtY2lvIC8gTWVyY2FkbyAvIOKAplwiIGRhcyB0ZWxhcyBkZSBtZXJjYWRvICgxNXB4LCBuZWdyaXRvKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBCcmVhZGNydW1iKHsgaXRlbXMgfTogeyBpdGVtczogeyBsYWJlbDogc3RyaW5nOyB0bz86ICcvJyB8ICcvY2FydCc7IGhhc2g/OiBzdHJpbmcgfVtdIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8bmF2IGFyaWEtbGFiZWw9XCJUcmlsaGEgZGUgbmF2ZWdhw6fDo29cIiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6YmxvY2tcIj5cbiAgICAgIDxvbCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgdGV4dC1bMTVweF0gZm9udC1ib2xkIGxlYWRpbmctNCB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAge2l0ZW1zLm1hcCgoaXRlbSwgaSkgPT4ge1xuICAgICAgICAgIGNvbnN0IGxhc3QgPSBpID09PSBpdGVtcy5sZW5ndGggLSAxXG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxsaSBrZXk9e2l0ZW0ubGFiZWx9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgIHtpdGVtLnRvICYmICFsYXN0ID8gKFxuICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtpdGVtLnRvfSBoYXNoPXtpdGVtLmhhc2h9IGNsYXNzTmFtZT1cImhvdmVyOnRleHQtYWNjZW50XCI+XG4gICAgICAgICAgICAgICAgICB7aXRlbS5sYWJlbH1cbiAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gYXJpYS1jdXJyZW50PXtsYXN0ID8gJ3BhZ2UnIDogdW5kZWZpbmVkfT57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIHshbGFzdCA/IChcbiAgICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbiBjbGFzc05hbWU9XCJ3aGl0ZXNwYWNlLXByZVwiPlxuICAgICAgICAgICAgICAgICAgeycgLyAnfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgIClcbiAgICAgICAgfSl9XG4gICAgICA8L29sPlxuICAgIDwvbmF2PlxuICApXG59XG4iXX0=