import { keepPreviousData, useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=5d4ac5a9";
import * as api from "/src/api/resources.ts";
import "/src/api/contracts.ts";
import { ApiError, toApiError } from "/src/api/errors.ts";
import { qk } from "/src/api/keys.ts";
import { clearGuestId, sessionStore } from "/src/auth/session-store.ts";
import { useSessionState } from "/src/auth/use-session.ts";
import { sleep, uid } from "/src/lib/utils.ts";
import { toast } from "/src/stores/toasts.ts";
/* ───────────── sessão ───────────── */
export function useCurrentUser() {
	const { isAuthenticated } = useSessionState();
	return useQuery({
		queryKey: qk.session,
		queryFn: ({ signal }) => api.getSession({ signal }),
		enabled: isAuthenticated,
		staleTime: 6e4
	});
}
function startSession(res) {
	clearGuestId();
	sessionStore.start({
		token: res.token,
		expiresAt: res.expiresAt,
		userId: res.user.id
	});
}
export function useLogin() {
	return useMutation({
		mutationFn: (body) => api.login(body),
		onSuccess: startSession
	});
}
export function useSignup() {
	return useMutation({
		mutationFn: (body) => api.signup(body),
		onSuccess: startSession
	});
}
export function useLogout() {
	return useMutation({
		mutationFn: async () => {
			try {
				await api.logout();
			} catch {}
		},
		onSettled: () => sessionStore.end("logout")
	});
}
export function useUpdateProfile() {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: (body) => api.updateProfile(body),
		onSuccess: (user) => {
			qc.setQueryData(qk.session, (old) => old ? {
				...old,
				user
			} : undefined);
			void qc.invalidateQueries({ queryKey: qk.session });
		}
	});
}
export function useChangePassword() {
	return useMutation({ mutationFn: (body) => api.changePassword(body) });
}
/* ───────────── catálogo ───────────── */
export function useNftList(params) {
	const { userId } = useSessionState();
	return useQuery({
		// userId na chave: dados de um usuário (isFavorite) nunca são reaproveitados por outro.
		queryKey: [...qk.nfts.list(params), userId],
		// `signal` cancela a requisição anterior ao mudar filtros (sem respostas obsoletas).
		queryFn: ({ signal }) => api.listNfts(params, { signal }),
		placeholderData: keepPreviousData
	});
}
export function useFeatured() {
	const { userId } = useSessionState();
	return useQuery({
		queryKey: [...qk.nfts.featured, userId],
		queryFn: ({ signal }) => api.listFeatured({ signal })
	});
}
export function useNft(id) {
	const { userId } = useSessionState();
	return useQuery({
		queryKey: [...qk.nfts.detail(id), userId],
		queryFn: ({ signal }) => api.getNft(id, { signal }),
		retry: (count, error) => !(error instanceof ApiError && error.code === "NOT_FOUND") && count < 2
	});
}
/* ───────────── favoritos (atualização otimista com rollback) ───────────── */
function patchFavoriteEverywhere(qc, nftId, isFavorite) {
	qc.setQueriesData({ queryKey: qk.nfts.all }, (old) => {
		if (!old) return old;
		if ("items" in old) {
			return {
				...old,
				items: old.items.map((i) => i.id === nftId ? {
					...i,
					isFavorite
				} : i)
			};
		}
		return old.id === nftId ? {
			...old,
			isFavorite
		} : old;
	});
}
export function useFavorites() {
	const { isAuthenticated, userId } = useSessionState();
	return useQuery({
		queryKey: [...qk.favorites, userId],
		queryFn: ({ signal }) => api.listFavorites({ signal }),
		enabled: isAuthenticated
	});
}
export function useToggleFavorite() {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: async ({ nftId, next }) => next ? api.addFavorite(nftId) : api.removeFavorite(nftId),
		onMutate: async ({ nftId, next }) => {
			await qc.cancelQueries({ queryKey: qk.nfts.all });
			await qc.cancelQueries({ queryKey: qk.favorites });
			const snapshotNfts = qc.getQueriesData({ queryKey: qk.nfts.all });
			const snapshotFavs = qc.getQueriesData({ queryKey: qk.favorites });
			patchFavoriteEverywhere(qc, nftId, next);
			if (!next) {
				qc.setQueriesData({ queryKey: qk.favorites }, (old) => old?.filter((f) => f.id !== nftId));
			}
			return {
				snapshotNfts,
				snapshotFavs
			};
		},
		onError: (error, _vars, ctx) => {
			// Rollback do estado otimista.
			for (const [key, data] of ctx?.snapshotNfts ?? []) qc.setQueryData(key, data);
			for (const [key, data] of ctx?.snapshotFavs ?? []) qc.setQueryData(key, data);
			toast({
				title: "Não foi possível atualizar o favorito",
				description: toApiError(error).message,
				variant: "destructive"
			});
		},
		onSettled: () => {
			void qc.invalidateQueries({ queryKey: qk.favorites });
		}
	});
}
/* ───────────── carrinho (otimista na quantidade/remoção) ───────────── */
export function useCart() {
	const { userId } = useSessionState();
	return useQuery({
		queryKey: [...qk.cart, userId ?? "guest"],
		queryFn: ({ signal }) => api.getCart({ signal })
	});
}
/** Chave do carrinho do usuário atual (visitante ou autenticado). */
function useCartKey() {
	const { userId } = useSessionState();
	return [...qk.cart, userId ?? "guest"];
}
export function useAddToCart() {
	const qc = useQueryClient();
	const key = useCartKey();
	return useMutation({
		mutationFn: (vars) => api.addCartItem(vars),
		onSuccess: (cart) => {
			qc.setQueryData(key, cart);
			void qc.invalidateQueries({ queryKey: ["quote"] });
		}
	});
}
export function useSetCartQuantity() {
	const qc = useQueryClient();
	const key = useCartKey();
	return useMutation({
		mutationFn: (vars) => api.setCartItemQuantity(vars.nftId, vars.quantity),
		onMutate: async ({ nftId, quantity }) => {
			await qc.cancelQueries({ queryKey: key });
			const previous = qc.getQueryData(key);
			if (previous) {
				qc.setQueryData(key, {
					...previous,
					items: previous.items.map((i) => i.nftId === nftId ? {
						...i,
						quantity
					} : i)
				});
			}
			return { previous };
		},
		onError: (error, _vars, ctx) => {
			if (ctx?.previous) qc.setQueryData(key, ctx.previous);
			toast({
				title: "Não foi possível alterar a quantidade",
				description: toApiError(error).message,
				variant: "warning"
			});
		},
		onSettled: () => {
			void qc.invalidateQueries({ queryKey: key });
			void qc.invalidateQueries({ queryKey: ["quote"] });
		}
	});
}
export function useRemoveCartItem() {
	const qc = useQueryClient();
	const key = useCartKey();
	return useMutation({
		mutationFn: (nftId) => api.removeCartItem(nftId),
		onMutate: async (nftId) => {
			await qc.cancelQueries({ queryKey: key });
			const previous = qc.getQueryData(key);
			if (previous) qc.setQueryData(key, {
				...previous,
				items: previous.items.filter((i) => i.nftId !== nftId)
			});
			return { previous };
		},
		onError: (error, _vars, ctx) => {
			if (ctx?.previous) qc.setQueryData(key, ctx.previous);
			toast({
				title: "Não foi possível remover o item",
				description: toApiError(error).message,
				variant: "destructive"
			});
		},
		onSettled: () => {
			void qc.invalidateQueries({ queryKey: key });
			void qc.invalidateQueries({ queryKey: ["quote"] });
		}
	});
}
export function useQuote(args) {
	const { userId } = useSessionState();
	return useQuery({
		queryKey: [...qk.quote(args.coupon, args.network), userId ?? "guest"],
		queryFn: ({ signal }) => api.getQuote({
			couponCode: args.coupon || undefined,
			network: args.network
		}, { signal }),
		enabled: args.enabled,
		placeholderData: keepPreviousData,
		staleTime: 1e4
	});
}
/* ───────────── carteiras ───────────── */
export function useWallets() {
	const { isAuthenticated, userId } = useSessionState();
	return useQuery({
		queryKey: [...qk.wallets, userId],
		queryFn: ({ signal }) => api.listWallets({ signal }),
		enabled: isAuthenticated
	});
}
export function useCreateWallet() {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: (body) => api.createWallet(body),
		onSuccess: () => qc.invalidateQueries({ queryKey: qk.wallets })
	});
}
export function useUpdateWallet() {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: ({ id, body }) => api.updateWallet(id, body),
		onSuccess: () => qc.invalidateQueries({ queryKey: qk.wallets })
	});
}
export function useConnectWallet() {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: ({ id, network }) => api.connectWallet(id, network),
		onSuccess: () => qc.invalidateQueries({ queryKey: qk.wallets })
	});
}
export function useDisconnectWallet() {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: (id) => api.disconnectWallet(id),
		onSuccess: () => qc.invalidateQueries({ queryKey: qk.wallets })
	});
}
/* ───────────── pedidos ───────────── */
export function useOrder(id) {
	return useQuery({
		queryKey: qk.order(id),
		queryFn: ({ signal }) => api.getOrder(id, { signal }),
		// Rede de segurança além do Socket.IO: enquanto pendente, reconcilia periodicamente.
		refetchInterval: (query) => query.state.data?.status === "pending" ? 3e3 : false,
		retry: (count, error) => !(error instanceof ApiError && error.code === "NOT_FOUND") && count < 2
	});
}
const IDEM_PREFIX = "nft.idem.";
function fingerprintOf(body) {
	return JSON.stringify([
		body.walletId,
		body.network,
		(body.couponCode ?? "").toUpperCase(),
		body.expectedTotal
	]);
}
/**
* Cria o pedido com Idempotency-Key estável por conteúdo: reenvios do mesmo
* pedido (duplo clique, timeout, refresh) devolvem o mesmo pedido. Se o
* conteúdo mudar (ex.: usuário revisou um novo total), uma nova chave é usada.
*/
export function usePlaceOrder() {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: async (body) => {
			const fp = fingerprintOf(body);
			let key = null;
			try {
				key = sessionStorage.getItem(IDEM_PREFIX + fp);
			} catch {}
			if (!key) {
				key = uid("idem");
				try {
					sessionStorage.setItem(IDEM_PREFIX + fp, key);
				} catch {}
			}
			let lastError;
			// Timeout/queda de rede: o pedido pode ter sido criado. Repete COM A MESMA chave.
			for (let attempt = 0; attempt < 3; attempt++) {
				try {
					return await api.createOrder(body, key);
				} catch (error) {
					lastError = error;
					const e = toApiError(error);
					if (e.code !== "TIMEOUT" && e.code !== "NETWORK") throw e;
					await sleep(1e3 * (attempt + 1));
				}
			}
			throw toApiError(lastError);
		},
		onSuccess: (order) => {
			qc.setQueryData(qk.order(order.id), order);
			void qc.invalidateQueries({ queryKey: qk.cart });
			void qc.invalidateQueries({ queryKey: ["quote"] });
			void qc.invalidateQueries({ queryKey: qk.nfts.all });
			try {
				for (let i = sessionStorage.length - 1; i >= 0; i--) {
					const k = sessionStorage.key(i);
					if (k?.startsWith(IDEM_PREFIX)) sessionStorage.removeItem(k);
				}
			} catch {}
		}
	});
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDRSxrQkFDQSxhQUNBLFVBQ0Esc0JBRUs7QUFDUCxZQUFZLFNBQVM7QUFDckIsT0FjTztBQUNQLFNBQVMsVUFBVSxrQkFBa0I7QUFDckMsU0FBUyxVQUFVO0FBQ25CLFNBQVMsY0FBYyxvQkFBb0I7QUFDM0MsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxPQUFPLFdBQVc7QUFDM0IsU0FBUyxhQUFhOztBQUd0QixPQUFPLFNBQVMsaUJBQWlCO0NBQy9CLE1BQU0sRUFBRSxvQkFBb0IsZ0JBQWdCO0NBQzVDLE9BQU8sU0FBUztFQUNkLFVBQVUsR0FBRztFQUNiLFVBQVUsRUFBRSxhQUFhLElBQUksV0FBVyxFQUFFLE9BQU8sQ0FBQztFQUNsRCxTQUFTO0VBQ1QsV0FBVztDQUNiLENBQUM7QUFDSDtBQUVBLFNBQVMsYUFBYSxLQUFpRTtDQUNyRixhQUFhO0NBQ2IsYUFBYSxNQUFNO0VBQUUsT0FBTyxJQUFJO0VBQU8sV0FBVyxJQUFJO0VBQVcsUUFBUSxJQUFJLEtBQUs7Q0FBRyxDQUFDO0FBQ3hGO0FBRUEsT0FBTyxTQUFTLFdBQVc7Q0FDekIsT0FBTyxZQUFZO0VBQUUsYUFBYSxTQUFvQixJQUFJLE1BQU0sSUFBSTtFQUFHLFdBQVc7Q0FBYSxDQUFDO0FBQ2xHO0FBRUEsT0FBTyxTQUFTLFlBQVk7Q0FDMUIsT0FBTyxZQUFZO0VBQUUsYUFBYSxTQUFxQixJQUFJLE9BQU8sSUFBSTtFQUFHLFdBQVc7Q0FBYSxDQUFDO0FBQ3BHO0FBRUEsT0FBTyxTQUFTLFlBQVk7Q0FDMUIsT0FBTyxZQUFZO0VBQ2pCLFlBQVksWUFBWTtHQUN0QixJQUFJO0lBQ0YsTUFBTSxJQUFJLE9BQU87R0FDbkIsUUFBUSxDQUVSO0VBQ0Y7RUFDQSxpQkFBaUIsYUFBYSxJQUFJLFFBQVE7Q0FDNUMsQ0FBQztBQUNIO0FBRUEsT0FBTyxTQUFTLG1CQUFtQjtDQUNqQyxNQUFNLEtBQUssZUFBZTtDQUMxQixPQUFPLFlBQVk7RUFDakIsYUFBYSxTQUFzQixJQUFJLGNBQWMsSUFBSTtFQUN6RCxZQUFZLFNBQVM7R0FDbkIsR0FBRyxhQUFhLEdBQUcsVUFBVSxRQUMzQixNQUFNO0lBQUUsR0FBRztJQUFLO0dBQUssSUFBSSxTQUMzQjtHQUNBLEtBQUssR0FBRyxrQkFBa0IsRUFBRSxVQUFVLEdBQUcsUUFBUSxDQUFDO0VBQ3BEO0NBQ0YsQ0FBQztBQUNIO0FBRUEsT0FBTyxTQUFTLG9CQUFvQjtDQUNsQyxPQUFPLFlBQVksRUFBRSxhQUFhLFNBQXVCLElBQUksZUFBZSxJQUFJLEVBQUUsQ0FBQztBQUNyRjs7QUFHQSxPQUFPLFNBQVMsV0FBVyxRQUFnQztDQUN6RCxNQUFNLEVBQUUsV0FBVyxnQkFBZ0I7Q0FDbkMsT0FBTyxTQUFTOztFQUVkLFVBQVUsQ0FBQyxHQUFHLEdBQUcsS0FBSyxLQUFLLE1BQU0sR0FBRyxNQUFNOztFQUUxQyxVQUFVLEVBQUUsYUFBYSxJQUFJLFNBQVMsUUFBUSxFQUFFLE9BQU8sQ0FBQztFQUN4RCxpQkFBaUI7Q0FDbkIsQ0FBQztBQUNIO0FBRUEsT0FBTyxTQUFTLGNBQWM7Q0FDNUIsTUFBTSxFQUFFLFdBQVcsZ0JBQWdCO0NBQ25DLE9BQU8sU0FBUztFQUNkLFVBQVUsQ0FBQyxHQUFHLEdBQUcsS0FBSyxVQUFVLE1BQU07RUFDdEMsVUFBVSxFQUFFLGFBQWEsSUFBSSxhQUFhLEVBQUUsT0FBTyxDQUFDO0NBQ3RELENBQUM7QUFDSDtBQUVBLE9BQU8sU0FBUyxPQUFPLElBQVk7Q0FDakMsTUFBTSxFQUFFLFdBQVcsZ0JBQWdCO0NBQ25DLE9BQU8sU0FBUztFQUNkLFVBQVUsQ0FBQyxHQUFHLEdBQUcsS0FBSyxPQUFPLEVBQUUsR0FBRyxNQUFNO0VBQ3hDLFVBQVUsRUFBRSxhQUFhLElBQUksT0FBTyxJQUFJLEVBQUUsT0FBTyxDQUFDO0VBQ2xELFFBQVEsT0FBTyxVQUFVLEVBQUUsaUJBQWlCLFlBQVksTUFBTSxTQUFTLGdCQUFnQixRQUFRO0NBQ2pHLENBQUM7QUFDSDs7QUFHQSxTQUFTLHdCQUF3QixJQUFpQixPQUFlLFlBQXFCO0NBQ3BGLEdBQUcsZUFBb0MsRUFBRSxVQUFVLEdBQUcsS0FBSyxJQUFJLElBQUksUUFBUTtFQUN6RSxJQUFJLENBQUMsS0FBSyxPQUFPO0VBQ2pCLElBQUksV0FBVyxLQUFLO0dBQ2xCLE9BQU87SUFBRSxHQUFHO0lBQUssT0FBTyxJQUFJLE1BQU0sS0FBSyxNQUFPLEVBQUUsT0FBTyxRQUFRO0tBQUUsR0FBRztLQUFHO0lBQVcsSUFBSSxDQUFFO0dBQUU7RUFDNUY7RUFDQSxPQUFPLElBQUksT0FBTyxRQUFRO0dBQUUsR0FBRztHQUFLO0VBQVcsSUFBSTtDQUNyRCxDQUFDO0FBQ0g7QUFFQSxPQUFPLFNBQVMsZUFBZTtDQUM3QixNQUFNLEVBQUUsaUJBQWlCLFdBQVcsZ0JBQWdCO0NBQ3BELE9BQU8sU0FBUztFQUNkLFVBQVUsQ0FBQyxHQUFHLEdBQUcsV0FBVyxNQUFNO0VBQ2xDLFVBQVUsRUFBRSxhQUFhLElBQUksY0FBYyxFQUFFLE9BQU8sQ0FBQztFQUNyRCxTQUFTO0NBQ1gsQ0FBQztBQUNIO0FBRUEsT0FBTyxTQUFTLG9CQUFvQjtDQUNsQyxNQUFNLEtBQUssZUFBZTtDQUMxQixPQUFPLFlBQVk7RUFDakIsWUFBWSxPQUFPLEVBQUUsT0FBTyxXQUMxQixPQUFPLElBQUksWUFBWSxLQUFLLElBQUksSUFBSSxlQUFlLEtBQUs7RUFDMUQsVUFBVSxPQUFPLEVBQUUsT0FBTyxXQUFXO0dBQ25DLE1BQU0sR0FBRyxjQUFjLEVBQUUsVUFBVSxHQUFHLEtBQUssSUFBSSxDQUFDO0dBQ2hELE1BQU0sR0FBRyxjQUFjLEVBQUUsVUFBVSxHQUFHLFVBQVUsQ0FBQztHQUNqRCxNQUFNLGVBQWUsR0FBRyxlQUFvQyxFQUFFLFVBQVUsR0FBRyxLQUFLLElBQUksQ0FBQztHQUNyRixNQUFNLGVBQWUsR0FBRyxlQUE2QixFQUFFLFVBQVUsR0FBRyxVQUFVLENBQUM7R0FDL0Usd0JBQXdCLElBQUksT0FBTyxJQUFJO0dBQ3ZDLElBQUksQ0FBQyxNQUFNO0lBQ1QsR0FBRyxlQUE2QixFQUFFLFVBQVUsR0FBRyxVQUFVLElBQUksUUFBUSxLQUFLLFFBQVEsTUFBTSxFQUFFLE9BQU8sS0FBSyxDQUFDO0dBQ3pHO0dBQ0EsT0FBTztJQUFFO0lBQWM7R0FBYTtFQUN0QztFQUNBLFVBQVUsT0FBTyxPQUFPLFFBQVE7O0dBRTlCLEtBQUssTUFBTSxDQUFDLEtBQUssU0FBUyxLQUFLLGdCQUFnQixDQUFDLEdBQUcsR0FBRyxhQUFhLEtBQUssSUFBSTtHQUM1RSxLQUFLLE1BQU0sQ0FBQyxLQUFLLFNBQVMsS0FBSyxnQkFBZ0IsQ0FBQyxHQUFHLEdBQUcsYUFBYSxLQUFLLElBQUk7R0FDNUUsTUFBTTtJQUNKLE9BQU87SUFDUCxhQUFhLFdBQVcsS0FBSyxDQUFDLENBQUM7SUFDL0IsU0FBUztHQUNYLENBQUM7RUFDSDtFQUNBLGlCQUFpQjtHQUNmLEtBQUssR0FBRyxrQkFBa0IsRUFBRSxVQUFVLEdBQUcsVUFBVSxDQUFDO0VBQ3REO0NBQ0YsQ0FBQztBQUNIOztBQUdBLE9BQU8sU0FBUyxVQUFVO0NBQ3hCLE1BQU0sRUFBRSxXQUFXLGdCQUFnQjtDQUNuQyxPQUFPLFNBQVM7RUFDZCxVQUFVLENBQUMsR0FBRyxHQUFHLE1BQU0sVUFBVSxPQUFPO0VBQ3hDLFVBQVUsRUFBRSxhQUFhLElBQUksUUFBUSxFQUFFLE9BQU8sQ0FBQztDQUNqRCxDQUFDO0FBQ0g7O0FBR0EsU0FBUyxhQUFhO0NBQ3BCLE1BQU0sRUFBRSxXQUFXLGdCQUFnQjtDQUNuQyxPQUFPLENBQUMsR0FBRyxHQUFHLE1BQU0sVUFBVSxPQUFPO0FBQ3ZDO0FBRUEsT0FBTyxTQUFTLGVBQWU7Q0FDN0IsTUFBTSxLQUFLLGVBQWU7Q0FDMUIsTUFBTSxNQUFNLFdBQVc7Q0FDdkIsT0FBTyxZQUFZO0VBQ2pCLGFBQWEsU0FBOEMsSUFBSSxZQUFZLElBQUk7RUFDL0UsWUFBWSxTQUFTO0dBQ25CLEdBQUcsYUFBYSxLQUFLLElBQUk7R0FDekIsS0FBSyxHQUFHLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztFQUNuRDtDQUNGLENBQUM7QUFDSDtBQUVBLE9BQU8sU0FBUyxxQkFBcUI7Q0FDbkMsTUFBTSxLQUFLLGVBQWU7Q0FDMUIsTUFBTSxNQUFNLFdBQVc7Q0FDdkIsT0FBTyxZQUFZO0VBQ2pCLGFBQWEsU0FBOEMsSUFBSSxvQkFBb0IsS0FBSyxPQUFPLEtBQUssUUFBUTtFQUM1RyxVQUFVLE9BQU8sRUFBRSxPQUFPLGVBQWU7R0FDdkMsTUFBTSxHQUFHLGNBQWMsRUFBRSxVQUFVLElBQUksQ0FBQztHQUN4QyxNQUFNLFdBQVcsR0FBRyxhQUFtQixHQUFHO0dBQzFDLElBQUksVUFBVTtJQUNaLEdBQUcsYUFBbUIsS0FBSztLQUN6QixHQUFHO0tBQ0gsT0FBTyxTQUFTLE1BQU0sS0FBSyxNQUFPLEVBQUUsVUFBVSxRQUFRO01BQUUsR0FBRztNQUFHO0tBQVMsSUFBSSxDQUFFO0lBQy9FLENBQUM7R0FDSDtHQUNBLE9BQU8sRUFBRSxTQUFTO0VBQ3BCO0VBQ0EsVUFBVSxPQUFPLE9BQU8sUUFBUTtHQUM5QixJQUFJLEtBQUssVUFBVSxHQUFHLGFBQWEsS0FBSyxJQUFJLFFBQVE7R0FDcEQsTUFBTTtJQUFFLE9BQU87SUFBeUMsYUFBYSxXQUFXLEtBQUssQ0FBQyxDQUFDO0lBQVMsU0FBUztHQUFVLENBQUM7RUFDdEg7RUFDQSxpQkFBaUI7R0FDZixLQUFLLEdBQUcsa0JBQWtCLEVBQUUsVUFBVSxJQUFJLENBQUM7R0FDM0MsS0FBSyxHQUFHLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztFQUNuRDtDQUNGLENBQUM7QUFDSDtBQUVBLE9BQU8sU0FBUyxvQkFBb0I7Q0FDbEMsTUFBTSxLQUFLLGVBQWU7Q0FDMUIsTUFBTSxNQUFNLFdBQVc7Q0FDdkIsT0FBTyxZQUFZO0VBQ2pCLGFBQWEsVUFBa0IsSUFBSSxlQUFlLEtBQUs7RUFDdkQsVUFBVSxPQUFPLFVBQVU7R0FDekIsTUFBTSxHQUFHLGNBQWMsRUFBRSxVQUFVLElBQUksQ0FBQztHQUN4QyxNQUFNLFdBQVcsR0FBRyxhQUFtQixHQUFHO0dBQzFDLElBQUksVUFBVSxHQUFHLGFBQW1CLEtBQUs7SUFBRSxHQUFHO0lBQVUsT0FBTyxTQUFTLE1BQU0sUUFBUSxNQUFNLEVBQUUsVUFBVSxLQUFLO0dBQUUsQ0FBQztHQUNoSCxPQUFPLEVBQUUsU0FBUztFQUNwQjtFQUNBLFVBQVUsT0FBTyxPQUFPLFFBQVE7R0FDOUIsSUFBSSxLQUFLLFVBQVUsR0FBRyxhQUFhLEtBQUssSUFBSSxRQUFRO0dBQ3BELE1BQU07SUFBRSxPQUFPO0lBQW1DLGFBQWEsV0FBVyxLQUFLLENBQUMsQ0FBQztJQUFTLFNBQVM7R0FBYyxDQUFDO0VBQ3BIO0VBQ0EsaUJBQWlCO0dBQ2YsS0FBSyxHQUFHLGtCQUFrQixFQUFFLFVBQVUsSUFBSSxDQUFDO0dBQzNDLEtBQUssR0FBRyxrQkFBa0IsRUFBRSxVQUFVLENBQUMsT0FBTyxFQUFFLENBQUM7RUFDbkQ7Q0FDRixDQUFDO0FBQ0g7QUFFQSxPQUFPLFNBQVMsU0FBUyxNQUE4RDtDQUNyRixNQUFNLEVBQUUsV0FBVyxnQkFBZ0I7Q0FDbkMsT0FBTyxTQUFTO0VBQ2QsVUFBVSxDQUFDLEdBQUcsR0FBRyxNQUFNLEtBQUssUUFBUSxLQUFLLE9BQU8sR0FBRyxVQUFVLE9BQU87RUFDcEUsVUFBVSxFQUFFLGFBQWEsSUFBSSxTQUFTO0dBQUUsWUFBWSxLQUFLLFVBQVU7R0FBVyxTQUFTLEtBQUs7RUFBUSxHQUFHLEVBQUUsT0FBTyxDQUFDO0VBQ2pILFNBQVMsS0FBSztFQUNkLGlCQUFpQjtFQUNqQixXQUFXO0NBQ2IsQ0FBQztBQUNIOztBQUdBLE9BQU8sU0FBUyxhQUFhO0NBQzNCLE1BQU0sRUFBRSxpQkFBaUIsV0FBVyxnQkFBZ0I7Q0FDcEQsT0FBTyxTQUFTO0VBQ2QsVUFBVSxDQUFDLEdBQUcsR0FBRyxTQUFTLE1BQU07RUFDaEMsVUFBVSxFQUFFLGFBQWEsSUFBSSxZQUFZLEVBQUUsT0FBTyxDQUFDO0VBQ25ELFNBQVM7Q0FDWCxDQUFDO0FBQ0g7QUFFQSxPQUFPLFNBQVMsa0JBQWtCO0NBQ2hDLE1BQU0sS0FBSyxlQUFlO0NBQzFCLE9BQU8sWUFBWTtFQUNqQixhQUFhLFNBQXFCLElBQUksYUFBYSxJQUFJO0VBQ3ZELGlCQUFpQixHQUFHLGtCQUFrQixFQUFFLFVBQVUsR0FBRyxRQUFRLENBQUM7Q0FDaEUsQ0FBQztBQUNIO0FBRUEsT0FBTyxTQUFTLGtCQUFrQjtDQUNoQyxNQUFNLEtBQUssZUFBZTtDQUMxQixPQUFPLFlBQVk7RUFDakIsYUFBYSxFQUFFLElBQUksV0FBc0QsSUFBSSxhQUFhLElBQUksSUFBSTtFQUNsRyxpQkFBaUIsR0FBRyxrQkFBa0IsRUFBRSxVQUFVLEdBQUcsUUFBUSxDQUFDO0NBQ2hFLENBQUM7QUFDSDtBQUVBLE9BQU8sU0FBUyxtQkFBbUI7Q0FDakMsTUFBTSxLQUFLLGVBQWU7Q0FDMUIsT0FBTyxZQUFZO0VBQ2pCLGFBQWEsRUFBRSxJQUFJLGNBQWdELElBQUksY0FBYyxJQUFJLE9BQU87RUFDaEcsaUJBQWlCLEdBQUcsa0JBQWtCLEVBQUUsVUFBVSxHQUFHLFFBQVEsQ0FBQztDQUNoRSxDQUFDO0FBQ0g7QUFFQSxPQUFPLFNBQVMsc0JBQXNCO0NBQ3BDLE1BQU0sS0FBSyxlQUFlO0NBQzFCLE9BQU8sWUFBWTtFQUNqQixhQUFhLE9BQWUsSUFBSSxpQkFBaUIsRUFBRTtFQUNuRCxpQkFBaUIsR0FBRyxrQkFBa0IsRUFBRSxVQUFVLEdBQUcsUUFBUSxDQUFDO0NBQ2hFLENBQUM7QUFDSDs7QUFLQSxPQUFPLFNBQVMsU0FBUyxJQUFZO0NBQ25DLE9BQU8sU0FBUztFQUNkLFVBQVUsR0FBRyxNQUFNLEVBQUU7RUFDckIsVUFBVSxFQUFFLGFBQWEsSUFBSSxTQUFTLElBQUksRUFBRSxPQUFPLENBQUM7O0VBRXBELGtCQUFrQixVQUFXLE1BQU0sTUFBTSxNQUFNLFdBQVcsWUFBWSxNQUFPO0VBQzdFLFFBQVEsT0FBTyxVQUFVLEVBQUUsaUJBQWlCLFlBQVksTUFBTSxTQUFTLGdCQUFnQixRQUFRO0NBQ2pHLENBQUM7QUFDSDtBQUVBLE1BQU0sY0FBYztBQUVwQixTQUFTLGNBQWMsTUFBdUI7Q0FDNUMsT0FBTyxLQUFLLFVBQVU7RUFBQyxLQUFLO0VBQVUsS0FBSztHQUFVLEtBQUssY0FBYyxHQUFFLENBQUUsWUFBWTtFQUFHLEtBQUs7Q0FBYSxDQUFDO0FBQ2hIOzs7Ozs7QUFPQSxPQUFPLFNBQVMsZ0JBQWdCO0NBQzlCLE1BQU0sS0FBSyxlQUFlO0NBQzFCLE9BQU8sWUFBWTtFQUNqQixZQUFZLE9BQU8sU0FBMEI7R0FDM0MsTUFBTSxLQUFLLGNBQWMsSUFBSTtHQUM3QixJQUFJLE1BQXFCO0dBQ3pCLElBQUk7SUFDRixNQUFNLGVBQWUsUUFBUSxjQUFjLEVBQUU7R0FDL0MsUUFBUSxDQUVSO0dBQ0EsSUFBSSxDQUFDLEtBQUs7SUFDUixNQUFNLElBQUksTUFBTTtJQUNoQixJQUFJO0tBQ0YsZUFBZSxRQUFRLGNBQWMsSUFBSSxHQUFHO0lBQzlDLFFBQVEsQ0FFUjtHQUNGO0dBQ0EsSUFBSTs7R0FFSixLQUFLLElBQUksVUFBVSxHQUFHLFVBQVUsR0FBRyxXQUFXO0lBQzVDLElBQUk7S0FDRixPQUFPLE1BQU0sSUFBSSxZQUFZLE1BQU0sR0FBRztJQUN4QyxTQUFTLE9BQU87S0FDZCxZQUFZO0tBQ1osTUFBTSxJQUFJLFdBQVcsS0FBSztLQUMxQixJQUFJLEVBQUUsU0FBUyxhQUFhLEVBQUUsU0FBUyxXQUFXLE1BQU07S0FDeEQsTUFBTSxNQUFNLE9BQVEsVUFBVSxFQUFFO0lBQ2xDO0dBQ0Y7R0FDQSxNQUFNLFdBQVcsU0FBUztFQUM1QjtFQUNBLFlBQVksVUFBVTtHQUNwQixHQUFHLGFBQWEsR0FBRyxNQUFNLE1BQU0sRUFBRSxHQUFHLEtBQUs7R0FDekMsS0FBSyxHQUFHLGtCQUFrQixFQUFFLFVBQVUsR0FBRyxLQUFLLENBQUM7R0FDL0MsS0FBSyxHQUFHLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztHQUNqRCxLQUFLLEdBQUcsa0JBQWtCLEVBQUUsVUFBVSxHQUFHLEtBQUssSUFBSSxDQUFDO0dBQ25ELElBQUk7SUFDRixLQUFLLElBQUksSUFBSSxlQUFlLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztLQUNuRCxNQUFNLElBQUksZUFBZSxJQUFJLENBQUM7S0FDOUIsSUFBSSxHQUFHLFdBQVcsV0FBVyxHQUFHLGVBQWUsV0FBVyxDQUFDO0lBQzdEO0dBQ0YsUUFBUSxDQUVSO0VBQ0Y7Q0FDRixDQUFDO0FBQ0giLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidXNlLWFwaS50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBrZWVwUHJldmlvdXNEYXRhLFxuICB1c2VNdXRhdGlvbixcbiAgdXNlUXVlcnksXG4gIHVzZVF1ZXJ5Q2xpZW50LFxuICB0eXBlIFF1ZXJ5Q2xpZW50LFxufSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgKiBhcyBhcGkgZnJvbSAnQC9hcGkvcmVzb3VyY2VzJ1xuaW1wb3J0IHtcbiAgdHlwZSBDYXJ0LFxuICB0eXBlIENyZWF0ZU9yZGVyQm9keSxcbiAgdHlwZSBMb2dpbkJvZHksXG4gIHR5cGUgTmV0d29yayxcbiAgdHlwZSBOZnREZXRhaWwsXG4gIHR5cGUgTmZ0TGlzdCxcbiAgdHlwZSBOZnRMaXN0UGFyYW1zLFxuICB0eXBlIE5mdFN1bW1hcnksXG4gIHR5cGUgUGFzc3dvcmRCb2R5LFxuICB0eXBlIFByb2ZpbGVCb2R5LFxuICB0eXBlIFNpZ251cEJvZHksXG4gIHR5cGUgV2FsbGV0LFxuICB0eXBlIFdhbGxldEJvZHksXG59IGZyb20gJ0AvYXBpL2NvbnRyYWN0cydcbmltcG9ydCB7IEFwaUVycm9yLCB0b0FwaUVycm9yIH0gZnJvbSAnQC9hcGkvZXJyb3JzJ1xuaW1wb3J0IHsgcWsgfSBmcm9tICdAL2FwaS9rZXlzJ1xuaW1wb3J0IHsgY2xlYXJHdWVzdElkLCBzZXNzaW9uU3RvcmUgfSBmcm9tICdAL2F1dGgvc2Vzc2lvbi1zdG9yZSdcbmltcG9ydCB7IHVzZVNlc3Npb25TdGF0ZSB9IGZyb20gJ0AvYXV0aC91c2Utc2Vzc2lvbidcbmltcG9ydCB7IHNsZWVwLCB1aWQgfSBmcm9tICdAL2xpYi91dGlscydcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAnQC9zdG9yZXMvdG9hc3RzJ1xuXG4vKiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgc2Vzc8OjbyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VDdXJyZW50VXNlcigpIHtcbiAgY29uc3QgeyBpc0F1dGhlbnRpY2F0ZWQgfSA9IHVzZVNlc3Npb25TdGF0ZSgpXG4gIHJldHVybiB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IHFrLnNlc3Npb24sXG4gICAgcXVlcnlGbjogKHsgc2lnbmFsIH0pID0+IGFwaS5nZXRTZXNzaW9uKHsgc2lnbmFsIH0pLFxuICAgIGVuYWJsZWQ6IGlzQXV0aGVudGljYXRlZCxcbiAgICBzdGFsZVRpbWU6IDYwXzAwMCxcbiAgfSlcbn1cblxuZnVuY3Rpb24gc3RhcnRTZXNzaW9uKHJlczogeyB0b2tlbjogc3RyaW5nOyBleHBpcmVzQXQ6IHN0cmluZzsgdXNlcjogeyBpZDogc3RyaW5nIH0gfSkge1xuICBjbGVhckd1ZXN0SWQoKVxuICBzZXNzaW9uU3RvcmUuc3RhcnQoeyB0b2tlbjogcmVzLnRva2VuLCBleHBpcmVzQXQ6IHJlcy5leHBpcmVzQXQsIHVzZXJJZDogcmVzLnVzZXIuaWQgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUxvZ2luKCkge1xuICByZXR1cm4gdXNlTXV0YXRpb24oeyBtdXRhdGlvbkZuOiAoYm9keTogTG9naW5Cb2R5KSA9PiBhcGkubG9naW4oYm9keSksIG9uU3VjY2Vzczogc3RhcnRTZXNzaW9uIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VTaWdudXAoKSB7XG4gIHJldHVybiB1c2VNdXRhdGlvbih7IG11dGF0aW9uRm46IChib2R5OiBTaWdudXBCb2R5KSA9PiBhcGkuc2lnbnVwKGJvZHkpLCBvblN1Y2Nlc3M6IHN0YXJ0U2Vzc2lvbiB9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlTG9nb3V0KCkge1xuICByZXR1cm4gdXNlTXV0YXRpb24oe1xuICAgIG11dGF0aW9uRm46IGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IGFwaS5sb2dvdXQoKVxuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8vIE1lc21vIHF1ZSBhIEFQSSBmYWxoZSwgYSBzZXNzw6NvIGxvY2FsIMOpIGVuY2VycmFkYTogbG9nb3V0IG51bmNhIGRldmUgZmljYXIgcHJlc28uXG4gICAgICB9XG4gICAgfSxcbiAgICBvblNldHRsZWQ6ICgpID0+IHNlc3Npb25TdG9yZS5lbmQoJ2xvZ291dCcpLFxuICB9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlVXBkYXRlUHJvZmlsZSgpIHtcbiAgY29uc3QgcWMgPSB1c2VRdWVyeUNsaWVudCgpXG4gIHJldHVybiB1c2VNdXRhdGlvbih7XG4gICAgbXV0YXRpb25GbjogKGJvZHk6IFByb2ZpbGVCb2R5KSA9PiBhcGkudXBkYXRlUHJvZmlsZShib2R5KSxcbiAgICBvblN1Y2Nlc3M6ICh1c2VyKSA9PiB7XG4gICAgICBxYy5zZXRRdWVyeURhdGEocWsuc2Vzc2lvbiwgKG9sZDogeyBleHBpcmVzQXQ6IHN0cmluZyB9IHwgdW5kZWZpbmVkKSA9PlxuICAgICAgICBvbGQgPyB7IC4uLm9sZCwgdXNlciB9IDogdW5kZWZpbmVkLFxuICAgICAgKVxuICAgICAgdm9pZCBxYy5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBxay5zZXNzaW9uIH0pXG4gICAgfSxcbiAgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUNoYW5nZVBhc3N3b3JkKCkge1xuICByZXR1cm4gdXNlTXV0YXRpb24oeyBtdXRhdGlvbkZuOiAoYm9keTogUGFzc3dvcmRCb2R5KSA9PiBhcGkuY2hhbmdlUGFzc3dvcmQoYm9keSkgfSlcbn1cblxuLyog4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIGNhdMOhbG9nbyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VOZnRMaXN0KHBhcmFtczogUGFydGlhbDxOZnRMaXN0UGFyYW1zPikge1xuICBjb25zdCB7IHVzZXJJZCB9ID0gdXNlU2Vzc2lvblN0YXRlKClcbiAgcmV0dXJuIHVzZVF1ZXJ5KHtcbiAgICAvLyB1c2VySWQgbmEgY2hhdmU6IGRhZG9zIGRlIHVtIHVzdcOhcmlvIChpc0Zhdm9yaXRlKSBudW5jYSBzw6NvIHJlYXByb3ZlaXRhZG9zIHBvciBvdXRyby5cbiAgICBxdWVyeUtleTogWy4uLnFrLm5mdHMubGlzdChwYXJhbXMpLCB1c2VySWRdLFxuICAgIC8vIGBzaWduYWxgIGNhbmNlbGEgYSByZXF1aXNpw6fDo28gYW50ZXJpb3IgYW8gbXVkYXIgZmlsdHJvcyAoc2VtIHJlc3Bvc3RhcyBvYnNvbGV0YXMpLlxuICAgIHF1ZXJ5Rm46ICh7IHNpZ25hbCB9KSA9PiBhcGkubGlzdE5mdHMocGFyYW1zLCB7IHNpZ25hbCB9KSxcbiAgICBwbGFjZWhvbGRlckRhdGE6IGtlZXBQcmV2aW91c0RhdGEsXG4gIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VGZWF0dXJlZCgpIHtcbiAgY29uc3QgeyB1c2VySWQgfSA9IHVzZVNlc3Npb25TdGF0ZSgpXG4gIHJldHVybiB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFsuLi5xay5uZnRzLmZlYXR1cmVkLCB1c2VySWRdLFxuICAgIHF1ZXJ5Rm46ICh7IHNpZ25hbCB9KSA9PiBhcGkubGlzdEZlYXR1cmVkKHsgc2lnbmFsIH0pLFxuICB9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlTmZ0KGlkOiBzdHJpbmcpIHtcbiAgY29uc3QgeyB1c2VySWQgfSA9IHVzZVNlc3Npb25TdGF0ZSgpXG4gIHJldHVybiB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFsuLi5xay5uZnRzLmRldGFpbChpZCksIHVzZXJJZF0sXG4gICAgcXVlcnlGbjogKHsgc2lnbmFsIH0pID0+IGFwaS5nZXROZnQoaWQsIHsgc2lnbmFsIH0pLFxuICAgIHJldHJ5OiAoY291bnQsIGVycm9yKSA9PiAhKGVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgZXJyb3IuY29kZSA9PT0gJ05PVF9GT1VORCcpICYmIGNvdW50IDwgMixcbiAgfSlcbn1cblxuLyog4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIGZhdm9yaXRvcyAoYXR1YWxpemHDp8OjbyBvdGltaXN0YSBjb20gcm9sbGJhY2spIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL1xuZnVuY3Rpb24gcGF0Y2hGYXZvcml0ZUV2ZXJ5d2hlcmUocWM6IFF1ZXJ5Q2xpZW50LCBuZnRJZDogc3RyaW5nLCBpc0Zhdm9yaXRlOiBib29sZWFuKSB7XG4gIHFjLnNldFF1ZXJpZXNEYXRhPE5mdERldGFpbCB8IE5mdExpc3Q+KHsgcXVlcnlLZXk6IHFrLm5mdHMuYWxsIH0sIChvbGQpID0+IHtcbiAgICBpZiAoIW9sZCkgcmV0dXJuIG9sZFxuICAgIGlmICgnaXRlbXMnIGluIG9sZCkge1xuICAgICAgcmV0dXJuIHsgLi4ub2xkLCBpdGVtczogb2xkLml0ZW1zLm1hcCgoaSkgPT4gKGkuaWQgPT09IG5mdElkID8geyAuLi5pLCBpc0Zhdm9yaXRlIH0gOiBpKSkgfVxuICAgIH1cbiAgICByZXR1cm4gb2xkLmlkID09PSBuZnRJZCA/IHsgLi4ub2xkLCBpc0Zhdm9yaXRlIH0gOiBvbGRcbiAgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUZhdm9yaXRlcygpIHtcbiAgY29uc3QgeyBpc0F1dGhlbnRpY2F0ZWQsIHVzZXJJZCB9ID0gdXNlU2Vzc2lvblN0YXRlKClcbiAgcmV0dXJuIHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogWy4uLnFrLmZhdm9yaXRlcywgdXNlcklkXSxcbiAgICBxdWVyeUZuOiAoeyBzaWduYWwgfSkgPT4gYXBpLmxpc3RGYXZvcml0ZXMoeyBzaWduYWwgfSksXG4gICAgZW5hYmxlZDogaXNBdXRoZW50aWNhdGVkLFxuICB9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlVG9nZ2xlRmF2b3JpdGUoKSB7XG4gIGNvbnN0IHFjID0gdXNlUXVlcnlDbGllbnQoKVxuICByZXR1cm4gdXNlTXV0YXRpb24oe1xuICAgIG11dGF0aW9uRm46IGFzeW5jICh7IG5mdElkLCBuZXh0IH06IHsgbmZ0SWQ6IHN0cmluZzsgbmV4dDogYm9vbGVhbiB9KSA9PlxuICAgICAgbmV4dCA/IGFwaS5hZGRGYXZvcml0ZShuZnRJZCkgOiBhcGkucmVtb3ZlRmF2b3JpdGUobmZ0SWQpLFxuICAgIG9uTXV0YXRlOiBhc3luYyAoeyBuZnRJZCwgbmV4dCB9KSA9PiB7XG4gICAgICBhd2FpdCBxYy5jYW5jZWxRdWVyaWVzKHsgcXVlcnlLZXk6IHFrLm5mdHMuYWxsIH0pXG4gICAgICBhd2FpdCBxYy5jYW5jZWxRdWVyaWVzKHsgcXVlcnlLZXk6IHFrLmZhdm9yaXRlcyB9KVxuICAgICAgY29uc3Qgc25hcHNob3ROZnRzID0gcWMuZ2V0UXVlcmllc0RhdGE8TmZ0RGV0YWlsIHwgTmZ0TGlzdD4oeyBxdWVyeUtleTogcWsubmZ0cy5hbGwgfSlcbiAgICAgIGNvbnN0IHNuYXBzaG90RmF2cyA9IHFjLmdldFF1ZXJpZXNEYXRhPE5mdFN1bW1hcnlbXT4oeyBxdWVyeUtleTogcWsuZmF2b3JpdGVzIH0pXG4gICAgICBwYXRjaEZhdm9yaXRlRXZlcnl3aGVyZShxYywgbmZ0SWQsIG5leHQpXG4gICAgICBpZiAoIW5leHQpIHtcbiAgICAgICAgcWMuc2V0UXVlcmllc0RhdGE8TmZ0U3VtbWFyeVtdPih7IHF1ZXJ5S2V5OiBxay5mYXZvcml0ZXMgfSwgKG9sZCkgPT4gb2xkPy5maWx0ZXIoKGYpID0+IGYuaWQgIT09IG5mdElkKSlcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IHNuYXBzaG90TmZ0cywgc25hcHNob3RGYXZzIH1cbiAgICB9LFxuICAgIG9uRXJyb3I6IChlcnJvciwgX3ZhcnMsIGN0eCkgPT4ge1xuICAgICAgLy8gUm9sbGJhY2sgZG8gZXN0YWRvIG90aW1pc3RhLlxuICAgICAgZm9yIChjb25zdCBba2V5LCBkYXRhXSBvZiBjdHg/LnNuYXBzaG90TmZ0cyA/PyBbXSkgcWMuc2V0UXVlcnlEYXRhKGtleSwgZGF0YSlcbiAgICAgIGZvciAoY29uc3QgW2tleSwgZGF0YV0gb2YgY3R4Py5zbmFwc2hvdEZhdnMgPz8gW10pIHFjLnNldFF1ZXJ5RGF0YShrZXksIGRhdGEpXG4gICAgICB0b2FzdCh7XG4gICAgICAgIHRpdGxlOiAnTsOjbyBmb2kgcG9zc8OtdmVsIGF0dWFsaXphciBvIGZhdm9yaXRvJyxcbiAgICAgICAgZGVzY3JpcHRpb246IHRvQXBpRXJyb3IoZXJyb3IpLm1lc3NhZ2UsXG4gICAgICAgIHZhcmlhbnQ6ICdkZXN0cnVjdGl2ZScsXG4gICAgICB9KVxuICAgIH0sXG4gICAgb25TZXR0bGVkOiAoKSA9PiB7XG4gICAgICB2b2lkIHFjLmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IHFrLmZhdm9yaXRlcyB9KVxuICAgIH0sXG4gIH0pXG59XG5cbi8qIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBjYXJyaW5obyAob3RpbWlzdGEgbmEgcXVhbnRpZGFkZS9yZW1vw6fDo28pIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUNhcnQoKSB7XG4gIGNvbnN0IHsgdXNlcklkIH0gPSB1c2VTZXNzaW9uU3RhdGUoKVxuICByZXR1cm4gdXNlUXVlcnkoe1xuICAgIHF1ZXJ5S2V5OiBbLi4ucWsuY2FydCwgdXNlcklkID8/ICdndWVzdCddLFxuICAgIHF1ZXJ5Rm46ICh7IHNpZ25hbCB9KSA9PiBhcGkuZ2V0Q2FydCh7IHNpZ25hbCB9KSxcbiAgfSlcbn1cblxuLyoqIENoYXZlIGRvIGNhcnJpbmhvIGRvIHVzdcOhcmlvIGF0dWFsICh2aXNpdGFudGUgb3UgYXV0ZW50aWNhZG8pLiAqL1xuZnVuY3Rpb24gdXNlQ2FydEtleSgpIHtcbiAgY29uc3QgeyB1c2VySWQgfSA9IHVzZVNlc3Npb25TdGF0ZSgpXG4gIHJldHVybiBbLi4ucWsuY2FydCwgdXNlcklkID8/ICdndWVzdCddIGFzIGNvbnN0XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VBZGRUb0NhcnQoKSB7XG4gIGNvbnN0IHFjID0gdXNlUXVlcnlDbGllbnQoKVxuICBjb25zdCBrZXkgPSB1c2VDYXJ0S2V5KClcbiAgcmV0dXJuIHVzZU11dGF0aW9uKHtcbiAgICBtdXRhdGlvbkZuOiAodmFyczogeyBuZnRJZDogc3RyaW5nOyBxdWFudGl0eTogbnVtYmVyIH0pID0+IGFwaS5hZGRDYXJ0SXRlbSh2YXJzKSxcbiAgICBvblN1Y2Nlc3M6IChjYXJ0KSA9PiB7XG4gICAgICBxYy5zZXRRdWVyeURhdGEoa2V5LCBjYXJ0KVxuICAgICAgdm9pZCBxYy5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3F1b3RlJ10gfSlcbiAgICB9LFxuICB9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlU2V0Q2FydFF1YW50aXR5KCkge1xuICBjb25zdCBxYyA9IHVzZVF1ZXJ5Q2xpZW50KClcbiAgY29uc3Qga2V5ID0gdXNlQ2FydEtleSgpXG4gIHJldHVybiB1c2VNdXRhdGlvbih7XG4gICAgbXV0YXRpb25GbjogKHZhcnM6IHsgbmZ0SWQ6IHN0cmluZzsgcXVhbnRpdHk6IG51bWJlciB9KSA9PiBhcGkuc2V0Q2FydEl0ZW1RdWFudGl0eSh2YXJzLm5mdElkLCB2YXJzLnF1YW50aXR5KSxcbiAgICBvbk11dGF0ZTogYXN5bmMgKHsgbmZ0SWQsIHF1YW50aXR5IH0pID0+IHtcbiAgICAgIGF3YWl0IHFjLmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleToga2V5IH0pXG4gICAgICBjb25zdCBwcmV2aW91cyA9IHFjLmdldFF1ZXJ5RGF0YTxDYXJ0PihrZXkpXG4gICAgICBpZiAocHJldmlvdXMpIHtcbiAgICAgICAgcWMuc2V0UXVlcnlEYXRhPENhcnQ+KGtleSwge1xuICAgICAgICAgIC4uLnByZXZpb3VzLFxuICAgICAgICAgIGl0ZW1zOiBwcmV2aW91cy5pdGVtcy5tYXAoKGkpID0+IChpLm5mdElkID09PSBuZnRJZCA/IHsgLi4uaSwgcXVhbnRpdHkgfSA6IGkpKSxcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IHByZXZpb3VzIH1cbiAgICB9LFxuICAgIG9uRXJyb3I6IChlcnJvciwgX3ZhcnMsIGN0eCkgPT4ge1xuICAgICAgaWYgKGN0eD8ucHJldmlvdXMpIHFjLnNldFF1ZXJ5RGF0YShrZXksIGN0eC5wcmV2aW91cylcbiAgICAgIHRvYXN0KHsgdGl0bGU6ICdOw6NvIGZvaSBwb3Nzw612ZWwgYWx0ZXJhciBhIHF1YW50aWRhZGUnLCBkZXNjcmlwdGlvbjogdG9BcGlFcnJvcihlcnJvcikubWVzc2FnZSwgdmFyaWFudDogJ3dhcm5pbmcnIH0pXG4gICAgfSxcbiAgICBvblNldHRsZWQ6ICgpID0+IHtcbiAgICAgIHZvaWQgcWMuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleToga2V5IH0pXG4gICAgICB2b2lkIHFjLmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsncXVvdGUnXSB9KVxuICAgIH0sXG4gIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VSZW1vdmVDYXJ0SXRlbSgpIHtcbiAgY29uc3QgcWMgPSB1c2VRdWVyeUNsaWVudCgpXG4gIGNvbnN0IGtleSA9IHVzZUNhcnRLZXkoKVxuICByZXR1cm4gdXNlTXV0YXRpb24oe1xuICAgIG11dGF0aW9uRm46IChuZnRJZDogc3RyaW5nKSA9PiBhcGkucmVtb3ZlQ2FydEl0ZW0obmZ0SWQpLFxuICAgIG9uTXV0YXRlOiBhc3luYyAobmZ0SWQpID0+IHtcbiAgICAgIGF3YWl0IHFjLmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleToga2V5IH0pXG4gICAgICBjb25zdCBwcmV2aW91cyA9IHFjLmdldFF1ZXJ5RGF0YTxDYXJ0PihrZXkpXG4gICAgICBpZiAocHJldmlvdXMpIHFjLnNldFF1ZXJ5RGF0YTxDYXJ0PihrZXksIHsgLi4ucHJldmlvdXMsIGl0ZW1zOiBwcmV2aW91cy5pdGVtcy5maWx0ZXIoKGkpID0+IGkubmZ0SWQgIT09IG5mdElkKSB9KVxuICAgICAgcmV0dXJuIHsgcHJldmlvdXMgfVxuICAgIH0sXG4gICAgb25FcnJvcjogKGVycm9yLCBfdmFycywgY3R4KSA9PiB7XG4gICAgICBpZiAoY3R4Py5wcmV2aW91cykgcWMuc2V0UXVlcnlEYXRhKGtleSwgY3R4LnByZXZpb3VzKVxuICAgICAgdG9hc3QoeyB0aXRsZTogJ07Do28gZm9pIHBvc3PDrXZlbCByZW1vdmVyIG8gaXRlbScsIGRlc2NyaXB0aW9uOiB0b0FwaUVycm9yKGVycm9yKS5tZXNzYWdlLCB2YXJpYW50OiAnZGVzdHJ1Y3RpdmUnIH0pXG4gICAgfSxcbiAgICBvblNldHRsZWQ6ICgpID0+IHtcbiAgICAgIHZvaWQgcWMuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleToga2V5IH0pXG4gICAgICB2b2lkIHFjLmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsncXVvdGUnXSB9KVxuICAgIH0sXG4gIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VRdW90ZShhcmdzOiB7IGNvdXBvbjogc3RyaW5nOyBuZXR3b3JrOiBOZXR3b3JrOyBlbmFibGVkOiBib29sZWFuIH0pIHtcbiAgY29uc3QgeyB1c2VySWQgfSA9IHVzZVNlc3Npb25TdGF0ZSgpXG4gIHJldHVybiB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFsuLi5xay5xdW90ZShhcmdzLmNvdXBvbiwgYXJncy5uZXR3b3JrKSwgdXNlcklkID8/ICdndWVzdCddLFxuICAgIHF1ZXJ5Rm46ICh7IHNpZ25hbCB9KSA9PiBhcGkuZ2V0UXVvdGUoeyBjb3Vwb25Db2RlOiBhcmdzLmNvdXBvbiB8fCB1bmRlZmluZWQsIG5ldHdvcms6IGFyZ3MubmV0d29yayB9LCB7IHNpZ25hbCB9KSxcbiAgICBlbmFibGVkOiBhcmdzLmVuYWJsZWQsXG4gICAgcGxhY2Vob2xkZXJEYXRhOiBrZWVwUHJldmlvdXNEYXRhLFxuICAgIHN0YWxlVGltZTogMTBfMDAwLFxuICB9KVxufVxuXG4vKiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgY2FydGVpcmFzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVdhbGxldHMoKSB7XG4gIGNvbnN0IHsgaXNBdXRoZW50aWNhdGVkLCB1c2VySWQgfSA9IHVzZVNlc3Npb25TdGF0ZSgpXG4gIHJldHVybiB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFsuLi5xay53YWxsZXRzLCB1c2VySWRdLFxuICAgIHF1ZXJ5Rm46ICh7IHNpZ25hbCB9KSA9PiBhcGkubGlzdFdhbGxldHMoeyBzaWduYWwgfSksXG4gICAgZW5hYmxlZDogaXNBdXRoZW50aWNhdGVkLFxuICB9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlQ3JlYXRlV2FsbGV0KCkge1xuICBjb25zdCBxYyA9IHVzZVF1ZXJ5Q2xpZW50KClcbiAgcmV0dXJuIHVzZU11dGF0aW9uKHtcbiAgICBtdXRhdGlvbkZuOiAoYm9keTogV2FsbGV0Qm9keSkgPT4gYXBpLmNyZWF0ZVdhbGxldChib2R5KSxcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHFjLmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IHFrLndhbGxldHMgfSksXG4gIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VVcGRhdGVXYWxsZXQoKSB7XG4gIGNvbnN0IHFjID0gdXNlUXVlcnlDbGllbnQoKVxuICByZXR1cm4gdXNlTXV0YXRpb24oe1xuICAgIG11dGF0aW9uRm46ICh7IGlkLCBib2R5IH06IHsgaWQ6IHN0cmluZzsgYm9keTogUGFydGlhbDxXYWxsZXRCb2R5PiB9KSA9PiBhcGkudXBkYXRlV2FsbGV0KGlkLCBib2R5KSxcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHFjLmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IHFrLndhbGxldHMgfSksXG4gIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VDb25uZWN0V2FsbGV0KCkge1xuICBjb25zdCBxYyA9IHVzZVF1ZXJ5Q2xpZW50KClcbiAgcmV0dXJuIHVzZU11dGF0aW9uKHtcbiAgICBtdXRhdGlvbkZuOiAoeyBpZCwgbmV0d29yayB9OiB7IGlkOiBzdHJpbmc7IG5ldHdvcms6IE5ldHdvcmsgfSkgPT4gYXBpLmNvbm5lY3RXYWxsZXQoaWQsIG5ldHdvcmspLFxuICAgIG9uU3VjY2VzczogKCkgPT4gcWMuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogcWsud2FsbGV0cyB9KSxcbiAgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZURpc2Nvbm5lY3RXYWxsZXQoKSB7XG4gIGNvbnN0IHFjID0gdXNlUXVlcnlDbGllbnQoKVxuICByZXR1cm4gdXNlTXV0YXRpb24oe1xuICAgIG11dGF0aW9uRm46IChpZDogc3RyaW5nKSA9PiBhcGkuZGlzY29ubmVjdFdhbGxldChpZCksXG4gICAgb25TdWNjZXNzOiAoKSA9PiBxYy5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBxay53YWxsZXRzIH0pLFxuICB9KVxufVxuXG5leHBvcnQgdHlwZSB7IFdhbGxldCB9XG5cbi8qIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBwZWRpZG9zIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZU9yZGVyKGlkOiBzdHJpbmcpIHtcbiAgcmV0dXJuIHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogcWsub3JkZXIoaWQpLFxuICAgIHF1ZXJ5Rm46ICh7IHNpZ25hbCB9KSA9PiBhcGkuZ2V0T3JkZXIoaWQsIHsgc2lnbmFsIH0pLFxuICAgIC8vIFJlZGUgZGUgc2VndXJhbsOnYSBhbMOpbSBkbyBTb2NrZXQuSU86IGVucXVhbnRvIHBlbmRlbnRlLCByZWNvbmNpbGlhIHBlcmlvZGljYW1lbnRlLlxuICAgIHJlZmV0Y2hJbnRlcnZhbDogKHF1ZXJ5KSA9PiAocXVlcnkuc3RhdGUuZGF0YT8uc3RhdHVzID09PSAncGVuZGluZycgPyAzMDAwIDogZmFsc2UpLFxuICAgIHJldHJ5OiAoY291bnQsIGVycm9yKSA9PiAhKGVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgZXJyb3IuY29kZSA9PT0gJ05PVF9GT1VORCcpICYmIGNvdW50IDwgMixcbiAgfSlcbn1cblxuY29uc3QgSURFTV9QUkVGSVggPSAnbmZ0LmlkZW0uJ1xuXG5mdW5jdGlvbiBmaW5nZXJwcmludE9mKGJvZHk6IENyZWF0ZU9yZGVyQm9keSkge1xuICByZXR1cm4gSlNPTi5zdHJpbmdpZnkoW2JvZHkud2FsbGV0SWQsIGJvZHkubmV0d29yaywgKGJvZHkuY291cG9uQ29kZSA/PyAnJykudG9VcHBlckNhc2UoKSwgYm9keS5leHBlY3RlZFRvdGFsXSlcbn1cblxuLyoqXG4gKiBDcmlhIG8gcGVkaWRvIGNvbSBJZGVtcG90ZW5jeS1LZXkgZXN0w6F2ZWwgcG9yIGNvbnRlw7pkbzogcmVlbnZpb3MgZG8gbWVzbW9cbiAqIHBlZGlkbyAoZHVwbG8gY2xpcXVlLCB0aW1lb3V0LCByZWZyZXNoKSBkZXZvbHZlbSBvIG1lc21vIHBlZGlkby4gU2Ugb1xuICogY29udGXDumRvIG11ZGFyIChleC46IHVzdcOhcmlvIHJldmlzb3UgdW0gbm92byB0b3RhbCksIHVtYSBub3ZhIGNoYXZlIMOpIHVzYWRhLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlUGxhY2VPcmRlcigpIHtcbiAgY29uc3QgcWMgPSB1c2VRdWVyeUNsaWVudCgpXG4gIHJldHVybiB1c2VNdXRhdGlvbih7XG4gICAgbXV0YXRpb25GbjogYXN5bmMgKGJvZHk6IENyZWF0ZU9yZGVyQm9keSkgPT4ge1xuICAgICAgY29uc3QgZnAgPSBmaW5nZXJwcmludE9mKGJvZHkpXG4gICAgICBsZXQga2V5OiBzdHJpbmcgfCBudWxsID0gbnVsbFxuICAgICAgdHJ5IHtcbiAgICAgICAga2V5ID0gc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShJREVNX1BSRUZJWCArIGZwKVxuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8qIG5vb3AgKi9cbiAgICAgIH1cbiAgICAgIGlmICgha2V5KSB7XG4gICAgICAgIGtleSA9IHVpZCgnaWRlbScpXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShJREVNX1BSRUZJWCArIGZwLCBrZXkpXG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8qIG5vb3AgKi9cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgbGV0IGxhc3RFcnJvcjogdW5rbm93blxuICAgICAgLy8gVGltZW91dC9xdWVkYSBkZSByZWRlOiBvIHBlZGlkbyBwb2RlIHRlciBzaWRvIGNyaWFkby4gUmVwZXRlIENPTSBBIE1FU01BIGNoYXZlLlxuICAgICAgZm9yIChsZXQgYXR0ZW1wdCA9IDA7IGF0dGVtcHQgPCAzOyBhdHRlbXB0KyspIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXR1cm4gYXdhaXQgYXBpLmNyZWF0ZU9yZGVyKGJvZHksIGtleSlcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBsYXN0RXJyb3IgPSBlcnJvclxuICAgICAgICAgIGNvbnN0IGUgPSB0b0FwaUVycm9yKGVycm9yKVxuICAgICAgICAgIGlmIChlLmNvZGUgIT09ICdUSU1FT1VUJyAmJiBlLmNvZGUgIT09ICdORVRXT1JLJykgdGhyb3cgZVxuICAgICAgICAgIGF3YWl0IHNsZWVwKDEwMDAgKiAoYXR0ZW1wdCArIDEpKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aHJvdyB0b0FwaUVycm9yKGxhc3RFcnJvcilcbiAgICB9LFxuICAgIG9uU3VjY2VzczogKG9yZGVyKSA9PiB7XG4gICAgICBxYy5zZXRRdWVyeURhdGEocWsub3JkZXIob3JkZXIuaWQpLCBvcmRlcilcbiAgICAgIHZvaWQgcWMuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogcWsuY2FydCB9KVxuICAgICAgdm9pZCBxYy5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3F1b3RlJ10gfSlcbiAgICAgIHZvaWQgcWMuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogcWsubmZ0cy5hbGwgfSlcbiAgICAgIHRyeSB7XG4gICAgICAgIGZvciAobGV0IGkgPSBzZXNzaW9uU3RvcmFnZS5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgICAgIGNvbnN0IGsgPSBzZXNzaW9uU3RvcmFnZS5rZXkoaSlcbiAgICAgICAgICBpZiAoaz8uc3RhcnRzV2l0aChJREVNX1BSRUZJWCkpIHNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0oaylcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8qIG5vb3AgKi9cbiAgICAgIH1cbiAgICB9LFxuICB9KVxufVxuIl19