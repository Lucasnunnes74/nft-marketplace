import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/catalog/catalog-parts.tsx");const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import { sortLabels, sortOptions } from "/src/api/contracts.ts";
import { ErrorState } from "/src/components/common/states.tsx";
import { FigmaIcon } from "/src/components/ui/figma-icon.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { useFeatured } from "/src/hooks/use-api.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/catalog/catalog-parts.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$();
/** "NFT em destaque / Oferta limitada" (barra lateral, 310×470). */
export function FeaturedBanner() {
	_s();
	const featured = useFeatured();
	const nft = featured.data?.items[0];
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-labelledby": "featured-title",
		className: "relative flex h-[470px] w-full flex-col gap-4 overflow-hidden bg-[linear-gradient(180deg,rgba(210,138,76,0.1),rgba(210,138,76,0.03))] pb-1 pt-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col items-center gap-4 px-5",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					id: "featured-title",
					className: "w-full text-2xl font-bold leading-8 text-accent",
					children: "NFT EM DESTAQUE"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "w-full text-center text-[22px] font-bold leading-4 text-foreground",
					children: "OFERTA LIMITADA"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this),
			featured.isError ? /* @__PURE__ */ _jsxDEV(ErrorState, {
				compact: true,
				error: featured.error,
				onRetry: () => void featured.refetch(),
				retrying: featured.isFetching
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 9
			}, this) : nft ? /* @__PURE__ */ _jsxDEV(Link, {
				to: "/nft/$nftId",
				params: { nftId: nft.id },
				className: "group relative block h-[368px] w-full overflow-hidden rounded-[22px]",
				children: /* @__PURE__ */ _jsxDEV("img", {
					src: nft.image.replace("-sm.webp", ".webp"),
					alt: `${nft.name} — ver oferta`,
					loading: "lazy",
					width: 310,
					height: 368,
					className: "size-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-[368px] w-full rounded-[22px] bg-surface-raised" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				"aria-hidden": true,
				className: "absolute left-4 top-[299px] size-[22px] rounded-[7px] border-2 border-[#46a358] opacity-20"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				"aria-hidden": true,
				className: "absolute left-[248px] top-[343px] size-[45px] rounded-[29px] bg-[linear-gradient(145.5deg,rgba(210,138,76,0.3)_46%,rgba(210,138,76,0)_103%)]"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				"aria-hidden": true,
				className: "absolute left-[38px] top-[105px] size-[15px] rounded-[29px] bg-[linear-gradient(145.5deg,rgba(210,138,76,0.3)_46%,rgba(210,138,76,0)_103%)]"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 5
	}, this);
}
_s(FeaturedBanner, "Lio4SyndO4nk+9jabmFvFMg2JWk=", false, function() {
	return [useFeatured];
});
_c = FeaturedBanner;
const tabs = [
	{
		key: "all",
		label: "Todos os NFTs"
	},
	{
		key: "new",
		label: "Novos lançamentos"
	},
	{
		key: "trending",
		label: "Em alta"
	}
];
export function CatalogTabs({ active }) {
	return /* @__PURE__ */ _jsxDEV("nav", {
		"aria-label": "Seções do catálogo",
		children: /* @__PURE__ */ _jsxDEV("ul", {
			className: "flex items-start gap-4 text-sm leading-4 md:gap-5 md:text-[15px] md:font-medium",
			children: tabs.map((t) => {
				const isActive = t.key === active;
				return /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					search: (prev) => ({
						...prev,
						tab: t.key === "all" ? undefined : t.key,
						page: undefined
					}),
					replace: true,
					resetScroll: false,
					"aria-current": isActive ? "page" : undefined,
					className: cn("flex flex-col gap-1 whitespace-nowrap md:gap-[7px]", isActive ? "font-bold text-accent md:font-medium" : "text-foreground hover:text-accent"),
					children: [t.label, /* @__PURE__ */ _jsxDEV("span", {
						"aria-hidden": true,
						className: cn("h-0.5 w-full", isActive ? "bg-primary" : "bg-transparent")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 15
				}, this) }, t.key, false, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 13
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 63,
		columnNumber: 5
	}, this);
}
_c2 = CatalogTabs;
export function SortSelect({ value, onChange }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex items-center gap-2 text-[15px] leading-normal text-foreground",
		children: [/* @__PURE__ */ _jsxDEV("label", {
			htmlFor: "f-sort",
			className: "whitespace-nowrap",
			children: "Ordenar por:"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 94,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative",
			children: [/* @__PURE__ */ _jsxDEV("select", {
				id: "f-sort",
				value,
				onChange: (e) => onChange(e.target.value),
				className: "cursor-pointer appearance-none bg-transparent pr-6 text-[15px] text-foreground outline-none focus-visible:underline",
				children: sortOptions.map((s) => /* @__PURE__ */ _jsxDEV("option", {
					value: s,
					className: "bg-card",
					children: sortLabels[s]
				}, s, false, {
					fileName: _jsxFileName,
					lineNumber: 105,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(FigmaIcon, {
				name: "icon-chevron-down",
				width: 9,
				height: 5,
				className: "pointer-events-none absolute right-1 top-1/2 -translate-y-1/2 text-foreground"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 97,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 93,
		columnNumber: 5
	}, this);
}
_c3 = SortSelect;
/** Paginação numerada (35×35, página atual preenchida). */
export function Pagination({ page, totalPages }) {
	const pages = pageWindow(page, totalPages);
	const box = "grid size-[35px] place-items-center rounded-[4px] text-lg leading-4";
	return /* @__PURE__ */ _jsxDEV("nav", {
		"aria-label": "Paginação",
		className: "flex items-center gap-2",
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "sr-only",
				"data-testid": "page-indicator",
				children: [
					"Página ",
					page,
					" de ",
					totalPages
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 122,
				columnNumber: 7
			}, this),
			page > 1 ? /* @__PURE__ */ _jsxDEV(Link, {
				to: "/",
				search: (prev) => ({
					...prev,
					page: page - 1 <= 1 ? undefined : page - 1
				}),
				"aria-label": "Página anterior",
				className: cn(box, "border border-border text-foreground hover:border-primary"),
				children: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
					name: "icon-chevron-right",
					width: 12,
					height: 7,
					className: "rotate-90"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 126,
				columnNumber: 9
			}, this) : null,
			pages.map((p, i) => p === "gap" ? /* @__PURE__ */ _jsxDEV("span", {
				"aria-hidden": true,
				className: "px-1 text-foreground",
				children: "…"
			}, `gap-${i}`, false, {
				fileName: _jsxFileName,
				lineNumber: 137,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV(Link, {
				to: "/",
				search: (prev) => ({
					...prev,
					page: p === 1 ? undefined : p
				}),
				"aria-label": `Página ${p}`,
				"aria-current": p === page ? "page" : undefined,
				className: cn(box, p === page ? "bg-primary font-bold text-primary-foreground" : "border border-border text-foreground hover:border-primary"),
				children: p
			}, p, false, {
				fileName: _jsxFileName,
				lineNumber: 141,
				columnNumber: 11
			}, this)),
			page < totalPages ? /* @__PURE__ */ _jsxDEV(Link, {
				to: "/",
				search: (prev) => ({
					...prev,
					page: page + 1
				}),
				"aria-label": "Próxima página",
				className: cn(box, "border border-border text-foreground hover:border-primary"),
				children: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
					name: "icon-chevron-right",
					width: 12,
					height: 7,
					className: "-rotate-90"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 163,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 157,
				columnNumber: 9
			}, this) : null
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 121,
		columnNumber: 5
	}, this);
}
_c4 = Pagination;
function pageWindow(page, total) {
	if (total <= 5) return Array.from({ length: total }, (_, i) => i + 1);
	const start = Math.max(1, Math.min(page - 1, total - 3));
	const out = [];
	if (start > 1) out.push(1, "gap");
	for (let p = start; p <= Math.min(total, start + 3); p++) out.push(p);
	if (start + 3 < total) out.push("gap", total);
	return out;
}
export function CatalogGridSkeleton({ count = 9 }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: Array.from({ length: count }, (_, i) => /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-[20px] bg-card px-1 pb-5 pt-3 md:rounded-none md:pb-[26px] md:pt-6",
				children: /* @__PURE__ */ _jsxDEV(Skeleton, { className: "aspect-square w-full rounded-2xl bg-surface-raised md:rounded-[15px]" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 186,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 185,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-3/4 bg-card" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 188,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-1/3 bg-card" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 189,
				columnNumber: 11
			}, this)
		]
	}, i, true, {
		fileName: _jsxFileName,
		lineNumber: 184,
		columnNumber: 9
	}, this)) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 182,
		columnNumber: 5
	}, this);
}
_c5 = CatalogGridSkeleton;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "FeaturedBanner");
$RefreshReg$(_c2, "CatalogTabs");
$RefreshReg$(_c3, "SortSelect");
$RefreshReg$(_c4, "Pagination");
$RefreshReg$(_c5, "CatalogGridSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/catalog/catalog-parts.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/catalog/catalog-parts.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/catalog/catalog-parts.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/catalog/catalog-parts.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQTBCLFlBQVksbUJBQW1CO0FBQ3pELFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsVUFBVTs7Ozs7QUFJbkIsT0FBTyxTQUFTLGlCQUFpQjs7Q0FDL0IsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNO0NBRWpDLE9BQ0Usd0JBQUMsV0FBRDtFQUNFLG1CQUFnQjtFQUNoQixXQUFVO1lBRlo7R0FJRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLElBQUc7S0FBaUIsV0FBVTtlQUFrRDtJQUVoRjs7OztjQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXFFO0lBQWtCOzs7O1lBQ2pHOzs7Ozs7R0FDSixTQUFTLFVBQ1Isd0JBQUMsWUFBRDtJQUFZO0lBQVEsT0FBTyxTQUFTO0lBQU8sZUFBZSxLQUFLLFNBQVMsUUFBUTtJQUFHLFVBQVUsU0FBUztHQUFhOzs7O2NBQ2pILE1BQ0Ysd0JBQUMsTUFBRDtJQUFNLElBQUc7SUFBYyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7SUFBRyxXQUFVO2NBQzFELHdCQUFDLE9BQUQ7S0FDRSxLQUFLLElBQUksTUFBTSxRQUFRLFlBQVksT0FBTztLQUMxQyxLQUFLLEdBQUcsSUFBSSxLQUFLO0tBQ2pCLFNBQVE7S0FDUixPQUFPO0tBQ1AsUUFBUTtLQUNSLFdBQVU7SUFDWDs7Ozs7R0FDRzs7OztjQUVOLHdCQUFDLFVBQUQsRUFBVSxXQUFVLG9EQUFxRDs7Ozs7R0FFM0Usd0JBQUMsUUFBRDtJQUFNO0lBQVksV0FBVTtHQUE4Rjs7Ozs7R0FDMUgsd0JBQUMsUUFBRDtJQUNFO0lBQ0EsV0FBVTtHQUNYOzs7OztHQUNELHdCQUFDLFFBQUQ7SUFDRTtJQUNBLFdBQVU7R0FDWDs7Ozs7RUFDTTs7Ozs7O0FBRWI7Ozs7O0FBRUEsTUFBTSxPQUE2QztDQUNqRDtFQUFFLEtBQUs7RUFBTyxPQUFPO0NBQWdCO0NBQ3JDO0VBQUUsS0FBSztFQUFPLE9BQU87Q0FBb0I7Q0FDekM7RUFBRSxLQUFLO0VBQVksT0FBTztDQUFVO0FBQ3RDO0FBRUEsT0FBTyxTQUFTLFlBQVksRUFBRSxVQUFrQztDQUM5RCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxjQUFXO1lBQ2Qsd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFDWCxLQUFLLEtBQUssTUFBTTtJQUNmLE1BQU0sV0FBVyxFQUFFLFFBQVE7SUFDM0IsT0FDRSx3QkFBQyxNQUFELFlBQ0Usd0JBQUMsTUFBRDtLQUNFLElBQUc7S0FDSCxTQUFTLFVBQXNCO01BQUUsR0FBRztNQUFNLEtBQUssRUFBRSxRQUFRLFFBQVEsWUFBWSxFQUFFO01BQUssTUFBTTtLQUFVO0tBQ3BHO0tBQ0EsYUFBYTtLQUNiLGdCQUFjLFdBQVcsU0FBUztLQUNsQyxXQUFXLEdBQ1Qsc0RBQ0EsV0FBVyx5Q0FBeUMsbUNBQ3REO2VBVEYsQ0FXRyxFQUFFLE9BQ0gsd0JBQUMsUUFBRDtNQUFNO01BQVksV0FBVyxHQUFHLGdCQUFnQixXQUFXLGVBQWUsZ0JBQWdCO0tBQUk7Ozs7YUFDMUY7Ozs7O2FBQ0osR0FmSyxFQUFFOzs7O1dBZVA7R0FFUixDQUFDO0VBQ0M7Ozs7O0NBQ0Q7Ozs7O0FBRVQ7O0FBRUEsT0FBTyxTQUFTLFdBQVcsRUFBRSxPQUFPLFlBQXNFO0NBQ3hHLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLFNBQUQ7R0FBTyxTQUFRO0dBQVMsV0FBVTthQUFvQjtFQUUvQzs7OztZQUNQLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxVQUFEO0lBQ0UsSUFBRztJQUNJO0lBQ1AsV0FBVyxNQUFNLFNBQVMsRUFBRSxPQUFPLEtBQW1CO0lBQ3RELFdBQVU7Y0FFVCxZQUFZLEtBQUssTUFDaEIsd0JBQUMsVUFBRDtLQUFnQixPQUFPO0tBQUcsV0FBVTtlQUNqQyxXQUFXO0lBQ04sR0FGSzs7OztXQUVMLENBQ1Q7R0FDSzs7OzthQUNSLHdCQUFDLFdBQUQ7SUFBVyxNQUFLO0lBQW9CLE9BQU87SUFBRyxRQUFRO0lBQUcsV0FBVTtHQUFpRjs7OztXQUNqSjs7Ozs7VUFDRjs7Ozs7O0FBRVQ7OztBQUdBLE9BQU8sU0FBUyxXQUFXLEVBQUUsTUFBTSxjQUFvRDtDQUNyRixNQUFNLFFBQVEsV0FBVyxNQUFNLFVBQVU7Q0FDekMsTUFBTSxNQUFNO0NBQ1osT0FDRSx3QkFBQyxPQUFEO0VBQUssY0FBVztFQUFZLFdBQVU7WUFBdEM7R0FDRSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtJQUFVLGVBQVk7Y0FBdEM7S0FBdUQ7S0FDN0M7S0FBSztLQUFLO0lBQ2Q7Ozs7OztHQUNMLE9BQU8sSUFDTix3QkFBQyxNQUFEO0lBQ0UsSUFBRztJQUNILFNBQVMsVUFBc0I7S0FBRSxHQUFHO0tBQU0sTUFBTSxPQUFPLEtBQUssSUFBSSxZQUFZLE9BQU87SUFBRTtJQUNyRixjQUFXO0lBQ1gsV0FBVyxHQUFHLEtBQUssMkRBQTJEO2NBRTlFLHdCQUFDLFdBQUQ7S0FBVyxNQUFLO0tBQXFCLE9BQU87S0FBSSxRQUFRO0tBQUcsV0FBVTtJQUFhOzs7OztHQUM5RTs7OztjQUNKO0dBQ0gsTUFBTSxLQUFLLEdBQUcsTUFDYixNQUFNLFFBQ0osd0JBQUMsUUFBRDtJQUF1QjtJQUFZLFdBQVU7Y0FBdUI7R0FFOUQsR0FGSyxPQUFPOzs7O1VBRVosSUFFTix3QkFBQyxNQUFEO0lBRUUsSUFBRztJQUNILFNBQVMsVUFBc0I7S0FBRSxHQUFHO0tBQU0sTUFBTSxNQUFNLElBQUksWUFBWTtJQUFFO0lBQ3hFLGNBQVksVUFBVTtJQUN0QixnQkFBYyxNQUFNLE9BQU8sU0FBUztJQUNwQyxXQUFXLEdBQ1QsS0FDQSxNQUFNLE9BQU8saURBQWlELDJEQUNoRTtjQUVDO0dBQ0csR0FYQzs7OztVQVdELENBRVY7R0FDQyxPQUFPLGFBQ04sd0JBQUMsTUFBRDtJQUNFLElBQUc7SUFDSCxTQUFTLFVBQXNCO0tBQUUsR0FBRztLQUFNLE1BQU0sT0FBTztJQUFFO0lBQ3pELGNBQVc7SUFDWCxXQUFXLEdBQUcsS0FBSywyREFBMkQ7Y0FFOUUsd0JBQUMsV0FBRDtLQUFXLE1BQUs7S0FBcUIsT0FBTztLQUFJLFFBQVE7S0FBRyxXQUFVO0lBQWM7Ozs7O0dBQy9FOzs7O2NBQ0o7RUFDRDs7Ozs7O0FBRVQ7O0FBRUEsU0FBUyxXQUFXLE1BQWMsT0FBbUM7Q0FDbkUsSUFBSSxTQUFTLEdBQUcsT0FBTyxNQUFNLEtBQUssRUFBRSxRQUFRLE1BQU0sSUFBSSxHQUFHLE1BQU0sSUFBSSxDQUFDO0NBQ3BFLE1BQU0sUUFBUSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksT0FBTyxHQUFHLFFBQVEsQ0FBQyxDQUFDO0NBQ3ZELE1BQU0sTUFBMEIsQ0FBQztDQUNqQyxJQUFJLFFBQVEsR0FBRyxJQUFJLEtBQUssR0FBRyxLQUFLO0NBQ2hDLEtBQUssSUFBSSxJQUFJLE9BQU8sS0FBSyxLQUFLLElBQUksT0FBTyxRQUFRLENBQUMsR0FBRyxLQUFLLElBQUksS0FBSyxDQUFDO0NBQ3BFLElBQUksUUFBUSxJQUFJLE9BQU8sSUFBSSxLQUFLLE9BQU8sS0FBSztDQUM1QyxPQUFPO0FBQ1Q7QUFFQSxPQUFPLFNBQVMsb0JBQW9CLEVBQUUsUUFBUSxLQUF5QjtDQUNyRSxPQUNFLCtDQUNHLE1BQU0sS0FBSyxFQUFFLFFBQVEsTUFBTSxJQUFJLEdBQUcsTUFDakMsd0JBQUMsT0FBRDtFQUFhLFdBQVU7WUFBdkI7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHVFQUF3RTs7Ozs7R0FDekY7Ozs7O0dBQ0wsd0JBQUMsVUFBRCxFQUFVLFdBQVUsb0JBQXFCOzs7OztHQUN6Qyx3QkFBQyxVQUFELEVBQVUsV0FBVSxvQkFBcUI7Ozs7O0VBQ3RDO0lBTks7Ozs7UUFNTCxDQUNOLEVBQ0Q7Ozs7O0FBRU4iLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiY2F0YWxvZy1wYXJ0cy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyB0eXBlIFNvcnRPcHRpb24sIHNvcnRMYWJlbHMsIHNvcnRPcHRpb25zIH0gZnJvbSAnQC9hcGkvY29udHJhY3RzJ1xuaW1wb3J0IHsgRXJyb3JTdGF0ZSB9IGZyb20gJ0AvY29tcG9uZW50cy9jb21tb24vc3RhdGVzJ1xuaW1wb3J0IHsgRmlnbWFJY29uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2ZpZ21hLWljb24nXG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9za2VsZXRvbidcbmltcG9ydCB7IHVzZUZlYXR1cmVkIH0gZnJvbSAnQC9ob29rcy91c2UtYXBpJ1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcbmltcG9ydCB0eXBlIHsgQ2F0YWxvZ1RhYiwgSG9tZVNlYXJjaCB9IGZyb20gJ0Avc2VhcmNoLXNjaGVtYXMnXG5cbi8qKiBcIk5GVCBlbSBkZXN0YXF1ZSAvIE9mZXJ0YSBsaW1pdGFkYVwiIChiYXJyYSBsYXRlcmFsLCAzMTDDlzQ3MCkuICovXG5leHBvcnQgZnVuY3Rpb24gRmVhdHVyZWRCYW5uZXIoKSB7XG4gIGNvbnN0IGZlYXR1cmVkID0gdXNlRmVhdHVyZWQoKVxuICBjb25zdCBuZnQgPSBmZWF0dXJlZC5kYXRhPy5pdGVtc1swXVxuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb25cbiAgICAgIGFyaWEtbGFiZWxsZWRieT1cImZlYXR1cmVkLXRpdGxlXCJcbiAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaC1bNDcwcHhdIHctZnVsbCBmbGV4LWNvbCBnYXAtNCBvdmVyZmxvdy1oaWRkZW4gYmctW2xpbmVhci1ncmFkaWVudCgxODBkZWcscmdiYSgyMTAsMTM4LDc2LDAuMSkscmdiYSgyMTAsMTM4LDc2LDAuMDMpKV0gcGItMSBwdC02XCJcbiAgICA+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC00IHB4LTVcIj5cbiAgICAgICAgPGgyIGlkPVwiZmVhdHVyZWQtdGl0bGVcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC0yeGwgZm9udC1ib2xkIGxlYWRpbmctOCB0ZXh0LWFjY2VudFwiPlxuICAgICAgICAgIE5GVCBFTSBERVNUQVFVRVxuICAgICAgICA8L2gyPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgdGV4dC1bMjJweF0gZm9udC1ib2xkIGxlYWRpbmctNCB0ZXh0LWZvcmVncm91bmRcIj5PRkVSVEEgTElNSVRBREE8L3A+XG4gICAgICA8L2Rpdj5cbiAgICAgIHtmZWF0dXJlZC5pc0Vycm9yID8gKFxuICAgICAgICA8RXJyb3JTdGF0ZSBjb21wYWN0IGVycm9yPXtmZWF0dXJlZC5lcnJvcn0gb25SZXRyeT17KCkgPT4gdm9pZCBmZWF0dXJlZC5yZWZldGNoKCl9IHJldHJ5aW5nPXtmZWF0dXJlZC5pc0ZldGNoaW5nfSAvPlxuICAgICAgKSA6IG5mdCA/IChcbiAgICAgICAgPExpbmsgdG89XCIvbmZ0LyRuZnRJZFwiIHBhcmFtcz17eyBuZnRJZDogbmZ0LmlkIH19IGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlIGJsb2NrIGgtWzM2OHB4XSB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtWzIycHhdXCI+XG4gICAgICAgICAgPGltZ1xuICAgICAgICAgICAgc3JjPXtuZnQuaW1hZ2UucmVwbGFjZSgnLXNtLndlYnAnLCAnLndlYnAnKX1cbiAgICAgICAgICAgIGFsdD17YCR7bmZ0Lm5hbWV9IOKAlCB2ZXIgb2ZlcnRhYH1cbiAgICAgICAgICAgIGxvYWRpbmc9XCJsYXp5XCJcbiAgICAgICAgICAgIHdpZHRoPXszMTB9XG4gICAgICAgICAgICBoZWlnaHQ9ezM2OH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInNpemUtZnVsbCBvYmplY3QtY292ZXIgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwIGdyb3VwLWhvdmVyOnNjYWxlLVsxLjAyXVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgKSA6IChcbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtWzM2OHB4XSB3LWZ1bGwgcm91bmRlZC1bMjJweF0gYmctc3VyZmFjZS1yYWlzZWRcIiAvPlxuICAgICAgKX1cbiAgICAgIDxzcGFuIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtNCB0b3AtWzI5OXB4XSBzaXplLVsyMnB4XSByb3VuZGVkLVs3cHhdIGJvcmRlci0yIGJvcmRlci1bIzQ2YTM1OF0gb3BhY2l0eS0yMFwiIC8+XG4gICAgICA8c3BhblxuICAgICAgICBhcmlhLWhpZGRlblxuICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LVsyNDhweF0gdG9wLVszNDNweF0gc2l6ZS1bNDVweF0gcm91bmRlZC1bMjlweF0gYmctW2xpbmVhci1ncmFkaWVudCgxNDUuNWRlZyxyZ2JhKDIxMCwxMzgsNzYsMC4zKV80NiUscmdiYSgyMTAsMTM4LDc2LDApXzEwMyUpXVwiXG4gICAgICAvPlxuICAgICAgPHNwYW5cbiAgICAgICAgYXJpYS1oaWRkZW5cbiAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC1bMzhweF0gdG9wLVsxMDVweF0gc2l6ZS1bMTVweF0gcm91bmRlZC1bMjlweF0gYmctW2xpbmVhci1ncmFkaWVudCgxNDUuNWRlZyxyZ2JhKDIxMCwxMzgsNzYsMC4zKV80NiUscmdiYSgyMTAsMTM4LDc2LDApXzEwMyUpXVwiXG4gICAgICAvPlxuICAgIDwvc2VjdGlvbj5cbiAgKVxufVxuXG5jb25zdCB0YWJzOiB7IGtleTogQ2F0YWxvZ1RhYjsgbGFiZWw6IHN0cmluZyB9W10gPSBbXG4gIHsga2V5OiAnYWxsJywgbGFiZWw6ICdUb2RvcyBvcyBORlRzJyB9LFxuICB7IGtleTogJ25ldycsIGxhYmVsOiAnTm92b3MgbGFuw6dhbWVudG9zJyB9LFxuICB7IGtleTogJ3RyZW5kaW5nJywgbGFiZWw6ICdFbSBhbHRhJyB9LFxuXVxuXG5leHBvcnQgZnVuY3Rpb24gQ2F0YWxvZ1RhYnMoeyBhY3RpdmUgfTogeyBhY3RpdmU6IENhdGFsb2dUYWIgfSkge1xuICByZXR1cm4gKFxuICAgIDxuYXYgYXJpYS1sYWJlbD1cIlNlw6fDtWVzIGRvIGNhdMOhbG9nb1wiPlxuICAgICAgPHVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTQgdGV4dC1zbSBsZWFkaW5nLTQgbWQ6Z2FwLTUgbWQ6dGV4dC1bMTVweF0gbWQ6Zm9udC1tZWRpdW1cIj5cbiAgICAgICAge3RhYnMubWFwKCh0KSA9PiB7XG4gICAgICAgICAgY29uc3QgaXNBY3RpdmUgPSB0LmtleSA9PT0gYWN0aXZlXG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxsaSBrZXk9e3Qua2V5fT5cbiAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICB0bz1cIi9cIlxuICAgICAgICAgICAgICAgIHNlYXJjaD17KHByZXY6IEhvbWVTZWFyY2gpID0+ICh7IC4uLnByZXYsIHRhYjogdC5rZXkgPT09ICdhbGwnID8gdW5kZWZpbmVkIDogdC5rZXksIHBhZ2U6IHVuZGVmaW5lZCB9KX1cbiAgICAgICAgICAgICAgICByZXBsYWNlXG4gICAgICAgICAgICAgICAgcmVzZXRTY3JvbGw9e2ZhbHNlfVxuICAgICAgICAgICAgICAgIGFyaWEtY3VycmVudD17aXNBY3RpdmUgPyAncGFnZScgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICdmbGV4IGZsZXgtY29sIGdhcC0xIHdoaXRlc3BhY2Utbm93cmFwIG1kOmdhcC1bN3B4XScsXG4gICAgICAgICAgICAgICAgICBpc0FjdGl2ZSA/ICdmb250LWJvbGQgdGV4dC1hY2NlbnQgbWQ6Zm9udC1tZWRpdW0nIDogJ3RleHQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWFjY2VudCcsXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt0LmxhYmVsfVxuICAgICAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT17Y24oJ2gtMC41IHctZnVsbCcsIGlzQWN0aXZlID8gJ2JnLXByaW1hcnknIDogJ2JnLXRyYW5zcGFyZW50Jyl9IC8+XG4gICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgKVxuICAgICAgICB9KX1cbiAgICAgIDwvdWw+XG4gICAgPC9uYXY+XG4gIClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFNvcnRTZWxlY3QoeyB2YWx1ZSwgb25DaGFuZ2UgfTogeyB2YWx1ZTogU29ydE9wdGlvbjsgb25DaGFuZ2U6ICh2OiBTb3J0T3B0aW9uKSA9PiB2b2lkIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzE1cHhdIGxlYWRpbmctbm9ybWFsIHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgPGxhYmVsIGh0bWxGb3I9XCJmLXNvcnRcIiBjbGFzc05hbWU9XCJ3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICBPcmRlbmFyIHBvcjpcbiAgICAgIDwvbGFiZWw+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgIDxzZWxlY3RcbiAgICAgICAgICBpZD1cImYtc29ydFwiXG4gICAgICAgICAgdmFsdWU9e3ZhbHVlfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2UoZS50YXJnZXQudmFsdWUgYXMgU29ydE9wdGlvbil9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXIgYXBwZWFyYW5jZS1ub25lIGJnLXRyYW5zcGFyZW50IHByLTYgdGV4dC1bMTVweF0gdGV4dC1mb3JlZ3JvdW5kIG91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnVuZGVybGluZVwiXG4gICAgICAgID5cbiAgICAgICAgICB7c29ydE9wdGlvbnMubWFwKChzKSA9PiAoXG4gICAgICAgICAgICA8b3B0aW9uIGtleT17c30gdmFsdWU9e3N9IGNsYXNzTmFtZT1cImJnLWNhcmRcIj5cbiAgICAgICAgICAgICAge3NvcnRMYWJlbHNbc119XG4gICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgIDxGaWdtYUljb24gbmFtZT1cImljb24tY2hldnJvbi1kb3duXCIgd2lkdGg9ezl9IGhlaWdodD17NX0gY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSByaWdodC0xIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWZvcmVncm91bmRcIiAvPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuLyoqIFBhZ2luYcOnw6NvIG51bWVyYWRhICgzNcOXMzUsIHDDoWdpbmEgYXR1YWwgcHJlZW5jaGlkYSkuICovXG5leHBvcnQgZnVuY3Rpb24gUGFnaW5hdGlvbih7IHBhZ2UsIHRvdGFsUGFnZXMgfTogeyBwYWdlOiBudW1iZXI7IHRvdGFsUGFnZXM6IG51bWJlciB9KSB7XG4gIGNvbnN0IHBhZ2VzID0gcGFnZVdpbmRvdyhwYWdlLCB0b3RhbFBhZ2VzKVxuICBjb25zdCBib3ggPSAnZ3JpZCBzaXplLVszNXB4XSBwbGFjZS1pdGVtcy1jZW50ZXIgcm91bmRlZC1bNHB4XSB0ZXh0LWxnIGxlYWRpbmctNCdcbiAgcmV0dXJuIChcbiAgICA8bmF2IGFyaWEtbGFiZWw9XCJQYWdpbmHDp8Ojb1wiIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCIgZGF0YS10ZXN0aWQ9XCJwYWdlLWluZGljYXRvclwiPlxuICAgICAgICBQw6FnaW5hIHtwYWdlfSBkZSB7dG90YWxQYWdlc31cbiAgICAgIDwvc3Bhbj5cbiAgICAgIHtwYWdlID4gMSA/IChcbiAgICAgICAgPExpbmtcbiAgICAgICAgICB0bz1cIi9cIlxuICAgICAgICAgIHNlYXJjaD17KHByZXY6IEhvbWVTZWFyY2gpID0+ICh7IC4uLnByZXYsIHBhZ2U6IHBhZ2UgLSAxIDw9IDEgPyB1bmRlZmluZWQgOiBwYWdlIC0gMSB9KX1cbiAgICAgICAgICBhcmlhLWxhYmVsPVwiUMOhZ2luYSBhbnRlcmlvclwiXG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihib3gsICdib3JkZXIgYm9yZGVyLWJvcmRlciB0ZXh0LWZvcmVncm91bmQgaG92ZXI6Ym9yZGVyLXByaW1hcnknKX1cbiAgICAgICAgPlxuICAgICAgICAgIDxGaWdtYUljb24gbmFtZT1cImljb24tY2hldnJvbi1yaWdodFwiIHdpZHRoPXsxMn0gaGVpZ2h0PXs3fSBjbGFzc05hbWU9XCJyb3RhdGUtOTBcIiAvPlxuICAgICAgICA8L0xpbms+XG4gICAgICApIDogbnVsbH1cbiAgICAgIHtwYWdlcy5tYXAoKHAsIGkpID0+XG4gICAgICAgIHAgPT09ICdnYXAnID8gKFxuICAgICAgICAgIDxzcGFuIGtleT17YGdhcC0ke2l9YH0gYXJpYS1oaWRkZW4gY2xhc3NOYW1lPVwicHgtMSB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgIOKAplxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8TGlua1xuICAgICAgICAgICAga2V5PXtwfVxuICAgICAgICAgICAgdG89XCIvXCJcbiAgICAgICAgICAgIHNlYXJjaD17KHByZXY6IEhvbWVTZWFyY2gpID0+ICh7IC4uLnByZXYsIHBhZ2U6IHAgPT09IDEgPyB1bmRlZmluZWQgOiBwIH0pfVxuICAgICAgICAgICAgYXJpYS1sYWJlbD17YFDDoWdpbmEgJHtwfWB9XG4gICAgICAgICAgICBhcmlhLWN1cnJlbnQ9e3AgPT09IHBhZ2UgPyAncGFnZScgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICBib3gsXG4gICAgICAgICAgICAgIHAgPT09IHBhZ2UgPyAnYmctcHJpbWFyeSBmb250LWJvbGQgdGV4dC1wcmltYXJ5LWZvcmVncm91bmQnIDogJ2JvcmRlciBib3JkZXItYm9yZGVyIHRleHQtZm9yZWdyb3VuZCBob3Zlcjpib3JkZXItcHJpbWFyeScsXG4gICAgICAgICAgICApfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtwfVxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgKSxcbiAgICAgICl9XG4gICAgICB7cGFnZSA8IHRvdGFsUGFnZXMgPyAoXG4gICAgICAgIDxMaW5rXG4gICAgICAgICAgdG89XCIvXCJcbiAgICAgICAgICBzZWFyY2g9eyhwcmV2OiBIb21lU2VhcmNoKSA9PiAoeyAuLi5wcmV2LCBwYWdlOiBwYWdlICsgMSB9KX1cbiAgICAgICAgICBhcmlhLWxhYmVsPVwiUHLDs3hpbWEgcMOhZ2luYVwiXG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihib3gsICdib3JkZXIgYm9yZGVyLWJvcmRlciB0ZXh0LWZvcmVncm91bmQgaG92ZXI6Ym9yZGVyLXByaW1hcnknKX1cbiAgICAgICAgPlxuICAgICAgICAgIDxGaWdtYUljb24gbmFtZT1cImljb24tY2hldnJvbi1yaWdodFwiIHdpZHRoPXsxMn0gaGVpZ2h0PXs3fSBjbGFzc05hbWU9XCItcm90YXRlLTkwXCIgLz5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9uYXY+XG4gIClcbn1cblxuZnVuY3Rpb24gcGFnZVdpbmRvdyhwYWdlOiBudW1iZXIsIHRvdGFsOiBudW1iZXIpOiAobnVtYmVyIHwgJ2dhcCcpW10ge1xuICBpZiAodG90YWwgPD0gNSkgcmV0dXJuIEFycmF5LmZyb20oeyBsZW5ndGg6IHRvdGFsIH0sIChfLCBpKSA9PiBpICsgMSlcbiAgY29uc3Qgc3RhcnQgPSBNYXRoLm1heCgxLCBNYXRoLm1pbihwYWdlIC0gMSwgdG90YWwgLSAzKSlcbiAgY29uc3Qgb3V0OiAobnVtYmVyIHwgJ2dhcCcpW10gPSBbXVxuICBpZiAoc3RhcnQgPiAxKSBvdXQucHVzaCgxLCAnZ2FwJylcbiAgZm9yIChsZXQgcCA9IHN0YXJ0OyBwIDw9IE1hdGgubWluKHRvdGFsLCBzdGFydCArIDMpOyBwKyspIG91dC5wdXNoKHApXG4gIGlmIChzdGFydCArIDMgPCB0b3RhbCkgb3V0LnB1c2goJ2dhcCcsIHRvdGFsKVxuICByZXR1cm4gb3V0XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBDYXRhbG9nR3JpZFNrZWxldG9uKHsgY291bnQgPSA5IH06IHsgY291bnQ/OiBudW1iZXIgfSkge1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogY291bnQgfSwgKF8sIGkpID0+IChcbiAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtWzIwcHhdIGJnLWNhcmQgcHgtMSBwYi01IHB0LTMgbWQ6cm91bmRlZC1ub25lIG1kOnBiLVsyNnB4XSBtZDpwdC02XCI+XG4gICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiYXNwZWN0LXNxdWFyZSB3LWZ1bGwgcm91bmRlZC0yeGwgYmctc3VyZmFjZS1yYWlzZWQgbWQ6cm91bmRlZC1bMTVweF1cIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy0zLzQgYmctY2FyZFwiIC8+XG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LTEvMyBiZy1jYXJkXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICApKX1cbiAgICA8Lz5cbiAgKVxufVxuIl19