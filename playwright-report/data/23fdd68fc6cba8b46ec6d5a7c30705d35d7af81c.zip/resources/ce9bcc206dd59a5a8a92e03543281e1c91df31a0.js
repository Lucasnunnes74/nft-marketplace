import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/header.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import { Link, useLocation, useNavigate, useRouterState } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { useSessionState } from "/src/auth/use-session.ts";
import { FigmaIcon } from "/src/components/ui/figma-icon.tsx";
import { useCart, useCurrentUser } from "/src/hooks/use-api.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/header.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
/** Telas do fluxo de compra destacam "Mercado"; as demais, "Início" (regra do componente Header Row). */
const marketPaths = [
	"/nft/",
	"/cart",
	"/checkout",
	"/orders/"
];
export function useActiveSection() {
	_s();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return marketPaths.some((p) => pathname.startsWith(p)) ? "market" : "home";
}
_s(useActiveSection, "eg6hVyoc2mOhGYADidkjZn32mkc=", false, function() {
	return [useRouterState];
});
const navItems = [
	{
		key: "home",
		label: "Início",
		hash: undefined
	},
	{
		key: "market",
		label: "Mercado",
		hash: "catalogo"
	},
	{
		key: "creators",
		label: "Criadores",
		hash: "destaques"
	},
	{
		key: "learn",
		label: "Aprenda",
		hash: "diario"
	}
];
export function useCartCount() {
	_s2();
	const cart = useCart();
	return cart.data?.items.reduce((n, i) => n + i.quantity, 0) ?? 0;
}
_s2(useCartCount, "kj6vYOuuZe117C9BX73N0wcQ3Yk=", false, function() {
	return [useCart];
});
export function Header() {
	_s3();
	const active = useActiveSection();
	const count = useCartCount();
	const { isAuthenticated } = useSessionState();
	const user = useCurrentUser();
	// Telas de mercado usam o Header Row sem o divisor (descrição do componente no Figma).
	const withDivider = active === "home";
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "pt-6",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-start justify-between",
			children: [
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					search: {},
					className: "block h-[34px] w-40 pt-2 text-sm font-bold leading-normal tracking-[1.4px] text-foreground",
					children: "KURIO"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("nav", {
					"aria-label": "Principal",
					children: /* @__PURE__ */ _jsxDEV("ul", {
						className: "flex items-start gap-10",
						children: navItems.map((item) => {
							const isActive = item.key === active;
							return /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
								to: "/",
								hash: item.hash,
								search: item.key === "home" ? {} : undefined,
								"aria-current": isActive ? "page" : undefined,
								className: "group flex flex-col gap-6 text-base leading-normal",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: isActive ? "font-bold text-accent" : "text-foreground group-hover:text-accent",
									children: item.label
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 56,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									"aria-hidden": true,
									className: cn("h-[3px] w-full", isActive ? "bg-primary" : "bg-transparent")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 57,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 19
							}, this) }, item.key, false, {
								fileName: _jsxFileName,
								lineNumber: 48,
								columnNumber: 17
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-7",
					children: [
						/* @__PURE__ */ _jsxDEV(HeaderSearch, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/cart",
							"aria-label": count ? `Carrinho, ${count} ${count === 1 ? "item" : "itens"}` : "Carrinho",
							className: "relative grid h-6 w-[31px] text-foreground hover:text-accent",
							children: [/* @__PURE__ */ _jsxDEV(FigmaIcon, {
								name: "icon-cart",
								width: 24
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 13
							}, this), count > 0 ? /* @__PURE__ */ _jsxDEV("span", {
								"data-testid": "cart-count",
								"aria-hidden": true,
								className: "absolute left-[15px] top-0 grid size-4 place-items-center rounded-full border-2 border-background bg-primary text-[10px] font-medium leading-none text-primary-foreground",
								children: count > 99 ? "99+" : count
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 15
							}, this) : null]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 11
						}, this),
						isAuthenticated ? /* @__PURE__ */ _jsxDEV(Link, {
							to: "/profile",
							"aria-label": "Meu perfil",
							className: "flex h-[35px] min-w-[100px] max-w-44 items-center justify-center gap-1 rounded-[6px] bg-primary px-3 text-base font-medium text-primary-foreground hover:brightness-110",
							children: [/* @__PURE__ */ _jsxDEV(FigmaIcon, {
								name: "acc-user",
								width: 18
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "truncate",
								children: user.data?.user.name.split(" ")[0] ?? "Perfil"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 13
						}, this) : /* @__PURE__ */ _jsxDEV(Link, {
							to: "/login",
							search: {},
							className: "flex h-[35px] w-[100px] items-center justify-center gap-1 rounded-[6px] bg-primary text-base font-medium text-primary-foreground hover:brightness-110",
							children: [/* @__PURE__ */ _jsxDEV(FigmaIcon, {
								name: "icon-login",
								width: 20,
								height: 19
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 15
							}, this), "Entrar"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 7
		}, this), withDivider ? /* @__PURE__ */ _jsxDEV("div", { className: "k-hairline -mt-px" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 104,
			columnNumber: 22
		}, this) : null]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 5
	}, this);
}
_s3(Header, "9bsGBp82DvCaU8mjp/HHtkODc0g=", false, function() {
	return [
		useActiveSection,
		useCartCount,
		useSessionState,
		useCurrentUser
	];
});
_c = Header;
/** Busca do cabeçalho: abre um campo que escreve `q` na URL do catálogo. */
function HeaderSearch() {
	_s4();
	const navigate = useNavigate();
	const location = useLocation();
	const onHome = location.pathname === "/";
	const urlQ = onHome ? location.search.q ?? "" : "";
	const [open, setOpen] = useState(Boolean(urlQ));
	const [value, setValue] = useState(urlQ);
	const inputRef = useRef(null);
	const timer = useRef(undefined);
	useEffect(() => setValue(urlQ), [urlQ]);
	useEffect(() => () => clearTimeout(timer.current), []);
	function commit(next, scroll) {
		clearTimeout(timer.current);
		void navigate({
			to: "/",
			search: (prev) => ({
				...onHome ? prev : {},
				q: next.trim() || undefined,
				page: undefined
			}),
			replace: onHome,
			resetScroll: false
		}).then(() => {
			if (scroll) document.getElementById("catalogo")?.scrollIntoView({
				behavior: "smooth",
				block: "start"
			});
		});
	}
	return /* @__PURE__ */ _jsxDEV("form", {
		role: "search",
		className: "flex items-center gap-2",
		onSubmit: (e) => {
			e.preventDefault();
			commit(value, true);
		},
		children: [open ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("label", {
			htmlFor: "header-search",
			className: "sr-only",
			children: "Buscar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 146,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("input", {
			id: "header-search",
			ref: inputRef,
			type: "search",
			autoComplete: "off",
			placeholder: "Buscar NFTs, coleções…",
			value,
			onChange: (e) => {
				const next = e.target.value;
				setValue(next);
				// No catálogo os resultados acompanham a digitação; fora dele, a busca vai no Enter.
				if (onHome) {
					clearTimeout(timer.current);
					timer.current = setTimeout(() => commit(next, false), 350);
				}
			},
			onKeyDown: (e) => {
				if (e.key === "Escape") {
					setOpen(false);
				}
			},
			className: "h-8 w-56 rounded-[6px] border border-border bg-card px-3 text-sm text-foreground outline-none focus-visible:border-primary"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 149,
			columnNumber: 11
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 145,
			columnNumber: 9
		}, this) : null, /* @__PURE__ */ _jsxDEV("button", {
			type: open ? "submit" : "button",
			"aria-label": open ? "Pesquisar" : "Abrir busca",
			"aria-expanded": open,
			className: "grid size-6 place-items-center text-foreground hover:text-accent",
			onClick: (e) => {
				if (!open) {
					e.preventDefault();
					setOpen(true);
					requestAnimationFrame(() => inputRef.current?.focus());
				}
			},
			children: /* @__PURE__ */ _jsxDEV(FigmaIcon, {
				name: "icon-search",
				width: 20
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 187,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 174,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 136,
		columnNumber: 5
	}, this);
}
_s4(HeaderSearch, "OKYLco4g7ALC776G6lV7CViAm/c=", false, function() {
	return [useNavigate, useLocation];
});
_c2 = HeaderSearch;
var _c, _c2;
$RefreshReg$(_c, "Header");
$RefreshReg$(_c2, "HeaderSearch");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/header.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/header.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLGFBQWEsYUFBYSxzQkFBc0I7QUFDL0QsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBQzVDLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsU0FBUyxzQkFBc0I7QUFDeEMsU0FBUyxVQUFVOzs7OztBQUduQixNQUFNLGNBQWM7Q0FBQztDQUFTO0NBQVM7Q0FBYTtBQUFVO0FBRTlELE9BQU8sU0FBUyxtQkFBc0M7O0NBQ3BELE1BQU0sV0FBVyxlQUFlLEVBQUUsU0FBUyxNQUFNLEVBQUUsU0FBUyxTQUFTLENBQUM7Q0FDdEUsT0FBTyxZQUFZLE1BQU0sTUFBTSxTQUFTLFdBQVcsQ0FBQyxDQUFDLElBQUksV0FBVztBQUN0RTs7OztBQUVBLE1BQU0sV0FBVztDQUNmO0VBQUUsS0FBSztFQUFRLE9BQU87RUFBVSxNQUFNO0NBQVU7Q0FDaEQ7RUFBRSxLQUFLO0VBQVUsT0FBTztFQUFXLE1BQU07Q0FBVztDQUNwRDtFQUFFLEtBQUs7RUFBWSxPQUFPO0VBQWEsTUFBTTtDQUFZO0NBQ3pEO0VBQUUsS0FBSztFQUFTLE9BQU87RUFBVyxNQUFNO0NBQVM7QUFDbkQ7QUFFQSxPQUFPLFNBQVMsZUFBZTs7Q0FDN0IsTUFBTSxPQUFPLFFBQVE7Q0FDckIsT0FBTyxLQUFLLE1BQU0sTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLEVBQUUsVUFBVSxDQUFDLEtBQUs7QUFDakU7Ozs7QUFFQSxPQUFPLFNBQVMsU0FBUzs7Q0FDdkIsTUFBTSxTQUFTLGlCQUFpQjtDQUNoQyxNQUFNLFFBQVEsYUFBYTtDQUMzQixNQUFNLEVBQUUsb0JBQW9CLGdCQUFnQjtDQUM1QyxNQUFNLE9BQU8sZUFBZTs7Q0FFNUIsTUFBTSxjQUFjLFdBQVc7Q0FFL0IsT0FDRSx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUFsQixDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxNQUFEO0tBQU0sSUFBRztLQUFJLFFBQVEsQ0FBQztLQUFHLFdBQVU7ZUFBNkY7SUFFMUg7Ozs7O0lBRU4sd0JBQUMsT0FBRDtLQUFLLGNBQVc7ZUFDZCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFDWCxTQUFTLEtBQUssU0FBUztPQUN0QixNQUFNLFdBQVcsS0FBSyxRQUFRO09BQzlCLE9BQ0Usd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7UUFDRSxJQUFHO1FBQ0gsTUFBTSxLQUFLO1FBQ1gsUUFBUSxLQUFLLFFBQVEsU0FBUyxDQUFDLElBQUk7UUFDbkMsZ0JBQWMsV0FBVyxTQUFTO1FBQ2xDLFdBQVU7a0JBTFosQ0FPRSx3QkFBQyxRQUFEO1NBQU0sV0FBVyxXQUFXLDBCQUEwQjttQkFBNEMsS0FBSztRQUFZOzs7O2tCQUNuSCx3QkFBQyxRQUFEO1NBQU07U0FBWSxXQUFXLEdBQUcsa0JBQWtCLFdBQVcsZUFBZSxnQkFBZ0I7UUFBSTs7OztnQkFDNUY7Ozs7O2dCQUNKLEdBWEssS0FBSzs7OztjQVdWO01BRVIsQ0FBQztLQUNDOzs7OztJQUNEOzs7OztJQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxjQUFELENBQWU7Ozs7O01BQ2Ysd0JBQUMsTUFBRDtPQUNFLElBQUc7T0FDSCxjQUFZLFFBQVEsYUFBYSxNQUFNLEdBQUcsVUFBVSxJQUFJLFNBQVMsWUFBWTtPQUM3RSxXQUFVO2lCQUhaLENBS0Usd0JBQUMsV0FBRDtRQUFXLE1BQUs7UUFBWSxPQUFPO09BQUs7Ozs7aUJBQ3ZDLFFBQVEsSUFDUCx3QkFBQyxRQUFEO1FBQ0UsZUFBWTtRQUNaO1FBQ0EsV0FBVTtrQkFFVCxRQUFRLEtBQUssUUFBUTtPQUNsQjs7OztrQkFDSixJQUNBOzs7Ozs7TUFDTCxrQkFDQyx3QkFBQyxNQUFEO09BQ0UsSUFBRztPQUNILGNBQVc7T0FDWCxXQUFVO2lCQUhaLENBS0Usd0JBQUMsV0FBRDtRQUFXLE1BQUs7UUFBVyxPQUFPO09BQUs7Ozs7aUJBQ3ZDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFZLEtBQUssTUFBTSxLQUFLLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNO09BQWU7Ozs7ZUFDN0U7Ozs7O2lCQUVOLHdCQUFDLE1BQUQ7T0FDRSxJQUFHO09BQ0gsUUFBUSxDQUFDO09BQ1QsV0FBVTtpQkFIWixDQUtFLHdCQUFDLFdBQUQ7UUFBVyxNQUFLO1FBQWEsT0FBTztRQUFJLFFBQVE7T0FBSzs7OztpQkFBQyxRQUVsRDs7Ozs7O0tBRUw7Ozs7OztHQUNGOzs7OztZQUNKLGNBQWMsd0JBQUMsT0FBRCxFQUFLLFdBQVUsb0JBQXFCOzs7O2FBQUksSUFDakQ7Ozs7OztBQUVaOzs7Ozs7Ozs7OztBQUdBLFNBQVMsZUFBZTs7Q0FDdEIsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxTQUFTLFNBQVMsYUFBYTtDQUNyQyxNQUFNLE9BQU8sU0FBVyxTQUFTLE9BQTBCLEtBQUssS0FBTTtDQUN0RSxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsUUFBUSxJQUFJLENBQUM7Q0FDOUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FDdkMsTUFBTSxXQUFXLE9BQXlCLElBQUk7Q0FDOUMsTUFBTSxRQUFRLE9BQWtELFNBQVM7Q0FFekUsZ0JBQWdCLFNBQVMsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDO0NBQ3RDLHNCQUFzQixhQUFhLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQztDQUVyRCxTQUFTLE9BQU8sTUFBYyxRQUFpQjtFQUM3QyxhQUFhLE1BQU0sT0FBTztFQUMxQixLQUFLLFNBQVM7R0FDWixJQUFJO0dBQ0osU0FBUyxVQUFVO0lBQUUsR0FBSSxTQUFTLE9BQU8sQ0FBQztJQUFJLEdBQUcsS0FBSyxLQUFLLEtBQUs7SUFBVyxNQUFNO0dBQVU7R0FDM0YsU0FBUztHQUNULGFBQWE7RUFDZixDQUFDLENBQUMsQ0FBQyxXQUFXO0dBQ1osSUFBSSxRQUFRLFNBQVMsZUFBZSxVQUFVLENBQUMsRUFBRSxlQUFlO0lBQUUsVUFBVTtJQUFVLE9BQU87R0FBUSxDQUFDO0VBQ3hHLENBQUM7Q0FDSDtDQUVBLE9BQ0Usd0JBQUMsUUFBRDtFQUNFLE1BQUs7RUFDTCxXQUFVO0VBQ1YsV0FBVyxNQUFNO0dBQ2YsRUFBRSxlQUFlO0dBQ2pCLE9BQU8sT0FBTyxJQUFJO0VBQ3BCO1lBTkYsQ0FRRyxPQUNDLGdEQUNFLHdCQUFDLFNBQUQ7R0FBTyxTQUFRO0dBQWdCLFdBQVU7YUFBVTtFQUU1Qzs7OztZQUNQLHdCQUFDLFNBQUQ7R0FDRSxJQUFHO0dBQ0gsS0FBSztHQUNMLE1BQUs7R0FDTCxjQUFhO0dBQ2IsYUFBWTtHQUNMO0dBQ1AsV0FBVyxNQUFNO0lBQ2YsTUFBTSxPQUFPLEVBQUUsT0FBTztJQUN0QixTQUFTLElBQUk7O0lBRWIsSUFBSSxRQUFRO0tBQ1YsYUFBYSxNQUFNLE9BQU87S0FDMUIsTUFBTSxVQUFVLGlCQUFpQixPQUFPLE1BQU0sS0FBSyxHQUFHLEdBQUc7SUFDM0Q7R0FDRjtHQUNBLFlBQVksTUFBTTtJQUNoQixJQUFJLEVBQUUsUUFBUSxVQUFVO0tBQ3RCLFFBQVEsS0FBSztJQUNmO0dBQ0Y7R0FDQSxXQUFVO0VBQ1g7Ozs7VUFDRDs7OzthQUNBLE1BQ0osd0JBQUMsVUFBRDtHQUNFLE1BQU0sT0FBTyxXQUFXO0dBQ3hCLGNBQVksT0FBTyxjQUFjO0dBQ2pDLGlCQUFlO0dBQ2YsV0FBVTtHQUNWLFVBQVUsTUFBTTtJQUNkLElBQUksQ0FBQyxNQUFNO0tBQ1QsRUFBRSxlQUFlO0tBQ2pCLFFBQVEsSUFBSTtLQUNaLDRCQUE0QixTQUFTLFNBQVMsTUFBTSxDQUFDO0lBQ3ZEO0dBQ0Y7YUFFQSx3QkFBQyxXQUFEO0lBQVcsTUFBSztJQUFjLE9BQU87R0FBSzs7Ozs7RUFDcEM7Ozs7VUFDSjs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaGVhZGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rLCB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUsIHVzZVJvdXRlclN0YXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlU2Vzc2lvblN0YXRlIH0gZnJvbSAnQC9hdXRoL3VzZS1zZXNzaW9uJ1xuaW1wb3J0IHsgRmlnbWFJY29uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2ZpZ21hLWljb24nXG5pbXBvcnQgeyB1c2VDYXJ0LCB1c2VDdXJyZW50VXNlciB9IGZyb20gJ0AvaG9va3MvdXNlLWFwaSdcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnXG5cbi8qKiBUZWxhcyBkbyBmbHV4byBkZSBjb21wcmEgZGVzdGFjYW0gXCJNZXJjYWRvXCI7IGFzIGRlbWFpcywgXCJJbsOtY2lvXCIgKHJlZ3JhIGRvIGNvbXBvbmVudGUgSGVhZGVyIFJvdykuICovXG5jb25zdCBtYXJrZXRQYXRocyA9IFsnL25mdC8nLCAnL2NhcnQnLCAnL2NoZWNrb3V0JywgJy9vcmRlcnMvJ11cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUFjdGl2ZVNlY3Rpb24oKTogJ2hvbWUnIHwgJ21hcmtldCcge1xuICBjb25zdCBwYXRobmFtZSA9IHVzZVJvdXRlclN0YXRlKHsgc2VsZWN0OiAocykgPT4gcy5sb2NhdGlvbi5wYXRobmFtZSB9KVxuICByZXR1cm4gbWFya2V0UGF0aHMuc29tZSgocCkgPT4gcGF0aG5hbWUuc3RhcnRzV2l0aChwKSkgPyAnbWFya2V0JyA6ICdob21lJ1xufVxuXG5jb25zdCBuYXZJdGVtcyA9IFtcbiAgeyBrZXk6ICdob21lJywgbGFiZWw6ICdJbsOtY2lvJywgaGFzaDogdW5kZWZpbmVkIH0sXG4gIHsga2V5OiAnbWFya2V0JywgbGFiZWw6ICdNZXJjYWRvJywgaGFzaDogJ2NhdGFsb2dvJyB9LFxuICB7IGtleTogJ2NyZWF0b3JzJywgbGFiZWw6ICdDcmlhZG9yZXMnLCBoYXNoOiAnZGVzdGFxdWVzJyB9LFxuICB7IGtleTogJ2xlYXJuJywgbGFiZWw6ICdBcHJlbmRhJywgaGFzaDogJ2RpYXJpbycgfSxcbl0gYXMgY29uc3RcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUNhcnRDb3VudCgpIHtcbiAgY29uc3QgY2FydCA9IHVzZUNhcnQoKVxuICByZXR1cm4gY2FydC5kYXRhPy5pdGVtcy5yZWR1Y2UoKG4sIGkpID0+IG4gKyBpLnF1YW50aXR5LCAwKSA/PyAwXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBIZWFkZXIoKSB7XG4gIGNvbnN0IGFjdGl2ZSA9IHVzZUFjdGl2ZVNlY3Rpb24oKVxuICBjb25zdCBjb3VudCA9IHVzZUNhcnRDb3VudCgpXG4gIGNvbnN0IHsgaXNBdXRoZW50aWNhdGVkIH0gPSB1c2VTZXNzaW9uU3RhdGUoKVxuICBjb25zdCB1c2VyID0gdXNlQ3VycmVudFVzZXIoKVxuICAvLyBUZWxhcyBkZSBtZXJjYWRvIHVzYW0gbyBIZWFkZXIgUm93IHNlbSBvIGRpdmlzb3IgKGRlc2NyacOnw6NvIGRvIGNvbXBvbmVudGUgbm8gRmlnbWEpLlxuICBjb25zdCB3aXRoRGl2aWRlciA9IGFjdGl2ZSA9PT0gJ2hvbWUnXG5cbiAgcmV0dXJuIChcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInB0LTZcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgPExpbmsgdG89XCIvXCIgc2VhcmNoPXt7fX0gY2xhc3NOYW1lPVwiYmxvY2sgaC1bMzRweF0gdy00MCBwdC0yIHRleHQtc20gZm9udC1ib2xkIGxlYWRpbmctbm9ybWFsIHRyYWNraW5nLVsxLjRweF0gdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgS1VSSU9cbiAgICAgICAgPC9MaW5rPlxuXG4gICAgICAgIDxuYXYgYXJpYS1sYWJlbD1cIlByaW5jaXBhbFwiPlxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0xMFwiPlxuICAgICAgICAgICAge25hdkl0ZW1zLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGl0ZW0ua2V5ID09PSBhY3RpdmVcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8bGkga2V5PXtpdGVtLmtleX0+XG4gICAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgICB0bz1cIi9cIlxuICAgICAgICAgICAgICAgICAgICBoYXNoPXtpdGVtLmhhc2h9XG4gICAgICAgICAgICAgICAgICAgIHNlYXJjaD17aXRlbS5rZXkgPT09ICdob21lJyA/IHt9IDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgICAgICAgICBhcmlhLWN1cnJlbnQ9e2lzQWN0aXZlID8gJ3BhZ2UnIDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBmbGV4IGZsZXgtY29sIGdhcC02IHRleHQtYmFzZSBsZWFkaW5nLW5vcm1hbFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17aXNBY3RpdmUgPyAnZm9udC1ib2xkIHRleHQtYWNjZW50JyA6ICd0ZXh0LWZvcmVncm91bmQgZ3JvdXAtaG92ZXI6dGV4dC1hY2NlbnQnfT57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT17Y24oJ2gtWzNweF0gdy1mdWxsJywgaXNBY3RpdmUgPyAnYmctcHJpbWFyeScgOiAnYmctdHJhbnNwYXJlbnQnKX0gLz5cbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L3VsPlxuICAgICAgICA8L25hdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC03XCI+XG4gICAgICAgICAgPEhlYWRlclNlYXJjaCAvPlxuICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICB0bz1cIi9jYXJ0XCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e2NvdW50ID8gYENhcnJpbmhvLCAke2NvdW50fSAke2NvdW50ID09PSAxID8gJ2l0ZW0nIDogJ2l0ZW5zJ31gIDogJ0NhcnJpbmhvJ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGdyaWQgaC02IHctWzMxcHhdIHRleHQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWFjY2VudFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEZpZ21hSWNvbiBuYW1lPVwiaWNvbi1jYXJ0XCIgd2lkdGg9ezI0fSAvPlxuICAgICAgICAgICAge2NvdW50ID4gMCA/IChcbiAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImNhcnQtY291bnRcIlxuICAgICAgICAgICAgICAgIGFyaWEtaGlkZGVuXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC1bMTVweF0gdG9wLTAgZ3JpZCBzaXplLTQgcGxhY2UtaXRlbXMtY2VudGVyIHJvdW5kZWQtZnVsbCBib3JkZXItMiBib3JkZXItYmFja2dyb3VuZCBiZy1wcmltYXJ5IHRleHQtWzEwcHhdIGZvbnQtbWVkaXVtIGxlYWRpbmctbm9uZSB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7Y291bnQgPiA5OSA/ICc5OSsnIDogY291bnR9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICB7aXNBdXRoZW50aWNhdGVkID8gKFxuICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgdG89XCIvcHJvZmlsZVwiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJNZXUgcGVyZmlsXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLVszNXB4XSBtaW4tdy1bMTAwcHhdIG1heC13LTQ0IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSByb3VuZGVkLVs2cHhdIGJnLXByaW1hcnkgcHgtMyB0ZXh0LWJhc2UgZm9udC1tZWRpdW0gdGV4dC1wcmltYXJ5LWZvcmVncm91bmQgaG92ZXI6YnJpZ2h0bmVzcy0xMTBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8RmlnbWFJY29uIG5hbWU9XCJhY2MtdXNlclwiIHdpZHRoPXsxOH0gLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj57dXNlci5kYXRhPy51c2VyLm5hbWUuc3BsaXQoJyAnKVswXSA/PyAnUGVyZmlsJ308L3NwYW4+XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgIHRvPVwiL2xvZ2luXCJcbiAgICAgICAgICAgICAgc2VhcmNoPXt7fX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLVszNXB4XSB3LVsxMDBweF0gaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xIHJvdW5kZWQtWzZweF0gYmctcHJpbWFyeSB0ZXh0LWJhc2UgZm9udC1tZWRpdW0gdGV4dC1wcmltYXJ5LWZvcmVncm91bmQgaG92ZXI6YnJpZ2h0bmVzcy0xMTBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8RmlnbWFJY29uIG5hbWU9XCJpY29uLWxvZ2luXCIgd2lkdGg9ezIwfSBoZWlnaHQ9ezE5fSAvPlxuICAgICAgICAgICAgICBFbnRyYXJcbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAge3dpdGhEaXZpZGVyID8gPGRpdiBjbGFzc05hbWU9XCJrLWhhaXJsaW5lIC1tdC1weFwiIC8+IDogbnVsbH1cbiAgICA8L2hlYWRlcj5cbiAgKVxufVxuXG4vKiogQnVzY2EgZG8gY2FiZcOnYWxobzogYWJyZSB1bSBjYW1wbyBxdWUgZXNjcmV2ZSBgcWAgbmEgVVJMIGRvIGNhdMOhbG9nby4gKi9cbmZ1bmN0aW9uIEhlYWRlclNlYXJjaCgpIHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKVxuICBjb25zdCBvbkhvbWUgPSBsb2NhdGlvbi5wYXRobmFtZSA9PT0gJy8nXG4gIGNvbnN0IHVybFEgPSBvbkhvbWUgPyAoKGxvY2F0aW9uLnNlYXJjaCBhcyB7IHE/OiBzdHJpbmcgfSkucSA/PyAnJykgOiAnJ1xuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShCb29sZWFuKHVybFEpKVxuICBjb25zdCBbdmFsdWUsIHNldFZhbHVlXSA9IHVzZVN0YXRlKHVybFEpXG4gIGNvbnN0IGlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpXG4gIGNvbnN0IHRpbWVyID0gdXNlUmVmPFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgdW5kZWZpbmVkPih1bmRlZmluZWQpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHNldFZhbHVlKHVybFEpLCBbdXJsUV0pXG4gIHVzZUVmZmVjdCgoKSA9PiAoKSA9PiBjbGVhclRpbWVvdXQodGltZXIuY3VycmVudCksIFtdKVxuXG4gIGZ1bmN0aW9uIGNvbW1pdChuZXh0OiBzdHJpbmcsIHNjcm9sbDogYm9vbGVhbikge1xuICAgIGNsZWFyVGltZW91dCh0aW1lci5jdXJyZW50KVxuICAgIHZvaWQgbmF2aWdhdGUoe1xuICAgICAgdG86ICcvJyxcbiAgICAgIHNlYXJjaDogKHByZXYpID0+ICh7IC4uLihvbkhvbWUgPyBwcmV2IDoge30pLCBxOiBuZXh0LnRyaW0oKSB8fCB1bmRlZmluZWQsIHBhZ2U6IHVuZGVmaW5lZCB9KSxcbiAgICAgIHJlcGxhY2U6IG9uSG9tZSxcbiAgICAgIHJlc2V0U2Nyb2xsOiBmYWxzZSxcbiAgICB9KS50aGVuKCgpID0+IHtcbiAgICAgIGlmIChzY3JvbGwpIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdjYXRhbG9nbycpPy5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJywgYmxvY2s6ICdzdGFydCcgfSlcbiAgICB9KVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8Zm9ybVxuICAgICAgcm9sZT1cInNlYXJjaFwiXG4gICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiXG4gICAgICBvblN1Ym1pdD17KGUpID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIGNvbW1pdCh2YWx1ZSwgdHJ1ZSlcbiAgICAgIH19XG4gICAgPlxuICAgICAge29wZW4gPyAoXG4gICAgICAgIDw+XG4gICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJoZWFkZXItc2VhcmNoXCIgY2xhc3NOYW1lPVwic3Itb25seVwiPlxuICAgICAgICAgICAgQnVzY2FyXG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGlkPVwiaGVhZGVyLXNlYXJjaFwiXG4gICAgICAgICAgICByZWY9e2lucHV0UmVmfVxuICAgICAgICAgICAgdHlwZT1cInNlYXJjaFwiXG4gICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIgTkZUcywgY29sZcOnw7Vlc+KAplwiXG4gICAgICAgICAgICB2YWx1ZT17dmFsdWV9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgbmV4dCA9IGUudGFyZ2V0LnZhbHVlXG4gICAgICAgICAgICAgIHNldFZhbHVlKG5leHQpXG4gICAgICAgICAgICAgIC8vIE5vIGNhdMOhbG9nbyBvcyByZXN1bHRhZG9zIGFjb21wYW5oYW0gYSBkaWdpdGHDp8OjbzsgZm9yYSBkZWxlLCBhIGJ1c2NhIHZhaSBubyBFbnRlci5cbiAgICAgICAgICAgICAgaWYgKG9uSG9tZSkge1xuICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lci5jdXJyZW50KVxuICAgICAgICAgICAgICAgIHRpbWVyLmN1cnJlbnQgPSBzZXRUaW1lb3V0KCgpID0+IGNvbW1pdChuZXh0LCBmYWxzZSksIDM1MClcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IHtcbiAgICAgICAgICAgICAgaWYgKGUua2V5ID09PSAnRXNjYXBlJykge1xuICAgICAgICAgICAgICAgIHNldE9wZW4oZmFsc2UpXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggdy01NiByb3VuZGVkLVs2cHhdIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWNhcmQgcHgtMyB0ZXh0LXNtIHRleHQtZm9yZWdyb3VuZCBvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpib3JkZXItcHJpbWFyeVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC8+XG4gICAgICApIDogbnVsbH1cbiAgICAgIDxidXR0b25cbiAgICAgICAgdHlwZT17b3BlbiA/ICdzdWJtaXQnIDogJ2J1dHRvbid9XG4gICAgICAgIGFyaWEtbGFiZWw9e29wZW4gPyAnUGVzcXVpc2FyJyA6ICdBYnJpciBidXNjYSd9XG4gICAgICAgIGFyaWEtZXhwYW5kZWQ9e29wZW59XG4gICAgICAgIGNsYXNzTmFtZT1cImdyaWQgc2l6ZS02IHBsYWNlLWl0ZW1zLWNlbnRlciB0ZXh0LWZvcmVncm91bmQgaG92ZXI6dGV4dC1hY2NlbnRcIlxuICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICAgIGlmICghb3Blbikge1xuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgICAgICBzZXRPcGVuKHRydWUpXG4gICAgICAgICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gaW5wdXRSZWYuY3VycmVudD8uZm9jdXMoKSlcbiAgICAgICAgICB9XG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxGaWdtYUljb24gbmFtZT1cImljb24tc2VhcmNoXCIgd2lkdGg9ezIwfSAvPlxuICAgICAgPC9idXR0b24+XG4gICAgPC9mb3JtPlxuICApXG59XG4iXX0=