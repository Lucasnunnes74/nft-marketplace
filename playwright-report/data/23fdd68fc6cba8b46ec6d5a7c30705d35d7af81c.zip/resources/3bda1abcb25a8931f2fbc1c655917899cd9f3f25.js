import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/toaster.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { X } from "/node_modules/.vite/deps/lucide-react.js?v=b07c072a";
import { dismissToast, toastStore } from "/src/stores/toasts.ts";
import { Alert } from "/src/components/ui/alert.tsx";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/toaster.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$();
/** Região live: leitores de tela anunciam avisos sem roubar o foco. */
export function Toaster() {
	_s();
	const toasts = toastStore.use();
	return /* @__PURE__ */ _jsxDEV("div", {
		"aria-live": "polite",
		className: "pointer-events-none fixed bottom-4 right-4 z-[60] flex w-[min(24rem,calc(100vw-2rem))] flex-col gap-2",
		children: toasts.map((t) => /* @__PURE__ */ _jsxDEV("div", {
			className: "pointer-events-auto relative shadow-lg",
			children: [/* @__PURE__ */ _jsxDEV(Alert, {
				variant: t.variant,
				title: t.title,
				className: "bg-card pr-9",
				children: t.description
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				"aria-label": "Dispensar aviso",
				className: "absolute right-2 top-2 rounded p-1 opacity-70 hover:opacity-100",
				onClick: () => dismissToast(t.id),
				children: /* @__PURE__ */ _jsxDEV(X, { className: "size-4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 11
			}, this)]
		}, t.id, true, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 5
	}, this);
}
_s(Toaster, "5/gSX8ijYZko905viM9WdAE2UdE=", false, function() {
	return [toastStore.use];
});
_c = Toaster;
var _c;
$RefreshReg$(_c, "Toaster");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/toaster.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/toaster.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/toaster.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/toaster.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxTQUFTO0FBQ2xCLFNBQVMsY0FBYyxrQkFBa0I7QUFDekMsU0FBUyxhQUFhOzs7OztBQUd0QixPQUFPLFNBQVMsVUFBVTs7Q0FDeEIsTUFBTSxTQUFTLFdBQVcsSUFBSTtDQUM5QixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxhQUFVO0VBQVMsV0FBVTtZQUMvQixPQUFPLEtBQUssTUFDWCx3QkFBQyxPQUFEO0dBQWdCLFdBQVU7YUFBMUIsQ0FDRSx3QkFBQyxPQUFEO0lBQU8sU0FBUyxFQUFFO0lBQVMsT0FBTyxFQUFFO0lBQU8sV0FBVTtjQUNsRCxFQUFFO0dBQ0U7Ozs7YUFDUCx3QkFBQyxVQUFEO0lBQ0UsTUFBSztJQUNMLGNBQVc7SUFDWCxXQUFVO0lBQ1YsZUFBZSxhQUFhLEVBQUUsRUFBRTtjQUVoQyx3QkFBQyxHQUFELEVBQUcsV0FBVSxTQUFVOzs7OztHQUNqQjs7OztXQUNMO0tBWkssRUFBRTs7OztTQVlQLENBQ047Q0FDRTs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJ0b2FzdGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBYIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgZGlzbWlzc1RvYXN0LCB0b2FzdFN0b3JlIH0gZnJvbSAnQC9zdG9yZXMvdG9hc3RzJ1xuaW1wb3J0IHsgQWxlcnQgfSBmcm9tICcuL2FsZXJ0J1xuXG4vKiogUmVnacOjbyBsaXZlOiBsZWl0b3JlcyBkZSB0ZWxhIGFudW5jaWFtIGF2aXNvcyBzZW0gcm91YmFyIG8gZm9jby4gKi9cbmV4cG9ydCBmdW5jdGlvbiBUb2FzdGVyKCkge1xuICBjb25zdCB0b2FzdHMgPSB0b2FzdFN0b3JlLnVzZSgpXG4gIHJldHVybiAoXG4gICAgPGRpdiBhcmlhLWxpdmU9XCJwb2xpdGVcIiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGZpeGVkIGJvdHRvbS00IHJpZ2h0LTQgei1bNjBdIGZsZXggdy1bbWluKDI0cmVtLGNhbGMoMTAwdnctMnJlbSkpXSBmbGV4LWNvbCBnYXAtMlwiPlxuICAgICAge3RvYXN0cy5tYXAoKHQpID0+IChcbiAgICAgICAgPGRpdiBrZXk9e3QuaWR9IGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLWF1dG8gcmVsYXRpdmUgc2hhZG93LWxnXCI+XG4gICAgICAgICAgPEFsZXJ0IHZhcmlhbnQ9e3QudmFyaWFudH0gdGl0bGU9e3QudGl0bGV9IGNsYXNzTmFtZT1cImJnLWNhcmQgcHItOVwiPlxuICAgICAgICAgICAge3QuZGVzY3JpcHRpb259XG4gICAgICAgICAgPC9BbGVydD5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJEaXNwZW5zYXIgYXZpc29cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMiB0b3AtMiByb3VuZGVkIHAtMSBvcGFjaXR5LTcwIGhvdmVyOm9wYWNpdHktMTAwXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGRpc21pc3NUb2FzdCh0LmlkKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJzaXplLTRcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkpfVxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=