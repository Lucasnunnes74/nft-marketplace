const useSyncExternalStore = __vite__cjsImport0_react["useSyncExternalStore"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
/** Store externa mínima (sem dependências) para estado de UI que não vem do servidor. */
export function createStore(initial) {
	let state = initial;
	const listeners = new Set();
	return {
		get: () => state,
		set(next) {
			state = typeof next === "function" ? next(state) : next;
			for (const l of listeners) l();
		},
		subscribe(l) {
			listeners.add(l);
			return () => listeners.delete(l);
		},
		use: () => useSyncExternalStore((l) => {
			listeners.add(l);
			return () => listeners.delete(l);
		}, () => state, () => state)
	};
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyw0QkFBNEI7O0FBR3JDLE9BQU8sU0FBUyxZQUFlLFNBQVk7Q0FDekMsSUFBSSxRQUFRO0NBQ1osTUFBTSxZQUFZLElBQUksSUFBZ0I7Q0FDdEMsT0FBTztFQUNMLFdBQVc7RUFDWCxJQUFJLE1BQTRCO0dBQzlCLFFBQVEsT0FBTyxTQUFTLGFBQWMsS0FBcUIsS0FBSyxJQUFJO0dBQ3BFLEtBQUssTUFBTSxLQUFLLFdBQVcsRUFBRTtFQUMvQjtFQUNBLFVBQVUsR0FBZTtHQUN2QixVQUFVLElBQUksQ0FBQztHQUNmLGFBQWEsVUFBVSxPQUFPLENBQUM7RUFDakM7RUFDQSxXQUFXLHNCQUNSLE1BQU07R0FDTCxVQUFVLElBQUksQ0FBQztHQUNmLGFBQWEsVUFBVSxPQUFPLENBQUM7RUFDakMsU0FDTSxhQUNBLEtBQ1I7Q0FDRjtBQUNGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImNyZWF0ZS1zdG9yZS50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTeW5jRXh0ZXJuYWxTdG9yZSB9IGZyb20gJ3JlYWN0J1xuXG4vKiogU3RvcmUgZXh0ZXJuYSBtw61uaW1hIChzZW0gZGVwZW5kw6puY2lhcykgcGFyYSBlc3RhZG8gZGUgVUkgcXVlIG7Do28gdmVtIGRvIHNlcnZpZG9yLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVN0b3JlPFQ+KGluaXRpYWw6IFQpIHtcbiAgbGV0IHN0YXRlID0gaW5pdGlhbFxuICBjb25zdCBsaXN0ZW5lcnMgPSBuZXcgU2V0PCgpID0+IHZvaWQ+KClcbiAgcmV0dXJuIHtcbiAgICBnZXQ6ICgpID0+IHN0YXRlLFxuICAgIHNldChuZXh0OiBUIHwgKChwcmV2OiBUKSA9PiBUKSkge1xuICAgICAgc3RhdGUgPSB0eXBlb2YgbmV4dCA9PT0gJ2Z1bmN0aW9uJyA/IChuZXh0IGFzIChwOiBUKSA9PiBUKShzdGF0ZSkgOiBuZXh0XG4gICAgICBmb3IgKGNvbnN0IGwgb2YgbGlzdGVuZXJzKSBsKClcbiAgICB9LFxuICAgIHN1YnNjcmliZShsOiAoKSA9PiB2b2lkKSB7XG4gICAgICBsaXN0ZW5lcnMuYWRkKGwpXG4gICAgICByZXR1cm4gKCkgPT4gbGlzdGVuZXJzLmRlbGV0ZShsKVxuICAgIH0sXG4gICAgdXNlOiAoKSA9PiB1c2VTeW5jRXh0ZXJuYWxTdG9yZShcbiAgICAgIChsKSA9PiB7XG4gICAgICAgIGxpc3RlbmVycy5hZGQobClcbiAgICAgICAgcmV0dXJuICgpID0+IGxpc3RlbmVycy5kZWxldGUobClcbiAgICAgIH0sXG4gICAgICAoKSA9PiBzdGF0ZSxcbiAgICAgICgpID0+IHN0YXRlLFxuICAgICksXG4gIH1cbn1cbiJdfQ==