import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/footer.tsx");const useId = __vite__cjsImport1_react["useId"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { z } from "/node_modules/.vite/deps/zod.js?v=fc04a259";
import { realtimeStatus } from "/src/stores/realtime-status.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/footer.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const features = [
	{
		letter: "W",
		title: "Segurança da carteira",
		text: "Proteja sua carteira e colecione arte digital verificada com confiança."
	},
	{
		letter: "C",
		title: "Criadores em destaque",
		text: "Conheça artistas, estúdios e comunidades que moldam a cultura digital na rede."
	},
	{
		letter: "D",
		title: "Alertas de lançamentos",
		text: "Receba calendários de cunhagem, novidades de listas de acesso e análises do mercado."
	}
];
const helpLinks = [
	"Central de ajuda",
	"Como comprar NFTs",
	"Carteira e segurança",
	"Política do mercado",
	"Denunciar item"
];
const collectionLinks = [
	{
		label: "Arte digital",
		category: "art"
	},
	{
		label: "Fotografia",
		category: "photography"
	},
	{
		label: "Música",
		category: "music"
	},
	{
		label: "Arte 3D",
		category: "3d"
	},
	{
		label: "Utilidade",
		category: "utility"
	}
];
const socials = [
	{
		name: "Facebook",
		icon: "social-facebook"
	},
	{
		name: "Instagram",
		icon: "social-instagram"
	},
	{
		name: "Twitter",
		icon: "social-twitter"
	},
	{
		name: "LinkedIn",
		icon: "social-linkedin"
	},
	{
		name: "YouTube",
		icon: "social-youtube"
	}
];
const statusText = {
	connected: "Ao vivo",
	connecting: "Conectando…",
	reconnecting: "Reconectando…",
	offline: "Offline"
};
export function LiveIndicator({ className }) {
	_s();
	const status = realtimeStatus.use();
	return /* @__PURE__ */ _jsxDEV("span", {
		className: cn("inline-flex items-center gap-1.5 text-xs text-muted-foreground", className),
		title: "Preços e estoque atualizados em tempo real",
		children: [/* @__PURE__ */ _jsxDEV("span", {
			"aria-hidden": true,
			className: cn("size-2 rounded-full", status === "connected" ? "bg-success" : status === "offline" ? "bg-subtle" : "animate-pulse bg-warning")
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("span", {
			className: "sr-only",
			children: "Tempo real: "
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 9
		}, this), statusText[status]] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
}
_s(LiveIndicator, "QZ09JMTCcTW4+djAgjnsbGk3lSw=", false, function() {
	return [realtimeStatus.use];
});
_c = LiveIndicator;
export function Footer() {
	return /* @__PURE__ */ _jsxDEV("footer", {
		className: "flex flex-col",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-card px-6 py-8 md:h-[250px] md:p-8",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col gap-8 md:flex-row md:items-end md:justify-between md:gap-0",
					children: [features.map((f, i) => /* @__PURE__ */ _jsxDEV("div", {
						className: "flex md:contents",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: cn("flex flex-col gap-3 px-4", i === 0 ? "md:flex-1" : "md:w-[264px]"),
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									"aria-hidden": true,
									className: "grid size-[74px] place-items-center rounded-full bg-primary text-2xl font-bold text-primary-foreground",
									children: f.letter
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 65,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[17px] font-bold leading-4 text-foreground",
									children: f.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 68,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "w-[204px] text-sm leading-[22px] text-muted-foreground",
									children: f.text
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 69,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							"aria-hidden": true,
							className: "hidden w-px self-stretch bg-primary md:block"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 15
						}, this)]
					}, f.letter, true, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 13
					}, this)), /* @__PURE__ */ _jsxDEV(Newsletter, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-surface-dark px-6 py-6 md:h-[88px] md:px-8 md:py-0",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex h-full flex-col gap-4 md:flex-row md:items-center md:gap-[92px]",
					children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "py-2 text-sm font-bold tracking-[1.4px] text-foreground md:flex-1",
							children: "KURIO"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm leading-[22px] text-foreground md:flex-1 md:whitespace-nowrap",
							children: [
								"Feito para colecionadores,",
								/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 83,
									columnNumber: 13
								}, this),
								"criadores e cultura"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "md:flex-1",
							children: /* @__PURE__ */ _jsxDEV("a", {
								href: "mailto:contato@email.com",
								className: "text-sm leading-[22px] text-foreground hover:text-accent",
								children: "contato@email.com"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 87,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 86,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm leading-[22px] text-foreground md:w-[228px]",
							children: "+55 11 4002 8922"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-card px-6 py-8 md:h-[236px] md:p-8",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "grid gap-8 sm:grid-cols-2 md:flex md:gap-[124px]",
					children: [
						/* @__PURE__ */ _jsxDEV(FooterColumn, {
							title: "Meu perfil",
							children: [
								/* @__PURE__ */ _jsxDEV(FooterLink, {
									to: "/profile",
									children: "Meu perfil"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 98,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(FooterLink, {
									to: "/profile",
									children: "Minha coleção"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 99,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(FooterLink, {
									to: "/profile",
									children: "Atividade"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 100,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(FooterText, { children: "Estúdio do criador" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 101,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(FooterLink, {
									to: "/profile",
									search: { section: "interesse" },
									children: "Lista de interesse"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 102,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(FooterColumn, {
							title: "Central de ajuda",
							children: helpLinks.map((l) => /* @__PURE__ */ _jsxDEV(FooterText, { children: l }, l, false, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 15
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(FooterColumn, {
							title: "Coleções",
							children: collectionLinks.map((c) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
								to: "/",
								search: { category: c.category },
								hash: "catalogo",
								className: "text-sm leading-[30px] text-foreground hover:text-accent",
								children: c.label
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 17
							}, this) }, c.category, false, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 15
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-8 md:w-[228px]",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex w-[190px] flex-col gap-5",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-lg font-bold leading-4 text-foreground",
									children: "Redes sociais"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("ul", {
									className: "flex items-center gap-2.5",
									children: socials.map((s) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("img", {
										src: `/figma/${s.icon}.svg`,
										alt: s.name,
										width: 30,
										height: 30,
										className: "size-[30px]"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 126,
										columnNumber: 21
									}, this) }, s.name, false, {
										fileName: _jsxFileName,
										lineNumber: 125,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 123,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col gap-3",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-lg font-bold leading-4 text-foreground",
									children: "Carteiras compatíveis"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 132,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV(WalletChip, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col items-center gap-1 pt-1.5 sm:flex-row sm:justify-center sm:gap-6",
				children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "text-center text-sm leading-[30px] text-foreground",
					children: "© 2026 Kurio. Propriedade digital para todos."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 140,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(LiveIndicator, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 141,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 139,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 5
	}, this);
}
_c2 = Footer;
export function WalletChip({ className }) {
	return /* @__PURE__ */ _jsxDEV("p", {
		className: cn("flex h-[26px] items-center justify-center whitespace-pre rounded-[6px] border border-border-soft bg-surface-dark px-2 text-[9px] font-bold tracking-[0.1px] text-accent", className),
		children: "METAMASK  •  WALLETCONNECT  •  COINBASE"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 149,
		columnNumber: 5
	}, this);
}
_c3 = WalletChip;
function FooterColumn({ title, children }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-2 md:flex-1",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "text-lg font-bold leading-4 text-foreground",
			children: title
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 163,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("ul", { children }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 164,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 162,
		columnNumber: 5
	}, this);
}
_c4 = FooterColumn;
function FooterLink({ to, search, children }) {
	return /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
		to,
		search: search ?? {},
		className: "text-sm leading-[30px] text-foreground hover:text-accent",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 172,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 171,
		columnNumber: 5
	}, this);
}
_c5 = FooterLink;
function FooterText({ children }) {
	return /* @__PURE__ */ _jsxDEV("li", {
		className: "text-sm leading-[30px] text-foreground",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 180,
		columnNumber: 10
	}, this);
}
_c6 = FooterText;
const emailSchema = z.email();
function Newsletter() {
	_s2();
	const id = useId();
	const [email, setEmail] = useState("");
	const [status, setStatus] = useState(null);
	return /* @__PURE__ */ _jsxDEV("form", {
		noValidate: true,
		className: "flex flex-col gap-3 px-4 md:h-full md:w-[357px]",
		onSubmit: (e) => {
			e.preventDefault();
			if (!emailSchema.safeParse(email.trim()).success) {
				setStatus({
					ok: false,
					text: "Informe um e-mail válido."
				});
				return;
			}
			setEmail("");
			setStatus({
				ok: true,
				text: "Inscrição registrada (simulação)."
			});
		},
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col gap-4",
			children: [/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: id,
				className: "text-lg font-bold leading-4 text-foreground",
				children: "Antecipe-se ao próximo lançamento"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 205,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex h-10 items-center justify-between rounded-[6px] bg-surface-dark pl-3 shadow-[0_0_10px_rgba(10,6,4,0.45)]",
				children: [/* @__PURE__ */ _jsxDEV("input", {
					id,
					type: "email",
					autoComplete: "email",
					placeholder: "digite seu e-mail...",
					value: email,
					"aria-invalid": status?.ok === false,
					"aria-describedby": `${id}-status`,
					onChange: (e) => {
						setEmail(e.target.value);
						setStatus(null);
					},
					className: "h-full min-w-0 flex-1 bg-transparent text-sm leading-4 text-foreground outline-none"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 209,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					className: "flex h-10 w-[85px] shrink-0 items-center justify-center rounded-r-[6px] bg-primary pl-4 pr-1 text-lg font-bold leading-4 text-primary-foreground hover:brightness-110",
					children: "Enviar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 223,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 208,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 204,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("p", {
			id: `${id}-status`,
			"aria-live": "polite",
			className: cn("text-[13px] leading-[22px]", status?.ok === false ? "text-coral" : "text-muted-foreground"),
			children: status?.text ?? "Receba lançamentos selecionados, histórias de criadores e novidades do mercado."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 231,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 191,
		columnNumber: 5
	}, this);
}
_s2(Newsletter, "oTwsn/qNZnLqbC9lKRlATWTBAZs=");
_c7 = Newsletter;
var _c, _c2, _c3, _c4, _c5, _c6, _c7;
$RefreshReg$(_c, "LiveIndicator");
$RefreshReg$(_c2, "Footer");
$RefreshReg$(_c3, "WalletChip");
$RefreshReg$(_c4, "FooterColumn");
$RefreshReg$(_c5, "FooterLink");
$RefreshReg$(_c6, "FooterText");
$RefreshReg$(_c7, "Newsletter");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/footer.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/footer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/footer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/layout/footer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBRXJCLFNBQVMsT0FBTyxnQkFBZ0I7QUFDaEMsU0FBUyxTQUFTO0FBRWxCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsVUFBVTs7OztBQUVuQixNQUFNLFdBQVc7Q0FDZjtFQUFFLFFBQVE7RUFBSyxPQUFPO0VBQXlCLE1BQU07Q0FBMEU7Q0FDL0g7RUFBRSxRQUFRO0VBQUssT0FBTztFQUF5QixNQUFNO0NBQWlGO0NBQ3RJO0VBQUUsUUFBUTtFQUFLLE9BQU87RUFBMEIsTUFBTTtDQUF1RjtBQUMvSTtBQUVBLE1BQU0sWUFBWTtDQUFDO0NBQW9CO0NBQXFCO0NBQXdCO0NBQXVCO0FBQWdCO0FBQzNILE1BQU0sa0JBQTJEO0NBQy9EO0VBQUUsT0FBTztFQUFnQixVQUFVO0NBQU07Q0FDekM7RUFBRSxPQUFPO0VBQWMsVUFBVTtDQUFjO0NBQy9DO0VBQUUsT0FBTztFQUFVLFVBQVU7Q0FBUTtDQUNyQztFQUFFLE9BQU87RUFBVyxVQUFVO0NBQUs7Q0FDbkM7RUFBRSxPQUFPO0VBQWEsVUFBVTtDQUFVO0FBQzVDO0FBQ0EsTUFBTSxVQUFVO0NBQ2Q7RUFBRSxNQUFNO0VBQVksTUFBTTtDQUFrQjtDQUM1QztFQUFFLE1BQU07RUFBYSxNQUFNO0NBQW1CO0NBQzlDO0VBQUUsTUFBTTtFQUFXLE1BQU07Q0FBaUI7Q0FDMUM7RUFBRSxNQUFNO0VBQVksTUFBTTtDQUFrQjtDQUM1QztFQUFFLE1BQU07RUFBVyxNQUFNO0NBQWlCO0FBQzVDO0FBRUEsTUFBTSxhQUFhO0NBQ2pCLFdBQVc7Q0FDWCxZQUFZO0NBQ1osY0FBYztDQUNkLFNBQVM7QUFDWDtBQUVBLE9BQU8sU0FBUyxjQUFjLEVBQUUsYUFBcUM7O0NBQ25FLE1BQU0sU0FBUyxlQUFlLElBQUk7Q0FDbEMsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVyxHQUFHLGtFQUFrRSxTQUFTO0VBQUcsT0FBTTtZQUF4RyxDQUNFLHdCQUFDLFFBQUQ7R0FDRTtHQUNBLFdBQVcsR0FDVCx1QkFDQSxXQUFXLGNBQWMsZUFBZSxXQUFXLFlBQVksY0FBYywwQkFDL0U7RUFDRDs7OztZQUNELHdCQUFDLFFBQUQsYUFDRSx3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUFVO0VBQWtCOzs7O1lBQzNDLFdBQVcsT0FDUjs7OztVQUNGOzs7Ozs7QUFFVjs7Ozs7QUFFQSxPQUFPLFNBQVMsU0FBUztDQUN2QixPQUNFLHdCQUFDLFVBQUQ7RUFBUSxXQUFVO1lBQWxCO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0csU0FBUyxLQUFLLEdBQUcsTUFDaEIsd0JBQUMsT0FBRDtNQUFvQixXQUFVO2dCQUE5QixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFXLEdBQUcsNEJBQTRCLE1BQU0sSUFBSSxjQUFjLGNBQWM7aUJBQXJGO1FBQ0Usd0JBQUMsUUFBRDtTQUFNO1NBQVksV0FBVTttQkFDekIsRUFBRTtRQUNDOzs7OztRQUNOLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFtRCxFQUFFO1FBQVM7Ozs7O1FBQzNFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUEwRCxFQUFFO1FBQVE7Ozs7O09BQzlFOzs7OztnQkFDTCx3QkFBQyxRQUFEO09BQU07T0FBWSxXQUFVO01BQWdEOzs7O2NBQ3pFO1FBVEssRUFBRTs7OztZQVNQLENBQ04sR0FDRCx3QkFBQyxZQUFELENBQWE7Ozs7YUFDVjs7Ozs7O0dBQ0Y7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQW9FO01BQVE7Ozs7O01BQ3pGLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQXFGO1FBRW5GLHdCQUFDLE1BQUQsQ0FBSzs7Ozs7UUFBQztPQUVMOzs7Ozs7TUFDSCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDWCx3QkFBQyxLQUFEO1FBQUcsTUFBSztRQUEyQixXQUFVO2tCQUEyRDtPQUVyRzs7Ozs7TUFDRjs7Ozs7TUFDSCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBc0Q7TUFBbUI7Ozs7O0tBQ25GOzs7Ozs7R0FDRjs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxjQUFEO09BQWMsT0FBTTtpQkFBcEI7UUFDRSx3QkFBQyxZQUFEO1NBQVksSUFBRzttQkFBVztRQUFzQjs7Ozs7UUFDaEQsd0JBQUMsWUFBRDtTQUFZLElBQUc7bUJBQVc7UUFBeUI7Ozs7O1FBQ25ELHdCQUFDLFlBQUQ7U0FBWSxJQUFHO21CQUFXO1FBQXFCOzs7OztRQUMvQyx3QkFBQyxZQUFELFlBQVkscUJBQThCOzs7OztRQUMxQyx3QkFBQyxZQUFEO1NBQVksSUFBRztTQUFXLFFBQVEsRUFBRSxTQUFTLFlBQVk7bUJBQUc7UUFFaEQ7Ozs7O09BQ0E7Ozs7OztNQUNkLHdCQUFDLGNBQUQ7T0FBYyxPQUFNO2lCQUNqQixVQUFVLEtBQUssTUFDZCx3QkFBQyxZQUFELFlBQXFCLEVBQWMsR0FBbEI7Ozs7Y0FBa0IsQ0FDcEM7TUFDVzs7Ozs7TUFDZCx3QkFBQyxjQUFEO09BQWMsT0FBTTtpQkFDakIsZ0JBQWdCLEtBQUssTUFDcEIsd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7UUFBTSxJQUFHO1FBQUksUUFBUSxFQUFFLFVBQVUsRUFBRSxTQUFTO1FBQUcsTUFBSztRQUFXLFdBQVU7a0JBQ3RFLEVBQUU7T0FDQzs7OztnQkFDSixHQUpLLEVBQUU7Ozs7Y0FJUCxDQUNMO01BQ1c7Ozs7O01BQ2Qsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUE4QztRQUFpQjs7OztrQkFDN0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsUUFBUSxLQUFLLE1BQ1osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE9BQUQ7VUFBSyxLQUFLLFVBQVUsRUFBRSxLQUFLO1VBQU8sS0FBSyxFQUFFO1VBQU0sT0FBTztVQUFJLFFBQVE7VUFBSSxXQUFVO1NBQWU7Ozs7a0JBQzdGLEdBRkssRUFBRTs7OztnQkFFUCxDQUNMO1FBQ0M7Ozs7Z0JBQ0Q7Ozs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQThDO1FBQXlCOzs7O2tCQUNyRix3QkFBQyxZQUFELENBQWE7Ozs7Z0JBQ1Y7Ozs7O2VBQ0Y7Ozs7OztLQUNGOzs7Ozs7R0FDRjs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBcUQ7SUFBZ0Q7Ozs7Y0FDbEgsd0JBQUMsZUFBRCxDQUFnQjs7OztZQUNiOzs7Ozs7RUFDQzs7Ozs7O0FBRVo7O0FBRUEsT0FBTyxTQUFTLFdBQVcsRUFBRSxhQUFxQztDQUNoRSxPQUNFLHdCQUFDLEtBQUQ7RUFDRSxXQUFXLEdBQ1QsMktBQ0EsU0FDRjtZQUVDO0NBQ0E7Ozs7O0FBRVA7O0FBRUEsU0FBUyxhQUFhLEVBQUUsT0FBTyxZQUEwRDtDQUN2RixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUErQztFQUFVOzs7O1lBQ3ZFLHdCQUFDLE1BQUQsRUFBSyxTQUFhOzs7O1VBQ2Y7Ozs7OztBQUVUOztBQUVBLFNBQVMsV0FBVyxFQUFFLElBQUksUUFBUSxZQUE4RjtDQUM5SCxPQUNFLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO0VBQVU7RUFBSSxRQUFRLFVBQVUsQ0FBQztFQUFHLFdBQVU7RUFDM0M7Q0FDRzs7OztVQUNKOzs7OztBQUVSOztBQUVBLFNBQVMsV0FBVyxFQUFFLFlBQTJDO0NBQy9ELE9BQU8sd0JBQUMsTUFBRDtFQUFJLFdBQVU7RUFBMEM7Q0FBYTs7Ozs7QUFDOUU7O0FBRUEsTUFBTSxjQUFjLEVBQUUsTUFBTTtBQUU1QixTQUFTLGFBQWE7O0NBQ3BCLE1BQU0sS0FBSyxNQUFNO0NBQ2pCLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBK0MsSUFBSTtDQUUvRSxPQUNFLHdCQUFDLFFBQUQ7RUFDRTtFQUNBLFdBQVU7RUFDVixXQUFXLE1BQU07R0FDZixFQUFFLGVBQWU7R0FDakIsSUFBSSxDQUFDLFlBQVksVUFBVSxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUztJQUNoRCxVQUFVO0tBQUUsSUFBSTtLQUFPLE1BQU07SUFBNEIsQ0FBQztJQUMxRDtHQUNGO0dBQ0EsU0FBUyxFQUFFO0dBQ1gsVUFBVTtJQUFFLElBQUk7SUFBTSxNQUFNO0dBQW9DLENBQUM7RUFDbkU7WUFYRixDQWFFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxTQUFEO0lBQU8sU0FBUztJQUFJLFdBQVU7Y0FBOEM7R0FFckU7Ozs7YUFDUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsU0FBRDtLQUNNO0tBQ0osTUFBSztLQUNMLGNBQWE7S0FDYixhQUFZO0tBQ1osT0FBTztLQUNQLGdCQUFjLFFBQVEsT0FBTztLQUM3QixvQkFBa0IsR0FBRyxHQUFHO0tBQ3hCLFdBQVcsTUFBTTtNQUNmLFNBQVMsRUFBRSxPQUFPLEtBQUs7TUFDdkIsVUFBVSxJQUFJO0tBQ2hCO0tBQ0EsV0FBVTtJQUNYOzs7O2NBQ0Qsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxXQUFVO2VBQ1g7SUFFTzs7OztZQUNMOzs7OztXQUNGOzs7OztZQUNMLHdCQUFDLEtBQUQ7R0FBRyxJQUFJLEdBQUcsR0FBRztHQUFVLGFBQVU7R0FBUyxXQUFXLEdBQUcsOEJBQThCLFFBQVEsT0FBTyxRQUFRLGVBQWUsdUJBQXVCO2FBQ2hKLFFBQVEsUUFBUTtFQUNoQjs7OztVQUNDOzs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJmb290ZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHR5cGUgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZUlkLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCdcbmltcG9ydCB0eXBlIHsgQ2F0ZWdvcnkgfSBmcm9tICdAL2FwaS9jb250cmFjdHMnXG5pbXBvcnQgeyByZWFsdGltZVN0YXR1cyB9IGZyb20gJ0Avc3RvcmVzL3JlYWx0aW1lLXN0YXR1cydcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnXG5cbmNvbnN0IGZlYXR1cmVzID0gW1xuICB7IGxldHRlcjogJ1cnLCB0aXRsZTogJ1NlZ3VyYW7Dp2EgZGEgY2FydGVpcmEnLCB0ZXh0OiAnUHJvdGVqYSBzdWEgY2FydGVpcmEgZSBjb2xlY2lvbmUgYXJ0ZSBkaWdpdGFsIHZlcmlmaWNhZGEgY29tIGNvbmZpYW7Dp2EuJyB9LFxuICB7IGxldHRlcjogJ0MnLCB0aXRsZTogJ0NyaWFkb3JlcyBlbSBkZXN0YXF1ZScsIHRleHQ6ICdDb25oZcOnYSBhcnRpc3RhcywgZXN0w7pkaW9zIGUgY29tdW5pZGFkZXMgcXVlIG1vbGRhbSBhIGN1bHR1cmEgZGlnaXRhbCBuYSByZWRlLicgfSxcbiAgeyBsZXR0ZXI6ICdEJywgdGl0bGU6ICdBbGVydGFzIGRlIGxhbsOnYW1lbnRvcycsIHRleHQ6ICdSZWNlYmEgY2FsZW5kw6FyaW9zIGRlIGN1bmhhZ2VtLCBub3ZpZGFkZXMgZGUgbGlzdGFzIGRlIGFjZXNzbyBlIGFuw6FsaXNlcyBkbyBtZXJjYWRvLicgfSxcbl1cblxuY29uc3QgaGVscExpbmtzID0gWydDZW50cmFsIGRlIGFqdWRhJywgJ0NvbW8gY29tcHJhciBORlRzJywgJ0NhcnRlaXJhIGUgc2VndXJhbsOnYScsICdQb2zDrXRpY2EgZG8gbWVyY2FkbycsICdEZW51bmNpYXIgaXRlbSddXG5jb25zdCBjb2xsZWN0aW9uTGlua3M6IHsgbGFiZWw6IHN0cmluZzsgY2F0ZWdvcnk6IENhdGVnb3J5IH1bXSA9IFtcbiAgeyBsYWJlbDogJ0FydGUgZGlnaXRhbCcsIGNhdGVnb3J5OiAnYXJ0JyB9LFxuICB7IGxhYmVsOiAnRm90b2dyYWZpYScsIGNhdGVnb3J5OiAncGhvdG9ncmFwaHknIH0sXG4gIHsgbGFiZWw6ICdNw7pzaWNhJywgY2F0ZWdvcnk6ICdtdXNpYycgfSxcbiAgeyBsYWJlbDogJ0FydGUgM0QnLCBjYXRlZ29yeTogJzNkJyB9LFxuICB7IGxhYmVsOiAnVXRpbGlkYWRlJywgY2F0ZWdvcnk6ICd1dGlsaXR5JyB9LFxuXVxuY29uc3Qgc29jaWFscyA9IFtcbiAgeyBuYW1lOiAnRmFjZWJvb2snLCBpY29uOiAnc29jaWFsLWZhY2Vib29rJyB9LFxuICB7IG5hbWU6ICdJbnN0YWdyYW0nLCBpY29uOiAnc29jaWFsLWluc3RhZ3JhbScgfSxcbiAgeyBuYW1lOiAnVHdpdHRlcicsIGljb246ICdzb2NpYWwtdHdpdHRlcicgfSxcbiAgeyBuYW1lOiAnTGlua2VkSW4nLCBpY29uOiAnc29jaWFsLWxpbmtlZGluJyB9LFxuICB7IG5hbWU6ICdZb3VUdWJlJywgaWNvbjogJ3NvY2lhbC15b3V0dWJlJyB9LFxuXVxuXG5jb25zdCBzdGF0dXNUZXh0ID0ge1xuICBjb25uZWN0ZWQ6ICdBbyB2aXZvJyxcbiAgY29ubmVjdGluZzogJ0NvbmVjdGFuZG/igKYnLFxuICByZWNvbm5lY3Rpbmc6ICdSZWNvbmVjdGFuZG/igKYnLFxuICBvZmZsaW5lOiAnT2ZmbGluZScsXG59IGFzIGNvbnN0XG5cbmV4cG9ydCBmdW5jdGlvbiBMaXZlSW5kaWNhdG9yKHsgY2xhc3NOYW1lIH06IHsgY2xhc3NOYW1lPzogc3RyaW5nIH0pIHtcbiAgY29uc3Qgc3RhdHVzID0gcmVhbHRpbWVTdGF0dXMudXNlKClcbiAgcmV0dXJuIChcbiAgICA8c3BhbiBjbGFzc05hbWU9e2NuKCdpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCcsIGNsYXNzTmFtZSl9IHRpdGxlPVwiUHJlw6dvcyBlIGVzdG9xdWUgYXR1YWxpemFkb3MgZW0gdGVtcG8gcmVhbFwiPlxuICAgICAgPHNwYW5cbiAgICAgICAgYXJpYS1oaWRkZW5cbiAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAnc2l6ZS0yIHJvdW5kZWQtZnVsbCcsXG4gICAgICAgICAgc3RhdHVzID09PSAnY29ubmVjdGVkJyA/ICdiZy1zdWNjZXNzJyA6IHN0YXR1cyA9PT0gJ29mZmxpbmUnID8gJ2JnLXN1YnRsZScgOiAnYW5pbWF0ZS1wdWxzZSBiZy13YXJuaW5nJyxcbiAgICAgICAgKX1cbiAgICAgIC8+XG4gICAgICA8c3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPlRlbXBvIHJlYWw6IDwvc3Bhbj5cbiAgICAgICAge3N0YXR1c1RleHRbc3RhdHVzXX1cbiAgICAgIDwvc3Bhbj5cbiAgICA8L3NwYW4+XG4gIClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEZvb3RlcigpIHtcbiAgcmV0dXJuIChcbiAgICA8Zm9vdGVyIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctY2FyZCBweC02IHB5LTggbWQ6aC1bMjUwcHhdIG1kOnAtOFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTggbWQ6ZmxleC1yb3cgbWQ6aXRlbXMtZW5kIG1kOmp1c3RpZnktYmV0d2VlbiBtZDpnYXAtMFwiPlxuICAgICAgICAgIHtmZWF0dXJlcy5tYXAoKGYsIGkpID0+IChcbiAgICAgICAgICAgIDxkaXYga2V5PXtmLmxldHRlcn0gY2xhc3NOYW1lPVwiZmxleCBtZDpjb250ZW50c1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y24oJ2ZsZXggZmxleC1jb2wgZ2FwLTMgcHgtNCcsIGkgPT09IDAgPyAnbWQ6ZmxleC0xJyA6ICdtZDp3LVsyNjRweF0nKX0+XG4gICAgICAgICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW4gY2xhc3NOYW1lPVwiZ3JpZCBzaXplLVs3NHB4XSBwbGFjZS1pdGVtcy1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLXByaW1hcnkgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICB7Zi5sZXR0ZXJ9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE3cHhdIGZvbnQtYm9sZCBsZWFkaW5nLTQgdGV4dC1mb3JlZ3JvdW5kXCI+e2YudGl0bGV9PC9wPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInctWzIwNHB4XSB0ZXh0LXNtIGxlYWRpbmctWzIycHhdIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntmLnRleHR9PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW4gY2xhc3NOYW1lPVwiaGlkZGVuIHctcHggc2VsZi1zdHJldGNoIGJnLXByaW1hcnkgbWQ6YmxvY2tcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgICAgPE5ld3NsZXR0ZXIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlLWRhcmsgcHgtNiBweS02IG1kOmgtWzg4cHhdIG1kOnB4LTggbWQ6cHktMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIGZsZXgtY29sIGdhcC00IG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBtZDpnYXAtWzkycHhdXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwicHktMiB0ZXh0LXNtIGZvbnQtYm9sZCB0cmFja2luZy1bMS40cHhdIHRleHQtZm9yZWdyb3VuZCBtZDpmbGV4LTFcIj5LVVJJTzwvcD5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGxlYWRpbmctWzIycHhdIHRleHQtZm9yZWdyb3VuZCBtZDpmbGV4LTEgbWQ6d2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgIEZlaXRvIHBhcmEgY29sZWNpb25hZG9yZXMsXG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIGNyaWFkb3JlcyBlIGN1bHR1cmFcbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWQ6ZmxleC0xXCI+XG4gICAgICAgICAgICA8YSBocmVmPVwibWFpbHRvOmNvbnRhdG9AZW1haWwuY29tXCIgY2xhc3NOYW1lPVwidGV4dC1zbSBsZWFkaW5nLVsyMnB4XSB0ZXh0LWZvcmVncm91bmQgaG92ZXI6dGV4dC1hY2NlbnRcIj5cbiAgICAgICAgICAgICAgY29udGF0b0BlbWFpbC5jb21cbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBsZWFkaW5nLVsyMnB4XSB0ZXh0LWZvcmVncm91bmQgbWQ6dy1bMjI4cHhdXCI+KzU1IDExIDQwMDIgODkyMjwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1jYXJkIHB4LTYgcHktOCBtZDpoLVsyMzZweF0gbWQ6cC04XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtOCBzbTpncmlkLWNvbHMtMiBtZDpmbGV4IG1kOmdhcC1bMTI0cHhdXCI+XG4gICAgICAgICAgPEZvb3RlckNvbHVtbiB0aXRsZT1cIk1ldSBwZXJmaWxcIj5cbiAgICAgICAgICAgIDxGb290ZXJMaW5rIHRvPVwiL3Byb2ZpbGVcIj5NZXUgcGVyZmlsPC9Gb290ZXJMaW5rPlxuICAgICAgICAgICAgPEZvb3RlckxpbmsgdG89XCIvcHJvZmlsZVwiPk1pbmhhIGNvbGXDp8OjbzwvRm9vdGVyTGluaz5cbiAgICAgICAgICAgIDxGb290ZXJMaW5rIHRvPVwiL3Byb2ZpbGVcIj5BdGl2aWRhZGU8L0Zvb3Rlckxpbms+XG4gICAgICAgICAgICA8Rm9vdGVyVGV4dD5Fc3TDumRpbyBkbyBjcmlhZG9yPC9Gb290ZXJUZXh0PlxuICAgICAgICAgICAgPEZvb3RlckxpbmsgdG89XCIvcHJvZmlsZVwiIHNlYXJjaD17eyBzZWN0aW9uOiAnaW50ZXJlc3NlJyB9fT5cbiAgICAgICAgICAgICAgTGlzdGEgZGUgaW50ZXJlc3NlXG4gICAgICAgICAgICA8L0Zvb3Rlckxpbms+XG4gICAgICAgICAgPC9Gb290ZXJDb2x1bW4+XG4gICAgICAgICAgPEZvb3RlckNvbHVtbiB0aXRsZT1cIkNlbnRyYWwgZGUgYWp1ZGFcIj5cbiAgICAgICAgICAgIHtoZWxwTGlua3MubWFwKChsKSA9PiAoXG4gICAgICAgICAgICAgIDxGb290ZXJUZXh0IGtleT17bH0+e2x9PC9Gb290ZXJUZXh0PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9Gb290ZXJDb2x1bW4+XG4gICAgICAgICAgPEZvb3RlckNvbHVtbiB0aXRsZT1cIkNvbGXDp8O1ZXNcIj5cbiAgICAgICAgICAgIHtjb2xsZWN0aW9uTGlua3MubWFwKChjKSA9PiAoXG4gICAgICAgICAgICAgIDxsaSBrZXk9e2MuY2F0ZWdvcnl9PlxuICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL1wiIHNlYXJjaD17eyBjYXRlZ29yeTogYy5jYXRlZ29yeSB9fSBoYXNoPVwiY2F0YWxvZ29cIiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGxlYWRpbmctWzMwcHhdIHRleHQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWFjY2VudFwiPlxuICAgICAgICAgICAgICAgICAge2MubGFiZWx9XG4gICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9Gb290ZXJDb2x1bW4+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC04IG1kOnctWzIyOHB4XVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHctWzE5MHB4XSBmbGV4LWNvbCBnYXAtNVwiPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgbGVhZGluZy00IHRleHQtZm9yZWdyb3VuZFwiPlJlZGVzIHNvY2lhaXM8L2gyPlxuICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgIHtzb2NpYWxzLm1hcCgocykgPT4gKFxuICAgICAgICAgICAgICAgICAgPGxpIGtleT17cy5uYW1lfT5cbiAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2AvZmlnbWEvJHtzLmljb259LnN2Z2B9IGFsdD17cy5uYW1lfSB3aWR0aD17MzB9IGhlaWdodD17MzB9IGNsYXNzTmFtZT1cInNpemUtWzMwcHhdXCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgbGVhZGluZy00IHRleHQtZm9yZWdyb3VuZFwiPkNhcnRlaXJhcyBjb21wYXTDrXZlaXM8L2gyPlxuICAgICAgICAgICAgICA8V2FsbGV0Q2hpcCAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHQtMS41IHNtOmZsZXgtcm93IHNtOmp1c3RpZnktY2VudGVyIHNtOmdhcC02XCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtc20gbGVhZGluZy1bMzBweF0gdGV4dC1mb3JlZ3JvdW5kXCI+wqkgMjAyNiBLdXJpby4gUHJvcHJpZWRhZGUgZGlnaXRhbCBwYXJhIHRvZG9zLjwvcD5cbiAgICAgICAgPExpdmVJbmRpY2F0b3IgLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvZm9vdGVyPlxuICApXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBXYWxsZXRDaGlwKHsgY2xhc3NOYW1lIH06IHsgY2xhc3NOYW1lPzogc3RyaW5nIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8cFxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgJ2ZsZXggaC1bMjZweF0gaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHdoaXRlc3BhY2UtcHJlIHJvdW5kZWQtWzZweF0gYm9yZGVyIGJvcmRlci1ib3JkZXItc29mdCBiZy1zdXJmYWNlLWRhcmsgcHgtMiB0ZXh0LVs5cHhdIGZvbnQtYm9sZCB0cmFja2luZy1bMC4xcHhdIHRleHQtYWNjZW50JyxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgKX1cbiAgICA+XG4gICAgICB7J01FVEFNQVNLICDigKIgIFdBTExFVENPTk5FQ1QgIOKAoiAgQ09JTkJBU0UnfVxuICAgIDwvcD5cbiAgKVxufVxuXG5mdW5jdGlvbiBGb290ZXJDb2x1bW4oeyB0aXRsZSwgY2hpbGRyZW4gfTogeyB0aXRsZTogc3RyaW5nOyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTIgbWQ6ZmxleC0xXCI+XG4gICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgbGVhZGluZy00IHRleHQtZm9yZWdyb3VuZFwiPnt0aXRsZX08L2gyPlxuICAgICAgPHVsPntjaGlsZHJlbn08L3VsPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIEZvb3RlckxpbmsoeyB0bywgc2VhcmNoLCBjaGlsZHJlbiB9OiB7IHRvOiAnL3Byb2ZpbGUnOyBzZWFyY2g/OiB7IHNlY3Rpb246ICdpbnRlcmVzc2UnIH07IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuICByZXR1cm4gKFxuICAgIDxsaT5cbiAgICAgIDxMaW5rIHRvPXt0b30gc2VhcmNoPXtzZWFyY2ggPz8ge319IGNsYXNzTmFtZT1cInRleHQtc20gbGVhZGluZy1bMzBweF0gdGV4dC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtYWNjZW50XCI+XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDwvTGluaz5cbiAgICA8L2xpPlxuICApXG59XG5cbmZ1bmN0aW9uIEZvb3RlclRleHQoeyBjaGlsZHJlbiB9OiB7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuICByZXR1cm4gPGxpIGNsYXNzTmFtZT1cInRleHQtc20gbGVhZGluZy1bMzBweF0gdGV4dC1mb3JlZ3JvdW5kXCI+e2NoaWxkcmVufTwvbGk+XG59XG5cbmNvbnN0IGVtYWlsU2NoZW1hID0gei5lbWFpbCgpXG5cbmZ1bmN0aW9uIE5ld3NsZXR0ZXIoKSB7XG4gIGNvbnN0IGlkID0gdXNlSWQoKVxuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbc3RhdHVzLCBzZXRTdGF0dXNdID0gdXNlU3RhdGU8eyBvazogYm9vbGVhbjsgdGV4dDogc3RyaW5nIH0gfCBudWxsPihudWxsKVxuXG4gIHJldHVybiAoXG4gICAgPGZvcm1cbiAgICAgIG5vVmFsaWRhdGVcbiAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTMgcHgtNCBtZDpoLWZ1bGwgbWQ6dy1bMzU3cHhdXCJcbiAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgaWYgKCFlbWFpbFNjaGVtYS5zYWZlUGFyc2UoZW1haWwudHJpbSgpKS5zdWNjZXNzKSB7XG4gICAgICAgICAgc2V0U3RhdHVzKHsgb2s6IGZhbHNlLCB0ZXh0OiAnSW5mb3JtZSB1bSBlLW1haWwgdsOhbGlkby4nIH0pXG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cbiAgICAgICAgc2V0RW1haWwoJycpXG4gICAgICAgIHNldFN0YXR1cyh7IG9rOiB0cnVlLCB0ZXh0OiAnSW5zY3Jpw6fDo28gcmVnaXN0cmFkYSAoc2ltdWxhw6fDo28pLicgfSlcbiAgICAgIH19XG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00XCI+XG4gICAgICAgIDxsYWJlbCBodG1sRm9yPXtpZH0gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgbGVhZGluZy00IHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgIEFudGVjaXBlLXNlIGFvIHByw7N4aW1vIGxhbsOnYW1lbnRvXG4gICAgICAgIDwvbGFiZWw+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTEwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC1bNnB4XSBiZy1zdXJmYWNlLWRhcmsgcGwtMyBzaGFkb3ctWzBfMF8xMHB4X3JnYmEoMTAsNiw0LDAuNDUpXVwiPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgaWQ9e2lkfVxuICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImVtYWlsXCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZGlnaXRlIHNldSBlLW1haWwuLi5cIlxuICAgICAgICAgICAgdmFsdWU9e2VtYWlsfVxuICAgICAgICAgICAgYXJpYS1pbnZhbGlkPXtzdGF0dXM/Lm9rID09PSBmYWxzZX1cbiAgICAgICAgICAgIGFyaWEtZGVzY3JpYmVkYnk9e2Ake2lkfS1zdGF0dXNgfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgIHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKVxuICAgICAgICAgICAgICBzZXRTdGF0dXMobnVsbClcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgbWluLXctMCBmbGV4LTEgYmctdHJhbnNwYXJlbnQgdGV4dC1zbSBsZWFkaW5nLTQgdGV4dC1mb3JlZ3JvdW5kIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC0xMCB3LVs4NXB4XSBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1yLVs2cHhdIGJnLXByaW1hcnkgcGwtNCBwci0xIHRleHQtbGcgZm9udC1ib2xkIGxlYWRpbmctNCB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBob3ZlcjpicmlnaHRuZXNzLTExMFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgRW52aWFyXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8cCBpZD17YCR7aWR9LXN0YXR1c2B9IGFyaWEtbGl2ZT1cInBvbGl0ZVwiIGNsYXNzTmFtZT17Y24oJ3RleHQtWzEzcHhdIGxlYWRpbmctWzIycHhdJywgc3RhdHVzPy5vayA9PT0gZmFsc2UgPyAndGV4dC1jb3JhbCcgOiAndGV4dC1tdXRlZC1mb3JlZ3JvdW5kJyl9PlxuICAgICAgICB7c3RhdHVzPy50ZXh0ID8/ICdSZWNlYmEgbGFuw6dhbWVudG9zIHNlbGVjaW9uYWRvcywgaGlzdMOzcmlhcyBkZSBjcmlhZG9yZXMgZSBub3ZpZGFkZXMgZG8gbWVyY2Fkby4nfVxuICAgICAgPC9wPlxuICAgIDwvZm9ybT5cbiAgKVxufVxuIl19