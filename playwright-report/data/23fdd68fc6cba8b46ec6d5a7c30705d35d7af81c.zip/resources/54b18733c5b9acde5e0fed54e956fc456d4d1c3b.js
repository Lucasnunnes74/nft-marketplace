import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/session-effects.tsx");const useEffect = __vite__cjsImport2_react["useEffect"]; const useRef = __vite__cjsImport2_react["useRef"];import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=5d4ac5a9";
import { useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=5644a95d";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { sessionStore } from "/src/auth/session-store.ts";
import { useSessionState } from "/src/auth/use-session.ts";
import { resetRealtimeState } from "/src/realtime/socket.ts";
import { clearNotices } from "/src/stores/market-notices.ts";
import { toast } from "/src/stores/toasts.ts";
var _s = $RefreshSig$();
/**
* Reage a mudanças de sessão (login, logout, expiração):
*  - limpa o cache do usuário anterior (nada privado vaza entre sessões);
*  - reavalia os guardas de rota (rotas privadas redirecionam ao login,
*    preservando o caminho de volta);
*  - agenda a expiração local do token.
*/
export function SessionEffects() {
	_s();
	const qc = useQueryClient();
	const router = useRouter();
	const { session, userId } = useSessionState();
	const previous = useRef(userId);
	useEffect(() => {
		if (previous.current === userId) return;
		previous.current = userId;
		void qc.cancelQueries();
		qc.removeQueries();
		resetRealtimeState();
		clearNotices();
		const reason = sessionStore.consumeEndReason();
		if (reason === "expired" || reason === "unauthorized") {
			toast({
				title: "Sua sessão expirou",
				description: "Entre novamente para continuar. Seu carrinho foi mantido.",
				variant: "warning"
			});
		}
		void router.invalidate();
	}, [
		userId,
		qc,
		router
	]);
	useEffect(() => {
		if (!session) return;
		const ms = new Date(session.expiresAt).getTime() - Date.now();
		const id = setTimeout(() => sessionStore.end("expired"), Math.max(ms, 0));
		return () => clearTimeout(id);
	}, [session]);
	return null;
}
_s(SessionEffects, "TeU8uJZQZnEpyqW7c7bsm91cU5I=", false, function() {
	return [
		useQueryClient,
		useRouter,
		useSessionState
	];
});
_c = SessionEffects;
var _c;
$RefreshReg$(_c, "SessionEffects");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/app/session-effects.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/app/session-effects.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/app/session-effects.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/app/session-effects.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxXQUFXLGNBQWM7QUFDbEMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxhQUFhOzs7Ozs7Ozs7QUFTdEIsT0FBTyxTQUFTLGlCQUFpQjs7Q0FDL0IsTUFBTSxLQUFLLGVBQWU7Q0FDMUIsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxFQUFFLFNBQVMsV0FBVyxnQkFBZ0I7Q0FDNUMsTUFBTSxXQUFXLE9BQXNCLE1BQU07Q0FFN0MsZ0JBQWdCO0VBQ2QsSUFBSSxTQUFTLFlBQVksUUFBUTtFQUNqQyxTQUFTLFVBQVU7RUFDbkIsS0FBSyxHQUFHLGNBQWM7RUFDdEIsR0FBRyxjQUFjO0VBQ2pCLG1CQUFtQjtFQUNuQixhQUFhO0VBQ2IsTUFBTSxTQUFTLGFBQWEsaUJBQWlCO0VBQzdDLElBQUksV0FBVyxhQUFhLFdBQVcsZ0JBQWdCO0dBQ3JELE1BQU07SUFDSixPQUFPO0lBQ1AsYUFBYTtJQUNiLFNBQVM7R0FDWCxDQUFDO0VBQ0g7RUFDQSxLQUFLLE9BQU8sV0FBVztDQUN6QixHQUFHO0VBQUM7RUFBUTtFQUFJO0NBQU0sQ0FBQztDQUV2QixnQkFBZ0I7RUFDZCxJQUFJLENBQUMsU0FBUztFQUNkLE1BQU0sS0FBSyxJQUFJLEtBQUssUUFBUSxTQUFTLENBQUMsQ0FBQyxRQUFRLElBQUksS0FBSyxJQUFJO0VBQzVELE1BQU0sS0FBSyxpQkFBaUIsYUFBYSxJQUFJLFNBQVMsR0FBRyxLQUFLLElBQUksSUFBSSxDQUFDLENBQUM7RUFDeEUsYUFBYSxhQUFhLEVBQUU7Q0FDOUIsR0FBRyxDQUFDLE9BQU8sQ0FBQztDQUVaLE9BQU87QUFDVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzZXNzaW9uLWVmZmVjdHMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBzZXNzaW9uU3RvcmUgfSBmcm9tICdAL2F1dGgvc2Vzc2lvbi1zdG9yZSdcbmltcG9ydCB7IHVzZVNlc3Npb25TdGF0ZSB9IGZyb20gJ0AvYXV0aC91c2Utc2Vzc2lvbidcbmltcG9ydCB7IHJlc2V0UmVhbHRpbWVTdGF0ZSB9IGZyb20gJ0AvcmVhbHRpbWUvc29ja2V0J1xuaW1wb3J0IHsgY2xlYXJOb3RpY2VzIH0gZnJvbSAnQC9zdG9yZXMvbWFya2V0LW5vdGljZXMnXG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ0Avc3RvcmVzL3RvYXN0cydcblxuLyoqXG4gKiBSZWFnZSBhIG11ZGFuw6dhcyBkZSBzZXNzw6NvIChsb2dpbiwgbG9nb3V0LCBleHBpcmHDp8Ojbyk6XG4gKiAgLSBsaW1wYSBvIGNhY2hlIGRvIHVzdcOhcmlvIGFudGVyaW9yIChuYWRhIHByaXZhZG8gdmF6YSBlbnRyZSBzZXNzw7Vlcyk7XG4gKiAgLSByZWF2YWxpYSBvcyBndWFyZGFzIGRlIHJvdGEgKHJvdGFzIHByaXZhZGFzIHJlZGlyZWNpb25hbSBhbyBsb2dpbixcbiAqICAgIHByZXNlcnZhbmRvIG8gY2FtaW5obyBkZSB2b2x0YSk7XG4gKiAgLSBhZ2VuZGEgYSBleHBpcmHDp8OjbyBsb2NhbCBkbyB0b2tlbi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFNlc3Npb25FZmZlY3RzKCkge1xuICBjb25zdCBxYyA9IHVzZVF1ZXJ5Q2xpZW50KClcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcbiAgY29uc3QgeyBzZXNzaW9uLCB1c2VySWQgfSA9IHVzZVNlc3Npb25TdGF0ZSgpXG4gIGNvbnN0IHByZXZpb3VzID0gdXNlUmVmPHN0cmluZyB8IG51bGw+KHVzZXJJZClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChwcmV2aW91cy5jdXJyZW50ID09PSB1c2VySWQpIHJldHVyblxuICAgIHByZXZpb3VzLmN1cnJlbnQgPSB1c2VySWRcbiAgICB2b2lkIHFjLmNhbmNlbFF1ZXJpZXMoKVxuICAgIHFjLnJlbW92ZVF1ZXJpZXMoKVxuICAgIHJlc2V0UmVhbHRpbWVTdGF0ZSgpXG4gICAgY2xlYXJOb3RpY2VzKClcbiAgICBjb25zdCByZWFzb24gPSBzZXNzaW9uU3RvcmUuY29uc3VtZUVuZFJlYXNvbigpXG4gICAgaWYgKHJlYXNvbiA9PT0gJ2V4cGlyZWQnIHx8IHJlYXNvbiA9PT0gJ3VuYXV0aG9yaXplZCcpIHtcbiAgICAgIHRvYXN0KHtcbiAgICAgICAgdGl0bGU6ICdTdWEgc2Vzc8OjbyBleHBpcm91JyxcbiAgICAgICAgZGVzY3JpcHRpb246ICdFbnRyZSBub3ZhbWVudGUgcGFyYSBjb250aW51YXIuIFNldSBjYXJyaW5obyBmb2kgbWFudGlkby4nLFxuICAgICAgICB2YXJpYW50OiAnd2FybmluZycsXG4gICAgICB9KVxuICAgIH1cbiAgICB2b2lkIHJvdXRlci5pbnZhbGlkYXRlKClcbiAgfSwgW3VzZXJJZCwgcWMsIHJvdXRlcl0pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXNlc3Npb24pIHJldHVyblxuICAgIGNvbnN0IG1zID0gbmV3IERhdGUoc2Vzc2lvbi5leHBpcmVzQXQpLmdldFRpbWUoKSAtIERhdGUubm93KClcbiAgICBjb25zdCBpZCA9IHNldFRpbWVvdXQoKCkgPT4gc2Vzc2lvblN0b3JlLmVuZCgnZXhwaXJlZCcpLCBNYXRoLm1heChtcywgMCkpXG4gICAgcmV0dXJuICgpID0+IGNsZWFyVGltZW91dChpZClcbiAgfSwgW3Nlc3Npb25dKVxuXG4gIHJldHVybiBudWxsXG59XG4iXX0=