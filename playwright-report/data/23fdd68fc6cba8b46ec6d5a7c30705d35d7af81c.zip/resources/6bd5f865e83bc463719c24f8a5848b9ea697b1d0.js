import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/button.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport2_react, 1);const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Slot } from "/node_modules/.vite/deps/@radix-ui_react-slot.js?v=8fe49896";
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=79ae7cb2";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=22ccf3e0";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/button.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22ccf3e0";
const buttonVariants = cva("inline-flex cursor-pointer items-center justify-center gap-2 whitespace-nowrap rounded-[6px] text-sm transition-[filter,background-color,color,border-color] disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary font-bold text-primary-foreground hover:brightness-110",
			secondary: "border border-border bg-surface-raised text-foreground hover:border-border-soft",
			outline: "border border-primary font-medium text-accent hover:bg-primary/10",
			ghost: "text-foreground hover:bg-surface-raised",
			destructive: "bg-coral font-bold text-primary-foreground hover:brightness-110",
			link: "text-accent underline-offset-4 hover:underline"
		},
		size: {
			default: "h-10 px-4",
			sm: "h-8 px-3 text-xs",
			lg: "h-[45px] px-6 text-[15px]",
			icon: "size-10"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
const Button = React.forwardRef(_c = ({ className, variant, size, asChild = false, type = "button", ...props }, ref) => {
	const Comp = asChild ? Slot : "button";
	return /* @__PURE__ */ _jsxDEV(Comp, {
		ref,
		...asChild ? {} : { type },
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 7
	}, this);
});
_c2 = Button;
Button.displayName = "Button";
export { Button, buttonVariants };
var _c, _c2;
$RefreshReg$(_c, "Button$React.forwardRef");
$RefreshReg$(_c2, "Button");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/button.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Dell/OneDrive/Documents/projetos/react/nft-marketplace/src/components/ui/button.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsV0FBOEI7QUFDdkMsWUFBWSxXQUFXO0FBQ3ZCLFNBQVMsVUFBVTs7O0FBRW5CLE1BQU0saUJBQWlCLElBQ3JCLDRTQUNBO0NBQ0UsVUFBVTtFQUNSLFNBQVM7R0FDUCxTQUFTO0dBQ1QsV0FBVztHQUNYLFNBQVM7R0FDVCxPQUFPO0dBQ1AsYUFBYTtHQUNiLE1BQU07RUFDUjtFQUNBLE1BQU07R0FDSixTQUFTO0dBQ1QsSUFBSTtHQUNKLElBQUk7R0FDSixNQUFNO0VBQ1I7Q0FDRjtDQUNBLGlCQUFpQjtFQUFFLFNBQVM7RUFBVyxNQUFNO0NBQVU7QUFDekQsQ0FDRjtBQVFBLE1BQU0sU0FBUyxNQUFNLGlCQUNsQixFQUFFLFdBQVcsU0FBUyxNQUFNLFVBQVUsT0FBTyxPQUFPLFVBQVUsR0FBRyxTQUFTLFFBQVE7Q0FDakYsTUFBTSxPQUFPLFVBQVUsT0FBTztDQUM5QixPQUNFLHdCQUFDLE1BQUQ7RUFDTztFQUNMLEdBQUssVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLO0VBQzNCLFdBQVcsR0FBRyxlQUFlO0dBQUU7R0FBUztFQUFLLENBQUMsR0FBRyxTQUFTO0VBQzFELEdBQUk7Q0FDTDs7Ozs7QUFFTCxDQUNGOztBQUNBLE9BQU8sY0FBYztBQUVyQixTQUFTLFFBQVEiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYnV0dG9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTbG90IH0gZnJvbSAnQHJhZGl4LXVpL3JlYWN0LXNsb3QnXG5pbXBvcnQgeyBjdmEsIHR5cGUgVmFyaWFudFByb3BzIH0gZnJvbSAnY2xhc3MtdmFyaWFuY2UtYXV0aG9yaXR5J1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL3V0aWxzJ1xuXG5jb25zdCBidXR0b25WYXJpYW50cyA9IGN2YShcbiAgJ2lubGluZS1mbGV4IGN1cnNvci1wb2ludGVyIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiB3aGl0ZXNwYWNlLW5vd3JhcCByb3VuZGVkLVs2cHhdIHRleHQtc20gdHJhbnNpdGlvbi1bZmlsdGVyLGJhY2tncm91bmQtY29sb3IsY29sb3IsYm9yZGVyLWNvbG9yXSBkaXNhYmxlZDpwb2ludGVyLWV2ZW50cy1ub25lIGRpc2FibGVkOm9wYWNpdHktNTAgYXJpYS1kaXNhYmxlZDpwb2ludGVyLWV2ZW50cy1ub25lIGFyaWEtZGlzYWJsZWQ6b3BhY2l0eS01MCBbJl9zdmddOnNpemUtNCBbJl9zdmddOnNocmluay0wJyxcbiAge1xuICAgIHZhcmlhbnRzOiB7XG4gICAgICB2YXJpYW50OiB7XG4gICAgICAgIGRlZmF1bHQ6ICdiZy1wcmltYXJ5IGZvbnQtYm9sZCB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBob3ZlcjpicmlnaHRuZXNzLTExMCcsXG4gICAgICAgIHNlY29uZGFyeTogJ2JvcmRlciBib3JkZXItYm9yZGVyIGJnLXN1cmZhY2UtcmFpc2VkIHRleHQtZm9yZWdyb3VuZCBob3Zlcjpib3JkZXItYm9yZGVyLXNvZnQnLFxuICAgICAgICBvdXRsaW5lOiAnYm9yZGVyIGJvcmRlci1wcmltYXJ5IGZvbnQtbWVkaXVtIHRleHQtYWNjZW50IGhvdmVyOmJnLXByaW1hcnkvMTAnLFxuICAgICAgICBnaG9zdDogJ3RleHQtZm9yZWdyb3VuZCBob3ZlcjpiZy1zdXJmYWNlLXJhaXNlZCcsXG4gICAgICAgIGRlc3RydWN0aXZlOiAnYmctY29yYWwgZm9udC1ib2xkIHRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kIGhvdmVyOmJyaWdodG5lc3MtMTEwJyxcbiAgICAgICAgbGluazogJ3RleHQtYWNjZW50IHVuZGVybGluZS1vZmZzZXQtNCBob3Zlcjp1bmRlcmxpbmUnLFxuICAgICAgfSxcbiAgICAgIHNpemU6IHtcbiAgICAgICAgZGVmYXVsdDogJ2gtMTAgcHgtNCcsXG4gICAgICAgIHNtOiAnaC04IHB4LTMgdGV4dC14cycsXG4gICAgICAgIGxnOiAnaC1bNDVweF0gcHgtNiB0ZXh0LVsxNXB4XScsXG4gICAgICAgIGljb246ICdzaXplLTEwJyxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBkZWZhdWx0VmFyaWFudHM6IHsgdmFyaWFudDogJ2RlZmF1bHQnLCBzaXplOiAnZGVmYXVsdCcgfSxcbiAgfSxcbilcblxuZXhwb3J0IGludGVyZmFjZSBCdXR0b25Qcm9wc1xuICBleHRlbmRzIFJlYWN0LkJ1dHRvbkhUTUxBdHRyaWJ1dGVzPEhUTUxCdXR0b25FbGVtZW50PixcbiAgICBWYXJpYW50UHJvcHM8dHlwZW9mIGJ1dHRvblZhcmlhbnRzPiB7XG4gIGFzQ2hpbGQ/OiBib29sZWFuXG59XG5cbmNvbnN0IEJ1dHRvbiA9IFJlYWN0LmZvcndhcmRSZWY8SFRNTEJ1dHRvbkVsZW1lbnQsIEJ1dHRvblByb3BzPihcbiAgKHsgY2xhc3NOYW1lLCB2YXJpYW50LCBzaXplLCBhc0NoaWxkID0gZmFsc2UsIHR5cGUgPSAnYnV0dG9uJywgLi4ucHJvcHMgfSwgcmVmKSA9PiB7XG4gICAgY29uc3QgQ29tcCA9IGFzQ2hpbGQgPyBTbG90IDogJ2J1dHRvbidcbiAgICByZXR1cm4gKFxuICAgICAgPENvbXBcbiAgICAgICAgcmVmPXtyZWZ9XG4gICAgICAgIHsuLi4oYXNDaGlsZCA/IHt9IDogeyB0eXBlIH0pfVxuICAgICAgICBjbGFzc05hbWU9e2NuKGJ1dHRvblZhcmlhbnRzKHsgdmFyaWFudCwgc2l6ZSB9KSwgY2xhc3NOYW1lKX1cbiAgICAgICAgey4uLnByb3BzfVxuICAgICAgLz5cbiAgICApXG4gIH0sXG4pXG5CdXR0b24uZGlzcGxheU5hbWUgPSAnQnV0dG9uJ1xuXG5leHBvcnQgeyBCdXR0b24sIGJ1dHRvblZhcmlhbnRzIH1cbiJdfQ==